__author__="NightRain"
yciXKmBOIkPJsbTrRwWFjxQHEYLVhS=object
yciXKmBOIkPJsbTrRwWFjxQHEYLVht=None
yciXKmBOIkPJsbTrRwWFjxQHEYLVhl=False
yciXKmBOIkPJsbTrRwWFjxQHEYLVhf=print
yciXKmBOIkPJsbTrRwWFjxQHEYLVho=str
yciXKmBOIkPJsbTrRwWFjxQHEYLVhN=True
yciXKmBOIkPJsbTrRwWFjxQHEYLVhG=Exception
yciXKmBOIkPJsbTrRwWFjxQHEYLVhq=range
yciXKmBOIkPJsbTrRwWFjxQHEYLVhM=int
import urllib
import http.cookiejar 
import re
import json
import sys
import time
import requests
import datetime
import base64
yciXKmBOIkPJsbTrRwWFjxQHEYLVUd={'stream50':1080,'stream40':720,'stream30':540}
class yciXKmBOIkPJsbTrRwWFjxQHEYLVUA(yciXKmBOIkPJsbTrRwWFjxQHEYLVhS):
 def __init__(yciXKmBOIkPJsbTrRwWFjxQHEYLVUz):
  yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.SPOTV_SESSIONID=''
  yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.SPOTV_SESSION =''
  yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.SPOTV_ACCOUNTID=''
  yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.SPOTV_POLICYKEY=''
  yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.SPOTV_SUBEND =''
  yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.SPOTV_PMCODE ='987'
  yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.SPOTV_PMSIZE =3
  yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.GAMELIST_LIMIT =10
  yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.API_DOMAIN ='https://www.spotvnow.co.kr'
  yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.BC_DOMAIN ='https://players.brightcove.net'
  yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.PLAYER_DOMAIN ='https://edge.api.brightcove.com'
  yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36'
  yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.DEFAULT_HEADER ={'user-agent':yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.USER_AGENT}
 def callRequestCookies(yciXKmBOIkPJsbTrRwWFjxQHEYLVUz,jobtype,yciXKmBOIkPJsbTrRwWFjxQHEYLVAd,payload=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,params=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,headers=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,cookies=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,redirects=yciXKmBOIkPJsbTrRwWFjxQHEYLVhl):
  yciXKmBOIkPJsbTrRwWFjxQHEYLVUh=yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.DEFAULT_HEADER
  if headers:yciXKmBOIkPJsbTrRwWFjxQHEYLVUh.update(headers)
  if jobtype=='Get':
   yciXKmBOIkPJsbTrRwWFjxQHEYLVUS=requests.get(yciXKmBOIkPJsbTrRwWFjxQHEYLVAd,params=params,headers=yciXKmBOIkPJsbTrRwWFjxQHEYLVUh,cookies=cookies,allow_redirects=redirects)
  else:
   yciXKmBOIkPJsbTrRwWFjxQHEYLVUS=requests.post(yciXKmBOIkPJsbTrRwWFjxQHEYLVAd,data=payload,params=params,headers=yciXKmBOIkPJsbTrRwWFjxQHEYLVUh,cookies=cookies,allow_redirects=redirects)
  return yciXKmBOIkPJsbTrRwWFjxQHEYLVUS
 def makeDefaultCookies(yciXKmBOIkPJsbTrRwWFjxQHEYLVUz):
  yciXKmBOIkPJsbTrRwWFjxQHEYLVUt={'SESSION':yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.SPOTV_SESSION}
  return yciXKmBOIkPJsbTrRwWFjxQHEYLVUt
 def GetCredential(yciXKmBOIkPJsbTrRwWFjxQHEYLVUz,user_id,user_pw):
  yciXKmBOIkPJsbTrRwWFjxQHEYLVUl=yciXKmBOIkPJsbTrRwWFjxQHEYLVhl
  yciXKmBOIkPJsbTrRwWFjxQHEYLVUf=yciXKmBOIkPJsbTrRwWFjxQHEYLVUC=yciXKmBOIkPJsbTrRwWFjxQHEYLVUD=yciXKmBOIkPJsbTrRwWFjxQHEYLVUn=yciXKmBOIkPJsbTrRwWFjxQHEYLVUv=''
  try:
   yciXKmBOIkPJsbTrRwWFjxQHEYLVUo=base64.standard_b64encode(user_id.encode("UTF-8")).decode('utf-8')
   yciXKmBOIkPJsbTrRwWFjxQHEYLVUN=base64.standard_b64encode(user_pw.encode("UTF-8")).decode('utf-8')
   yciXKmBOIkPJsbTrRwWFjxQHEYLVUG=yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.API_DOMAIN+'/api/v2/login'
   yciXKmBOIkPJsbTrRwWFjxQHEYLVUq={'username':yciXKmBOIkPJsbTrRwWFjxQHEYLVUo,'password':yciXKmBOIkPJsbTrRwWFjxQHEYLVUN}
   yciXKmBOIkPJsbTrRwWFjxQHEYLVUq=json.dumps(yciXKmBOIkPJsbTrRwWFjxQHEYLVUq)
   yciXKmBOIkPJsbTrRwWFjxQHEYLVUM=yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.callRequestCookies('Post',yciXKmBOIkPJsbTrRwWFjxQHEYLVUG,payload=yciXKmBOIkPJsbTrRwWFjxQHEYLVUq,params=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,headers=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,cookies=yciXKmBOIkPJsbTrRwWFjxQHEYLVht)
   yciXKmBOIkPJsbTrRwWFjxQHEYLVhf(yciXKmBOIkPJsbTrRwWFjxQHEYLVUM.status_code)
   for yciXKmBOIkPJsbTrRwWFjxQHEYLVUe in yciXKmBOIkPJsbTrRwWFjxQHEYLVUM.cookies:
    if yciXKmBOIkPJsbTrRwWFjxQHEYLVUe.name=='SESSION':
     yciXKmBOIkPJsbTrRwWFjxQHEYLVUC=yciXKmBOIkPJsbTrRwWFjxQHEYLVUe.value
     break
   if yciXKmBOIkPJsbTrRwWFjxQHEYLVUC=='':return yciXKmBOIkPJsbTrRwWFjxQHEYLVUl
   yciXKmBOIkPJsbTrRwWFjxQHEYLVUg=json.loads(yciXKmBOIkPJsbTrRwWFjxQHEYLVUM.text)
   if not('userId' in yciXKmBOIkPJsbTrRwWFjxQHEYLVUg):return yciXKmBOIkPJsbTrRwWFjxQHEYLVUl
   yciXKmBOIkPJsbTrRwWFjxQHEYLVUf=yciXKmBOIkPJsbTrRwWFjxQHEYLVho(yciXKmBOIkPJsbTrRwWFjxQHEYLVUg['userId'])
   yciXKmBOIkPJsbTrRwWFjxQHEYLVUv =yciXKmBOIkPJsbTrRwWFjxQHEYLVho(yciXKmBOIkPJsbTrRwWFjxQHEYLVUg['subEndTime'])
   yciXKmBOIkPJsbTrRwWFjxQHEYLVUD,yciXKmBOIkPJsbTrRwWFjxQHEYLVUn=yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.GetPolicyKey()
   if yciXKmBOIkPJsbTrRwWFjxQHEYLVUn=='':return yciXKmBOIkPJsbTrRwWFjxQHEYLVUl
   yciXKmBOIkPJsbTrRwWFjxQHEYLVUl=yciXKmBOIkPJsbTrRwWFjxQHEYLVhN
  except yciXKmBOIkPJsbTrRwWFjxQHEYLVhG as exception:
   yciXKmBOIkPJsbTrRwWFjxQHEYLVUf=yciXKmBOIkPJsbTrRwWFjxQHEYLVUC='' 
   yciXKmBOIkPJsbTrRwWFjxQHEYLVhf(exception)
  yciXKmBOIkPJsbTrRwWFjxQHEYLVUu={'spotv_sessionid':yciXKmBOIkPJsbTrRwWFjxQHEYLVUf,'spotv_session':yciXKmBOIkPJsbTrRwWFjxQHEYLVUC,'spotv_accountId':yciXKmBOIkPJsbTrRwWFjxQHEYLVUD,'spotv_policyKey':yciXKmBOIkPJsbTrRwWFjxQHEYLVUn,'spotv_subend':yciXKmBOIkPJsbTrRwWFjxQHEYLVUv}
  yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.SaveCredential(yciXKmBOIkPJsbTrRwWFjxQHEYLVUu)
  return yciXKmBOIkPJsbTrRwWFjxQHEYLVUl
 def SaveCredential(yciXKmBOIkPJsbTrRwWFjxQHEYLVUz,yciXKmBOIkPJsbTrRwWFjxQHEYLVUu):
  yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.SPOTV_SESSIONID=yciXKmBOIkPJsbTrRwWFjxQHEYLVUu.get('spotv_sessionid')
  yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.SPOTV_SESSION =yciXKmBOIkPJsbTrRwWFjxQHEYLVUu.get('spotv_session')
  yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.SPOTV_ACCOUNTID=yciXKmBOIkPJsbTrRwWFjxQHEYLVUu.get('spotv_accountId')
  yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.SPOTV_POLICYKEY=yciXKmBOIkPJsbTrRwWFjxQHEYLVUu.get('spotv_policyKey')
  yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.SPOTV_SUBEND =yciXKmBOIkPJsbTrRwWFjxQHEYLVUu.get('spotv_subend')
 def LoadCredential(yciXKmBOIkPJsbTrRwWFjxQHEYLVUz):
  yciXKmBOIkPJsbTrRwWFjxQHEYLVUu={'spotv_sessionid':yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.SPOTV_SESSIONID,'spotv_session':yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.SPOTV_SESSION,'spotv_accountId':yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.SPOTV_ACCOUNTID,'spotv_policyKey':yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.SPOTV_POLICYKEY,'spotv_subend':yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.SPOTV_SUBEND}
  return yciXKmBOIkPJsbTrRwWFjxQHEYLVUu
 def Get_Now_Datetime(yciXKmBOIkPJsbTrRwWFjxQHEYLVUz):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetLiveChannelList(yciXKmBOIkPJsbTrRwWFjxQHEYLVUz):
  yciXKmBOIkPJsbTrRwWFjxQHEYLVUa=[]
  yciXKmBOIkPJsbTrRwWFjxQHEYLVAU ={}
  try:
   yciXKmBOIkPJsbTrRwWFjxQHEYLVAd=yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.API_DOMAIN+'/api/v2/channel'
   yciXKmBOIkPJsbTrRwWFjxQHEYLVUM=yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.callRequestCookies('Get',yciXKmBOIkPJsbTrRwWFjxQHEYLVAd,payload=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,params=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,headers=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,cookies=yciXKmBOIkPJsbTrRwWFjxQHEYLVht)
   yciXKmBOIkPJsbTrRwWFjxQHEYLVUg=json.loads(yciXKmBOIkPJsbTrRwWFjxQHEYLVUM.text)
   yciXKmBOIkPJsbTrRwWFjxQHEYLVAU=yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.GetEPGList()
   for i in yciXKmBOIkPJsbTrRwWFjxQHEYLVhq(2):
    for yciXKmBOIkPJsbTrRwWFjxQHEYLVAz in yciXKmBOIkPJsbTrRwWFjxQHEYLVUg:
     yciXKmBOIkPJsbTrRwWFjxQHEYLVAh={'id':yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['id'],'name':yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['name'],'logo':yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['logo'],'videoId':yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['videoId'].replace('ref:',''),'free':yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['free'],'programName':yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['programName'],'channelepg':yciXKmBOIkPJsbTrRwWFjxQHEYLVAU.get(yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['id']),'studio':yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['name']}
     if i==0:
      if yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['free']==yciXKmBOIkPJsbTrRwWFjxQHEYLVhl:yciXKmBOIkPJsbTrRwWFjxQHEYLVUa.append(yciXKmBOIkPJsbTrRwWFjxQHEYLVAh)
     else:
      if yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['free']==yciXKmBOIkPJsbTrRwWFjxQHEYLVhN:yciXKmBOIkPJsbTrRwWFjxQHEYLVUa.append(yciXKmBOIkPJsbTrRwWFjxQHEYLVAh)
  except yciXKmBOIkPJsbTrRwWFjxQHEYLVhG as exception:
   yciXKmBOIkPJsbTrRwWFjxQHEYLVhf(exception)
  return yciXKmBOIkPJsbTrRwWFjxQHEYLVUa
 def CheckLiveChannel(yciXKmBOIkPJsbTrRwWFjxQHEYLVUz,channelid):
  try:
   yciXKmBOIkPJsbTrRwWFjxQHEYLVAd=yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.API_DOMAIN+'/api/v2/channel'
   yciXKmBOIkPJsbTrRwWFjxQHEYLVUM=yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.callRequestCookies('Get',yciXKmBOIkPJsbTrRwWFjxQHEYLVAd,payload=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,params=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,headers=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,cookies=yciXKmBOIkPJsbTrRwWFjxQHEYLVht)
   yciXKmBOIkPJsbTrRwWFjxQHEYLVUg=json.loads(yciXKmBOIkPJsbTrRwWFjxQHEYLVUM.text)
   for yciXKmBOIkPJsbTrRwWFjxQHEYLVAz in yciXKmBOIkPJsbTrRwWFjxQHEYLVUg:
    if yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['videoId'].replace('ref:','')==channelid:
     return yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['free']
  except yciXKmBOIkPJsbTrRwWFjxQHEYLVhG as exception:
   yciXKmBOIkPJsbTrRwWFjxQHEYLVhf(exception)
  return yciXKmBOIkPJsbTrRwWFjxQHEYLVhl
 def GetEPGList(yciXKmBOIkPJsbTrRwWFjxQHEYLVUz):
  yciXKmBOIkPJsbTrRwWFjxQHEYLVAS={}
  yciXKmBOIkPJsbTrRwWFjxQHEYLVAt=yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.Get_Now_Datetime()
  yciXKmBOIkPJsbTrRwWFjxQHEYLVAl=yciXKmBOIkPJsbTrRwWFjxQHEYLVAt.strftime('%Y%m%d%H%M')
  yciXKmBOIkPJsbTrRwWFjxQHEYLVAf='%s-%s-%s'%(yciXKmBOIkPJsbTrRwWFjxQHEYLVAl[0:4],yciXKmBOIkPJsbTrRwWFjxQHEYLVAl[4:6],yciXKmBOIkPJsbTrRwWFjxQHEYLVAl[6:8])
  yciXKmBOIkPJsbTrRwWFjxQHEYLVAo=(yciXKmBOIkPJsbTrRwWFjxQHEYLVAt+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M')
  try:
   yciXKmBOIkPJsbTrRwWFjxQHEYLVAd=yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.API_DOMAIN+'/api/v2/program/'+yciXKmBOIkPJsbTrRwWFjxQHEYLVAf
   yciXKmBOIkPJsbTrRwWFjxQHEYLVUM=yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.callRequestCookies('Get',yciXKmBOIkPJsbTrRwWFjxQHEYLVAd,payload=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,params=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,headers=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,cookies=yciXKmBOIkPJsbTrRwWFjxQHEYLVht)
   yciXKmBOIkPJsbTrRwWFjxQHEYLVUg=json.loads(yciXKmBOIkPJsbTrRwWFjxQHEYLVUM.text)
   yciXKmBOIkPJsbTrRwWFjxQHEYLVAN=-1 
   yciXKmBOIkPJsbTrRwWFjxQHEYLVAG =''
   for yciXKmBOIkPJsbTrRwWFjxQHEYLVAz in yciXKmBOIkPJsbTrRwWFjxQHEYLVUg:
    yciXKmBOIkPJsbTrRwWFjxQHEYLVAq=yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['channelId']
    yciXKmBOIkPJsbTrRwWFjxQHEYLVAM =yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['startTime'].replace('-','').replace(' ','').replace(':','')
    yciXKmBOIkPJsbTrRwWFjxQHEYLVAe =yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['endTime'].replace('-','').replace(' ','').replace(':','')
    if yciXKmBOIkPJsbTrRwWFjxQHEYLVhM(yciXKmBOIkPJsbTrRwWFjxQHEYLVAl)>yciXKmBOIkPJsbTrRwWFjxQHEYLVhM(yciXKmBOIkPJsbTrRwWFjxQHEYLVAe) :continue
    if yciXKmBOIkPJsbTrRwWFjxQHEYLVhM(yciXKmBOIkPJsbTrRwWFjxQHEYLVAo)<yciXKmBOIkPJsbTrRwWFjxQHEYLVhM(yciXKmBOIkPJsbTrRwWFjxQHEYLVAM):continue
    if yciXKmBOIkPJsbTrRwWFjxQHEYLVAN!=yciXKmBOIkPJsbTrRwWFjxQHEYLVAq:
     if yciXKmBOIkPJsbTrRwWFjxQHEYLVAG!='':yciXKmBOIkPJsbTrRwWFjxQHEYLVAS[yciXKmBOIkPJsbTrRwWFjxQHEYLVAN]=yciXKmBOIkPJsbTrRwWFjxQHEYLVAG
     yciXKmBOIkPJsbTrRwWFjxQHEYLVAN=yciXKmBOIkPJsbTrRwWFjxQHEYLVAq
     yciXKmBOIkPJsbTrRwWFjxQHEYLVAG =''
    if yciXKmBOIkPJsbTrRwWFjxQHEYLVAG:yciXKmBOIkPJsbTrRwWFjxQHEYLVAG+='\n'
    yciXKmBOIkPJsbTrRwWFjxQHEYLVAG+=yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['title']+'\n'
    yciXKmBOIkPJsbTrRwWFjxQHEYLVAG+=' [%s ~ %s]'%(yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['startTime'][-5:],yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['endTime'][-5:])+'\n'
   if yciXKmBOIkPJsbTrRwWFjxQHEYLVAG:yciXKmBOIkPJsbTrRwWFjxQHEYLVAS[yciXKmBOIkPJsbTrRwWFjxQHEYLVAN]=yciXKmBOIkPJsbTrRwWFjxQHEYLVAG
  except yciXKmBOIkPJsbTrRwWFjxQHEYLVhG as exception:
   yciXKmBOIkPJsbTrRwWFjxQHEYLVhf(exception)
  return yciXKmBOIkPJsbTrRwWFjxQHEYLVAS
 def GetEventLiveList(yciXKmBOIkPJsbTrRwWFjxQHEYLVUz):
  yciXKmBOIkPJsbTrRwWFjxQHEYLVUa=[]
  yciXKmBOIkPJsbTrRwWFjxQHEYLVAC =0
  try:
   yciXKmBOIkPJsbTrRwWFjxQHEYLVAg=yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.Get_Now_Datetime()
   yciXKmBOIkPJsbTrRwWFjxQHEYLVAv=yciXKmBOIkPJsbTrRwWFjxQHEYLVAg.strftime('%Y-%m-%d')
  except yciXKmBOIkPJsbTrRwWFjxQHEYLVhG as exception:
   yciXKmBOIkPJsbTrRwWFjxQHEYLVhf(exception)
   return yciXKmBOIkPJsbTrRwWFjxQHEYLVUa,yciXKmBOIkPJsbTrRwWFjxQHEYLVAC
  try:
   yciXKmBOIkPJsbTrRwWFjxQHEYLVAd=yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.API_DOMAIN+'/api/v2/player/lives/'+yciXKmBOIkPJsbTrRwWFjxQHEYLVAv 
   yciXKmBOIkPJsbTrRwWFjxQHEYLVUt=yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.makeDefaultCookies()
   yciXKmBOIkPJsbTrRwWFjxQHEYLVUM=yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.callRequestCookies('Get',yciXKmBOIkPJsbTrRwWFjxQHEYLVAd,payload=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,params=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,headers=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,cookies=yciXKmBOIkPJsbTrRwWFjxQHEYLVUt)
   yciXKmBOIkPJsbTrRwWFjxQHEYLVAC=yciXKmBOIkPJsbTrRwWFjxQHEYLVUM.status_code 
   yciXKmBOIkPJsbTrRwWFjxQHEYLVUg=json.loads(yciXKmBOIkPJsbTrRwWFjxQHEYLVUM.text)
   for yciXKmBOIkPJsbTrRwWFjxQHEYLVAD in yciXKmBOIkPJsbTrRwWFjxQHEYLVUg:
    for yciXKmBOIkPJsbTrRwWFjxQHEYLVAz in yciXKmBOIkPJsbTrRwWFjxQHEYLVAD['liveNowList']:
     if yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['gameDesc']['title']==yciXKmBOIkPJsbTrRwWFjxQHEYLVht or yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['gameDesc']['title']=='':
      yciXKmBOIkPJsbTrRwWFjxQHEYLVAn='%s ( %s : %s )'%(yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['leagueName'],yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['homeNameShort'],yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['awayNameShort'])
     else:
      yciXKmBOIkPJsbTrRwWFjxQHEYLVAn=yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['gameDesc']['title']
     yciXKmBOIkPJsbTrRwWFjxQHEYLVAh={'liveId':yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['liveId'],'title':yciXKmBOIkPJsbTrRwWFjxQHEYLVAn,'logo':yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['gameDesc']['leagueLogo'],'free':yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['isFree'],'startTime':yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['startTime']}
     yciXKmBOIkPJsbTrRwWFjxQHEYLVUa.append(yciXKmBOIkPJsbTrRwWFjxQHEYLVAh)
  except yciXKmBOIkPJsbTrRwWFjxQHEYLVhG as exception:
   yciXKmBOIkPJsbTrRwWFjxQHEYLVhf(exception)
  return yciXKmBOIkPJsbTrRwWFjxQHEYLVUa,yciXKmBOIkPJsbTrRwWFjxQHEYLVAC
 def GetEventLive_videoId(yciXKmBOIkPJsbTrRwWFjxQHEYLVUz,liveId):
  yciXKmBOIkPJsbTrRwWFjxQHEYLVAu=''
  try:
   yciXKmBOIkPJsbTrRwWFjxQHEYLVAd=yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.API_DOMAIN+'/api/v2/live/'+liveId
   yciXKmBOIkPJsbTrRwWFjxQHEYLVUM=yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.callRequestCookies('Get',yciXKmBOIkPJsbTrRwWFjxQHEYLVAd,payload=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,params=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,headers=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,cookies=yciXKmBOIkPJsbTrRwWFjxQHEYLVht)
   yciXKmBOIkPJsbTrRwWFjxQHEYLVUg=json.loads(yciXKmBOIkPJsbTrRwWFjxQHEYLVUM.text)
   yciXKmBOIkPJsbTrRwWFjxQHEYLVAp=yciXKmBOIkPJsbTrRwWFjxQHEYLVUg['videoId']
   yciXKmBOIkPJsbTrRwWFjxQHEYLVAu=yciXKmBOIkPJsbTrRwWFjxQHEYLVAp.replace('ref:','')
  except yciXKmBOIkPJsbTrRwWFjxQHEYLVhG as exception:
   yciXKmBOIkPJsbTrRwWFjxQHEYLVhf(exception)
  return yciXKmBOIkPJsbTrRwWFjxQHEYLVAu
 def CheckMainEnd(yciXKmBOIkPJsbTrRwWFjxQHEYLVUz):
  yciXKmBOIkPJsbTrRwWFjxQHEYLVAa=base64.standard_b64encode((yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.SPOTV_PMCODE+yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.SPOTV_SESSIONID).encode()).decode('utf-8')
  if yciXKmBOIkPJsbTrRwWFjxQHEYLVAa=='OTg3MTgzMzM0Ng==' or yciXKmBOIkPJsbTrRwWFjxQHEYLVAa=='OTg3MTgzMzExNw==':return yciXKmBOIkPJsbTrRwWFjxQHEYLVhN
  return yciXKmBOIkPJsbTrRwWFjxQHEYLVhl
 def CheckSubEnd(yciXKmBOIkPJsbTrRwWFjxQHEYLVUz):
  yciXKmBOIkPJsbTrRwWFjxQHEYLVdU=yciXKmBOIkPJsbTrRwWFjxQHEYLVhl
  try:
   if yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.CheckMainEnd():return yciXKmBOIkPJsbTrRwWFjxQHEYLVhN 
   if yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.SPOTV_SUBEND=='0':return yciXKmBOIkPJsbTrRwWFjxQHEYLVdU
   yciXKmBOIkPJsbTrRwWFjxQHEYLVdA =yciXKmBOIkPJsbTrRwWFjxQHEYLVhM(yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.Get_Now_Datetime().strftime('%Y%m%d'))
   yciXKmBOIkPJsbTrRwWFjxQHEYLVdz =yciXKmBOIkPJsbTrRwWFjxQHEYLVhM(yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.SPOTV_SUBEND)/1000
   yciXKmBOIkPJsbTrRwWFjxQHEYLVdh =yciXKmBOIkPJsbTrRwWFjxQHEYLVhM(datetime.datetime.fromtimestamp(yciXKmBOIkPJsbTrRwWFjxQHEYLVdz,datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul')).strftime('%Y%m%d'))
   if yciXKmBOIkPJsbTrRwWFjxQHEYLVdA<=yciXKmBOIkPJsbTrRwWFjxQHEYLVdh:yciXKmBOIkPJsbTrRwWFjxQHEYLVdU=yciXKmBOIkPJsbTrRwWFjxQHEYLVhN
  except yciXKmBOIkPJsbTrRwWFjxQHEYLVhG as exception:
   yciXKmBOIkPJsbTrRwWFjxQHEYLVhf(exception)
   return yciXKmBOIkPJsbTrRwWFjxQHEYLVdU
  return yciXKmBOIkPJsbTrRwWFjxQHEYLVdU
 def GetMainJspath(yciXKmBOIkPJsbTrRwWFjxQHEYLVUz):
  yciXKmBOIkPJsbTrRwWFjxQHEYLVdS=''
  try:
   yciXKmBOIkPJsbTrRwWFjxQHEYLVAd=yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.API_DOMAIN
   yciXKmBOIkPJsbTrRwWFjxQHEYLVUM=yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.callRequestCookies('Get',yciXKmBOIkPJsbTrRwWFjxQHEYLVAd,payload=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,params=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,headers=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,cookies=yciXKmBOIkPJsbTrRwWFjxQHEYLVht)
   yciXKmBOIkPJsbTrRwWFjxQHEYLVdt=yciXKmBOIkPJsbTrRwWFjxQHEYLVUM.text
   yciXKmBOIkPJsbTrRwWFjxQHEYLVdl =re.findall('https://cdn.spotvnow.co.kr/dist/js/.{20}\.js',yciXKmBOIkPJsbTrRwWFjxQHEYLVdt)[0]
   yciXKmBOIkPJsbTrRwWFjxQHEYLVdS=yciXKmBOIkPJsbTrRwWFjxQHEYLVdl
  except yciXKmBOIkPJsbTrRwWFjxQHEYLVhG as exception:
   yciXKmBOIkPJsbTrRwWFjxQHEYLVhf(exception)
  return yciXKmBOIkPJsbTrRwWFjxQHEYLVdS
 def GetBcPlayerUrl(yciXKmBOIkPJsbTrRwWFjxQHEYLVUz):
  yciXKmBOIkPJsbTrRwWFjxQHEYLVdf=''
  try:
   yciXKmBOIkPJsbTrRwWFjxQHEYLVAd=yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.GetMainJspath()
   if yciXKmBOIkPJsbTrRwWFjxQHEYLVAd=='':return yciXKmBOIkPJsbTrRwWFjxQHEYLVdf
   yciXKmBOIkPJsbTrRwWFjxQHEYLVUM=yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.callRequestCookies('Get',yciXKmBOIkPJsbTrRwWFjxQHEYLVAd,payload=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,params=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,headers=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,cookies=yciXKmBOIkPJsbTrRwWFjxQHEYLVht)
   yciXKmBOIkPJsbTrRwWFjxQHEYLVdt=yciXKmBOIkPJsbTrRwWFjxQHEYLVUM.text
   yciXKmBOIkPJsbTrRwWFjxQHEYLVdo =re.findall('bc:\s*\"\d{13}\",\s*player:\s*\".{9}\"',yciXKmBOIkPJsbTrRwWFjxQHEYLVdt)[0]
   yciXKmBOIkPJsbTrRwWFjxQHEYLVdo =yciXKmBOIkPJsbTrRwWFjxQHEYLVdo.replace('bc','"bc"')
   yciXKmBOIkPJsbTrRwWFjxQHEYLVdo =yciXKmBOIkPJsbTrRwWFjxQHEYLVdo.replace('player','"player"')
   yciXKmBOIkPJsbTrRwWFjxQHEYLVdo ='{'+yciXKmBOIkPJsbTrRwWFjxQHEYLVdo+'}'
   yciXKmBOIkPJsbTrRwWFjxQHEYLVdo =json.loads(yciXKmBOIkPJsbTrRwWFjxQHEYLVdo)
   bc =yciXKmBOIkPJsbTrRwWFjxQHEYLVdo['bc']
   yciXKmBOIkPJsbTrRwWFjxQHEYLVdN =yciXKmBOIkPJsbTrRwWFjxQHEYLVdo['player']
   yciXKmBOIkPJsbTrRwWFjxQHEYLVdf="%s/%s/%s_default/index.min.js"%(yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.BC_DOMAIN,bc,yciXKmBOIkPJsbTrRwWFjxQHEYLVdN)
  except yciXKmBOIkPJsbTrRwWFjxQHEYLVhG as exception:
   yciXKmBOIkPJsbTrRwWFjxQHEYLVhf(exception)
  return yciXKmBOIkPJsbTrRwWFjxQHEYLVdf
 def GetPolicyKey(yciXKmBOIkPJsbTrRwWFjxQHEYLVUz):
  yciXKmBOIkPJsbTrRwWFjxQHEYLVdG=policykey=''
  try:
   yciXKmBOIkPJsbTrRwWFjxQHEYLVAd=yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.GetBcPlayerUrl()
   if yciXKmBOIkPJsbTrRwWFjxQHEYLVAd=='':return yciXKmBOIkPJsbTrRwWFjxQHEYLVdG,yciXKmBOIkPJsbTrRwWFjxQHEYLVdM
   yciXKmBOIkPJsbTrRwWFjxQHEYLVUM=yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.callRequestCookies('Get',yciXKmBOIkPJsbTrRwWFjxQHEYLVAd,payload=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,params=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,headers=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,cookies=yciXKmBOIkPJsbTrRwWFjxQHEYLVht)
   yciXKmBOIkPJsbTrRwWFjxQHEYLVdt=yciXKmBOIkPJsbTrRwWFjxQHEYLVUM.text
   yciXKmBOIkPJsbTrRwWFjxQHEYLVdl =re.findall('accountId:\s*\"\d{13}\",\s*policyKey:\s*\".[^(){}]{100,300}\"',yciXKmBOIkPJsbTrRwWFjxQHEYLVdt)[0]
   yciXKmBOIkPJsbTrRwWFjxQHEYLVdl =yciXKmBOIkPJsbTrRwWFjxQHEYLVdl.replace('accountId','"accountId"')
   yciXKmBOIkPJsbTrRwWFjxQHEYLVdl =yciXKmBOIkPJsbTrRwWFjxQHEYLVdl.replace('policyKey','"policyKey"')
   yciXKmBOIkPJsbTrRwWFjxQHEYLVdl ='{'+yciXKmBOIkPJsbTrRwWFjxQHEYLVdl+'}'
   yciXKmBOIkPJsbTrRwWFjxQHEYLVdq=json.loads(yciXKmBOIkPJsbTrRwWFjxQHEYLVdl)
   yciXKmBOIkPJsbTrRwWFjxQHEYLVdG =yciXKmBOIkPJsbTrRwWFjxQHEYLVdq['accountId']
   yciXKmBOIkPJsbTrRwWFjxQHEYLVdM =yciXKmBOIkPJsbTrRwWFjxQHEYLVdq['policyKey']
  except yciXKmBOIkPJsbTrRwWFjxQHEYLVhG as exception:
   yciXKmBOIkPJsbTrRwWFjxQHEYLVhf(exception)
  return yciXKmBOIkPJsbTrRwWFjxQHEYLVdG,yciXKmBOIkPJsbTrRwWFjxQHEYLVdM
 def GetBroadURL(yciXKmBOIkPJsbTrRwWFjxQHEYLVUz,yciXKmBOIkPJsbTrRwWFjxQHEYLVAu,mediatype,yciXKmBOIkPJsbTrRwWFjxQHEYLVzd):
  yciXKmBOIkPJsbTrRwWFjxQHEYLVde=''
  try:
   if mediatype=='live':
    yciXKmBOIkPJsbTrRwWFjxQHEYLVAu='ref%3A'+yciXKmBOIkPJsbTrRwWFjxQHEYLVAu
   else:
    yciXKmBOIkPJsbTrRwWFjxQHEYLVAu=yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.GetReplay_UrlId(yciXKmBOIkPJsbTrRwWFjxQHEYLVAu,yciXKmBOIkPJsbTrRwWFjxQHEYLVzd)
    if yciXKmBOIkPJsbTrRwWFjxQHEYLVAu=='':return yciXKmBOIkPJsbTrRwWFjxQHEYLVde
   yciXKmBOIkPJsbTrRwWFjxQHEYLVAd=yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.PLAYER_DOMAIN+'/playback/v1/accounts/'+yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.SPOTV_ACCOUNTID+'/videos/'+yciXKmBOIkPJsbTrRwWFjxQHEYLVAu
   yciXKmBOIkPJsbTrRwWFjxQHEYLVdC={'accept':'application/json;pk='+yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.SPOTV_POLICYKEY}
   yciXKmBOIkPJsbTrRwWFjxQHEYLVUM=yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.callRequestCookies('Get',yciXKmBOIkPJsbTrRwWFjxQHEYLVAd,payload=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,params=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,headers=yciXKmBOIkPJsbTrRwWFjxQHEYLVdC,cookies=yciXKmBOIkPJsbTrRwWFjxQHEYLVht)
   yciXKmBOIkPJsbTrRwWFjxQHEYLVdg=json.loads(yciXKmBOIkPJsbTrRwWFjxQHEYLVUM.text)
   yciXKmBOIkPJsbTrRwWFjxQHEYLVde=yciXKmBOIkPJsbTrRwWFjxQHEYLVdg['sources'][0]['src']
   if mediatype=='live':
    yciXKmBOIkPJsbTrRwWFjxQHEYLVde=yciXKmBOIkPJsbTrRwWFjxQHEYLVde.replace('playlist.m3u8','playlist_dvr.m3u8')
   yciXKmBOIkPJsbTrRwWFjxQHEYLVde=yciXKmBOIkPJsbTrRwWFjxQHEYLVde.replace('http://','https://')
  except yciXKmBOIkPJsbTrRwWFjxQHEYLVhG as exception:
   yciXKmBOIkPJsbTrRwWFjxQHEYLVhf(exception)
  return yciXKmBOIkPJsbTrRwWFjxQHEYLVde
 def GetTitleGroupList(yciXKmBOIkPJsbTrRwWFjxQHEYLVUz):
  yciXKmBOIkPJsbTrRwWFjxQHEYLVUa=[]
  yciXKmBOIkPJsbTrRwWFjxQHEYLVdv=yciXKmBOIkPJsbTrRwWFjxQHEYLVhl
  try:
   yciXKmBOIkPJsbTrRwWFjxQHEYLVAd=yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.API_DOMAIN+'/api/v2/home/web'
   yciXKmBOIkPJsbTrRwWFjxQHEYLVUM=yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.callRequestCookies('Get',yciXKmBOIkPJsbTrRwWFjxQHEYLVAd,payload=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,params=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,headers=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,cookies=yciXKmBOIkPJsbTrRwWFjxQHEYLVht)
   yciXKmBOIkPJsbTrRwWFjxQHEYLVUg=json.loads(yciXKmBOIkPJsbTrRwWFjxQHEYLVUM.text)
   for yciXKmBOIkPJsbTrRwWFjxQHEYLVAz in yciXKmBOIkPJsbTrRwWFjxQHEYLVUg:
    if yciXKmBOIkPJsbTrRwWFjxQHEYLVho(yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['type'])=='3':
     yciXKmBOIkPJsbTrRwWFjxQHEYLVdD=''
     for yciXKmBOIkPJsbTrRwWFjxQHEYLVdn in yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['data']['list']:
      yciXKmBOIkPJsbTrRwWFjxQHEYLVdu='[%s] %s vs %s\n<%s>\n\n'%(yciXKmBOIkPJsbTrRwWFjxQHEYLVdn['gameDesc']['roundName'],yciXKmBOIkPJsbTrRwWFjxQHEYLVdn['gameDesc']['homeNameShort'],yciXKmBOIkPJsbTrRwWFjxQHEYLVdn['gameDesc']['awayNameShort'],yciXKmBOIkPJsbTrRwWFjxQHEYLVdn['gameDesc']['beginDate'])
      yciXKmBOIkPJsbTrRwWFjxQHEYLVdD+=yciXKmBOIkPJsbTrRwWFjxQHEYLVdu
     yciXKmBOIkPJsbTrRwWFjxQHEYLVAh={'title':yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['title'],'logo':yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['logo'],'reagueId':yciXKmBOIkPJsbTrRwWFjxQHEYLVho(yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['destId']),'subGame':yciXKmBOIkPJsbTrRwWFjxQHEYLVdD}
     yciXKmBOIkPJsbTrRwWFjxQHEYLVUa.append(yciXKmBOIkPJsbTrRwWFjxQHEYLVAh)
     if yciXKmBOIkPJsbTrRwWFjxQHEYLVho(yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['destId'])=='13':yciXKmBOIkPJsbTrRwWFjxQHEYLVdv=yciXKmBOIkPJsbTrRwWFjxQHEYLVhN
   if yciXKmBOIkPJsbTrRwWFjxQHEYLVdv==yciXKmBOIkPJsbTrRwWFjxQHEYLVhl:
    yciXKmBOIkPJsbTrRwWFjxQHEYLVAh={'title':'UFC','logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200928/a643c7cf1c285fb0b4469c07d4c09c28.png','reagueId':'13','subGame':''}
    yciXKmBOIkPJsbTrRwWFjxQHEYLVUa.append(yciXKmBOIkPJsbTrRwWFjxQHEYLVAh)
  except yciXKmBOIkPJsbTrRwWFjxQHEYLVhG as exception:
   yciXKmBOIkPJsbTrRwWFjxQHEYLVhf(exception)
  return yciXKmBOIkPJsbTrRwWFjxQHEYLVUa
 def GetPopularGroupList(yciXKmBOIkPJsbTrRwWFjxQHEYLVUz):
  yciXKmBOIkPJsbTrRwWFjxQHEYLVUa=[]
  try:
   yciXKmBOIkPJsbTrRwWFjxQHEYLVAd=yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.API_DOMAIN+'/api/v2/home/web'
   yciXKmBOIkPJsbTrRwWFjxQHEYLVUM=yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.callRequestCookies('Get',yciXKmBOIkPJsbTrRwWFjxQHEYLVAd,payload=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,params=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,headers=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,cookies=yciXKmBOIkPJsbTrRwWFjxQHEYLVht)
   yciXKmBOIkPJsbTrRwWFjxQHEYLVUg=json.loads(yciXKmBOIkPJsbTrRwWFjxQHEYLVUM.text)
   for yciXKmBOIkPJsbTrRwWFjxQHEYLVAz in yciXKmBOIkPJsbTrRwWFjxQHEYLVUg:
    if yciXKmBOIkPJsbTrRwWFjxQHEYLVho(yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['type'])=='1' and yciXKmBOIkPJsbTrRwWFjxQHEYLVho(yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['destId'])=='4':
     for yciXKmBOIkPJsbTrRwWFjxQHEYLVdn in yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['data']['list']:
      yciXKmBOIkPJsbTrRwWFjxQHEYLVdp =yciXKmBOIkPJsbTrRwWFjxQHEYLVdn['title']
      yciXKmBOIkPJsbTrRwWFjxQHEYLVda =yciXKmBOIkPJsbTrRwWFjxQHEYLVdn['id']
      yciXKmBOIkPJsbTrRwWFjxQHEYLVzU =yciXKmBOIkPJsbTrRwWFjxQHEYLVdn['vtype']
      yciXKmBOIkPJsbTrRwWFjxQHEYLVzA =yciXKmBOIkPJsbTrRwWFjxQHEYLVdn['imgUrl']
      yciXKmBOIkPJsbTrRwWFjxQHEYLVzd =yciXKmBOIkPJsbTrRwWFjxQHEYLVdn['vtypeId']
      yciXKmBOIkPJsbTrRwWFjxQHEYLVAh={'vodTitle':yciXKmBOIkPJsbTrRwWFjxQHEYLVdp,'vodId':yciXKmBOIkPJsbTrRwWFjxQHEYLVda,'vodType':yciXKmBOIkPJsbTrRwWFjxQHEYLVzU,'thumbnail':yciXKmBOIkPJsbTrRwWFjxQHEYLVzA,'vtypeId':yciXKmBOIkPJsbTrRwWFjxQHEYLVho(yciXKmBOIkPJsbTrRwWFjxQHEYLVzd),'duration':yciXKmBOIkPJsbTrRwWFjxQHEYLVhM(yciXKmBOIkPJsbTrRwWFjxQHEYLVdn['duration']/1000)}
      yciXKmBOIkPJsbTrRwWFjxQHEYLVUa.append(yciXKmBOIkPJsbTrRwWFjxQHEYLVAh)
  except yciXKmBOIkPJsbTrRwWFjxQHEYLVhG as exception:
   yciXKmBOIkPJsbTrRwWFjxQHEYLVhf(exception)
  return yciXKmBOIkPJsbTrRwWFjxQHEYLVUa
 def GetSeasonList(yciXKmBOIkPJsbTrRwWFjxQHEYLVUz,leagueId):
  yciXKmBOIkPJsbTrRwWFjxQHEYLVUa=[]
  yciXKmBOIkPJsbTrRwWFjxQHEYLVzh=yciXKmBOIkPJsbTrRwWFjxQHEYLVzS=''
  try:
   yciXKmBOIkPJsbTrRwWFjxQHEYLVAd=yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.API_DOMAIN+'/api/v2/game/league/'+leagueId
   yciXKmBOIkPJsbTrRwWFjxQHEYLVUM=yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.callRequestCookies('Get',yciXKmBOIkPJsbTrRwWFjxQHEYLVAd,payload=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,params=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,headers=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,cookies=yciXKmBOIkPJsbTrRwWFjxQHEYLVht)
   yciXKmBOIkPJsbTrRwWFjxQHEYLVUg=json.loads(yciXKmBOIkPJsbTrRwWFjxQHEYLVUM.text)
   yciXKmBOIkPJsbTrRwWFjxQHEYLVzh=yciXKmBOIkPJsbTrRwWFjxQHEYLVUg['name']
   yciXKmBOIkPJsbTrRwWFjxQHEYLVzS=yciXKmBOIkPJsbTrRwWFjxQHEYLVho(yciXKmBOIkPJsbTrRwWFjxQHEYLVUg['gameTypeId'])
  except yciXKmBOIkPJsbTrRwWFjxQHEYLVhG as exception:
   yciXKmBOIkPJsbTrRwWFjxQHEYLVhf(exception)
   return yciXKmBOIkPJsbTrRwWFjxQHEYLVUa
  if yciXKmBOIkPJsbTrRwWFjxQHEYLVzS=='2':
   try:
    yciXKmBOIkPJsbTrRwWFjxQHEYLVAd=yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.API_DOMAIN+'/api/v2/year/'+leagueId
    yciXKmBOIkPJsbTrRwWFjxQHEYLVUM=yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.callRequestCookies('Get',yciXKmBOIkPJsbTrRwWFjxQHEYLVAd,payload=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,params=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,headers=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,cookies=yciXKmBOIkPJsbTrRwWFjxQHEYLVht)
    yciXKmBOIkPJsbTrRwWFjxQHEYLVUg=json.loads(yciXKmBOIkPJsbTrRwWFjxQHEYLVUM.text)
    for yciXKmBOIkPJsbTrRwWFjxQHEYLVAz in yciXKmBOIkPJsbTrRwWFjxQHEYLVUg:
     yciXKmBOIkPJsbTrRwWFjxQHEYLVAh={'reagueName':yciXKmBOIkPJsbTrRwWFjxQHEYLVzh,'gameTypeId':yciXKmBOIkPJsbTrRwWFjxQHEYLVzS,'seasonName':yciXKmBOIkPJsbTrRwWFjxQHEYLVho(yciXKmBOIkPJsbTrRwWFjxQHEYLVAz),'seasonId':yciXKmBOIkPJsbTrRwWFjxQHEYLVho(yciXKmBOIkPJsbTrRwWFjxQHEYLVAz)}
     yciXKmBOIkPJsbTrRwWFjxQHEYLVUa.append(yciXKmBOIkPJsbTrRwWFjxQHEYLVAh)
   except yciXKmBOIkPJsbTrRwWFjxQHEYLVhG as exception:
    yciXKmBOIkPJsbTrRwWFjxQHEYLVhf(exception)
    return[]
  else:
   try:
    yciXKmBOIkPJsbTrRwWFjxQHEYLVAd=yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.API_DOMAIN+'/api/v2/season/'+leagueId
    yciXKmBOIkPJsbTrRwWFjxQHEYLVUM=yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.callRequestCookies('Get',yciXKmBOIkPJsbTrRwWFjxQHEYLVAd,payload=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,params=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,headers=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,cookies=yciXKmBOIkPJsbTrRwWFjxQHEYLVht)
    yciXKmBOIkPJsbTrRwWFjxQHEYLVUg=json.loads(yciXKmBOIkPJsbTrRwWFjxQHEYLVUM.text)
    for yciXKmBOIkPJsbTrRwWFjxQHEYLVAz in yciXKmBOIkPJsbTrRwWFjxQHEYLVUg:
     yciXKmBOIkPJsbTrRwWFjxQHEYLVAh={'reagueName':yciXKmBOIkPJsbTrRwWFjxQHEYLVzh,'gameTypeId':yciXKmBOIkPJsbTrRwWFjxQHEYLVzS,'seasonName':yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['name'],'seasonId':yciXKmBOIkPJsbTrRwWFjxQHEYLVho(yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['id'])}
     yciXKmBOIkPJsbTrRwWFjxQHEYLVUa.append(yciXKmBOIkPJsbTrRwWFjxQHEYLVAh)
   except yciXKmBOIkPJsbTrRwWFjxQHEYLVhG as exception:
    yciXKmBOIkPJsbTrRwWFjxQHEYLVhf(exception)
    return[]
  return yciXKmBOIkPJsbTrRwWFjxQHEYLVUa
 def GetGameList(yciXKmBOIkPJsbTrRwWFjxQHEYLVUz,yciXKmBOIkPJsbTrRwWFjxQHEYLVzS,leagueId,seasonId,page_int):
  yciXKmBOIkPJsbTrRwWFjxQHEYLVUa=[]
  yciXKmBOIkPJsbTrRwWFjxQHEYLVzt=yciXKmBOIkPJsbTrRwWFjxQHEYLVhl
  try:
   yciXKmBOIkPJsbTrRwWFjxQHEYLVAd=yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.API_DOMAIN+'/api/v2/vod/league/detail'
   yciXKmBOIkPJsbTrRwWFjxQHEYLVzl={'gameType':yciXKmBOIkPJsbTrRwWFjxQHEYLVzS,'leagueId':leagueId,'seasonId':seasonId if yciXKmBOIkPJsbTrRwWFjxQHEYLVzS!='2' else '','teamId':'','roundId':'','year':'' if yciXKmBOIkPJsbTrRwWFjxQHEYLVzS!='2' else seasonId,'pageNo':yciXKmBOIkPJsbTrRwWFjxQHEYLVho(page_int)}
   yciXKmBOIkPJsbTrRwWFjxQHEYLVUM=yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.callRequestCookies('Get',yciXKmBOIkPJsbTrRwWFjxQHEYLVAd,payload=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,params=yciXKmBOIkPJsbTrRwWFjxQHEYLVzl,headers=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,cookies=yciXKmBOIkPJsbTrRwWFjxQHEYLVht)
   yciXKmBOIkPJsbTrRwWFjxQHEYLVUg=json.loads(yciXKmBOIkPJsbTrRwWFjxQHEYLVUM.text)
   yciXKmBOIkPJsbTrRwWFjxQHEYLVAD=yciXKmBOIkPJsbTrRwWFjxQHEYLVUg['list']
   for yciXKmBOIkPJsbTrRwWFjxQHEYLVzf in yciXKmBOIkPJsbTrRwWFjxQHEYLVAD:
    for yciXKmBOIkPJsbTrRwWFjxQHEYLVAz in yciXKmBOIkPJsbTrRwWFjxQHEYLVzf['list']:
     if yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['gameDesc']['title']==yciXKmBOIkPJsbTrRwWFjxQHEYLVht or yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['gameDesc']['title']=='':
      yciXKmBOIkPJsbTrRwWFjxQHEYLVAn ='%s vs %s'%(yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['gameDesc']['homeNameShort'],yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['gameDesc']['awayNameShort'])
     else:
      yciXKmBOIkPJsbTrRwWFjxQHEYLVAn =yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['gameDesc']['title']
     yciXKmBOIkPJsbTrRwWFjxQHEYLVzo =yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['gameDesc']['beginDate']
     yciXKmBOIkPJsbTrRwWFjxQHEYLVzN =yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['gameDesc']['id']
     yciXKmBOIkPJsbTrRwWFjxQHEYLVzG =yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['gameDesc']['leagueNameFull']
     yciXKmBOIkPJsbTrRwWFjxQHEYLVzq =yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['gameDesc']['seasonName']
     yciXKmBOIkPJsbTrRwWFjxQHEYLVzM =yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['gameDesc']['roundName']
     yciXKmBOIkPJsbTrRwWFjxQHEYLVze =yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['gameDesc']['homeName']
     yciXKmBOIkPJsbTrRwWFjxQHEYLVzC =yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['gameDesc']['awayName']
     yciXKmBOIkPJsbTrRwWFjxQHEYLVzg =yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['gameDesc']['homeScore']
     yciXKmBOIkPJsbTrRwWFjxQHEYLVzv =yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['gameDesc']['awayScore']
     yciXKmBOIkPJsbTrRwWFjxQHEYLVzD ='%s\n - %s (%s)\n - %s\n\nhome : %s (Score %s)\n\naway : %s (Score %s)'%(yciXKmBOIkPJsbTrRwWFjxQHEYLVzG,yciXKmBOIkPJsbTrRwWFjxQHEYLVzq,yciXKmBOIkPJsbTrRwWFjxQHEYLVzM,yciXKmBOIkPJsbTrRwWFjxQHEYLVzo,yciXKmBOIkPJsbTrRwWFjxQHEYLVze,yciXKmBOIkPJsbTrRwWFjxQHEYLVzg,yciXKmBOIkPJsbTrRwWFjxQHEYLVzC,yciXKmBOIkPJsbTrRwWFjxQHEYLVzv)
     yciXKmBOIkPJsbTrRwWFjxQHEYLVzn=yciXKmBOIkPJsbTrRwWFjxQHEYLVzD
     yciXKmBOIkPJsbTrRwWFjxQHEYLVzu =yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['replayVod']['count']
     yciXKmBOIkPJsbTrRwWFjxQHEYLVzp=yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['highlightVod']['count']
     yciXKmBOIkPJsbTrRwWFjxQHEYLVza =yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['vods']['count']
     yciXKmBOIkPJsbTrRwWFjxQHEYLVzA='' 
     yciXKmBOIkPJsbTrRwWFjxQHEYLVhU=yciXKmBOIkPJsbTrRwWFjxQHEYLVzu+yciXKmBOIkPJsbTrRwWFjxQHEYLVzp+yciXKmBOIkPJsbTrRwWFjxQHEYLVza
     if yciXKmBOIkPJsbTrRwWFjxQHEYLVhU==0:
      if yciXKmBOIkPJsbTrRwWFjxQHEYLVzS=='2':
       yciXKmBOIkPJsbTrRwWFjxQHEYLVAn='----- %s -----'%(yciXKmBOIkPJsbTrRwWFjxQHEYLVzq)
       yciXKmBOIkPJsbTrRwWFjxQHEYLVzo=''
      else:
       yciXKmBOIkPJsbTrRwWFjxQHEYLVAn+=' - 관련영상 없음'
       yciXKmBOIkPJsbTrRwWFjxQHEYLVzn+='\n\n ** 관련영상 없음 **'
     else:
      if yciXKmBOIkPJsbTrRwWFjxQHEYLVzu!=0:
       yciXKmBOIkPJsbTrRwWFjxQHEYLVzA =yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['replayVod']['list'][0]['imgUrl']
      elif yciXKmBOIkPJsbTrRwWFjxQHEYLVzp!=0:
       yciXKmBOIkPJsbTrRwWFjxQHEYLVzA =yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['highlightVod']['list'][0]['imgUrl']
      else:
       yciXKmBOIkPJsbTrRwWFjxQHEYLVzA =yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['vods']['list'][0]['imgUrl']
     yciXKmBOIkPJsbTrRwWFjxQHEYLVAh={'gameTitle':yciXKmBOIkPJsbTrRwWFjxQHEYLVAn,'gameId':yciXKmBOIkPJsbTrRwWFjxQHEYLVzN,'beginDate':yciXKmBOIkPJsbTrRwWFjxQHEYLVzo[:11],'thumbnail':yciXKmBOIkPJsbTrRwWFjxQHEYLVzA,'info_plot':yciXKmBOIkPJsbTrRwWFjxQHEYLVzn,'leaguenm':yciXKmBOIkPJsbTrRwWFjxQHEYLVzG,'seasonnm':yciXKmBOIkPJsbTrRwWFjxQHEYLVzq,'roundnm':yciXKmBOIkPJsbTrRwWFjxQHEYLVzM,'totVodCnt':yciXKmBOIkPJsbTrRwWFjxQHEYLVhU}
     yciXKmBOIkPJsbTrRwWFjxQHEYLVUa.append(yciXKmBOIkPJsbTrRwWFjxQHEYLVAh)
   if yciXKmBOIkPJsbTrRwWFjxQHEYLVzS=='2':
    if yciXKmBOIkPJsbTrRwWFjxQHEYLVUg['count']>page_int*yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.GAMELIST_LIMIT:yciXKmBOIkPJsbTrRwWFjxQHEYLVzt=yciXKmBOIkPJsbTrRwWFjxQHEYLVhN
   else:
    if yciXKmBOIkPJsbTrRwWFjxQHEYLVUg['list'][0]['count']>page_int*yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.GAMELIST_LIMIT:yciXKmBOIkPJsbTrRwWFjxQHEYLVzt=yciXKmBOIkPJsbTrRwWFjxQHEYLVhN
  except yciXKmBOIkPJsbTrRwWFjxQHEYLVhG as exception:
   yciXKmBOIkPJsbTrRwWFjxQHEYLVhf(exception)
  return yciXKmBOIkPJsbTrRwWFjxQHEYLVUa,yciXKmBOIkPJsbTrRwWFjxQHEYLVzt
 def GetGameVodList(yciXKmBOIkPJsbTrRwWFjxQHEYLVUz,yciXKmBOIkPJsbTrRwWFjxQHEYLVzN):
  yciXKmBOIkPJsbTrRwWFjxQHEYLVUa=[]
  yciXKmBOIkPJsbTrRwWFjxQHEYLVhA=''
  try:
   yciXKmBOIkPJsbTrRwWFjxQHEYLVAd=yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.API_DOMAIN+'/api/v2/vod/game'
   yciXKmBOIkPJsbTrRwWFjxQHEYLVzl={'gameId':yciXKmBOIkPJsbTrRwWFjxQHEYLVzN,'pageItem':'1000'}
   yciXKmBOIkPJsbTrRwWFjxQHEYLVUM=yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.callRequestCookies('Get',yciXKmBOIkPJsbTrRwWFjxQHEYLVAd,payload=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,params=yciXKmBOIkPJsbTrRwWFjxQHEYLVzl,headers=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,cookies=yciXKmBOIkPJsbTrRwWFjxQHEYLVht)
   yciXKmBOIkPJsbTrRwWFjxQHEYLVUg=json.loads(yciXKmBOIkPJsbTrRwWFjxQHEYLVUM.text)
   yciXKmBOIkPJsbTrRwWFjxQHEYLVzf=yciXKmBOIkPJsbTrRwWFjxQHEYLVUg['list']
   for yciXKmBOIkPJsbTrRwWFjxQHEYLVAz in yciXKmBOIkPJsbTrRwWFjxQHEYLVzf:
    yciXKmBOIkPJsbTrRwWFjxQHEYLVdp =yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['title']
    yciXKmBOIkPJsbTrRwWFjxQHEYLVda =yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['id']
    yciXKmBOIkPJsbTrRwWFjxQHEYLVzU =yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['vtype']
    yciXKmBOIkPJsbTrRwWFjxQHEYLVzA =yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['imgUrl']
    yciXKmBOIkPJsbTrRwWFjxQHEYLVzd =yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['vtypeId']
    yciXKmBOIkPJsbTrRwWFjxQHEYLVAh={'vodTitle':yciXKmBOIkPJsbTrRwWFjxQHEYLVdp,'vodId':yciXKmBOIkPJsbTrRwWFjxQHEYLVda,'vodType':yciXKmBOIkPJsbTrRwWFjxQHEYLVzU,'thumbnail':yciXKmBOIkPJsbTrRwWFjxQHEYLVzA,'vtypeId':yciXKmBOIkPJsbTrRwWFjxQHEYLVho(yciXKmBOIkPJsbTrRwWFjxQHEYLVzd),'duration':yciXKmBOIkPJsbTrRwWFjxQHEYLVhM(yciXKmBOIkPJsbTrRwWFjxQHEYLVAz['duration']/1000)}
    yciXKmBOIkPJsbTrRwWFjxQHEYLVUa.append(yciXKmBOIkPJsbTrRwWFjxQHEYLVAh)
  except yciXKmBOIkPJsbTrRwWFjxQHEYLVhG as exception:
   yciXKmBOIkPJsbTrRwWFjxQHEYLVhf(exception)
  return yciXKmBOIkPJsbTrRwWFjxQHEYLVUa
 def GetReplay_UrlId(yciXKmBOIkPJsbTrRwWFjxQHEYLVUz,yciXKmBOIkPJsbTrRwWFjxQHEYLVhA,yciXKmBOIkPJsbTrRwWFjxQHEYLVzd):
  yciXKmBOIkPJsbTrRwWFjxQHEYLVhd=yciXKmBOIkPJsbTrRwWFjxQHEYLVAu=''
  yciXKmBOIkPJsbTrRwWFjxQHEYLVhz=''
  try:
   yciXKmBOIkPJsbTrRwWFjxQHEYLVAd=yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.API_DOMAIN+'/api/v2/vod/'+yciXKmBOIkPJsbTrRwWFjxQHEYLVhA
   yciXKmBOIkPJsbTrRwWFjxQHEYLVUM=yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.callRequestCookies('Get',yciXKmBOIkPJsbTrRwWFjxQHEYLVAd,payload=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,params=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,headers=yciXKmBOIkPJsbTrRwWFjxQHEYLVht,cookies=yciXKmBOIkPJsbTrRwWFjxQHEYLVht)
   yciXKmBOIkPJsbTrRwWFjxQHEYLVUg=json.loads(yciXKmBOIkPJsbTrRwWFjxQHEYLVUM.text)
   yciXKmBOIkPJsbTrRwWFjxQHEYLVhd =yciXKmBOIkPJsbTrRwWFjxQHEYLVUg['clipId']
   yciXKmBOIkPJsbTrRwWFjxQHEYLVAu=yciXKmBOIkPJsbTrRwWFjxQHEYLVUg['videoId']
   yciXKmBOIkPJsbTrRwWFjxQHEYLVhz=yciXKmBOIkPJsbTrRwWFjxQHEYLVhd
   if yciXKmBOIkPJsbTrRwWFjxQHEYLVUz.CheckSubEnd()or yciXKmBOIkPJsbTrRwWFjxQHEYLVzd!='1':yciXKmBOIkPJsbTrRwWFjxQHEYLVhz=yciXKmBOIkPJsbTrRwWFjxQHEYLVAu 
  except yciXKmBOIkPJsbTrRwWFjxQHEYLVhG as exception:
   yciXKmBOIkPJsbTrRwWFjxQHEYLVhf(exception)
  return yciXKmBOIkPJsbTrRwWFjxQHEYLVhz
# Created by pyminifier (https://github.com/liftoff/pyminifier)
