__author__="NightRain"
viRgTJAeXGMUapzbdoEqftSmNCOnWw=object
viRgTJAeXGMUapzbdoEqftSmNCOnWL=None
viRgTJAeXGMUapzbdoEqftSmNCOnWP=False
viRgTJAeXGMUapzbdoEqftSmNCOnWl=open
viRgTJAeXGMUapzbdoEqftSmNCOnWu=True
viRgTJAeXGMUapzbdoEqftSmNCOnWk=str
viRgTJAeXGMUapzbdoEqftSmNCOnWK=Exception
viRgTJAeXGMUapzbdoEqftSmNCOnWV=print
viRgTJAeXGMUapzbdoEqftSmNCOnWj=int
viRgTJAeXGMUapzbdoEqftSmNCOnWI=len
viRgTJAeXGMUapzbdoEqftSmNCOnWr=range
import urllib
import re
import json
import sys
import time
import requests
import datetime
import base64
viRgTJAeXGMUapzbdoEqftSmNCOnBc={'stream50':1080,'stream40':720,'stream30':540}
class viRgTJAeXGMUapzbdoEqftSmNCOnBh(viRgTJAeXGMUapzbdoEqftSmNCOnWw):
 def __init__(viRgTJAeXGMUapzbdoEqftSmNCOnBx):
  viRgTJAeXGMUapzbdoEqftSmNCOnBx.SPOTV_PMCODE ='987'
  viRgTJAeXGMUapzbdoEqftSmNCOnBx.SPOTV_PMSIZE =3
  viRgTJAeXGMUapzbdoEqftSmNCOnBx.GAMELIST_LIMIT =10
  viRgTJAeXGMUapzbdoEqftSmNCOnBx.API_DOMAIN ='https://www.spotvnow.co.kr'
  viRgTJAeXGMUapzbdoEqftSmNCOnBx.BC_DOMAIN ='https://players.brightcove.net'
  viRgTJAeXGMUapzbdoEqftSmNCOnBx.PLAYER_DOMAIN ='https://edge.api.brightcove.com'
  viRgTJAeXGMUapzbdoEqftSmNCOnBx.STREAM_DOMAIN ='https://gtm-spotv.brightcovecdn.com'
  viRgTJAeXGMUapzbdoEqftSmNCOnBx.STREAM_M3U8 ='ap-northeast-1/5764318566001/playlist_dvr'
  viRgTJAeXGMUapzbdoEqftSmNCOnBx.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36'
  viRgTJAeXGMUapzbdoEqftSmNCOnBx.DEFAULT_HEADER ={'user-agent':viRgTJAeXGMUapzbdoEqftSmNCOnBx.USER_AGENT}
  viRgTJAeXGMUapzbdoEqftSmNCOnBx.COOKIE_FILE_NAME=''
  viRgTJAeXGMUapzbdoEqftSmNCOnBx.ST ={}
  viRgTJAeXGMUapzbdoEqftSmNCOnBx.Init_ST_Total()
 def Init_ST_Total(viRgTJAeXGMUapzbdoEqftSmNCOnBx):
  viRgTJAeXGMUapzbdoEqftSmNCOnBx.ST={'account':{},'cookies':{'spotv_sessionid':'','spotv_session':'','spotv_accountId':'','spotv_policyKey':'','spotv_subend':'',},}
 def callRequestCookies(viRgTJAeXGMUapzbdoEqftSmNCOnBx,jobtype,viRgTJAeXGMUapzbdoEqftSmNCOnBr,payload=viRgTJAeXGMUapzbdoEqftSmNCOnWL,params=viRgTJAeXGMUapzbdoEqftSmNCOnWL,headers=viRgTJAeXGMUapzbdoEqftSmNCOnWL,cookies=viRgTJAeXGMUapzbdoEqftSmNCOnWL,redirects=viRgTJAeXGMUapzbdoEqftSmNCOnWP):
  viRgTJAeXGMUapzbdoEqftSmNCOnBW=viRgTJAeXGMUapzbdoEqftSmNCOnBx.DEFAULT_HEADER
  if headers:viRgTJAeXGMUapzbdoEqftSmNCOnBW.update(headers)
  if jobtype=='Get':
   viRgTJAeXGMUapzbdoEqftSmNCOnBY=requests.get(viRgTJAeXGMUapzbdoEqftSmNCOnBr,params=params,headers=viRgTJAeXGMUapzbdoEqftSmNCOnBW,cookies=cookies,allow_redirects=redirects)
  else:
   viRgTJAeXGMUapzbdoEqftSmNCOnBY=requests.post(viRgTJAeXGMUapzbdoEqftSmNCOnBr,data=payload,params=params,headers=viRgTJAeXGMUapzbdoEqftSmNCOnBW,cookies=cookies,allow_redirects=redirects)
  return viRgTJAeXGMUapzbdoEqftSmNCOnBY
 def JsonFile_Save(viRgTJAeXGMUapzbdoEqftSmNCOnBx,filename,viRgTJAeXGMUapzbdoEqftSmNCOnBD):
  if filename=='':return viRgTJAeXGMUapzbdoEqftSmNCOnWP
  try:
   fp=viRgTJAeXGMUapzbdoEqftSmNCOnWl(filename,'w',-1,'utf-8')
   json.dump(viRgTJAeXGMUapzbdoEqftSmNCOnBD,fp,indent=4,ensure_ascii=viRgTJAeXGMUapzbdoEqftSmNCOnWP)
   fp.close()
  except:
   return viRgTJAeXGMUapzbdoEqftSmNCOnWP
  return viRgTJAeXGMUapzbdoEqftSmNCOnWu
 def JsonFile_Load(viRgTJAeXGMUapzbdoEqftSmNCOnBx,filename):
  if filename=='':return{}
  try:
   fp=viRgTJAeXGMUapzbdoEqftSmNCOnWl(filename,'r',-1,'utf-8')
   viRgTJAeXGMUapzbdoEqftSmNCOnBy=json.load(fp)
   fp.close()
  except:
   return{}
  return viRgTJAeXGMUapzbdoEqftSmNCOnBy
 def Save_session_acount(viRgTJAeXGMUapzbdoEqftSmNCOnBx,viRgTJAeXGMUapzbdoEqftSmNCOnBH,viRgTJAeXGMUapzbdoEqftSmNCOnBs):
  viRgTJAeXGMUapzbdoEqftSmNCOnBx.ST['account']['stid'] =base64.standard_b64encode(viRgTJAeXGMUapzbdoEqftSmNCOnBH.encode()).decode('utf-8')
  viRgTJAeXGMUapzbdoEqftSmNCOnBx.ST['account']['stpw'] =base64.standard_b64encode(viRgTJAeXGMUapzbdoEqftSmNCOnBs.encode()).decode('utf-8')
 def Load_session_acount(viRgTJAeXGMUapzbdoEqftSmNCOnBx):
  try:
   viRgTJAeXGMUapzbdoEqftSmNCOnBH =base64.standard_b64decode(viRgTJAeXGMUapzbdoEqftSmNCOnBx.ST['account']['stid']).decode('utf-8')
   viRgTJAeXGMUapzbdoEqftSmNCOnBs =base64.standard_b64decode(viRgTJAeXGMUapzbdoEqftSmNCOnBx.ST['account']['stpw']).decode('utf-8')
  except:
   return '',''
  return viRgTJAeXGMUapzbdoEqftSmNCOnBH,viRgTJAeXGMUapzbdoEqftSmNCOnBs
 def makeDefaultCookies(viRgTJAeXGMUapzbdoEqftSmNCOnBx):
  viRgTJAeXGMUapzbdoEqftSmNCOnBQ={'SESSION':viRgTJAeXGMUapzbdoEqftSmNCOnBx.ST['cookies']['spotv_session']}
  return viRgTJAeXGMUapzbdoEqftSmNCOnBQ
 def makeDefaultHeaders(viRgTJAeXGMUapzbdoEqftSmNCOnBx):
  viRgTJAeXGMUapzbdoEqftSmNCOnBw={'accept':'application/json;pk={}'.format(viRgTJAeXGMUapzbdoEqftSmNCOnBx.ST['cookies']['spotv_policyKey'])}
  return viRgTJAeXGMUapzbdoEqftSmNCOnBw
 def xmlText(viRgTJAeXGMUapzbdoEqftSmNCOnBx,in_text):
  viRgTJAeXGMUapzbdoEqftSmNCOnBL=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;')
  return viRgTJAeXGMUapzbdoEqftSmNCOnBL
 def GetCredential(viRgTJAeXGMUapzbdoEqftSmNCOnBx,user_id,user_pw):
  try:
   viRgTJAeXGMUapzbdoEqftSmNCOnBP=base64.standard_b64encode(user_id.encode('UTF-8')).decode('utf-8')
   viRgTJAeXGMUapzbdoEqftSmNCOnBl=base64.standard_b64encode(user_pw.encode('UTF-8')).decode('utf-8')
   viRgTJAeXGMUapzbdoEqftSmNCOnBu=viRgTJAeXGMUapzbdoEqftSmNCOnBx.API_DOMAIN+'/api/v2/login'
   viRgTJAeXGMUapzbdoEqftSmNCOnBk={'username':viRgTJAeXGMUapzbdoEqftSmNCOnBP,'password':viRgTJAeXGMUapzbdoEqftSmNCOnBl}
   viRgTJAeXGMUapzbdoEqftSmNCOnBk=json.dumps(viRgTJAeXGMUapzbdoEqftSmNCOnBk)
   viRgTJAeXGMUapzbdoEqftSmNCOnBK=viRgTJAeXGMUapzbdoEqftSmNCOnBx.callRequestCookies('Post',viRgTJAeXGMUapzbdoEqftSmNCOnBu,payload=viRgTJAeXGMUapzbdoEqftSmNCOnBk,params=viRgTJAeXGMUapzbdoEqftSmNCOnWL,headers=viRgTJAeXGMUapzbdoEqftSmNCOnWL,cookies=viRgTJAeXGMUapzbdoEqftSmNCOnWL)
   viRgTJAeXGMUapzbdoEqftSmNCOnBV=json.loads(viRgTJAeXGMUapzbdoEqftSmNCOnBK.text)
   for viRgTJAeXGMUapzbdoEqftSmNCOnBj in viRgTJAeXGMUapzbdoEqftSmNCOnBK.cookies:
    if viRgTJAeXGMUapzbdoEqftSmNCOnBj.name=='SESSION':
     viRgTJAeXGMUapzbdoEqftSmNCOnBx.ST['cookies']['spotv_session']=viRgTJAeXGMUapzbdoEqftSmNCOnBj.value
     break
   if viRgTJAeXGMUapzbdoEqftSmNCOnBx.ST['cookies']['spotv_session']=='':
    viRgTJAeXGMUapzbdoEqftSmNCOnBx.Init_ST_Total()
    return viRgTJAeXGMUapzbdoEqftSmNCOnWP
   viRgTJAeXGMUapzbdoEqftSmNCOnBx.ST['cookies']['spotv_sessionid']=viRgTJAeXGMUapzbdoEqftSmNCOnWk(viRgTJAeXGMUapzbdoEqftSmNCOnBV['userId'])
   viRgTJAeXGMUapzbdoEqftSmNCOnBI=viRgTJAeXGMUapzbdoEqftSmNCOnBx.SPOTV_PMCODE+viRgTJAeXGMUapzbdoEqftSmNCOnWk(viRgTJAeXGMUapzbdoEqftSmNCOnBV['subEndTime'])
   viRgTJAeXGMUapzbdoEqftSmNCOnBx.ST['cookies']['spotv_subend'] =base64.standard_b64encode(viRgTJAeXGMUapzbdoEqftSmNCOnBI.encode()).decode('utf-8')
   if viRgTJAeXGMUapzbdoEqftSmNCOnBx.GetPolicyKey()==viRgTJAeXGMUapzbdoEqftSmNCOnWP:
    viRgTJAeXGMUapzbdoEqftSmNCOnBx.Init_ST_Total()
    return viRgTJAeXGMUapzbdoEqftSmNCOnWP
  except viRgTJAeXGMUapzbdoEqftSmNCOnWK as exception:
   viRgTJAeXGMUapzbdoEqftSmNCOnWV(exception)
   viRgTJAeXGMUapzbdoEqftSmNCOnBx.Init_ST_Total()
   return viRgTJAeXGMUapzbdoEqftSmNCOnWP
  return viRgTJAeXGMUapzbdoEqftSmNCOnWu
 def GetPolicyKey(viRgTJAeXGMUapzbdoEqftSmNCOnBx):
  try:
   viRgTJAeXGMUapzbdoEqftSmNCOnBr=viRgTJAeXGMUapzbdoEqftSmNCOnBx.GetBcPlayerUrl()
   if viRgTJAeXGMUapzbdoEqftSmNCOnBr=='':return viRgTJAeXGMUapzbdoEqftSmNCOnWP
   viRgTJAeXGMUapzbdoEqftSmNCOnBK=viRgTJAeXGMUapzbdoEqftSmNCOnBx.callRequestCookies('Get',viRgTJAeXGMUapzbdoEqftSmNCOnBr,payload=viRgTJAeXGMUapzbdoEqftSmNCOnWL,params=viRgTJAeXGMUapzbdoEqftSmNCOnWL,headers=viRgTJAeXGMUapzbdoEqftSmNCOnWL,cookies=viRgTJAeXGMUapzbdoEqftSmNCOnWL)
   viRgTJAeXGMUapzbdoEqftSmNCOnhB=viRgTJAeXGMUapzbdoEqftSmNCOnBK.text
   viRgTJAeXGMUapzbdoEqftSmNCOnhc =re.findall('accountId:\s*\"\d{13}\",\s*policyKey:\s*\".[^(){}]{100,300}\"',viRgTJAeXGMUapzbdoEqftSmNCOnhB)[0]
   viRgTJAeXGMUapzbdoEqftSmNCOnhc =viRgTJAeXGMUapzbdoEqftSmNCOnhc.replace('accountId','"accountId"')
   viRgTJAeXGMUapzbdoEqftSmNCOnhc =viRgTJAeXGMUapzbdoEqftSmNCOnhc.replace('policyKey','"policyKey"')
   viRgTJAeXGMUapzbdoEqftSmNCOnhc ='{'+viRgTJAeXGMUapzbdoEqftSmNCOnhc+'}'
   viRgTJAeXGMUapzbdoEqftSmNCOnhx=json.loads(viRgTJAeXGMUapzbdoEqftSmNCOnhc)
   viRgTJAeXGMUapzbdoEqftSmNCOnBx.ST['cookies']['spotv_accountId']=viRgTJAeXGMUapzbdoEqftSmNCOnhx['accountId']
   viRgTJAeXGMUapzbdoEqftSmNCOnBx.ST['cookies']['spotv_policyKey']=viRgTJAeXGMUapzbdoEqftSmNCOnhx['policyKey']
  except viRgTJAeXGMUapzbdoEqftSmNCOnWK as exception:
   viRgTJAeXGMUapzbdoEqftSmNCOnWV(exception)
   return viRgTJAeXGMUapzbdoEqftSmNCOnWP
  return viRgTJAeXGMUapzbdoEqftSmNCOnWu
 def GetBcPlayerUrl(viRgTJAeXGMUapzbdoEqftSmNCOnBx):
  viRgTJAeXGMUapzbdoEqftSmNCOnhW=''
  try:
   viRgTJAeXGMUapzbdoEqftSmNCOnBr=viRgTJAeXGMUapzbdoEqftSmNCOnBx.GetMainJspath()
   if viRgTJAeXGMUapzbdoEqftSmNCOnBr=='':return viRgTJAeXGMUapzbdoEqftSmNCOnhW
   viRgTJAeXGMUapzbdoEqftSmNCOnBK=viRgTJAeXGMUapzbdoEqftSmNCOnBx.callRequestCookies('Get',viRgTJAeXGMUapzbdoEqftSmNCOnBr,payload=viRgTJAeXGMUapzbdoEqftSmNCOnWL,params=viRgTJAeXGMUapzbdoEqftSmNCOnWL,headers=viRgTJAeXGMUapzbdoEqftSmNCOnWL,cookies=viRgTJAeXGMUapzbdoEqftSmNCOnWL)
   viRgTJAeXGMUapzbdoEqftSmNCOnhB=viRgTJAeXGMUapzbdoEqftSmNCOnBK.text
   viRgTJAeXGMUapzbdoEqftSmNCOnhY =r'default:{(.*?)}'
   viRgTJAeXGMUapzbdoEqftSmNCOnhD =re.compile(viRgTJAeXGMUapzbdoEqftSmNCOnhY).findall(viRgTJAeXGMUapzbdoEqftSmNCOnhB)[0]
   viRgTJAeXGMUapzbdoEqftSmNCOnhF=r'bc:"(.*?)"'
   viRgTJAeXGMUapzbdoEqftSmNCOnhy=re.compile(viRgTJAeXGMUapzbdoEqftSmNCOnhF).findall(viRgTJAeXGMUapzbdoEqftSmNCOnhD)[0]
   viRgTJAeXGMUapzbdoEqftSmNCOnhH=r'":"(.*?)"'
   viRgTJAeXGMUapzbdoEqftSmNCOnhs=re.compile(viRgTJAeXGMUapzbdoEqftSmNCOnhH).findall(viRgTJAeXGMUapzbdoEqftSmNCOnhD)[0]
   viRgTJAeXGMUapzbdoEqftSmNCOnhW="%s/%s/%s_default/index.min.js"%(viRgTJAeXGMUapzbdoEqftSmNCOnBx.BC_DOMAIN,viRgTJAeXGMUapzbdoEqftSmNCOnhy,viRgTJAeXGMUapzbdoEqftSmNCOnhs)
  except viRgTJAeXGMUapzbdoEqftSmNCOnWK as exception:
   viRgTJAeXGMUapzbdoEqftSmNCOnWV(exception)
  return viRgTJAeXGMUapzbdoEqftSmNCOnhW
 def GetMainJspath(viRgTJAeXGMUapzbdoEqftSmNCOnBx):
  viRgTJAeXGMUapzbdoEqftSmNCOnhQ=''
  try:
   viRgTJAeXGMUapzbdoEqftSmNCOnBr=viRgTJAeXGMUapzbdoEqftSmNCOnBx.API_DOMAIN
   viRgTJAeXGMUapzbdoEqftSmNCOnBK=viRgTJAeXGMUapzbdoEqftSmNCOnBx.callRequestCookies('Get',viRgTJAeXGMUapzbdoEqftSmNCOnBr,payload=viRgTJAeXGMUapzbdoEqftSmNCOnWL,params=viRgTJAeXGMUapzbdoEqftSmNCOnWL,headers=viRgTJAeXGMUapzbdoEqftSmNCOnWL,cookies=viRgTJAeXGMUapzbdoEqftSmNCOnWL)
   viRgTJAeXGMUapzbdoEqftSmNCOnhB=viRgTJAeXGMUapzbdoEqftSmNCOnBK.text
   viRgTJAeXGMUapzbdoEqftSmNCOnhc =re.findall('https://cdn.spotvnow.co.kr/dist/js/.{20}\.js',viRgTJAeXGMUapzbdoEqftSmNCOnhB)[0]
   viRgTJAeXGMUapzbdoEqftSmNCOnhQ=viRgTJAeXGMUapzbdoEqftSmNCOnhc
  except viRgTJAeXGMUapzbdoEqftSmNCOnWK as exception:
   viRgTJAeXGMUapzbdoEqftSmNCOnWV(exception)
  return viRgTJAeXGMUapzbdoEqftSmNCOnhQ
 def Get_Now_Datetime(viRgTJAeXGMUapzbdoEqftSmNCOnBx):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetLiveChannelList(viRgTJAeXGMUapzbdoEqftSmNCOnBx):
  viRgTJAeXGMUapzbdoEqftSmNCOnhL=[]
  viRgTJAeXGMUapzbdoEqftSmNCOnhP ={}
  try:
   viRgTJAeXGMUapzbdoEqftSmNCOnBr=viRgTJAeXGMUapzbdoEqftSmNCOnBx.API_DOMAIN+'/api/v2/channel'
   viRgTJAeXGMUapzbdoEqftSmNCOnBK=viRgTJAeXGMUapzbdoEqftSmNCOnBx.callRequestCookies('Get',viRgTJAeXGMUapzbdoEqftSmNCOnBr,payload=viRgTJAeXGMUapzbdoEqftSmNCOnWL,params=viRgTJAeXGMUapzbdoEqftSmNCOnWL,headers=viRgTJAeXGMUapzbdoEqftSmNCOnWL,cookies=viRgTJAeXGMUapzbdoEqftSmNCOnWL)
   viRgTJAeXGMUapzbdoEqftSmNCOnBV=json.loads(viRgTJAeXGMUapzbdoEqftSmNCOnBK.text)
   viRgTJAeXGMUapzbdoEqftSmNCOnhP=viRgTJAeXGMUapzbdoEqftSmNCOnBx.GetEPGList()
   for viRgTJAeXGMUapzbdoEqftSmNCOnhl in viRgTJAeXGMUapzbdoEqftSmNCOnBV:
    viRgTJAeXGMUapzbdoEqftSmNCOnhu={'id':viRgTJAeXGMUapzbdoEqftSmNCOnhl['id'],'name':viRgTJAeXGMUapzbdoEqftSmNCOnhl['name'],'logo':viRgTJAeXGMUapzbdoEqftSmNCOnhl['logo'],'free':viRgTJAeXGMUapzbdoEqftSmNCOnhl['free'],'programName':viRgTJAeXGMUapzbdoEqftSmNCOnhl['programName'],'channelepg':viRgTJAeXGMUapzbdoEqftSmNCOnhP.get(viRgTJAeXGMUapzbdoEqftSmNCOnhl['id']),'hlsUrl':viRgTJAeXGMUapzbdoEqftSmNCOnhl['hlsUrl'],}
    viRgTJAeXGMUapzbdoEqftSmNCOnhL.append(viRgTJAeXGMUapzbdoEqftSmNCOnhu)
  except viRgTJAeXGMUapzbdoEqftSmNCOnWK as exception:
   viRgTJAeXGMUapzbdoEqftSmNCOnWV(exception)
  return viRgTJAeXGMUapzbdoEqftSmNCOnhL
 def GetHlsUrl(viRgTJAeXGMUapzbdoEqftSmNCOnBx,mediacode):
  viRgTJAeXGMUapzbdoEqftSmNCOnhk=''
  try:
   viRgTJAeXGMUapzbdoEqftSmNCOnBr=viRgTJAeXGMUapzbdoEqftSmNCOnBx.API_DOMAIN+'/api/v2/channel'
   viRgTJAeXGMUapzbdoEqftSmNCOnBK=viRgTJAeXGMUapzbdoEqftSmNCOnBx.callRequestCookies('Get',viRgTJAeXGMUapzbdoEqftSmNCOnBr,payload=viRgTJAeXGMUapzbdoEqftSmNCOnWL,params=viRgTJAeXGMUapzbdoEqftSmNCOnWL,headers=viRgTJAeXGMUapzbdoEqftSmNCOnWL,cookies=viRgTJAeXGMUapzbdoEqftSmNCOnWL)
   viRgTJAeXGMUapzbdoEqftSmNCOnBV=json.loads(viRgTJAeXGMUapzbdoEqftSmNCOnBK.text)
   for viRgTJAeXGMUapzbdoEqftSmNCOnhl in viRgTJAeXGMUapzbdoEqftSmNCOnBV:
    if viRgTJAeXGMUapzbdoEqftSmNCOnWk(viRgTJAeXGMUapzbdoEqftSmNCOnhl['id'])==viRgTJAeXGMUapzbdoEqftSmNCOnWk(mediacode):
     viRgTJAeXGMUapzbdoEqftSmNCOnhk=viRgTJAeXGMUapzbdoEqftSmNCOnhl['hlsUrl']
     break
  except viRgTJAeXGMUapzbdoEqftSmNCOnWK as exception:
   viRgTJAeXGMUapzbdoEqftSmNCOnWV(exception)
  return viRgTJAeXGMUapzbdoEqftSmNCOnhk
 def GetEPGList(viRgTJAeXGMUapzbdoEqftSmNCOnBx):
  viRgTJAeXGMUapzbdoEqftSmNCOnhK={}
  viRgTJAeXGMUapzbdoEqftSmNCOnhV=viRgTJAeXGMUapzbdoEqftSmNCOnBx.Get_Now_Datetime()
  viRgTJAeXGMUapzbdoEqftSmNCOnhj=viRgTJAeXGMUapzbdoEqftSmNCOnhV.strftime('%Y%m%d%H%M')
  viRgTJAeXGMUapzbdoEqftSmNCOnhI='%s-%s-%s'%(viRgTJAeXGMUapzbdoEqftSmNCOnhj[0:4],viRgTJAeXGMUapzbdoEqftSmNCOnhj[4:6],viRgTJAeXGMUapzbdoEqftSmNCOnhj[6:8])
  viRgTJAeXGMUapzbdoEqftSmNCOnhr=(viRgTJAeXGMUapzbdoEqftSmNCOnhV+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M')
  try:
   viRgTJAeXGMUapzbdoEqftSmNCOnBr=viRgTJAeXGMUapzbdoEqftSmNCOnBx.API_DOMAIN+'/api/v2/program/'+viRgTJAeXGMUapzbdoEqftSmNCOnhI
   viRgTJAeXGMUapzbdoEqftSmNCOnBK=viRgTJAeXGMUapzbdoEqftSmNCOnBx.callRequestCookies('Get',viRgTJAeXGMUapzbdoEqftSmNCOnBr,payload=viRgTJAeXGMUapzbdoEqftSmNCOnWL,params=viRgTJAeXGMUapzbdoEqftSmNCOnWL,headers=viRgTJAeXGMUapzbdoEqftSmNCOnWL,cookies=viRgTJAeXGMUapzbdoEqftSmNCOnWL)
   viRgTJAeXGMUapzbdoEqftSmNCOnBV=json.loads(viRgTJAeXGMUapzbdoEqftSmNCOnBK.text)
   viRgTJAeXGMUapzbdoEqftSmNCOncB=-1 
   viRgTJAeXGMUapzbdoEqftSmNCOnch =''
   for viRgTJAeXGMUapzbdoEqftSmNCOnhl in viRgTJAeXGMUapzbdoEqftSmNCOnBV:
    viRgTJAeXGMUapzbdoEqftSmNCOncx=viRgTJAeXGMUapzbdoEqftSmNCOnhl['channelId']
    viRgTJAeXGMUapzbdoEqftSmNCOncW =viRgTJAeXGMUapzbdoEqftSmNCOnhl['startTime'].replace('-','').replace(' ','').replace(':','')
    viRgTJAeXGMUapzbdoEqftSmNCOncY =viRgTJAeXGMUapzbdoEqftSmNCOnhl['endTime'].replace('-','').replace(' ','').replace(':','')
    if viRgTJAeXGMUapzbdoEqftSmNCOnWj(viRgTJAeXGMUapzbdoEqftSmNCOnhj)>viRgTJAeXGMUapzbdoEqftSmNCOnWj(viRgTJAeXGMUapzbdoEqftSmNCOncY) :continue
    if viRgTJAeXGMUapzbdoEqftSmNCOnWj(viRgTJAeXGMUapzbdoEqftSmNCOnhr)<viRgTJAeXGMUapzbdoEqftSmNCOnWj(viRgTJAeXGMUapzbdoEqftSmNCOncW):continue
    if viRgTJAeXGMUapzbdoEqftSmNCOncB!=viRgTJAeXGMUapzbdoEqftSmNCOncx:
     if viRgTJAeXGMUapzbdoEqftSmNCOnch!='':viRgTJAeXGMUapzbdoEqftSmNCOnhK[viRgTJAeXGMUapzbdoEqftSmNCOncB]=viRgTJAeXGMUapzbdoEqftSmNCOnch
     viRgTJAeXGMUapzbdoEqftSmNCOncB=viRgTJAeXGMUapzbdoEqftSmNCOncx
     viRgTJAeXGMUapzbdoEqftSmNCOnch =''
    if viRgTJAeXGMUapzbdoEqftSmNCOnch:viRgTJAeXGMUapzbdoEqftSmNCOnch+='\n'
    viRgTJAeXGMUapzbdoEqftSmNCOnch+=viRgTJAeXGMUapzbdoEqftSmNCOnhl['title']+'\n'
    viRgTJAeXGMUapzbdoEqftSmNCOnch+=' [%s ~ %s]'%(viRgTJAeXGMUapzbdoEqftSmNCOnhl['startTime'][-5:],viRgTJAeXGMUapzbdoEqftSmNCOnhl['endTime'][-5:])+'\n'
   if viRgTJAeXGMUapzbdoEqftSmNCOnch:viRgTJAeXGMUapzbdoEqftSmNCOnhK[viRgTJAeXGMUapzbdoEqftSmNCOncB]=viRgTJAeXGMUapzbdoEqftSmNCOnch
  except viRgTJAeXGMUapzbdoEqftSmNCOnWK as exception:
   viRgTJAeXGMUapzbdoEqftSmNCOnWV(exception)
  return viRgTJAeXGMUapzbdoEqftSmNCOnhK
 def GetEPGList_new(viRgTJAeXGMUapzbdoEqftSmNCOnBx):
  viRgTJAeXGMUapzbdoEqftSmNCOnhK={}
  viRgTJAeXGMUapzbdoEqftSmNCOnhV=viRgTJAeXGMUapzbdoEqftSmNCOnBx.Get_Now_Datetime()
  viRgTJAeXGMUapzbdoEqftSmNCOnhj=viRgTJAeXGMUapzbdoEqftSmNCOnhV.strftime('%Y%m%d%H%M00')
  viRgTJAeXGMUapzbdoEqftSmNCOnhI='%s%s%s'%(viRgTJAeXGMUapzbdoEqftSmNCOnhj[0:4],viRgTJAeXGMUapzbdoEqftSmNCOnhj[4:6],viRgTJAeXGMUapzbdoEqftSmNCOnhj[6:8])
  viRgTJAeXGMUapzbdoEqftSmNCOnhr=(viRgTJAeXGMUapzbdoEqftSmNCOnhV+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M00')
  try:
   for viRgTJAeXGMUapzbdoEqftSmNCOnhl in LIVETV_LIST:
    viRgTJAeXGMUapzbdoEqftSmNCOncD =viRgTJAeXGMUapzbdoEqftSmNCOnhl['videoId']
    if viRgTJAeXGMUapzbdoEqftSmNCOnhl['epgtype']=='spotvon':
     viRgTJAeXGMUapzbdoEqftSmNCOnch=viRgTJAeXGMUapzbdoEqftSmNCOnBx.Get_EpgInfo_Spotv_spotvon(viRgTJAeXGMUapzbdoEqftSmNCOncD,viRgTJAeXGMUapzbdoEqftSmNCOnhl['epgnm'],viRgTJAeXGMUapzbdoEqftSmNCOnhI)
     viRgTJAeXGMUapzbdoEqftSmNCOnhK[viRgTJAeXGMUapzbdoEqftSmNCOncD]=viRgTJAeXGMUapzbdoEqftSmNCOnch
    if viRgTJAeXGMUapzbdoEqftSmNCOnhl['epgtype']=='spotvnet':
     viRgTJAeXGMUapzbdoEqftSmNCOnch=viRgTJAeXGMUapzbdoEqftSmNCOnBx.Get_EpgInfo_Spotv_spotvnet(viRgTJAeXGMUapzbdoEqftSmNCOncD,viRgTJAeXGMUapzbdoEqftSmNCOnhl['epgnm'],viRgTJAeXGMUapzbdoEqftSmNCOnhI)
     viRgTJAeXGMUapzbdoEqftSmNCOnhK[viRgTJAeXGMUapzbdoEqftSmNCOncD]=viRgTJAeXGMUapzbdoEqftSmNCOnch
   for viRgTJAeXGMUapzbdoEqftSmNCOncF in viRgTJAeXGMUapzbdoEqftSmNCOnhK.keys():
    if viRgTJAeXGMUapzbdoEqftSmNCOnWI(viRgTJAeXGMUapzbdoEqftSmNCOnhK.get(viRgTJAeXGMUapzbdoEqftSmNCOncF))==0:continue
    viRgTJAeXGMUapzbdoEqftSmNCOnch =''
    viRgTJAeXGMUapzbdoEqftSmNCOncy=''
    for viRgTJAeXGMUapzbdoEqftSmNCOncH in viRgTJAeXGMUapzbdoEqftSmNCOnhK.get(viRgTJAeXGMUapzbdoEqftSmNCOncF):
     viRgTJAeXGMUapzbdoEqftSmNCOncW =viRgTJAeXGMUapzbdoEqftSmNCOncH['startTime']
     viRgTJAeXGMUapzbdoEqftSmNCOncY =viRgTJAeXGMUapzbdoEqftSmNCOncH['endTime']
     if viRgTJAeXGMUapzbdoEqftSmNCOnWj(viRgTJAeXGMUapzbdoEqftSmNCOnhj)>viRgTJAeXGMUapzbdoEqftSmNCOnWj(viRgTJAeXGMUapzbdoEqftSmNCOncY) :continue
     if viRgTJAeXGMUapzbdoEqftSmNCOnWj(viRgTJAeXGMUapzbdoEqftSmNCOnhr)<viRgTJAeXGMUapzbdoEqftSmNCOnWj(viRgTJAeXGMUapzbdoEqftSmNCOncW):continue
     if viRgTJAeXGMUapzbdoEqftSmNCOnWj(viRgTJAeXGMUapzbdoEqftSmNCOnhj)>=viRgTJAeXGMUapzbdoEqftSmNCOnWj(viRgTJAeXGMUapzbdoEqftSmNCOncW)and viRgTJAeXGMUapzbdoEqftSmNCOnWj(viRgTJAeXGMUapzbdoEqftSmNCOnhj)<viRgTJAeXGMUapzbdoEqftSmNCOnWj(viRgTJAeXGMUapzbdoEqftSmNCOncY):viRgTJAeXGMUapzbdoEqftSmNCOncy=viRgTJAeXGMUapzbdoEqftSmNCOnBx.xmlText(viRgTJAeXGMUapzbdoEqftSmNCOncH['title'])
     if viRgTJAeXGMUapzbdoEqftSmNCOnch:viRgTJAeXGMUapzbdoEqftSmNCOnch+='\n'
     viRgTJAeXGMUapzbdoEqftSmNCOnch+=viRgTJAeXGMUapzbdoEqftSmNCOnBx.xmlText(viRgTJAeXGMUapzbdoEqftSmNCOncH['title'])+'\n'
     viRgTJAeXGMUapzbdoEqftSmNCOnch+=' [%s:%s ~ %s:%s]'%(viRgTJAeXGMUapzbdoEqftSmNCOncH['startTime'][8:10],viRgTJAeXGMUapzbdoEqftSmNCOncH['startTime'][10:12],viRgTJAeXGMUapzbdoEqftSmNCOncH['endTime'][8:10],viRgTJAeXGMUapzbdoEqftSmNCOncH['endTime'][10:12])+'\n'
    viRgTJAeXGMUapzbdoEqftSmNCOnhK[viRgTJAeXGMUapzbdoEqftSmNCOncF]={'epg':viRgTJAeXGMUapzbdoEqftSmNCOnch,'title':viRgTJAeXGMUapzbdoEqftSmNCOncy}
  except viRgTJAeXGMUapzbdoEqftSmNCOnWK as exception:
   viRgTJAeXGMUapzbdoEqftSmNCOnWV(exception)
  return viRgTJAeXGMUapzbdoEqftSmNCOnhK
 def Get_EpgInfo_Spotv_spotvon(viRgTJAeXGMUapzbdoEqftSmNCOnBx,viRgTJAeXGMUapzbdoEqftSmNCOncD,epgnm,now_day):
  viRgTJAeXGMUapzbdoEqftSmNCOnhK =[]
  try:
   viRgTJAeXGMUapzbdoEqftSmNCOnBr='https://www.spotvon.co.kr/data/onAir/%s/Daily/D%s.asp'%(epgnm,now_day)
   viRgTJAeXGMUapzbdoEqftSmNCOnBK=viRgTJAeXGMUapzbdoEqftSmNCOnBx.callRequestCookies('Get',viRgTJAeXGMUapzbdoEqftSmNCOnBr,payload=viRgTJAeXGMUapzbdoEqftSmNCOnWL,params=viRgTJAeXGMUapzbdoEqftSmNCOnWL,headers=viRgTJAeXGMUapzbdoEqftSmNCOnWL,cookies=viRgTJAeXGMUapzbdoEqftSmNCOnWL)
   viRgTJAeXGMUapzbdoEqftSmNCOncs=json.loads(viRgTJAeXGMUapzbdoEqftSmNCOnBK.text)
   for viRgTJAeXGMUapzbdoEqftSmNCOnhl in viRgTJAeXGMUapzbdoEqftSmNCOncs:
    viRgTJAeXGMUapzbdoEqftSmNCOnhu={'title':viRgTJAeXGMUapzbdoEqftSmNCOnhl['title'],'startTime':viRgTJAeXGMUapzbdoEqftSmNCOnhl['sch_date'].replace('-','')+viRgTJAeXGMUapzbdoEqftSmNCOnWk(viRgTJAeXGMUapzbdoEqftSmNCOnhl['sch_hour']).zfill(2)+viRgTJAeXGMUapzbdoEqftSmNCOnhl['sch_min']+'00'}
    viRgTJAeXGMUapzbdoEqftSmNCOnhK.append(viRgTJAeXGMUapzbdoEqftSmNCOnhu)
   for i in viRgTJAeXGMUapzbdoEqftSmNCOnWr(viRgTJAeXGMUapzbdoEqftSmNCOnWI(viRgTJAeXGMUapzbdoEqftSmNCOnhK)):
    if i>0:viRgTJAeXGMUapzbdoEqftSmNCOnhK[i-1]['endTime']=viRgTJAeXGMUapzbdoEqftSmNCOnhK[i]['startTime']
    if i==viRgTJAeXGMUapzbdoEqftSmNCOnWI(viRgTJAeXGMUapzbdoEqftSmNCOnhK)-1: viRgTJAeXGMUapzbdoEqftSmNCOnhK[i]['endTime']=now_day+'240000'
  except viRgTJAeXGMUapzbdoEqftSmNCOnWK as exception:
   viRgTJAeXGMUapzbdoEqftSmNCOnWV(exception)
   return[]
  return viRgTJAeXGMUapzbdoEqftSmNCOnhK
 def Get_EpgInfo_Spotv_spotvnet(viRgTJAeXGMUapzbdoEqftSmNCOnBx,viRgTJAeXGMUapzbdoEqftSmNCOncD,epgnm,now_day):
  viRgTJAeXGMUapzbdoEqftSmNCOnhK =[]
  try:
   viRgTJAeXGMUapzbdoEqftSmNCOnBr='https://www.spotv.net/data/json/schedule/%s/Daily/D%s.json'%(epgnm,now_day)
   viRgTJAeXGMUapzbdoEqftSmNCOnBK=viRgTJAeXGMUapzbdoEqftSmNCOnBx.callRequestCookies('Get',viRgTJAeXGMUapzbdoEqftSmNCOnBr,payload=viRgTJAeXGMUapzbdoEqftSmNCOnWL,params=viRgTJAeXGMUapzbdoEqftSmNCOnWL,headers=viRgTJAeXGMUapzbdoEqftSmNCOnWL,cookies=viRgTJAeXGMUapzbdoEqftSmNCOnWL)
   viRgTJAeXGMUapzbdoEqftSmNCOncs=json.loads(viRgTJAeXGMUapzbdoEqftSmNCOnBK.text)
   for viRgTJAeXGMUapzbdoEqftSmNCOnhl in viRgTJAeXGMUapzbdoEqftSmNCOncs:
    viRgTJAeXGMUapzbdoEqftSmNCOnhu={'title':viRgTJAeXGMUapzbdoEqftSmNCOnhl['title'],'startTime':viRgTJAeXGMUapzbdoEqftSmNCOnhl['sch_date'].replace('-','')+viRgTJAeXGMUapzbdoEqftSmNCOnWk(viRgTJAeXGMUapzbdoEqftSmNCOnhl['sch_hour']).zfill(2)+viRgTJAeXGMUapzbdoEqftSmNCOnhl['sch_min']+'00'}
    viRgTJAeXGMUapzbdoEqftSmNCOnhK.append(viRgTJAeXGMUapzbdoEqftSmNCOnhu)
   for i in viRgTJAeXGMUapzbdoEqftSmNCOnWr(viRgTJAeXGMUapzbdoEqftSmNCOnWI(viRgTJAeXGMUapzbdoEqftSmNCOnhK)):
    if i>0:viRgTJAeXGMUapzbdoEqftSmNCOnhK[i-1]['endTime']=viRgTJAeXGMUapzbdoEqftSmNCOnhK[i]['startTime']
    if i==viRgTJAeXGMUapzbdoEqftSmNCOnWI(viRgTJAeXGMUapzbdoEqftSmNCOnhK)-1: viRgTJAeXGMUapzbdoEqftSmNCOnhK[i]['endTime']=now_day+'240000'
  except viRgTJAeXGMUapzbdoEqftSmNCOnWK as exception:
   viRgTJAeXGMUapzbdoEqftSmNCOnWV(exception)
   return[]
  return viRgTJAeXGMUapzbdoEqftSmNCOnhK
 def GetEventLiveList(viRgTJAeXGMUapzbdoEqftSmNCOnBx):
  viRgTJAeXGMUapzbdoEqftSmNCOnhL=[]
  viRgTJAeXGMUapzbdoEqftSmNCOncQ =0
  try:
   viRgTJAeXGMUapzbdoEqftSmNCOncw=viRgTJAeXGMUapzbdoEqftSmNCOnBx.Get_Now_Datetime()
   viRgTJAeXGMUapzbdoEqftSmNCOncL=viRgTJAeXGMUapzbdoEqftSmNCOncw.strftime('%Y-%m-%d')
  except viRgTJAeXGMUapzbdoEqftSmNCOnWK as exception:
   viRgTJAeXGMUapzbdoEqftSmNCOnWV(exception)
   return viRgTJAeXGMUapzbdoEqftSmNCOnhL,viRgTJAeXGMUapzbdoEqftSmNCOncQ
  try:
   viRgTJAeXGMUapzbdoEqftSmNCOnBr=viRgTJAeXGMUapzbdoEqftSmNCOnBx.API_DOMAIN+'/api/v2/player/lives/'+viRgTJAeXGMUapzbdoEqftSmNCOncL 
   viRgTJAeXGMUapzbdoEqftSmNCOnBQ=viRgTJAeXGMUapzbdoEqftSmNCOnBx.makeDefaultCookies()
   viRgTJAeXGMUapzbdoEqftSmNCOnBK=viRgTJAeXGMUapzbdoEqftSmNCOnBx.callRequestCookies('Get',viRgTJAeXGMUapzbdoEqftSmNCOnBr,payload=viRgTJAeXGMUapzbdoEqftSmNCOnWL,params=viRgTJAeXGMUapzbdoEqftSmNCOnWL,headers=viRgTJAeXGMUapzbdoEqftSmNCOnWL,cookies=viRgTJAeXGMUapzbdoEqftSmNCOnBQ)
   viRgTJAeXGMUapzbdoEqftSmNCOncQ=viRgTJAeXGMUapzbdoEqftSmNCOnBK.status_code 
   viRgTJAeXGMUapzbdoEqftSmNCOnBV=json.loads(viRgTJAeXGMUapzbdoEqftSmNCOnBK.text)
   for viRgTJAeXGMUapzbdoEqftSmNCOncP in viRgTJAeXGMUapzbdoEqftSmNCOnBV:
    for viRgTJAeXGMUapzbdoEqftSmNCOnhl in viRgTJAeXGMUapzbdoEqftSmNCOncP['liveNowList']:
     if viRgTJAeXGMUapzbdoEqftSmNCOnhl['gameDesc']['title']==viRgTJAeXGMUapzbdoEqftSmNCOnWL or viRgTJAeXGMUapzbdoEqftSmNCOnhl['gameDesc']['title']=='':
      viRgTJAeXGMUapzbdoEqftSmNCOncl='%s ( %s : %s )'%(viRgTJAeXGMUapzbdoEqftSmNCOnhl['leagueName'],viRgTJAeXGMUapzbdoEqftSmNCOnhl['homeNameShort'],viRgTJAeXGMUapzbdoEqftSmNCOnhl['awayNameShort'])
     else:
      viRgTJAeXGMUapzbdoEqftSmNCOncl=viRgTJAeXGMUapzbdoEqftSmNCOnhl['gameDesc']['title']
     viRgTJAeXGMUapzbdoEqftSmNCOnhu={'liveId':viRgTJAeXGMUapzbdoEqftSmNCOnhl['liveId'],'title':viRgTJAeXGMUapzbdoEqftSmNCOncl,'logo':viRgTJAeXGMUapzbdoEqftSmNCOnhl['gameDesc']['leagueLogo'],'free':viRgTJAeXGMUapzbdoEqftSmNCOnhl['isFree'],'startTime':viRgTJAeXGMUapzbdoEqftSmNCOnhl['startTime']}
     viRgTJAeXGMUapzbdoEqftSmNCOnhL.append(viRgTJAeXGMUapzbdoEqftSmNCOnhu)
  except viRgTJAeXGMUapzbdoEqftSmNCOnWK as exception:
   viRgTJAeXGMUapzbdoEqftSmNCOnWV(exception)
  return viRgTJAeXGMUapzbdoEqftSmNCOnhL,viRgTJAeXGMUapzbdoEqftSmNCOncQ
 def GetEventLive_videoId(viRgTJAeXGMUapzbdoEqftSmNCOnBx,liveId):
  viRgTJAeXGMUapzbdoEqftSmNCOncu=''
  try:
   viRgTJAeXGMUapzbdoEqftSmNCOnBr=viRgTJAeXGMUapzbdoEqftSmNCOnBx.API_DOMAIN+'/api/v2/live/'+liveId
   viRgTJAeXGMUapzbdoEqftSmNCOnBK=viRgTJAeXGMUapzbdoEqftSmNCOnBx.callRequestCookies('Get',viRgTJAeXGMUapzbdoEqftSmNCOnBr,payload=viRgTJAeXGMUapzbdoEqftSmNCOnWL,params=viRgTJAeXGMUapzbdoEqftSmNCOnWL,headers=viRgTJAeXGMUapzbdoEqftSmNCOnWL,cookies=viRgTJAeXGMUapzbdoEqftSmNCOnWL)
   viRgTJAeXGMUapzbdoEqftSmNCOnBV=json.loads(viRgTJAeXGMUapzbdoEqftSmNCOnBK.text)
   viRgTJAeXGMUapzbdoEqftSmNCOnck=viRgTJAeXGMUapzbdoEqftSmNCOnBV['videoId']
   viRgTJAeXGMUapzbdoEqftSmNCOncu=viRgTJAeXGMUapzbdoEqftSmNCOnck.replace('ref:','')
  except viRgTJAeXGMUapzbdoEqftSmNCOnWK as exception:
   viRgTJAeXGMUapzbdoEqftSmNCOnWV(exception)
  return viRgTJAeXGMUapzbdoEqftSmNCOncu
 def CheckMainEnd(viRgTJAeXGMUapzbdoEqftSmNCOnBx):
  viRgTJAeXGMUapzbdoEqftSmNCOncK=viRgTJAeXGMUapzbdoEqftSmNCOnBx.SPOTV_PMCODE+viRgTJAeXGMUapzbdoEqftSmNCOnBx.ST['cookies']['spotv_sessionid']
  viRgTJAeXGMUapzbdoEqftSmNCOncK=base64.standard_b64encode(viRgTJAeXGMUapzbdoEqftSmNCOncK.encode()).decode('utf-8')
  if viRgTJAeXGMUapzbdoEqftSmNCOncK=='OTg3MTgzMzM0Ng==' or viRgTJAeXGMUapzbdoEqftSmNCOncK=='OTg3MTgzMzExNw==':return viRgTJAeXGMUapzbdoEqftSmNCOnWu
  return viRgTJAeXGMUapzbdoEqftSmNCOnWP
 def CheckSubEnd(viRgTJAeXGMUapzbdoEqftSmNCOnBx):
  viRgTJAeXGMUapzbdoEqftSmNCOnBy=viRgTJAeXGMUapzbdoEqftSmNCOnWP
  try:
   if viRgTJAeXGMUapzbdoEqftSmNCOnBx.CheckMainEnd():return viRgTJAeXGMUapzbdoEqftSmNCOnWu 
   viRgTJAeXGMUapzbdoEqftSmNCOncV=base64.standard_b64decode(viRgTJAeXGMUapzbdoEqftSmNCOnBx.ST['cookies']['spotv_subend']).decode('utf-8')[viRgTJAeXGMUapzbdoEqftSmNCOnBx.SPOTV_PMSIZE:]
   if viRgTJAeXGMUapzbdoEqftSmNCOncV=='0':return viRgTJAeXGMUapzbdoEqftSmNCOnBy
   viRgTJAeXGMUapzbdoEqftSmNCOncj =viRgTJAeXGMUapzbdoEqftSmNCOnWj(viRgTJAeXGMUapzbdoEqftSmNCOnBx.Get_Now_Datetime().strftime('%Y%m%d'))
   viRgTJAeXGMUapzbdoEqftSmNCOncI =viRgTJAeXGMUapzbdoEqftSmNCOnWj(viRgTJAeXGMUapzbdoEqftSmNCOncV)/1000
   viRgTJAeXGMUapzbdoEqftSmNCOncr =viRgTJAeXGMUapzbdoEqftSmNCOnWj(datetime.datetime.fromtimestamp(viRgTJAeXGMUapzbdoEqftSmNCOncI,datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul')).strftime('%Y%m%d'))
   if viRgTJAeXGMUapzbdoEqftSmNCOncj<=viRgTJAeXGMUapzbdoEqftSmNCOncr:viRgTJAeXGMUapzbdoEqftSmNCOnBy=viRgTJAeXGMUapzbdoEqftSmNCOnWu
  except viRgTJAeXGMUapzbdoEqftSmNCOnWK as exception:
   viRgTJAeXGMUapzbdoEqftSmNCOnWV(exception)
   return viRgTJAeXGMUapzbdoEqftSmNCOnBy
  return viRgTJAeXGMUapzbdoEqftSmNCOnBy
 def GetBroadURL(viRgTJAeXGMUapzbdoEqftSmNCOnBx,viRgTJAeXGMUapzbdoEqftSmNCOncu,mediatype,viRgTJAeXGMUapzbdoEqftSmNCOnxs):
  viRgTJAeXGMUapzbdoEqftSmNCOnxB=''
  try:
   if mediatype=='live':
    viRgTJAeXGMUapzbdoEqftSmNCOnBr=viRgTJAeXGMUapzbdoEqftSmNCOnBx.API_DOMAIN+'/api/v2/live/'+viRgTJAeXGMUapzbdoEqftSmNCOncu
   else:
    viRgTJAeXGMUapzbdoEqftSmNCOncu=viRgTJAeXGMUapzbdoEqftSmNCOnBx.GetReplay_UrlId(viRgTJAeXGMUapzbdoEqftSmNCOncu,viRgTJAeXGMUapzbdoEqftSmNCOnxs)
    if viRgTJAeXGMUapzbdoEqftSmNCOncu=='':return viRgTJAeXGMUapzbdoEqftSmNCOnxB
    viRgTJAeXGMUapzbdoEqftSmNCOnBr=viRgTJAeXGMUapzbdoEqftSmNCOnBx.PLAYER_DOMAIN+'/playback/v1/accounts/'+viRgTJAeXGMUapzbdoEqftSmNCOnBx.ST['cookies']['spotv_accountId']+'/videos/'+viRgTJAeXGMUapzbdoEqftSmNCOncu
   viRgTJAeXGMUapzbdoEqftSmNCOnBw=viRgTJAeXGMUapzbdoEqftSmNCOnBx.makeDefaultHeaders()
   viRgTJAeXGMUapzbdoEqftSmNCOnBK=viRgTJAeXGMUapzbdoEqftSmNCOnBx.callRequestCookies('Get',viRgTJAeXGMUapzbdoEqftSmNCOnBr,payload=viRgTJAeXGMUapzbdoEqftSmNCOnWL,params=viRgTJAeXGMUapzbdoEqftSmNCOnWL,headers=viRgTJAeXGMUapzbdoEqftSmNCOnBw,cookies=viRgTJAeXGMUapzbdoEqftSmNCOnWL)
   viRgTJAeXGMUapzbdoEqftSmNCOncs=json.loads(viRgTJAeXGMUapzbdoEqftSmNCOnBK.text)
   if mediatype=='live':
    viRgTJAeXGMUapzbdoEqftSmNCOnxB=viRgTJAeXGMUapzbdoEqftSmNCOncs['hlsUrl2']or viRgTJAeXGMUapzbdoEqftSmNCOncs['hlsUrl']
   else:
    viRgTJAeXGMUapzbdoEqftSmNCOnxB=viRgTJAeXGMUapzbdoEqftSmNCOncs['sources'][0]['src']
   viRgTJAeXGMUapzbdoEqftSmNCOnxB=viRgTJAeXGMUapzbdoEqftSmNCOnxB.replace('http://','https://')
  except viRgTJAeXGMUapzbdoEqftSmNCOnWK as exception:
   viRgTJAeXGMUapzbdoEqftSmNCOnWV(exception)
  return viRgTJAeXGMUapzbdoEqftSmNCOnxB
 def GetTitleGroupList(viRgTJAeXGMUapzbdoEqftSmNCOnBx):
  viRgTJAeXGMUapzbdoEqftSmNCOnhL=[]
  viRgTJAeXGMUapzbdoEqftSmNCOnxh=viRgTJAeXGMUapzbdoEqftSmNCOnWP
  try:
   viRgTJAeXGMUapzbdoEqftSmNCOnBr=viRgTJAeXGMUapzbdoEqftSmNCOnBx.API_DOMAIN+'/api/v2/home/web'
   viRgTJAeXGMUapzbdoEqftSmNCOnBK=viRgTJAeXGMUapzbdoEqftSmNCOnBx.callRequestCookies('Get',viRgTJAeXGMUapzbdoEqftSmNCOnBr,payload=viRgTJAeXGMUapzbdoEqftSmNCOnWL,params=viRgTJAeXGMUapzbdoEqftSmNCOnWL,headers=viRgTJAeXGMUapzbdoEqftSmNCOnWL,cookies=viRgTJAeXGMUapzbdoEqftSmNCOnWL)
   viRgTJAeXGMUapzbdoEqftSmNCOnBV=json.loads(viRgTJAeXGMUapzbdoEqftSmNCOnBK.text)
   for viRgTJAeXGMUapzbdoEqftSmNCOnhl in viRgTJAeXGMUapzbdoEqftSmNCOnBV:
    if viRgTJAeXGMUapzbdoEqftSmNCOnWk(viRgTJAeXGMUapzbdoEqftSmNCOnhl['type'])=='3':
     viRgTJAeXGMUapzbdoEqftSmNCOnxc=''
     for viRgTJAeXGMUapzbdoEqftSmNCOnxW in viRgTJAeXGMUapzbdoEqftSmNCOnhl['data']['list']:
      viRgTJAeXGMUapzbdoEqftSmNCOnxY='[%s] %s vs %s\n<%s>\n\n'%(viRgTJAeXGMUapzbdoEqftSmNCOnxW['gameDesc']['roundName'],viRgTJAeXGMUapzbdoEqftSmNCOnxW['gameDesc']['homeNameShort'],viRgTJAeXGMUapzbdoEqftSmNCOnxW['gameDesc']['awayNameShort'],viRgTJAeXGMUapzbdoEqftSmNCOnxW['gameDesc']['beginDate'])
      viRgTJAeXGMUapzbdoEqftSmNCOnxc+=viRgTJAeXGMUapzbdoEqftSmNCOnxY
     viRgTJAeXGMUapzbdoEqftSmNCOnhu={'title':viRgTJAeXGMUapzbdoEqftSmNCOnhl['title'],'logo':viRgTJAeXGMUapzbdoEqftSmNCOnhl['logo'],'reagueId':viRgTJAeXGMUapzbdoEqftSmNCOnWk(viRgTJAeXGMUapzbdoEqftSmNCOnhl['destId']),'subGame':viRgTJAeXGMUapzbdoEqftSmNCOnxc}
     viRgTJAeXGMUapzbdoEqftSmNCOnhL.append(viRgTJAeXGMUapzbdoEqftSmNCOnhu)
     if viRgTJAeXGMUapzbdoEqftSmNCOnWk(viRgTJAeXGMUapzbdoEqftSmNCOnhl['destId'])=='13':viRgTJAeXGMUapzbdoEqftSmNCOnxh=viRgTJAeXGMUapzbdoEqftSmNCOnWu
   if viRgTJAeXGMUapzbdoEqftSmNCOnxh==viRgTJAeXGMUapzbdoEqftSmNCOnWP:
    viRgTJAeXGMUapzbdoEqftSmNCOnhu={'title':'UFC','logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200928/a643c7cf1c285fb0b4469c07d4c09c28.png','reagueId':'13','subGame':''}
    viRgTJAeXGMUapzbdoEqftSmNCOnhL.append(viRgTJAeXGMUapzbdoEqftSmNCOnhu)
  except viRgTJAeXGMUapzbdoEqftSmNCOnWK as exception:
   viRgTJAeXGMUapzbdoEqftSmNCOnWV(exception)
  return viRgTJAeXGMUapzbdoEqftSmNCOnhL
 def GetPopularGroupList(viRgTJAeXGMUapzbdoEqftSmNCOnBx):
  viRgTJAeXGMUapzbdoEqftSmNCOnhL=[]
  try:
   viRgTJAeXGMUapzbdoEqftSmNCOnBr=viRgTJAeXGMUapzbdoEqftSmNCOnBx.API_DOMAIN+'/api/v2/home/web'
   viRgTJAeXGMUapzbdoEqftSmNCOnBK=viRgTJAeXGMUapzbdoEqftSmNCOnBx.callRequestCookies('Get',viRgTJAeXGMUapzbdoEqftSmNCOnBr,payload=viRgTJAeXGMUapzbdoEqftSmNCOnWL,params=viRgTJAeXGMUapzbdoEqftSmNCOnWL,headers=viRgTJAeXGMUapzbdoEqftSmNCOnWL,cookies=viRgTJAeXGMUapzbdoEqftSmNCOnWL)
   viRgTJAeXGMUapzbdoEqftSmNCOnBV=json.loads(viRgTJAeXGMUapzbdoEqftSmNCOnBK.text)
   for viRgTJAeXGMUapzbdoEqftSmNCOnhl in viRgTJAeXGMUapzbdoEqftSmNCOnBV:
    if viRgTJAeXGMUapzbdoEqftSmNCOnWk(viRgTJAeXGMUapzbdoEqftSmNCOnhl['type'])=='1' and viRgTJAeXGMUapzbdoEqftSmNCOnWk(viRgTJAeXGMUapzbdoEqftSmNCOnhl['destId'])=='4':
     for viRgTJAeXGMUapzbdoEqftSmNCOnxW in viRgTJAeXGMUapzbdoEqftSmNCOnhl['data']['list']:
      viRgTJAeXGMUapzbdoEqftSmNCOnxD =viRgTJAeXGMUapzbdoEqftSmNCOnxW['title']
      viRgTJAeXGMUapzbdoEqftSmNCOnxF =viRgTJAeXGMUapzbdoEqftSmNCOnxW['id']
      viRgTJAeXGMUapzbdoEqftSmNCOnxy =viRgTJAeXGMUapzbdoEqftSmNCOnxW['vtype']
      viRgTJAeXGMUapzbdoEqftSmNCOnxH =viRgTJAeXGMUapzbdoEqftSmNCOnxW['imgUrl']
      viRgTJAeXGMUapzbdoEqftSmNCOnxs =viRgTJAeXGMUapzbdoEqftSmNCOnxW['vtypeId']
      viRgTJAeXGMUapzbdoEqftSmNCOnhu={'vodTitle':viRgTJAeXGMUapzbdoEqftSmNCOnxD,'vodId':viRgTJAeXGMUapzbdoEqftSmNCOnxF,'vodType':viRgTJAeXGMUapzbdoEqftSmNCOnxy,'thumbnail':viRgTJAeXGMUapzbdoEqftSmNCOnxH,'vtypeId':viRgTJAeXGMUapzbdoEqftSmNCOnWk(viRgTJAeXGMUapzbdoEqftSmNCOnxs),'duration':viRgTJAeXGMUapzbdoEqftSmNCOnWj(viRgTJAeXGMUapzbdoEqftSmNCOnxW['duration']/1000)}
      viRgTJAeXGMUapzbdoEqftSmNCOnhL.append(viRgTJAeXGMUapzbdoEqftSmNCOnhu)
  except viRgTJAeXGMUapzbdoEqftSmNCOnWK as exception:
   viRgTJAeXGMUapzbdoEqftSmNCOnWV(exception)
  return viRgTJAeXGMUapzbdoEqftSmNCOnhL
 def Get_NowVod_GroupList(viRgTJAeXGMUapzbdoEqftSmNCOnBx,page_int):
  viRgTJAeXGMUapzbdoEqftSmNCOnhL=[]
  viRgTJAeXGMUapzbdoEqftSmNCOnxQ=viRgTJAeXGMUapzbdoEqftSmNCOnWP
  try:
   viRgTJAeXGMUapzbdoEqftSmNCOnBr=viRgTJAeXGMUapzbdoEqftSmNCOnBx.API_DOMAIN+'/api/v2/theme/14/list'
   viRgTJAeXGMUapzbdoEqftSmNCOnxw={'pageItem':'10','pageNo':viRgTJAeXGMUapzbdoEqftSmNCOnWk(page_int)}
   viRgTJAeXGMUapzbdoEqftSmNCOnBK=viRgTJAeXGMUapzbdoEqftSmNCOnBx.callRequestCookies('Get',viRgTJAeXGMUapzbdoEqftSmNCOnBr,payload=viRgTJAeXGMUapzbdoEqftSmNCOnWL,params=viRgTJAeXGMUapzbdoEqftSmNCOnxw,headers=viRgTJAeXGMUapzbdoEqftSmNCOnWL,cookies=viRgTJAeXGMUapzbdoEqftSmNCOnWL)
   viRgTJAeXGMUapzbdoEqftSmNCOnBV=json.loads(viRgTJAeXGMUapzbdoEqftSmNCOnBK.text)
   for viRgTJAeXGMUapzbdoEqftSmNCOnhl in viRgTJAeXGMUapzbdoEqftSmNCOnBV['list']:
    viRgTJAeXGMUapzbdoEqftSmNCOnxD =viRgTJAeXGMUapzbdoEqftSmNCOnhl['title']
    viRgTJAeXGMUapzbdoEqftSmNCOnxF =viRgTJAeXGMUapzbdoEqftSmNCOnhl['id']
    viRgTJAeXGMUapzbdoEqftSmNCOnxy =viRgTJAeXGMUapzbdoEqftSmNCOnhl['vtype']
    viRgTJAeXGMUapzbdoEqftSmNCOnxH =viRgTJAeXGMUapzbdoEqftSmNCOnhl['imgUrl']
    viRgTJAeXGMUapzbdoEqftSmNCOnxs =viRgTJAeXGMUapzbdoEqftSmNCOnhl['vtypeId']
    viRgTJAeXGMUapzbdoEqftSmNCOnhu={'vodTitle':viRgTJAeXGMUapzbdoEqftSmNCOnxD,'vodId':viRgTJAeXGMUapzbdoEqftSmNCOnxF,'vodType':viRgTJAeXGMUapzbdoEqftSmNCOnxy,'thumbnail':viRgTJAeXGMUapzbdoEqftSmNCOnxH,'vtypeId':viRgTJAeXGMUapzbdoEqftSmNCOnWk(viRgTJAeXGMUapzbdoEqftSmNCOnxs),'duration':viRgTJAeXGMUapzbdoEqftSmNCOnWj(viRgTJAeXGMUapzbdoEqftSmNCOnhl['duration']/1000),}
    viRgTJAeXGMUapzbdoEqftSmNCOnhL.append(viRgTJAeXGMUapzbdoEqftSmNCOnhu)
    if viRgTJAeXGMUapzbdoEqftSmNCOnBV['count']>page_int*viRgTJAeXGMUapzbdoEqftSmNCOnBx.GAMELIST_LIMIT:viRgTJAeXGMUapzbdoEqftSmNCOnxQ=viRgTJAeXGMUapzbdoEqftSmNCOnWu
  except viRgTJAeXGMUapzbdoEqftSmNCOnWK as exception:
   viRgTJAeXGMUapzbdoEqftSmNCOnWV(exception)
  return viRgTJAeXGMUapzbdoEqftSmNCOnhL,viRgTJAeXGMUapzbdoEqftSmNCOnxQ
 def GetSeasonList(viRgTJAeXGMUapzbdoEqftSmNCOnBx,leagueId):
  viRgTJAeXGMUapzbdoEqftSmNCOnhL=[]
  viRgTJAeXGMUapzbdoEqftSmNCOnxL=viRgTJAeXGMUapzbdoEqftSmNCOnxP=''
  try:
   viRgTJAeXGMUapzbdoEqftSmNCOnBr=viRgTJAeXGMUapzbdoEqftSmNCOnBx.API_DOMAIN+'/api/v2/game/league/'+leagueId
   viRgTJAeXGMUapzbdoEqftSmNCOnBK=viRgTJAeXGMUapzbdoEqftSmNCOnBx.callRequestCookies('Get',viRgTJAeXGMUapzbdoEqftSmNCOnBr,payload=viRgTJAeXGMUapzbdoEqftSmNCOnWL,params=viRgTJAeXGMUapzbdoEqftSmNCOnWL,headers=viRgTJAeXGMUapzbdoEqftSmNCOnWL,cookies=viRgTJAeXGMUapzbdoEqftSmNCOnWL)
   viRgTJAeXGMUapzbdoEqftSmNCOnBV=json.loads(viRgTJAeXGMUapzbdoEqftSmNCOnBK.text)
   viRgTJAeXGMUapzbdoEqftSmNCOnxL=viRgTJAeXGMUapzbdoEqftSmNCOnBV['name']
   viRgTJAeXGMUapzbdoEqftSmNCOnxP=viRgTJAeXGMUapzbdoEqftSmNCOnWk(viRgTJAeXGMUapzbdoEqftSmNCOnBV['gameTypeId'])
  except viRgTJAeXGMUapzbdoEqftSmNCOnWK as exception:
   viRgTJAeXGMUapzbdoEqftSmNCOnWV(exception)
   return viRgTJAeXGMUapzbdoEqftSmNCOnhL
  if viRgTJAeXGMUapzbdoEqftSmNCOnxP=='2':
   try:
    viRgTJAeXGMUapzbdoEqftSmNCOnBr=viRgTJAeXGMUapzbdoEqftSmNCOnBx.API_DOMAIN+'/api/v2/year/'+leagueId
    viRgTJAeXGMUapzbdoEqftSmNCOnBK=viRgTJAeXGMUapzbdoEqftSmNCOnBx.callRequestCookies('Get',viRgTJAeXGMUapzbdoEqftSmNCOnBr,payload=viRgTJAeXGMUapzbdoEqftSmNCOnWL,params=viRgTJAeXGMUapzbdoEqftSmNCOnWL,headers=viRgTJAeXGMUapzbdoEqftSmNCOnWL,cookies=viRgTJAeXGMUapzbdoEqftSmNCOnWL)
    viRgTJAeXGMUapzbdoEqftSmNCOnBV=json.loads(viRgTJAeXGMUapzbdoEqftSmNCOnBK.text)
    for viRgTJAeXGMUapzbdoEqftSmNCOnhl in viRgTJAeXGMUapzbdoEqftSmNCOnBV:
     viRgTJAeXGMUapzbdoEqftSmNCOnhu={'reagueName':viRgTJAeXGMUapzbdoEqftSmNCOnxL,'gameTypeId':viRgTJAeXGMUapzbdoEqftSmNCOnxP,'seasonName':viRgTJAeXGMUapzbdoEqftSmNCOnWk(viRgTJAeXGMUapzbdoEqftSmNCOnhl),'seasonId':viRgTJAeXGMUapzbdoEqftSmNCOnWk(viRgTJAeXGMUapzbdoEqftSmNCOnhl)}
     viRgTJAeXGMUapzbdoEqftSmNCOnhL.append(viRgTJAeXGMUapzbdoEqftSmNCOnhu)
   except viRgTJAeXGMUapzbdoEqftSmNCOnWK as exception:
    viRgTJAeXGMUapzbdoEqftSmNCOnWV(exception)
    return[]
  else:
   try:
    viRgTJAeXGMUapzbdoEqftSmNCOnBr=viRgTJAeXGMUapzbdoEqftSmNCOnBx.API_DOMAIN+'/api/v2/season/'+leagueId
    viRgTJAeXGMUapzbdoEqftSmNCOnBK=viRgTJAeXGMUapzbdoEqftSmNCOnBx.callRequestCookies('Get',viRgTJAeXGMUapzbdoEqftSmNCOnBr,payload=viRgTJAeXGMUapzbdoEqftSmNCOnWL,params=viRgTJAeXGMUapzbdoEqftSmNCOnWL,headers=viRgTJAeXGMUapzbdoEqftSmNCOnWL,cookies=viRgTJAeXGMUapzbdoEqftSmNCOnWL)
    viRgTJAeXGMUapzbdoEqftSmNCOnBV=json.loads(viRgTJAeXGMUapzbdoEqftSmNCOnBK.text)
    for viRgTJAeXGMUapzbdoEqftSmNCOnhl in viRgTJAeXGMUapzbdoEqftSmNCOnBV:
     viRgTJAeXGMUapzbdoEqftSmNCOnhu={'reagueName':viRgTJAeXGMUapzbdoEqftSmNCOnxL,'gameTypeId':viRgTJAeXGMUapzbdoEqftSmNCOnxP,'seasonName':viRgTJAeXGMUapzbdoEqftSmNCOnhl['name'],'seasonId':viRgTJAeXGMUapzbdoEqftSmNCOnWk(viRgTJAeXGMUapzbdoEqftSmNCOnhl['id'])}
     viRgTJAeXGMUapzbdoEqftSmNCOnhL.append(viRgTJAeXGMUapzbdoEqftSmNCOnhu)
   except viRgTJAeXGMUapzbdoEqftSmNCOnWK as exception:
    viRgTJAeXGMUapzbdoEqftSmNCOnWV(exception)
    return[]
  return viRgTJAeXGMUapzbdoEqftSmNCOnhL
 def GetGameList(viRgTJAeXGMUapzbdoEqftSmNCOnBx,viRgTJAeXGMUapzbdoEqftSmNCOnxP,leagueId,seasonId,page_int,hidescore=viRgTJAeXGMUapzbdoEqftSmNCOnWu):
  viRgTJAeXGMUapzbdoEqftSmNCOnhL=[]
  viRgTJAeXGMUapzbdoEqftSmNCOnxQ=viRgTJAeXGMUapzbdoEqftSmNCOnWP
  try:
   viRgTJAeXGMUapzbdoEqftSmNCOnBr=viRgTJAeXGMUapzbdoEqftSmNCOnBx.API_DOMAIN+'/api/v2/vod/league/detail'
   viRgTJAeXGMUapzbdoEqftSmNCOnxw={'gameType':viRgTJAeXGMUapzbdoEqftSmNCOnxP,'leagueId':leagueId,'seasonId':seasonId if viRgTJAeXGMUapzbdoEqftSmNCOnxP!='2' else '','teamId':'','roundId':'','year':'' if viRgTJAeXGMUapzbdoEqftSmNCOnxP!='2' else seasonId,'pageNo':viRgTJAeXGMUapzbdoEqftSmNCOnWk(page_int)}
   viRgTJAeXGMUapzbdoEqftSmNCOnBK=viRgTJAeXGMUapzbdoEqftSmNCOnBx.callRequestCookies('Get',viRgTJAeXGMUapzbdoEqftSmNCOnBr,payload=viRgTJAeXGMUapzbdoEqftSmNCOnWL,params=viRgTJAeXGMUapzbdoEqftSmNCOnxw,headers=viRgTJAeXGMUapzbdoEqftSmNCOnWL,cookies=viRgTJAeXGMUapzbdoEqftSmNCOnWL)
   viRgTJAeXGMUapzbdoEqftSmNCOnBV=json.loads(viRgTJAeXGMUapzbdoEqftSmNCOnBK.text)
   viRgTJAeXGMUapzbdoEqftSmNCOncP=viRgTJAeXGMUapzbdoEqftSmNCOnBV['list']
   for viRgTJAeXGMUapzbdoEqftSmNCOnxl in viRgTJAeXGMUapzbdoEqftSmNCOncP:
    for viRgTJAeXGMUapzbdoEqftSmNCOnhl in viRgTJAeXGMUapzbdoEqftSmNCOnxl['list']:
     if viRgTJAeXGMUapzbdoEqftSmNCOnhl['gameDesc']['title']==viRgTJAeXGMUapzbdoEqftSmNCOnWL or viRgTJAeXGMUapzbdoEqftSmNCOnhl['gameDesc']['title']=='':
      viRgTJAeXGMUapzbdoEqftSmNCOncl ='%s vs %s'%(viRgTJAeXGMUapzbdoEqftSmNCOnhl['gameDesc']['homeNameShort'],viRgTJAeXGMUapzbdoEqftSmNCOnhl['gameDesc']['awayNameShort'])
     else:
      viRgTJAeXGMUapzbdoEqftSmNCOncl =viRgTJAeXGMUapzbdoEqftSmNCOnhl['gameDesc']['title']
     viRgTJAeXGMUapzbdoEqftSmNCOnxu =viRgTJAeXGMUapzbdoEqftSmNCOnhl['gameDesc']['beginDate']
     viRgTJAeXGMUapzbdoEqftSmNCOnxk =viRgTJAeXGMUapzbdoEqftSmNCOnhl['gameDesc']['id']
     viRgTJAeXGMUapzbdoEqftSmNCOnxK =viRgTJAeXGMUapzbdoEqftSmNCOnhl['gameDesc']['leagueNameFull']
     viRgTJAeXGMUapzbdoEqftSmNCOnxV =viRgTJAeXGMUapzbdoEqftSmNCOnhl['gameDesc']['seasonName']
     viRgTJAeXGMUapzbdoEqftSmNCOnxj =viRgTJAeXGMUapzbdoEqftSmNCOnhl['gameDesc']['roundName']
     viRgTJAeXGMUapzbdoEqftSmNCOnxI =viRgTJAeXGMUapzbdoEqftSmNCOnhl['gameDesc']['homeName']
     viRgTJAeXGMUapzbdoEqftSmNCOnxr =viRgTJAeXGMUapzbdoEqftSmNCOnhl['gameDesc']['awayName']
     viRgTJAeXGMUapzbdoEqftSmNCOnWB =viRgTJAeXGMUapzbdoEqftSmNCOnhl['gameDesc']['homeScore']
     viRgTJAeXGMUapzbdoEqftSmNCOnWh =viRgTJAeXGMUapzbdoEqftSmNCOnhl['gameDesc']['awayScore']
     if hidescore==viRgTJAeXGMUapzbdoEqftSmNCOnWu:
      viRgTJAeXGMUapzbdoEqftSmNCOnWc ='%s\n - %s (%s)\n - %s\n\nhome : %s\n\naway : %s'%(viRgTJAeXGMUapzbdoEqftSmNCOnxK,viRgTJAeXGMUapzbdoEqftSmNCOnxV,viRgTJAeXGMUapzbdoEqftSmNCOnxj,viRgTJAeXGMUapzbdoEqftSmNCOnxu,viRgTJAeXGMUapzbdoEqftSmNCOnxI,viRgTJAeXGMUapzbdoEqftSmNCOnxr)
     else:
      viRgTJAeXGMUapzbdoEqftSmNCOnWc ='%s\n - %s (%s)\n - %s\n\nhome : %s (Score %s)\n\naway : %s (Score %s)'%(viRgTJAeXGMUapzbdoEqftSmNCOnxK,viRgTJAeXGMUapzbdoEqftSmNCOnxV,viRgTJAeXGMUapzbdoEqftSmNCOnxj,viRgTJAeXGMUapzbdoEqftSmNCOnxu,viRgTJAeXGMUapzbdoEqftSmNCOnxI,viRgTJAeXGMUapzbdoEqftSmNCOnWB,viRgTJAeXGMUapzbdoEqftSmNCOnxr,viRgTJAeXGMUapzbdoEqftSmNCOnWh)
     viRgTJAeXGMUapzbdoEqftSmNCOnWx=viRgTJAeXGMUapzbdoEqftSmNCOnWc
     viRgTJAeXGMUapzbdoEqftSmNCOnWY =viRgTJAeXGMUapzbdoEqftSmNCOnhl['replayVod']['count']
     viRgTJAeXGMUapzbdoEqftSmNCOnWD=viRgTJAeXGMUapzbdoEqftSmNCOnhl['highlightVod']['count']
     viRgTJAeXGMUapzbdoEqftSmNCOnWF =viRgTJAeXGMUapzbdoEqftSmNCOnhl['vods']['count']
     viRgTJAeXGMUapzbdoEqftSmNCOnxH='' 
     viRgTJAeXGMUapzbdoEqftSmNCOnWy=viRgTJAeXGMUapzbdoEqftSmNCOnWY+viRgTJAeXGMUapzbdoEqftSmNCOnWD+viRgTJAeXGMUapzbdoEqftSmNCOnWF
     if viRgTJAeXGMUapzbdoEqftSmNCOnWy==0:
      if viRgTJAeXGMUapzbdoEqftSmNCOnxP=='2':
       viRgTJAeXGMUapzbdoEqftSmNCOncl='----- %s -----'%(viRgTJAeXGMUapzbdoEqftSmNCOnxV)
       viRgTJAeXGMUapzbdoEqftSmNCOnxu=''
      else:
       viRgTJAeXGMUapzbdoEqftSmNCOncl+=' - 관련영상 없음'
       viRgTJAeXGMUapzbdoEqftSmNCOnWx+='\n\n ** 관련영상 없음 **'
     else:
      if viRgTJAeXGMUapzbdoEqftSmNCOnWY!=0:
       viRgTJAeXGMUapzbdoEqftSmNCOnxH =viRgTJAeXGMUapzbdoEqftSmNCOnhl['replayVod']['list'][0]['imgUrl']
      elif viRgTJAeXGMUapzbdoEqftSmNCOnWD!=0:
       viRgTJAeXGMUapzbdoEqftSmNCOnxH =viRgTJAeXGMUapzbdoEqftSmNCOnhl['highlightVod']['list'][0]['imgUrl']
      else:
       viRgTJAeXGMUapzbdoEqftSmNCOnxH =viRgTJAeXGMUapzbdoEqftSmNCOnhl['vods']['list'][0]['imgUrl']
     viRgTJAeXGMUapzbdoEqftSmNCOnhu={'gameTitle':viRgTJAeXGMUapzbdoEqftSmNCOncl,'gameId':viRgTJAeXGMUapzbdoEqftSmNCOnxk,'beginDate':viRgTJAeXGMUapzbdoEqftSmNCOnxu[:11],'thumbnail':viRgTJAeXGMUapzbdoEqftSmNCOnxH,'info_plot':viRgTJAeXGMUapzbdoEqftSmNCOnWx,'leaguenm':viRgTJAeXGMUapzbdoEqftSmNCOnxK,'seasonnm':viRgTJAeXGMUapzbdoEqftSmNCOnxV,'roundnm':viRgTJAeXGMUapzbdoEqftSmNCOnxj,'totVodCnt':viRgTJAeXGMUapzbdoEqftSmNCOnWy}
     viRgTJAeXGMUapzbdoEqftSmNCOnhL.append(viRgTJAeXGMUapzbdoEqftSmNCOnhu)
  except viRgTJAeXGMUapzbdoEqftSmNCOnWK as exception:
   viRgTJAeXGMUapzbdoEqftSmNCOnWV(exception)
  if viRgTJAeXGMUapzbdoEqftSmNCOnBV['count']>page_int*viRgTJAeXGMUapzbdoEqftSmNCOnBx.GAMELIST_LIMIT:viRgTJAeXGMUapzbdoEqftSmNCOnxQ=viRgTJAeXGMUapzbdoEqftSmNCOnWu
  return viRgTJAeXGMUapzbdoEqftSmNCOnhL,viRgTJAeXGMUapzbdoEqftSmNCOnxQ
 def GetGameVodList(viRgTJAeXGMUapzbdoEqftSmNCOnBx,viRgTJAeXGMUapzbdoEqftSmNCOnxk,vodCount=1000):
  viRgTJAeXGMUapzbdoEqftSmNCOnhL=[]
  viRgTJAeXGMUapzbdoEqftSmNCOnWH=''
  try:
   viRgTJAeXGMUapzbdoEqftSmNCOnBr=viRgTJAeXGMUapzbdoEqftSmNCOnBx.API_DOMAIN+'/api/v2/vod/game'
   viRgTJAeXGMUapzbdoEqftSmNCOnxw={'gameId':viRgTJAeXGMUapzbdoEqftSmNCOnxk,'pageItem':viRgTJAeXGMUapzbdoEqftSmNCOnWk(vodCount)}
   viRgTJAeXGMUapzbdoEqftSmNCOnBK=viRgTJAeXGMUapzbdoEqftSmNCOnBx.callRequestCookies('Get',viRgTJAeXGMUapzbdoEqftSmNCOnBr,payload=viRgTJAeXGMUapzbdoEqftSmNCOnWL,params=viRgTJAeXGMUapzbdoEqftSmNCOnxw,headers=viRgTJAeXGMUapzbdoEqftSmNCOnWL,cookies=viRgTJAeXGMUapzbdoEqftSmNCOnWL)
   viRgTJAeXGMUapzbdoEqftSmNCOnBV=json.loads(viRgTJAeXGMUapzbdoEqftSmNCOnBK.text)
   viRgTJAeXGMUapzbdoEqftSmNCOnxl=viRgTJAeXGMUapzbdoEqftSmNCOnBV['list']
   for viRgTJAeXGMUapzbdoEqftSmNCOnhl in viRgTJAeXGMUapzbdoEqftSmNCOnxl:
    viRgTJAeXGMUapzbdoEqftSmNCOnxD =viRgTJAeXGMUapzbdoEqftSmNCOnhl['title']
    viRgTJAeXGMUapzbdoEqftSmNCOnxF =viRgTJAeXGMUapzbdoEqftSmNCOnhl['id']
    viRgTJAeXGMUapzbdoEqftSmNCOnxy =viRgTJAeXGMUapzbdoEqftSmNCOnhl['vtype']
    viRgTJAeXGMUapzbdoEqftSmNCOnxH =viRgTJAeXGMUapzbdoEqftSmNCOnhl['imgUrl']
    viRgTJAeXGMUapzbdoEqftSmNCOnxs =viRgTJAeXGMUapzbdoEqftSmNCOnhl['vtypeId']
    viRgTJAeXGMUapzbdoEqftSmNCOnWs =viRgTJAeXGMUapzbdoEqftSmNCOnhl['isFree']
    viRgTJAeXGMUapzbdoEqftSmNCOnhu={'vodTitle':viRgTJAeXGMUapzbdoEqftSmNCOnxD,'vodId':viRgTJAeXGMUapzbdoEqftSmNCOnxF,'vodType':viRgTJAeXGMUapzbdoEqftSmNCOnxy,'thumbnail':viRgTJAeXGMUapzbdoEqftSmNCOnxH,'vtypeId':viRgTJAeXGMUapzbdoEqftSmNCOnWk(viRgTJAeXGMUapzbdoEqftSmNCOnxs),'duration':viRgTJAeXGMUapzbdoEqftSmNCOnWj(viRgTJAeXGMUapzbdoEqftSmNCOnhl['duration']/1000),'isFree':viRgTJAeXGMUapzbdoEqftSmNCOnWs}
    viRgTJAeXGMUapzbdoEqftSmNCOnhL.append(viRgTJAeXGMUapzbdoEqftSmNCOnhu)
  except viRgTJAeXGMUapzbdoEqftSmNCOnWK as exception:
   viRgTJAeXGMUapzbdoEqftSmNCOnWV(exception)
  return viRgTJAeXGMUapzbdoEqftSmNCOnhL
 def GetReplay_UrlId(viRgTJAeXGMUapzbdoEqftSmNCOnBx,viRgTJAeXGMUapzbdoEqftSmNCOnWH,viRgTJAeXGMUapzbdoEqftSmNCOnxs):
  viRgTJAeXGMUapzbdoEqftSmNCOnWQ=''
  try:
   viRgTJAeXGMUapzbdoEqftSmNCOnBr=viRgTJAeXGMUapzbdoEqftSmNCOnBx.API_DOMAIN+'/api/v2/vod/'+viRgTJAeXGMUapzbdoEqftSmNCOnWH
   viRgTJAeXGMUapzbdoEqftSmNCOnBK=viRgTJAeXGMUapzbdoEqftSmNCOnBx.callRequestCookies('Get',viRgTJAeXGMUapzbdoEqftSmNCOnBr,payload=viRgTJAeXGMUapzbdoEqftSmNCOnWL,params=viRgTJAeXGMUapzbdoEqftSmNCOnWL,headers=viRgTJAeXGMUapzbdoEqftSmNCOnWL,cookies=viRgTJAeXGMUapzbdoEqftSmNCOnWL)
   viRgTJAeXGMUapzbdoEqftSmNCOnBV=json.loads(viRgTJAeXGMUapzbdoEqftSmNCOnBK.text)
   viRgTJAeXGMUapzbdoEqftSmNCOnWQ=viRgTJAeXGMUapzbdoEqftSmNCOnBV['videoId']
  except viRgTJAeXGMUapzbdoEqftSmNCOnWK as exception:
   viRgTJAeXGMUapzbdoEqftSmNCOnWV(exception)
  return viRgTJAeXGMUapzbdoEqftSmNCOnWQ
# Created by pyminifier (https://github.com/liftoff/pyminifier)
