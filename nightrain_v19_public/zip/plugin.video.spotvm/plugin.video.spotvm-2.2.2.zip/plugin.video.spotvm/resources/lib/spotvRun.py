__author__="NightRain"
ebqDEihJlxAtLgVBSzvdsUQCORjMrk=object
ebqDEihJlxAtLgVBSzvdsUQCORjMrN=None
ebqDEihJlxAtLgVBSzvdsUQCORjMrG=False
ebqDEihJlxAtLgVBSzvdsUQCORjMru=True
ebqDEihJlxAtLgVBSzvdsUQCORjMrT=int
ebqDEihJlxAtLgVBSzvdsUQCORjMrf=len
ebqDEihJlxAtLgVBSzvdsUQCORjMrW=str
ebqDEihJlxAtLgVBSzvdsUQCORjMyn=id
ebqDEihJlxAtLgVBSzvdsUQCORjMyK=open
ebqDEihJlxAtLgVBSzvdsUQCORjMyP=dict
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
ebqDEihJlxAtLgVBSzvdsUQCORjMnP=[{'title':'TV 채널 (유료사용자만 지원)','mode':'LIVE_GROUP','icon':'live.png'},{'title':'Live중계 (경기중에만 재생)','mode':'ELIVE_GROUP','icon':'live.png'},{'title':'-----------------','mode':'XXX'},{'title':'오늘의 추천 VOD','mode':'NOW_GROUP'},{'title':'인기영상 5','mode':'POP_GROUP'},{'title':'-----------------','mode':'XXX'},{'title':'VOD (리그, 경기별)','mode':'VOD_GROUP'},{'title':'Watched (시청목록)','mode':'WATCH','icon':'history.png'},]
ebqDEihJlxAtLgVBSzvdsUQCORjMnc=xbmcvfs.translatePath(os.path.join(__profile__,'spotv_cookies.json'))
from spotvCore import*
class ebqDEihJlxAtLgVBSzvdsUQCORjMnK(ebqDEihJlxAtLgVBSzvdsUQCORjMrk):
 def __init__(ebqDEihJlxAtLgVBSzvdsUQCORjMnr,ebqDEihJlxAtLgVBSzvdsUQCORjMny,ebqDEihJlxAtLgVBSzvdsUQCORjMnH,ebqDEihJlxAtLgVBSzvdsUQCORjMno):
  ebqDEihJlxAtLgVBSzvdsUQCORjMnr._addon_url =ebqDEihJlxAtLgVBSzvdsUQCORjMny
  ebqDEihJlxAtLgVBSzvdsUQCORjMnr._addon_handle=ebqDEihJlxAtLgVBSzvdsUQCORjMnH
  ebqDEihJlxAtLgVBSzvdsUQCORjMnr.main_params =ebqDEihJlxAtLgVBSzvdsUQCORjMno
  ebqDEihJlxAtLgVBSzvdsUQCORjMnr.SpotvObj =viRgTJAeXGMUapzbdoEqftSmNCOnBh() 
 def addon_noti(ebqDEihJlxAtLgVBSzvdsUQCORjMnr,sting):
  try:
   ebqDEihJlxAtLgVBSzvdsUQCORjMnp=xbmcgui.Dialog()
   ebqDEihJlxAtLgVBSzvdsUQCORjMnp.notification(__addonname__,sting)
  except:
   ebqDEihJlxAtLgVBSzvdsUQCORjMrN
 def addon_log(ebqDEihJlxAtLgVBSzvdsUQCORjMnr,string):
  try:
   ebqDEihJlxAtLgVBSzvdsUQCORjMnI=string.encode('utf-8','ignore')
  except:
   ebqDEihJlxAtLgVBSzvdsUQCORjMnI='addonException: addon_log'
  ebqDEihJlxAtLgVBSzvdsUQCORjMnm=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,ebqDEihJlxAtLgVBSzvdsUQCORjMnI),level=ebqDEihJlxAtLgVBSzvdsUQCORjMnm)
 def get_keyboard_input(ebqDEihJlxAtLgVBSzvdsUQCORjMnr,ebqDEihJlxAtLgVBSzvdsUQCORjMnN):
  ebqDEihJlxAtLgVBSzvdsUQCORjMnX=ebqDEihJlxAtLgVBSzvdsUQCORjMrN
  kb=xbmc.Keyboard()
  kb.setHeading(ebqDEihJlxAtLgVBSzvdsUQCORjMnN)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   ebqDEihJlxAtLgVBSzvdsUQCORjMnX=kb.getText()
  return ebqDEihJlxAtLgVBSzvdsUQCORjMnX
 def get_settings_account(ebqDEihJlxAtLgVBSzvdsUQCORjMnr):
  ebqDEihJlxAtLgVBSzvdsUQCORjMnw =__addon__.getSetting('id')
  ebqDEihJlxAtLgVBSzvdsUQCORjMnY =__addon__.getSetting('pw')
  return(ebqDEihJlxAtLgVBSzvdsUQCORjMnw,ebqDEihJlxAtLgVBSzvdsUQCORjMnY)
 def get_settings_hidescoreyn(ebqDEihJlxAtLgVBSzvdsUQCORjMnr):
  ebqDEihJlxAtLgVBSzvdsUQCORjMnF =__addon__.getSetting('hidescore')
  if ebqDEihJlxAtLgVBSzvdsUQCORjMnF=='false':
   return ebqDEihJlxAtLgVBSzvdsUQCORjMrG
  else:
   return ebqDEihJlxAtLgVBSzvdsUQCORjMru
 def add_dir(ebqDEihJlxAtLgVBSzvdsUQCORjMnr,label,sublabel='',img='',infoLabels=ebqDEihJlxAtLgVBSzvdsUQCORjMrN,isFolder=ebqDEihJlxAtLgVBSzvdsUQCORjMru,params='',isLink=ebqDEihJlxAtLgVBSzvdsUQCORjMrG,ContextMenu=ebqDEihJlxAtLgVBSzvdsUQCORjMrN):
  ebqDEihJlxAtLgVBSzvdsUQCORjMnk='%s?%s'%(ebqDEihJlxAtLgVBSzvdsUQCORjMnr._addon_url,urllib.parse.urlencode(params))
  if sublabel:ebqDEihJlxAtLgVBSzvdsUQCORjMnN='%s < %s >'%(label,sublabel)
  else: ebqDEihJlxAtLgVBSzvdsUQCORjMnN=label
  if not img:img='DefaultFolder.png'
  ebqDEihJlxAtLgVBSzvdsUQCORjMnG=xbmcgui.ListItem(ebqDEihJlxAtLgVBSzvdsUQCORjMnN)
  ebqDEihJlxAtLgVBSzvdsUQCORjMnG.setArt({'thumb':img,'icon':img,'poster':img})
  if infoLabels:ebqDEihJlxAtLgVBSzvdsUQCORjMnG.setInfo(type="Video",infoLabels=infoLabels)
  if not isFolder and not isLink:
   ebqDEihJlxAtLgVBSzvdsUQCORjMnG.setProperty('IsPlayable','true')
  if ContextMenu:ebqDEihJlxAtLgVBSzvdsUQCORjMnG.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(ebqDEihJlxAtLgVBSzvdsUQCORjMnr._addon_handle,ebqDEihJlxAtLgVBSzvdsUQCORjMnk,ebqDEihJlxAtLgVBSzvdsUQCORjMnG,isFolder)
 def get_selQuality(ebqDEihJlxAtLgVBSzvdsUQCORjMnr,etype):
  try:
   ebqDEihJlxAtLgVBSzvdsUQCORjMnu='selected_quality'
   ebqDEihJlxAtLgVBSzvdsUQCORjMnT=[1080,720,540]
   ebqDEihJlxAtLgVBSzvdsUQCORjMnf=ebqDEihJlxAtLgVBSzvdsUQCORjMrT(__addon__.getSetting(ebqDEihJlxAtLgVBSzvdsUQCORjMnu))
   return ebqDEihJlxAtLgVBSzvdsUQCORjMnT[ebqDEihJlxAtLgVBSzvdsUQCORjMnf]
  except:
   ebqDEihJlxAtLgVBSzvdsUQCORjMrN
  return 1080 
 def dp_Main_List(ebqDEihJlxAtLgVBSzvdsUQCORjMnr):
  for ebqDEihJlxAtLgVBSzvdsUQCORjMnW in ebqDEihJlxAtLgVBSzvdsUQCORjMnP:
   ebqDEihJlxAtLgVBSzvdsUQCORjMnN=ebqDEihJlxAtLgVBSzvdsUQCORjMnW.get('title')
   ebqDEihJlxAtLgVBSzvdsUQCORjMKn=''
   ebqDEihJlxAtLgVBSzvdsUQCORjMKP={'mode':ebqDEihJlxAtLgVBSzvdsUQCORjMnW.get('mode'),'page':'1'}
   if ebqDEihJlxAtLgVBSzvdsUQCORjMnW.get('mode')=='XXX':
    ebqDEihJlxAtLgVBSzvdsUQCORjMKc=ebqDEihJlxAtLgVBSzvdsUQCORjMrG
    ebqDEihJlxAtLgVBSzvdsUQCORjMKr =ebqDEihJlxAtLgVBSzvdsUQCORjMru
   else:
    ebqDEihJlxAtLgVBSzvdsUQCORjMKc=ebqDEihJlxAtLgVBSzvdsUQCORjMru
    ebqDEihJlxAtLgVBSzvdsUQCORjMKr =ebqDEihJlxAtLgVBSzvdsUQCORjMrG
   if 'icon' in ebqDEihJlxAtLgVBSzvdsUQCORjMnW:ebqDEihJlxAtLgVBSzvdsUQCORjMKn=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',ebqDEihJlxAtLgVBSzvdsUQCORjMnW.get('icon')) 
   ebqDEihJlxAtLgVBSzvdsUQCORjMnr.add_dir(ebqDEihJlxAtLgVBSzvdsUQCORjMnN,sublabel='',img=ebqDEihJlxAtLgVBSzvdsUQCORjMKn,infoLabels=ebqDEihJlxAtLgVBSzvdsUQCORjMrN,isFolder=ebqDEihJlxAtLgVBSzvdsUQCORjMKc,params=ebqDEihJlxAtLgVBSzvdsUQCORjMKP,isLink=ebqDEihJlxAtLgVBSzvdsUQCORjMKr)
  if ebqDEihJlxAtLgVBSzvdsUQCORjMrf(ebqDEihJlxAtLgVBSzvdsUQCORjMnP)>0:xbmcplugin.endOfDirectory(ebqDEihJlxAtLgVBSzvdsUQCORjMnr._addon_handle)
 def dp_MainLeague_List(ebqDEihJlxAtLgVBSzvdsUQCORjMnr,args):
  ebqDEihJlxAtLgVBSzvdsUQCORjMKH=ebqDEihJlxAtLgVBSzvdsUQCORjMnr.SpotvObj.GetTitleGroupList()
  for ebqDEihJlxAtLgVBSzvdsUQCORjMKo in ebqDEihJlxAtLgVBSzvdsUQCORjMKH:
   ebqDEihJlxAtLgVBSzvdsUQCORjMnN =ebqDEihJlxAtLgVBSzvdsUQCORjMKo.get('title')
   ebqDEihJlxAtLgVBSzvdsUQCORjMKa =ebqDEihJlxAtLgVBSzvdsUQCORjMKo.get('logo')
   ebqDEihJlxAtLgVBSzvdsUQCORjMKp =ebqDEihJlxAtLgVBSzvdsUQCORjMKo.get('reagueId')
   ebqDEihJlxAtLgVBSzvdsUQCORjMKI =ebqDEihJlxAtLgVBSzvdsUQCORjMKo.get('subGame')
   ebqDEihJlxAtLgVBSzvdsUQCORjMKm={'mediatype':'episode','plot':'%s\n\n%s'%(ebqDEihJlxAtLgVBSzvdsUQCORjMnN,ebqDEihJlxAtLgVBSzvdsUQCORjMKI)}
   ebqDEihJlxAtLgVBSzvdsUQCORjMKP={'mode':'LEAGUE_GROUP','reagueId':ebqDEihJlxAtLgVBSzvdsUQCORjMKp}
   ebqDEihJlxAtLgVBSzvdsUQCORjMnr.add_dir(ebqDEihJlxAtLgVBSzvdsUQCORjMnN,sublabel=ebqDEihJlxAtLgVBSzvdsUQCORjMrN,img=ebqDEihJlxAtLgVBSzvdsUQCORjMKa,infoLabels=ebqDEihJlxAtLgVBSzvdsUQCORjMKm,isFolder=ebqDEihJlxAtLgVBSzvdsUQCORjMru,params=ebqDEihJlxAtLgVBSzvdsUQCORjMKP)
  if ebqDEihJlxAtLgVBSzvdsUQCORjMrf(ebqDEihJlxAtLgVBSzvdsUQCORjMKH)>0:xbmcplugin.endOfDirectory(ebqDEihJlxAtLgVBSzvdsUQCORjMnr._addon_handle,cacheToDisc=ebqDEihJlxAtLgVBSzvdsUQCORjMrG)
 def dp_NowVod_GroupList(ebqDEihJlxAtLgVBSzvdsUQCORjMnr,args):
  ebqDEihJlxAtLgVBSzvdsUQCORjMKX=ebqDEihJlxAtLgVBSzvdsUQCORjMrT(args.get('page'))
  ebqDEihJlxAtLgVBSzvdsUQCORjMKH,ebqDEihJlxAtLgVBSzvdsUQCORjMKw=ebqDEihJlxAtLgVBSzvdsUQCORjMnr.SpotvObj.Get_NowVod_GroupList(ebqDEihJlxAtLgVBSzvdsUQCORjMKX)
  for ebqDEihJlxAtLgVBSzvdsUQCORjMKo in ebqDEihJlxAtLgVBSzvdsUQCORjMKH:
   ebqDEihJlxAtLgVBSzvdsUQCORjMKY =ebqDEihJlxAtLgVBSzvdsUQCORjMKo.get('vodTitle')
   ebqDEihJlxAtLgVBSzvdsUQCORjMKF =ebqDEihJlxAtLgVBSzvdsUQCORjMKo.get('vodId')
   ebqDEihJlxAtLgVBSzvdsUQCORjMKk =ebqDEihJlxAtLgVBSzvdsUQCORjMKo.get('vodType')
   ebqDEihJlxAtLgVBSzvdsUQCORjMKa=ebqDEihJlxAtLgVBSzvdsUQCORjMKo.get('thumbnail')
   ebqDEihJlxAtLgVBSzvdsUQCORjMKN =ebqDEihJlxAtLgVBSzvdsUQCORjMKo.get('vtypeId')
   ebqDEihJlxAtLgVBSzvdsUQCORjMKG =ebqDEihJlxAtLgVBSzvdsUQCORjMKo.get('duration')
   ebqDEihJlxAtLgVBSzvdsUQCORjMKm={'mediatype':'episode','duration':ebqDEihJlxAtLgVBSzvdsUQCORjMKG,'plot':ebqDEihJlxAtLgVBSzvdsUQCORjMKY}
   ebqDEihJlxAtLgVBSzvdsUQCORjMKP={'mode':'NOW_VOD','mediacode':ebqDEihJlxAtLgVBSzvdsUQCORjMKF,'mediatype':'vod','vtypeId':ebqDEihJlxAtLgVBSzvdsUQCORjMKN}
   ebqDEihJlxAtLgVBSzvdsUQCORjMnr.add_dir(ebqDEihJlxAtLgVBSzvdsUQCORjMKY,sublabel=ebqDEihJlxAtLgVBSzvdsUQCORjMKk,img=ebqDEihJlxAtLgVBSzvdsUQCORjMKa,infoLabels=ebqDEihJlxAtLgVBSzvdsUQCORjMKm,isFolder=ebqDEihJlxAtLgVBSzvdsUQCORjMrG,params=ebqDEihJlxAtLgVBSzvdsUQCORjMKP)
  if ebqDEihJlxAtLgVBSzvdsUQCORjMKw:
   ebqDEihJlxAtLgVBSzvdsUQCORjMKP['mode'] ='NOW_GROUP' 
   ebqDEihJlxAtLgVBSzvdsUQCORjMKP['page'] =ebqDEihJlxAtLgVBSzvdsUQCORjMrW(ebqDEihJlxAtLgVBSzvdsUQCORjMKX+1)
   ebqDEihJlxAtLgVBSzvdsUQCORjMnN='[B]%s >>[/B]'%'다음 페이지'
   ebqDEihJlxAtLgVBSzvdsUQCORjMKu=ebqDEihJlxAtLgVBSzvdsUQCORjMrW(ebqDEihJlxAtLgVBSzvdsUQCORjMKX+1)
   ebqDEihJlxAtLgVBSzvdsUQCORjMKn=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   ebqDEihJlxAtLgVBSzvdsUQCORjMnr.add_dir(ebqDEihJlxAtLgVBSzvdsUQCORjMnN,sublabel=ebqDEihJlxAtLgVBSzvdsUQCORjMKu,img=ebqDEihJlxAtLgVBSzvdsUQCORjMKn,infoLabels=ebqDEihJlxAtLgVBSzvdsUQCORjMrN,isFolder=ebqDEihJlxAtLgVBSzvdsUQCORjMru,params=ebqDEihJlxAtLgVBSzvdsUQCORjMKP)
  xbmcplugin.setContent(ebqDEihJlxAtLgVBSzvdsUQCORjMnr._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(ebqDEihJlxAtLgVBSzvdsUQCORjMnr._addon_handle,cacheToDisc=ebqDEihJlxAtLgVBSzvdsUQCORjMrG)
 def dp_PopVod_GroupList(ebqDEihJlxAtLgVBSzvdsUQCORjMnr,args):
  ebqDEihJlxAtLgVBSzvdsUQCORjMKH=ebqDEihJlxAtLgVBSzvdsUQCORjMnr.SpotvObj.GetPopularGroupList()
  for ebqDEihJlxAtLgVBSzvdsUQCORjMKo in ebqDEihJlxAtLgVBSzvdsUQCORjMKH:
   ebqDEihJlxAtLgVBSzvdsUQCORjMKY =ebqDEihJlxAtLgVBSzvdsUQCORjMKo.get('vodTitle')
   ebqDEihJlxAtLgVBSzvdsUQCORjMKF =ebqDEihJlxAtLgVBSzvdsUQCORjMKo.get('vodId')
   ebqDEihJlxAtLgVBSzvdsUQCORjMKk =ebqDEihJlxAtLgVBSzvdsUQCORjMKo.get('vodType')
   ebqDEihJlxAtLgVBSzvdsUQCORjMKa=ebqDEihJlxAtLgVBSzvdsUQCORjMKo.get('thumbnail')
   ebqDEihJlxAtLgVBSzvdsUQCORjMKN =ebqDEihJlxAtLgVBSzvdsUQCORjMKo.get('vtypeId')
   ebqDEihJlxAtLgVBSzvdsUQCORjMKG =ebqDEihJlxAtLgVBSzvdsUQCORjMKo.get('duration')
   ebqDEihJlxAtLgVBSzvdsUQCORjMKm={'mediatype':'episode','duration':ebqDEihJlxAtLgVBSzvdsUQCORjMKG,'plot':ebqDEihJlxAtLgVBSzvdsUQCORjMKY}
   ebqDEihJlxAtLgVBSzvdsUQCORjMKP={'mode':'POP_VOD','mediacode':ebqDEihJlxAtLgVBSzvdsUQCORjMKF,'mediatype':'vod','vtypeId':ebqDEihJlxAtLgVBSzvdsUQCORjMKN}
   ebqDEihJlxAtLgVBSzvdsUQCORjMnr.add_dir(ebqDEihJlxAtLgVBSzvdsUQCORjMKY,sublabel=ebqDEihJlxAtLgVBSzvdsUQCORjMKk,img=ebqDEihJlxAtLgVBSzvdsUQCORjMKa,infoLabels=ebqDEihJlxAtLgVBSzvdsUQCORjMKm,isFolder=ebqDEihJlxAtLgVBSzvdsUQCORjMrG,params=ebqDEihJlxAtLgVBSzvdsUQCORjMKP)
  xbmcplugin.setContent(ebqDEihJlxAtLgVBSzvdsUQCORjMnr._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(ebqDEihJlxAtLgVBSzvdsUQCORjMnr._addon_handle,cacheToDisc=ebqDEihJlxAtLgVBSzvdsUQCORjMrG)
 def dp_Season_List(ebqDEihJlxAtLgVBSzvdsUQCORjMnr,args):
  ebqDEihJlxAtLgVBSzvdsUQCORjMKp=args.get('reagueId')
  ebqDEihJlxAtLgVBSzvdsUQCORjMKH=ebqDEihJlxAtLgVBSzvdsUQCORjMnr.SpotvObj.GetSeasonList(ebqDEihJlxAtLgVBSzvdsUQCORjMKp)
  for ebqDEihJlxAtLgVBSzvdsUQCORjMKo in ebqDEihJlxAtLgVBSzvdsUQCORjMKH:
   ebqDEihJlxAtLgVBSzvdsUQCORjMKf =ebqDEihJlxAtLgVBSzvdsUQCORjMKo.get('reagueName')
   ebqDEihJlxAtLgVBSzvdsUQCORjMKW =ebqDEihJlxAtLgVBSzvdsUQCORjMKo.get('gameTypeId')
   ebqDEihJlxAtLgVBSzvdsUQCORjMPn =ebqDEihJlxAtLgVBSzvdsUQCORjMKo.get('seasonName')
   ebqDEihJlxAtLgVBSzvdsUQCORjMPK =ebqDEihJlxAtLgVBSzvdsUQCORjMKo.get('seasonId')
   ebqDEihJlxAtLgVBSzvdsUQCORjMKm={'mediatype':'episode','plot':'%s - %s'%(ebqDEihJlxAtLgVBSzvdsUQCORjMKf,ebqDEihJlxAtLgVBSzvdsUQCORjMPn)}
   ebqDEihJlxAtLgVBSzvdsUQCORjMKP={'mode':'SEASON_GROUP','reagueId':ebqDEihJlxAtLgVBSzvdsUQCORjMKp,'seasonId':ebqDEihJlxAtLgVBSzvdsUQCORjMPK,'gameTypeId':ebqDEihJlxAtLgVBSzvdsUQCORjMKW,'page':'1'}
   ebqDEihJlxAtLgVBSzvdsUQCORjMnr.add_dir(ebqDEihJlxAtLgVBSzvdsUQCORjMKf,sublabel=ebqDEihJlxAtLgVBSzvdsUQCORjMPn,img='',infoLabels=ebqDEihJlxAtLgVBSzvdsUQCORjMKm,isFolder=ebqDEihJlxAtLgVBSzvdsUQCORjMru,params=ebqDEihJlxAtLgVBSzvdsUQCORjMKP)
  if ebqDEihJlxAtLgVBSzvdsUQCORjMrf(ebqDEihJlxAtLgVBSzvdsUQCORjMKH)>0:xbmcplugin.endOfDirectory(ebqDEihJlxAtLgVBSzvdsUQCORjMnr._addon_handle,cacheToDisc=ebqDEihJlxAtLgVBSzvdsUQCORjMru)
 def dp_Game_List(ebqDEihJlxAtLgVBSzvdsUQCORjMnr,args):
  ebqDEihJlxAtLgVBSzvdsUQCORjMKW=args.get('gameTypeId')
  ebqDEihJlxAtLgVBSzvdsUQCORjMKp =args.get('reagueId')
  ebqDEihJlxAtLgVBSzvdsUQCORjMPK =args.get('seasonId')
  ebqDEihJlxAtLgVBSzvdsUQCORjMKX =ebqDEihJlxAtLgVBSzvdsUQCORjMrT(args.get('page'))
  ebqDEihJlxAtLgVBSzvdsUQCORjMKH,ebqDEihJlxAtLgVBSzvdsUQCORjMKw=ebqDEihJlxAtLgVBSzvdsUQCORjMnr.SpotvObj.GetGameList(ebqDEihJlxAtLgVBSzvdsUQCORjMKW,ebqDEihJlxAtLgVBSzvdsUQCORjMKp,ebqDEihJlxAtLgVBSzvdsUQCORjMPK,ebqDEihJlxAtLgVBSzvdsUQCORjMKX,hidescore=ebqDEihJlxAtLgVBSzvdsUQCORjMnr.get_settings_hidescoreyn())
  for ebqDEihJlxAtLgVBSzvdsUQCORjMKo in ebqDEihJlxAtLgVBSzvdsUQCORjMKH:
   ebqDEihJlxAtLgVBSzvdsUQCORjMPc =ebqDEihJlxAtLgVBSzvdsUQCORjMKo.get('gameTitle')
   ebqDEihJlxAtLgVBSzvdsUQCORjMPr =ebqDEihJlxAtLgVBSzvdsUQCORjMKo.get('beginDate')
   ebqDEihJlxAtLgVBSzvdsUQCORjMKa =ebqDEihJlxAtLgVBSzvdsUQCORjMKo.get('thumbnail')
   ebqDEihJlxAtLgVBSzvdsUQCORjMPy =ebqDEihJlxAtLgVBSzvdsUQCORjMKo.get('gameId')
   ebqDEihJlxAtLgVBSzvdsUQCORjMPH =ebqDEihJlxAtLgVBSzvdsUQCORjMKo.get('totVodCnt')
   ebqDEihJlxAtLgVBSzvdsUQCORjMPo =ebqDEihJlxAtLgVBSzvdsUQCORjMKo.get('leaguenm')
   ebqDEihJlxAtLgVBSzvdsUQCORjMPa =ebqDEihJlxAtLgVBSzvdsUQCORjMKo.get('seasonnm')
   ebqDEihJlxAtLgVBSzvdsUQCORjMPp =ebqDEihJlxAtLgVBSzvdsUQCORjMKo.get('roundnm')
   ebqDEihJlxAtLgVBSzvdsUQCORjMPI =ebqDEihJlxAtLgVBSzvdsUQCORjMKo.get('info_plot')
   ebqDEihJlxAtLgVBSzvdsUQCORjMPm ='%s < %s >'%(ebqDEihJlxAtLgVBSzvdsUQCORjMPc,ebqDEihJlxAtLgVBSzvdsUQCORjMPr)
   ebqDEihJlxAtLgVBSzvdsUQCORjMKm={'mediatype':'video','plot':ebqDEihJlxAtLgVBSzvdsUQCORjMPI}
   ebqDEihJlxAtLgVBSzvdsUQCORjMKP={'mode':'GAME_VOD_GROUP' if ebqDEihJlxAtLgVBSzvdsUQCORjMPH!=0 else 'XXX','saveTitle':ebqDEihJlxAtLgVBSzvdsUQCORjMPm,'saveImg':ebqDEihJlxAtLgVBSzvdsUQCORjMKa,'saveInfo':ebqDEihJlxAtLgVBSzvdsUQCORjMKm['plot'],'gameid':ebqDEihJlxAtLgVBSzvdsUQCORjMPy,'totVodCnt':ebqDEihJlxAtLgVBSzvdsUQCORjMPH,}
   ebqDEihJlxAtLgVBSzvdsUQCORjMnr.add_dir(ebqDEihJlxAtLgVBSzvdsUQCORjMPc,sublabel=ebqDEihJlxAtLgVBSzvdsUQCORjMPr,img=ebqDEihJlxAtLgVBSzvdsUQCORjMKa,infoLabels=ebqDEihJlxAtLgVBSzvdsUQCORjMKm,isFolder=ebqDEihJlxAtLgVBSzvdsUQCORjMru,params=ebqDEihJlxAtLgVBSzvdsUQCORjMKP)
  if ebqDEihJlxAtLgVBSzvdsUQCORjMKw:
   ebqDEihJlxAtLgVBSzvdsUQCORjMKP['mode'] ='SEASON_GROUP' 
   ebqDEihJlxAtLgVBSzvdsUQCORjMKP['reagueId'] =ebqDEihJlxAtLgVBSzvdsUQCORjMKp
   ebqDEihJlxAtLgVBSzvdsUQCORjMKP['seasonId'] =ebqDEihJlxAtLgVBSzvdsUQCORjMPK
   ebqDEihJlxAtLgVBSzvdsUQCORjMKP['gameTypeId']=ebqDEihJlxAtLgVBSzvdsUQCORjMKW
   ebqDEihJlxAtLgVBSzvdsUQCORjMKP['page'] =ebqDEihJlxAtLgVBSzvdsUQCORjMrW(ebqDEihJlxAtLgVBSzvdsUQCORjMKX+1)
   ebqDEihJlxAtLgVBSzvdsUQCORjMnN='[B]%s >>[/B]'%'다음 페이지'
   ebqDEihJlxAtLgVBSzvdsUQCORjMKu=ebqDEihJlxAtLgVBSzvdsUQCORjMrW(ebqDEihJlxAtLgVBSzvdsUQCORjMKX+1)
   ebqDEihJlxAtLgVBSzvdsUQCORjMKn=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   ebqDEihJlxAtLgVBSzvdsUQCORjMnr.add_dir(ebqDEihJlxAtLgVBSzvdsUQCORjMnN,sublabel=ebqDEihJlxAtLgVBSzvdsUQCORjMKu,img=ebqDEihJlxAtLgVBSzvdsUQCORjMKn,infoLabels=ebqDEihJlxAtLgVBSzvdsUQCORjMrN,isFolder=ebqDEihJlxAtLgVBSzvdsUQCORjMru,params=ebqDEihJlxAtLgVBSzvdsUQCORjMKP)
  if ebqDEihJlxAtLgVBSzvdsUQCORjMrf(ebqDEihJlxAtLgVBSzvdsUQCORjMKH)>0:xbmcplugin.endOfDirectory(ebqDEihJlxAtLgVBSzvdsUQCORjMnr._addon_handle,cacheToDisc=ebqDEihJlxAtLgVBSzvdsUQCORjMrG)
 def dp_GameVod_List(ebqDEihJlxAtLgVBSzvdsUQCORjMnr,args):
  ebqDEihJlxAtLgVBSzvdsUQCORjMPX =args.get('gameid')
  ebqDEihJlxAtLgVBSzvdsUQCORjMPm=args.get('saveTitle')
  ebqDEihJlxAtLgVBSzvdsUQCORjMPw =args.get('saveImg')
  ebqDEihJlxAtLgVBSzvdsUQCORjMPY =args.get('saveInfo')
  ebqDEihJlxAtLgVBSzvdsUQCORjMKH=ebqDEihJlxAtLgVBSzvdsUQCORjMnr.SpotvObj.GetGameVodList(ebqDEihJlxAtLgVBSzvdsUQCORjMPX)
  for ebqDEihJlxAtLgVBSzvdsUQCORjMKo in ebqDEihJlxAtLgVBSzvdsUQCORjMKH:
   ebqDEihJlxAtLgVBSzvdsUQCORjMKY =ebqDEihJlxAtLgVBSzvdsUQCORjMKo.get('vodTitle')
   ebqDEihJlxAtLgVBSzvdsUQCORjMKF =ebqDEihJlxAtLgVBSzvdsUQCORjMKo.get('vodId')
   ebqDEihJlxAtLgVBSzvdsUQCORjMKk =ebqDEihJlxAtLgVBSzvdsUQCORjMKo.get('vodType')
   ebqDEihJlxAtLgVBSzvdsUQCORjMKa=ebqDEihJlxAtLgVBSzvdsUQCORjMKo.get('thumbnail')
   ebqDEihJlxAtLgVBSzvdsUQCORjMKN =ebqDEihJlxAtLgVBSzvdsUQCORjMKo.get('vtypeId')
   ebqDEihJlxAtLgVBSzvdsUQCORjMKG =ebqDEihJlxAtLgVBSzvdsUQCORjMKo.get('duration')
   ebqDEihJlxAtLgVBSzvdsUQCORjMKm={'mediatype':'episode','duration':ebqDEihJlxAtLgVBSzvdsUQCORjMKG,'plot':'%s \n\n %s'%(ebqDEihJlxAtLgVBSzvdsUQCORjMKY,ebqDEihJlxAtLgVBSzvdsUQCORjMPY)}
   ebqDEihJlxAtLgVBSzvdsUQCORjMKP={'mode':'GAME_VOD','saveTitle':ebqDEihJlxAtLgVBSzvdsUQCORjMPm,'saveImg':ebqDEihJlxAtLgVBSzvdsUQCORjMPw,'saveId':ebqDEihJlxAtLgVBSzvdsUQCORjMPX,'saveInfo':ebqDEihJlxAtLgVBSzvdsUQCORjMPY,'mediacode':ebqDEihJlxAtLgVBSzvdsUQCORjMKF,'mediatype':'vod','vtypeId':ebqDEihJlxAtLgVBSzvdsUQCORjMKN}
   ebqDEihJlxAtLgVBSzvdsUQCORjMnr.add_dir(ebqDEihJlxAtLgVBSzvdsUQCORjMKY,sublabel=ebqDEihJlxAtLgVBSzvdsUQCORjMKk,img=ebqDEihJlxAtLgVBSzvdsUQCORjMKa,infoLabels=ebqDEihJlxAtLgVBSzvdsUQCORjMKm,isFolder=ebqDEihJlxAtLgVBSzvdsUQCORjMrG,params=ebqDEihJlxAtLgVBSzvdsUQCORjMKP)
  xbmcplugin.setContent(ebqDEihJlxAtLgVBSzvdsUQCORjMnr._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(ebqDEihJlxAtLgVBSzvdsUQCORjMnr._addon_handle,cacheToDisc=ebqDEihJlxAtLgVBSzvdsUQCORjMrG)
 def login_main(ebqDEihJlxAtLgVBSzvdsUQCORjMnr):
  (ebqDEihJlxAtLgVBSzvdsUQCORjMPF,ebqDEihJlxAtLgVBSzvdsUQCORjMPk)=ebqDEihJlxAtLgVBSzvdsUQCORjMnr.get_settings_account()
  if not(ebqDEihJlxAtLgVBSzvdsUQCORjMPF and ebqDEihJlxAtLgVBSzvdsUQCORjMPk):
   ebqDEihJlxAtLgVBSzvdsUQCORjMnp=xbmcgui.Dialog()
   ebqDEihJlxAtLgVBSzvdsUQCORjMPN=ebqDEihJlxAtLgVBSzvdsUQCORjMnp.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if ebqDEihJlxAtLgVBSzvdsUQCORjMPN==ebqDEihJlxAtLgVBSzvdsUQCORjMru:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if ebqDEihJlxAtLgVBSzvdsUQCORjMnr.cookiefile_check():return
  if xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINWAIT')=='TRUE':
   ebqDEihJlxAtLgVBSzvdsUQCORjMPG=0
   while ebqDEihJlxAtLgVBSzvdsUQCORjMru:
    ebqDEihJlxAtLgVBSzvdsUQCORjMPG+=1
    time.sleep(0.05)
    if ebqDEihJlxAtLgVBSzvdsUQCORjMPG>600:return
  else:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','TRUE')
  ebqDEihJlxAtLgVBSzvdsUQCORjMPu=ebqDEihJlxAtLgVBSzvdsUQCORjMnr.SpotvObj.GetCredential(ebqDEihJlxAtLgVBSzvdsUQCORjMPF,ebqDEihJlxAtLgVBSzvdsUQCORjMPk)
  if ebqDEihJlxAtLgVBSzvdsUQCORjMPu:ebqDEihJlxAtLgVBSzvdsUQCORjMnr.cookiefile_save()
  xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
  if ebqDEihJlxAtLgVBSzvdsUQCORjMPu==ebqDEihJlxAtLgVBSzvdsUQCORjMrG:
   ebqDEihJlxAtLgVBSzvdsUQCORjMnr.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_LiveChannel_List(ebqDEihJlxAtLgVBSzvdsUQCORjMnr,args):
  ebqDEihJlxAtLgVBSzvdsUQCORjMPT=ebqDEihJlxAtLgVBSzvdsUQCORjMnr.SpotvObj.GetLiveChannelList()
  for ebqDEihJlxAtLgVBSzvdsUQCORjMPf in ebqDEihJlxAtLgVBSzvdsUQCORjMPT:
   ebqDEihJlxAtLgVBSzvdsUQCORjMyn =ebqDEihJlxAtLgVBSzvdsUQCORjMPf.get('id')
   ebqDEihJlxAtLgVBSzvdsUQCORjMnN =ebqDEihJlxAtLgVBSzvdsUQCORjMPf.get('name')
   ebqDEihJlxAtLgVBSzvdsUQCORjMKy =ebqDEihJlxAtLgVBSzvdsUQCORjMPf.get('programName')
   ebqDEihJlxAtLgVBSzvdsUQCORjMKa =ebqDEihJlxAtLgVBSzvdsUQCORjMPf.get('logo')
   ebqDEihJlxAtLgVBSzvdsUQCORjMPW=ebqDEihJlxAtLgVBSzvdsUQCORjMPf.get('channelepg')
   ebqDEihJlxAtLgVBSzvdsUQCORjMcn =ebqDEihJlxAtLgVBSzvdsUQCORjMPf.get('free')
   ebqDEihJlxAtLgVBSzvdsUQCORjMcK =ebqDEihJlxAtLgVBSzvdsUQCORjMPf.get('hlsUrl')
   ebqDEihJlxAtLgVBSzvdsUQCORjMKm={'plot':'%s\n\n%s'%(ebqDEihJlxAtLgVBSzvdsUQCORjMnN,ebqDEihJlxAtLgVBSzvdsUQCORjMPW),'mediatype':'episode',}
   ebqDEihJlxAtLgVBSzvdsUQCORjMKP={'mode':'LIVE','mediacode':ebqDEihJlxAtLgVBSzvdsUQCORjMyn,'hlsUrl':ebqDEihJlxAtLgVBSzvdsUQCORjMcK,'free':ebqDEihJlxAtLgVBSzvdsUQCORjMcn,'mediatype':'live'}
   if ebqDEihJlxAtLgVBSzvdsUQCORjMcn:ebqDEihJlxAtLgVBSzvdsUQCORjMnN+=' [free]'
   ebqDEihJlxAtLgVBSzvdsUQCORjMnr.add_dir(ebqDEihJlxAtLgVBSzvdsUQCORjMnN,sublabel=ebqDEihJlxAtLgVBSzvdsUQCORjMKy,img=ebqDEihJlxAtLgVBSzvdsUQCORjMKa,infoLabels=ebqDEihJlxAtLgVBSzvdsUQCORjMKm,isFolder=ebqDEihJlxAtLgVBSzvdsUQCORjMrG,params=ebqDEihJlxAtLgVBSzvdsUQCORjMKP)
  xbmcplugin.setContent(ebqDEihJlxAtLgVBSzvdsUQCORjMnr._addon_handle,'episodes')
  if ebqDEihJlxAtLgVBSzvdsUQCORjMrf(ebqDEihJlxAtLgVBSzvdsUQCORjMPT)>0:xbmcplugin.endOfDirectory(ebqDEihJlxAtLgVBSzvdsUQCORjMnr._addon_handle,cacheToDisc=ebqDEihJlxAtLgVBSzvdsUQCORjMrG)
 def dp_EventLiveChannel_List(ebqDEihJlxAtLgVBSzvdsUQCORjMnr,args):
  ebqDEihJlxAtLgVBSzvdsUQCORjMPT,ebqDEihJlxAtLgVBSzvdsUQCORjMcP=ebqDEihJlxAtLgVBSzvdsUQCORjMnr.SpotvObj.GetEventLiveList()
  if ebqDEihJlxAtLgVBSzvdsUQCORjMcP!=401 and ebqDEihJlxAtLgVBSzvdsUQCORjMrf(ebqDEihJlxAtLgVBSzvdsUQCORjMPT)==0:
   ebqDEihJlxAtLgVBSzvdsUQCORjMnr.addon_noti(__language__(30907).encode('utf8'))
  for ebqDEihJlxAtLgVBSzvdsUQCORjMPf in ebqDEihJlxAtLgVBSzvdsUQCORjMPT:
   ebqDEihJlxAtLgVBSzvdsUQCORjMnN =ebqDEihJlxAtLgVBSzvdsUQCORjMPf.get('title')
   ebqDEihJlxAtLgVBSzvdsUQCORjMKy =ebqDEihJlxAtLgVBSzvdsUQCORjMPf.get('startTime')
   ebqDEihJlxAtLgVBSzvdsUQCORjMKa =ebqDEihJlxAtLgVBSzvdsUQCORjMPf.get('logo')
   ebqDEihJlxAtLgVBSzvdsUQCORjMcn =ebqDEihJlxAtLgVBSzvdsUQCORjMPf.get('free')
   ebqDEihJlxAtLgVBSzvdsUQCORjMKm={'mediatype':'episode','plot':'%s\n\n%s'%(ebqDEihJlxAtLgVBSzvdsUQCORjMnN,ebqDEihJlxAtLgVBSzvdsUQCORjMKy)}
   ebqDEihJlxAtLgVBSzvdsUQCORjMKP={'mode':'ELIVE','mediacode':ebqDEihJlxAtLgVBSzvdsUQCORjMPf.get('liveId'),'free':ebqDEihJlxAtLgVBSzvdsUQCORjMcn,'mediatype':'live'}
   if ebqDEihJlxAtLgVBSzvdsUQCORjMcn:ebqDEihJlxAtLgVBSzvdsUQCORjMnN+=' [free]'
   ebqDEihJlxAtLgVBSzvdsUQCORjMnr.add_dir(ebqDEihJlxAtLgVBSzvdsUQCORjMnN,sublabel=ebqDEihJlxAtLgVBSzvdsUQCORjMKy,img=ebqDEihJlxAtLgVBSzvdsUQCORjMKa,infoLabels=ebqDEihJlxAtLgVBSzvdsUQCORjMKm,isFolder=ebqDEihJlxAtLgVBSzvdsUQCORjMrG,params=ebqDEihJlxAtLgVBSzvdsUQCORjMKP)
  xbmcplugin.setContent(ebqDEihJlxAtLgVBSzvdsUQCORjMnr._addon_handle,'episodes')
  if ebqDEihJlxAtLgVBSzvdsUQCORjMrf(ebqDEihJlxAtLgVBSzvdsUQCORjMPT)>0:xbmcplugin.endOfDirectory(ebqDEihJlxAtLgVBSzvdsUQCORjMnr._addon_handle,cacheToDisc=ebqDEihJlxAtLgVBSzvdsUQCORjMru)
  return ebqDEihJlxAtLgVBSzvdsUQCORjMcP
 def play_VIDEO(ebqDEihJlxAtLgVBSzvdsUQCORjMnr,args):
  ebqDEihJlxAtLgVBSzvdsUQCORjMcr =args.get('mode')
  ebqDEihJlxAtLgVBSzvdsUQCORjMcy =args.get('mediacode')
  ebqDEihJlxAtLgVBSzvdsUQCORjMcH =args.get('mediatype')
  ebqDEihJlxAtLgVBSzvdsUQCORjMKN =args.get('vtypeId')
  ebqDEihJlxAtLgVBSzvdsUQCORjMcK =args.get('hlsUrl')
  if ebqDEihJlxAtLgVBSzvdsUQCORjMcr=='LIVE':
   if args.get('free')=='False':
    if ebqDEihJlxAtLgVBSzvdsUQCORjMnr.SpotvObj.CheckSubEnd()==ebqDEihJlxAtLgVBSzvdsUQCORjMrG:
     ebqDEihJlxAtLgVBSzvdsUQCORjMnr.addon_noti(__language__(30908).encode('utf8'))
     return
  elif ebqDEihJlxAtLgVBSzvdsUQCORjMcr=='ELIVE':
   if args.get('free')=='False':
    if ebqDEihJlxAtLgVBSzvdsUQCORjMnr.SpotvObj.CheckSubEnd()==ebqDEihJlxAtLgVBSzvdsUQCORjMrG:
     ebqDEihJlxAtLgVBSzvdsUQCORjMnr.addon_noti(__language__(30908).encode('utf8'))
     return
  if ebqDEihJlxAtLgVBSzvdsUQCORjMcy=='' or ebqDEihJlxAtLgVBSzvdsUQCORjMcy==ebqDEihJlxAtLgVBSzvdsUQCORjMrN:
   ebqDEihJlxAtLgVBSzvdsUQCORjMnr.addon_noti(__language__(30907).encode('utf8'))
   return
  if ebqDEihJlxAtLgVBSzvdsUQCORjMcr=='LIVE':
   if ebqDEihJlxAtLgVBSzvdsUQCORjMcK:
    ebqDEihJlxAtLgVBSzvdsUQCORjMco=ebqDEihJlxAtLgVBSzvdsUQCORjMcK
   else:
    ebqDEihJlxAtLgVBSzvdsUQCORjMco=ebqDEihJlxAtLgVBSzvdsUQCORjMnr.SpotvObj.GetHlsUrl(ebqDEihJlxAtLgVBSzvdsUQCORjMcy)
  else:
   ebqDEihJlxAtLgVBSzvdsUQCORjMnr.addon_log('mediacode : '+ebqDEihJlxAtLgVBSzvdsUQCORjMcy)
   ebqDEihJlxAtLgVBSzvdsUQCORjMnr.addon_log('mediatype : '+ebqDEihJlxAtLgVBSzvdsUQCORjMcH)
   ebqDEihJlxAtLgVBSzvdsUQCORjMnr.addon_log('vtypeId   : '+ebqDEihJlxAtLgVBSzvdsUQCORjMrW(ebqDEihJlxAtLgVBSzvdsUQCORjMKN))
   ebqDEihJlxAtLgVBSzvdsUQCORjMco=ebqDEihJlxAtLgVBSzvdsUQCORjMnr.SpotvObj.GetBroadURL(ebqDEihJlxAtLgVBSzvdsUQCORjMcy,ebqDEihJlxAtLgVBSzvdsUQCORjMcH,ebqDEihJlxAtLgVBSzvdsUQCORjMKN)
  if ebqDEihJlxAtLgVBSzvdsUQCORjMco=='':
   ebqDEihJlxAtLgVBSzvdsUQCORjMnr.addon_noti(__language__(30908).encode('utf8'))
   return
  ebqDEihJlxAtLgVBSzvdsUQCORjMca=ebqDEihJlxAtLgVBSzvdsUQCORjMco
  try:
   ebqDEihJlxAtLgVBSzvdsUQCORjMnr.addon_log('mainMode  = '+ebqDEihJlxAtLgVBSzvdsUQCORjMcr)
  except:
   ebqDEihJlxAtLgVBSzvdsUQCORjMrN
  ebqDEihJlxAtLgVBSzvdsUQCORjMnr.addon_log(ebqDEihJlxAtLgVBSzvdsUQCORjMca)
  ebqDEihJlxAtLgVBSzvdsUQCORjMcp=xbmcgui.ListItem(path=ebqDEihJlxAtLgVBSzvdsUQCORjMca)
  xbmcplugin.setResolvedUrl(ebqDEihJlxAtLgVBSzvdsUQCORjMnr._addon_handle,ebqDEihJlxAtLgVBSzvdsUQCORjMru,ebqDEihJlxAtLgVBSzvdsUQCORjMcp)
  try:
   if ebqDEihJlxAtLgVBSzvdsUQCORjMcH=='vod' and ebqDEihJlxAtLgVBSzvdsUQCORjMcr not in['POP_VOD','NOW_VOD']:
    ebqDEihJlxAtLgVBSzvdsUQCORjMKP={'code':args.get('saveId'),'img':args.get('saveImg'),'title':args.get('saveTitle'),'info':args.get('saveInfo')}
    ebqDEihJlxAtLgVBSzvdsUQCORjMnr.Save_Watched_List(ebqDEihJlxAtLgVBSzvdsUQCORjMcH,ebqDEihJlxAtLgVBSzvdsUQCORjMKP)
  except:
   ebqDEihJlxAtLgVBSzvdsUQCORjMrN
 def logout(ebqDEihJlxAtLgVBSzvdsUQCORjMnr):
  ebqDEihJlxAtLgVBSzvdsUQCORjMnp=xbmcgui.Dialog()
  ebqDEihJlxAtLgVBSzvdsUQCORjMPN=ebqDEihJlxAtLgVBSzvdsUQCORjMnp.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if ebqDEihJlxAtLgVBSzvdsUQCORjMPN==ebqDEihJlxAtLgVBSzvdsUQCORjMrG:sys.exit()
  ebqDEihJlxAtLgVBSzvdsUQCORjMnr.SpotvObj.Init_ST_Total()
  if os.path.isfile(ebqDEihJlxAtLgVBSzvdsUQCORjMnc):os.remove(ebqDEihJlxAtLgVBSzvdsUQCORjMnc)
  ebqDEihJlxAtLgVBSzvdsUQCORjMnr.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(ebqDEihJlxAtLgVBSzvdsUQCORjMnr):
  ebqDEihJlxAtLgVBSzvdsUQCORjMcI =ebqDEihJlxAtLgVBSzvdsUQCORjMnr.SpotvObj.Get_Now_Datetime()
  ebqDEihJlxAtLgVBSzvdsUQCORjMcm=ebqDEihJlxAtLgVBSzvdsUQCORjMcI+datetime.timedelta(days=ebqDEihJlxAtLgVBSzvdsUQCORjMrT(__addon__.getSetting('cache_ttl')))
  (ebqDEihJlxAtLgVBSzvdsUQCORjMPF,ebqDEihJlxAtLgVBSzvdsUQCORjMPk)=ebqDEihJlxAtLgVBSzvdsUQCORjMnr.get_settings_account()
  ebqDEihJlxAtLgVBSzvdsUQCORjMnr.SpotvObj.Save_session_acount(ebqDEihJlxAtLgVBSzvdsUQCORjMPF,ebqDEihJlxAtLgVBSzvdsUQCORjMPk)
  ebqDEihJlxAtLgVBSzvdsUQCORjMnr.SpotvObj.ST['account']['token_limit']=ebqDEihJlxAtLgVBSzvdsUQCORjMcm.strftime('%Y%m%d')
  ebqDEihJlxAtLgVBSzvdsUQCORjMnr.SpotvObj.JsonFile_Save(ebqDEihJlxAtLgVBSzvdsUQCORjMnc,ebqDEihJlxAtLgVBSzvdsUQCORjMnr.SpotvObj.ST)
 def cookiefile_check(ebqDEihJlxAtLgVBSzvdsUQCORjMnr):
  ebqDEihJlxAtLgVBSzvdsUQCORjMnr.SpotvObj.ST=ebqDEihJlxAtLgVBSzvdsUQCORjMnr.SpotvObj.JsonFile_Load(ebqDEihJlxAtLgVBSzvdsUQCORjMnc)
  if 'account' not in ebqDEihJlxAtLgVBSzvdsUQCORjMnr.SpotvObj.ST:
   ebqDEihJlxAtLgVBSzvdsUQCORjMnr.SpotvObj.Init_ST_Total()
   return ebqDEihJlxAtLgVBSzvdsUQCORjMrG
  (ebqDEihJlxAtLgVBSzvdsUQCORjMcX,ebqDEihJlxAtLgVBSzvdsUQCORjMcw)=ebqDEihJlxAtLgVBSzvdsUQCORjMnr.get_settings_account()
  (ebqDEihJlxAtLgVBSzvdsUQCORjMcY,ebqDEihJlxAtLgVBSzvdsUQCORjMcF)=ebqDEihJlxAtLgVBSzvdsUQCORjMnr.SpotvObj.Load_session_acount()
  if ebqDEihJlxAtLgVBSzvdsUQCORjMcX!=ebqDEihJlxAtLgVBSzvdsUQCORjMcY or ebqDEihJlxAtLgVBSzvdsUQCORjMcw!=ebqDEihJlxAtLgVBSzvdsUQCORjMcF:
   ebqDEihJlxAtLgVBSzvdsUQCORjMnr.SpotvObj.Init_ST_Total()
   return ebqDEihJlxAtLgVBSzvdsUQCORjMrG
  if ebqDEihJlxAtLgVBSzvdsUQCORjMrT(ebqDEihJlxAtLgVBSzvdsUQCORjMnr.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))>ebqDEihJlxAtLgVBSzvdsUQCORjMrT(ebqDEihJlxAtLgVBSzvdsUQCORjMnr.SpotvObj.ST['account']['token_limit']):
   ebqDEihJlxAtLgVBSzvdsUQCORjMnr.SpotvObj.Init_ST_Total()
   return ebqDEihJlxAtLgVBSzvdsUQCORjMrG
  return ebqDEihJlxAtLgVBSzvdsUQCORjMru
 def dp_History_Remove(ebqDEihJlxAtLgVBSzvdsUQCORjMnr,args):
  ebqDEihJlxAtLgVBSzvdsUQCORjMck=args.get('delType')
  ebqDEihJlxAtLgVBSzvdsUQCORjMcN =args.get('sKey')
  ebqDEihJlxAtLgVBSzvdsUQCORjMcG =args.get('vType')
  ebqDEihJlxAtLgVBSzvdsUQCORjMnp=xbmcgui.Dialog()
  if ebqDEihJlxAtLgVBSzvdsUQCORjMck=='WATCH_ALL':
   ebqDEihJlxAtLgVBSzvdsUQCORjMPN=ebqDEihJlxAtLgVBSzvdsUQCORjMnp.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif ebqDEihJlxAtLgVBSzvdsUQCORjMck=='WATCH_ONE':
   ebqDEihJlxAtLgVBSzvdsUQCORjMPN=ebqDEihJlxAtLgVBSzvdsUQCORjMnp.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  if ebqDEihJlxAtLgVBSzvdsUQCORjMPN==ebqDEihJlxAtLgVBSzvdsUQCORjMrG:sys.exit()
  if ebqDEihJlxAtLgVBSzvdsUQCORjMck=='WATCH_ALL':
   ebqDEihJlxAtLgVBSzvdsUQCORjMcu=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%ebqDEihJlxAtLgVBSzvdsUQCORjMcG))
   if os.path.isfile(ebqDEihJlxAtLgVBSzvdsUQCORjMcu):os.remove(ebqDEihJlxAtLgVBSzvdsUQCORjMcu)
  elif ebqDEihJlxAtLgVBSzvdsUQCORjMck=='WATCH_ONE':
   ebqDEihJlxAtLgVBSzvdsUQCORjMcu=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%ebqDEihJlxAtLgVBSzvdsUQCORjMcG))
   try:
    ebqDEihJlxAtLgVBSzvdsUQCORjMcT=ebqDEihJlxAtLgVBSzvdsUQCORjMnr.Load_List_File(ebqDEihJlxAtLgVBSzvdsUQCORjMcG) 
    fp=ebqDEihJlxAtLgVBSzvdsUQCORjMyK(ebqDEihJlxAtLgVBSzvdsUQCORjMcu,'w',-1,'utf-8')
    for ebqDEihJlxAtLgVBSzvdsUQCORjMcf in ebqDEihJlxAtLgVBSzvdsUQCORjMcT:
     ebqDEihJlxAtLgVBSzvdsUQCORjMcW=ebqDEihJlxAtLgVBSzvdsUQCORjMyP(urllib.parse.parse_qsl(ebqDEihJlxAtLgVBSzvdsUQCORjMcf))
     ebqDEihJlxAtLgVBSzvdsUQCORjMrn=ebqDEihJlxAtLgVBSzvdsUQCORjMcW.get('code').strip()
     if ebqDEihJlxAtLgVBSzvdsUQCORjMcN!=ebqDEihJlxAtLgVBSzvdsUQCORjMrn:
      fp.write(ebqDEihJlxAtLgVBSzvdsUQCORjMcf)
    fp.close()
   except:
    ebqDEihJlxAtLgVBSzvdsUQCORjMrN
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(ebqDEihJlxAtLgVBSzvdsUQCORjMnr,ebqDEihJlxAtLgVBSzvdsUQCORjMcH):
  try:
   ebqDEihJlxAtLgVBSzvdsUQCORjMrK=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%ebqDEihJlxAtLgVBSzvdsUQCORjMcH))
   fp=ebqDEihJlxAtLgVBSzvdsUQCORjMyK(ebqDEihJlxAtLgVBSzvdsUQCORjMrK,'r',-1,'utf-8')
   ebqDEihJlxAtLgVBSzvdsUQCORjMrP=fp.readlines()
   fp.close()
  except:
   ebqDEihJlxAtLgVBSzvdsUQCORjMrP=[]
  return ebqDEihJlxAtLgVBSzvdsUQCORjMrP
 def Save_Watched_List(ebqDEihJlxAtLgVBSzvdsUQCORjMnr,stype,ebqDEihJlxAtLgVBSzvdsUQCORjMno):
  try:
   ebqDEihJlxAtLgVBSzvdsUQCORjMrK=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   ebqDEihJlxAtLgVBSzvdsUQCORjMcT=ebqDEihJlxAtLgVBSzvdsUQCORjMnr.Load_List_File(stype) 
   fp=ebqDEihJlxAtLgVBSzvdsUQCORjMyK(ebqDEihJlxAtLgVBSzvdsUQCORjMrK,'w',-1,'utf-8')
   ebqDEihJlxAtLgVBSzvdsUQCORjMrc=urllib.parse.urlencode(ebqDEihJlxAtLgVBSzvdsUQCORjMno)
   ebqDEihJlxAtLgVBSzvdsUQCORjMrc=ebqDEihJlxAtLgVBSzvdsUQCORjMrc+'\n'
   fp.write(ebqDEihJlxAtLgVBSzvdsUQCORjMrc)
   ebqDEihJlxAtLgVBSzvdsUQCORjMry=0
   for ebqDEihJlxAtLgVBSzvdsUQCORjMcf in ebqDEihJlxAtLgVBSzvdsUQCORjMcT:
    ebqDEihJlxAtLgVBSzvdsUQCORjMcW=ebqDEihJlxAtLgVBSzvdsUQCORjMyP(urllib.parse.parse_qsl(ebqDEihJlxAtLgVBSzvdsUQCORjMcf))
    ebqDEihJlxAtLgVBSzvdsUQCORjMrH=ebqDEihJlxAtLgVBSzvdsUQCORjMno.get('code')
    ebqDEihJlxAtLgVBSzvdsUQCORjMro=ebqDEihJlxAtLgVBSzvdsUQCORjMcW.get('code')
    if ebqDEihJlxAtLgVBSzvdsUQCORjMrH!=ebqDEihJlxAtLgVBSzvdsUQCORjMro:
     fp.write(ebqDEihJlxAtLgVBSzvdsUQCORjMcf)
     ebqDEihJlxAtLgVBSzvdsUQCORjMry+=1
     if ebqDEihJlxAtLgVBSzvdsUQCORjMry>=50:break
   fp.close()
  except:
   ebqDEihJlxAtLgVBSzvdsUQCORjMrN
 def dp_Watch_List(ebqDEihJlxAtLgVBSzvdsUQCORjMnr,args):
  ebqDEihJlxAtLgVBSzvdsUQCORjMcH ='vod'
  if ebqDEihJlxAtLgVBSzvdsUQCORjMcH=='vod':
   ebqDEihJlxAtLgVBSzvdsUQCORjMra=ebqDEihJlxAtLgVBSzvdsUQCORjMnr.Load_List_File(ebqDEihJlxAtLgVBSzvdsUQCORjMcH)
   for ebqDEihJlxAtLgVBSzvdsUQCORjMrp in ebqDEihJlxAtLgVBSzvdsUQCORjMra:
    ebqDEihJlxAtLgVBSzvdsUQCORjMrI=ebqDEihJlxAtLgVBSzvdsUQCORjMyP(urllib.parse.parse_qsl(ebqDEihJlxAtLgVBSzvdsUQCORjMrp))
    ebqDEihJlxAtLgVBSzvdsUQCORjMnN =ebqDEihJlxAtLgVBSzvdsUQCORjMrI.get('title')
    ebqDEihJlxAtLgVBSzvdsUQCORjMKa=ebqDEihJlxAtLgVBSzvdsUQCORjMrI.get('img')
    ebqDEihJlxAtLgVBSzvdsUQCORjMcy=ebqDEihJlxAtLgVBSzvdsUQCORjMrI.get('code')
    ebqDEihJlxAtLgVBSzvdsUQCORjMrm =ebqDEihJlxAtLgVBSzvdsUQCORjMrI.get('info')
    ebqDEihJlxAtLgVBSzvdsUQCORjMKm={}
    ebqDEihJlxAtLgVBSzvdsUQCORjMKm['plot'] =ebqDEihJlxAtLgVBSzvdsUQCORjMrm
    ebqDEihJlxAtLgVBSzvdsUQCORjMKm['mediatype']='tvshow'
    ebqDEihJlxAtLgVBSzvdsUQCORjMKP={'mode':'GAME_VOD_GROUP','gameid':ebqDEihJlxAtLgVBSzvdsUQCORjMcy,'saveTitle':ebqDEihJlxAtLgVBSzvdsUQCORjMnN,'saveImg':ebqDEihJlxAtLgVBSzvdsUQCORjMKa,'saveInfo':ebqDEihJlxAtLgVBSzvdsUQCORjMrm,'mediatype':ebqDEihJlxAtLgVBSzvdsUQCORjMcH}
    ebqDEihJlxAtLgVBSzvdsUQCORjMrX={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':ebqDEihJlxAtLgVBSzvdsUQCORjMcy,'vType':ebqDEihJlxAtLgVBSzvdsUQCORjMcH,}
    ebqDEihJlxAtLgVBSzvdsUQCORjMrw=urllib.parse.urlencode(ebqDEihJlxAtLgVBSzvdsUQCORjMrX)
    ebqDEihJlxAtLgVBSzvdsUQCORjMrY=[('선택된 시청이력 ( %s ) 삭제'%(ebqDEihJlxAtLgVBSzvdsUQCORjMnN),'RunPlugin(plugin://plugin.video.spotvm/?%s)'%(ebqDEihJlxAtLgVBSzvdsUQCORjMrw))]
    ebqDEihJlxAtLgVBSzvdsUQCORjMnr.add_dir(ebqDEihJlxAtLgVBSzvdsUQCORjMnN,sublabel='',img=ebqDEihJlxAtLgVBSzvdsUQCORjMKa,infoLabels=ebqDEihJlxAtLgVBSzvdsUQCORjMKm,isFolder=ebqDEihJlxAtLgVBSzvdsUQCORjMru,params=ebqDEihJlxAtLgVBSzvdsUQCORjMKP,ContextMenu=ebqDEihJlxAtLgVBSzvdsUQCORjMrY)
   ebqDEihJlxAtLgVBSzvdsUQCORjMKm={'plot':'시청목록을 삭제합니다.'}
   ebqDEihJlxAtLgVBSzvdsUQCORjMnN='*** 시청목록 삭제 ***'
   ebqDEihJlxAtLgVBSzvdsUQCORjMKP={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':ebqDEihJlxAtLgVBSzvdsUQCORjMcH,}
   ebqDEihJlxAtLgVBSzvdsUQCORjMKn=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   ebqDEihJlxAtLgVBSzvdsUQCORjMnr.add_dir(ebqDEihJlxAtLgVBSzvdsUQCORjMnN,sublabel='',img=ebqDEihJlxAtLgVBSzvdsUQCORjMKn,infoLabels=ebqDEihJlxAtLgVBSzvdsUQCORjMKm,isFolder=ebqDEihJlxAtLgVBSzvdsUQCORjMrG,params=ebqDEihJlxAtLgVBSzvdsUQCORjMKP,isLink=ebqDEihJlxAtLgVBSzvdsUQCORjMru)
   xbmcplugin.endOfDirectory(ebqDEihJlxAtLgVBSzvdsUQCORjMnr._addon_handle,cacheToDisc=ebqDEihJlxAtLgVBSzvdsUQCORjMrG)
 def spotv_main(ebqDEihJlxAtLgVBSzvdsUQCORjMnr):
  ebqDEihJlxAtLgVBSzvdsUQCORjMrF=ebqDEihJlxAtLgVBSzvdsUQCORjMnr.main_params.get('mode',ebqDEihJlxAtLgVBSzvdsUQCORjMrN)
  if ebqDEihJlxAtLgVBSzvdsUQCORjMrF=='LOGOUT':
   ebqDEihJlxAtLgVBSzvdsUQCORjMnr.logout()
   return
  ebqDEihJlxAtLgVBSzvdsUQCORjMnr.login_main()
  if ebqDEihJlxAtLgVBSzvdsUQCORjMrF is ebqDEihJlxAtLgVBSzvdsUQCORjMrN:
   ebqDEihJlxAtLgVBSzvdsUQCORjMnr.dp_Main_List()
  elif ebqDEihJlxAtLgVBSzvdsUQCORjMrF=='LIVE_GROUP':
   ebqDEihJlxAtLgVBSzvdsUQCORjMnr.dp_LiveChannel_List(ebqDEihJlxAtLgVBSzvdsUQCORjMnr.main_params)
  elif ebqDEihJlxAtLgVBSzvdsUQCORjMrF=='ELIVE_GROUP':
   ebqDEihJlxAtLgVBSzvdsUQCORjMcP=ebqDEihJlxAtLgVBSzvdsUQCORjMnr.dp_EventLiveChannel_List(ebqDEihJlxAtLgVBSzvdsUQCORjMnr.main_params)
   if ebqDEihJlxAtLgVBSzvdsUQCORjMcP==401:
    if os.path.isfile(ebqDEihJlxAtLgVBSzvdsUQCORjMnc):os.remove(ebqDEihJlxAtLgVBSzvdsUQCORjMnc)
    ebqDEihJlxAtLgVBSzvdsUQCORjMnr.login_main()
    ebqDEihJlxAtLgVBSzvdsUQCORjMnr.dp_EventLiveChannel_List(ebqDEihJlxAtLgVBSzvdsUQCORjMnr.main_params)
  elif ebqDEihJlxAtLgVBSzvdsUQCORjMrF in['LIVE','GAME_VOD','POP_VOD','NOW_VOD','ELIVE']:
   ebqDEihJlxAtLgVBSzvdsUQCORjMnr.play_VIDEO(ebqDEihJlxAtLgVBSzvdsUQCORjMnr.main_params)
  elif ebqDEihJlxAtLgVBSzvdsUQCORjMrF=='VOD_GROUP':
   ebqDEihJlxAtLgVBSzvdsUQCORjMnr.dp_MainLeague_List(ebqDEihJlxAtLgVBSzvdsUQCORjMnr.main_params)
  elif ebqDEihJlxAtLgVBSzvdsUQCORjMrF=='NOW_GROUP':
   ebqDEihJlxAtLgVBSzvdsUQCORjMnr.dp_NowVod_GroupList(ebqDEihJlxAtLgVBSzvdsUQCORjMnr.main_params)
  elif ebqDEihJlxAtLgVBSzvdsUQCORjMrF=='POP_GROUP':
   ebqDEihJlxAtLgVBSzvdsUQCORjMnr.dp_PopVod_GroupList(ebqDEihJlxAtLgVBSzvdsUQCORjMnr.main_params)
  elif ebqDEihJlxAtLgVBSzvdsUQCORjMrF=='LEAGUE_GROUP':
   ebqDEihJlxAtLgVBSzvdsUQCORjMnr.dp_Season_List(ebqDEihJlxAtLgVBSzvdsUQCORjMnr.main_params)
  elif ebqDEihJlxAtLgVBSzvdsUQCORjMrF=='SEASON_GROUP':
   ebqDEihJlxAtLgVBSzvdsUQCORjMnr.dp_Game_List(ebqDEihJlxAtLgVBSzvdsUQCORjMnr.main_params)
  elif ebqDEihJlxAtLgVBSzvdsUQCORjMrF=='GAME_VOD_GROUP':
   ebqDEihJlxAtLgVBSzvdsUQCORjMnr.dp_GameVod_List(ebqDEihJlxAtLgVBSzvdsUQCORjMnr.main_params)
  elif ebqDEihJlxAtLgVBSzvdsUQCORjMrF=='WATCH':
   ebqDEihJlxAtLgVBSzvdsUQCORjMnr.dp_Watch_List(ebqDEihJlxAtLgVBSzvdsUQCORjMnr.main_params)
  elif ebqDEihJlxAtLgVBSzvdsUQCORjMrF=='MYVIEW_REMOVE':
   ebqDEihJlxAtLgVBSzvdsUQCORjMnr.dp_History_Remove(ebqDEihJlxAtLgVBSzvdsUQCORjMnr.main_params)
  else:
   ebqDEihJlxAtLgVBSzvdsUQCORjMrN
# Created by pyminifier (https://github.com/liftoff/pyminifier)
