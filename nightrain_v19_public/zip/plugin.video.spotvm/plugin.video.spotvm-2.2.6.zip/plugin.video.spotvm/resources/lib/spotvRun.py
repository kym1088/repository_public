__author__="NightRain"
kGzqRIdshjiXtfbWCgYcrounmalpxP=object
kGzqRIdshjiXtfbWCgYcrounmalpxQ=None
kGzqRIdshjiXtfbWCgYcrounmalpxN=False
kGzqRIdshjiXtfbWCgYcrounmalpwE=True
kGzqRIdshjiXtfbWCgYcrounmalpwJ=getattr
kGzqRIdshjiXtfbWCgYcrounmalpwB=type
kGzqRIdshjiXtfbWCgYcrounmalpwy=int
kGzqRIdshjiXtfbWCgYcrounmalpwx=list
kGzqRIdshjiXtfbWCgYcrounmalpwH=len
kGzqRIdshjiXtfbWCgYcrounmalpwS=str
kGzqRIdshjiXtfbWCgYcrounmalpwT=id
kGzqRIdshjiXtfbWCgYcrounmalpwL=open
kGzqRIdshjiXtfbWCgYcrounmalpwA=dict
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
kGzqRIdshjiXtfbWCgYcrounmalpEB=[{'title':'TV 채널 (유료사용자만 지원)','mode':'LIVE_GROUP','icon':'live.png'},{'title':'Live중계 (경기중에만 재생)','mode':'ELIVE_GROUP','icon':'live.png'},{'title':'-----------------','mode':'XXX'},{'title':'오늘의 추천 VOD','mode':'NOW_GROUP'},{'title':'인기영상 5','mode':'POP_GROUP'},{'title':'-----------------','mode':'XXX'},{'title':'VOD (리그, 경기별)','mode':'VOD_GROUP'},{'title':'Watched (시청목록)','mode':'WATCH','icon':'history.png'},]
kGzqRIdshjiXtfbWCgYcrounmalpEy={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
kGzqRIdshjiXtfbWCgYcrounmalpEx=xbmcvfs.translatePath(os.path.join(__profile__,'spotv_cookies.json'))
from spotvCore import*
class kGzqRIdshjiXtfbWCgYcrounmalpEJ(kGzqRIdshjiXtfbWCgYcrounmalpxP):
 def __init__(kGzqRIdshjiXtfbWCgYcrounmalpEw,kGzqRIdshjiXtfbWCgYcrounmalpEH,kGzqRIdshjiXtfbWCgYcrounmalpES,kGzqRIdshjiXtfbWCgYcrounmalpET):
  kGzqRIdshjiXtfbWCgYcrounmalpEw._addon_url =kGzqRIdshjiXtfbWCgYcrounmalpEH
  kGzqRIdshjiXtfbWCgYcrounmalpEw._addon_handle=kGzqRIdshjiXtfbWCgYcrounmalpES
  kGzqRIdshjiXtfbWCgYcrounmalpEw.main_params =kGzqRIdshjiXtfbWCgYcrounmalpET
  kGzqRIdshjiXtfbWCgYcrounmalpEw.SpotvObj =eFGpKEulRDmPsrkUQfhXwotdWJLHnc() 
 def addon_noti(kGzqRIdshjiXtfbWCgYcrounmalpEw,sting):
  try:
   kGzqRIdshjiXtfbWCgYcrounmalpEA=xbmcgui.Dialog()
   kGzqRIdshjiXtfbWCgYcrounmalpEA.notification(__addonname__,sting)
  except:
   kGzqRIdshjiXtfbWCgYcrounmalpxQ
 def addon_log(kGzqRIdshjiXtfbWCgYcrounmalpEw,string):
  try:
   kGzqRIdshjiXtfbWCgYcrounmalpEV=string.encode('utf-8','ignore')
  except:
   kGzqRIdshjiXtfbWCgYcrounmalpEV='addonException: addon_log'
  kGzqRIdshjiXtfbWCgYcrounmalpEv=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,kGzqRIdshjiXtfbWCgYcrounmalpEV),level=kGzqRIdshjiXtfbWCgYcrounmalpEv)
 def get_keyboard_input(kGzqRIdshjiXtfbWCgYcrounmalpEw,kGzqRIdshjiXtfbWCgYcrounmalpEF):
  kGzqRIdshjiXtfbWCgYcrounmalpEe=kGzqRIdshjiXtfbWCgYcrounmalpxQ
  kb=xbmc.Keyboard()
  kb.setHeading(kGzqRIdshjiXtfbWCgYcrounmalpEF)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   kGzqRIdshjiXtfbWCgYcrounmalpEe=kb.getText()
  return kGzqRIdshjiXtfbWCgYcrounmalpEe
 def get_settings_account(kGzqRIdshjiXtfbWCgYcrounmalpEw):
  kGzqRIdshjiXtfbWCgYcrounmalpED =__addon__.getSetting('id')
  kGzqRIdshjiXtfbWCgYcrounmalpEU =__addon__.getSetting('pw')
  return(kGzqRIdshjiXtfbWCgYcrounmalpED,kGzqRIdshjiXtfbWCgYcrounmalpEU)
 def get_settings_hidescoreyn(kGzqRIdshjiXtfbWCgYcrounmalpEw):
  kGzqRIdshjiXtfbWCgYcrounmalpEK =__addon__.getSetting('hidescore')
  if kGzqRIdshjiXtfbWCgYcrounmalpEK=='false':
   return kGzqRIdshjiXtfbWCgYcrounmalpxN
  else:
   return kGzqRIdshjiXtfbWCgYcrounmalpwE
 def add_dir(kGzqRIdshjiXtfbWCgYcrounmalpEw,label,sublabel='',img='',infoLabels=kGzqRIdshjiXtfbWCgYcrounmalpxQ,isFolder=kGzqRIdshjiXtfbWCgYcrounmalpwE,params='',isLink=kGzqRIdshjiXtfbWCgYcrounmalpxN,ContextMenu=kGzqRIdshjiXtfbWCgYcrounmalpxQ):
  kGzqRIdshjiXtfbWCgYcrounmalpEO='%s?%s'%(kGzqRIdshjiXtfbWCgYcrounmalpEw._addon_url,urllib.parse.urlencode(params))
  if sublabel:kGzqRIdshjiXtfbWCgYcrounmalpEF='%s < %s >'%(label,sublabel)
  else: kGzqRIdshjiXtfbWCgYcrounmalpEF=label
  if not img:img='DefaultFolder.png'
  kGzqRIdshjiXtfbWCgYcrounmalpEM=xbmcgui.ListItem(kGzqRIdshjiXtfbWCgYcrounmalpEF)
  kGzqRIdshjiXtfbWCgYcrounmalpEM.setArt({'thumb':img,'icon':img,'poster':img})
  if kGzqRIdshjiXtfbWCgYcrounmalpEw.SpotvObj.KodiVersion>=20:
   if infoLabels:kGzqRIdshjiXtfbWCgYcrounmalpEw.Set_InfoTag(kGzqRIdshjiXtfbWCgYcrounmalpEM.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:kGzqRIdshjiXtfbWCgYcrounmalpEM.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   kGzqRIdshjiXtfbWCgYcrounmalpEM.setProperty('IsPlayable','true')
  if ContextMenu:kGzqRIdshjiXtfbWCgYcrounmalpEM.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(kGzqRIdshjiXtfbWCgYcrounmalpEw._addon_handle,kGzqRIdshjiXtfbWCgYcrounmalpEO,kGzqRIdshjiXtfbWCgYcrounmalpEM,isFolder)
 def Set_InfoTag(kGzqRIdshjiXtfbWCgYcrounmalpEw,video_InfoTag:xbmc.InfoTagVideo,kGzqRIdshjiXtfbWCgYcrounmalpJT):
  for kGzqRIdshjiXtfbWCgYcrounmalpEP,value in kGzqRIdshjiXtfbWCgYcrounmalpJT.items():
   if kGzqRIdshjiXtfbWCgYcrounmalpEy[kGzqRIdshjiXtfbWCgYcrounmalpEP]['type']=='string':
    kGzqRIdshjiXtfbWCgYcrounmalpwJ(video_InfoTag,kGzqRIdshjiXtfbWCgYcrounmalpEy[kGzqRIdshjiXtfbWCgYcrounmalpEP]['func'])(value)
   elif kGzqRIdshjiXtfbWCgYcrounmalpEy[kGzqRIdshjiXtfbWCgYcrounmalpEP]['type']=='int':
    if kGzqRIdshjiXtfbWCgYcrounmalpwB(value)==kGzqRIdshjiXtfbWCgYcrounmalpwy:
     kGzqRIdshjiXtfbWCgYcrounmalpEQ=kGzqRIdshjiXtfbWCgYcrounmalpwy(value)
    else:
     kGzqRIdshjiXtfbWCgYcrounmalpEQ=0
    kGzqRIdshjiXtfbWCgYcrounmalpwJ(video_InfoTag,kGzqRIdshjiXtfbWCgYcrounmalpEy[kGzqRIdshjiXtfbWCgYcrounmalpEP]['func'])(kGzqRIdshjiXtfbWCgYcrounmalpEQ)
   elif kGzqRIdshjiXtfbWCgYcrounmalpEy[kGzqRIdshjiXtfbWCgYcrounmalpEP]['type']=='actor':
    if value!=[]:
     kGzqRIdshjiXtfbWCgYcrounmalpwJ(video_InfoTag,kGzqRIdshjiXtfbWCgYcrounmalpEy[kGzqRIdshjiXtfbWCgYcrounmalpEP]['func'])([xbmc.Actor(name)for name in value])
   elif kGzqRIdshjiXtfbWCgYcrounmalpEy[kGzqRIdshjiXtfbWCgYcrounmalpEP]['type']=='list':
    if kGzqRIdshjiXtfbWCgYcrounmalpwB(value)==kGzqRIdshjiXtfbWCgYcrounmalpwx:
     kGzqRIdshjiXtfbWCgYcrounmalpwJ(video_InfoTag,kGzqRIdshjiXtfbWCgYcrounmalpEy[kGzqRIdshjiXtfbWCgYcrounmalpEP]['func'])(value)
    else:
     kGzqRIdshjiXtfbWCgYcrounmalpwJ(video_InfoTag,kGzqRIdshjiXtfbWCgYcrounmalpEy[kGzqRIdshjiXtfbWCgYcrounmalpEP]['func'])([value])
 def get_selQuality(kGzqRIdshjiXtfbWCgYcrounmalpEw,etype):
  try:
   kGzqRIdshjiXtfbWCgYcrounmalpEN='selected_quality'
   kGzqRIdshjiXtfbWCgYcrounmalpJE=[1080,720,540]
   kGzqRIdshjiXtfbWCgYcrounmalpJB=kGzqRIdshjiXtfbWCgYcrounmalpwy(__addon__.getSetting(kGzqRIdshjiXtfbWCgYcrounmalpEN))
   return kGzqRIdshjiXtfbWCgYcrounmalpJE[kGzqRIdshjiXtfbWCgYcrounmalpJB]
  except:
   kGzqRIdshjiXtfbWCgYcrounmalpxQ
  return 1080 
 def dp_Main_List(kGzqRIdshjiXtfbWCgYcrounmalpEw):
  for kGzqRIdshjiXtfbWCgYcrounmalpJy in kGzqRIdshjiXtfbWCgYcrounmalpEB:
   kGzqRIdshjiXtfbWCgYcrounmalpEF=kGzqRIdshjiXtfbWCgYcrounmalpJy.get('title')
   kGzqRIdshjiXtfbWCgYcrounmalpJx=''
   kGzqRIdshjiXtfbWCgYcrounmalpJw={'mode':kGzqRIdshjiXtfbWCgYcrounmalpJy.get('mode'),'page':'1'}
   if kGzqRIdshjiXtfbWCgYcrounmalpJy.get('mode')=='XXX':
    kGzqRIdshjiXtfbWCgYcrounmalpJH=kGzqRIdshjiXtfbWCgYcrounmalpxN
    kGzqRIdshjiXtfbWCgYcrounmalpJS =kGzqRIdshjiXtfbWCgYcrounmalpwE
   else:
    kGzqRIdshjiXtfbWCgYcrounmalpJH=kGzqRIdshjiXtfbWCgYcrounmalpwE
    kGzqRIdshjiXtfbWCgYcrounmalpJS =kGzqRIdshjiXtfbWCgYcrounmalpxN
   kGzqRIdshjiXtfbWCgYcrounmalpJT={'title':kGzqRIdshjiXtfbWCgYcrounmalpEF,'plot':kGzqRIdshjiXtfbWCgYcrounmalpEF}
   if kGzqRIdshjiXtfbWCgYcrounmalpJy.get('mode')=='XXX':kGzqRIdshjiXtfbWCgYcrounmalpJT=kGzqRIdshjiXtfbWCgYcrounmalpxQ
   if 'icon' in kGzqRIdshjiXtfbWCgYcrounmalpJy:kGzqRIdshjiXtfbWCgYcrounmalpJx=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',kGzqRIdshjiXtfbWCgYcrounmalpJy.get('icon')) 
   kGzqRIdshjiXtfbWCgYcrounmalpEw.add_dir(kGzqRIdshjiXtfbWCgYcrounmalpEF,sublabel='',img=kGzqRIdshjiXtfbWCgYcrounmalpJx,infoLabels=kGzqRIdshjiXtfbWCgYcrounmalpJT,isFolder=kGzqRIdshjiXtfbWCgYcrounmalpJH,params=kGzqRIdshjiXtfbWCgYcrounmalpJw,isLink=kGzqRIdshjiXtfbWCgYcrounmalpJS)
  if kGzqRIdshjiXtfbWCgYcrounmalpwH(kGzqRIdshjiXtfbWCgYcrounmalpEB)>0:xbmcplugin.endOfDirectory(kGzqRIdshjiXtfbWCgYcrounmalpEw._addon_handle)
 def dp_MainLeague_List(kGzqRIdshjiXtfbWCgYcrounmalpEw,args):
  kGzqRIdshjiXtfbWCgYcrounmalpJA=kGzqRIdshjiXtfbWCgYcrounmalpEw.SpotvObj.GetTitleGroupList()
  for kGzqRIdshjiXtfbWCgYcrounmalpJV in kGzqRIdshjiXtfbWCgYcrounmalpJA:
   kGzqRIdshjiXtfbWCgYcrounmalpEF =kGzqRIdshjiXtfbWCgYcrounmalpJV.get('title')
   kGzqRIdshjiXtfbWCgYcrounmalpJv =kGzqRIdshjiXtfbWCgYcrounmalpJV.get('logo')
   kGzqRIdshjiXtfbWCgYcrounmalpJe =kGzqRIdshjiXtfbWCgYcrounmalpJV.get('reagueId')
   kGzqRIdshjiXtfbWCgYcrounmalpJD =kGzqRIdshjiXtfbWCgYcrounmalpJV.get('subGame')
   kGzqRIdshjiXtfbWCgYcrounmalpJU={'mediatype':'episode','plot':'%s\n\n%s'%(kGzqRIdshjiXtfbWCgYcrounmalpEF,kGzqRIdshjiXtfbWCgYcrounmalpJD)}
   kGzqRIdshjiXtfbWCgYcrounmalpJw={'mode':'LEAGUE_GROUP','reagueId':kGzqRIdshjiXtfbWCgYcrounmalpJe}
   kGzqRIdshjiXtfbWCgYcrounmalpEw.add_dir(kGzqRIdshjiXtfbWCgYcrounmalpEF,sublabel=kGzqRIdshjiXtfbWCgYcrounmalpxQ,img=kGzqRIdshjiXtfbWCgYcrounmalpJv,infoLabels=kGzqRIdshjiXtfbWCgYcrounmalpJU,isFolder=kGzqRIdshjiXtfbWCgYcrounmalpwE,params=kGzqRIdshjiXtfbWCgYcrounmalpJw)
  if kGzqRIdshjiXtfbWCgYcrounmalpwH(kGzqRIdshjiXtfbWCgYcrounmalpJA)>0:xbmcplugin.endOfDirectory(kGzqRIdshjiXtfbWCgYcrounmalpEw._addon_handle,cacheToDisc=kGzqRIdshjiXtfbWCgYcrounmalpxN)
 def dp_NowVod_GroupList(kGzqRIdshjiXtfbWCgYcrounmalpEw,args):
  kGzqRIdshjiXtfbWCgYcrounmalpJK=kGzqRIdshjiXtfbWCgYcrounmalpwy(args.get('page'))
  kGzqRIdshjiXtfbWCgYcrounmalpJA,kGzqRIdshjiXtfbWCgYcrounmalpJO=kGzqRIdshjiXtfbWCgYcrounmalpEw.SpotvObj.Get_NowVod_GroupList(kGzqRIdshjiXtfbWCgYcrounmalpJK)
  for kGzqRIdshjiXtfbWCgYcrounmalpJV in kGzqRIdshjiXtfbWCgYcrounmalpJA:
   kGzqRIdshjiXtfbWCgYcrounmalpJF =kGzqRIdshjiXtfbWCgYcrounmalpJV.get('vodTitle')
   kGzqRIdshjiXtfbWCgYcrounmalpJM =kGzqRIdshjiXtfbWCgYcrounmalpJV.get('vodId')
   kGzqRIdshjiXtfbWCgYcrounmalpJP =kGzqRIdshjiXtfbWCgYcrounmalpJV.get('vodType')
   kGzqRIdshjiXtfbWCgYcrounmalpJv=kGzqRIdshjiXtfbWCgYcrounmalpJV.get('thumbnail')
   kGzqRIdshjiXtfbWCgYcrounmalpJQ =kGzqRIdshjiXtfbWCgYcrounmalpJV.get('vtypeId')
   kGzqRIdshjiXtfbWCgYcrounmalpJN =kGzqRIdshjiXtfbWCgYcrounmalpJV.get('duration')
   kGzqRIdshjiXtfbWCgYcrounmalpJU={'mediatype':'episode','duration':kGzqRIdshjiXtfbWCgYcrounmalpJN,'plot':kGzqRIdshjiXtfbWCgYcrounmalpJF}
   kGzqRIdshjiXtfbWCgYcrounmalpJw={'mode':'NOW_VOD','mediacode':kGzqRIdshjiXtfbWCgYcrounmalpJM,'mediatype':'vod','vtypeId':kGzqRIdshjiXtfbWCgYcrounmalpJQ}
   kGzqRIdshjiXtfbWCgYcrounmalpEw.add_dir(kGzqRIdshjiXtfbWCgYcrounmalpJF,sublabel=kGzqRIdshjiXtfbWCgYcrounmalpJP,img=kGzqRIdshjiXtfbWCgYcrounmalpJv,infoLabels=kGzqRIdshjiXtfbWCgYcrounmalpJU,isFolder=kGzqRIdshjiXtfbWCgYcrounmalpxN,params=kGzqRIdshjiXtfbWCgYcrounmalpJw)
  if kGzqRIdshjiXtfbWCgYcrounmalpJO:
   kGzqRIdshjiXtfbWCgYcrounmalpJw['mode'] ='NOW_GROUP' 
   kGzqRIdshjiXtfbWCgYcrounmalpJw['page'] =kGzqRIdshjiXtfbWCgYcrounmalpwS(kGzqRIdshjiXtfbWCgYcrounmalpJK+1)
   kGzqRIdshjiXtfbWCgYcrounmalpEF='[B]%s >>[/B]'%'다음 페이지'
   kGzqRIdshjiXtfbWCgYcrounmalpBE=kGzqRIdshjiXtfbWCgYcrounmalpwS(kGzqRIdshjiXtfbWCgYcrounmalpJK+1)
   kGzqRIdshjiXtfbWCgYcrounmalpJx=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   kGzqRIdshjiXtfbWCgYcrounmalpEw.add_dir(kGzqRIdshjiXtfbWCgYcrounmalpEF,sublabel=kGzqRIdshjiXtfbWCgYcrounmalpBE,img=kGzqRIdshjiXtfbWCgYcrounmalpJx,infoLabels=kGzqRIdshjiXtfbWCgYcrounmalpxQ,isFolder=kGzqRIdshjiXtfbWCgYcrounmalpwE,params=kGzqRIdshjiXtfbWCgYcrounmalpJw)
  xbmcplugin.setContent(kGzqRIdshjiXtfbWCgYcrounmalpEw._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(kGzqRIdshjiXtfbWCgYcrounmalpEw._addon_handle,cacheToDisc=kGzqRIdshjiXtfbWCgYcrounmalpxN)
 def dp_PopVod_GroupList(kGzqRIdshjiXtfbWCgYcrounmalpEw,args):
  kGzqRIdshjiXtfbWCgYcrounmalpJA=kGzqRIdshjiXtfbWCgYcrounmalpEw.SpotvObj.GetPopularGroupList()
  for kGzqRIdshjiXtfbWCgYcrounmalpJV in kGzqRIdshjiXtfbWCgYcrounmalpJA:
   kGzqRIdshjiXtfbWCgYcrounmalpJF =kGzqRIdshjiXtfbWCgYcrounmalpJV.get('vodTitle')
   kGzqRIdshjiXtfbWCgYcrounmalpJM =kGzqRIdshjiXtfbWCgYcrounmalpJV.get('vodId')
   kGzqRIdshjiXtfbWCgYcrounmalpJP =kGzqRIdshjiXtfbWCgYcrounmalpJV.get('vodType')
   kGzqRIdshjiXtfbWCgYcrounmalpJv=kGzqRIdshjiXtfbWCgYcrounmalpJV.get('thumbnail')
   kGzqRIdshjiXtfbWCgYcrounmalpJQ =kGzqRIdshjiXtfbWCgYcrounmalpJV.get('vtypeId')
   kGzqRIdshjiXtfbWCgYcrounmalpJN =kGzqRIdshjiXtfbWCgYcrounmalpJV.get('duration')
   kGzqRIdshjiXtfbWCgYcrounmalpJU={'mediatype':'episode','duration':kGzqRIdshjiXtfbWCgYcrounmalpJN,'plot':kGzqRIdshjiXtfbWCgYcrounmalpJF}
   kGzqRIdshjiXtfbWCgYcrounmalpJw={'mode':'POP_VOD','mediacode':kGzqRIdshjiXtfbWCgYcrounmalpJM,'mediatype':'vod','vtypeId':kGzqRIdshjiXtfbWCgYcrounmalpJQ}
   kGzqRIdshjiXtfbWCgYcrounmalpEw.add_dir(kGzqRIdshjiXtfbWCgYcrounmalpJF,sublabel=kGzqRIdshjiXtfbWCgYcrounmalpJP,img=kGzqRIdshjiXtfbWCgYcrounmalpJv,infoLabels=kGzqRIdshjiXtfbWCgYcrounmalpJU,isFolder=kGzqRIdshjiXtfbWCgYcrounmalpxN,params=kGzqRIdshjiXtfbWCgYcrounmalpJw)
  xbmcplugin.setContent(kGzqRIdshjiXtfbWCgYcrounmalpEw._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(kGzqRIdshjiXtfbWCgYcrounmalpEw._addon_handle,cacheToDisc=kGzqRIdshjiXtfbWCgYcrounmalpxN)
 def dp_Season_List(kGzqRIdshjiXtfbWCgYcrounmalpEw,args):
  kGzqRIdshjiXtfbWCgYcrounmalpJe=args.get('reagueId')
  kGzqRIdshjiXtfbWCgYcrounmalpEw.addon_log('Season_List - reagueId : '+kGzqRIdshjiXtfbWCgYcrounmalpJe)
  kGzqRIdshjiXtfbWCgYcrounmalpJA=kGzqRIdshjiXtfbWCgYcrounmalpEw.SpotvObj.GetSeasonList(kGzqRIdshjiXtfbWCgYcrounmalpJe)
  for kGzqRIdshjiXtfbWCgYcrounmalpJV in kGzqRIdshjiXtfbWCgYcrounmalpJA:
   kGzqRIdshjiXtfbWCgYcrounmalpBy =kGzqRIdshjiXtfbWCgYcrounmalpJV.get('reagueName')
   kGzqRIdshjiXtfbWCgYcrounmalpBx =kGzqRIdshjiXtfbWCgYcrounmalpJV.get('gameTypeId')
   kGzqRIdshjiXtfbWCgYcrounmalpBw =kGzqRIdshjiXtfbWCgYcrounmalpJV.get('seasonName')
   kGzqRIdshjiXtfbWCgYcrounmalpBH =kGzqRIdshjiXtfbWCgYcrounmalpJV.get('seasonId')
   kGzqRIdshjiXtfbWCgYcrounmalpJU={'mediatype':'episode','plot':'%s - %s'%(kGzqRIdshjiXtfbWCgYcrounmalpBy,kGzqRIdshjiXtfbWCgYcrounmalpBw)}
   kGzqRIdshjiXtfbWCgYcrounmalpJw={'mode':'SEASON_GROUP','reagueId':kGzqRIdshjiXtfbWCgYcrounmalpJe,'seasonId':kGzqRIdshjiXtfbWCgYcrounmalpBH,'gameTypeId':kGzqRIdshjiXtfbWCgYcrounmalpBx,'page':'1'}
   kGzqRIdshjiXtfbWCgYcrounmalpEw.add_dir(kGzqRIdshjiXtfbWCgYcrounmalpBy,sublabel=kGzqRIdshjiXtfbWCgYcrounmalpBw,img='',infoLabels=kGzqRIdshjiXtfbWCgYcrounmalpJU,isFolder=kGzqRIdshjiXtfbWCgYcrounmalpwE,params=kGzqRIdshjiXtfbWCgYcrounmalpJw)
  if kGzqRIdshjiXtfbWCgYcrounmalpwH(kGzqRIdshjiXtfbWCgYcrounmalpJA)>0:xbmcplugin.endOfDirectory(kGzqRIdshjiXtfbWCgYcrounmalpEw._addon_handle,cacheToDisc=kGzqRIdshjiXtfbWCgYcrounmalpwE)
 def dp_Game_List(kGzqRIdshjiXtfbWCgYcrounmalpEw,args):
  kGzqRIdshjiXtfbWCgYcrounmalpBx=args.get('gameTypeId')
  kGzqRIdshjiXtfbWCgYcrounmalpJe =args.get('reagueId')
  kGzqRIdshjiXtfbWCgYcrounmalpBH =args.get('seasonId')
  kGzqRIdshjiXtfbWCgYcrounmalpJK =kGzqRIdshjiXtfbWCgYcrounmalpwy(args.get('page'))
  kGzqRIdshjiXtfbWCgYcrounmalpEw.addon_log('Game_List - gameTypeId : '+kGzqRIdshjiXtfbWCgYcrounmalpBx)
  kGzqRIdshjiXtfbWCgYcrounmalpEw.addon_log('Game_List - reagueId   : '+kGzqRIdshjiXtfbWCgYcrounmalpJe)
  kGzqRIdshjiXtfbWCgYcrounmalpEw.addon_log('Game_List - seasonId   : '+kGzqRIdshjiXtfbWCgYcrounmalpBH)
  kGzqRIdshjiXtfbWCgYcrounmalpJA,kGzqRIdshjiXtfbWCgYcrounmalpJO=kGzqRIdshjiXtfbWCgYcrounmalpEw.SpotvObj.GetGameList(kGzqRIdshjiXtfbWCgYcrounmalpBx,kGzqRIdshjiXtfbWCgYcrounmalpJe,kGzqRIdshjiXtfbWCgYcrounmalpBH,kGzqRIdshjiXtfbWCgYcrounmalpJK,hidescore=kGzqRIdshjiXtfbWCgYcrounmalpEw.get_settings_hidescoreyn())
  for kGzqRIdshjiXtfbWCgYcrounmalpJV in kGzqRIdshjiXtfbWCgYcrounmalpJA:
   kGzqRIdshjiXtfbWCgYcrounmalpBS =kGzqRIdshjiXtfbWCgYcrounmalpJV.get('gameTitle')
   kGzqRIdshjiXtfbWCgYcrounmalpBT =kGzqRIdshjiXtfbWCgYcrounmalpJV.get('beginDate')
   kGzqRIdshjiXtfbWCgYcrounmalpJv =kGzqRIdshjiXtfbWCgYcrounmalpJV.get('thumbnail')
   kGzqRIdshjiXtfbWCgYcrounmalpBL =kGzqRIdshjiXtfbWCgYcrounmalpJV.get('gameId')
   kGzqRIdshjiXtfbWCgYcrounmalpBA =kGzqRIdshjiXtfbWCgYcrounmalpJV.get('totVodCnt')
   kGzqRIdshjiXtfbWCgYcrounmalpBV =kGzqRIdshjiXtfbWCgYcrounmalpJV.get('leaguenm')
   kGzqRIdshjiXtfbWCgYcrounmalpBv =kGzqRIdshjiXtfbWCgYcrounmalpJV.get('seasonnm')
   kGzqRIdshjiXtfbWCgYcrounmalpBe =kGzqRIdshjiXtfbWCgYcrounmalpJV.get('roundnm')
   kGzqRIdshjiXtfbWCgYcrounmalpBD =kGzqRIdshjiXtfbWCgYcrounmalpJV.get('info_plot')
   kGzqRIdshjiXtfbWCgYcrounmalpBU ='%s < %s >'%(kGzqRIdshjiXtfbWCgYcrounmalpBS,kGzqRIdshjiXtfbWCgYcrounmalpBT)
   kGzqRIdshjiXtfbWCgYcrounmalpJU={'mediatype':'video','plot':kGzqRIdshjiXtfbWCgYcrounmalpBD}
   kGzqRIdshjiXtfbWCgYcrounmalpJw={'mode':'GAME_VOD_GROUP' if kGzqRIdshjiXtfbWCgYcrounmalpBA!=0 else 'XXX','saveTitle':kGzqRIdshjiXtfbWCgYcrounmalpBU,'saveImg':kGzqRIdshjiXtfbWCgYcrounmalpJv,'saveInfo':kGzqRIdshjiXtfbWCgYcrounmalpJU['plot'],'gameid':kGzqRIdshjiXtfbWCgYcrounmalpBL,'totVodCnt':kGzqRIdshjiXtfbWCgYcrounmalpBA,}
   kGzqRIdshjiXtfbWCgYcrounmalpEw.add_dir(kGzqRIdshjiXtfbWCgYcrounmalpBS,sublabel=kGzqRIdshjiXtfbWCgYcrounmalpBT,img=kGzqRIdshjiXtfbWCgYcrounmalpJv,infoLabels=kGzqRIdshjiXtfbWCgYcrounmalpJU,isFolder=kGzqRIdshjiXtfbWCgYcrounmalpwE,params=kGzqRIdshjiXtfbWCgYcrounmalpJw)
  if kGzqRIdshjiXtfbWCgYcrounmalpJO:
   kGzqRIdshjiXtfbWCgYcrounmalpJw['mode'] ='SEASON_GROUP' 
   kGzqRIdshjiXtfbWCgYcrounmalpJw['reagueId'] =kGzqRIdshjiXtfbWCgYcrounmalpJe
   kGzqRIdshjiXtfbWCgYcrounmalpJw['seasonId'] =kGzqRIdshjiXtfbWCgYcrounmalpBH
   kGzqRIdshjiXtfbWCgYcrounmalpJw['gameTypeId']=kGzqRIdshjiXtfbWCgYcrounmalpBx
   kGzqRIdshjiXtfbWCgYcrounmalpJw['page'] =kGzqRIdshjiXtfbWCgYcrounmalpwS(kGzqRIdshjiXtfbWCgYcrounmalpJK+1)
   kGzqRIdshjiXtfbWCgYcrounmalpEF='[B]%s >>[/B]'%'다음 페이지'
   kGzqRIdshjiXtfbWCgYcrounmalpBE=kGzqRIdshjiXtfbWCgYcrounmalpwS(kGzqRIdshjiXtfbWCgYcrounmalpJK+1)
   kGzqRIdshjiXtfbWCgYcrounmalpJx=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   kGzqRIdshjiXtfbWCgYcrounmalpEw.add_dir(kGzqRIdshjiXtfbWCgYcrounmalpEF,sublabel=kGzqRIdshjiXtfbWCgYcrounmalpBE,img=kGzqRIdshjiXtfbWCgYcrounmalpJx,infoLabels=kGzqRIdshjiXtfbWCgYcrounmalpxQ,isFolder=kGzqRIdshjiXtfbWCgYcrounmalpwE,params=kGzqRIdshjiXtfbWCgYcrounmalpJw)
  if kGzqRIdshjiXtfbWCgYcrounmalpwH(kGzqRIdshjiXtfbWCgYcrounmalpJA)>0:xbmcplugin.endOfDirectory(kGzqRIdshjiXtfbWCgYcrounmalpEw._addon_handle,cacheToDisc=kGzqRIdshjiXtfbWCgYcrounmalpxN)
 def dp_GameVod_List(kGzqRIdshjiXtfbWCgYcrounmalpEw,args):
  kGzqRIdshjiXtfbWCgYcrounmalpBK =args.get('gameid')
  kGzqRIdshjiXtfbWCgYcrounmalpBU=args.get('saveTitle')
  kGzqRIdshjiXtfbWCgYcrounmalpBO =args.get('saveImg')
  kGzqRIdshjiXtfbWCgYcrounmalpBF =args.get('saveInfo')
  kGzqRIdshjiXtfbWCgYcrounmalpJA=kGzqRIdshjiXtfbWCgYcrounmalpEw.SpotvObj.GetGameVodList(kGzqRIdshjiXtfbWCgYcrounmalpBK)
  for kGzqRIdshjiXtfbWCgYcrounmalpJV in kGzqRIdshjiXtfbWCgYcrounmalpJA:
   kGzqRIdshjiXtfbWCgYcrounmalpJF =kGzqRIdshjiXtfbWCgYcrounmalpJV.get('vodTitle')
   kGzqRIdshjiXtfbWCgYcrounmalpJM =kGzqRIdshjiXtfbWCgYcrounmalpJV.get('vodId')
   kGzqRIdshjiXtfbWCgYcrounmalpJP =kGzqRIdshjiXtfbWCgYcrounmalpJV.get('vodType')
   kGzqRIdshjiXtfbWCgYcrounmalpJv=kGzqRIdshjiXtfbWCgYcrounmalpJV.get('thumbnail')
   kGzqRIdshjiXtfbWCgYcrounmalpJQ =kGzqRIdshjiXtfbWCgYcrounmalpJV.get('vtypeId')
   kGzqRIdshjiXtfbWCgYcrounmalpJN =kGzqRIdshjiXtfbWCgYcrounmalpJV.get('duration')
   kGzqRIdshjiXtfbWCgYcrounmalpJU={'mediatype':'episode','duration':kGzqRIdshjiXtfbWCgYcrounmalpJN,'plot':'%s \n\n %s'%(kGzqRIdshjiXtfbWCgYcrounmalpJF,kGzqRIdshjiXtfbWCgYcrounmalpBF)}
   kGzqRIdshjiXtfbWCgYcrounmalpJw={'mode':'GAME_VOD','saveTitle':kGzqRIdshjiXtfbWCgYcrounmalpBU,'saveImg':kGzqRIdshjiXtfbWCgYcrounmalpBO,'saveId':kGzqRIdshjiXtfbWCgYcrounmalpBK,'saveInfo':kGzqRIdshjiXtfbWCgYcrounmalpBF,'mediacode':kGzqRIdshjiXtfbWCgYcrounmalpJM,'mediatype':'vod','vtypeId':kGzqRIdshjiXtfbWCgYcrounmalpJQ}
   kGzqRIdshjiXtfbWCgYcrounmalpEw.add_dir(kGzqRIdshjiXtfbWCgYcrounmalpJF,sublabel=kGzqRIdshjiXtfbWCgYcrounmalpJP,img=kGzqRIdshjiXtfbWCgYcrounmalpJv,infoLabels=kGzqRIdshjiXtfbWCgYcrounmalpJU,isFolder=kGzqRIdshjiXtfbWCgYcrounmalpxN,params=kGzqRIdshjiXtfbWCgYcrounmalpJw)
  xbmcplugin.setContent(kGzqRIdshjiXtfbWCgYcrounmalpEw._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(kGzqRIdshjiXtfbWCgYcrounmalpEw._addon_handle,cacheToDisc=kGzqRIdshjiXtfbWCgYcrounmalpxN)
 def login_main(kGzqRIdshjiXtfbWCgYcrounmalpEw):
  (kGzqRIdshjiXtfbWCgYcrounmalpBM,kGzqRIdshjiXtfbWCgYcrounmalpBP)=kGzqRIdshjiXtfbWCgYcrounmalpEw.get_settings_account()
  if not(kGzqRIdshjiXtfbWCgYcrounmalpBM and kGzqRIdshjiXtfbWCgYcrounmalpBP):
   kGzqRIdshjiXtfbWCgYcrounmalpEA=xbmcgui.Dialog()
   kGzqRIdshjiXtfbWCgYcrounmalpBQ=kGzqRIdshjiXtfbWCgYcrounmalpEA.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if kGzqRIdshjiXtfbWCgYcrounmalpBQ==kGzqRIdshjiXtfbWCgYcrounmalpwE:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if kGzqRIdshjiXtfbWCgYcrounmalpEw.cookiefile_check():return
  if xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINWAIT')=='TRUE':
   kGzqRIdshjiXtfbWCgYcrounmalpBN=0
   while kGzqRIdshjiXtfbWCgYcrounmalpwE:
    kGzqRIdshjiXtfbWCgYcrounmalpBN+=1
    time.sleep(0.05)
    if kGzqRIdshjiXtfbWCgYcrounmalpBN>600:return
  else:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','TRUE')
  kGzqRIdshjiXtfbWCgYcrounmalpyE=kGzqRIdshjiXtfbWCgYcrounmalpEw.SpotvObj.GetCredential_new(kGzqRIdshjiXtfbWCgYcrounmalpBM,kGzqRIdshjiXtfbWCgYcrounmalpBP)
  if kGzqRIdshjiXtfbWCgYcrounmalpyE:kGzqRIdshjiXtfbWCgYcrounmalpEw.cookiefile_save()
  xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
  if kGzqRIdshjiXtfbWCgYcrounmalpyE==kGzqRIdshjiXtfbWCgYcrounmalpxN:
   kGzqRIdshjiXtfbWCgYcrounmalpEw.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_LiveChannel_List(kGzqRIdshjiXtfbWCgYcrounmalpEw,args):
  kGzqRIdshjiXtfbWCgYcrounmalpyJ=kGzqRIdshjiXtfbWCgYcrounmalpEw.SpotvObj.GetLiveChannelList()
  for kGzqRIdshjiXtfbWCgYcrounmalpyB in kGzqRIdshjiXtfbWCgYcrounmalpyJ:
   kGzqRIdshjiXtfbWCgYcrounmalpwT =kGzqRIdshjiXtfbWCgYcrounmalpyB.get('id')
   kGzqRIdshjiXtfbWCgYcrounmalpEF =kGzqRIdshjiXtfbWCgYcrounmalpyB.get('name')
   kGzqRIdshjiXtfbWCgYcrounmalpJL =kGzqRIdshjiXtfbWCgYcrounmalpyB.get('programName')
   kGzqRIdshjiXtfbWCgYcrounmalpJv =kGzqRIdshjiXtfbWCgYcrounmalpyB.get('logo')
   kGzqRIdshjiXtfbWCgYcrounmalpyx=kGzqRIdshjiXtfbWCgYcrounmalpyB.get('channelepg')
   kGzqRIdshjiXtfbWCgYcrounmalpyw =kGzqRIdshjiXtfbWCgYcrounmalpyB.get('free')
   kGzqRIdshjiXtfbWCgYcrounmalpJU={'plot':'%s\n\n%s'%(kGzqRIdshjiXtfbWCgYcrounmalpEF,kGzqRIdshjiXtfbWCgYcrounmalpyx),'mediatype':'episode',}
   kGzqRIdshjiXtfbWCgYcrounmalpJw={'mode':'LIVE','mediacode':kGzqRIdshjiXtfbWCgYcrounmalpwT,'free':kGzqRIdshjiXtfbWCgYcrounmalpyw,'mediatype':'live'}
   if kGzqRIdshjiXtfbWCgYcrounmalpyw:kGzqRIdshjiXtfbWCgYcrounmalpEF+=' [free]'
   kGzqRIdshjiXtfbWCgYcrounmalpEw.add_dir(kGzqRIdshjiXtfbWCgYcrounmalpEF,sublabel=kGzqRIdshjiXtfbWCgYcrounmalpJL,img=kGzqRIdshjiXtfbWCgYcrounmalpJv,infoLabels=kGzqRIdshjiXtfbWCgYcrounmalpJU,isFolder=kGzqRIdshjiXtfbWCgYcrounmalpxN,params=kGzqRIdshjiXtfbWCgYcrounmalpJw)
  xbmcplugin.setContent(kGzqRIdshjiXtfbWCgYcrounmalpEw._addon_handle,'episodes')
  if kGzqRIdshjiXtfbWCgYcrounmalpwH(kGzqRIdshjiXtfbWCgYcrounmalpyJ)>0:xbmcplugin.endOfDirectory(kGzqRIdshjiXtfbWCgYcrounmalpEw._addon_handle,cacheToDisc=kGzqRIdshjiXtfbWCgYcrounmalpxN)
 def dp_EventLiveChannel_List(kGzqRIdshjiXtfbWCgYcrounmalpEw,args):
  kGzqRIdshjiXtfbWCgYcrounmalpyJ,kGzqRIdshjiXtfbWCgYcrounmalpyH=kGzqRIdshjiXtfbWCgYcrounmalpEw.SpotvObj.GetEventLiveList()
  if kGzqRIdshjiXtfbWCgYcrounmalpyH!=401 and kGzqRIdshjiXtfbWCgYcrounmalpwH(kGzqRIdshjiXtfbWCgYcrounmalpyJ)==0:
   kGzqRIdshjiXtfbWCgYcrounmalpEw.addon_noti(__language__(30907).encode('utf8'))
  for kGzqRIdshjiXtfbWCgYcrounmalpyB in kGzqRIdshjiXtfbWCgYcrounmalpyJ:
   kGzqRIdshjiXtfbWCgYcrounmalpEF =kGzqRIdshjiXtfbWCgYcrounmalpyB.get('title')
   kGzqRIdshjiXtfbWCgYcrounmalpJL =kGzqRIdshjiXtfbWCgYcrounmalpyB.get('startTime')
   kGzqRIdshjiXtfbWCgYcrounmalpJv =kGzqRIdshjiXtfbWCgYcrounmalpyB.get('logo')
   kGzqRIdshjiXtfbWCgYcrounmalpyw =kGzqRIdshjiXtfbWCgYcrounmalpyB.get('free')
   kGzqRIdshjiXtfbWCgYcrounmalpJU={'mediatype':'episode','plot':'%s\n\n%s'%(kGzqRIdshjiXtfbWCgYcrounmalpEF,kGzqRIdshjiXtfbWCgYcrounmalpJL)}
   kGzqRIdshjiXtfbWCgYcrounmalpJw={'mode':'ELIVE','mediacode':kGzqRIdshjiXtfbWCgYcrounmalpyB.get('liveId'),'free':kGzqRIdshjiXtfbWCgYcrounmalpyw,'mediatype':'live'}
   if kGzqRIdshjiXtfbWCgYcrounmalpyw:kGzqRIdshjiXtfbWCgYcrounmalpEF+=' [free]'
   kGzqRIdshjiXtfbWCgYcrounmalpEw.add_dir(kGzqRIdshjiXtfbWCgYcrounmalpEF,sublabel=kGzqRIdshjiXtfbWCgYcrounmalpJL,img=kGzqRIdshjiXtfbWCgYcrounmalpJv,infoLabels=kGzqRIdshjiXtfbWCgYcrounmalpJU,isFolder=kGzqRIdshjiXtfbWCgYcrounmalpxN,params=kGzqRIdshjiXtfbWCgYcrounmalpJw)
  xbmcplugin.setContent(kGzqRIdshjiXtfbWCgYcrounmalpEw._addon_handle,'episodes')
  if kGzqRIdshjiXtfbWCgYcrounmalpwH(kGzqRIdshjiXtfbWCgYcrounmalpyJ)>0:xbmcplugin.endOfDirectory(kGzqRIdshjiXtfbWCgYcrounmalpEw._addon_handle,cacheToDisc=kGzqRIdshjiXtfbWCgYcrounmalpwE)
  return kGzqRIdshjiXtfbWCgYcrounmalpyH
 def play_VIDEO(kGzqRIdshjiXtfbWCgYcrounmalpEw,args):
  kGzqRIdshjiXtfbWCgYcrounmalpyS =args.get('mode')
  kGzqRIdshjiXtfbWCgYcrounmalpyT =args.get('mediacode')
  kGzqRIdshjiXtfbWCgYcrounmalpyL =args.get('mediatype')
  kGzqRIdshjiXtfbWCgYcrounmalpJQ =args.get('vtypeId')
  kGzqRIdshjiXtfbWCgYcrounmalpyA =args.get('hlsUrl')
  if kGzqRIdshjiXtfbWCgYcrounmalpyS=='LIVE':
   if args.get('free')=='False':
    if kGzqRIdshjiXtfbWCgYcrounmalpEw.SpotvObj.CheckSubEnd()==kGzqRIdshjiXtfbWCgYcrounmalpxN:
     kGzqRIdshjiXtfbWCgYcrounmalpEw.addon_noti(__language__(30908).encode('utf8'))
     return
  elif kGzqRIdshjiXtfbWCgYcrounmalpyS=='ELIVE':
   if args.get('free')=='False':
    if kGzqRIdshjiXtfbWCgYcrounmalpEw.SpotvObj.CheckSubEnd()==kGzqRIdshjiXtfbWCgYcrounmalpxN:
     kGzqRIdshjiXtfbWCgYcrounmalpEw.addon_noti(__language__(30908).encode('utf8'))
     return
  if kGzqRIdshjiXtfbWCgYcrounmalpyT=='' or kGzqRIdshjiXtfbWCgYcrounmalpyT==kGzqRIdshjiXtfbWCgYcrounmalpxQ:
   kGzqRIdshjiXtfbWCgYcrounmalpEw.addon_noti(__language__(30907).encode('utf8'))
   return
  if kGzqRIdshjiXtfbWCgYcrounmalpyS=='LIVE':
   kGzqRIdshjiXtfbWCgYcrounmalpyV=kGzqRIdshjiXtfbWCgYcrounmalpEw.SpotvObj.GetHlsUrl(kGzqRIdshjiXtfbWCgYcrounmalpyT)
  else:
   kGzqRIdshjiXtfbWCgYcrounmalpEw.addon_log('mediacode : '+kGzqRIdshjiXtfbWCgYcrounmalpyT)
   kGzqRIdshjiXtfbWCgYcrounmalpEw.addon_log('mediatype : '+kGzqRIdshjiXtfbWCgYcrounmalpyL)
   kGzqRIdshjiXtfbWCgYcrounmalpEw.addon_log('vtypeId   : '+kGzqRIdshjiXtfbWCgYcrounmalpwS(kGzqRIdshjiXtfbWCgYcrounmalpJQ))
   kGzqRIdshjiXtfbWCgYcrounmalpyV=kGzqRIdshjiXtfbWCgYcrounmalpEw.SpotvObj.GetBroadURL(kGzqRIdshjiXtfbWCgYcrounmalpyT,kGzqRIdshjiXtfbWCgYcrounmalpyL,kGzqRIdshjiXtfbWCgYcrounmalpJQ)
  if kGzqRIdshjiXtfbWCgYcrounmalpyV=='':
   kGzqRIdshjiXtfbWCgYcrounmalpEw.addon_noti(__language__(30908).encode('utf8'))
   return
  kGzqRIdshjiXtfbWCgYcrounmalpyv=kGzqRIdshjiXtfbWCgYcrounmalpyV
  try:
   kGzqRIdshjiXtfbWCgYcrounmalpEw.addon_log('mainMode  = '+kGzqRIdshjiXtfbWCgYcrounmalpyS)
  except:
   kGzqRIdshjiXtfbWCgYcrounmalpxQ
  kGzqRIdshjiXtfbWCgYcrounmalpEw.addon_log(kGzqRIdshjiXtfbWCgYcrounmalpyv)
  kGzqRIdshjiXtfbWCgYcrounmalpye=xbmcgui.ListItem(path=kGzqRIdshjiXtfbWCgYcrounmalpyv)
  xbmcplugin.setResolvedUrl(kGzqRIdshjiXtfbWCgYcrounmalpEw._addon_handle,kGzqRIdshjiXtfbWCgYcrounmalpwE,kGzqRIdshjiXtfbWCgYcrounmalpye)
  try:
   if kGzqRIdshjiXtfbWCgYcrounmalpyL=='vod' and kGzqRIdshjiXtfbWCgYcrounmalpyS not in['POP_VOD','NOW_VOD']:
    kGzqRIdshjiXtfbWCgYcrounmalpJw={'code':args.get('saveId'),'img':args.get('saveImg'),'title':args.get('saveTitle'),'info':args.get('saveInfo')}
    kGzqRIdshjiXtfbWCgYcrounmalpEw.Save_Watched_List(kGzqRIdshjiXtfbWCgYcrounmalpyL,kGzqRIdshjiXtfbWCgYcrounmalpJw)
  except:
   kGzqRIdshjiXtfbWCgYcrounmalpxQ
 def logout(kGzqRIdshjiXtfbWCgYcrounmalpEw):
  kGzqRIdshjiXtfbWCgYcrounmalpEA=xbmcgui.Dialog()
  kGzqRIdshjiXtfbWCgYcrounmalpBQ=kGzqRIdshjiXtfbWCgYcrounmalpEA.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if kGzqRIdshjiXtfbWCgYcrounmalpBQ==kGzqRIdshjiXtfbWCgYcrounmalpxN:sys.exit()
  kGzqRIdshjiXtfbWCgYcrounmalpEw.SpotvObj.Init_ST_Total()
  if os.path.isfile(kGzqRIdshjiXtfbWCgYcrounmalpEx):os.remove(kGzqRIdshjiXtfbWCgYcrounmalpEx)
  kGzqRIdshjiXtfbWCgYcrounmalpEw.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(kGzqRIdshjiXtfbWCgYcrounmalpEw):
  kGzqRIdshjiXtfbWCgYcrounmalpyD =kGzqRIdshjiXtfbWCgYcrounmalpEw.SpotvObj.Get_Now_Datetime()
  kGzqRIdshjiXtfbWCgYcrounmalpyU=kGzqRIdshjiXtfbWCgYcrounmalpyD+datetime.timedelta(days=kGzqRIdshjiXtfbWCgYcrounmalpwy(__addon__.getSetting('cache_ttl')))
  (kGzqRIdshjiXtfbWCgYcrounmalpBM,kGzqRIdshjiXtfbWCgYcrounmalpBP)=kGzqRIdshjiXtfbWCgYcrounmalpEw.get_settings_account()
  kGzqRIdshjiXtfbWCgYcrounmalpEw.SpotvObj.Save_session_acount(kGzqRIdshjiXtfbWCgYcrounmalpBM,kGzqRIdshjiXtfbWCgYcrounmalpBP)
  kGzqRIdshjiXtfbWCgYcrounmalpEw.SpotvObj.ST['account']['token_limit']=kGzqRIdshjiXtfbWCgYcrounmalpyU.strftime('%Y%m%d')
  kGzqRIdshjiXtfbWCgYcrounmalpEw.SpotvObj.JsonFile_Save(kGzqRIdshjiXtfbWCgYcrounmalpEx,kGzqRIdshjiXtfbWCgYcrounmalpEw.SpotvObj.ST)
 def cookiefile_check(kGzqRIdshjiXtfbWCgYcrounmalpEw):
  kGzqRIdshjiXtfbWCgYcrounmalpEw.SpotvObj.ST=kGzqRIdshjiXtfbWCgYcrounmalpEw.SpotvObj.JsonFile_Load(kGzqRIdshjiXtfbWCgYcrounmalpEx)
  if 'account' not in kGzqRIdshjiXtfbWCgYcrounmalpEw.SpotvObj.ST:
   kGzqRIdshjiXtfbWCgYcrounmalpEw.SpotvObj.Init_ST_Total()
   return kGzqRIdshjiXtfbWCgYcrounmalpxN
  (kGzqRIdshjiXtfbWCgYcrounmalpyK,kGzqRIdshjiXtfbWCgYcrounmalpyO)=kGzqRIdshjiXtfbWCgYcrounmalpEw.get_settings_account()
  (kGzqRIdshjiXtfbWCgYcrounmalpyF,kGzqRIdshjiXtfbWCgYcrounmalpyM)=kGzqRIdshjiXtfbWCgYcrounmalpEw.SpotvObj.Load_session_acount()
  if kGzqRIdshjiXtfbWCgYcrounmalpyK!=kGzqRIdshjiXtfbWCgYcrounmalpyF or kGzqRIdshjiXtfbWCgYcrounmalpyO!=kGzqRIdshjiXtfbWCgYcrounmalpyM:
   kGzqRIdshjiXtfbWCgYcrounmalpEw.SpotvObj.Init_ST_Total()
   return kGzqRIdshjiXtfbWCgYcrounmalpxN
  if kGzqRIdshjiXtfbWCgYcrounmalpwy(kGzqRIdshjiXtfbWCgYcrounmalpEw.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))>kGzqRIdshjiXtfbWCgYcrounmalpwy(kGzqRIdshjiXtfbWCgYcrounmalpEw.SpotvObj.ST['account']['token_limit']):
   kGzqRIdshjiXtfbWCgYcrounmalpEw.SpotvObj.Init_ST_Total()
   return kGzqRIdshjiXtfbWCgYcrounmalpxN
  return kGzqRIdshjiXtfbWCgYcrounmalpwE
 def dp_History_Remove(kGzqRIdshjiXtfbWCgYcrounmalpEw,args):
  kGzqRIdshjiXtfbWCgYcrounmalpyP=args.get('delType')
  kGzqRIdshjiXtfbWCgYcrounmalpyQ =args.get('sKey')
  kGzqRIdshjiXtfbWCgYcrounmalpyN =args.get('vType')
  kGzqRIdshjiXtfbWCgYcrounmalpEA=xbmcgui.Dialog()
  if kGzqRIdshjiXtfbWCgYcrounmalpyP=='WATCH_ALL':
   kGzqRIdshjiXtfbWCgYcrounmalpBQ=kGzqRIdshjiXtfbWCgYcrounmalpEA.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif kGzqRIdshjiXtfbWCgYcrounmalpyP=='WATCH_ONE':
   kGzqRIdshjiXtfbWCgYcrounmalpBQ=kGzqRIdshjiXtfbWCgYcrounmalpEA.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  if kGzqRIdshjiXtfbWCgYcrounmalpBQ==kGzqRIdshjiXtfbWCgYcrounmalpxN:sys.exit()
  if kGzqRIdshjiXtfbWCgYcrounmalpyP=='WATCH_ALL':
   kGzqRIdshjiXtfbWCgYcrounmalpxE=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%kGzqRIdshjiXtfbWCgYcrounmalpyN))
   if os.path.isfile(kGzqRIdshjiXtfbWCgYcrounmalpxE):os.remove(kGzqRIdshjiXtfbWCgYcrounmalpxE)
  elif kGzqRIdshjiXtfbWCgYcrounmalpyP=='WATCH_ONE':
   kGzqRIdshjiXtfbWCgYcrounmalpxE=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%kGzqRIdshjiXtfbWCgYcrounmalpyN))
   try:
    kGzqRIdshjiXtfbWCgYcrounmalpxJ=kGzqRIdshjiXtfbWCgYcrounmalpEw.Load_List_File(kGzqRIdshjiXtfbWCgYcrounmalpyN) 
    fp=kGzqRIdshjiXtfbWCgYcrounmalpwL(kGzqRIdshjiXtfbWCgYcrounmalpxE,'w',-1,'utf-8')
    for kGzqRIdshjiXtfbWCgYcrounmalpxB in kGzqRIdshjiXtfbWCgYcrounmalpxJ:
     kGzqRIdshjiXtfbWCgYcrounmalpxy=kGzqRIdshjiXtfbWCgYcrounmalpwA(urllib.parse.parse_qsl(kGzqRIdshjiXtfbWCgYcrounmalpxB))
     kGzqRIdshjiXtfbWCgYcrounmalpxw=kGzqRIdshjiXtfbWCgYcrounmalpxy.get('code').strip()
     if kGzqRIdshjiXtfbWCgYcrounmalpyQ!=kGzqRIdshjiXtfbWCgYcrounmalpxw:
      fp.write(kGzqRIdshjiXtfbWCgYcrounmalpxB)
    fp.close()
   except:
    kGzqRIdshjiXtfbWCgYcrounmalpxQ
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(kGzqRIdshjiXtfbWCgYcrounmalpEw,kGzqRIdshjiXtfbWCgYcrounmalpyL):
  try:
   kGzqRIdshjiXtfbWCgYcrounmalpxH=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%kGzqRIdshjiXtfbWCgYcrounmalpyL))
   fp=kGzqRIdshjiXtfbWCgYcrounmalpwL(kGzqRIdshjiXtfbWCgYcrounmalpxH,'r',-1,'utf-8')
   kGzqRIdshjiXtfbWCgYcrounmalpxS=fp.readlines()
   fp.close()
  except:
   kGzqRIdshjiXtfbWCgYcrounmalpxS=[]
  return kGzqRIdshjiXtfbWCgYcrounmalpxS
 def Save_Watched_List(kGzqRIdshjiXtfbWCgYcrounmalpEw,stype,kGzqRIdshjiXtfbWCgYcrounmalpET):
  try:
   kGzqRIdshjiXtfbWCgYcrounmalpxH=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   kGzqRIdshjiXtfbWCgYcrounmalpxJ=kGzqRIdshjiXtfbWCgYcrounmalpEw.Load_List_File(stype) 
   fp=kGzqRIdshjiXtfbWCgYcrounmalpwL(kGzqRIdshjiXtfbWCgYcrounmalpxH,'w',-1,'utf-8')
   kGzqRIdshjiXtfbWCgYcrounmalpxT=urllib.parse.urlencode(kGzqRIdshjiXtfbWCgYcrounmalpET)
   kGzqRIdshjiXtfbWCgYcrounmalpxT=kGzqRIdshjiXtfbWCgYcrounmalpxT+'\n'
   fp.write(kGzqRIdshjiXtfbWCgYcrounmalpxT)
   kGzqRIdshjiXtfbWCgYcrounmalpxL=0
   for kGzqRIdshjiXtfbWCgYcrounmalpxB in kGzqRIdshjiXtfbWCgYcrounmalpxJ:
    kGzqRIdshjiXtfbWCgYcrounmalpxy=kGzqRIdshjiXtfbWCgYcrounmalpwA(urllib.parse.parse_qsl(kGzqRIdshjiXtfbWCgYcrounmalpxB))
    kGzqRIdshjiXtfbWCgYcrounmalpxA=kGzqRIdshjiXtfbWCgYcrounmalpET.get('code')
    kGzqRIdshjiXtfbWCgYcrounmalpxV=kGzqRIdshjiXtfbWCgYcrounmalpxy.get('code')
    if kGzqRIdshjiXtfbWCgYcrounmalpxA!=kGzqRIdshjiXtfbWCgYcrounmalpxV:
     fp.write(kGzqRIdshjiXtfbWCgYcrounmalpxB)
     kGzqRIdshjiXtfbWCgYcrounmalpxL+=1
     if kGzqRIdshjiXtfbWCgYcrounmalpxL>=50:break
   fp.close()
  except:
   kGzqRIdshjiXtfbWCgYcrounmalpxQ
 def dp_Watch_List(kGzqRIdshjiXtfbWCgYcrounmalpEw,args):
  kGzqRIdshjiXtfbWCgYcrounmalpyL ='vod'
  if kGzqRIdshjiXtfbWCgYcrounmalpyL=='vod':
   kGzqRIdshjiXtfbWCgYcrounmalpxv=kGzqRIdshjiXtfbWCgYcrounmalpEw.Load_List_File(kGzqRIdshjiXtfbWCgYcrounmalpyL)
   for kGzqRIdshjiXtfbWCgYcrounmalpxe in kGzqRIdshjiXtfbWCgYcrounmalpxv:
    kGzqRIdshjiXtfbWCgYcrounmalpxD=kGzqRIdshjiXtfbWCgYcrounmalpwA(urllib.parse.parse_qsl(kGzqRIdshjiXtfbWCgYcrounmalpxe))
    kGzqRIdshjiXtfbWCgYcrounmalpEF =kGzqRIdshjiXtfbWCgYcrounmalpxD.get('title')
    kGzqRIdshjiXtfbWCgYcrounmalpJv=kGzqRIdshjiXtfbWCgYcrounmalpxD.get('img')
    kGzqRIdshjiXtfbWCgYcrounmalpyT=kGzqRIdshjiXtfbWCgYcrounmalpxD.get('code')
    kGzqRIdshjiXtfbWCgYcrounmalpxU =kGzqRIdshjiXtfbWCgYcrounmalpxD.get('info')
    kGzqRIdshjiXtfbWCgYcrounmalpJU={}
    kGzqRIdshjiXtfbWCgYcrounmalpJU['plot'] =kGzqRIdshjiXtfbWCgYcrounmalpxU
    kGzqRIdshjiXtfbWCgYcrounmalpJU['mediatype']='tvshow'
    kGzqRIdshjiXtfbWCgYcrounmalpJw={'mode':'GAME_VOD_GROUP','gameid':kGzqRIdshjiXtfbWCgYcrounmalpyT,'saveTitle':kGzqRIdshjiXtfbWCgYcrounmalpEF,'saveImg':kGzqRIdshjiXtfbWCgYcrounmalpJv,'saveInfo':kGzqRIdshjiXtfbWCgYcrounmalpxU,'mediatype':kGzqRIdshjiXtfbWCgYcrounmalpyL}
    kGzqRIdshjiXtfbWCgYcrounmalpxK={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':kGzqRIdshjiXtfbWCgYcrounmalpyT,'vType':kGzqRIdshjiXtfbWCgYcrounmalpyL,}
    kGzqRIdshjiXtfbWCgYcrounmalpxO=urllib.parse.urlencode(kGzqRIdshjiXtfbWCgYcrounmalpxK)
    kGzqRIdshjiXtfbWCgYcrounmalpxF=[('선택된 시청이력 ( %s ) 삭제'%(kGzqRIdshjiXtfbWCgYcrounmalpEF),'RunPlugin(plugin://plugin.video.spotvm/?%s)'%(kGzqRIdshjiXtfbWCgYcrounmalpxO))]
    kGzqRIdshjiXtfbWCgYcrounmalpEw.add_dir(kGzqRIdshjiXtfbWCgYcrounmalpEF,sublabel='',img=kGzqRIdshjiXtfbWCgYcrounmalpJv,infoLabels=kGzqRIdshjiXtfbWCgYcrounmalpJU,isFolder=kGzqRIdshjiXtfbWCgYcrounmalpwE,params=kGzqRIdshjiXtfbWCgYcrounmalpJw,ContextMenu=kGzqRIdshjiXtfbWCgYcrounmalpxF)
   kGzqRIdshjiXtfbWCgYcrounmalpJU={'plot':'시청목록을 삭제합니다.'}
   kGzqRIdshjiXtfbWCgYcrounmalpEF='*** 시청목록 삭제 ***'
   kGzqRIdshjiXtfbWCgYcrounmalpJw={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':kGzqRIdshjiXtfbWCgYcrounmalpyL,}
   kGzqRIdshjiXtfbWCgYcrounmalpJx=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   kGzqRIdshjiXtfbWCgYcrounmalpEw.add_dir(kGzqRIdshjiXtfbWCgYcrounmalpEF,sublabel='',img=kGzqRIdshjiXtfbWCgYcrounmalpJx,infoLabels=kGzqRIdshjiXtfbWCgYcrounmalpJU,isFolder=kGzqRIdshjiXtfbWCgYcrounmalpxN,params=kGzqRIdshjiXtfbWCgYcrounmalpJw,isLink=kGzqRIdshjiXtfbWCgYcrounmalpwE)
   xbmcplugin.endOfDirectory(kGzqRIdshjiXtfbWCgYcrounmalpEw._addon_handle,cacheToDisc=kGzqRIdshjiXtfbWCgYcrounmalpxN)
 def spotv_main(kGzqRIdshjiXtfbWCgYcrounmalpEw):
  kGzqRIdshjiXtfbWCgYcrounmalpEw.SpotvObj.KodiVersion=kGzqRIdshjiXtfbWCgYcrounmalpwy(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  kGzqRIdshjiXtfbWCgYcrounmalpxM=kGzqRIdshjiXtfbWCgYcrounmalpEw.main_params.get('mode',kGzqRIdshjiXtfbWCgYcrounmalpxQ)
  if kGzqRIdshjiXtfbWCgYcrounmalpxM=='LOGOUT':
   kGzqRIdshjiXtfbWCgYcrounmalpEw.logout()
   return
  kGzqRIdshjiXtfbWCgYcrounmalpEw.login_main()
  if kGzqRIdshjiXtfbWCgYcrounmalpxM is kGzqRIdshjiXtfbWCgYcrounmalpxQ:
   kGzqRIdshjiXtfbWCgYcrounmalpEw.dp_Main_List()
  elif kGzqRIdshjiXtfbWCgYcrounmalpxM=='LIVE_GROUP':
   kGzqRIdshjiXtfbWCgYcrounmalpEw.dp_LiveChannel_List(kGzqRIdshjiXtfbWCgYcrounmalpEw.main_params)
  elif kGzqRIdshjiXtfbWCgYcrounmalpxM=='ELIVE_GROUP':
   kGzqRIdshjiXtfbWCgYcrounmalpyH=kGzqRIdshjiXtfbWCgYcrounmalpEw.dp_EventLiveChannel_List(kGzqRIdshjiXtfbWCgYcrounmalpEw.main_params)
   if kGzqRIdshjiXtfbWCgYcrounmalpyH==401:
    if os.path.isfile(kGzqRIdshjiXtfbWCgYcrounmalpEx):os.remove(kGzqRIdshjiXtfbWCgYcrounmalpEx)
    kGzqRIdshjiXtfbWCgYcrounmalpEw.login_main()
    kGzqRIdshjiXtfbWCgYcrounmalpEw.dp_EventLiveChannel_List(kGzqRIdshjiXtfbWCgYcrounmalpEw.main_params)
  elif kGzqRIdshjiXtfbWCgYcrounmalpxM in['LIVE','GAME_VOD','POP_VOD','NOW_VOD','ELIVE']:
   kGzqRIdshjiXtfbWCgYcrounmalpEw.play_VIDEO(kGzqRIdshjiXtfbWCgYcrounmalpEw.main_params)
  elif kGzqRIdshjiXtfbWCgYcrounmalpxM=='VOD_GROUP':
   kGzqRIdshjiXtfbWCgYcrounmalpEw.dp_MainLeague_List(kGzqRIdshjiXtfbWCgYcrounmalpEw.main_params)
  elif kGzqRIdshjiXtfbWCgYcrounmalpxM=='NOW_GROUP':
   kGzqRIdshjiXtfbWCgYcrounmalpEw.dp_NowVod_GroupList(kGzqRIdshjiXtfbWCgYcrounmalpEw.main_params)
  elif kGzqRIdshjiXtfbWCgYcrounmalpxM=='POP_GROUP':
   kGzqRIdshjiXtfbWCgYcrounmalpEw.dp_PopVod_GroupList(kGzqRIdshjiXtfbWCgYcrounmalpEw.main_params)
  elif kGzqRIdshjiXtfbWCgYcrounmalpxM=='LEAGUE_GROUP':
   kGzqRIdshjiXtfbWCgYcrounmalpEw.dp_Season_List(kGzqRIdshjiXtfbWCgYcrounmalpEw.main_params)
  elif kGzqRIdshjiXtfbWCgYcrounmalpxM=='SEASON_GROUP':
   kGzqRIdshjiXtfbWCgYcrounmalpEw.dp_Game_List(kGzqRIdshjiXtfbWCgYcrounmalpEw.main_params)
  elif kGzqRIdshjiXtfbWCgYcrounmalpxM=='GAME_VOD_GROUP':
   kGzqRIdshjiXtfbWCgYcrounmalpEw.dp_GameVod_List(kGzqRIdshjiXtfbWCgYcrounmalpEw.main_params)
  elif kGzqRIdshjiXtfbWCgYcrounmalpxM=='WATCH':
   kGzqRIdshjiXtfbWCgYcrounmalpEw.dp_Watch_List(kGzqRIdshjiXtfbWCgYcrounmalpEw.main_params)
  elif kGzqRIdshjiXtfbWCgYcrounmalpxM=='MYVIEW_REMOVE':
   kGzqRIdshjiXtfbWCgYcrounmalpEw.dp_History_Remove(kGzqRIdshjiXtfbWCgYcrounmalpEw.main_params)
  else:
   kGzqRIdshjiXtfbWCgYcrounmalpxQ
# Created by pyminifier (https://github.com/liftoff/pyminifier)
