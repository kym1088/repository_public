__author__="NightRain"
eFGpKEulRDmPsrkUQfhXwotdWJLHba=object
eFGpKEulRDmPsrkUQfhXwotdWJLHbg=None
eFGpKEulRDmPsrkUQfhXwotdWJLHbq=False
eFGpKEulRDmPsrkUQfhXwotdWJLHbS=open
eFGpKEulRDmPsrkUQfhXwotdWJLHbO=True
eFGpKEulRDmPsrkUQfhXwotdWJLHbv=int
eFGpKEulRDmPsrkUQfhXwotdWJLHbY=Exception
eFGpKEulRDmPsrkUQfhXwotdWJLHbx=print
eFGpKEulRDmPsrkUQfhXwotdWJLHbV=str
eFGpKEulRDmPsrkUQfhXwotdWJLHbT=len
eFGpKEulRDmPsrkUQfhXwotdWJLHMn=range
import urllib
import re
import json
import sys
import time
import requests
import datetime
import base64
import random
eFGpKEulRDmPsrkUQfhXwotdWJLHnB={'stream50':1080,'stream40':720,'stream30':540}
class eFGpKEulRDmPsrkUQfhXwotdWJLHnc(eFGpKEulRDmPsrkUQfhXwotdWJLHba):
 def __init__(eFGpKEulRDmPsrkUQfhXwotdWJLHnN):
  eFGpKEulRDmPsrkUQfhXwotdWJLHnN.SPOTV_PMCODE ='987'
  eFGpKEulRDmPsrkUQfhXwotdWJLHnN.SPOTV_PMSIZE =3
  eFGpKEulRDmPsrkUQfhXwotdWJLHnN.GAMELIST_LIMIT =10
  eFGpKEulRDmPsrkUQfhXwotdWJLHnN.API_DOMAIN ='https://www.spotvnow.co.kr'
  eFGpKEulRDmPsrkUQfhXwotdWJLHnN.BC_DOMAIN ='https://players.brightcove.net'
  eFGpKEulRDmPsrkUQfhXwotdWJLHnN.PLAYER_DOMAIN ='https://edge.api.brightcove.com'
  eFGpKEulRDmPsrkUQfhXwotdWJLHnN.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36'
  eFGpKEulRDmPsrkUQfhXwotdWJLHnN.DEFAULT_HEADER ={'user-agent':eFGpKEulRDmPsrkUQfhXwotdWJLHnN.USER_AGENT}
  eFGpKEulRDmPsrkUQfhXwotdWJLHnN.COOKIE_FILE_NAME=''
  eFGpKEulRDmPsrkUQfhXwotdWJLHnN.KodiVersion =20
  eFGpKEulRDmPsrkUQfhXwotdWJLHnN.ST ={}
  eFGpKEulRDmPsrkUQfhXwotdWJLHnN.Init_ST_Total()
 def Init_ST_Total(eFGpKEulRDmPsrkUQfhXwotdWJLHnN):
  eFGpKEulRDmPsrkUQfhXwotdWJLHnN.ST={'account':{},'cookies':{},}
 def callRequestCookies(eFGpKEulRDmPsrkUQfhXwotdWJLHnN,jobtype,eFGpKEulRDmPsrkUQfhXwotdWJLHnq,payload=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,json=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,params=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,headers=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,cookies=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,redirects=eFGpKEulRDmPsrkUQfhXwotdWJLHbq):
  eFGpKEulRDmPsrkUQfhXwotdWJLHnb=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.DEFAULT_HEADER
  if headers:eFGpKEulRDmPsrkUQfhXwotdWJLHnb.update(headers)
  if jobtype=='Get':
   eFGpKEulRDmPsrkUQfhXwotdWJLHnM=requests.get(eFGpKEulRDmPsrkUQfhXwotdWJLHnq,params=params,headers=eFGpKEulRDmPsrkUQfhXwotdWJLHnb,cookies=cookies,allow_redirects=redirects)
  else:
   eFGpKEulRDmPsrkUQfhXwotdWJLHnM=requests.post(eFGpKEulRDmPsrkUQfhXwotdWJLHnq,data=payload,json=json,params=params,headers=eFGpKEulRDmPsrkUQfhXwotdWJLHnb,cookies=cookies,allow_redirects=redirects)
  return eFGpKEulRDmPsrkUQfhXwotdWJLHnM
 def JsonFile_Save(eFGpKEulRDmPsrkUQfhXwotdWJLHnN,filename,eFGpKEulRDmPsrkUQfhXwotdWJLHnI):
  if filename=='':return eFGpKEulRDmPsrkUQfhXwotdWJLHbq
  try:
   fp=eFGpKEulRDmPsrkUQfhXwotdWJLHbS(filename,'w',-1,'utf-8')
   json.dump(eFGpKEulRDmPsrkUQfhXwotdWJLHnI,fp,indent=4,ensure_ascii=eFGpKEulRDmPsrkUQfhXwotdWJLHbq)
   fp.close()
  except:
   return eFGpKEulRDmPsrkUQfhXwotdWJLHbq
  return eFGpKEulRDmPsrkUQfhXwotdWJLHbO
 def JsonFile_Load(eFGpKEulRDmPsrkUQfhXwotdWJLHnN,filename):
  if filename=='':return{}
  try:
   fp=eFGpKEulRDmPsrkUQfhXwotdWJLHbS(filename,'r',-1,'utf-8')
   eFGpKEulRDmPsrkUQfhXwotdWJLHni=json.load(fp)
   fp.close()
  except:
   return{}
  return eFGpKEulRDmPsrkUQfhXwotdWJLHni
 def Save_session_acount(eFGpKEulRDmPsrkUQfhXwotdWJLHnN,eFGpKEulRDmPsrkUQfhXwotdWJLHnA,eFGpKEulRDmPsrkUQfhXwotdWJLHny):
  eFGpKEulRDmPsrkUQfhXwotdWJLHnN.ST['account']['stid'] =base64.standard_b64encode(eFGpKEulRDmPsrkUQfhXwotdWJLHnA.encode()).decode('utf-8')
  eFGpKEulRDmPsrkUQfhXwotdWJLHnN.ST['account']['stpw'] =base64.standard_b64encode(eFGpKEulRDmPsrkUQfhXwotdWJLHny.encode()).decode('utf-8')
 def Load_session_acount(eFGpKEulRDmPsrkUQfhXwotdWJLHnN):
  try:
   eFGpKEulRDmPsrkUQfhXwotdWJLHnA =base64.standard_b64decode(eFGpKEulRDmPsrkUQfhXwotdWJLHnN.ST['account']['stid']).decode('utf-8')
   eFGpKEulRDmPsrkUQfhXwotdWJLHny =base64.standard_b64decode(eFGpKEulRDmPsrkUQfhXwotdWJLHnN.ST['account']['stpw']).decode('utf-8')
  except:
   return '',''
  return eFGpKEulRDmPsrkUQfhXwotdWJLHnA,eFGpKEulRDmPsrkUQfhXwotdWJLHny
 def makeDefaultCookies(eFGpKEulRDmPsrkUQfhXwotdWJLHnN):
  eFGpKEulRDmPsrkUQfhXwotdWJLHnC={'id_token':eFGpKEulRDmPsrkUQfhXwotdWJLHnN.ST['cookies']['id_token']}
  return eFGpKEulRDmPsrkUQfhXwotdWJLHnC
 def makeDefaultHeaders(eFGpKEulRDmPsrkUQfhXwotdWJLHnN):
  eFGpKEulRDmPsrkUQfhXwotdWJLHnz={'accept':'application/json;pk={}'.format(eFGpKEulRDmPsrkUQfhXwotdWJLHnN.ST['cookies']['spotv_policyKey'])}
  return eFGpKEulRDmPsrkUQfhXwotdWJLHnz
 def xmlText(eFGpKEulRDmPsrkUQfhXwotdWJLHnN,in_text):
  eFGpKEulRDmPsrkUQfhXwotdWJLHna=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;')
  return eFGpKEulRDmPsrkUQfhXwotdWJLHna
 def GetNoCache(eFGpKEulRDmPsrkUQfhXwotdWJLHnN,timetype=1):
  if timetype==1:
   return eFGpKEulRDmPsrkUQfhXwotdWJLHbv(time.time())
  else:
   return eFGpKEulRDmPsrkUQfhXwotdWJLHbv(time.time()*1000)
 def GetCredential_new(eFGpKEulRDmPsrkUQfhXwotdWJLHnN,user_id,user_pw):
  eFGpKEulRDmPsrkUQfhXwotdWJLHng=requests.session()
  try:
   eFGpKEulRDmPsrkUQfhXwotdWJLHnq='https://nid.spotvnow.co.kr/api/v3/oauth2/authorize/spotvnow?return_url=https%3A%2F%2Fwww.spotvnow.co.kr%2Fcheck&err_return_url=https%3A%2F%2Fwww.spotvnow.co.kr%2Fabout&logout_url=https%3A%2F%2Fwww.spotvnow.co.kr%2Fintro'
   eFGpKEulRDmPsrkUQfhXwotdWJLHnz={'User-Agent':eFGpKEulRDmPsrkUQfhXwotdWJLHnN.USER_AGENT,}
   while(eFGpKEulRDmPsrkUQfhXwotdWJLHnq not in['',eFGpKEulRDmPsrkUQfhXwotdWJLHbg]):
    eFGpKEulRDmPsrkUQfhXwotdWJLHnS=eFGpKEulRDmPsrkUQfhXwotdWJLHng.get(eFGpKEulRDmPsrkUQfhXwotdWJLHnq,params=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,headers=eFGpKEulRDmPsrkUQfhXwotdWJLHnz,cookies=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.ST['cookies'],allow_redirects=eFGpKEulRDmPsrkUQfhXwotdWJLHbq)
    eFGpKEulRDmPsrkUQfhXwotdWJLHnq =eFGpKEulRDmPsrkUQfhXwotdWJLHnS.headers.get('location')
    for eFGpKEulRDmPsrkUQfhXwotdWJLHnO in eFGpKEulRDmPsrkUQfhXwotdWJLHnS.cookies:
     if eFGpKEulRDmPsrkUQfhXwotdWJLHnO.value not in['',eFGpKEulRDmPsrkUQfhXwotdWJLHbg]:
      eFGpKEulRDmPsrkUQfhXwotdWJLHnN.ST['cookies'][eFGpKEulRDmPsrkUQfhXwotdWJLHnO.name]=eFGpKEulRDmPsrkUQfhXwotdWJLHnO.value
    if eFGpKEulRDmPsrkUQfhXwotdWJLHnS.status_code==200:break
   if eFGpKEulRDmPsrkUQfhXwotdWJLHnN.ST['cookies']['login_challenge']=='':
    eFGpKEulRDmPsrkUQfhXwotdWJLHnN.Init_ST_Total()
    return eFGpKEulRDmPsrkUQfhXwotdWJLHbq
  except eFGpKEulRDmPsrkUQfhXwotdWJLHbY as exception:
   eFGpKEulRDmPsrkUQfhXwotdWJLHbx(exception)
   eFGpKEulRDmPsrkUQfhXwotdWJLHnN.Init_ST_Total()
   return eFGpKEulRDmPsrkUQfhXwotdWJLHbq
  try:
   eFGpKEulRDmPsrkUQfhXwotdWJLHnv=base64.standard_b64encode(user_id.encode('UTF-8')).decode('utf-8')
   eFGpKEulRDmPsrkUQfhXwotdWJLHnY=base64.standard_b64encode(user_pw.encode('UTF-8')).decode('utf-8')
   eFGpKEulRDmPsrkUQfhXwotdWJLHnq='https://nid.spotvnow.co.kr/api/v3/user-auth/login'
   eFGpKEulRDmPsrkUQfhXwotdWJLHnz={'User-Agent':eFGpKEulRDmPsrkUQfhXwotdWJLHnN.USER_AGENT,}
   eFGpKEulRDmPsrkUQfhXwotdWJLHnx={'username':eFGpKEulRDmPsrkUQfhXwotdWJLHnv,'password':eFGpKEulRDmPsrkUQfhXwotdWJLHnY,'remember':eFGpKEulRDmPsrkUQfhXwotdWJLHbO,'err_return_url':'https://www.spotvnow.co.kr/intro',}
   eFGpKEulRDmPsrkUQfhXwotdWJLHnS=eFGpKEulRDmPsrkUQfhXwotdWJLHng.post(eFGpKEulRDmPsrkUQfhXwotdWJLHnq,data=eFGpKEulRDmPsrkUQfhXwotdWJLHnx,params=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,headers=eFGpKEulRDmPsrkUQfhXwotdWJLHnz,cookies=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.ST['cookies'],allow_redirects=eFGpKEulRDmPsrkUQfhXwotdWJLHbq)
   for eFGpKEulRDmPsrkUQfhXwotdWJLHnO in eFGpKEulRDmPsrkUQfhXwotdWJLHnS.cookies:
    if eFGpKEulRDmPsrkUQfhXwotdWJLHnO.value not in['',eFGpKEulRDmPsrkUQfhXwotdWJLHbg]:
     eFGpKEulRDmPsrkUQfhXwotdWJLHnN.ST['cookies'][eFGpKEulRDmPsrkUQfhXwotdWJLHnO.name]=eFGpKEulRDmPsrkUQfhXwotdWJLHnO.value
   eFGpKEulRDmPsrkUQfhXwotdWJLHnq=eFGpKEulRDmPsrkUQfhXwotdWJLHnS.headers.get('location')
   while(eFGpKEulRDmPsrkUQfhXwotdWJLHnq not in['',eFGpKEulRDmPsrkUQfhXwotdWJLHbg]):
    eFGpKEulRDmPsrkUQfhXwotdWJLHnz={'user-agent':eFGpKEulRDmPsrkUQfhXwotdWJLHnN.USER_AGENT,}
    eFGpKEulRDmPsrkUQfhXwotdWJLHnS=eFGpKEulRDmPsrkUQfhXwotdWJLHng.get(eFGpKEulRDmPsrkUQfhXwotdWJLHnq,params=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,headers=eFGpKEulRDmPsrkUQfhXwotdWJLHnz,cookies=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.ST['cookies'],allow_redirects=eFGpKEulRDmPsrkUQfhXwotdWJLHbq)
    eFGpKEulRDmPsrkUQfhXwotdWJLHnq =eFGpKEulRDmPsrkUQfhXwotdWJLHnS.headers.get('location')
    for eFGpKEulRDmPsrkUQfhXwotdWJLHnO in eFGpKEulRDmPsrkUQfhXwotdWJLHnS.cookies:
     if eFGpKEulRDmPsrkUQfhXwotdWJLHnO.value not in['',eFGpKEulRDmPsrkUQfhXwotdWJLHbg]:
      eFGpKEulRDmPsrkUQfhXwotdWJLHnN.ST['cookies'][eFGpKEulRDmPsrkUQfhXwotdWJLHnO.name]=eFGpKEulRDmPsrkUQfhXwotdWJLHnO.value
    if eFGpKEulRDmPsrkUQfhXwotdWJLHnS.status_code==200:break
   if eFGpKEulRDmPsrkUQfhXwotdWJLHnN.ST['cookies']['id_token']=='':
    eFGpKEulRDmPsrkUQfhXwotdWJLHnN.Init_ST_Total()
    return eFGpKEulRDmPsrkUQfhXwotdWJLHbq
  except eFGpKEulRDmPsrkUQfhXwotdWJLHbY as exception:
   eFGpKEulRDmPsrkUQfhXwotdWJLHbx(exception)
   eFGpKEulRDmPsrkUQfhXwotdWJLHnN.Init_ST_Total()
   return eFGpKEulRDmPsrkUQfhXwotdWJLHbq
  try:
   eFGpKEulRDmPsrkUQfhXwotdWJLHnq=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.API_DOMAIN+'/api/v3/session' 
   eFGpKEulRDmPsrkUQfhXwotdWJLHnC=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.makeDefaultCookies()
   eFGpKEulRDmPsrkUQfhXwotdWJLHnS=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.callRequestCookies('Get',eFGpKEulRDmPsrkUQfhXwotdWJLHnq,params=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,headers=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,cookies=eFGpKEulRDmPsrkUQfhXwotdWJLHnC)
   eFGpKEulRDmPsrkUQfhXwotdWJLHnV=json.loads(eFGpKEulRDmPsrkUQfhXwotdWJLHnS.text)
   eFGpKEulRDmPsrkUQfhXwotdWJLHnN.ST['cookies']['spotv_sessionid']=eFGpKEulRDmPsrkUQfhXwotdWJLHnV.get('userId')
   eFGpKEulRDmPsrkUQfhXwotdWJLHnT=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.SPOTV_PMCODE+eFGpKEulRDmPsrkUQfhXwotdWJLHbV(eFGpKEulRDmPsrkUQfhXwotdWJLHnV['subEndTime'])
   eFGpKEulRDmPsrkUQfhXwotdWJLHnN.ST['cookies']['spotv_subend'] =base64.standard_b64encode(eFGpKEulRDmPsrkUQfhXwotdWJLHnT.encode()).decode('utf-8')
  except eFGpKEulRDmPsrkUQfhXwotdWJLHbY as exception:
   eFGpKEulRDmPsrkUQfhXwotdWJLHbx(exception)
   eFGpKEulRDmPsrkUQfhXwotdWJLHnN.Init_ST_Total()
   return eFGpKEulRDmPsrkUQfhXwotdWJLHbq
  try:
   if eFGpKEulRDmPsrkUQfhXwotdWJLHnV['subEndTime']in[0,'0',eFGpKEulRDmPsrkUQfhXwotdWJLHbg]:
    eFGpKEulRDmPsrkUQfhXwotdWJLHnq=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.API_DOMAIN+'/api/v3/user/sub/scope' 
    eFGpKEulRDmPsrkUQfhXwotdWJLHnC=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.makeDefaultCookies()
    eFGpKEulRDmPsrkUQfhXwotdWJLHnS=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.callRequestCookies('Get',eFGpKEulRDmPsrkUQfhXwotdWJLHnq,params=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,headers=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,cookies=eFGpKEulRDmPsrkUQfhXwotdWJLHnC)
    eFGpKEulRDmPsrkUQfhXwotdWJLHnV=json.loads(eFGpKEulRDmPsrkUQfhXwotdWJLHnS.text)
    if eFGpKEulRDmPsrkUQfhXwotdWJLHnV.get('endDate')==eFGpKEulRDmPsrkUQfhXwotdWJLHbg:
     eFGpKEulRDmPsrkUQfhXwotdWJLHnT=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.SPOTV_PMCODE+'0'
     eFGpKEulRDmPsrkUQfhXwotdWJLHnN.ST['cookies']['spotv_subend'] =base64.standard_b64encode(eFGpKEulRDmPsrkUQfhXwotdWJLHnT.encode()).decode('utf-8')
    else:
     eFGpKEulRDmPsrkUQfhXwotdWJLHcn=datetime.datetime.strptime(eFGpKEulRDmPsrkUQfhXwotdWJLHnV.get('endDate'),'%Y-%m-%d %H:%M:%S')
     eFGpKEulRDmPsrkUQfhXwotdWJLHnT=eFGpKEulRDmPsrkUQfhXwotdWJLHbv(time.mktime(eFGpKEulRDmPsrkUQfhXwotdWJLHcn.timetuple()))
     eFGpKEulRDmPsrkUQfhXwotdWJLHnT=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.SPOTV_PMCODE+eFGpKEulRDmPsrkUQfhXwotdWJLHbV(eFGpKEulRDmPsrkUQfhXwotdWJLHnT)+'000'
     eFGpKEulRDmPsrkUQfhXwotdWJLHnN.ST['cookies']['spotv_subend'] =base64.standard_b64encode(eFGpKEulRDmPsrkUQfhXwotdWJLHnT.encode()).decode('utf-8')
  except eFGpKEulRDmPsrkUQfhXwotdWJLHbY as exception:
   eFGpKEulRDmPsrkUQfhXwotdWJLHbx(exception)
   eFGpKEulRDmPsrkUQfhXwotdWJLHnN.Init_ST_Total()
   return eFGpKEulRDmPsrkUQfhXwotdWJLHbq
  if eFGpKEulRDmPsrkUQfhXwotdWJLHnN.GetPolicyKey()==eFGpKEulRDmPsrkUQfhXwotdWJLHbq:
   eFGpKEulRDmPsrkUQfhXwotdWJLHnN.Init_ST_Total()
   return eFGpKEulRDmPsrkUQfhXwotdWJLHbq
  '''
  https://players.brightcove.net/5764318566001/2SXVGLGl4_default/index.min.js
    options: {accountId: "5764318566001", policyKey: "BCpkADawqM072_NUcqm8RBVoMGIaio2x979NvYhN4Zrs685jLKKYmCx_ssySm_0HFSnwPKQIbaekH1PnWGFk-nQCtuky-DlMgN4KNvNlPYjsojAi1fU9ozEXVSpULPylDb8STvOgPf-F941V-RbByAkzD8CgApyhBS8TNN-yDc17gnFUj82OEBP8DEo" }  
  '''  
  return eFGpKEulRDmPsrkUQfhXwotdWJLHbO
 def GetCredential(eFGpKEulRDmPsrkUQfhXwotdWJLHnN,user_id,user_pw):
  try:
   eFGpKEulRDmPsrkUQfhXwotdWJLHnv=base64.standard_b64encode(user_id.encode('UTF-8')).decode('utf-8')
   eFGpKEulRDmPsrkUQfhXwotdWJLHnY=base64.standard_b64encode(user_pw.encode('UTF-8')).decode('utf-8')
   eFGpKEulRDmPsrkUQfhXwotdWJLHcB=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.API_DOMAIN+'/api/v2/login'
   eFGpKEulRDmPsrkUQfhXwotdWJLHnx={'username':eFGpKEulRDmPsrkUQfhXwotdWJLHnv,'password':eFGpKEulRDmPsrkUQfhXwotdWJLHnY}
   eFGpKEulRDmPsrkUQfhXwotdWJLHnx=json.dumps(eFGpKEulRDmPsrkUQfhXwotdWJLHnx)
   eFGpKEulRDmPsrkUQfhXwotdWJLHnS=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.callRequestCookies('Post',eFGpKEulRDmPsrkUQfhXwotdWJLHcB,payload=eFGpKEulRDmPsrkUQfhXwotdWJLHnx,params=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,headers=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,cookies=eFGpKEulRDmPsrkUQfhXwotdWJLHbg)
   eFGpKEulRDmPsrkUQfhXwotdWJLHcN=json.loads(eFGpKEulRDmPsrkUQfhXwotdWJLHnS.text)
   for eFGpKEulRDmPsrkUQfhXwotdWJLHnO in eFGpKEulRDmPsrkUQfhXwotdWJLHnS.cookies:
    if eFGpKEulRDmPsrkUQfhXwotdWJLHnO.name=='SESSION':
     eFGpKEulRDmPsrkUQfhXwotdWJLHnN.ST['cookies']['spotv_session']=eFGpKEulRDmPsrkUQfhXwotdWJLHnO.value
     break
   if eFGpKEulRDmPsrkUQfhXwotdWJLHnN.ST['cookies']['spotv_session']=='':
    eFGpKEulRDmPsrkUQfhXwotdWJLHnN.Init_ST_Total()
    return eFGpKEulRDmPsrkUQfhXwotdWJLHbq
   eFGpKEulRDmPsrkUQfhXwotdWJLHnN.ST['cookies']['spotv_sessionid']=eFGpKEulRDmPsrkUQfhXwotdWJLHbV(eFGpKEulRDmPsrkUQfhXwotdWJLHcN['userId'])
   eFGpKEulRDmPsrkUQfhXwotdWJLHnT=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.SPOTV_PMCODE+eFGpKEulRDmPsrkUQfhXwotdWJLHbV(eFGpKEulRDmPsrkUQfhXwotdWJLHcN['subEndTime'])
   eFGpKEulRDmPsrkUQfhXwotdWJLHnN.ST['cookies']['spotv_subend'] =base64.standard_b64encode(eFGpKEulRDmPsrkUQfhXwotdWJLHnT.encode()).decode('utf-8')
   if eFGpKEulRDmPsrkUQfhXwotdWJLHnN.GetPolicyKey()==eFGpKEulRDmPsrkUQfhXwotdWJLHbq:
    eFGpKEulRDmPsrkUQfhXwotdWJLHnN.Init_ST_Total()
    return eFGpKEulRDmPsrkUQfhXwotdWJLHbq
  except eFGpKEulRDmPsrkUQfhXwotdWJLHbY as exception:
   eFGpKEulRDmPsrkUQfhXwotdWJLHbx(exception)
   eFGpKEulRDmPsrkUQfhXwotdWJLHnN.Init_ST_Total()
   return eFGpKEulRDmPsrkUQfhXwotdWJLHbq
  return eFGpKEulRDmPsrkUQfhXwotdWJLHbO
 def GetPolicyKey(eFGpKEulRDmPsrkUQfhXwotdWJLHnN):
  try:
   eFGpKEulRDmPsrkUQfhXwotdWJLHnq=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.GetBcPlayerUrl()
   if eFGpKEulRDmPsrkUQfhXwotdWJLHnq=='':return eFGpKEulRDmPsrkUQfhXwotdWJLHbq
   eFGpKEulRDmPsrkUQfhXwotdWJLHnS=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.callRequestCookies('Get',eFGpKEulRDmPsrkUQfhXwotdWJLHnq,payload=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,params=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,headers=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,cookies=eFGpKEulRDmPsrkUQfhXwotdWJLHbg)
   eFGpKEulRDmPsrkUQfhXwotdWJLHcb=eFGpKEulRDmPsrkUQfhXwotdWJLHnS.text
   eFGpKEulRDmPsrkUQfhXwotdWJLHcM =re.findall('accountId:\s*\"\d{13}\",\s*policyKey:\s*\".[^(){}]{100,300}\"',eFGpKEulRDmPsrkUQfhXwotdWJLHcb)[0]
   eFGpKEulRDmPsrkUQfhXwotdWJLHcM =eFGpKEulRDmPsrkUQfhXwotdWJLHcM.replace('accountId','"accountId"')
   eFGpKEulRDmPsrkUQfhXwotdWJLHcM =eFGpKEulRDmPsrkUQfhXwotdWJLHcM.replace('policyKey','"policyKey"')
   eFGpKEulRDmPsrkUQfhXwotdWJLHcM ='{'+eFGpKEulRDmPsrkUQfhXwotdWJLHcM+'}'
   eFGpKEulRDmPsrkUQfhXwotdWJLHcI=json.loads(eFGpKEulRDmPsrkUQfhXwotdWJLHcM)
   eFGpKEulRDmPsrkUQfhXwotdWJLHnN.ST['cookies']['spotv_accountId']=eFGpKEulRDmPsrkUQfhXwotdWJLHcI['accountId']
   eFGpKEulRDmPsrkUQfhXwotdWJLHnN.ST['cookies']['spotv_policyKey']=eFGpKEulRDmPsrkUQfhXwotdWJLHcI['policyKey']
  except eFGpKEulRDmPsrkUQfhXwotdWJLHbY as exception:
   eFGpKEulRDmPsrkUQfhXwotdWJLHbx(exception)
   return eFGpKEulRDmPsrkUQfhXwotdWJLHbq
  return eFGpKEulRDmPsrkUQfhXwotdWJLHbO
 def GetBcPlayerUrl(eFGpKEulRDmPsrkUQfhXwotdWJLHnN):
  eFGpKEulRDmPsrkUQfhXwotdWJLHcj=''
  try:
   eFGpKEulRDmPsrkUQfhXwotdWJLHnq=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.GetMainJspath()
   if eFGpKEulRDmPsrkUQfhXwotdWJLHnq=='':return eFGpKEulRDmPsrkUQfhXwotdWJLHcj
   eFGpKEulRDmPsrkUQfhXwotdWJLHnS=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.callRequestCookies('Get',eFGpKEulRDmPsrkUQfhXwotdWJLHnq,payload=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,params=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,headers=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,cookies=eFGpKEulRDmPsrkUQfhXwotdWJLHbg)
   eFGpKEulRDmPsrkUQfhXwotdWJLHcb=eFGpKEulRDmPsrkUQfhXwotdWJLHnS.text
   eFGpKEulRDmPsrkUQfhXwotdWJLHci =r'default:{(.*?)}'
   eFGpKEulRDmPsrkUQfhXwotdWJLHcA =re.compile(eFGpKEulRDmPsrkUQfhXwotdWJLHci).findall(eFGpKEulRDmPsrkUQfhXwotdWJLHcb)[0]
   eFGpKEulRDmPsrkUQfhXwotdWJLHcy=r'bc:"(.*?)"'
   eFGpKEulRDmPsrkUQfhXwotdWJLHcC=re.compile(eFGpKEulRDmPsrkUQfhXwotdWJLHcy).findall(eFGpKEulRDmPsrkUQfhXwotdWJLHcA)[0]
   eFGpKEulRDmPsrkUQfhXwotdWJLHcz=r'":"(.*?)"'
   eFGpKEulRDmPsrkUQfhXwotdWJLHca=re.compile(eFGpKEulRDmPsrkUQfhXwotdWJLHcz).findall(eFGpKEulRDmPsrkUQfhXwotdWJLHcA)[0]
   eFGpKEulRDmPsrkUQfhXwotdWJLHcj="%s/%s/%s_default/index.min.js"%(eFGpKEulRDmPsrkUQfhXwotdWJLHnN.BC_DOMAIN,eFGpKEulRDmPsrkUQfhXwotdWJLHcC,eFGpKEulRDmPsrkUQfhXwotdWJLHca)
  except eFGpKEulRDmPsrkUQfhXwotdWJLHbY as exception:
   eFGpKEulRDmPsrkUQfhXwotdWJLHbx(exception)
  return eFGpKEulRDmPsrkUQfhXwotdWJLHcj
 def GetMainJspath(eFGpKEulRDmPsrkUQfhXwotdWJLHnN):
  eFGpKEulRDmPsrkUQfhXwotdWJLHcg=''
  try:
   eFGpKEulRDmPsrkUQfhXwotdWJLHnq=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.API_DOMAIN
   eFGpKEulRDmPsrkUQfhXwotdWJLHnS=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.callRequestCookies('Get',eFGpKEulRDmPsrkUQfhXwotdWJLHnq,payload=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,params=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,headers=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,cookies=eFGpKEulRDmPsrkUQfhXwotdWJLHbg)
   eFGpKEulRDmPsrkUQfhXwotdWJLHcb=eFGpKEulRDmPsrkUQfhXwotdWJLHnS.text
   eFGpKEulRDmPsrkUQfhXwotdWJLHcM =re.findall('https://cdn.spotvnow.co.kr/dist/js/.{20}\.js',eFGpKEulRDmPsrkUQfhXwotdWJLHcb)[0]
   eFGpKEulRDmPsrkUQfhXwotdWJLHcg=eFGpKEulRDmPsrkUQfhXwotdWJLHcM
  except eFGpKEulRDmPsrkUQfhXwotdWJLHbY as exception:
   eFGpKEulRDmPsrkUQfhXwotdWJLHbx(exception)
  return eFGpKEulRDmPsrkUQfhXwotdWJLHcg
 def Get_Now_Datetime(eFGpKEulRDmPsrkUQfhXwotdWJLHnN):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetLiveChannelList(eFGpKEulRDmPsrkUQfhXwotdWJLHnN):
  eFGpKEulRDmPsrkUQfhXwotdWJLHcS=[]
  eFGpKEulRDmPsrkUQfhXwotdWJLHcO ={}
  try:
   eFGpKEulRDmPsrkUQfhXwotdWJLHnq=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.API_DOMAIN+'/api/v3/channel'
   eFGpKEulRDmPsrkUQfhXwotdWJLHnS=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.callRequestCookies('Get',eFGpKEulRDmPsrkUQfhXwotdWJLHnq,payload=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,params=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,headers=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,cookies=eFGpKEulRDmPsrkUQfhXwotdWJLHbg)
   eFGpKEulRDmPsrkUQfhXwotdWJLHcN=json.loads(eFGpKEulRDmPsrkUQfhXwotdWJLHnS.text)
   eFGpKEulRDmPsrkUQfhXwotdWJLHcO=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.GetEPGList()
   for eFGpKEulRDmPsrkUQfhXwotdWJLHcv in eFGpKEulRDmPsrkUQfhXwotdWJLHcN:
    eFGpKEulRDmPsrkUQfhXwotdWJLHcY={'id':eFGpKEulRDmPsrkUQfhXwotdWJLHcv['id'],'name':eFGpKEulRDmPsrkUQfhXwotdWJLHcv['name'],'logo':eFGpKEulRDmPsrkUQfhXwotdWJLHcv['logo'],'free':eFGpKEulRDmPsrkUQfhXwotdWJLHcv['free'],'programName':eFGpKEulRDmPsrkUQfhXwotdWJLHcv['programName'],'channelepg':eFGpKEulRDmPsrkUQfhXwotdWJLHcO.get(eFGpKEulRDmPsrkUQfhXwotdWJLHcv['id']),}
    eFGpKEulRDmPsrkUQfhXwotdWJLHcS.append(eFGpKEulRDmPsrkUQfhXwotdWJLHcY)
  except eFGpKEulRDmPsrkUQfhXwotdWJLHbY as exception:
   eFGpKEulRDmPsrkUQfhXwotdWJLHbx(exception)
  return eFGpKEulRDmPsrkUQfhXwotdWJLHcS
 def GetHlsUrl(eFGpKEulRDmPsrkUQfhXwotdWJLHnN,mediacode):
  eFGpKEulRDmPsrkUQfhXwotdWJLHcx=''
  try:
   eFGpKEulRDmPsrkUQfhXwotdWJLHnq=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.API_DOMAIN+'/api/v3/channel/'+mediacode
   eFGpKEulRDmPsrkUQfhXwotdWJLHnS=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.callRequestCookies('Get',eFGpKEulRDmPsrkUQfhXwotdWJLHnq,payload=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,params=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,headers=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,cookies=eFGpKEulRDmPsrkUQfhXwotdWJLHbg)
   eFGpKEulRDmPsrkUQfhXwotdWJLHcN=json.loads(eFGpKEulRDmPsrkUQfhXwotdWJLHnS.text)
   eFGpKEulRDmPsrkUQfhXwotdWJLHcx=eFGpKEulRDmPsrkUQfhXwotdWJLHcN['hlsUrl']
  except eFGpKEulRDmPsrkUQfhXwotdWJLHbY as exception:
   eFGpKEulRDmPsrkUQfhXwotdWJLHbx(exception)
  return eFGpKEulRDmPsrkUQfhXwotdWJLHcx
 def GetEPGList(eFGpKEulRDmPsrkUQfhXwotdWJLHnN):
  eFGpKEulRDmPsrkUQfhXwotdWJLHcV={}
  eFGpKEulRDmPsrkUQfhXwotdWJLHcT=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.Get_Now_Datetime()
  eFGpKEulRDmPsrkUQfhXwotdWJLHBn=eFGpKEulRDmPsrkUQfhXwotdWJLHcT.strftime('%Y%m%d%H%M')
  eFGpKEulRDmPsrkUQfhXwotdWJLHBc='%s-%s-%s'%(eFGpKEulRDmPsrkUQfhXwotdWJLHBn[0:4],eFGpKEulRDmPsrkUQfhXwotdWJLHBn[4:6],eFGpKEulRDmPsrkUQfhXwotdWJLHBn[6:8])
  eFGpKEulRDmPsrkUQfhXwotdWJLHBN=(eFGpKEulRDmPsrkUQfhXwotdWJLHcT+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M')
  try:
   eFGpKEulRDmPsrkUQfhXwotdWJLHnq=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.API_DOMAIN+'/api/v3/program/'+eFGpKEulRDmPsrkUQfhXwotdWJLHBc
   eFGpKEulRDmPsrkUQfhXwotdWJLHnS=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.callRequestCookies('Get',eFGpKEulRDmPsrkUQfhXwotdWJLHnq,payload=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,params=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,headers=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,cookies=eFGpKEulRDmPsrkUQfhXwotdWJLHbg)
   eFGpKEulRDmPsrkUQfhXwotdWJLHcN=json.loads(eFGpKEulRDmPsrkUQfhXwotdWJLHnS.text)
   eFGpKEulRDmPsrkUQfhXwotdWJLHBb=-1 
   eFGpKEulRDmPsrkUQfhXwotdWJLHBM =''
   for eFGpKEulRDmPsrkUQfhXwotdWJLHcv in eFGpKEulRDmPsrkUQfhXwotdWJLHcN:
    eFGpKEulRDmPsrkUQfhXwotdWJLHBI=eFGpKEulRDmPsrkUQfhXwotdWJLHcv['channelId']
    eFGpKEulRDmPsrkUQfhXwotdWJLHBj =eFGpKEulRDmPsrkUQfhXwotdWJLHcv['startTime'].replace('-','').replace(' ','').replace(':','')
    eFGpKEulRDmPsrkUQfhXwotdWJLHBi =eFGpKEulRDmPsrkUQfhXwotdWJLHcv['endTime'].replace('-','').replace(' ','').replace(':','')
    if eFGpKEulRDmPsrkUQfhXwotdWJLHbv(eFGpKEulRDmPsrkUQfhXwotdWJLHBn)>eFGpKEulRDmPsrkUQfhXwotdWJLHbv(eFGpKEulRDmPsrkUQfhXwotdWJLHBi) :continue
    if eFGpKEulRDmPsrkUQfhXwotdWJLHbv(eFGpKEulRDmPsrkUQfhXwotdWJLHBN)<eFGpKEulRDmPsrkUQfhXwotdWJLHbv(eFGpKEulRDmPsrkUQfhXwotdWJLHBj):continue
    if eFGpKEulRDmPsrkUQfhXwotdWJLHBb!=eFGpKEulRDmPsrkUQfhXwotdWJLHBI:
     if eFGpKEulRDmPsrkUQfhXwotdWJLHBM!='':eFGpKEulRDmPsrkUQfhXwotdWJLHcV[eFGpKEulRDmPsrkUQfhXwotdWJLHBb]=eFGpKEulRDmPsrkUQfhXwotdWJLHBM
     eFGpKEulRDmPsrkUQfhXwotdWJLHBb=eFGpKEulRDmPsrkUQfhXwotdWJLHBI
     eFGpKEulRDmPsrkUQfhXwotdWJLHBM =''
    if eFGpKEulRDmPsrkUQfhXwotdWJLHBM:eFGpKEulRDmPsrkUQfhXwotdWJLHBM+='\n'
    eFGpKEulRDmPsrkUQfhXwotdWJLHBM+=eFGpKEulRDmPsrkUQfhXwotdWJLHcv['title']+'\n'
    eFGpKEulRDmPsrkUQfhXwotdWJLHBM+=' [%s ~ %s]'%(eFGpKEulRDmPsrkUQfhXwotdWJLHcv['startTime'][-5:],eFGpKEulRDmPsrkUQfhXwotdWJLHcv['endTime'][-5:])+'\n'
   if eFGpKEulRDmPsrkUQfhXwotdWJLHBM:eFGpKEulRDmPsrkUQfhXwotdWJLHcV[eFGpKEulRDmPsrkUQfhXwotdWJLHBb]=eFGpKEulRDmPsrkUQfhXwotdWJLHBM
  except eFGpKEulRDmPsrkUQfhXwotdWJLHbY as exception:
   eFGpKEulRDmPsrkUQfhXwotdWJLHbx(exception)
  return eFGpKEulRDmPsrkUQfhXwotdWJLHcV
 def GetEPGList_new(eFGpKEulRDmPsrkUQfhXwotdWJLHnN):
  eFGpKEulRDmPsrkUQfhXwotdWJLHcV={}
  eFGpKEulRDmPsrkUQfhXwotdWJLHcT=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.Get_Now_Datetime()
  eFGpKEulRDmPsrkUQfhXwotdWJLHBn=eFGpKEulRDmPsrkUQfhXwotdWJLHcT.strftime('%Y%m%d%H%M00')
  eFGpKEulRDmPsrkUQfhXwotdWJLHBc='%s%s%s'%(eFGpKEulRDmPsrkUQfhXwotdWJLHBn[0:4],eFGpKEulRDmPsrkUQfhXwotdWJLHBn[4:6],eFGpKEulRDmPsrkUQfhXwotdWJLHBn[6:8])
  eFGpKEulRDmPsrkUQfhXwotdWJLHBN=(eFGpKEulRDmPsrkUQfhXwotdWJLHcT+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M00')
  try:
   for eFGpKEulRDmPsrkUQfhXwotdWJLHcv in LIVETV_LIST:
    eFGpKEulRDmPsrkUQfhXwotdWJLHBA =eFGpKEulRDmPsrkUQfhXwotdWJLHcv['videoId']
    if eFGpKEulRDmPsrkUQfhXwotdWJLHcv['epgtype']=='spotvon':
     eFGpKEulRDmPsrkUQfhXwotdWJLHBM=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.Get_EpgInfo_Spotv_spotvon(eFGpKEulRDmPsrkUQfhXwotdWJLHBA,eFGpKEulRDmPsrkUQfhXwotdWJLHcv['epgnm'],eFGpKEulRDmPsrkUQfhXwotdWJLHBc)
     eFGpKEulRDmPsrkUQfhXwotdWJLHcV[eFGpKEulRDmPsrkUQfhXwotdWJLHBA]=eFGpKEulRDmPsrkUQfhXwotdWJLHBM
    if eFGpKEulRDmPsrkUQfhXwotdWJLHcv['epgtype']=='spotvnet':
     eFGpKEulRDmPsrkUQfhXwotdWJLHBM=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.Get_EpgInfo_Spotv_spotvnet(eFGpKEulRDmPsrkUQfhXwotdWJLHBA,eFGpKEulRDmPsrkUQfhXwotdWJLHcv['epgnm'],eFGpKEulRDmPsrkUQfhXwotdWJLHBc)
     eFGpKEulRDmPsrkUQfhXwotdWJLHcV[eFGpKEulRDmPsrkUQfhXwotdWJLHBA]=eFGpKEulRDmPsrkUQfhXwotdWJLHBM
   for eFGpKEulRDmPsrkUQfhXwotdWJLHBy in eFGpKEulRDmPsrkUQfhXwotdWJLHcV.keys():
    if eFGpKEulRDmPsrkUQfhXwotdWJLHbT(eFGpKEulRDmPsrkUQfhXwotdWJLHcV.get(eFGpKEulRDmPsrkUQfhXwotdWJLHBy))==0:continue
    eFGpKEulRDmPsrkUQfhXwotdWJLHBM =''
    eFGpKEulRDmPsrkUQfhXwotdWJLHBC=''
    for eFGpKEulRDmPsrkUQfhXwotdWJLHBz in eFGpKEulRDmPsrkUQfhXwotdWJLHcV.get(eFGpKEulRDmPsrkUQfhXwotdWJLHBy):
     eFGpKEulRDmPsrkUQfhXwotdWJLHBj =eFGpKEulRDmPsrkUQfhXwotdWJLHBz['startTime']
     eFGpKEulRDmPsrkUQfhXwotdWJLHBi =eFGpKEulRDmPsrkUQfhXwotdWJLHBz['endTime']
     if eFGpKEulRDmPsrkUQfhXwotdWJLHbv(eFGpKEulRDmPsrkUQfhXwotdWJLHBn)>eFGpKEulRDmPsrkUQfhXwotdWJLHbv(eFGpKEulRDmPsrkUQfhXwotdWJLHBi) :continue
     if eFGpKEulRDmPsrkUQfhXwotdWJLHbv(eFGpKEulRDmPsrkUQfhXwotdWJLHBN)<eFGpKEulRDmPsrkUQfhXwotdWJLHbv(eFGpKEulRDmPsrkUQfhXwotdWJLHBj):continue
     if eFGpKEulRDmPsrkUQfhXwotdWJLHbv(eFGpKEulRDmPsrkUQfhXwotdWJLHBn)>=eFGpKEulRDmPsrkUQfhXwotdWJLHbv(eFGpKEulRDmPsrkUQfhXwotdWJLHBj)and eFGpKEulRDmPsrkUQfhXwotdWJLHbv(eFGpKEulRDmPsrkUQfhXwotdWJLHBn)<eFGpKEulRDmPsrkUQfhXwotdWJLHbv(eFGpKEulRDmPsrkUQfhXwotdWJLHBi):eFGpKEulRDmPsrkUQfhXwotdWJLHBC=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.xmlText(eFGpKEulRDmPsrkUQfhXwotdWJLHBz['title'])
     if eFGpKEulRDmPsrkUQfhXwotdWJLHBM:eFGpKEulRDmPsrkUQfhXwotdWJLHBM+='\n'
     eFGpKEulRDmPsrkUQfhXwotdWJLHBM+=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.xmlText(eFGpKEulRDmPsrkUQfhXwotdWJLHBz['title'])+'\n'
     eFGpKEulRDmPsrkUQfhXwotdWJLHBM+=' [%s:%s ~ %s:%s]'%(eFGpKEulRDmPsrkUQfhXwotdWJLHBz['startTime'][8:10],eFGpKEulRDmPsrkUQfhXwotdWJLHBz['startTime'][10:12],eFGpKEulRDmPsrkUQfhXwotdWJLHBz['endTime'][8:10],eFGpKEulRDmPsrkUQfhXwotdWJLHBz['endTime'][10:12])+'\n'
    eFGpKEulRDmPsrkUQfhXwotdWJLHcV[eFGpKEulRDmPsrkUQfhXwotdWJLHBy]={'epg':eFGpKEulRDmPsrkUQfhXwotdWJLHBM,'title':eFGpKEulRDmPsrkUQfhXwotdWJLHBC}
  except eFGpKEulRDmPsrkUQfhXwotdWJLHbY as exception:
   eFGpKEulRDmPsrkUQfhXwotdWJLHbx(exception)
  return eFGpKEulRDmPsrkUQfhXwotdWJLHcV
 def Get_EpgInfo_Spotv_spotvon(eFGpKEulRDmPsrkUQfhXwotdWJLHnN,eFGpKEulRDmPsrkUQfhXwotdWJLHBA,epgnm,now_day):
  eFGpKEulRDmPsrkUQfhXwotdWJLHcV =[]
  try:
   eFGpKEulRDmPsrkUQfhXwotdWJLHnq='https://www.spotvon.co.kr/data/onAir/%s/Daily/D%s.asp'%(epgnm,now_day)
   eFGpKEulRDmPsrkUQfhXwotdWJLHnS=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.callRequestCookies('Get',eFGpKEulRDmPsrkUQfhXwotdWJLHnq,payload=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,params=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,headers=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,cookies=eFGpKEulRDmPsrkUQfhXwotdWJLHbg)
   eFGpKEulRDmPsrkUQfhXwotdWJLHnV=json.loads(eFGpKEulRDmPsrkUQfhXwotdWJLHnS.text)
   for eFGpKEulRDmPsrkUQfhXwotdWJLHcv in eFGpKEulRDmPsrkUQfhXwotdWJLHnV:
    eFGpKEulRDmPsrkUQfhXwotdWJLHcY={'title':eFGpKEulRDmPsrkUQfhXwotdWJLHcv['title'],'startTime':eFGpKEulRDmPsrkUQfhXwotdWJLHcv['sch_date'].replace('-','')+eFGpKEulRDmPsrkUQfhXwotdWJLHbV(eFGpKEulRDmPsrkUQfhXwotdWJLHcv['sch_hour']).zfill(2)+eFGpKEulRDmPsrkUQfhXwotdWJLHcv['sch_min']+'00'}
    eFGpKEulRDmPsrkUQfhXwotdWJLHcV.append(eFGpKEulRDmPsrkUQfhXwotdWJLHcY)
   for i in eFGpKEulRDmPsrkUQfhXwotdWJLHMn(eFGpKEulRDmPsrkUQfhXwotdWJLHbT(eFGpKEulRDmPsrkUQfhXwotdWJLHcV)):
    if i>0:eFGpKEulRDmPsrkUQfhXwotdWJLHcV[i-1]['endTime']=eFGpKEulRDmPsrkUQfhXwotdWJLHcV[i]['startTime']
    if i==eFGpKEulRDmPsrkUQfhXwotdWJLHbT(eFGpKEulRDmPsrkUQfhXwotdWJLHcV)-1: eFGpKEulRDmPsrkUQfhXwotdWJLHcV[i]['endTime']=now_day+'240000'
  except eFGpKEulRDmPsrkUQfhXwotdWJLHbY as exception:
   eFGpKEulRDmPsrkUQfhXwotdWJLHbx(exception)
   return[]
  return eFGpKEulRDmPsrkUQfhXwotdWJLHcV
 def Get_EpgInfo_Spotv_spotvnet(eFGpKEulRDmPsrkUQfhXwotdWJLHnN,eFGpKEulRDmPsrkUQfhXwotdWJLHBA,epgnm,now_day):
  eFGpKEulRDmPsrkUQfhXwotdWJLHcV =[]
  try:
   eFGpKEulRDmPsrkUQfhXwotdWJLHnq='https://www.spotv.net/data/json/schedule/%s/Daily/D%s.json'%(epgnm,now_day)
   eFGpKEulRDmPsrkUQfhXwotdWJLHnS=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.callRequestCookies('Get',eFGpKEulRDmPsrkUQfhXwotdWJLHnq,payload=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,params=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,headers=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,cookies=eFGpKEulRDmPsrkUQfhXwotdWJLHbg)
   eFGpKEulRDmPsrkUQfhXwotdWJLHnV=json.loads(eFGpKEulRDmPsrkUQfhXwotdWJLHnS.text)
   for eFGpKEulRDmPsrkUQfhXwotdWJLHcv in eFGpKEulRDmPsrkUQfhXwotdWJLHnV:
    eFGpKEulRDmPsrkUQfhXwotdWJLHcY={'title':eFGpKEulRDmPsrkUQfhXwotdWJLHcv['title'],'startTime':eFGpKEulRDmPsrkUQfhXwotdWJLHcv['sch_date'].replace('-','')+eFGpKEulRDmPsrkUQfhXwotdWJLHbV(eFGpKEulRDmPsrkUQfhXwotdWJLHcv['sch_hour']).zfill(2)+eFGpKEulRDmPsrkUQfhXwotdWJLHcv['sch_min']+'00'}
    eFGpKEulRDmPsrkUQfhXwotdWJLHcV.append(eFGpKEulRDmPsrkUQfhXwotdWJLHcY)
   for i in eFGpKEulRDmPsrkUQfhXwotdWJLHMn(eFGpKEulRDmPsrkUQfhXwotdWJLHbT(eFGpKEulRDmPsrkUQfhXwotdWJLHcV)):
    if i>0:eFGpKEulRDmPsrkUQfhXwotdWJLHcV[i-1]['endTime']=eFGpKEulRDmPsrkUQfhXwotdWJLHcV[i]['startTime']
    if i==eFGpKEulRDmPsrkUQfhXwotdWJLHbT(eFGpKEulRDmPsrkUQfhXwotdWJLHcV)-1: eFGpKEulRDmPsrkUQfhXwotdWJLHcV[i]['endTime']=now_day+'240000'
  except eFGpKEulRDmPsrkUQfhXwotdWJLHbY as exception:
   eFGpKEulRDmPsrkUQfhXwotdWJLHbx(exception)
   return[]
  return eFGpKEulRDmPsrkUQfhXwotdWJLHcV
 def GetEventLiveList(eFGpKEulRDmPsrkUQfhXwotdWJLHnN):
  eFGpKEulRDmPsrkUQfhXwotdWJLHcS=[]
  eFGpKEulRDmPsrkUQfhXwotdWJLHBa =0
  try:
   eFGpKEulRDmPsrkUQfhXwotdWJLHBg=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.Get_Now_Datetime()
   eFGpKEulRDmPsrkUQfhXwotdWJLHBq=eFGpKEulRDmPsrkUQfhXwotdWJLHBg.strftime('%Y-%m-%d')
  except eFGpKEulRDmPsrkUQfhXwotdWJLHbY as exception:
   eFGpKEulRDmPsrkUQfhXwotdWJLHbx(exception)
   return eFGpKEulRDmPsrkUQfhXwotdWJLHcS,eFGpKEulRDmPsrkUQfhXwotdWJLHBa
  try:
   eFGpKEulRDmPsrkUQfhXwotdWJLHnq=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.API_DOMAIN+'/api/v3/player/lives/'+eFGpKEulRDmPsrkUQfhXwotdWJLHBq 
   eFGpKEulRDmPsrkUQfhXwotdWJLHnC=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.makeDefaultCookies()
   eFGpKEulRDmPsrkUQfhXwotdWJLHnS=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.callRequestCookies('Get',eFGpKEulRDmPsrkUQfhXwotdWJLHnq,payload=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,params=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,headers=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,cookies=eFGpKEulRDmPsrkUQfhXwotdWJLHnC)
   eFGpKEulRDmPsrkUQfhXwotdWJLHBa=eFGpKEulRDmPsrkUQfhXwotdWJLHnS.status_code 
   eFGpKEulRDmPsrkUQfhXwotdWJLHcN=json.loads(eFGpKEulRDmPsrkUQfhXwotdWJLHnS.text)
   for eFGpKEulRDmPsrkUQfhXwotdWJLHBS in eFGpKEulRDmPsrkUQfhXwotdWJLHcN:
    for eFGpKEulRDmPsrkUQfhXwotdWJLHcv in eFGpKEulRDmPsrkUQfhXwotdWJLHBS['liveNowList']:
     if eFGpKEulRDmPsrkUQfhXwotdWJLHcv['gameDesc']['title']==eFGpKEulRDmPsrkUQfhXwotdWJLHbg or eFGpKEulRDmPsrkUQfhXwotdWJLHcv['gameDesc']['title']=='':
      eFGpKEulRDmPsrkUQfhXwotdWJLHBO='%s ( %s : %s )'%(eFGpKEulRDmPsrkUQfhXwotdWJLHcv['leagueName'],eFGpKEulRDmPsrkUQfhXwotdWJLHcv['homeNameShort'],eFGpKEulRDmPsrkUQfhXwotdWJLHcv['awayNameShort'])
     else:
      eFGpKEulRDmPsrkUQfhXwotdWJLHBO=eFGpKEulRDmPsrkUQfhXwotdWJLHcv['gameDesc']['title']
     eFGpKEulRDmPsrkUQfhXwotdWJLHcY={'liveId':eFGpKEulRDmPsrkUQfhXwotdWJLHcv['liveId'],'title':eFGpKEulRDmPsrkUQfhXwotdWJLHBO,'logo':eFGpKEulRDmPsrkUQfhXwotdWJLHcv['gameDesc']['leagueLogo'],'free':eFGpKEulRDmPsrkUQfhXwotdWJLHcv['isFree'],'startTime':eFGpKEulRDmPsrkUQfhXwotdWJLHcv['startTime']}
     eFGpKEulRDmPsrkUQfhXwotdWJLHcS.append(eFGpKEulRDmPsrkUQfhXwotdWJLHcY)
  except eFGpKEulRDmPsrkUQfhXwotdWJLHbY as exception:
   eFGpKEulRDmPsrkUQfhXwotdWJLHbx(exception)
  return eFGpKEulRDmPsrkUQfhXwotdWJLHcS,eFGpKEulRDmPsrkUQfhXwotdWJLHBa
 def GetEventLive_videoId(eFGpKEulRDmPsrkUQfhXwotdWJLHnN,liveId):
  eFGpKEulRDmPsrkUQfhXwotdWJLHBv=''
  try:
   eFGpKEulRDmPsrkUQfhXwotdWJLHnq=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.API_DOMAIN+'/api/v3/live/'+liveId
   eFGpKEulRDmPsrkUQfhXwotdWJLHnS=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.callRequestCookies('Get',eFGpKEulRDmPsrkUQfhXwotdWJLHnq,payload=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,params=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,headers=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,cookies=eFGpKEulRDmPsrkUQfhXwotdWJLHbg)
   eFGpKEulRDmPsrkUQfhXwotdWJLHcN=json.loads(eFGpKEulRDmPsrkUQfhXwotdWJLHnS.text)
   eFGpKEulRDmPsrkUQfhXwotdWJLHBY=eFGpKEulRDmPsrkUQfhXwotdWJLHcN['videoId']
   eFGpKEulRDmPsrkUQfhXwotdWJLHBv=eFGpKEulRDmPsrkUQfhXwotdWJLHBY.replace('ref:','')
  except eFGpKEulRDmPsrkUQfhXwotdWJLHbY as exception:
   eFGpKEulRDmPsrkUQfhXwotdWJLHbx(exception)
  return eFGpKEulRDmPsrkUQfhXwotdWJLHBv
 def CheckMainEnd(eFGpKEulRDmPsrkUQfhXwotdWJLHnN):
  eFGpKEulRDmPsrkUQfhXwotdWJLHBx=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.SPOTV_PMCODE+eFGpKEulRDmPsrkUQfhXwotdWJLHbV(eFGpKEulRDmPsrkUQfhXwotdWJLHnN.ST['cookies']['spotv_sessionid'])
  eFGpKEulRDmPsrkUQfhXwotdWJLHBx=base64.standard_b64encode(eFGpKEulRDmPsrkUQfhXwotdWJLHBx.encode()).decode('utf-8')
  if eFGpKEulRDmPsrkUQfhXwotdWJLHBx=='OTg3MTgzMzM0Ng==' or eFGpKEulRDmPsrkUQfhXwotdWJLHBx=='OTg3MTgzMzExNw==':return eFGpKEulRDmPsrkUQfhXwotdWJLHbO
  return eFGpKEulRDmPsrkUQfhXwotdWJLHbq
 def CheckSubEnd(eFGpKEulRDmPsrkUQfhXwotdWJLHnN):
  eFGpKEulRDmPsrkUQfhXwotdWJLHni=eFGpKEulRDmPsrkUQfhXwotdWJLHbq
  try:
   if eFGpKEulRDmPsrkUQfhXwotdWJLHnN.CheckMainEnd():return eFGpKEulRDmPsrkUQfhXwotdWJLHbO 
   eFGpKEulRDmPsrkUQfhXwotdWJLHBV=base64.standard_b64decode(eFGpKEulRDmPsrkUQfhXwotdWJLHnN.ST['cookies']['spotv_subend']).decode('utf-8')[eFGpKEulRDmPsrkUQfhXwotdWJLHnN.SPOTV_PMSIZE:]
   if eFGpKEulRDmPsrkUQfhXwotdWJLHBV=='0':return eFGpKEulRDmPsrkUQfhXwotdWJLHni
   eFGpKEulRDmPsrkUQfhXwotdWJLHBT =eFGpKEulRDmPsrkUQfhXwotdWJLHbv(eFGpKEulRDmPsrkUQfhXwotdWJLHnN.Get_Now_Datetime().strftime('%Y%m%d'))
   eFGpKEulRDmPsrkUQfhXwotdWJLHNn =eFGpKEulRDmPsrkUQfhXwotdWJLHbv(eFGpKEulRDmPsrkUQfhXwotdWJLHBV)/1000
   eFGpKEulRDmPsrkUQfhXwotdWJLHNc =eFGpKEulRDmPsrkUQfhXwotdWJLHbv(datetime.datetime.fromtimestamp(eFGpKEulRDmPsrkUQfhXwotdWJLHNn,datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul')).strftime('%Y%m%d'))
   if eFGpKEulRDmPsrkUQfhXwotdWJLHBT<=eFGpKEulRDmPsrkUQfhXwotdWJLHNc:eFGpKEulRDmPsrkUQfhXwotdWJLHni=eFGpKEulRDmPsrkUQfhXwotdWJLHbO
  except eFGpKEulRDmPsrkUQfhXwotdWJLHbY as exception:
   eFGpKEulRDmPsrkUQfhXwotdWJLHbx(exception)
   return eFGpKEulRDmPsrkUQfhXwotdWJLHni
  return eFGpKEulRDmPsrkUQfhXwotdWJLHni
 def GetBroadURL(eFGpKEulRDmPsrkUQfhXwotdWJLHnN,eFGpKEulRDmPsrkUQfhXwotdWJLHBv,mediatype,eFGpKEulRDmPsrkUQfhXwotdWJLHNC):
  eFGpKEulRDmPsrkUQfhXwotdWJLHNB=''
  try:
   if mediatype=='live':
    eFGpKEulRDmPsrkUQfhXwotdWJLHnq=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.API_DOMAIN+'/api/v3/live/'+eFGpKEulRDmPsrkUQfhXwotdWJLHBv
   else:
    eFGpKEulRDmPsrkUQfhXwotdWJLHBv=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.GetReplay_UrlId(eFGpKEulRDmPsrkUQfhXwotdWJLHBv,eFGpKEulRDmPsrkUQfhXwotdWJLHNC)
    if eFGpKEulRDmPsrkUQfhXwotdWJLHBv=='':return eFGpKEulRDmPsrkUQfhXwotdWJLHNB
    eFGpKEulRDmPsrkUQfhXwotdWJLHnq=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.PLAYER_DOMAIN+'/playback/v1/accounts/'+eFGpKEulRDmPsrkUQfhXwotdWJLHbV(eFGpKEulRDmPsrkUQfhXwotdWJLHnN.ST['cookies']['spotv_accountId'])+'/videos/'+eFGpKEulRDmPsrkUQfhXwotdWJLHBv
   eFGpKEulRDmPsrkUQfhXwotdWJLHnz=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.makeDefaultHeaders()
   eFGpKEulRDmPsrkUQfhXwotdWJLHnS=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.callRequestCookies('Get',eFGpKEulRDmPsrkUQfhXwotdWJLHnq,payload=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,params=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,headers=eFGpKEulRDmPsrkUQfhXwotdWJLHnz,cookies=eFGpKEulRDmPsrkUQfhXwotdWJLHbg)
   eFGpKEulRDmPsrkUQfhXwotdWJLHnV=json.loads(eFGpKEulRDmPsrkUQfhXwotdWJLHnS.text)
   eFGpKEulRDmPsrkUQfhXwotdWJLHbx(eFGpKEulRDmPsrkUQfhXwotdWJLHnq)
   if mediatype=='live':
    eFGpKEulRDmPsrkUQfhXwotdWJLHNB=eFGpKEulRDmPsrkUQfhXwotdWJLHnV['hlsUrl2']or eFGpKEulRDmPsrkUQfhXwotdWJLHnV['hlsUrl']
   else:
    eFGpKEulRDmPsrkUQfhXwotdWJLHbx(eFGpKEulRDmPsrkUQfhXwotdWJLHnV)
    eFGpKEulRDmPsrkUQfhXwotdWJLHNB=eFGpKEulRDmPsrkUQfhXwotdWJLHnV['sources'][0]['src']
   eFGpKEulRDmPsrkUQfhXwotdWJLHNB=eFGpKEulRDmPsrkUQfhXwotdWJLHNB.replace('http://','https://')
  except eFGpKEulRDmPsrkUQfhXwotdWJLHbY as exception:
   eFGpKEulRDmPsrkUQfhXwotdWJLHbx(exception)
  return eFGpKEulRDmPsrkUQfhXwotdWJLHNB
 def GetTitleGroupList(eFGpKEulRDmPsrkUQfhXwotdWJLHnN):
  eFGpKEulRDmPsrkUQfhXwotdWJLHcS=[]
  try:
   eFGpKEulRDmPsrkUQfhXwotdWJLHnq=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.API_DOMAIN+'/api/v3/home/web'
   eFGpKEulRDmPsrkUQfhXwotdWJLHnS=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.callRequestCookies('Get',eFGpKEulRDmPsrkUQfhXwotdWJLHnq,payload=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,params=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,headers=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,cookies=eFGpKEulRDmPsrkUQfhXwotdWJLHbg)
   eFGpKEulRDmPsrkUQfhXwotdWJLHcN=json.loads(eFGpKEulRDmPsrkUQfhXwotdWJLHnS.text)
   for eFGpKEulRDmPsrkUQfhXwotdWJLHcv in eFGpKEulRDmPsrkUQfhXwotdWJLHcN:
    if eFGpKEulRDmPsrkUQfhXwotdWJLHbV(eFGpKEulRDmPsrkUQfhXwotdWJLHcv['type'])=='3':
     eFGpKEulRDmPsrkUQfhXwotdWJLHNb=''
     for eFGpKEulRDmPsrkUQfhXwotdWJLHNM in eFGpKEulRDmPsrkUQfhXwotdWJLHcv['data']['list']:
      eFGpKEulRDmPsrkUQfhXwotdWJLHNI='[%s] %s vs %s\n<%s>\n\n'%(eFGpKEulRDmPsrkUQfhXwotdWJLHNM['gameDesc']['roundName'],eFGpKEulRDmPsrkUQfhXwotdWJLHNM['gameDesc']['homeNameShort'],eFGpKEulRDmPsrkUQfhXwotdWJLHNM['gameDesc']['awayNameShort'],eFGpKEulRDmPsrkUQfhXwotdWJLHNM['gameDesc']['beginDate'])
      eFGpKEulRDmPsrkUQfhXwotdWJLHNb+=eFGpKEulRDmPsrkUQfhXwotdWJLHNI
     eFGpKEulRDmPsrkUQfhXwotdWJLHcY={'title':eFGpKEulRDmPsrkUQfhXwotdWJLHcv['title'],'logo':eFGpKEulRDmPsrkUQfhXwotdWJLHcv['logo'],'reagueId':eFGpKEulRDmPsrkUQfhXwotdWJLHbV(eFGpKEulRDmPsrkUQfhXwotdWJLHcv['destId']),'subGame':eFGpKEulRDmPsrkUQfhXwotdWJLHNb}
     eFGpKEulRDmPsrkUQfhXwotdWJLHcS.append(eFGpKEulRDmPsrkUQfhXwotdWJLHcY)
  except eFGpKEulRDmPsrkUQfhXwotdWJLHbY as exception:
   eFGpKEulRDmPsrkUQfhXwotdWJLHbx(exception)
  return eFGpKEulRDmPsrkUQfhXwotdWJLHcS
 def GetPopularGroupList(eFGpKEulRDmPsrkUQfhXwotdWJLHnN):
  eFGpKEulRDmPsrkUQfhXwotdWJLHcS=[]
  try:
   eFGpKEulRDmPsrkUQfhXwotdWJLHnq=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.API_DOMAIN+'/api/v3/home/web'
   eFGpKEulRDmPsrkUQfhXwotdWJLHnS=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.callRequestCookies('Get',eFGpKEulRDmPsrkUQfhXwotdWJLHnq,payload=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,params=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,headers=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,cookies=eFGpKEulRDmPsrkUQfhXwotdWJLHbg)
   eFGpKEulRDmPsrkUQfhXwotdWJLHcN=json.loads(eFGpKEulRDmPsrkUQfhXwotdWJLHnS.text)
   for eFGpKEulRDmPsrkUQfhXwotdWJLHcv in eFGpKEulRDmPsrkUQfhXwotdWJLHcN:
    if eFGpKEulRDmPsrkUQfhXwotdWJLHbV(eFGpKEulRDmPsrkUQfhXwotdWJLHcv['type'])=='1' and eFGpKEulRDmPsrkUQfhXwotdWJLHbV(eFGpKEulRDmPsrkUQfhXwotdWJLHcv['destId'])=='4':
     for eFGpKEulRDmPsrkUQfhXwotdWJLHNM in eFGpKEulRDmPsrkUQfhXwotdWJLHcv['data']['list']:
      eFGpKEulRDmPsrkUQfhXwotdWJLHNj =eFGpKEulRDmPsrkUQfhXwotdWJLHNM['title']
      eFGpKEulRDmPsrkUQfhXwotdWJLHNi =eFGpKEulRDmPsrkUQfhXwotdWJLHNM['id']
      eFGpKEulRDmPsrkUQfhXwotdWJLHNA =eFGpKEulRDmPsrkUQfhXwotdWJLHNM['vtype']
      eFGpKEulRDmPsrkUQfhXwotdWJLHNy =eFGpKEulRDmPsrkUQfhXwotdWJLHNM['imgUrl']
      eFGpKEulRDmPsrkUQfhXwotdWJLHNC =eFGpKEulRDmPsrkUQfhXwotdWJLHNM['vtypeId']
      eFGpKEulRDmPsrkUQfhXwotdWJLHcY={'vodTitle':eFGpKEulRDmPsrkUQfhXwotdWJLHNj,'vodId':eFGpKEulRDmPsrkUQfhXwotdWJLHNi,'vodType':eFGpKEulRDmPsrkUQfhXwotdWJLHNA,'thumbnail':eFGpKEulRDmPsrkUQfhXwotdWJLHNy,'vtypeId':eFGpKEulRDmPsrkUQfhXwotdWJLHbV(eFGpKEulRDmPsrkUQfhXwotdWJLHNC),'duration':eFGpKEulRDmPsrkUQfhXwotdWJLHbv(eFGpKEulRDmPsrkUQfhXwotdWJLHNM['duration']/1000)}
      eFGpKEulRDmPsrkUQfhXwotdWJLHcS.append(eFGpKEulRDmPsrkUQfhXwotdWJLHcY)
  except eFGpKEulRDmPsrkUQfhXwotdWJLHbY as exception:
   eFGpKEulRDmPsrkUQfhXwotdWJLHbx(exception)
  return eFGpKEulRDmPsrkUQfhXwotdWJLHcS
 def Get_NowVod_GroupList(eFGpKEulRDmPsrkUQfhXwotdWJLHnN,page_int):
  eFGpKEulRDmPsrkUQfhXwotdWJLHcS=[]
  eFGpKEulRDmPsrkUQfhXwotdWJLHNz=eFGpKEulRDmPsrkUQfhXwotdWJLHbq
  try:
   eFGpKEulRDmPsrkUQfhXwotdWJLHnq=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.API_DOMAIN+'/api/v3/theme/14/list'
   eFGpKEulRDmPsrkUQfhXwotdWJLHNa={'pageItem':'10','pageNo':eFGpKEulRDmPsrkUQfhXwotdWJLHbV(page_int)}
   eFGpKEulRDmPsrkUQfhXwotdWJLHnS=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.callRequestCookies('Get',eFGpKEulRDmPsrkUQfhXwotdWJLHnq,payload=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,params=eFGpKEulRDmPsrkUQfhXwotdWJLHNa,headers=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,cookies=eFGpKEulRDmPsrkUQfhXwotdWJLHbg)
   eFGpKEulRDmPsrkUQfhXwotdWJLHcN=json.loads(eFGpKEulRDmPsrkUQfhXwotdWJLHnS.text)
   for eFGpKEulRDmPsrkUQfhXwotdWJLHcv in eFGpKEulRDmPsrkUQfhXwotdWJLHcN['list']:
    eFGpKEulRDmPsrkUQfhXwotdWJLHNj =eFGpKEulRDmPsrkUQfhXwotdWJLHcv['title']
    eFGpKEulRDmPsrkUQfhXwotdWJLHNi =eFGpKEulRDmPsrkUQfhXwotdWJLHcv['id']
    eFGpKEulRDmPsrkUQfhXwotdWJLHNA =eFGpKEulRDmPsrkUQfhXwotdWJLHcv['vtype']
    eFGpKEulRDmPsrkUQfhXwotdWJLHNy =eFGpKEulRDmPsrkUQfhXwotdWJLHcv['imgUrl']
    eFGpKEulRDmPsrkUQfhXwotdWJLHNC =eFGpKEulRDmPsrkUQfhXwotdWJLHcv['vtypeId']
    eFGpKEulRDmPsrkUQfhXwotdWJLHcY={'vodTitle':eFGpKEulRDmPsrkUQfhXwotdWJLHNj,'vodId':eFGpKEulRDmPsrkUQfhXwotdWJLHNi,'vodType':eFGpKEulRDmPsrkUQfhXwotdWJLHNA,'thumbnail':eFGpKEulRDmPsrkUQfhXwotdWJLHNy,'vtypeId':eFGpKEulRDmPsrkUQfhXwotdWJLHbV(eFGpKEulRDmPsrkUQfhXwotdWJLHNC),'duration':eFGpKEulRDmPsrkUQfhXwotdWJLHbv(eFGpKEulRDmPsrkUQfhXwotdWJLHcv['duration']/1000),}
    eFGpKEulRDmPsrkUQfhXwotdWJLHcS.append(eFGpKEulRDmPsrkUQfhXwotdWJLHcY)
    if eFGpKEulRDmPsrkUQfhXwotdWJLHcN['count']>page_int*eFGpKEulRDmPsrkUQfhXwotdWJLHnN.GAMELIST_LIMIT:eFGpKEulRDmPsrkUQfhXwotdWJLHNz=eFGpKEulRDmPsrkUQfhXwotdWJLHbO
  except eFGpKEulRDmPsrkUQfhXwotdWJLHbY as exception:
   eFGpKEulRDmPsrkUQfhXwotdWJLHbx(exception)
  return eFGpKEulRDmPsrkUQfhXwotdWJLHcS,eFGpKEulRDmPsrkUQfhXwotdWJLHNz
 def GetSeasonList(eFGpKEulRDmPsrkUQfhXwotdWJLHnN,leagueId):
  eFGpKEulRDmPsrkUQfhXwotdWJLHcS=[]
  eFGpKEulRDmPsrkUQfhXwotdWJLHNg=eFGpKEulRDmPsrkUQfhXwotdWJLHNq=''
  try:
   eFGpKEulRDmPsrkUQfhXwotdWJLHnq=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.API_DOMAIN+'/api/v3/game/league/'+leagueId
   eFGpKEulRDmPsrkUQfhXwotdWJLHnS=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.callRequestCookies('Get',eFGpKEulRDmPsrkUQfhXwotdWJLHnq,payload=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,params=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,headers=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,cookies=eFGpKEulRDmPsrkUQfhXwotdWJLHbg)
   eFGpKEulRDmPsrkUQfhXwotdWJLHcN=json.loads(eFGpKEulRDmPsrkUQfhXwotdWJLHnS.text)
   eFGpKEulRDmPsrkUQfhXwotdWJLHNg=eFGpKEulRDmPsrkUQfhXwotdWJLHcN['name']
   eFGpKEulRDmPsrkUQfhXwotdWJLHNq=eFGpKEulRDmPsrkUQfhXwotdWJLHbV(eFGpKEulRDmPsrkUQfhXwotdWJLHcN['gameTypeId'])
  except eFGpKEulRDmPsrkUQfhXwotdWJLHbY as exception:
   eFGpKEulRDmPsrkUQfhXwotdWJLHbx(exception)
   return eFGpKEulRDmPsrkUQfhXwotdWJLHcS
  if eFGpKEulRDmPsrkUQfhXwotdWJLHNq in['2','5','6','8']:
   try:
    eFGpKEulRDmPsrkUQfhXwotdWJLHnq=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.API_DOMAIN+'/api/v3/year/'+leagueId
    eFGpKEulRDmPsrkUQfhXwotdWJLHnS=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.callRequestCookies('Get',eFGpKEulRDmPsrkUQfhXwotdWJLHnq,payload=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,params=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,headers=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,cookies=eFGpKEulRDmPsrkUQfhXwotdWJLHbg)
    eFGpKEulRDmPsrkUQfhXwotdWJLHcN=json.loads(eFGpKEulRDmPsrkUQfhXwotdWJLHnS.text)
    for eFGpKEulRDmPsrkUQfhXwotdWJLHcv in eFGpKEulRDmPsrkUQfhXwotdWJLHcN:
     eFGpKEulRDmPsrkUQfhXwotdWJLHcY={'reagueName':eFGpKEulRDmPsrkUQfhXwotdWJLHNg,'gameTypeId':eFGpKEulRDmPsrkUQfhXwotdWJLHNq,'seasonName':eFGpKEulRDmPsrkUQfhXwotdWJLHbV(eFGpKEulRDmPsrkUQfhXwotdWJLHcv),'seasonId':eFGpKEulRDmPsrkUQfhXwotdWJLHbV(eFGpKEulRDmPsrkUQfhXwotdWJLHcv)}
     eFGpKEulRDmPsrkUQfhXwotdWJLHcS.append(eFGpKEulRDmPsrkUQfhXwotdWJLHcY)
   except eFGpKEulRDmPsrkUQfhXwotdWJLHbY as exception:
    eFGpKEulRDmPsrkUQfhXwotdWJLHbx(exception)
    return[]
  else:
   try:
    eFGpKEulRDmPsrkUQfhXwotdWJLHnq=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.API_DOMAIN+'/api/v3/season/'+leagueId
    eFGpKEulRDmPsrkUQfhXwotdWJLHnS=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.callRequestCookies('Get',eFGpKEulRDmPsrkUQfhXwotdWJLHnq,payload=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,params=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,headers=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,cookies=eFGpKEulRDmPsrkUQfhXwotdWJLHbg)
    eFGpKEulRDmPsrkUQfhXwotdWJLHcN=json.loads(eFGpKEulRDmPsrkUQfhXwotdWJLHnS.text)
    for eFGpKEulRDmPsrkUQfhXwotdWJLHcv in eFGpKEulRDmPsrkUQfhXwotdWJLHcN:
     eFGpKEulRDmPsrkUQfhXwotdWJLHcY={'reagueName':eFGpKEulRDmPsrkUQfhXwotdWJLHNg,'gameTypeId':eFGpKEulRDmPsrkUQfhXwotdWJLHNq,'seasonName':eFGpKEulRDmPsrkUQfhXwotdWJLHcv['name'],'seasonId':eFGpKEulRDmPsrkUQfhXwotdWJLHbV(eFGpKEulRDmPsrkUQfhXwotdWJLHcv['id'])}
     eFGpKEulRDmPsrkUQfhXwotdWJLHcS.append(eFGpKEulRDmPsrkUQfhXwotdWJLHcY)
   except eFGpKEulRDmPsrkUQfhXwotdWJLHbY as exception:
    eFGpKEulRDmPsrkUQfhXwotdWJLHbx(exception)
    return[]
  return eFGpKEulRDmPsrkUQfhXwotdWJLHcS
 def GetGameList(eFGpKEulRDmPsrkUQfhXwotdWJLHnN,eFGpKEulRDmPsrkUQfhXwotdWJLHNq,leagueId,seasonId,page_int,hidescore=eFGpKEulRDmPsrkUQfhXwotdWJLHbO):
  eFGpKEulRDmPsrkUQfhXwotdWJLHcS=[]
  eFGpKEulRDmPsrkUQfhXwotdWJLHNz=eFGpKEulRDmPsrkUQfhXwotdWJLHbq
  try:
   eFGpKEulRDmPsrkUQfhXwotdWJLHnq=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.API_DOMAIN+'/api/v3/vod/league/detail'
   eFGpKEulRDmPsrkUQfhXwotdWJLHNa={'gameType':eFGpKEulRDmPsrkUQfhXwotdWJLHNq,'leagueId':leagueId,'seasonId':seasonId if eFGpKEulRDmPsrkUQfhXwotdWJLHNq not in['2','5','6','8']else '','teamId':'','roundId':'','year':'' if eFGpKEulRDmPsrkUQfhXwotdWJLHNq not in['2','5','6','8']else seasonId,'pageNo':eFGpKEulRDmPsrkUQfhXwotdWJLHbV(page_int)}
   eFGpKEulRDmPsrkUQfhXwotdWJLHnS=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.callRequestCookies('Get',eFGpKEulRDmPsrkUQfhXwotdWJLHnq,payload=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,params=eFGpKEulRDmPsrkUQfhXwotdWJLHNa,headers=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,cookies=eFGpKEulRDmPsrkUQfhXwotdWJLHbg)
   eFGpKEulRDmPsrkUQfhXwotdWJLHcN=json.loads(eFGpKEulRDmPsrkUQfhXwotdWJLHnS.text)
   eFGpKEulRDmPsrkUQfhXwotdWJLHBS=eFGpKEulRDmPsrkUQfhXwotdWJLHcN['list']
   for eFGpKEulRDmPsrkUQfhXwotdWJLHNS in eFGpKEulRDmPsrkUQfhXwotdWJLHBS:
    for eFGpKEulRDmPsrkUQfhXwotdWJLHcv in eFGpKEulRDmPsrkUQfhXwotdWJLHNS['list']:
     if eFGpKEulRDmPsrkUQfhXwotdWJLHcv['gameDesc']['title']==eFGpKEulRDmPsrkUQfhXwotdWJLHbg or eFGpKEulRDmPsrkUQfhXwotdWJLHcv['gameDesc']['title']=='':
      eFGpKEulRDmPsrkUQfhXwotdWJLHBO ='%s vs %s'%(eFGpKEulRDmPsrkUQfhXwotdWJLHcv['gameDesc']['homeNameShort'],eFGpKEulRDmPsrkUQfhXwotdWJLHcv['gameDesc']['awayNameShort'])
     else:
      eFGpKEulRDmPsrkUQfhXwotdWJLHBO =eFGpKEulRDmPsrkUQfhXwotdWJLHcv['gameDesc']['title']
     eFGpKEulRDmPsrkUQfhXwotdWJLHNO =eFGpKEulRDmPsrkUQfhXwotdWJLHcv['gameDesc']['beginDate']
     eFGpKEulRDmPsrkUQfhXwotdWJLHNv =eFGpKEulRDmPsrkUQfhXwotdWJLHcv['gameDesc']['id']
     eFGpKEulRDmPsrkUQfhXwotdWJLHNY =eFGpKEulRDmPsrkUQfhXwotdWJLHcv['gameDesc']['leagueNameFull']
     eFGpKEulRDmPsrkUQfhXwotdWJLHNx =eFGpKEulRDmPsrkUQfhXwotdWJLHcv['gameDesc']['seasonName']
     eFGpKEulRDmPsrkUQfhXwotdWJLHNV =eFGpKEulRDmPsrkUQfhXwotdWJLHcv['gameDesc']['roundName']
     eFGpKEulRDmPsrkUQfhXwotdWJLHNT =eFGpKEulRDmPsrkUQfhXwotdWJLHcv['gameDesc']['homeName']
     eFGpKEulRDmPsrkUQfhXwotdWJLHbn =eFGpKEulRDmPsrkUQfhXwotdWJLHcv['gameDesc']['awayName']
     eFGpKEulRDmPsrkUQfhXwotdWJLHbc =eFGpKEulRDmPsrkUQfhXwotdWJLHcv['gameDesc']['homeScore']
     eFGpKEulRDmPsrkUQfhXwotdWJLHbB =eFGpKEulRDmPsrkUQfhXwotdWJLHcv['gameDesc']['awayScore']
     if hidescore==eFGpKEulRDmPsrkUQfhXwotdWJLHbO:
      eFGpKEulRDmPsrkUQfhXwotdWJLHbN ='%s\n - %s (%s)\n - %s\n\nhome : %s\n\naway : %s'%(eFGpKEulRDmPsrkUQfhXwotdWJLHNY,eFGpKEulRDmPsrkUQfhXwotdWJLHNx,eFGpKEulRDmPsrkUQfhXwotdWJLHNV,eFGpKEulRDmPsrkUQfhXwotdWJLHNO,eFGpKEulRDmPsrkUQfhXwotdWJLHNT,eFGpKEulRDmPsrkUQfhXwotdWJLHbn)
     else:
      eFGpKEulRDmPsrkUQfhXwotdWJLHbN ='%s\n - %s (%s)\n - %s\n\nhome : %s (Score %s)\n\naway : %s (Score %s)'%(eFGpKEulRDmPsrkUQfhXwotdWJLHNY,eFGpKEulRDmPsrkUQfhXwotdWJLHNx,eFGpKEulRDmPsrkUQfhXwotdWJLHNV,eFGpKEulRDmPsrkUQfhXwotdWJLHNO,eFGpKEulRDmPsrkUQfhXwotdWJLHNT,eFGpKEulRDmPsrkUQfhXwotdWJLHbc,eFGpKEulRDmPsrkUQfhXwotdWJLHbn,eFGpKEulRDmPsrkUQfhXwotdWJLHbB)
     eFGpKEulRDmPsrkUQfhXwotdWJLHbM=eFGpKEulRDmPsrkUQfhXwotdWJLHbN
     eFGpKEulRDmPsrkUQfhXwotdWJLHbI =eFGpKEulRDmPsrkUQfhXwotdWJLHcv['replayVod']['count']
     eFGpKEulRDmPsrkUQfhXwotdWJLHbj=eFGpKEulRDmPsrkUQfhXwotdWJLHcv['highlightVod']['count']
     eFGpKEulRDmPsrkUQfhXwotdWJLHbi =eFGpKEulRDmPsrkUQfhXwotdWJLHcv['vods']['count']
     eFGpKEulRDmPsrkUQfhXwotdWJLHNy='' 
     eFGpKEulRDmPsrkUQfhXwotdWJLHbA=eFGpKEulRDmPsrkUQfhXwotdWJLHbI+eFGpKEulRDmPsrkUQfhXwotdWJLHbj+eFGpKEulRDmPsrkUQfhXwotdWJLHbi
     if eFGpKEulRDmPsrkUQfhXwotdWJLHbA==0:
      if eFGpKEulRDmPsrkUQfhXwotdWJLHNq=='2':
       eFGpKEulRDmPsrkUQfhXwotdWJLHBO='----- %s -----'%(eFGpKEulRDmPsrkUQfhXwotdWJLHNx)
       eFGpKEulRDmPsrkUQfhXwotdWJLHNO=''
      else:
       eFGpKEulRDmPsrkUQfhXwotdWJLHBO+=' - 관련영상 없음'
       eFGpKEulRDmPsrkUQfhXwotdWJLHbM+='\n\n ** 관련영상 없음 **'
     else:
      if eFGpKEulRDmPsrkUQfhXwotdWJLHbI!=0:
       eFGpKEulRDmPsrkUQfhXwotdWJLHNy =eFGpKEulRDmPsrkUQfhXwotdWJLHcv['replayVod']['list'][0]['imgUrl']
      elif eFGpKEulRDmPsrkUQfhXwotdWJLHbj!=0:
       eFGpKEulRDmPsrkUQfhXwotdWJLHNy =eFGpKEulRDmPsrkUQfhXwotdWJLHcv['highlightVod']['list'][0]['imgUrl']
      else:
       eFGpKEulRDmPsrkUQfhXwotdWJLHNy =eFGpKEulRDmPsrkUQfhXwotdWJLHcv['vods']['list'][0]['imgUrl']
     eFGpKEulRDmPsrkUQfhXwotdWJLHcY={'gameTitle':eFGpKEulRDmPsrkUQfhXwotdWJLHBO,'gameId':eFGpKEulRDmPsrkUQfhXwotdWJLHNv,'beginDate':eFGpKEulRDmPsrkUQfhXwotdWJLHNO[:11],'thumbnail':eFGpKEulRDmPsrkUQfhXwotdWJLHNy,'info_plot':eFGpKEulRDmPsrkUQfhXwotdWJLHbM,'leaguenm':eFGpKEulRDmPsrkUQfhXwotdWJLHNY,'seasonnm':eFGpKEulRDmPsrkUQfhXwotdWJLHNx,'roundnm':eFGpKEulRDmPsrkUQfhXwotdWJLHNV,'totVodCnt':eFGpKEulRDmPsrkUQfhXwotdWJLHbA}
     eFGpKEulRDmPsrkUQfhXwotdWJLHcS.append(eFGpKEulRDmPsrkUQfhXwotdWJLHcY)
  except eFGpKEulRDmPsrkUQfhXwotdWJLHbY as exception:
   eFGpKEulRDmPsrkUQfhXwotdWJLHbx(exception)
  if eFGpKEulRDmPsrkUQfhXwotdWJLHcN['count']>page_int*eFGpKEulRDmPsrkUQfhXwotdWJLHnN.GAMELIST_LIMIT:eFGpKEulRDmPsrkUQfhXwotdWJLHNz=eFGpKEulRDmPsrkUQfhXwotdWJLHbO
  return eFGpKEulRDmPsrkUQfhXwotdWJLHcS,eFGpKEulRDmPsrkUQfhXwotdWJLHNz
 def GetGameVodList(eFGpKEulRDmPsrkUQfhXwotdWJLHnN,eFGpKEulRDmPsrkUQfhXwotdWJLHNv,vodCount=1000):
  eFGpKEulRDmPsrkUQfhXwotdWJLHcS=[]
  eFGpKEulRDmPsrkUQfhXwotdWJLHby=''
  try:
   eFGpKEulRDmPsrkUQfhXwotdWJLHnq=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.API_DOMAIN+'/api/v3/vod/game'
   eFGpKEulRDmPsrkUQfhXwotdWJLHNa={'gameId':eFGpKEulRDmPsrkUQfhXwotdWJLHNv,'pageItem':eFGpKEulRDmPsrkUQfhXwotdWJLHbV(vodCount)}
   eFGpKEulRDmPsrkUQfhXwotdWJLHnS=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.callRequestCookies('Get',eFGpKEulRDmPsrkUQfhXwotdWJLHnq,payload=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,params=eFGpKEulRDmPsrkUQfhXwotdWJLHNa,headers=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,cookies=eFGpKEulRDmPsrkUQfhXwotdWJLHbg)
   eFGpKEulRDmPsrkUQfhXwotdWJLHcN=json.loads(eFGpKEulRDmPsrkUQfhXwotdWJLHnS.text)
   eFGpKEulRDmPsrkUQfhXwotdWJLHNS=eFGpKEulRDmPsrkUQfhXwotdWJLHcN['list']
   for eFGpKEulRDmPsrkUQfhXwotdWJLHcv in eFGpKEulRDmPsrkUQfhXwotdWJLHNS:
    eFGpKEulRDmPsrkUQfhXwotdWJLHNj =eFGpKEulRDmPsrkUQfhXwotdWJLHcv['title']
    eFGpKEulRDmPsrkUQfhXwotdWJLHNi =eFGpKEulRDmPsrkUQfhXwotdWJLHcv['id']
    eFGpKEulRDmPsrkUQfhXwotdWJLHNA =eFGpKEulRDmPsrkUQfhXwotdWJLHcv['vtype']
    eFGpKEulRDmPsrkUQfhXwotdWJLHNy =eFGpKEulRDmPsrkUQfhXwotdWJLHcv['imgUrl']
    eFGpKEulRDmPsrkUQfhXwotdWJLHNC =eFGpKEulRDmPsrkUQfhXwotdWJLHcv['vtypeId']
    eFGpKEulRDmPsrkUQfhXwotdWJLHbC =eFGpKEulRDmPsrkUQfhXwotdWJLHcv['isFree']
    eFGpKEulRDmPsrkUQfhXwotdWJLHcY={'vodTitle':eFGpKEulRDmPsrkUQfhXwotdWJLHNj,'vodId':eFGpKEulRDmPsrkUQfhXwotdWJLHNi,'vodType':eFGpKEulRDmPsrkUQfhXwotdWJLHNA,'thumbnail':eFGpKEulRDmPsrkUQfhXwotdWJLHNy,'vtypeId':eFGpKEulRDmPsrkUQfhXwotdWJLHbV(eFGpKEulRDmPsrkUQfhXwotdWJLHNC),'duration':eFGpKEulRDmPsrkUQfhXwotdWJLHbv(eFGpKEulRDmPsrkUQfhXwotdWJLHcv['duration']/1000),'isFree':eFGpKEulRDmPsrkUQfhXwotdWJLHbC}
    eFGpKEulRDmPsrkUQfhXwotdWJLHcS.append(eFGpKEulRDmPsrkUQfhXwotdWJLHcY)
  except eFGpKEulRDmPsrkUQfhXwotdWJLHbY as exception:
   eFGpKEulRDmPsrkUQfhXwotdWJLHbx(exception)
  return eFGpKEulRDmPsrkUQfhXwotdWJLHcS
 def GetReplay_UrlId(eFGpKEulRDmPsrkUQfhXwotdWJLHnN,eFGpKEulRDmPsrkUQfhXwotdWJLHby,eFGpKEulRDmPsrkUQfhXwotdWJLHNC):
  eFGpKEulRDmPsrkUQfhXwotdWJLHbz=''
  try:
   eFGpKEulRDmPsrkUQfhXwotdWJLHnq=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.API_DOMAIN+'/api/v3/vod/'+eFGpKEulRDmPsrkUQfhXwotdWJLHby
   eFGpKEulRDmPsrkUQfhXwotdWJLHnS=eFGpKEulRDmPsrkUQfhXwotdWJLHnN.callRequestCookies('Get',eFGpKEulRDmPsrkUQfhXwotdWJLHnq,payload=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,params=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,headers=eFGpKEulRDmPsrkUQfhXwotdWJLHbg,cookies=eFGpKEulRDmPsrkUQfhXwotdWJLHbg)
   eFGpKEulRDmPsrkUQfhXwotdWJLHcN=json.loads(eFGpKEulRDmPsrkUQfhXwotdWJLHnS.text)
   eFGpKEulRDmPsrkUQfhXwotdWJLHbz=eFGpKEulRDmPsrkUQfhXwotdWJLHcN['videoId']
  except eFGpKEulRDmPsrkUQfhXwotdWJLHbY as exception:
   eFGpKEulRDmPsrkUQfhXwotdWJLHbx(exception)
  return eFGpKEulRDmPsrkUQfhXwotdWJLHbz
# Created by pyminifier (https://github.com/liftoff/pyminifier)
