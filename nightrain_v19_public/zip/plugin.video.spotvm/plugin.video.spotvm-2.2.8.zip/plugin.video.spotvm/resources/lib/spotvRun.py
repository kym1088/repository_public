__author__="NightRain"
NKaIplWLvEPBCzkgtnmDUoeuhJxTVw=object
NKaIplWLvEPBCzkgtnmDUoeuhJxTVc=None
NKaIplWLvEPBCzkgtnmDUoeuhJxTVX=False
NKaIplWLvEPBCzkgtnmDUoeuhJxTjQ=True
NKaIplWLvEPBCzkgtnmDUoeuhJxTjH=getattr
NKaIplWLvEPBCzkgtnmDUoeuhJxTjA=type
NKaIplWLvEPBCzkgtnmDUoeuhJxTjb=int
NKaIplWLvEPBCzkgtnmDUoeuhJxTjV=list
NKaIplWLvEPBCzkgtnmDUoeuhJxTjr=len
NKaIplWLvEPBCzkgtnmDUoeuhJxTjd=str
NKaIplWLvEPBCzkgtnmDUoeuhJxTjq=id
NKaIplWLvEPBCzkgtnmDUoeuhJxTjO=open
NKaIplWLvEPBCzkgtnmDUoeuhJxTjf=dict
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
NKaIplWLvEPBCzkgtnmDUoeuhJxTQA=[{'title':'TV 채널 (유료사용자만 지원)','mode':'LIVE_GROUP','icon':'live.png'},{'title':'Live중계 (경기중에만 재생)','mode':'ELIVE_GROUP','icon':'live.png'},{'title':'-----------------','mode':'XXX'},{'title':'오늘의 추천 VOD','mode':'NOW_GROUP'},{'title':'인기영상 5','mode':'POP_GROUP'},{'title':'-----------------','mode':'XXX'},{'title':'VOD (리그, 경기별)','mode':'VOD_GROUP'},{'title':'Watched (시청목록)','mode':'WATCH','icon':'history.png'},]
NKaIplWLvEPBCzkgtnmDUoeuhJxTQb={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
NKaIplWLvEPBCzkgtnmDUoeuhJxTQV=xbmcvfs.translatePath(os.path.join(__profile__,'spotv_cookies.json'))
from spotvCore import*
class NKaIplWLvEPBCzkgtnmDUoeuhJxTQH(NKaIplWLvEPBCzkgtnmDUoeuhJxTVw):
 def __init__(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj,NKaIplWLvEPBCzkgtnmDUoeuhJxTQr,NKaIplWLvEPBCzkgtnmDUoeuhJxTQd,NKaIplWLvEPBCzkgtnmDUoeuhJxTQq):
  NKaIplWLvEPBCzkgtnmDUoeuhJxTQj._addon_url =NKaIplWLvEPBCzkgtnmDUoeuhJxTQr
  NKaIplWLvEPBCzkgtnmDUoeuhJxTQj._addon_handle=NKaIplWLvEPBCzkgtnmDUoeuhJxTQd
  NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.main_params =NKaIplWLvEPBCzkgtnmDUoeuhJxTQq
  NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.SpotvObj =YAkbljwTLcyQCfsUxRuznXeiEtKHIP() 
 def addon_noti(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj,sting):
  try:
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQf=xbmcgui.Dialog()
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQf.notification(__addonname__,sting)
  except:
   NKaIplWLvEPBCzkgtnmDUoeuhJxTVc
 def addon_log(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj,string):
  try:
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQF=string.encode('utf-8','ignore')
  except:
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQF='addonException: addon_log'
  NKaIplWLvEPBCzkgtnmDUoeuhJxTQR=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,NKaIplWLvEPBCzkgtnmDUoeuhJxTQF),level=NKaIplWLvEPBCzkgtnmDUoeuhJxTQR)
 def get_keyboard_input(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj,NKaIplWLvEPBCzkgtnmDUoeuhJxTQM):
  NKaIplWLvEPBCzkgtnmDUoeuhJxTQG=NKaIplWLvEPBCzkgtnmDUoeuhJxTVc
  kb=xbmc.Keyboard()
  kb.setHeading(NKaIplWLvEPBCzkgtnmDUoeuhJxTQM)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQG=kb.getText()
  return NKaIplWLvEPBCzkgtnmDUoeuhJxTQG
 def get_settings_account(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj):
  NKaIplWLvEPBCzkgtnmDUoeuhJxTQi =__addon__.getSetting('id')
  NKaIplWLvEPBCzkgtnmDUoeuhJxTQS =__addon__.getSetting('pw')
  return(NKaIplWLvEPBCzkgtnmDUoeuhJxTQi,NKaIplWLvEPBCzkgtnmDUoeuhJxTQS)
 def get_settings_hidescoreyn(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj):
  NKaIplWLvEPBCzkgtnmDUoeuhJxTQy =__addon__.getSetting('hidescore')
  if NKaIplWLvEPBCzkgtnmDUoeuhJxTQy=='false':
   return NKaIplWLvEPBCzkgtnmDUoeuhJxTVX
  else:
   return NKaIplWLvEPBCzkgtnmDUoeuhJxTjQ
 def add_dir(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj,label,sublabel='',img='',infoLabels=NKaIplWLvEPBCzkgtnmDUoeuhJxTVc,isFolder=NKaIplWLvEPBCzkgtnmDUoeuhJxTjQ,params='',isLink=NKaIplWLvEPBCzkgtnmDUoeuhJxTVX,ContextMenu=NKaIplWLvEPBCzkgtnmDUoeuhJxTVc):
  NKaIplWLvEPBCzkgtnmDUoeuhJxTQs='%s?%s'%(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj._addon_url,urllib.parse.urlencode(params))
  if sublabel:NKaIplWLvEPBCzkgtnmDUoeuhJxTQM='%s < %s >'%(label,sublabel)
  else: NKaIplWLvEPBCzkgtnmDUoeuhJxTQM=label
  if not img:img='DefaultFolder.png'
  NKaIplWLvEPBCzkgtnmDUoeuhJxTQY=xbmcgui.ListItem(NKaIplWLvEPBCzkgtnmDUoeuhJxTQM)
  NKaIplWLvEPBCzkgtnmDUoeuhJxTQY.setArt({'thumb':img,'icon':img,'poster':img})
  if NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.SpotvObj.KodiVersion>=20:
   if infoLabels:NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.Set_InfoTag(NKaIplWLvEPBCzkgtnmDUoeuhJxTQY.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:NKaIplWLvEPBCzkgtnmDUoeuhJxTQY.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQY.setProperty('IsPlayable','true')
  if ContextMenu:NKaIplWLvEPBCzkgtnmDUoeuhJxTQY.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj._addon_handle,NKaIplWLvEPBCzkgtnmDUoeuhJxTQs,NKaIplWLvEPBCzkgtnmDUoeuhJxTQY,isFolder)
 def Set_InfoTag(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj,video_InfoTag:xbmc.InfoTagVideo,NKaIplWLvEPBCzkgtnmDUoeuhJxTHq):
  for NKaIplWLvEPBCzkgtnmDUoeuhJxTQw,value in NKaIplWLvEPBCzkgtnmDUoeuhJxTHq.items():
   if NKaIplWLvEPBCzkgtnmDUoeuhJxTQb[NKaIplWLvEPBCzkgtnmDUoeuhJxTQw]['type']=='string':
    NKaIplWLvEPBCzkgtnmDUoeuhJxTjH(video_InfoTag,NKaIplWLvEPBCzkgtnmDUoeuhJxTQb[NKaIplWLvEPBCzkgtnmDUoeuhJxTQw]['func'])(value)
   elif NKaIplWLvEPBCzkgtnmDUoeuhJxTQb[NKaIplWLvEPBCzkgtnmDUoeuhJxTQw]['type']=='int':
    if NKaIplWLvEPBCzkgtnmDUoeuhJxTjA(value)==NKaIplWLvEPBCzkgtnmDUoeuhJxTjb:
     NKaIplWLvEPBCzkgtnmDUoeuhJxTQc=NKaIplWLvEPBCzkgtnmDUoeuhJxTjb(value)
    else:
     NKaIplWLvEPBCzkgtnmDUoeuhJxTQc=0
    NKaIplWLvEPBCzkgtnmDUoeuhJxTjH(video_InfoTag,NKaIplWLvEPBCzkgtnmDUoeuhJxTQb[NKaIplWLvEPBCzkgtnmDUoeuhJxTQw]['func'])(NKaIplWLvEPBCzkgtnmDUoeuhJxTQc)
   elif NKaIplWLvEPBCzkgtnmDUoeuhJxTQb[NKaIplWLvEPBCzkgtnmDUoeuhJxTQw]['type']=='actor':
    if value!=[]:
     NKaIplWLvEPBCzkgtnmDUoeuhJxTjH(video_InfoTag,NKaIplWLvEPBCzkgtnmDUoeuhJxTQb[NKaIplWLvEPBCzkgtnmDUoeuhJxTQw]['func'])([xbmc.Actor(name)for name in value])
   elif NKaIplWLvEPBCzkgtnmDUoeuhJxTQb[NKaIplWLvEPBCzkgtnmDUoeuhJxTQw]['type']=='list':
    if NKaIplWLvEPBCzkgtnmDUoeuhJxTjA(value)==NKaIplWLvEPBCzkgtnmDUoeuhJxTjV:
     NKaIplWLvEPBCzkgtnmDUoeuhJxTjH(video_InfoTag,NKaIplWLvEPBCzkgtnmDUoeuhJxTQb[NKaIplWLvEPBCzkgtnmDUoeuhJxTQw]['func'])(value)
    else:
     NKaIplWLvEPBCzkgtnmDUoeuhJxTjH(video_InfoTag,NKaIplWLvEPBCzkgtnmDUoeuhJxTQb[NKaIplWLvEPBCzkgtnmDUoeuhJxTQw]['func'])([value])
 def get_selQuality(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj,etype):
  try:
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQX='selected_quality'
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHQ=[1080,720,540]
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHA=NKaIplWLvEPBCzkgtnmDUoeuhJxTjb(__addon__.getSetting(NKaIplWLvEPBCzkgtnmDUoeuhJxTQX))
   return NKaIplWLvEPBCzkgtnmDUoeuhJxTHQ[NKaIplWLvEPBCzkgtnmDUoeuhJxTHA]
  except:
   NKaIplWLvEPBCzkgtnmDUoeuhJxTVc
  return 1080 
 def dp_Main_List(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj):
  for NKaIplWLvEPBCzkgtnmDUoeuhJxTHb in NKaIplWLvEPBCzkgtnmDUoeuhJxTQA:
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQM=NKaIplWLvEPBCzkgtnmDUoeuhJxTHb.get('title')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHV=''
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHj={'mode':NKaIplWLvEPBCzkgtnmDUoeuhJxTHb.get('mode'),'page':'1'}
   if NKaIplWLvEPBCzkgtnmDUoeuhJxTHb.get('mode')=='XXX':
    NKaIplWLvEPBCzkgtnmDUoeuhJxTHr=NKaIplWLvEPBCzkgtnmDUoeuhJxTVX
    NKaIplWLvEPBCzkgtnmDUoeuhJxTHd =NKaIplWLvEPBCzkgtnmDUoeuhJxTjQ
   else:
    NKaIplWLvEPBCzkgtnmDUoeuhJxTHr=NKaIplWLvEPBCzkgtnmDUoeuhJxTjQ
    NKaIplWLvEPBCzkgtnmDUoeuhJxTHd =NKaIplWLvEPBCzkgtnmDUoeuhJxTVX
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHq={'title':NKaIplWLvEPBCzkgtnmDUoeuhJxTQM,'plot':NKaIplWLvEPBCzkgtnmDUoeuhJxTQM}
   if NKaIplWLvEPBCzkgtnmDUoeuhJxTHb.get('mode')=='XXX':NKaIplWLvEPBCzkgtnmDUoeuhJxTHq=NKaIplWLvEPBCzkgtnmDUoeuhJxTVc
   if 'icon' in NKaIplWLvEPBCzkgtnmDUoeuhJxTHb:NKaIplWLvEPBCzkgtnmDUoeuhJxTHV=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',NKaIplWLvEPBCzkgtnmDUoeuhJxTHb.get('icon')) 
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.add_dir(NKaIplWLvEPBCzkgtnmDUoeuhJxTQM,sublabel='',img=NKaIplWLvEPBCzkgtnmDUoeuhJxTHV,infoLabels=NKaIplWLvEPBCzkgtnmDUoeuhJxTHq,isFolder=NKaIplWLvEPBCzkgtnmDUoeuhJxTHr,params=NKaIplWLvEPBCzkgtnmDUoeuhJxTHj,isLink=NKaIplWLvEPBCzkgtnmDUoeuhJxTHd)
  if NKaIplWLvEPBCzkgtnmDUoeuhJxTjr(NKaIplWLvEPBCzkgtnmDUoeuhJxTQA)>0:xbmcplugin.endOfDirectory(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj._addon_handle,cacheToDisc=NKaIplWLvEPBCzkgtnmDUoeuhJxTVX)
 def dp_MainLeague_List(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj,args):
  NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.addon_log('dp_MainLeague_List')
  NKaIplWLvEPBCzkgtnmDUoeuhJxTHf=NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.SpotvObj.GetTitleGroupList()
  NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.addon_log('dp_MainLeague_List cnt : '+NKaIplWLvEPBCzkgtnmDUoeuhJxTjd(NKaIplWLvEPBCzkgtnmDUoeuhJxTjr(NKaIplWLvEPBCzkgtnmDUoeuhJxTHf)))
  for NKaIplWLvEPBCzkgtnmDUoeuhJxTHF in NKaIplWLvEPBCzkgtnmDUoeuhJxTHf:
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQM =NKaIplWLvEPBCzkgtnmDUoeuhJxTHF.get('title')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHR =NKaIplWLvEPBCzkgtnmDUoeuhJxTHF.get('logo')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHG =NKaIplWLvEPBCzkgtnmDUoeuhJxTHF.get('reagueId')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHi =NKaIplWLvEPBCzkgtnmDUoeuhJxTHF.get('subGame')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHS={'mediatype':'episode','plot':'%s\n\n%s'%(NKaIplWLvEPBCzkgtnmDUoeuhJxTQM,NKaIplWLvEPBCzkgtnmDUoeuhJxTHi)}
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHj={'mode':'LEAGUE_GROUP','reagueId':NKaIplWLvEPBCzkgtnmDUoeuhJxTHG}
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.add_dir(NKaIplWLvEPBCzkgtnmDUoeuhJxTQM,sublabel=NKaIplWLvEPBCzkgtnmDUoeuhJxTVc,img=NKaIplWLvEPBCzkgtnmDUoeuhJxTHR,infoLabels=NKaIplWLvEPBCzkgtnmDUoeuhJxTHS,isFolder=NKaIplWLvEPBCzkgtnmDUoeuhJxTjQ,params=NKaIplWLvEPBCzkgtnmDUoeuhJxTHj)
  if NKaIplWLvEPBCzkgtnmDUoeuhJxTjr(NKaIplWLvEPBCzkgtnmDUoeuhJxTHf)>0:xbmcplugin.endOfDirectory(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj._addon_handle,cacheToDisc=NKaIplWLvEPBCzkgtnmDUoeuhJxTVX)
 def dp_NowVod_GroupList(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj,args):
  NKaIplWLvEPBCzkgtnmDUoeuhJxTHy=NKaIplWLvEPBCzkgtnmDUoeuhJxTjb(args.get('page'))
  NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.addon_log('dp_NowVod_GroupList page : '+NKaIplWLvEPBCzkgtnmDUoeuhJxTjd(NKaIplWLvEPBCzkgtnmDUoeuhJxTHy))
  NKaIplWLvEPBCzkgtnmDUoeuhJxTHf,NKaIplWLvEPBCzkgtnmDUoeuhJxTHs=NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.SpotvObj.Get_NowVod_GroupList(NKaIplWLvEPBCzkgtnmDUoeuhJxTHy)
  NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.addon_log('dp_NowVod_GroupList cnt : '+NKaIplWLvEPBCzkgtnmDUoeuhJxTjd(NKaIplWLvEPBCzkgtnmDUoeuhJxTjr(NKaIplWLvEPBCzkgtnmDUoeuhJxTHf)))
  for NKaIplWLvEPBCzkgtnmDUoeuhJxTHF in NKaIplWLvEPBCzkgtnmDUoeuhJxTHf:
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHM =NKaIplWLvEPBCzkgtnmDUoeuhJxTHF.get('vodTitle')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHY =NKaIplWLvEPBCzkgtnmDUoeuhJxTHF.get('vodId')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHw =NKaIplWLvEPBCzkgtnmDUoeuhJxTHF.get('vodType')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHR=NKaIplWLvEPBCzkgtnmDUoeuhJxTHF.get('thumbnail')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHc =NKaIplWLvEPBCzkgtnmDUoeuhJxTHF.get('vtypeId')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHX =NKaIplWLvEPBCzkgtnmDUoeuhJxTHF.get('duration')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHS={'mediatype':'episode','duration':NKaIplWLvEPBCzkgtnmDUoeuhJxTHX,'plot':NKaIplWLvEPBCzkgtnmDUoeuhJxTHM}
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHj={'mode':'NOW_VOD','mediacode':NKaIplWLvEPBCzkgtnmDUoeuhJxTHY,'mediatype':'vod','vtypeId':NKaIplWLvEPBCzkgtnmDUoeuhJxTHc}
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.add_dir(NKaIplWLvEPBCzkgtnmDUoeuhJxTHM,sublabel=NKaIplWLvEPBCzkgtnmDUoeuhJxTHw,img=NKaIplWLvEPBCzkgtnmDUoeuhJxTHR,infoLabels=NKaIplWLvEPBCzkgtnmDUoeuhJxTHS,isFolder=NKaIplWLvEPBCzkgtnmDUoeuhJxTVX,params=NKaIplWLvEPBCzkgtnmDUoeuhJxTHj)
  if NKaIplWLvEPBCzkgtnmDUoeuhJxTHs:
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHj['mode'] ='NOW_GROUP' 
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHj['page'] =NKaIplWLvEPBCzkgtnmDUoeuhJxTjd(NKaIplWLvEPBCzkgtnmDUoeuhJxTHy+1)
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQM='[B]%s >>[/B]'%'다음 페이지'
   NKaIplWLvEPBCzkgtnmDUoeuhJxTAQ=NKaIplWLvEPBCzkgtnmDUoeuhJxTjd(NKaIplWLvEPBCzkgtnmDUoeuhJxTHy+1)
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHV=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.add_dir(NKaIplWLvEPBCzkgtnmDUoeuhJxTQM,sublabel=NKaIplWLvEPBCzkgtnmDUoeuhJxTAQ,img=NKaIplWLvEPBCzkgtnmDUoeuhJxTHV,infoLabels=NKaIplWLvEPBCzkgtnmDUoeuhJxTVc,isFolder=NKaIplWLvEPBCzkgtnmDUoeuhJxTjQ,params=NKaIplWLvEPBCzkgtnmDUoeuhJxTHj)
  xbmcplugin.setContent(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj._addon_handle,cacheToDisc=NKaIplWLvEPBCzkgtnmDUoeuhJxTVX)
 def dp_PopVod_GroupList(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj,args):
  NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.addon_log('dp_PopVod_GroupList ')
  NKaIplWLvEPBCzkgtnmDUoeuhJxTHf=NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.SpotvObj.GetPopularGroupList()
  NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.addon_log('dp_PopVod_GroupList cnt : '+NKaIplWLvEPBCzkgtnmDUoeuhJxTjd(NKaIplWLvEPBCzkgtnmDUoeuhJxTjr(NKaIplWLvEPBCzkgtnmDUoeuhJxTHf)))
  for NKaIplWLvEPBCzkgtnmDUoeuhJxTHF in NKaIplWLvEPBCzkgtnmDUoeuhJxTHf:
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHM =NKaIplWLvEPBCzkgtnmDUoeuhJxTHF.get('vodTitle')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHY =NKaIplWLvEPBCzkgtnmDUoeuhJxTHF.get('vodId')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHw =NKaIplWLvEPBCzkgtnmDUoeuhJxTHF.get('vodType')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHR=NKaIplWLvEPBCzkgtnmDUoeuhJxTHF.get('thumbnail')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHc =NKaIplWLvEPBCzkgtnmDUoeuhJxTHF.get('vtypeId')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHX =NKaIplWLvEPBCzkgtnmDUoeuhJxTHF.get('duration')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHS={'mediatype':'episode','duration':NKaIplWLvEPBCzkgtnmDUoeuhJxTHX,'plot':NKaIplWLvEPBCzkgtnmDUoeuhJxTHM}
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHj={'mode':'POP_VOD','mediacode':NKaIplWLvEPBCzkgtnmDUoeuhJxTHY,'mediatype':'vod','vtypeId':NKaIplWLvEPBCzkgtnmDUoeuhJxTHc}
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.add_dir(NKaIplWLvEPBCzkgtnmDUoeuhJxTHM,sublabel=NKaIplWLvEPBCzkgtnmDUoeuhJxTHw,img=NKaIplWLvEPBCzkgtnmDUoeuhJxTHR,infoLabels=NKaIplWLvEPBCzkgtnmDUoeuhJxTHS,isFolder=NKaIplWLvEPBCzkgtnmDUoeuhJxTVX,params=NKaIplWLvEPBCzkgtnmDUoeuhJxTHj)
  xbmcplugin.setContent(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj._addon_handle,cacheToDisc=NKaIplWLvEPBCzkgtnmDUoeuhJxTVX)
 def dp_Season_List(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj,args):
  NKaIplWLvEPBCzkgtnmDUoeuhJxTHG=args.get('reagueId')
  NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.addon_log('Season_List - reagueId : '+NKaIplWLvEPBCzkgtnmDUoeuhJxTHG)
  NKaIplWLvEPBCzkgtnmDUoeuhJxTHf=NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.SpotvObj.GetSeasonList(NKaIplWLvEPBCzkgtnmDUoeuhJxTHG)
  for NKaIplWLvEPBCzkgtnmDUoeuhJxTHF in NKaIplWLvEPBCzkgtnmDUoeuhJxTHf:
   NKaIplWLvEPBCzkgtnmDUoeuhJxTAb =NKaIplWLvEPBCzkgtnmDUoeuhJxTHF.get('reagueName')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTAV =NKaIplWLvEPBCzkgtnmDUoeuhJxTHF.get('gameTypeId')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTAj =NKaIplWLvEPBCzkgtnmDUoeuhJxTHF.get('seasonName')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTAr =NKaIplWLvEPBCzkgtnmDUoeuhJxTHF.get('seasonId')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHS={'mediatype':'episode','plot':'%s - %s'%(NKaIplWLvEPBCzkgtnmDUoeuhJxTAb,NKaIplWLvEPBCzkgtnmDUoeuhJxTAj)}
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHj={'mode':'SEASON_GROUP','reagueId':NKaIplWLvEPBCzkgtnmDUoeuhJxTHG,'seasonId':NKaIplWLvEPBCzkgtnmDUoeuhJxTAr,'gameTypeId':NKaIplWLvEPBCzkgtnmDUoeuhJxTAV,'page':'1'}
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.add_dir(NKaIplWLvEPBCzkgtnmDUoeuhJxTAb,sublabel=NKaIplWLvEPBCzkgtnmDUoeuhJxTAj,img='',infoLabels=NKaIplWLvEPBCzkgtnmDUoeuhJxTHS,isFolder=NKaIplWLvEPBCzkgtnmDUoeuhJxTjQ,params=NKaIplWLvEPBCzkgtnmDUoeuhJxTHj)
  if NKaIplWLvEPBCzkgtnmDUoeuhJxTjr(NKaIplWLvEPBCzkgtnmDUoeuhJxTHf)>0:xbmcplugin.endOfDirectory(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj._addon_handle,cacheToDisc=NKaIplWLvEPBCzkgtnmDUoeuhJxTVX)
 def dp_Game_List(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj,args):
  NKaIplWLvEPBCzkgtnmDUoeuhJxTAV=args.get('gameTypeId')
  NKaIplWLvEPBCzkgtnmDUoeuhJxTHG =args.get('reagueId')
  NKaIplWLvEPBCzkgtnmDUoeuhJxTAr =args.get('seasonId')
  NKaIplWLvEPBCzkgtnmDUoeuhJxTHy =NKaIplWLvEPBCzkgtnmDUoeuhJxTjb(args.get('page'))
  NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.addon_log('Game_List - gameTypeId : '+NKaIplWLvEPBCzkgtnmDUoeuhJxTAV)
  NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.addon_log('Game_List - reagueId   : '+NKaIplWLvEPBCzkgtnmDUoeuhJxTHG)
  NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.addon_log('Game_List - seasonId   : '+NKaIplWLvEPBCzkgtnmDUoeuhJxTAr)
  NKaIplWLvEPBCzkgtnmDUoeuhJxTHf,NKaIplWLvEPBCzkgtnmDUoeuhJxTHs=NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.SpotvObj.GetGameList(NKaIplWLvEPBCzkgtnmDUoeuhJxTAV,NKaIplWLvEPBCzkgtnmDUoeuhJxTHG,NKaIplWLvEPBCzkgtnmDUoeuhJxTAr,NKaIplWLvEPBCzkgtnmDUoeuhJxTHy,hidescore=NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.get_settings_hidescoreyn())
  for NKaIplWLvEPBCzkgtnmDUoeuhJxTHF in NKaIplWLvEPBCzkgtnmDUoeuhJxTHf:
   NKaIplWLvEPBCzkgtnmDUoeuhJxTAd =NKaIplWLvEPBCzkgtnmDUoeuhJxTHF.get('gameTitle')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTAq =NKaIplWLvEPBCzkgtnmDUoeuhJxTHF.get('beginDate')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHR =NKaIplWLvEPBCzkgtnmDUoeuhJxTHF.get('thumbnail')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTAO =NKaIplWLvEPBCzkgtnmDUoeuhJxTHF.get('gameId')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTAf =NKaIplWLvEPBCzkgtnmDUoeuhJxTHF.get('totVodCnt')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTAF =NKaIplWLvEPBCzkgtnmDUoeuhJxTHF.get('leaguenm')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTAR =NKaIplWLvEPBCzkgtnmDUoeuhJxTHF.get('seasonnm')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTAG =NKaIplWLvEPBCzkgtnmDUoeuhJxTHF.get('roundnm')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTAi =NKaIplWLvEPBCzkgtnmDUoeuhJxTHF.get('info_plot')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTAS ='%s < %s >'%(NKaIplWLvEPBCzkgtnmDUoeuhJxTAd,NKaIplWLvEPBCzkgtnmDUoeuhJxTAq)
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHS={'mediatype':'video','plot':NKaIplWLvEPBCzkgtnmDUoeuhJxTAi}
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHj={'mode':'GAME_VOD_GROUP' if NKaIplWLvEPBCzkgtnmDUoeuhJxTAf!=0 else 'XXX','saveTitle':NKaIplWLvEPBCzkgtnmDUoeuhJxTAS,'saveImg':NKaIplWLvEPBCzkgtnmDUoeuhJxTHR,'saveInfo':NKaIplWLvEPBCzkgtnmDUoeuhJxTHS['plot'],'gameid':NKaIplWLvEPBCzkgtnmDUoeuhJxTAO,'totVodCnt':NKaIplWLvEPBCzkgtnmDUoeuhJxTAf,}
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.add_dir(NKaIplWLvEPBCzkgtnmDUoeuhJxTAd,sublabel=NKaIplWLvEPBCzkgtnmDUoeuhJxTAq,img=NKaIplWLvEPBCzkgtnmDUoeuhJxTHR,infoLabels=NKaIplWLvEPBCzkgtnmDUoeuhJxTHS,isFolder=NKaIplWLvEPBCzkgtnmDUoeuhJxTjQ,params=NKaIplWLvEPBCzkgtnmDUoeuhJxTHj)
  if NKaIplWLvEPBCzkgtnmDUoeuhJxTHs:
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHj['mode'] ='SEASON_GROUP' 
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHj['reagueId'] =NKaIplWLvEPBCzkgtnmDUoeuhJxTHG
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHj['seasonId'] =NKaIplWLvEPBCzkgtnmDUoeuhJxTAr
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHj['gameTypeId']=NKaIplWLvEPBCzkgtnmDUoeuhJxTAV
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHj['page'] =NKaIplWLvEPBCzkgtnmDUoeuhJxTjd(NKaIplWLvEPBCzkgtnmDUoeuhJxTHy+1)
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQM='[B]%s >>[/B]'%'다음 페이지'
   NKaIplWLvEPBCzkgtnmDUoeuhJxTAQ=NKaIplWLvEPBCzkgtnmDUoeuhJxTjd(NKaIplWLvEPBCzkgtnmDUoeuhJxTHy+1)
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHV=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.add_dir(NKaIplWLvEPBCzkgtnmDUoeuhJxTQM,sublabel=NKaIplWLvEPBCzkgtnmDUoeuhJxTAQ,img=NKaIplWLvEPBCzkgtnmDUoeuhJxTHV,infoLabels=NKaIplWLvEPBCzkgtnmDUoeuhJxTVc,isFolder=NKaIplWLvEPBCzkgtnmDUoeuhJxTjQ,params=NKaIplWLvEPBCzkgtnmDUoeuhJxTHj)
  if NKaIplWLvEPBCzkgtnmDUoeuhJxTjr(NKaIplWLvEPBCzkgtnmDUoeuhJxTHf)>0:xbmcplugin.endOfDirectory(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj._addon_handle,cacheToDisc=NKaIplWLvEPBCzkgtnmDUoeuhJxTVX)
 def dp_GameVod_List(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj,args):
  NKaIplWLvEPBCzkgtnmDUoeuhJxTAy =args.get('gameid')
  NKaIplWLvEPBCzkgtnmDUoeuhJxTAS=args.get('saveTitle')
  NKaIplWLvEPBCzkgtnmDUoeuhJxTAs =args.get('saveImg')
  NKaIplWLvEPBCzkgtnmDUoeuhJxTAM =args.get('saveInfo')
  NKaIplWLvEPBCzkgtnmDUoeuhJxTHf=NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.SpotvObj.GetGameVodList(NKaIplWLvEPBCzkgtnmDUoeuhJxTAy)
  for NKaIplWLvEPBCzkgtnmDUoeuhJxTHF in NKaIplWLvEPBCzkgtnmDUoeuhJxTHf:
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHM =NKaIplWLvEPBCzkgtnmDUoeuhJxTHF.get('vodTitle')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHY =NKaIplWLvEPBCzkgtnmDUoeuhJxTHF.get('vodId')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHw =NKaIplWLvEPBCzkgtnmDUoeuhJxTHF.get('vodType')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHR=NKaIplWLvEPBCzkgtnmDUoeuhJxTHF.get('thumbnail')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHc =NKaIplWLvEPBCzkgtnmDUoeuhJxTHF.get('vtypeId')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHX =NKaIplWLvEPBCzkgtnmDUoeuhJxTHF.get('duration')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHS={'mediatype':'episode','duration':NKaIplWLvEPBCzkgtnmDUoeuhJxTHX,'plot':'%s \n\n %s'%(NKaIplWLvEPBCzkgtnmDUoeuhJxTHM,NKaIplWLvEPBCzkgtnmDUoeuhJxTAM)}
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHj={'mode':'GAME_VOD','saveTitle':NKaIplWLvEPBCzkgtnmDUoeuhJxTAS,'saveImg':NKaIplWLvEPBCzkgtnmDUoeuhJxTAs,'saveId':NKaIplWLvEPBCzkgtnmDUoeuhJxTAy,'saveInfo':NKaIplWLvEPBCzkgtnmDUoeuhJxTAM,'mediacode':NKaIplWLvEPBCzkgtnmDUoeuhJxTHY,'mediatype':'vod','vtypeId':NKaIplWLvEPBCzkgtnmDUoeuhJxTHc}
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.add_dir(NKaIplWLvEPBCzkgtnmDUoeuhJxTHM,sublabel=NKaIplWLvEPBCzkgtnmDUoeuhJxTHw,img=NKaIplWLvEPBCzkgtnmDUoeuhJxTHR,infoLabels=NKaIplWLvEPBCzkgtnmDUoeuhJxTHS,isFolder=NKaIplWLvEPBCzkgtnmDUoeuhJxTVX,params=NKaIplWLvEPBCzkgtnmDUoeuhJxTHj)
  xbmcplugin.setContent(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj._addon_handle,cacheToDisc=NKaIplWLvEPBCzkgtnmDUoeuhJxTVX)
 def login_main(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj):
  (NKaIplWLvEPBCzkgtnmDUoeuhJxTAY,NKaIplWLvEPBCzkgtnmDUoeuhJxTAw)=NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.get_settings_account()
  if not(NKaIplWLvEPBCzkgtnmDUoeuhJxTAY and NKaIplWLvEPBCzkgtnmDUoeuhJxTAw):
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQf=xbmcgui.Dialog()
   NKaIplWLvEPBCzkgtnmDUoeuhJxTAc=NKaIplWLvEPBCzkgtnmDUoeuhJxTQf.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if NKaIplWLvEPBCzkgtnmDUoeuhJxTAc==NKaIplWLvEPBCzkgtnmDUoeuhJxTjQ:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.cookiefile_check():return
  if xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINWAIT')=='TRUE':
   NKaIplWLvEPBCzkgtnmDUoeuhJxTAX=0
   while NKaIplWLvEPBCzkgtnmDUoeuhJxTjQ:
    NKaIplWLvEPBCzkgtnmDUoeuhJxTAX+=1
    time.sleep(0.05)
    if NKaIplWLvEPBCzkgtnmDUoeuhJxTAX>600:return
  else:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','TRUE')
  NKaIplWLvEPBCzkgtnmDUoeuhJxTbQ=NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.SpotvObj.GetCredential_new(NKaIplWLvEPBCzkgtnmDUoeuhJxTAY,NKaIplWLvEPBCzkgtnmDUoeuhJxTAw)
  if NKaIplWLvEPBCzkgtnmDUoeuhJxTbQ:NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.cookiefile_save()
  xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
  if NKaIplWLvEPBCzkgtnmDUoeuhJxTbQ==NKaIplWLvEPBCzkgtnmDUoeuhJxTVX:
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_LiveChannel_List(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj,args):
  NKaIplWLvEPBCzkgtnmDUoeuhJxTbH=NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.SpotvObj.GetLiveChannelList()
  for NKaIplWLvEPBCzkgtnmDUoeuhJxTbA in NKaIplWLvEPBCzkgtnmDUoeuhJxTbH:
   NKaIplWLvEPBCzkgtnmDUoeuhJxTjq =NKaIplWLvEPBCzkgtnmDUoeuhJxTbA.get('id')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQM =NKaIplWLvEPBCzkgtnmDUoeuhJxTbA.get('name')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHO =NKaIplWLvEPBCzkgtnmDUoeuhJxTbA.get('programName')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHR =NKaIplWLvEPBCzkgtnmDUoeuhJxTbA.get('logo')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTbV=NKaIplWLvEPBCzkgtnmDUoeuhJxTbA.get('channelepg')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTbj =NKaIplWLvEPBCzkgtnmDUoeuhJxTbA.get('free')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHS={'plot':'%s\n\n%s'%(NKaIplWLvEPBCzkgtnmDUoeuhJxTQM,NKaIplWLvEPBCzkgtnmDUoeuhJxTbV),'mediatype':'episode',}
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHj={'mode':'LIVE','mediacode':NKaIplWLvEPBCzkgtnmDUoeuhJxTjq,'free':NKaIplWLvEPBCzkgtnmDUoeuhJxTbj,'mediatype':'live'}
   if NKaIplWLvEPBCzkgtnmDUoeuhJxTbj:NKaIplWLvEPBCzkgtnmDUoeuhJxTQM+=' [free]'
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.add_dir(NKaIplWLvEPBCzkgtnmDUoeuhJxTQM,sublabel=NKaIplWLvEPBCzkgtnmDUoeuhJxTHO,img=NKaIplWLvEPBCzkgtnmDUoeuhJxTHR,infoLabels=NKaIplWLvEPBCzkgtnmDUoeuhJxTHS,isFolder=NKaIplWLvEPBCzkgtnmDUoeuhJxTVX,params=NKaIplWLvEPBCzkgtnmDUoeuhJxTHj)
  xbmcplugin.setContent(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj._addon_handle,'episodes')
  if NKaIplWLvEPBCzkgtnmDUoeuhJxTjr(NKaIplWLvEPBCzkgtnmDUoeuhJxTbH)>0:xbmcplugin.endOfDirectory(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj._addon_handle,cacheToDisc=NKaIplWLvEPBCzkgtnmDUoeuhJxTVX)
 def dp_EventLiveChannel_List(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj,args):
  NKaIplWLvEPBCzkgtnmDUoeuhJxTbH,NKaIplWLvEPBCzkgtnmDUoeuhJxTbr=NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.SpotvObj.GetEventLiveList()
  if NKaIplWLvEPBCzkgtnmDUoeuhJxTbr!=401 and NKaIplWLvEPBCzkgtnmDUoeuhJxTjr(NKaIplWLvEPBCzkgtnmDUoeuhJxTbH)==0:
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.addon_noti(__language__(30907).encode('utf8'))
  for NKaIplWLvEPBCzkgtnmDUoeuhJxTbA in NKaIplWLvEPBCzkgtnmDUoeuhJxTbH:
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQM =NKaIplWLvEPBCzkgtnmDUoeuhJxTbA.get('title')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHO =NKaIplWLvEPBCzkgtnmDUoeuhJxTbA.get('startTime')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHR =NKaIplWLvEPBCzkgtnmDUoeuhJxTbA.get('logo')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTbj =NKaIplWLvEPBCzkgtnmDUoeuhJxTbA.get('free')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHS={'mediatype':'episode','plot':'%s\n\n%s'%(NKaIplWLvEPBCzkgtnmDUoeuhJxTQM,NKaIplWLvEPBCzkgtnmDUoeuhJxTHO)}
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHj={'mode':'ELIVE','mediacode':NKaIplWLvEPBCzkgtnmDUoeuhJxTbA.get('liveId'),'free':NKaIplWLvEPBCzkgtnmDUoeuhJxTbj,'mediatype':'live'}
   if NKaIplWLvEPBCzkgtnmDUoeuhJxTbj:NKaIplWLvEPBCzkgtnmDUoeuhJxTQM+=' [free]'
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.add_dir(NKaIplWLvEPBCzkgtnmDUoeuhJxTQM,sublabel=NKaIplWLvEPBCzkgtnmDUoeuhJxTHO,img=NKaIplWLvEPBCzkgtnmDUoeuhJxTHR,infoLabels=NKaIplWLvEPBCzkgtnmDUoeuhJxTHS,isFolder=NKaIplWLvEPBCzkgtnmDUoeuhJxTVX,params=NKaIplWLvEPBCzkgtnmDUoeuhJxTHj)
  xbmcplugin.setContent(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj._addon_handle,'episodes')
  if NKaIplWLvEPBCzkgtnmDUoeuhJxTjr(NKaIplWLvEPBCzkgtnmDUoeuhJxTbH)>0:xbmcplugin.endOfDirectory(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj._addon_handle,cacheToDisc=NKaIplWLvEPBCzkgtnmDUoeuhJxTVX)
  return NKaIplWLvEPBCzkgtnmDUoeuhJxTbr
 def play_VIDEO(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj,args):
  NKaIplWLvEPBCzkgtnmDUoeuhJxTbd =args.get('mode')
  NKaIplWLvEPBCzkgtnmDUoeuhJxTbq =args.get('mediacode')
  NKaIplWLvEPBCzkgtnmDUoeuhJxTbO =args.get('mediatype')
  NKaIplWLvEPBCzkgtnmDUoeuhJxTHc =args.get('vtypeId')
  NKaIplWLvEPBCzkgtnmDUoeuhJxTbf =args.get('hlsUrl')
  if NKaIplWLvEPBCzkgtnmDUoeuhJxTbd=='LIVE':
   if args.get('free')=='False':
    if NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.SpotvObj.CheckSubEnd()==NKaIplWLvEPBCzkgtnmDUoeuhJxTVX:
     NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.addon_noti(__language__(30908).encode('utf8'))
     return
  elif NKaIplWLvEPBCzkgtnmDUoeuhJxTbd=='ELIVE':
   if args.get('free')=='False':
    if NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.SpotvObj.CheckSubEnd()==NKaIplWLvEPBCzkgtnmDUoeuhJxTVX:
     NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.addon_noti(__language__(30908).encode('utf8'))
     return
  if NKaIplWLvEPBCzkgtnmDUoeuhJxTbq=='' or NKaIplWLvEPBCzkgtnmDUoeuhJxTbq==NKaIplWLvEPBCzkgtnmDUoeuhJxTVc:
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.addon_noti(__language__(30907).encode('utf8'))
   return
  if NKaIplWLvEPBCzkgtnmDUoeuhJxTbd=='LIVE':
   NKaIplWLvEPBCzkgtnmDUoeuhJxTbF=NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.SpotvObj.GetHlsUrl(NKaIplWLvEPBCzkgtnmDUoeuhJxTbq)
  else:
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.addon_log('mediacode : '+NKaIplWLvEPBCzkgtnmDUoeuhJxTbq)
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.addon_log('mediatype : '+NKaIplWLvEPBCzkgtnmDUoeuhJxTbO)
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.addon_log('vtypeId   : '+NKaIplWLvEPBCzkgtnmDUoeuhJxTjd(NKaIplWLvEPBCzkgtnmDUoeuhJxTHc))
   NKaIplWLvEPBCzkgtnmDUoeuhJxTbF=NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.SpotvObj.GetBroadURL(NKaIplWLvEPBCzkgtnmDUoeuhJxTbq,NKaIplWLvEPBCzkgtnmDUoeuhJxTbO,NKaIplWLvEPBCzkgtnmDUoeuhJxTHc)
  if NKaIplWLvEPBCzkgtnmDUoeuhJxTbF=='':
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.addon_noti(__language__(30908).encode('utf8'))
   return
  NKaIplWLvEPBCzkgtnmDUoeuhJxTbR=NKaIplWLvEPBCzkgtnmDUoeuhJxTbF
  try:
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.addon_log('mainMode  = '+NKaIplWLvEPBCzkgtnmDUoeuhJxTbd)
  except:
   NKaIplWLvEPBCzkgtnmDUoeuhJxTVc
  NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.addon_log(NKaIplWLvEPBCzkgtnmDUoeuhJxTbR)
  NKaIplWLvEPBCzkgtnmDUoeuhJxTbG=xbmcgui.ListItem(path=NKaIplWLvEPBCzkgtnmDUoeuhJxTbR)
  xbmcplugin.setResolvedUrl(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj._addon_handle,NKaIplWLvEPBCzkgtnmDUoeuhJxTjQ,NKaIplWLvEPBCzkgtnmDUoeuhJxTbG)
  try:
   if NKaIplWLvEPBCzkgtnmDUoeuhJxTbO=='vod' and NKaIplWLvEPBCzkgtnmDUoeuhJxTbd not in['POP_VOD','NOW_VOD']:
    NKaIplWLvEPBCzkgtnmDUoeuhJxTHj={'code':args.get('saveId'),'img':args.get('saveImg'),'title':args.get('saveTitle'),'info':args.get('saveInfo')}
    NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.Save_Watched_List(NKaIplWLvEPBCzkgtnmDUoeuhJxTbO,NKaIplWLvEPBCzkgtnmDUoeuhJxTHj)
  except:
   NKaIplWLvEPBCzkgtnmDUoeuhJxTVc
 def logout(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj):
  NKaIplWLvEPBCzkgtnmDUoeuhJxTQf=xbmcgui.Dialog()
  NKaIplWLvEPBCzkgtnmDUoeuhJxTAc=NKaIplWLvEPBCzkgtnmDUoeuhJxTQf.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if NKaIplWLvEPBCzkgtnmDUoeuhJxTAc==NKaIplWLvEPBCzkgtnmDUoeuhJxTVX:sys.exit()
  NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.SpotvObj.Init_ST_Total()
  if os.path.isfile(NKaIplWLvEPBCzkgtnmDUoeuhJxTQV):os.remove(NKaIplWLvEPBCzkgtnmDUoeuhJxTQV)
  NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj):
  NKaIplWLvEPBCzkgtnmDUoeuhJxTbi =NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.SpotvObj.Get_Now_Datetime()
  NKaIplWLvEPBCzkgtnmDUoeuhJxTbS=NKaIplWLvEPBCzkgtnmDUoeuhJxTbi+datetime.timedelta(days=NKaIplWLvEPBCzkgtnmDUoeuhJxTjb(__addon__.getSetting('cache_ttl')))
  (NKaIplWLvEPBCzkgtnmDUoeuhJxTAY,NKaIplWLvEPBCzkgtnmDUoeuhJxTAw)=NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.get_settings_account()
  NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.SpotvObj.Save_session_acount(NKaIplWLvEPBCzkgtnmDUoeuhJxTAY,NKaIplWLvEPBCzkgtnmDUoeuhJxTAw)
  NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.SpotvObj.ST['account']['token_limit']=NKaIplWLvEPBCzkgtnmDUoeuhJxTbS.strftime('%Y%m%d')
  NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.SpotvObj.JsonFile_Save(NKaIplWLvEPBCzkgtnmDUoeuhJxTQV,NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.SpotvObj.ST)
 def cookiefile_check(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj):
  NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.SpotvObj.ST=NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.SpotvObj.JsonFile_Load(NKaIplWLvEPBCzkgtnmDUoeuhJxTQV)
  if 'account' not in NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.SpotvObj.ST:
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.SpotvObj.Init_ST_Total()
   return NKaIplWLvEPBCzkgtnmDUoeuhJxTVX
  (NKaIplWLvEPBCzkgtnmDUoeuhJxTby,NKaIplWLvEPBCzkgtnmDUoeuhJxTbs)=NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.get_settings_account()
  (NKaIplWLvEPBCzkgtnmDUoeuhJxTbM,NKaIplWLvEPBCzkgtnmDUoeuhJxTbY)=NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.SpotvObj.Load_session_acount()
  if NKaIplWLvEPBCzkgtnmDUoeuhJxTby!=NKaIplWLvEPBCzkgtnmDUoeuhJxTbM or NKaIplWLvEPBCzkgtnmDUoeuhJxTbs!=NKaIplWLvEPBCzkgtnmDUoeuhJxTbY:
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.SpotvObj.Init_ST_Total()
   return NKaIplWLvEPBCzkgtnmDUoeuhJxTVX
  if NKaIplWLvEPBCzkgtnmDUoeuhJxTjb(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))>NKaIplWLvEPBCzkgtnmDUoeuhJxTjb(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.SpotvObj.ST['account']['token_limit']):
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.SpotvObj.Init_ST_Total()
   return NKaIplWLvEPBCzkgtnmDUoeuhJxTVX
  return NKaIplWLvEPBCzkgtnmDUoeuhJxTjQ
 def dp_History_Remove(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj,args):
  NKaIplWLvEPBCzkgtnmDUoeuhJxTbw=args.get('delType')
  NKaIplWLvEPBCzkgtnmDUoeuhJxTbc =args.get('sKey')
  NKaIplWLvEPBCzkgtnmDUoeuhJxTbX =args.get('vType')
  NKaIplWLvEPBCzkgtnmDUoeuhJxTQf=xbmcgui.Dialog()
  if NKaIplWLvEPBCzkgtnmDUoeuhJxTbw=='WATCH_ALL':
   NKaIplWLvEPBCzkgtnmDUoeuhJxTAc=NKaIplWLvEPBCzkgtnmDUoeuhJxTQf.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif NKaIplWLvEPBCzkgtnmDUoeuhJxTbw=='WATCH_ONE':
   NKaIplWLvEPBCzkgtnmDUoeuhJxTAc=NKaIplWLvEPBCzkgtnmDUoeuhJxTQf.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  if NKaIplWLvEPBCzkgtnmDUoeuhJxTAc==NKaIplWLvEPBCzkgtnmDUoeuhJxTVX:sys.exit()
  if NKaIplWLvEPBCzkgtnmDUoeuhJxTbw=='WATCH_ALL':
   NKaIplWLvEPBCzkgtnmDUoeuhJxTVQ=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%NKaIplWLvEPBCzkgtnmDUoeuhJxTbX))
   if os.path.isfile(NKaIplWLvEPBCzkgtnmDUoeuhJxTVQ):os.remove(NKaIplWLvEPBCzkgtnmDUoeuhJxTVQ)
  elif NKaIplWLvEPBCzkgtnmDUoeuhJxTbw=='WATCH_ONE':
   NKaIplWLvEPBCzkgtnmDUoeuhJxTVQ=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%NKaIplWLvEPBCzkgtnmDUoeuhJxTbX))
   try:
    NKaIplWLvEPBCzkgtnmDUoeuhJxTVH=NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.Load_List_File(NKaIplWLvEPBCzkgtnmDUoeuhJxTbX) 
    fp=NKaIplWLvEPBCzkgtnmDUoeuhJxTjO(NKaIplWLvEPBCzkgtnmDUoeuhJxTVQ,'w',-1,'utf-8')
    for NKaIplWLvEPBCzkgtnmDUoeuhJxTVA in NKaIplWLvEPBCzkgtnmDUoeuhJxTVH:
     NKaIplWLvEPBCzkgtnmDUoeuhJxTVb=NKaIplWLvEPBCzkgtnmDUoeuhJxTjf(urllib.parse.parse_qsl(NKaIplWLvEPBCzkgtnmDUoeuhJxTVA))
     NKaIplWLvEPBCzkgtnmDUoeuhJxTVj=NKaIplWLvEPBCzkgtnmDUoeuhJxTVb.get('code').strip()
     if NKaIplWLvEPBCzkgtnmDUoeuhJxTbc!=NKaIplWLvEPBCzkgtnmDUoeuhJxTVj:
      fp.write(NKaIplWLvEPBCzkgtnmDUoeuhJxTVA)
    fp.close()
   except:
    NKaIplWLvEPBCzkgtnmDUoeuhJxTVc
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj,NKaIplWLvEPBCzkgtnmDUoeuhJxTbO):
  try:
   NKaIplWLvEPBCzkgtnmDUoeuhJxTVr=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%NKaIplWLvEPBCzkgtnmDUoeuhJxTbO))
   fp=NKaIplWLvEPBCzkgtnmDUoeuhJxTjO(NKaIplWLvEPBCzkgtnmDUoeuhJxTVr,'r',-1,'utf-8')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTVd=fp.readlines()
   fp.close()
  except:
   NKaIplWLvEPBCzkgtnmDUoeuhJxTVd=[]
  return NKaIplWLvEPBCzkgtnmDUoeuhJxTVd
 def Save_Watched_List(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj,stype,NKaIplWLvEPBCzkgtnmDUoeuhJxTQq):
  try:
   NKaIplWLvEPBCzkgtnmDUoeuhJxTVr=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   NKaIplWLvEPBCzkgtnmDUoeuhJxTVH=NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.Load_List_File(stype) 
   fp=NKaIplWLvEPBCzkgtnmDUoeuhJxTjO(NKaIplWLvEPBCzkgtnmDUoeuhJxTVr,'w',-1,'utf-8')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTVq=urllib.parse.urlencode(NKaIplWLvEPBCzkgtnmDUoeuhJxTQq)
   NKaIplWLvEPBCzkgtnmDUoeuhJxTVq=NKaIplWLvEPBCzkgtnmDUoeuhJxTVq+'\n'
   fp.write(NKaIplWLvEPBCzkgtnmDUoeuhJxTVq)
   NKaIplWLvEPBCzkgtnmDUoeuhJxTVO=0
   for NKaIplWLvEPBCzkgtnmDUoeuhJxTVA in NKaIplWLvEPBCzkgtnmDUoeuhJxTVH:
    NKaIplWLvEPBCzkgtnmDUoeuhJxTVb=NKaIplWLvEPBCzkgtnmDUoeuhJxTjf(urllib.parse.parse_qsl(NKaIplWLvEPBCzkgtnmDUoeuhJxTVA))
    NKaIplWLvEPBCzkgtnmDUoeuhJxTVf=NKaIplWLvEPBCzkgtnmDUoeuhJxTQq.get('code')
    NKaIplWLvEPBCzkgtnmDUoeuhJxTVF=NKaIplWLvEPBCzkgtnmDUoeuhJxTVb.get('code')
    if NKaIplWLvEPBCzkgtnmDUoeuhJxTVf!=NKaIplWLvEPBCzkgtnmDUoeuhJxTVF:
     fp.write(NKaIplWLvEPBCzkgtnmDUoeuhJxTVA)
     NKaIplWLvEPBCzkgtnmDUoeuhJxTVO+=1
     if NKaIplWLvEPBCzkgtnmDUoeuhJxTVO>=50:break
   fp.close()
  except:
   NKaIplWLvEPBCzkgtnmDUoeuhJxTVc
 def dp_Watch_List(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj,args):
  NKaIplWLvEPBCzkgtnmDUoeuhJxTbO ='vod'
  if NKaIplWLvEPBCzkgtnmDUoeuhJxTbO=='vod':
   NKaIplWLvEPBCzkgtnmDUoeuhJxTVR=NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.Load_List_File(NKaIplWLvEPBCzkgtnmDUoeuhJxTbO)
   for NKaIplWLvEPBCzkgtnmDUoeuhJxTVG in NKaIplWLvEPBCzkgtnmDUoeuhJxTVR:
    NKaIplWLvEPBCzkgtnmDUoeuhJxTVi=NKaIplWLvEPBCzkgtnmDUoeuhJxTjf(urllib.parse.parse_qsl(NKaIplWLvEPBCzkgtnmDUoeuhJxTVG))
    NKaIplWLvEPBCzkgtnmDUoeuhJxTQM =NKaIplWLvEPBCzkgtnmDUoeuhJxTVi.get('title')
    NKaIplWLvEPBCzkgtnmDUoeuhJxTHR=NKaIplWLvEPBCzkgtnmDUoeuhJxTVi.get('img')
    NKaIplWLvEPBCzkgtnmDUoeuhJxTbq=NKaIplWLvEPBCzkgtnmDUoeuhJxTVi.get('code')
    NKaIplWLvEPBCzkgtnmDUoeuhJxTVS =NKaIplWLvEPBCzkgtnmDUoeuhJxTVi.get('info')
    NKaIplWLvEPBCzkgtnmDUoeuhJxTHS={}
    NKaIplWLvEPBCzkgtnmDUoeuhJxTHS['plot'] =NKaIplWLvEPBCzkgtnmDUoeuhJxTVS
    NKaIplWLvEPBCzkgtnmDUoeuhJxTHS['mediatype']='tvshow'
    NKaIplWLvEPBCzkgtnmDUoeuhJxTHj={'mode':'GAME_VOD_GROUP','gameid':NKaIplWLvEPBCzkgtnmDUoeuhJxTbq,'saveTitle':NKaIplWLvEPBCzkgtnmDUoeuhJxTQM,'saveImg':NKaIplWLvEPBCzkgtnmDUoeuhJxTHR,'saveInfo':NKaIplWLvEPBCzkgtnmDUoeuhJxTVS,'mediatype':NKaIplWLvEPBCzkgtnmDUoeuhJxTbO}
    NKaIplWLvEPBCzkgtnmDUoeuhJxTVy={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':NKaIplWLvEPBCzkgtnmDUoeuhJxTbq,'vType':NKaIplWLvEPBCzkgtnmDUoeuhJxTbO,}
    NKaIplWLvEPBCzkgtnmDUoeuhJxTVs=urllib.parse.urlencode(NKaIplWLvEPBCzkgtnmDUoeuhJxTVy)
    NKaIplWLvEPBCzkgtnmDUoeuhJxTVM=[('선택된 시청이력 ( %s ) 삭제'%(NKaIplWLvEPBCzkgtnmDUoeuhJxTQM),'RunPlugin(plugin://plugin.video.spotvm/?%s)'%(NKaIplWLvEPBCzkgtnmDUoeuhJxTVs))]
    NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.add_dir(NKaIplWLvEPBCzkgtnmDUoeuhJxTQM,sublabel='',img=NKaIplWLvEPBCzkgtnmDUoeuhJxTHR,infoLabels=NKaIplWLvEPBCzkgtnmDUoeuhJxTHS,isFolder=NKaIplWLvEPBCzkgtnmDUoeuhJxTjQ,params=NKaIplWLvEPBCzkgtnmDUoeuhJxTHj,ContextMenu=NKaIplWLvEPBCzkgtnmDUoeuhJxTVM)
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHS={'plot':'시청목록을 삭제합니다.'}
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQM='*** 시청목록 삭제 ***'
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHj={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':NKaIplWLvEPBCzkgtnmDUoeuhJxTbO,}
   NKaIplWLvEPBCzkgtnmDUoeuhJxTHV=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.add_dir(NKaIplWLvEPBCzkgtnmDUoeuhJxTQM,sublabel='',img=NKaIplWLvEPBCzkgtnmDUoeuhJxTHV,infoLabels=NKaIplWLvEPBCzkgtnmDUoeuhJxTHS,isFolder=NKaIplWLvEPBCzkgtnmDUoeuhJxTVX,params=NKaIplWLvEPBCzkgtnmDUoeuhJxTHj,isLink=NKaIplWLvEPBCzkgtnmDUoeuhJxTjQ)
   xbmcplugin.endOfDirectory(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj._addon_handle,cacheToDisc=NKaIplWLvEPBCzkgtnmDUoeuhJxTVX)
 def spotv_main(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj):
  NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.SpotvObj.KodiVersion=NKaIplWLvEPBCzkgtnmDUoeuhJxTjb(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  NKaIplWLvEPBCzkgtnmDUoeuhJxTVY=NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.main_params.get('mode',NKaIplWLvEPBCzkgtnmDUoeuhJxTVc)
  if NKaIplWLvEPBCzkgtnmDUoeuhJxTVY=='LOGOUT':
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.logout()
   return
  NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.login_main()
  if NKaIplWLvEPBCzkgtnmDUoeuhJxTVY is NKaIplWLvEPBCzkgtnmDUoeuhJxTVc:
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.dp_Main_List()
  elif NKaIplWLvEPBCzkgtnmDUoeuhJxTVY=='LIVE_GROUP':
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.dp_LiveChannel_List(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.main_params)
  elif NKaIplWLvEPBCzkgtnmDUoeuhJxTVY=='ELIVE_GROUP':
   NKaIplWLvEPBCzkgtnmDUoeuhJxTbr=NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.dp_EventLiveChannel_List(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.main_params)
   if NKaIplWLvEPBCzkgtnmDUoeuhJxTbr==401:
    if os.path.isfile(NKaIplWLvEPBCzkgtnmDUoeuhJxTQV):os.remove(NKaIplWLvEPBCzkgtnmDUoeuhJxTQV)
    NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.login_main()
    NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.dp_EventLiveChannel_List(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.main_params)
  elif NKaIplWLvEPBCzkgtnmDUoeuhJxTVY in['LIVE','GAME_VOD','POP_VOD','NOW_VOD','ELIVE']:
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.play_VIDEO(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.main_params)
  elif NKaIplWLvEPBCzkgtnmDUoeuhJxTVY=='VOD_GROUP':
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.dp_MainLeague_List(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.main_params)
  elif NKaIplWLvEPBCzkgtnmDUoeuhJxTVY=='NOW_GROUP':
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.dp_NowVod_GroupList(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.main_params)
  elif NKaIplWLvEPBCzkgtnmDUoeuhJxTVY=='POP_GROUP':
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.dp_PopVod_GroupList(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.main_params)
  elif NKaIplWLvEPBCzkgtnmDUoeuhJxTVY=='LEAGUE_GROUP':
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.dp_Season_List(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.main_params)
  elif NKaIplWLvEPBCzkgtnmDUoeuhJxTVY=='SEASON_GROUP':
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.dp_Game_List(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.main_params)
  elif NKaIplWLvEPBCzkgtnmDUoeuhJxTVY=='GAME_VOD_GROUP':
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.dp_GameVod_List(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.main_params)
  elif NKaIplWLvEPBCzkgtnmDUoeuhJxTVY=='WATCH':
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.dp_Watch_List(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.main_params)
  elif NKaIplWLvEPBCzkgtnmDUoeuhJxTVY=='MYVIEW_REMOVE':
   NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.dp_History_Remove(NKaIplWLvEPBCzkgtnmDUoeuhJxTQj.main_params)
  else:
   NKaIplWLvEPBCzkgtnmDUoeuhJxTVc
# Created by pyminifier (https://github.com/liftoff/pyminifier)
