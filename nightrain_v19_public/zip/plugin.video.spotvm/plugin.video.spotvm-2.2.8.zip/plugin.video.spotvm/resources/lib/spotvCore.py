__author__="NightRain"
YAkbljwTLcyQCfsUxRuznXeiEtKHvD=object
YAkbljwTLcyQCfsUxRuznXeiEtKHvh=None
YAkbljwTLcyQCfsUxRuznXeiEtKHvo=False
YAkbljwTLcyQCfsUxRuznXeiEtKHvB=str
YAkbljwTLcyQCfsUxRuznXeiEtKHvJ=open
YAkbljwTLcyQCfsUxRuznXeiEtKHvG=True
YAkbljwTLcyQCfsUxRuznXeiEtKHva=int
YAkbljwTLcyQCfsUxRuznXeiEtKHvp=Exception
YAkbljwTLcyQCfsUxRuznXeiEtKHdI=print
YAkbljwTLcyQCfsUxRuznXeiEtKHdP=len
YAkbljwTLcyQCfsUxRuznXeiEtKHdm=range
import urllib
import re
import json
import sys
import time
import requests
import datetime
import base64
import random
YAkbljwTLcyQCfsUxRuznXeiEtKHIm={'stream50':1080,'stream40':720,'stream30':540}
class YAkbljwTLcyQCfsUxRuznXeiEtKHIP(YAkbljwTLcyQCfsUxRuznXeiEtKHvD):
 def __init__(YAkbljwTLcyQCfsUxRuznXeiEtKHIN):
  YAkbljwTLcyQCfsUxRuznXeiEtKHIN.SPOTV_PMCODE ='987'
  YAkbljwTLcyQCfsUxRuznXeiEtKHIN.SPOTV_PMSIZE =3
  YAkbljwTLcyQCfsUxRuznXeiEtKHIN.GAMELIST_LIMIT =10
  YAkbljwTLcyQCfsUxRuznXeiEtKHIN.API_DOMAIN ='https://www.spotvnow.co.kr'
  YAkbljwTLcyQCfsUxRuznXeiEtKHIN.BC_DOMAIN ='https://players.brightcove.net'
  YAkbljwTLcyQCfsUxRuznXeiEtKHIN.PLAYER_DOMAIN ='https://edge.api.brightcove.com'
  YAkbljwTLcyQCfsUxRuznXeiEtKHIN.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36'
  YAkbljwTLcyQCfsUxRuznXeiEtKHIN.DEFAULT_HEADER ={'user-agent':YAkbljwTLcyQCfsUxRuznXeiEtKHIN.USER_AGENT}
  YAkbljwTLcyQCfsUxRuznXeiEtKHIN.COOKIE_FILE_NAME=''
  YAkbljwTLcyQCfsUxRuznXeiEtKHIN.KodiVersion =20
  YAkbljwTLcyQCfsUxRuznXeiEtKHIN.ST ={}
  YAkbljwTLcyQCfsUxRuznXeiEtKHIN.Init_ST_Total()
 def Init_ST_Total(YAkbljwTLcyQCfsUxRuznXeiEtKHIN):
  YAkbljwTLcyQCfsUxRuznXeiEtKHIN.ST={'account':{},'cookies':{},}
 def addon_log(YAkbljwTLcyQCfsUxRuznXeiEtKHIN,string):
  import xbmcaddon,xbmc
  __version__=xbmcaddon.Addon().getAddonInfo('version')
  __addonid__=xbmcaddon.Addon().getAddonInfo('id')
  try:
   YAkbljwTLcyQCfsUxRuznXeiEtKHIv=string.encode('utf-8','ignore')
  except:
   YAkbljwTLcyQCfsUxRuznXeiEtKHIv='addonException: addon_log'
  YAkbljwTLcyQCfsUxRuznXeiEtKHId=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,YAkbljwTLcyQCfsUxRuznXeiEtKHIv),level=YAkbljwTLcyQCfsUxRuznXeiEtKHId)
 def callRequestCookies(YAkbljwTLcyQCfsUxRuznXeiEtKHIN,jobtype,YAkbljwTLcyQCfsUxRuznXeiEtKHIo,payload=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,json=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,params=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,headers=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,cookies=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,redirects=YAkbljwTLcyQCfsUxRuznXeiEtKHvo):
  YAkbljwTLcyQCfsUxRuznXeiEtKHIW=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.DEFAULT_HEADER
  if headers:YAkbljwTLcyQCfsUxRuznXeiEtKHIW.update(headers)
  if jobtype=='Get':
   YAkbljwTLcyQCfsUxRuznXeiEtKHIO=requests.get(YAkbljwTLcyQCfsUxRuznXeiEtKHIo,params=params,headers=YAkbljwTLcyQCfsUxRuznXeiEtKHIW,cookies=cookies,allow_redirects=redirects)
  else:
   YAkbljwTLcyQCfsUxRuznXeiEtKHIO=requests.post(YAkbljwTLcyQCfsUxRuznXeiEtKHIo,data=payload,json=json,params=params,headers=YAkbljwTLcyQCfsUxRuznXeiEtKHIW,cookies=cookies,allow_redirects=redirects)
  try:
   YAkbljwTLcyQCfsUxRuznXeiEtKHIN.addon_log(YAkbljwTLcyQCfsUxRuznXeiEtKHvB(YAkbljwTLcyQCfsUxRuznXeiEtKHIO.status_code)+' : '+YAkbljwTLcyQCfsUxRuznXeiEtKHIO.url)
  except:
   YAkbljwTLcyQCfsUxRuznXeiEtKHvh
  return YAkbljwTLcyQCfsUxRuznXeiEtKHIO
 def JsonFile_Save(YAkbljwTLcyQCfsUxRuznXeiEtKHIN,filename,YAkbljwTLcyQCfsUxRuznXeiEtKHIS):
  if filename=='':return YAkbljwTLcyQCfsUxRuznXeiEtKHvo
  try:
   fp=YAkbljwTLcyQCfsUxRuznXeiEtKHvJ(filename,'w',-1,'utf-8')
   json.dump(YAkbljwTLcyQCfsUxRuznXeiEtKHIS,fp,indent=4,ensure_ascii=YAkbljwTLcyQCfsUxRuznXeiEtKHvo)
   fp.close()
  except:
   return YAkbljwTLcyQCfsUxRuznXeiEtKHvo
  return YAkbljwTLcyQCfsUxRuznXeiEtKHvG
 def JsonFile_Load(YAkbljwTLcyQCfsUxRuznXeiEtKHIN,filename):
  if filename=='':return{}
  try:
   fp=YAkbljwTLcyQCfsUxRuznXeiEtKHvJ(filename,'r',-1,'utf-8')
   YAkbljwTLcyQCfsUxRuznXeiEtKHIV=json.load(fp)
   fp.close()
  except:
   return{}
  return YAkbljwTLcyQCfsUxRuznXeiEtKHIV
 def Save_session_acount(YAkbljwTLcyQCfsUxRuznXeiEtKHIN,YAkbljwTLcyQCfsUxRuznXeiEtKHIg,YAkbljwTLcyQCfsUxRuznXeiEtKHIM):
  YAkbljwTLcyQCfsUxRuznXeiEtKHIN.ST['account']['stid'] =base64.standard_b64encode(YAkbljwTLcyQCfsUxRuznXeiEtKHIg.encode()).decode('utf-8')
  YAkbljwTLcyQCfsUxRuznXeiEtKHIN.ST['account']['stpw'] =base64.standard_b64encode(YAkbljwTLcyQCfsUxRuznXeiEtKHIM.encode()).decode('utf-8')
 def Load_session_acount(YAkbljwTLcyQCfsUxRuznXeiEtKHIN):
  try:
   YAkbljwTLcyQCfsUxRuznXeiEtKHIg =base64.standard_b64decode(YAkbljwTLcyQCfsUxRuznXeiEtKHIN.ST['account']['stid']).decode('utf-8')
   YAkbljwTLcyQCfsUxRuznXeiEtKHIM =base64.standard_b64decode(YAkbljwTLcyQCfsUxRuznXeiEtKHIN.ST['account']['stpw']).decode('utf-8')
  except:
   return '',''
  return YAkbljwTLcyQCfsUxRuznXeiEtKHIg,YAkbljwTLcyQCfsUxRuznXeiEtKHIM
 def makeDefaultCookies(YAkbljwTLcyQCfsUxRuznXeiEtKHIN):
  YAkbljwTLcyQCfsUxRuznXeiEtKHIF={'id_token':YAkbljwTLcyQCfsUxRuznXeiEtKHIN.ST['cookies']['id_token']}
  return YAkbljwTLcyQCfsUxRuznXeiEtKHIF
 def makeDefaultHeaders(YAkbljwTLcyQCfsUxRuznXeiEtKHIN):
  YAkbljwTLcyQCfsUxRuznXeiEtKHIq={'accept':'application/json;pk={}'.format(YAkbljwTLcyQCfsUxRuznXeiEtKHIN.ST['cookies']['spotv_policyKey'])}
  return YAkbljwTLcyQCfsUxRuznXeiEtKHIq
 def xmlText(YAkbljwTLcyQCfsUxRuznXeiEtKHIN,in_text):
  YAkbljwTLcyQCfsUxRuznXeiEtKHID=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;')
  return YAkbljwTLcyQCfsUxRuznXeiEtKHID
 def GetNoCache(YAkbljwTLcyQCfsUxRuznXeiEtKHIN,timetype=1):
  if timetype==1:
   return YAkbljwTLcyQCfsUxRuznXeiEtKHva(time.time())
  else:
   return YAkbljwTLcyQCfsUxRuznXeiEtKHva(time.time()*1000)
 def GetCredential_new(YAkbljwTLcyQCfsUxRuznXeiEtKHIN,user_id,user_pw):
  YAkbljwTLcyQCfsUxRuznXeiEtKHIh=requests.session()
  try:
   YAkbljwTLcyQCfsUxRuznXeiEtKHIo='https://nid.spotvnow.co.kr/api/v3/oauth2/authorize/spotvnow?return_url=https%3A%2F%2Fwww.spotvnow.co.kr%2Fcheck&err_return_url=https%3A%2F%2Fwww.spotvnow.co.kr%2Fabout&logout_url=https%3A%2F%2Fwww.spotvnow.co.kr%2Fintro'
   YAkbljwTLcyQCfsUxRuznXeiEtKHIq={'User-Agent':YAkbljwTLcyQCfsUxRuznXeiEtKHIN.USER_AGENT,}
   while(YAkbljwTLcyQCfsUxRuznXeiEtKHIo not in['',YAkbljwTLcyQCfsUxRuznXeiEtKHvh]):
    YAkbljwTLcyQCfsUxRuznXeiEtKHIB=YAkbljwTLcyQCfsUxRuznXeiEtKHIh.get(YAkbljwTLcyQCfsUxRuznXeiEtKHIo,params=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,headers=YAkbljwTLcyQCfsUxRuznXeiEtKHIq,cookies=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.ST['cookies'],allow_redirects=YAkbljwTLcyQCfsUxRuznXeiEtKHvo)
    YAkbljwTLcyQCfsUxRuznXeiEtKHIo =YAkbljwTLcyQCfsUxRuznXeiEtKHIB.headers.get('location')
    for YAkbljwTLcyQCfsUxRuznXeiEtKHIJ in YAkbljwTLcyQCfsUxRuznXeiEtKHIB.cookies:
     if YAkbljwTLcyQCfsUxRuznXeiEtKHIJ.value not in['',YAkbljwTLcyQCfsUxRuznXeiEtKHvh]:
      YAkbljwTLcyQCfsUxRuznXeiEtKHIN.ST['cookies'][YAkbljwTLcyQCfsUxRuznXeiEtKHIJ.name]=YAkbljwTLcyQCfsUxRuznXeiEtKHIJ.value
    if YAkbljwTLcyQCfsUxRuznXeiEtKHIB.status_code==200:break
   if YAkbljwTLcyQCfsUxRuznXeiEtKHIN.ST['cookies']['login_challenge']=='':
    YAkbljwTLcyQCfsUxRuznXeiEtKHIN.Init_ST_Total()
    return YAkbljwTLcyQCfsUxRuznXeiEtKHvo
  except YAkbljwTLcyQCfsUxRuznXeiEtKHvp as exception:
   YAkbljwTLcyQCfsUxRuznXeiEtKHdI(exception)
   YAkbljwTLcyQCfsUxRuznXeiEtKHIN.Init_ST_Total()
   return YAkbljwTLcyQCfsUxRuznXeiEtKHvo
  try:
   YAkbljwTLcyQCfsUxRuznXeiEtKHIG=base64.standard_b64encode(user_id.encode('UTF-8')).decode('utf-8')
   YAkbljwTLcyQCfsUxRuznXeiEtKHIa=base64.standard_b64encode(user_pw.encode('UTF-8')).decode('utf-8')
   YAkbljwTLcyQCfsUxRuznXeiEtKHIo='https://nid.spotvnow.co.kr/api/v3/user-auth/login'
   YAkbljwTLcyQCfsUxRuznXeiEtKHIq={'User-Agent':YAkbljwTLcyQCfsUxRuznXeiEtKHIN.USER_AGENT,}
   YAkbljwTLcyQCfsUxRuznXeiEtKHIp={'username':YAkbljwTLcyQCfsUxRuznXeiEtKHIG,'password':YAkbljwTLcyQCfsUxRuznXeiEtKHIa,'remember':YAkbljwTLcyQCfsUxRuznXeiEtKHvG,'err_return_url':'https://www.spotvnow.co.kr/intro',}
   YAkbljwTLcyQCfsUxRuznXeiEtKHIB=YAkbljwTLcyQCfsUxRuznXeiEtKHIh.post(YAkbljwTLcyQCfsUxRuznXeiEtKHIo,data=YAkbljwTLcyQCfsUxRuznXeiEtKHIp,params=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,headers=YAkbljwTLcyQCfsUxRuznXeiEtKHIq,cookies=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.ST['cookies'],allow_redirects=YAkbljwTLcyQCfsUxRuznXeiEtKHvo)
   for YAkbljwTLcyQCfsUxRuznXeiEtKHIJ in YAkbljwTLcyQCfsUxRuznXeiEtKHIB.cookies:
    if YAkbljwTLcyQCfsUxRuznXeiEtKHIJ.value not in['',YAkbljwTLcyQCfsUxRuznXeiEtKHvh]:
     YAkbljwTLcyQCfsUxRuznXeiEtKHIN.ST['cookies'][YAkbljwTLcyQCfsUxRuznXeiEtKHIJ.name]=YAkbljwTLcyQCfsUxRuznXeiEtKHIJ.value
   YAkbljwTLcyQCfsUxRuznXeiEtKHIo=YAkbljwTLcyQCfsUxRuznXeiEtKHIB.headers.get('location')
   while(YAkbljwTLcyQCfsUxRuznXeiEtKHIo not in['',YAkbljwTLcyQCfsUxRuznXeiEtKHvh]):
    YAkbljwTLcyQCfsUxRuznXeiEtKHIq={'user-agent':YAkbljwTLcyQCfsUxRuznXeiEtKHIN.USER_AGENT,}
    YAkbljwTLcyQCfsUxRuznXeiEtKHIB=YAkbljwTLcyQCfsUxRuznXeiEtKHIh.get(YAkbljwTLcyQCfsUxRuznXeiEtKHIo,params=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,headers=YAkbljwTLcyQCfsUxRuznXeiEtKHIq,cookies=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.ST['cookies'],allow_redirects=YAkbljwTLcyQCfsUxRuznXeiEtKHvo)
    YAkbljwTLcyQCfsUxRuznXeiEtKHIo =YAkbljwTLcyQCfsUxRuznXeiEtKHIB.headers.get('location')
    for YAkbljwTLcyQCfsUxRuznXeiEtKHIJ in YAkbljwTLcyQCfsUxRuznXeiEtKHIB.cookies:
     if YAkbljwTLcyQCfsUxRuznXeiEtKHIJ.value not in['',YAkbljwTLcyQCfsUxRuznXeiEtKHvh]:
      YAkbljwTLcyQCfsUxRuznXeiEtKHIN.ST['cookies'][YAkbljwTLcyQCfsUxRuznXeiEtKHIJ.name]=YAkbljwTLcyQCfsUxRuznXeiEtKHIJ.value
    if YAkbljwTLcyQCfsUxRuznXeiEtKHIB.status_code==200:break
   if YAkbljwTLcyQCfsUxRuznXeiEtKHIN.ST['cookies']['id_token']=='':
    YAkbljwTLcyQCfsUxRuznXeiEtKHIN.Init_ST_Total()
    return YAkbljwTLcyQCfsUxRuznXeiEtKHvo
  except YAkbljwTLcyQCfsUxRuznXeiEtKHvp as exception:
   YAkbljwTLcyQCfsUxRuznXeiEtKHdI(exception)
   YAkbljwTLcyQCfsUxRuznXeiEtKHIN.Init_ST_Total()
   return YAkbljwTLcyQCfsUxRuznXeiEtKHvo
  try:
   YAkbljwTLcyQCfsUxRuznXeiEtKHIo=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.API_DOMAIN+'/api/v3/session' 
   YAkbljwTLcyQCfsUxRuznXeiEtKHIF=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.makeDefaultCookies()
   YAkbljwTLcyQCfsUxRuznXeiEtKHIB=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.callRequestCookies('Get',YAkbljwTLcyQCfsUxRuznXeiEtKHIo,params=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,headers=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,cookies=YAkbljwTLcyQCfsUxRuznXeiEtKHIF)
   YAkbljwTLcyQCfsUxRuznXeiEtKHPI=json.loads(YAkbljwTLcyQCfsUxRuznXeiEtKHIB.text)
   YAkbljwTLcyQCfsUxRuznXeiEtKHIN.ST['cookies']['spotv_sessionid']=YAkbljwTLcyQCfsUxRuznXeiEtKHPI.get('userId')
   YAkbljwTLcyQCfsUxRuznXeiEtKHPm=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.SPOTV_PMCODE+YAkbljwTLcyQCfsUxRuznXeiEtKHvB(YAkbljwTLcyQCfsUxRuznXeiEtKHPI['subEndTime'])
   YAkbljwTLcyQCfsUxRuznXeiEtKHIN.ST['cookies']['spotv_subend'] =base64.standard_b64encode(YAkbljwTLcyQCfsUxRuznXeiEtKHPm.encode()).decode('utf-8')
  except YAkbljwTLcyQCfsUxRuznXeiEtKHvp as exception:
   YAkbljwTLcyQCfsUxRuznXeiEtKHdI(exception)
   YAkbljwTLcyQCfsUxRuznXeiEtKHIN.Init_ST_Total()
   return YAkbljwTLcyQCfsUxRuznXeiEtKHvo
  try:
   if YAkbljwTLcyQCfsUxRuznXeiEtKHPI['subEndTime']in[0,'0',YAkbljwTLcyQCfsUxRuznXeiEtKHvh]:
    YAkbljwTLcyQCfsUxRuznXeiEtKHIo=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.API_DOMAIN+'/api/v3/user/sub/scope' 
    YAkbljwTLcyQCfsUxRuznXeiEtKHIF=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.makeDefaultCookies()
    YAkbljwTLcyQCfsUxRuznXeiEtKHIB=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.callRequestCookies('Get',YAkbljwTLcyQCfsUxRuznXeiEtKHIo,params=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,headers=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,cookies=YAkbljwTLcyQCfsUxRuznXeiEtKHIF)
    YAkbljwTLcyQCfsUxRuznXeiEtKHPI=json.loads(YAkbljwTLcyQCfsUxRuznXeiEtKHIB.text)
    if YAkbljwTLcyQCfsUxRuznXeiEtKHPI.get('endDate')==YAkbljwTLcyQCfsUxRuznXeiEtKHvh:
     YAkbljwTLcyQCfsUxRuznXeiEtKHPm=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.SPOTV_PMCODE+'0'
     YAkbljwTLcyQCfsUxRuznXeiEtKHIN.ST['cookies']['spotv_subend'] =base64.standard_b64encode(YAkbljwTLcyQCfsUxRuznXeiEtKHPm.encode()).decode('utf-8')
    else:
     YAkbljwTLcyQCfsUxRuznXeiEtKHPN=datetime.datetime.strptime(YAkbljwTLcyQCfsUxRuznXeiEtKHPI.get('endDate'),'%Y-%m-%d %H:%M:%S')
     YAkbljwTLcyQCfsUxRuznXeiEtKHPm=YAkbljwTLcyQCfsUxRuznXeiEtKHva(time.mktime(YAkbljwTLcyQCfsUxRuznXeiEtKHPN.timetuple()))
     YAkbljwTLcyQCfsUxRuznXeiEtKHPm=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.SPOTV_PMCODE+YAkbljwTLcyQCfsUxRuznXeiEtKHvB(YAkbljwTLcyQCfsUxRuznXeiEtKHPm)+'000'
     YAkbljwTLcyQCfsUxRuznXeiEtKHIN.ST['cookies']['spotv_subend'] =base64.standard_b64encode(YAkbljwTLcyQCfsUxRuznXeiEtKHPm.encode()).decode('utf-8')
  except YAkbljwTLcyQCfsUxRuznXeiEtKHvp as exception:
   YAkbljwTLcyQCfsUxRuznXeiEtKHdI(exception)
   YAkbljwTLcyQCfsUxRuznXeiEtKHIN.Init_ST_Total()
   return YAkbljwTLcyQCfsUxRuznXeiEtKHvo
  if YAkbljwTLcyQCfsUxRuznXeiEtKHIN.GetPolicyKey()==YAkbljwTLcyQCfsUxRuznXeiEtKHvo:
   YAkbljwTLcyQCfsUxRuznXeiEtKHIN.Init_ST_Total()
   return YAkbljwTLcyQCfsUxRuznXeiEtKHvo
  '''
  https://players.brightcove.net/5764318566001/2SXVGLGl4_default/index.min.js
    options: {accountId: "5764318566001", policyKey: "BCpkADawqM072_NUcqm8RBVoMGIaio2x979NvYhN4Zrs685jLKKYmCx_ssySm_0HFSnwPKQIbaekH1PnWGFk-nQCtuky-DlMgN4KNvNlPYjsojAi1fU9ozEXVSpULPylDb8STvOgPf-F941V-RbByAkzD8CgApyhBS8TNN-yDc17gnFUj82OEBP8DEo" }  
  '''  
  return YAkbljwTLcyQCfsUxRuznXeiEtKHvG
 def GetCredential(YAkbljwTLcyQCfsUxRuznXeiEtKHIN,user_id,user_pw):
  try:
   YAkbljwTLcyQCfsUxRuznXeiEtKHIG=base64.standard_b64encode(user_id.encode('UTF-8')).decode('utf-8')
   YAkbljwTLcyQCfsUxRuznXeiEtKHIa=base64.standard_b64encode(user_pw.encode('UTF-8')).decode('utf-8')
   YAkbljwTLcyQCfsUxRuznXeiEtKHPv=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.API_DOMAIN+'/api/v2/login'
   YAkbljwTLcyQCfsUxRuznXeiEtKHIp={'username':YAkbljwTLcyQCfsUxRuznXeiEtKHIG,'password':YAkbljwTLcyQCfsUxRuznXeiEtKHIa}
   YAkbljwTLcyQCfsUxRuznXeiEtKHIp=json.dumps(YAkbljwTLcyQCfsUxRuznXeiEtKHIp)
   YAkbljwTLcyQCfsUxRuznXeiEtKHIB=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.callRequestCookies('Post',YAkbljwTLcyQCfsUxRuznXeiEtKHPv,payload=YAkbljwTLcyQCfsUxRuznXeiEtKHIp,params=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,headers=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,cookies=YAkbljwTLcyQCfsUxRuznXeiEtKHvh)
   YAkbljwTLcyQCfsUxRuznXeiEtKHPd=json.loads(YAkbljwTLcyQCfsUxRuznXeiEtKHIB.text)
   for YAkbljwTLcyQCfsUxRuznXeiEtKHIJ in YAkbljwTLcyQCfsUxRuznXeiEtKHIB.cookies:
    if YAkbljwTLcyQCfsUxRuznXeiEtKHIJ.name=='SESSION':
     YAkbljwTLcyQCfsUxRuznXeiEtKHIN.ST['cookies']['spotv_session']=YAkbljwTLcyQCfsUxRuznXeiEtKHIJ.value
     break
   if YAkbljwTLcyQCfsUxRuznXeiEtKHIN.ST['cookies']['spotv_session']=='':
    YAkbljwTLcyQCfsUxRuznXeiEtKHIN.Init_ST_Total()
    return YAkbljwTLcyQCfsUxRuznXeiEtKHvo
   YAkbljwTLcyQCfsUxRuznXeiEtKHIN.ST['cookies']['spotv_sessionid']=YAkbljwTLcyQCfsUxRuznXeiEtKHvB(YAkbljwTLcyQCfsUxRuznXeiEtKHPd['userId'])
   YAkbljwTLcyQCfsUxRuznXeiEtKHPm=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.SPOTV_PMCODE+YAkbljwTLcyQCfsUxRuznXeiEtKHvB(YAkbljwTLcyQCfsUxRuznXeiEtKHPd['subEndTime'])
   YAkbljwTLcyQCfsUxRuznXeiEtKHIN.ST['cookies']['spotv_subend'] =base64.standard_b64encode(YAkbljwTLcyQCfsUxRuznXeiEtKHPm.encode()).decode('utf-8')
   if YAkbljwTLcyQCfsUxRuznXeiEtKHIN.GetPolicyKey()==YAkbljwTLcyQCfsUxRuznXeiEtKHvo:
    YAkbljwTLcyQCfsUxRuznXeiEtKHIN.Init_ST_Total()
    return YAkbljwTLcyQCfsUxRuznXeiEtKHvo
  except YAkbljwTLcyQCfsUxRuznXeiEtKHvp as exception:
   YAkbljwTLcyQCfsUxRuznXeiEtKHdI(exception)
   YAkbljwTLcyQCfsUxRuznXeiEtKHIN.Init_ST_Total()
   return YAkbljwTLcyQCfsUxRuznXeiEtKHvo
  return YAkbljwTLcyQCfsUxRuznXeiEtKHvG
 def GetPolicyKey(YAkbljwTLcyQCfsUxRuznXeiEtKHIN):
  try:
   YAkbljwTLcyQCfsUxRuznXeiEtKHIo=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.GetBcPlayerUrl()
   if YAkbljwTLcyQCfsUxRuznXeiEtKHIo=='':return YAkbljwTLcyQCfsUxRuznXeiEtKHvo
   YAkbljwTLcyQCfsUxRuznXeiEtKHIB=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.callRequestCookies('Get',YAkbljwTLcyQCfsUxRuznXeiEtKHIo,payload=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,params=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,headers=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,cookies=YAkbljwTLcyQCfsUxRuznXeiEtKHvh)
   YAkbljwTLcyQCfsUxRuznXeiEtKHPW=YAkbljwTLcyQCfsUxRuznXeiEtKHIB.text
   YAkbljwTLcyQCfsUxRuznXeiEtKHPO =re.findall('accountId:\s*\"\d{13}\",\s*policyKey:\s*\".[^(){}]{100,300}\"',YAkbljwTLcyQCfsUxRuznXeiEtKHPW)[0]
   YAkbljwTLcyQCfsUxRuznXeiEtKHPO =YAkbljwTLcyQCfsUxRuznXeiEtKHPO.replace('accountId','"accountId"')
   YAkbljwTLcyQCfsUxRuznXeiEtKHPO =YAkbljwTLcyQCfsUxRuznXeiEtKHPO.replace('policyKey','"policyKey"')
   YAkbljwTLcyQCfsUxRuznXeiEtKHPO ='{'+YAkbljwTLcyQCfsUxRuznXeiEtKHPO+'}'
   YAkbljwTLcyQCfsUxRuznXeiEtKHPS=json.loads(YAkbljwTLcyQCfsUxRuznXeiEtKHPO)
   YAkbljwTLcyQCfsUxRuznXeiEtKHIN.ST['cookies']['spotv_accountId']=YAkbljwTLcyQCfsUxRuznXeiEtKHPS['accountId']
   YAkbljwTLcyQCfsUxRuznXeiEtKHIN.ST['cookies']['spotv_policyKey']=YAkbljwTLcyQCfsUxRuznXeiEtKHPS['policyKey']
  except YAkbljwTLcyQCfsUxRuznXeiEtKHvp as exception:
   YAkbljwTLcyQCfsUxRuznXeiEtKHdI(exception)
   return YAkbljwTLcyQCfsUxRuznXeiEtKHvo
  return YAkbljwTLcyQCfsUxRuznXeiEtKHvG
 def GetBcPlayerUrl(YAkbljwTLcyQCfsUxRuznXeiEtKHIN):
  YAkbljwTLcyQCfsUxRuznXeiEtKHPr=''
  try:
   YAkbljwTLcyQCfsUxRuznXeiEtKHIo=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.GetMainJspath()
   if YAkbljwTLcyQCfsUxRuznXeiEtKHIo=='':return YAkbljwTLcyQCfsUxRuznXeiEtKHPr
   YAkbljwTLcyQCfsUxRuznXeiEtKHIB=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.callRequestCookies('Get',YAkbljwTLcyQCfsUxRuznXeiEtKHIo,payload=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,params=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,headers=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,cookies=YAkbljwTLcyQCfsUxRuznXeiEtKHvh)
   YAkbljwTLcyQCfsUxRuznXeiEtKHPW=YAkbljwTLcyQCfsUxRuznXeiEtKHIB.text
   YAkbljwTLcyQCfsUxRuznXeiEtKHPV =r'default:{(.*?)}'
   YAkbljwTLcyQCfsUxRuznXeiEtKHPg =re.compile(YAkbljwTLcyQCfsUxRuznXeiEtKHPV).findall(YAkbljwTLcyQCfsUxRuznXeiEtKHPW)[0]
   YAkbljwTLcyQCfsUxRuznXeiEtKHPM=r'bc:"(.*?)"'
   YAkbljwTLcyQCfsUxRuznXeiEtKHPF=re.compile(YAkbljwTLcyQCfsUxRuznXeiEtKHPM).findall(YAkbljwTLcyQCfsUxRuznXeiEtKHPg)[0]
   YAkbljwTLcyQCfsUxRuznXeiEtKHPq=r'":"(.*?)"'
   YAkbljwTLcyQCfsUxRuznXeiEtKHPD=re.compile(YAkbljwTLcyQCfsUxRuznXeiEtKHPq).findall(YAkbljwTLcyQCfsUxRuznXeiEtKHPg)[0]
   YAkbljwTLcyQCfsUxRuznXeiEtKHPr="%s/%s/%s_default/index.min.js"%(YAkbljwTLcyQCfsUxRuznXeiEtKHIN.BC_DOMAIN,YAkbljwTLcyQCfsUxRuznXeiEtKHPF,YAkbljwTLcyQCfsUxRuznXeiEtKHPD)
  except YAkbljwTLcyQCfsUxRuznXeiEtKHvp as exception:
   YAkbljwTLcyQCfsUxRuznXeiEtKHdI(exception)
  return YAkbljwTLcyQCfsUxRuznXeiEtKHPr
 def GetMainJspath(YAkbljwTLcyQCfsUxRuznXeiEtKHIN):
  YAkbljwTLcyQCfsUxRuznXeiEtKHPh=''
  try:
   YAkbljwTLcyQCfsUxRuznXeiEtKHIo=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.API_DOMAIN
   YAkbljwTLcyQCfsUxRuznXeiEtKHIB=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.callRequestCookies('Get',YAkbljwTLcyQCfsUxRuznXeiEtKHIo,payload=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,params=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,headers=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,cookies=YAkbljwTLcyQCfsUxRuznXeiEtKHvh)
   YAkbljwTLcyQCfsUxRuznXeiEtKHPW=YAkbljwTLcyQCfsUxRuznXeiEtKHIB.text
   YAkbljwTLcyQCfsUxRuznXeiEtKHPO =re.findall('https://cdn.spotvnow.co.kr/dist/js/.{20}\.js',YAkbljwTLcyQCfsUxRuznXeiEtKHPW)[0]
   YAkbljwTLcyQCfsUxRuznXeiEtKHPh=YAkbljwTLcyQCfsUxRuznXeiEtKHPO
  except YAkbljwTLcyQCfsUxRuznXeiEtKHvp as exception:
   YAkbljwTLcyQCfsUxRuznXeiEtKHdI(exception)
  return YAkbljwTLcyQCfsUxRuznXeiEtKHPh
 def Get_Now_Datetime(YAkbljwTLcyQCfsUxRuznXeiEtKHIN):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetLiveChannelList(YAkbljwTLcyQCfsUxRuznXeiEtKHIN):
  YAkbljwTLcyQCfsUxRuznXeiEtKHPB=[]
  YAkbljwTLcyQCfsUxRuznXeiEtKHPJ ={}
  try:
   YAkbljwTLcyQCfsUxRuznXeiEtKHIo=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.API_DOMAIN+'/api/v3/channel'
   YAkbljwTLcyQCfsUxRuznXeiEtKHIB=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.callRequestCookies('Get',YAkbljwTLcyQCfsUxRuznXeiEtKHIo,payload=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,params=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,headers=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,cookies=YAkbljwTLcyQCfsUxRuznXeiEtKHvh)
   YAkbljwTLcyQCfsUxRuznXeiEtKHPd=json.loads(YAkbljwTLcyQCfsUxRuznXeiEtKHIB.text)
   YAkbljwTLcyQCfsUxRuznXeiEtKHPJ=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.GetEPGList()
   for YAkbljwTLcyQCfsUxRuznXeiEtKHPG in YAkbljwTLcyQCfsUxRuznXeiEtKHPd:
    YAkbljwTLcyQCfsUxRuznXeiEtKHPa={'id':YAkbljwTLcyQCfsUxRuznXeiEtKHPG['id'],'name':YAkbljwTLcyQCfsUxRuznXeiEtKHPG['name'],'logo':YAkbljwTLcyQCfsUxRuznXeiEtKHPG['logo'],'free':YAkbljwTLcyQCfsUxRuznXeiEtKHPG['free'],'programName':YAkbljwTLcyQCfsUxRuznXeiEtKHPG['programName'],'channelepg':YAkbljwTLcyQCfsUxRuznXeiEtKHPJ.get(YAkbljwTLcyQCfsUxRuznXeiEtKHPG['id']),}
    YAkbljwTLcyQCfsUxRuznXeiEtKHPB.append(YAkbljwTLcyQCfsUxRuznXeiEtKHPa)
  except YAkbljwTLcyQCfsUxRuznXeiEtKHvp as exception:
   YAkbljwTLcyQCfsUxRuznXeiEtKHdI(exception)
  return YAkbljwTLcyQCfsUxRuznXeiEtKHPB
 def GetHlsUrl(YAkbljwTLcyQCfsUxRuznXeiEtKHIN,mediacode):
  YAkbljwTLcyQCfsUxRuznXeiEtKHPp=''
  try:
   YAkbljwTLcyQCfsUxRuznXeiEtKHIo=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.API_DOMAIN+'/api/v3/channel/'+mediacode
   YAkbljwTLcyQCfsUxRuznXeiEtKHIB=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.callRequestCookies('Get',YAkbljwTLcyQCfsUxRuznXeiEtKHIo,payload=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,params=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,headers=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,cookies=YAkbljwTLcyQCfsUxRuznXeiEtKHvh)
   YAkbljwTLcyQCfsUxRuznXeiEtKHPd=json.loads(YAkbljwTLcyQCfsUxRuznXeiEtKHIB.text)
   YAkbljwTLcyQCfsUxRuznXeiEtKHPp=YAkbljwTLcyQCfsUxRuznXeiEtKHPd['hlsUrl']
  except YAkbljwTLcyQCfsUxRuznXeiEtKHvp as exception:
   YAkbljwTLcyQCfsUxRuznXeiEtKHdI(exception)
  return YAkbljwTLcyQCfsUxRuznXeiEtKHPp
 def GetEPGList(YAkbljwTLcyQCfsUxRuznXeiEtKHIN):
  YAkbljwTLcyQCfsUxRuznXeiEtKHmI={}
  YAkbljwTLcyQCfsUxRuznXeiEtKHmP=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.Get_Now_Datetime()
  YAkbljwTLcyQCfsUxRuznXeiEtKHmN=YAkbljwTLcyQCfsUxRuznXeiEtKHmP.strftime('%Y%m%d%H%M')
  YAkbljwTLcyQCfsUxRuznXeiEtKHmv='%s-%s-%s'%(YAkbljwTLcyQCfsUxRuznXeiEtKHmN[0:4],YAkbljwTLcyQCfsUxRuznXeiEtKHmN[4:6],YAkbljwTLcyQCfsUxRuznXeiEtKHmN[6:8])
  YAkbljwTLcyQCfsUxRuznXeiEtKHmd=(YAkbljwTLcyQCfsUxRuznXeiEtKHmP+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M')
  try:
   YAkbljwTLcyQCfsUxRuznXeiEtKHIo=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.API_DOMAIN+'/api/v3/program/'+YAkbljwTLcyQCfsUxRuznXeiEtKHmv
   YAkbljwTLcyQCfsUxRuznXeiEtKHIB=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.callRequestCookies('Get',YAkbljwTLcyQCfsUxRuznXeiEtKHIo,payload=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,params=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,headers=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,cookies=YAkbljwTLcyQCfsUxRuznXeiEtKHvh)
   YAkbljwTLcyQCfsUxRuznXeiEtKHPd=json.loads(YAkbljwTLcyQCfsUxRuznXeiEtKHIB.text)
   YAkbljwTLcyQCfsUxRuznXeiEtKHmW=-1 
   YAkbljwTLcyQCfsUxRuznXeiEtKHmO =''
   for YAkbljwTLcyQCfsUxRuznXeiEtKHPG in YAkbljwTLcyQCfsUxRuznXeiEtKHPd:
    YAkbljwTLcyQCfsUxRuznXeiEtKHmS=YAkbljwTLcyQCfsUxRuznXeiEtKHPG['channelId']
    YAkbljwTLcyQCfsUxRuznXeiEtKHmr =YAkbljwTLcyQCfsUxRuznXeiEtKHPG['startTime'].replace('-','').replace(' ','').replace(':','')
    YAkbljwTLcyQCfsUxRuznXeiEtKHmV =YAkbljwTLcyQCfsUxRuznXeiEtKHPG['endTime'].replace('-','').replace(' ','').replace(':','')
    if YAkbljwTLcyQCfsUxRuznXeiEtKHva(YAkbljwTLcyQCfsUxRuznXeiEtKHmN)>YAkbljwTLcyQCfsUxRuznXeiEtKHva(YAkbljwTLcyQCfsUxRuznXeiEtKHmV) :continue
    if YAkbljwTLcyQCfsUxRuznXeiEtKHva(YAkbljwTLcyQCfsUxRuznXeiEtKHmd)<YAkbljwTLcyQCfsUxRuznXeiEtKHva(YAkbljwTLcyQCfsUxRuznXeiEtKHmr):continue
    if YAkbljwTLcyQCfsUxRuznXeiEtKHmW!=YAkbljwTLcyQCfsUxRuznXeiEtKHmS:
     if YAkbljwTLcyQCfsUxRuznXeiEtKHmO!='':YAkbljwTLcyQCfsUxRuznXeiEtKHmI[YAkbljwTLcyQCfsUxRuznXeiEtKHmW]=YAkbljwTLcyQCfsUxRuznXeiEtKHmO
     YAkbljwTLcyQCfsUxRuznXeiEtKHmW=YAkbljwTLcyQCfsUxRuznXeiEtKHmS
     YAkbljwTLcyQCfsUxRuznXeiEtKHmO =''
    if YAkbljwTLcyQCfsUxRuznXeiEtKHmO:YAkbljwTLcyQCfsUxRuznXeiEtKHmO+='\n'
    YAkbljwTLcyQCfsUxRuznXeiEtKHmO+=YAkbljwTLcyQCfsUxRuznXeiEtKHPG['title']+'\n'
    YAkbljwTLcyQCfsUxRuznXeiEtKHmO+=' [%s ~ %s]'%(YAkbljwTLcyQCfsUxRuznXeiEtKHPG['startTime'][-5:],YAkbljwTLcyQCfsUxRuznXeiEtKHPG['endTime'][-5:])+'\n'
   if YAkbljwTLcyQCfsUxRuznXeiEtKHmO:YAkbljwTLcyQCfsUxRuznXeiEtKHmI[YAkbljwTLcyQCfsUxRuznXeiEtKHmW]=YAkbljwTLcyQCfsUxRuznXeiEtKHmO
  except YAkbljwTLcyQCfsUxRuznXeiEtKHvp as exception:
   YAkbljwTLcyQCfsUxRuznXeiEtKHdI(exception)
  return YAkbljwTLcyQCfsUxRuznXeiEtKHmI
 def GetEPGList_new(YAkbljwTLcyQCfsUxRuznXeiEtKHIN):
  YAkbljwTLcyQCfsUxRuznXeiEtKHmI={}
  YAkbljwTLcyQCfsUxRuznXeiEtKHmP=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.Get_Now_Datetime()
  YAkbljwTLcyQCfsUxRuznXeiEtKHmN=YAkbljwTLcyQCfsUxRuznXeiEtKHmP.strftime('%Y%m%d%H%M00')
  YAkbljwTLcyQCfsUxRuznXeiEtKHmv='%s%s%s'%(YAkbljwTLcyQCfsUxRuznXeiEtKHmN[0:4],YAkbljwTLcyQCfsUxRuznXeiEtKHmN[4:6],YAkbljwTLcyQCfsUxRuznXeiEtKHmN[6:8])
  YAkbljwTLcyQCfsUxRuznXeiEtKHmd=(YAkbljwTLcyQCfsUxRuznXeiEtKHmP+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M00')
  try:
   for YAkbljwTLcyQCfsUxRuznXeiEtKHPG in LIVETV_LIST:
    YAkbljwTLcyQCfsUxRuznXeiEtKHmg =YAkbljwTLcyQCfsUxRuznXeiEtKHPG['videoId']
    if YAkbljwTLcyQCfsUxRuznXeiEtKHPG['epgtype']=='spotvon':
     YAkbljwTLcyQCfsUxRuznXeiEtKHmO=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.Get_EpgInfo_Spotv_spotvon(YAkbljwTLcyQCfsUxRuznXeiEtKHmg,YAkbljwTLcyQCfsUxRuznXeiEtKHPG['epgnm'],YAkbljwTLcyQCfsUxRuznXeiEtKHmv)
     YAkbljwTLcyQCfsUxRuznXeiEtKHmI[YAkbljwTLcyQCfsUxRuznXeiEtKHmg]=YAkbljwTLcyQCfsUxRuznXeiEtKHmO
    if YAkbljwTLcyQCfsUxRuznXeiEtKHPG['epgtype']=='spotvnet':
     YAkbljwTLcyQCfsUxRuznXeiEtKHmO=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.Get_EpgInfo_Spotv_spotvnet(YAkbljwTLcyQCfsUxRuznXeiEtKHmg,YAkbljwTLcyQCfsUxRuznXeiEtKHPG['epgnm'],YAkbljwTLcyQCfsUxRuznXeiEtKHmv)
     YAkbljwTLcyQCfsUxRuznXeiEtKHmI[YAkbljwTLcyQCfsUxRuznXeiEtKHmg]=YAkbljwTLcyQCfsUxRuznXeiEtKHmO
   for YAkbljwTLcyQCfsUxRuznXeiEtKHmM in YAkbljwTLcyQCfsUxRuznXeiEtKHmI.keys():
    if YAkbljwTLcyQCfsUxRuznXeiEtKHdP(YAkbljwTLcyQCfsUxRuznXeiEtKHmI.get(YAkbljwTLcyQCfsUxRuznXeiEtKHmM))==0:continue
    YAkbljwTLcyQCfsUxRuznXeiEtKHmO =''
    YAkbljwTLcyQCfsUxRuznXeiEtKHmF=''
    for YAkbljwTLcyQCfsUxRuznXeiEtKHmq in YAkbljwTLcyQCfsUxRuznXeiEtKHmI.get(YAkbljwTLcyQCfsUxRuznXeiEtKHmM):
     YAkbljwTLcyQCfsUxRuznXeiEtKHmr =YAkbljwTLcyQCfsUxRuznXeiEtKHmq['startTime']
     YAkbljwTLcyQCfsUxRuznXeiEtKHmV =YAkbljwTLcyQCfsUxRuznXeiEtKHmq['endTime']
     if YAkbljwTLcyQCfsUxRuznXeiEtKHva(YAkbljwTLcyQCfsUxRuznXeiEtKHmN)>YAkbljwTLcyQCfsUxRuznXeiEtKHva(YAkbljwTLcyQCfsUxRuznXeiEtKHmV) :continue
     if YAkbljwTLcyQCfsUxRuznXeiEtKHva(YAkbljwTLcyQCfsUxRuznXeiEtKHmd)<YAkbljwTLcyQCfsUxRuznXeiEtKHva(YAkbljwTLcyQCfsUxRuznXeiEtKHmr):continue
     if YAkbljwTLcyQCfsUxRuznXeiEtKHva(YAkbljwTLcyQCfsUxRuznXeiEtKHmN)>=YAkbljwTLcyQCfsUxRuznXeiEtKHva(YAkbljwTLcyQCfsUxRuznXeiEtKHmr)and YAkbljwTLcyQCfsUxRuznXeiEtKHva(YAkbljwTLcyQCfsUxRuznXeiEtKHmN)<YAkbljwTLcyQCfsUxRuznXeiEtKHva(YAkbljwTLcyQCfsUxRuznXeiEtKHmV):YAkbljwTLcyQCfsUxRuznXeiEtKHmF=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.xmlText(YAkbljwTLcyQCfsUxRuznXeiEtKHmq['title'])
     if YAkbljwTLcyQCfsUxRuznXeiEtKHmO:YAkbljwTLcyQCfsUxRuznXeiEtKHmO+='\n'
     YAkbljwTLcyQCfsUxRuznXeiEtKHmO+=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.xmlText(YAkbljwTLcyQCfsUxRuznXeiEtKHmq['title'])+'\n'
     YAkbljwTLcyQCfsUxRuznXeiEtKHmO+=' [%s:%s ~ %s:%s]'%(YAkbljwTLcyQCfsUxRuznXeiEtKHmq['startTime'][8:10],YAkbljwTLcyQCfsUxRuznXeiEtKHmq['startTime'][10:12],YAkbljwTLcyQCfsUxRuznXeiEtKHmq['endTime'][8:10],YAkbljwTLcyQCfsUxRuznXeiEtKHmq['endTime'][10:12])+'\n'
    YAkbljwTLcyQCfsUxRuznXeiEtKHmI[YAkbljwTLcyQCfsUxRuznXeiEtKHmM]={'epg':YAkbljwTLcyQCfsUxRuznXeiEtKHmO,'title':YAkbljwTLcyQCfsUxRuznXeiEtKHmF}
  except YAkbljwTLcyQCfsUxRuznXeiEtKHvp as exception:
   YAkbljwTLcyQCfsUxRuznXeiEtKHdI(exception)
  return YAkbljwTLcyQCfsUxRuznXeiEtKHmI
 def Get_EpgInfo_Spotv_spotvon(YAkbljwTLcyQCfsUxRuznXeiEtKHIN,YAkbljwTLcyQCfsUxRuznXeiEtKHmg,epgnm,now_day):
  YAkbljwTLcyQCfsUxRuznXeiEtKHmI =[]
  try:
   YAkbljwTLcyQCfsUxRuznXeiEtKHIo='https://www.spotvon.co.kr/data/onAir/%s/Daily/D%s.asp'%(epgnm,now_day)
   YAkbljwTLcyQCfsUxRuznXeiEtKHIB=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.callRequestCookies('Get',YAkbljwTLcyQCfsUxRuznXeiEtKHIo,payload=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,params=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,headers=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,cookies=YAkbljwTLcyQCfsUxRuznXeiEtKHvh)
   YAkbljwTLcyQCfsUxRuznXeiEtKHPI=json.loads(YAkbljwTLcyQCfsUxRuznXeiEtKHIB.text)
   for YAkbljwTLcyQCfsUxRuznXeiEtKHPG in YAkbljwTLcyQCfsUxRuznXeiEtKHPI:
    YAkbljwTLcyQCfsUxRuznXeiEtKHPa={'title':YAkbljwTLcyQCfsUxRuznXeiEtKHPG['title'],'startTime':YAkbljwTLcyQCfsUxRuznXeiEtKHPG['sch_date'].replace('-','')+YAkbljwTLcyQCfsUxRuznXeiEtKHvB(YAkbljwTLcyQCfsUxRuznXeiEtKHPG['sch_hour']).zfill(2)+YAkbljwTLcyQCfsUxRuznXeiEtKHPG['sch_min']+'00'}
    YAkbljwTLcyQCfsUxRuznXeiEtKHmI.append(YAkbljwTLcyQCfsUxRuznXeiEtKHPa)
   for i in YAkbljwTLcyQCfsUxRuznXeiEtKHdm(YAkbljwTLcyQCfsUxRuznXeiEtKHdP(YAkbljwTLcyQCfsUxRuznXeiEtKHmI)):
    if i>0:YAkbljwTLcyQCfsUxRuznXeiEtKHmI[i-1]['endTime']=YAkbljwTLcyQCfsUxRuznXeiEtKHmI[i]['startTime']
    if i==YAkbljwTLcyQCfsUxRuznXeiEtKHdP(YAkbljwTLcyQCfsUxRuznXeiEtKHmI)-1: YAkbljwTLcyQCfsUxRuznXeiEtKHmI[i]['endTime']=now_day+'240000'
  except YAkbljwTLcyQCfsUxRuznXeiEtKHvp as exception:
   YAkbljwTLcyQCfsUxRuznXeiEtKHdI(exception)
   return[]
  return YAkbljwTLcyQCfsUxRuznXeiEtKHmI
 def Get_EpgInfo_Spotv_spotvnet(YAkbljwTLcyQCfsUxRuznXeiEtKHIN,YAkbljwTLcyQCfsUxRuznXeiEtKHmg,epgnm,now_day):
  YAkbljwTLcyQCfsUxRuznXeiEtKHmI =[]
  try:
   YAkbljwTLcyQCfsUxRuznXeiEtKHIo='https://www.spotv.net/data/json/schedule/%s/Daily/D%s.json'%(epgnm,now_day)
   YAkbljwTLcyQCfsUxRuznXeiEtKHIB=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.callRequestCookies('Get',YAkbljwTLcyQCfsUxRuznXeiEtKHIo,payload=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,params=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,headers=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,cookies=YAkbljwTLcyQCfsUxRuznXeiEtKHvh)
   YAkbljwTLcyQCfsUxRuznXeiEtKHPI=json.loads(YAkbljwTLcyQCfsUxRuznXeiEtKHIB.text)
   for YAkbljwTLcyQCfsUxRuznXeiEtKHPG in YAkbljwTLcyQCfsUxRuznXeiEtKHPI:
    YAkbljwTLcyQCfsUxRuznXeiEtKHPa={'title':YAkbljwTLcyQCfsUxRuznXeiEtKHPG['title'],'startTime':YAkbljwTLcyQCfsUxRuznXeiEtKHPG['sch_date'].replace('-','')+YAkbljwTLcyQCfsUxRuznXeiEtKHvB(YAkbljwTLcyQCfsUxRuznXeiEtKHPG['sch_hour']).zfill(2)+YAkbljwTLcyQCfsUxRuznXeiEtKHPG['sch_min']+'00'}
    YAkbljwTLcyQCfsUxRuznXeiEtKHmI.append(YAkbljwTLcyQCfsUxRuznXeiEtKHPa)
   for i in YAkbljwTLcyQCfsUxRuznXeiEtKHdm(YAkbljwTLcyQCfsUxRuznXeiEtKHdP(YAkbljwTLcyQCfsUxRuznXeiEtKHmI)):
    if i>0:YAkbljwTLcyQCfsUxRuznXeiEtKHmI[i-1]['endTime']=YAkbljwTLcyQCfsUxRuznXeiEtKHmI[i]['startTime']
    if i==YAkbljwTLcyQCfsUxRuznXeiEtKHdP(YAkbljwTLcyQCfsUxRuznXeiEtKHmI)-1: YAkbljwTLcyQCfsUxRuznXeiEtKHmI[i]['endTime']=now_day+'240000'
  except YAkbljwTLcyQCfsUxRuznXeiEtKHvp as exception:
   YAkbljwTLcyQCfsUxRuznXeiEtKHdI(exception)
   return[]
  return YAkbljwTLcyQCfsUxRuznXeiEtKHmI
 def GetEventLiveList(YAkbljwTLcyQCfsUxRuznXeiEtKHIN):
  YAkbljwTLcyQCfsUxRuznXeiEtKHPB=[]
  YAkbljwTLcyQCfsUxRuznXeiEtKHmD =0
  try:
   YAkbljwTLcyQCfsUxRuznXeiEtKHmh=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.Get_Now_Datetime()
   YAkbljwTLcyQCfsUxRuznXeiEtKHmo=YAkbljwTLcyQCfsUxRuznXeiEtKHmh.strftime('%Y-%m-%d')
  except YAkbljwTLcyQCfsUxRuznXeiEtKHvp as exception:
   YAkbljwTLcyQCfsUxRuznXeiEtKHdI(exception)
   return YAkbljwTLcyQCfsUxRuznXeiEtKHPB,YAkbljwTLcyQCfsUxRuznXeiEtKHmD
  YAkbljwTLcyQCfsUxRuznXeiEtKHIo=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.API_DOMAIN+'/api/v3/player/lives/'+YAkbljwTLcyQCfsUxRuznXeiEtKHmo 
  YAkbljwTLcyQCfsUxRuznXeiEtKHIF=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.makeDefaultCookies()
  YAkbljwTLcyQCfsUxRuznXeiEtKHIB=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.callRequestCookies('Get',YAkbljwTLcyQCfsUxRuznXeiEtKHIo,payload=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,params=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,headers=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,cookies=YAkbljwTLcyQCfsUxRuznXeiEtKHIF)
  YAkbljwTLcyQCfsUxRuznXeiEtKHmD=YAkbljwTLcyQCfsUxRuznXeiEtKHIB.status_code 
  if YAkbljwTLcyQCfsUxRuznXeiEtKHmD!=200:return YAkbljwTLcyQCfsUxRuznXeiEtKHPB,YAkbljwTLcyQCfsUxRuznXeiEtKHmD
  YAkbljwTLcyQCfsUxRuznXeiEtKHPd=json.loads(YAkbljwTLcyQCfsUxRuznXeiEtKHIB.text)
  for YAkbljwTLcyQCfsUxRuznXeiEtKHmB in YAkbljwTLcyQCfsUxRuznXeiEtKHPd:
   for YAkbljwTLcyQCfsUxRuznXeiEtKHPG in YAkbljwTLcyQCfsUxRuznXeiEtKHmB['liveNowList']:
    if YAkbljwTLcyQCfsUxRuznXeiEtKHPG['gameDesc']['title']==YAkbljwTLcyQCfsUxRuznXeiEtKHvh or YAkbljwTLcyQCfsUxRuznXeiEtKHPG['gameDesc']['title']=='':
     YAkbljwTLcyQCfsUxRuznXeiEtKHmJ='%s ( %s : %s )'%(YAkbljwTLcyQCfsUxRuznXeiEtKHPG['leagueName'],YAkbljwTLcyQCfsUxRuznXeiEtKHPG['homeNameShort'],YAkbljwTLcyQCfsUxRuznXeiEtKHPG['awayNameShort'])
    else:
     YAkbljwTLcyQCfsUxRuznXeiEtKHmJ=YAkbljwTLcyQCfsUxRuznXeiEtKHPG['gameDesc']['title']
    YAkbljwTLcyQCfsUxRuznXeiEtKHPa={'liveId':YAkbljwTLcyQCfsUxRuznXeiEtKHPG['liveId'],'title':YAkbljwTLcyQCfsUxRuznXeiEtKHmJ,'logo':YAkbljwTLcyQCfsUxRuznXeiEtKHPG['gameDesc']['leagueLogo'],'free':YAkbljwTLcyQCfsUxRuznXeiEtKHPG['isFree'],'startTime':YAkbljwTLcyQCfsUxRuznXeiEtKHPG['startTime']}
    YAkbljwTLcyQCfsUxRuznXeiEtKHPB.append(YAkbljwTLcyQCfsUxRuznXeiEtKHPa)
  return YAkbljwTLcyQCfsUxRuznXeiEtKHPB,YAkbljwTLcyQCfsUxRuznXeiEtKHmD
 def GetEventLive_videoId(YAkbljwTLcyQCfsUxRuznXeiEtKHIN,liveId):
  YAkbljwTLcyQCfsUxRuznXeiEtKHmG=''
  try:
   YAkbljwTLcyQCfsUxRuznXeiEtKHIo=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.API_DOMAIN+'/api/v3/live/'+liveId
   YAkbljwTLcyQCfsUxRuznXeiEtKHIB=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.callRequestCookies('Get',YAkbljwTLcyQCfsUxRuznXeiEtKHIo,payload=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,params=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,headers=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,cookies=YAkbljwTLcyQCfsUxRuznXeiEtKHvh)
   YAkbljwTLcyQCfsUxRuznXeiEtKHPd=json.loads(YAkbljwTLcyQCfsUxRuznXeiEtKHIB.text)
   YAkbljwTLcyQCfsUxRuznXeiEtKHma=YAkbljwTLcyQCfsUxRuznXeiEtKHPd['videoId']
   YAkbljwTLcyQCfsUxRuznXeiEtKHmG=YAkbljwTLcyQCfsUxRuznXeiEtKHma.replace('ref:','')
  except YAkbljwTLcyQCfsUxRuznXeiEtKHvp as exception:
   YAkbljwTLcyQCfsUxRuznXeiEtKHdI(exception)
  return YAkbljwTLcyQCfsUxRuznXeiEtKHmG
 def CheckMainEnd(YAkbljwTLcyQCfsUxRuznXeiEtKHIN):
  YAkbljwTLcyQCfsUxRuznXeiEtKHmp=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.SPOTV_PMCODE+YAkbljwTLcyQCfsUxRuznXeiEtKHvB(YAkbljwTLcyQCfsUxRuznXeiEtKHIN.ST['cookies']['spotv_sessionid'])
  YAkbljwTLcyQCfsUxRuznXeiEtKHmp=base64.standard_b64encode(YAkbljwTLcyQCfsUxRuznXeiEtKHmp.encode()).decode('utf-8')
  if YAkbljwTLcyQCfsUxRuznXeiEtKHmp=='OTg3MTgzMzM0Ng==' or YAkbljwTLcyQCfsUxRuznXeiEtKHmp=='OTg3MTgzMzExNw==':return YAkbljwTLcyQCfsUxRuznXeiEtKHvG
  return YAkbljwTLcyQCfsUxRuznXeiEtKHvo
 def CheckSubEnd(YAkbljwTLcyQCfsUxRuznXeiEtKHIN):
  YAkbljwTLcyQCfsUxRuznXeiEtKHIV=YAkbljwTLcyQCfsUxRuznXeiEtKHvo
  try:
   if YAkbljwTLcyQCfsUxRuznXeiEtKHIN.CheckMainEnd():return YAkbljwTLcyQCfsUxRuznXeiEtKHvG 
   YAkbljwTLcyQCfsUxRuznXeiEtKHNI=base64.standard_b64decode(YAkbljwTLcyQCfsUxRuznXeiEtKHIN.ST['cookies']['spotv_subend']).decode('utf-8')[YAkbljwTLcyQCfsUxRuznXeiEtKHIN.SPOTV_PMSIZE:]
   if YAkbljwTLcyQCfsUxRuznXeiEtKHNI=='0':return YAkbljwTLcyQCfsUxRuznXeiEtKHIV
   YAkbljwTLcyQCfsUxRuznXeiEtKHNP =YAkbljwTLcyQCfsUxRuznXeiEtKHva(YAkbljwTLcyQCfsUxRuznXeiEtKHIN.Get_Now_Datetime().strftime('%Y%m%d'))
   YAkbljwTLcyQCfsUxRuznXeiEtKHNm =YAkbljwTLcyQCfsUxRuznXeiEtKHva(YAkbljwTLcyQCfsUxRuznXeiEtKHNI)/1000
   YAkbljwTLcyQCfsUxRuznXeiEtKHNv =YAkbljwTLcyQCfsUxRuznXeiEtKHva(datetime.datetime.fromtimestamp(YAkbljwTLcyQCfsUxRuznXeiEtKHNm,datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul')).strftime('%Y%m%d'))
   if YAkbljwTLcyQCfsUxRuznXeiEtKHNP<=YAkbljwTLcyQCfsUxRuznXeiEtKHNv:YAkbljwTLcyQCfsUxRuznXeiEtKHIV=YAkbljwTLcyQCfsUxRuznXeiEtKHvG
  except YAkbljwTLcyQCfsUxRuznXeiEtKHvp as exception:
   YAkbljwTLcyQCfsUxRuznXeiEtKHdI(exception)
   return YAkbljwTLcyQCfsUxRuznXeiEtKHIV
  return YAkbljwTLcyQCfsUxRuznXeiEtKHIV
 def GetBroadURL(YAkbljwTLcyQCfsUxRuznXeiEtKHIN,YAkbljwTLcyQCfsUxRuznXeiEtKHmG,mediatype,YAkbljwTLcyQCfsUxRuznXeiEtKHNF):
  YAkbljwTLcyQCfsUxRuznXeiEtKHNd=''
  try:
   if mediatype=='live':
    YAkbljwTLcyQCfsUxRuznXeiEtKHIo=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.API_DOMAIN+'/api/v3/live/'+YAkbljwTLcyQCfsUxRuznXeiEtKHmG
   else:
    YAkbljwTLcyQCfsUxRuznXeiEtKHmG=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.GetReplay_UrlId(YAkbljwTLcyQCfsUxRuznXeiEtKHmG,YAkbljwTLcyQCfsUxRuznXeiEtKHNF)
    if YAkbljwTLcyQCfsUxRuznXeiEtKHmG=='':return YAkbljwTLcyQCfsUxRuznXeiEtKHNd
    YAkbljwTLcyQCfsUxRuznXeiEtKHIo=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.PLAYER_DOMAIN+'/playback/v1/accounts/'+YAkbljwTLcyQCfsUxRuznXeiEtKHvB(YAkbljwTLcyQCfsUxRuznXeiEtKHIN.ST['cookies']['spotv_accountId'])+'/videos/'+YAkbljwTLcyQCfsUxRuznXeiEtKHmG
   YAkbljwTLcyQCfsUxRuznXeiEtKHIq=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.makeDefaultHeaders()
   YAkbljwTLcyQCfsUxRuznXeiEtKHIB=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.callRequestCookies('Get',YAkbljwTLcyQCfsUxRuznXeiEtKHIo,payload=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,params=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,headers=YAkbljwTLcyQCfsUxRuznXeiEtKHIq,cookies=YAkbljwTLcyQCfsUxRuznXeiEtKHvh)
   YAkbljwTLcyQCfsUxRuznXeiEtKHPI=json.loads(YAkbljwTLcyQCfsUxRuznXeiEtKHIB.text)
   YAkbljwTLcyQCfsUxRuznXeiEtKHdI(YAkbljwTLcyQCfsUxRuznXeiEtKHIo)
   if mediatype=='live':
    YAkbljwTLcyQCfsUxRuznXeiEtKHNd=YAkbljwTLcyQCfsUxRuznXeiEtKHPI['hlsUrl2']or YAkbljwTLcyQCfsUxRuznXeiEtKHPI['hlsUrl']
   else:
    YAkbljwTLcyQCfsUxRuznXeiEtKHdI(YAkbljwTLcyQCfsUxRuznXeiEtKHPI)
    YAkbljwTLcyQCfsUxRuznXeiEtKHNd=YAkbljwTLcyQCfsUxRuznXeiEtKHPI['sources'][0]['src']
   YAkbljwTLcyQCfsUxRuznXeiEtKHNd=YAkbljwTLcyQCfsUxRuznXeiEtKHNd.replace('http://','https://')
  except YAkbljwTLcyQCfsUxRuznXeiEtKHvp as exception:
   YAkbljwTLcyQCfsUxRuznXeiEtKHdI(exception)
  return YAkbljwTLcyQCfsUxRuznXeiEtKHNd
 def GetTitleGroupList(YAkbljwTLcyQCfsUxRuznXeiEtKHIN):
  YAkbljwTLcyQCfsUxRuznXeiEtKHPB=[]
  YAkbljwTLcyQCfsUxRuznXeiEtKHIo=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.API_DOMAIN+'/api/v3/home/web'
  YAkbljwTLcyQCfsUxRuznXeiEtKHIB=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.callRequestCookies('Get',YAkbljwTLcyQCfsUxRuznXeiEtKHIo,payload=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,params=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,headers=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,cookies=YAkbljwTLcyQCfsUxRuznXeiEtKHvh)
  YAkbljwTLcyQCfsUxRuznXeiEtKHPd=json.loads(YAkbljwTLcyQCfsUxRuznXeiEtKHIB.text)
  for YAkbljwTLcyQCfsUxRuznXeiEtKHPG in YAkbljwTLcyQCfsUxRuznXeiEtKHPd:
   if YAkbljwTLcyQCfsUxRuznXeiEtKHvB(YAkbljwTLcyQCfsUxRuznXeiEtKHPG['type'])=='3':
    YAkbljwTLcyQCfsUxRuznXeiEtKHNW=''
    for YAkbljwTLcyQCfsUxRuznXeiEtKHNO in YAkbljwTLcyQCfsUxRuznXeiEtKHPG['data']['list']:
     YAkbljwTLcyQCfsUxRuznXeiEtKHNS='[%s] %s vs %s\n<%s>\n\n'%(YAkbljwTLcyQCfsUxRuznXeiEtKHNO['gameDesc']['roundName'],YAkbljwTLcyQCfsUxRuznXeiEtKHNO['gameDesc']['homeNameShort'],YAkbljwTLcyQCfsUxRuznXeiEtKHNO['gameDesc']['awayNameShort'],YAkbljwTLcyQCfsUxRuznXeiEtKHNO['gameDesc']['beginDate'])
     YAkbljwTLcyQCfsUxRuznXeiEtKHNW+=YAkbljwTLcyQCfsUxRuznXeiEtKHNS
    YAkbljwTLcyQCfsUxRuznXeiEtKHPa={'title':YAkbljwTLcyQCfsUxRuznXeiEtKHPG['title'],'logo':YAkbljwTLcyQCfsUxRuznXeiEtKHPG['logo'],'reagueId':YAkbljwTLcyQCfsUxRuznXeiEtKHvB(YAkbljwTLcyQCfsUxRuznXeiEtKHPG['destId']),'subGame':YAkbljwTLcyQCfsUxRuznXeiEtKHNW,}
    YAkbljwTLcyQCfsUxRuznXeiEtKHPB.append(YAkbljwTLcyQCfsUxRuznXeiEtKHPa)
  return YAkbljwTLcyQCfsUxRuznXeiEtKHPB
 def GetPopularGroupList(YAkbljwTLcyQCfsUxRuznXeiEtKHIN):
  YAkbljwTLcyQCfsUxRuznXeiEtKHPB=[]
  YAkbljwTLcyQCfsUxRuznXeiEtKHIo=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.API_DOMAIN+'/api/v3/home/web'
  YAkbljwTLcyQCfsUxRuznXeiEtKHIB=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.callRequestCookies('Get',YAkbljwTLcyQCfsUxRuznXeiEtKHIo,payload=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,params=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,headers=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,cookies=YAkbljwTLcyQCfsUxRuznXeiEtKHvh)
  YAkbljwTLcyQCfsUxRuznXeiEtKHPd=json.loads(YAkbljwTLcyQCfsUxRuznXeiEtKHIB.text)
  for YAkbljwTLcyQCfsUxRuznXeiEtKHPG in YAkbljwTLcyQCfsUxRuznXeiEtKHPd:
   if YAkbljwTLcyQCfsUxRuznXeiEtKHvB(YAkbljwTLcyQCfsUxRuznXeiEtKHPG['type'])=='1' and YAkbljwTLcyQCfsUxRuznXeiEtKHvB(YAkbljwTLcyQCfsUxRuznXeiEtKHPG['destId'])=='4':
    for YAkbljwTLcyQCfsUxRuznXeiEtKHNO in YAkbljwTLcyQCfsUxRuznXeiEtKHPG['data']['list']:
     YAkbljwTLcyQCfsUxRuznXeiEtKHNr =YAkbljwTLcyQCfsUxRuznXeiEtKHNO['title']
     YAkbljwTLcyQCfsUxRuznXeiEtKHNV =YAkbljwTLcyQCfsUxRuznXeiEtKHNO['id']
     YAkbljwTLcyQCfsUxRuznXeiEtKHNg =YAkbljwTLcyQCfsUxRuznXeiEtKHNO['vtype']
     YAkbljwTLcyQCfsUxRuznXeiEtKHNM =YAkbljwTLcyQCfsUxRuznXeiEtKHNO['imgUrl']
     YAkbljwTLcyQCfsUxRuznXeiEtKHNF =YAkbljwTLcyQCfsUxRuznXeiEtKHNO['vtypeId']
     YAkbljwTLcyQCfsUxRuznXeiEtKHPa={'vodTitle':YAkbljwTLcyQCfsUxRuznXeiEtKHNr,'vodId':YAkbljwTLcyQCfsUxRuznXeiEtKHNV,'vodType':YAkbljwTLcyQCfsUxRuznXeiEtKHNg,'thumbnail':YAkbljwTLcyQCfsUxRuznXeiEtKHNM,'vtypeId':YAkbljwTLcyQCfsUxRuznXeiEtKHvB(YAkbljwTLcyQCfsUxRuznXeiEtKHNF),'duration':YAkbljwTLcyQCfsUxRuznXeiEtKHva(YAkbljwTLcyQCfsUxRuznXeiEtKHNO['duration']/1000),}
     YAkbljwTLcyQCfsUxRuznXeiEtKHPB.append(YAkbljwTLcyQCfsUxRuznXeiEtKHPa)
  return YAkbljwTLcyQCfsUxRuznXeiEtKHPB
 def Get_NowVod_GroupList(YAkbljwTLcyQCfsUxRuznXeiEtKHIN,page_int):
  YAkbljwTLcyQCfsUxRuznXeiEtKHPB=[]
  YAkbljwTLcyQCfsUxRuznXeiEtKHNq=YAkbljwTLcyQCfsUxRuznXeiEtKHvo
  YAkbljwTLcyQCfsUxRuznXeiEtKHIo=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.API_DOMAIN+'/api/v3/theme/14/list'
  YAkbljwTLcyQCfsUxRuznXeiEtKHND={'pageItem':'10','pageNo':YAkbljwTLcyQCfsUxRuznXeiEtKHvB(page_int)}
  YAkbljwTLcyQCfsUxRuznXeiEtKHIB=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.callRequestCookies('Get',YAkbljwTLcyQCfsUxRuznXeiEtKHIo,payload=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,params=YAkbljwTLcyQCfsUxRuznXeiEtKHND,headers=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,cookies=YAkbljwTLcyQCfsUxRuznXeiEtKHvh)
  YAkbljwTLcyQCfsUxRuznXeiEtKHPd=json.loads(YAkbljwTLcyQCfsUxRuznXeiEtKHIB.text)
  for YAkbljwTLcyQCfsUxRuznXeiEtKHPG in YAkbljwTLcyQCfsUxRuznXeiEtKHPd['list']:
   YAkbljwTLcyQCfsUxRuznXeiEtKHNr =YAkbljwTLcyQCfsUxRuznXeiEtKHPG['title']
   YAkbljwTLcyQCfsUxRuznXeiEtKHNV =YAkbljwTLcyQCfsUxRuznXeiEtKHPG['id']
   YAkbljwTLcyQCfsUxRuznXeiEtKHNg =YAkbljwTLcyQCfsUxRuznXeiEtKHPG['vtype']
   YAkbljwTLcyQCfsUxRuznXeiEtKHNM =YAkbljwTLcyQCfsUxRuznXeiEtKHPG['imgUrl']
   YAkbljwTLcyQCfsUxRuznXeiEtKHNF =YAkbljwTLcyQCfsUxRuznXeiEtKHPG['vtypeId']
   YAkbljwTLcyQCfsUxRuznXeiEtKHPa={'vodTitle':YAkbljwTLcyQCfsUxRuznXeiEtKHNr,'vodId':YAkbljwTLcyQCfsUxRuznXeiEtKHNV,'vodType':YAkbljwTLcyQCfsUxRuznXeiEtKHNg,'thumbnail':YAkbljwTLcyQCfsUxRuznXeiEtKHNM,'vtypeId':YAkbljwTLcyQCfsUxRuznXeiEtKHvB(YAkbljwTLcyQCfsUxRuznXeiEtKHNF),'duration':YAkbljwTLcyQCfsUxRuznXeiEtKHva(YAkbljwTLcyQCfsUxRuznXeiEtKHPG['duration']/1000),}
   YAkbljwTLcyQCfsUxRuznXeiEtKHPB.append(YAkbljwTLcyQCfsUxRuznXeiEtKHPa)
   if YAkbljwTLcyQCfsUxRuznXeiEtKHPd['count']>page_int*YAkbljwTLcyQCfsUxRuznXeiEtKHIN.GAMELIST_LIMIT:YAkbljwTLcyQCfsUxRuznXeiEtKHNq=YAkbljwTLcyQCfsUxRuznXeiEtKHvG
  return YAkbljwTLcyQCfsUxRuznXeiEtKHPB,YAkbljwTLcyQCfsUxRuznXeiEtKHNq
 def GetSeasonList(YAkbljwTLcyQCfsUxRuznXeiEtKHIN,leagueId):
  YAkbljwTLcyQCfsUxRuznXeiEtKHPB=[]
  YAkbljwTLcyQCfsUxRuznXeiEtKHNh=YAkbljwTLcyQCfsUxRuznXeiEtKHNo=''
  try:
   YAkbljwTLcyQCfsUxRuznXeiEtKHIo=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.API_DOMAIN+'/api/v3/game/league/'+leagueId
   YAkbljwTLcyQCfsUxRuznXeiEtKHIB=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.callRequestCookies('Get',YAkbljwTLcyQCfsUxRuznXeiEtKHIo,payload=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,params=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,headers=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,cookies=YAkbljwTLcyQCfsUxRuznXeiEtKHvh)
   YAkbljwTLcyQCfsUxRuznXeiEtKHPd=json.loads(YAkbljwTLcyQCfsUxRuznXeiEtKHIB.text)
   YAkbljwTLcyQCfsUxRuznXeiEtKHNh=YAkbljwTLcyQCfsUxRuznXeiEtKHPd['name']
   YAkbljwTLcyQCfsUxRuznXeiEtKHNo=YAkbljwTLcyQCfsUxRuznXeiEtKHvB(YAkbljwTLcyQCfsUxRuznXeiEtKHPd['gameTypeId'])
  except YAkbljwTLcyQCfsUxRuznXeiEtKHvp as exception:
   YAkbljwTLcyQCfsUxRuznXeiEtKHdI(exception)
   return YAkbljwTLcyQCfsUxRuznXeiEtKHPB
  if YAkbljwTLcyQCfsUxRuznXeiEtKHNo in['2','5','6','8']:
   try:
    YAkbljwTLcyQCfsUxRuznXeiEtKHIo=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.API_DOMAIN+'/api/v3/year/'+leagueId
    YAkbljwTLcyQCfsUxRuznXeiEtKHIB=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.callRequestCookies('Get',YAkbljwTLcyQCfsUxRuznXeiEtKHIo,payload=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,params=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,headers=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,cookies=YAkbljwTLcyQCfsUxRuznXeiEtKHvh)
    YAkbljwTLcyQCfsUxRuznXeiEtKHPd=json.loads(YAkbljwTLcyQCfsUxRuznXeiEtKHIB.text)
    for YAkbljwTLcyQCfsUxRuznXeiEtKHPG in YAkbljwTLcyQCfsUxRuznXeiEtKHPd:
     YAkbljwTLcyQCfsUxRuznXeiEtKHPa={'reagueName':YAkbljwTLcyQCfsUxRuznXeiEtKHNh,'gameTypeId':YAkbljwTLcyQCfsUxRuznXeiEtKHNo,'seasonName':YAkbljwTLcyQCfsUxRuznXeiEtKHvB(YAkbljwTLcyQCfsUxRuznXeiEtKHPG),'seasonId':YAkbljwTLcyQCfsUxRuznXeiEtKHvB(YAkbljwTLcyQCfsUxRuznXeiEtKHPG)}
     YAkbljwTLcyQCfsUxRuznXeiEtKHPB.append(YAkbljwTLcyQCfsUxRuznXeiEtKHPa)
   except YAkbljwTLcyQCfsUxRuznXeiEtKHvp as exception:
    YAkbljwTLcyQCfsUxRuznXeiEtKHdI(exception)
    return[]
  else:
   try:
    YAkbljwTLcyQCfsUxRuznXeiEtKHIo=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.API_DOMAIN+'/api/v3/season/'+leagueId
    YAkbljwTLcyQCfsUxRuznXeiEtKHIB=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.callRequestCookies('Get',YAkbljwTLcyQCfsUxRuznXeiEtKHIo,payload=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,params=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,headers=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,cookies=YAkbljwTLcyQCfsUxRuznXeiEtKHvh)
    YAkbljwTLcyQCfsUxRuznXeiEtKHPd=json.loads(YAkbljwTLcyQCfsUxRuznXeiEtKHIB.text)
    for YAkbljwTLcyQCfsUxRuznXeiEtKHPG in YAkbljwTLcyQCfsUxRuznXeiEtKHPd:
     YAkbljwTLcyQCfsUxRuznXeiEtKHPa={'reagueName':YAkbljwTLcyQCfsUxRuznXeiEtKHNh,'gameTypeId':YAkbljwTLcyQCfsUxRuznXeiEtKHNo,'seasonName':YAkbljwTLcyQCfsUxRuznXeiEtKHPG['name'],'seasonId':YAkbljwTLcyQCfsUxRuznXeiEtKHvB(YAkbljwTLcyQCfsUxRuznXeiEtKHPG['id'])}
     YAkbljwTLcyQCfsUxRuznXeiEtKHPB.append(YAkbljwTLcyQCfsUxRuznXeiEtKHPa)
   except YAkbljwTLcyQCfsUxRuznXeiEtKHvp as exception:
    YAkbljwTLcyQCfsUxRuznXeiEtKHdI(exception)
    return[]
  return YAkbljwTLcyQCfsUxRuznXeiEtKHPB
 def GetGameList(YAkbljwTLcyQCfsUxRuznXeiEtKHIN,YAkbljwTLcyQCfsUxRuznXeiEtKHNo,leagueId,seasonId,page_int,hidescore=YAkbljwTLcyQCfsUxRuznXeiEtKHvG):
  YAkbljwTLcyQCfsUxRuznXeiEtKHPB=[]
  YAkbljwTLcyQCfsUxRuznXeiEtKHNq=YAkbljwTLcyQCfsUxRuznXeiEtKHvo
  try:
   YAkbljwTLcyQCfsUxRuznXeiEtKHIo=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.API_DOMAIN+'/api/v3/vod/league/detail'
   YAkbljwTLcyQCfsUxRuznXeiEtKHND={'gameType':YAkbljwTLcyQCfsUxRuznXeiEtKHNo,'leagueId':leagueId,'seasonId':seasonId if YAkbljwTLcyQCfsUxRuznXeiEtKHNo not in['2','5','6','8']else '','teamId':'','roundId':'','year':'' if YAkbljwTLcyQCfsUxRuznXeiEtKHNo not in['2','5','6','8']else seasonId,'pageNo':YAkbljwTLcyQCfsUxRuznXeiEtKHvB(page_int)}
   YAkbljwTLcyQCfsUxRuznXeiEtKHIB=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.callRequestCookies('Get',YAkbljwTLcyQCfsUxRuznXeiEtKHIo,payload=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,params=YAkbljwTLcyQCfsUxRuznXeiEtKHND,headers=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,cookies=YAkbljwTLcyQCfsUxRuznXeiEtKHvh)
   YAkbljwTLcyQCfsUxRuznXeiEtKHPd=json.loads(YAkbljwTLcyQCfsUxRuznXeiEtKHIB.text)
   YAkbljwTLcyQCfsUxRuznXeiEtKHmB=YAkbljwTLcyQCfsUxRuznXeiEtKHPd['list']
   for YAkbljwTLcyQCfsUxRuznXeiEtKHNB in YAkbljwTLcyQCfsUxRuznXeiEtKHmB:
    for YAkbljwTLcyQCfsUxRuznXeiEtKHPG in YAkbljwTLcyQCfsUxRuznXeiEtKHNB['list']:
     if YAkbljwTLcyQCfsUxRuznXeiEtKHPG['gameDesc']['title']==YAkbljwTLcyQCfsUxRuznXeiEtKHvh or YAkbljwTLcyQCfsUxRuznXeiEtKHPG['gameDesc']['title']=='':
      YAkbljwTLcyQCfsUxRuznXeiEtKHmJ ='%s vs %s'%(YAkbljwTLcyQCfsUxRuznXeiEtKHPG['gameDesc']['homeNameShort'],YAkbljwTLcyQCfsUxRuznXeiEtKHPG['gameDesc']['awayNameShort'])
     else:
      YAkbljwTLcyQCfsUxRuznXeiEtKHmJ =YAkbljwTLcyQCfsUxRuznXeiEtKHPG['gameDesc']['title']
     YAkbljwTLcyQCfsUxRuznXeiEtKHNJ =YAkbljwTLcyQCfsUxRuznXeiEtKHPG['gameDesc']['beginDate']
     YAkbljwTLcyQCfsUxRuznXeiEtKHNG =YAkbljwTLcyQCfsUxRuznXeiEtKHPG['gameDesc']['id']
     YAkbljwTLcyQCfsUxRuznXeiEtKHNa =YAkbljwTLcyQCfsUxRuznXeiEtKHPG['gameDesc']['leagueNameFull']
     YAkbljwTLcyQCfsUxRuznXeiEtKHNp =YAkbljwTLcyQCfsUxRuznXeiEtKHPG['gameDesc']['seasonName']
     YAkbljwTLcyQCfsUxRuznXeiEtKHvI =YAkbljwTLcyQCfsUxRuznXeiEtKHPG['gameDesc']['roundName']
     YAkbljwTLcyQCfsUxRuznXeiEtKHvP =YAkbljwTLcyQCfsUxRuznXeiEtKHPG['gameDesc']['homeName']
     YAkbljwTLcyQCfsUxRuznXeiEtKHvm =YAkbljwTLcyQCfsUxRuznXeiEtKHPG['gameDesc']['awayName']
     YAkbljwTLcyQCfsUxRuznXeiEtKHvN =YAkbljwTLcyQCfsUxRuznXeiEtKHPG['gameDesc']['homeScore']
     YAkbljwTLcyQCfsUxRuznXeiEtKHvd =YAkbljwTLcyQCfsUxRuznXeiEtKHPG['gameDesc']['awayScore']
     if hidescore==YAkbljwTLcyQCfsUxRuznXeiEtKHvG:
      YAkbljwTLcyQCfsUxRuznXeiEtKHvW ='%s\n - %s (%s)\n - %s\n\nhome : %s\n\naway : %s'%(YAkbljwTLcyQCfsUxRuznXeiEtKHNa,YAkbljwTLcyQCfsUxRuznXeiEtKHNp,YAkbljwTLcyQCfsUxRuznXeiEtKHvI,YAkbljwTLcyQCfsUxRuznXeiEtKHNJ,YAkbljwTLcyQCfsUxRuznXeiEtKHvP,YAkbljwTLcyQCfsUxRuznXeiEtKHvm)
     else:
      YAkbljwTLcyQCfsUxRuznXeiEtKHvW ='%s\n - %s (%s)\n - %s\n\nhome : %s (Score %s)\n\naway : %s (Score %s)'%(YAkbljwTLcyQCfsUxRuznXeiEtKHNa,YAkbljwTLcyQCfsUxRuznXeiEtKHNp,YAkbljwTLcyQCfsUxRuznXeiEtKHvI,YAkbljwTLcyQCfsUxRuznXeiEtKHNJ,YAkbljwTLcyQCfsUxRuznXeiEtKHvP,YAkbljwTLcyQCfsUxRuznXeiEtKHvN,YAkbljwTLcyQCfsUxRuznXeiEtKHvm,YAkbljwTLcyQCfsUxRuznXeiEtKHvd)
     YAkbljwTLcyQCfsUxRuznXeiEtKHvO=YAkbljwTLcyQCfsUxRuznXeiEtKHvW
     YAkbljwTLcyQCfsUxRuznXeiEtKHvS =YAkbljwTLcyQCfsUxRuznXeiEtKHPG['replayVod']['count']
     YAkbljwTLcyQCfsUxRuznXeiEtKHvr=YAkbljwTLcyQCfsUxRuznXeiEtKHPG['highlightVod']['count']
     YAkbljwTLcyQCfsUxRuznXeiEtKHvV =YAkbljwTLcyQCfsUxRuznXeiEtKHPG['vods']['count']
     YAkbljwTLcyQCfsUxRuznXeiEtKHNM='' 
     YAkbljwTLcyQCfsUxRuznXeiEtKHvg=YAkbljwTLcyQCfsUxRuznXeiEtKHvS+YAkbljwTLcyQCfsUxRuznXeiEtKHvr+YAkbljwTLcyQCfsUxRuznXeiEtKHvV
     if YAkbljwTLcyQCfsUxRuznXeiEtKHvg==0:
      if YAkbljwTLcyQCfsUxRuznXeiEtKHNo=='2':
       YAkbljwTLcyQCfsUxRuznXeiEtKHmJ='----- %s -----'%(YAkbljwTLcyQCfsUxRuznXeiEtKHNp)
       YAkbljwTLcyQCfsUxRuznXeiEtKHNJ=''
      else:
       YAkbljwTLcyQCfsUxRuznXeiEtKHmJ+=' - 관련영상 없음'
       YAkbljwTLcyQCfsUxRuznXeiEtKHvO+='\n\n ** 관련영상 없음 **'
     else:
      if YAkbljwTLcyQCfsUxRuznXeiEtKHvS!=0:
       YAkbljwTLcyQCfsUxRuznXeiEtKHNM =YAkbljwTLcyQCfsUxRuznXeiEtKHPG['replayVod']['list'][0]['imgUrl']
      elif YAkbljwTLcyQCfsUxRuznXeiEtKHvr!=0:
       YAkbljwTLcyQCfsUxRuznXeiEtKHNM =YAkbljwTLcyQCfsUxRuznXeiEtKHPG['highlightVod']['list'][0]['imgUrl']
      else:
       YAkbljwTLcyQCfsUxRuznXeiEtKHNM =YAkbljwTLcyQCfsUxRuznXeiEtKHPG['vods']['list'][0]['imgUrl']
     YAkbljwTLcyQCfsUxRuznXeiEtKHPa={'gameTitle':YAkbljwTLcyQCfsUxRuznXeiEtKHmJ,'gameId':YAkbljwTLcyQCfsUxRuznXeiEtKHNG,'beginDate':YAkbljwTLcyQCfsUxRuznXeiEtKHNJ[:11],'thumbnail':YAkbljwTLcyQCfsUxRuznXeiEtKHNM,'info_plot':YAkbljwTLcyQCfsUxRuznXeiEtKHvO,'leaguenm':YAkbljwTLcyQCfsUxRuznXeiEtKHNa,'seasonnm':YAkbljwTLcyQCfsUxRuznXeiEtKHNp,'roundnm':YAkbljwTLcyQCfsUxRuznXeiEtKHvI,'totVodCnt':YAkbljwTLcyQCfsUxRuznXeiEtKHvg}
     YAkbljwTLcyQCfsUxRuznXeiEtKHPB.append(YAkbljwTLcyQCfsUxRuznXeiEtKHPa)
  except YAkbljwTLcyQCfsUxRuznXeiEtKHvp as exception:
   YAkbljwTLcyQCfsUxRuznXeiEtKHdI(exception)
  if YAkbljwTLcyQCfsUxRuznXeiEtKHPd['count']>page_int*YAkbljwTLcyQCfsUxRuznXeiEtKHIN.GAMELIST_LIMIT:YAkbljwTLcyQCfsUxRuznXeiEtKHNq=YAkbljwTLcyQCfsUxRuznXeiEtKHvG
  return YAkbljwTLcyQCfsUxRuznXeiEtKHPB,YAkbljwTLcyQCfsUxRuznXeiEtKHNq
 def GetGameVodList(YAkbljwTLcyQCfsUxRuznXeiEtKHIN,YAkbljwTLcyQCfsUxRuznXeiEtKHNG,vodCount=1000):
  YAkbljwTLcyQCfsUxRuznXeiEtKHPB=[]
  YAkbljwTLcyQCfsUxRuznXeiEtKHvM=''
  try:
   YAkbljwTLcyQCfsUxRuznXeiEtKHIo=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.API_DOMAIN+'/api/v3/vod/game'
   YAkbljwTLcyQCfsUxRuznXeiEtKHND={'gameId':YAkbljwTLcyQCfsUxRuznXeiEtKHNG,'pageItem':YAkbljwTLcyQCfsUxRuznXeiEtKHvB(vodCount)}
   YAkbljwTLcyQCfsUxRuznXeiEtKHIB=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.callRequestCookies('Get',YAkbljwTLcyQCfsUxRuznXeiEtKHIo,payload=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,params=YAkbljwTLcyQCfsUxRuznXeiEtKHND,headers=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,cookies=YAkbljwTLcyQCfsUxRuznXeiEtKHvh)
   YAkbljwTLcyQCfsUxRuznXeiEtKHPd=json.loads(YAkbljwTLcyQCfsUxRuznXeiEtKHIB.text)
   YAkbljwTLcyQCfsUxRuznXeiEtKHNB=YAkbljwTLcyQCfsUxRuznXeiEtKHPd['list']
   for YAkbljwTLcyQCfsUxRuznXeiEtKHPG in YAkbljwTLcyQCfsUxRuznXeiEtKHNB:
    YAkbljwTLcyQCfsUxRuznXeiEtKHNr =YAkbljwTLcyQCfsUxRuznXeiEtKHPG['title']
    YAkbljwTLcyQCfsUxRuznXeiEtKHNV =YAkbljwTLcyQCfsUxRuznXeiEtKHPG['id']
    YAkbljwTLcyQCfsUxRuznXeiEtKHNg =YAkbljwTLcyQCfsUxRuznXeiEtKHPG['vtype']
    YAkbljwTLcyQCfsUxRuznXeiEtKHNM =YAkbljwTLcyQCfsUxRuznXeiEtKHPG['imgUrl']
    YAkbljwTLcyQCfsUxRuznXeiEtKHNF =YAkbljwTLcyQCfsUxRuznXeiEtKHPG['vtypeId']
    YAkbljwTLcyQCfsUxRuznXeiEtKHvF =YAkbljwTLcyQCfsUxRuznXeiEtKHPG['isFree']
    YAkbljwTLcyQCfsUxRuznXeiEtKHPa={'vodTitle':YAkbljwTLcyQCfsUxRuznXeiEtKHNr,'vodId':YAkbljwTLcyQCfsUxRuznXeiEtKHNV,'vodType':YAkbljwTLcyQCfsUxRuznXeiEtKHNg,'thumbnail':YAkbljwTLcyQCfsUxRuznXeiEtKHNM,'vtypeId':YAkbljwTLcyQCfsUxRuznXeiEtKHvB(YAkbljwTLcyQCfsUxRuznXeiEtKHNF),'duration':YAkbljwTLcyQCfsUxRuznXeiEtKHva(YAkbljwTLcyQCfsUxRuznXeiEtKHPG['duration']/1000),'isFree':YAkbljwTLcyQCfsUxRuznXeiEtKHvF}
    YAkbljwTLcyQCfsUxRuznXeiEtKHPB.append(YAkbljwTLcyQCfsUxRuznXeiEtKHPa)
  except YAkbljwTLcyQCfsUxRuznXeiEtKHvp as exception:
   YAkbljwTLcyQCfsUxRuznXeiEtKHdI(exception)
  return YAkbljwTLcyQCfsUxRuznXeiEtKHPB
 def GetReplay_UrlId(YAkbljwTLcyQCfsUxRuznXeiEtKHIN,YAkbljwTLcyQCfsUxRuznXeiEtKHvM,YAkbljwTLcyQCfsUxRuznXeiEtKHNF):
  YAkbljwTLcyQCfsUxRuznXeiEtKHvq=''
  try:
   YAkbljwTLcyQCfsUxRuznXeiEtKHIo=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.API_DOMAIN+'/api/v3/vod/'+YAkbljwTLcyQCfsUxRuznXeiEtKHvM
   YAkbljwTLcyQCfsUxRuznXeiEtKHIB=YAkbljwTLcyQCfsUxRuznXeiEtKHIN.callRequestCookies('Get',YAkbljwTLcyQCfsUxRuznXeiEtKHIo,payload=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,params=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,headers=YAkbljwTLcyQCfsUxRuznXeiEtKHvh,cookies=YAkbljwTLcyQCfsUxRuznXeiEtKHvh)
   YAkbljwTLcyQCfsUxRuznXeiEtKHPd=json.loads(YAkbljwTLcyQCfsUxRuznXeiEtKHIB.text)
   YAkbljwTLcyQCfsUxRuznXeiEtKHvq=YAkbljwTLcyQCfsUxRuznXeiEtKHPd['videoId']
  except YAkbljwTLcyQCfsUxRuznXeiEtKHvp as exception:
   YAkbljwTLcyQCfsUxRuznXeiEtKHdI(exception)
  return YAkbljwTLcyQCfsUxRuznXeiEtKHvq
# Created by pyminifier (https://github.com/liftoff/pyminifier)
