__author__="NightRain"
BWXsHSeaxrFTQJitARwEPUONbDKlMk=object
BWXsHSeaxrFTQJitARwEPUONbDKlMI=None
BWXsHSeaxrFTQJitARwEPUONbDKlMy=False
BWXsHSeaxrFTQJitARwEPUONbDKlMo=True
BWXsHSeaxrFTQJitARwEPUONbDKlMg=getattr
BWXsHSeaxrFTQJitARwEPUONbDKlMc=type
BWXsHSeaxrFTQJitARwEPUONbDKlMq=int
BWXsHSeaxrFTQJitARwEPUONbDKlMp=list
BWXsHSeaxrFTQJitARwEPUONbDKlMY=len
BWXsHSeaxrFTQJitARwEPUONbDKlMh=str
BWXsHSeaxrFTQJitARwEPUONbDKlMn=id
BWXsHSeaxrFTQJitARwEPUONbDKlMC=open
BWXsHSeaxrFTQJitARwEPUONbDKlMz=dict
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
BWXsHSeaxrFTQJitARwEPUONbDKlvf=[{'title':'TV 채널 (유료사용자만 지원)','mode':'LIVE_GROUP','icon':'live.png'},{'title':'Live중계 (경기중에만 재생)','mode':'ELIVE_GROUP','icon':'live.png'},{'title':'-----------------','mode':'XXX'},{'title':'오늘의 추천 VOD','mode':'NOW_GROUP'},{'title':'인기영상 5','mode':'POP_GROUP'},{'title':'-----------------','mode':'XXX'},{'title':'VOD (리그, 경기별)','mode':'VOD_GROUP'},{'title':'Watched (시청목록)','mode':'WATCH','icon':'history.png'},]
BWXsHSeaxrFTQJitARwEPUONbDKlvm={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
BWXsHSeaxrFTQJitARwEPUONbDKlvG=xbmcvfs.translatePath(os.path.join(__profile__,'spotv_cookies.json'))
from spotvCore import*
class BWXsHSeaxrFTQJitARwEPUONbDKlvj(BWXsHSeaxrFTQJitARwEPUONbDKlMk):
 def __init__(BWXsHSeaxrFTQJitARwEPUONbDKlvM,BWXsHSeaxrFTQJitARwEPUONbDKlvu,BWXsHSeaxrFTQJitARwEPUONbDKlvd,BWXsHSeaxrFTQJitARwEPUONbDKlvL):
  BWXsHSeaxrFTQJitARwEPUONbDKlvM._addon_url =BWXsHSeaxrFTQJitARwEPUONbDKlvu
  BWXsHSeaxrFTQJitARwEPUONbDKlvM._addon_handle=BWXsHSeaxrFTQJitARwEPUONbDKlvd
  BWXsHSeaxrFTQJitARwEPUONbDKlvM.main_params =BWXsHSeaxrFTQJitARwEPUONbDKlvL
  BWXsHSeaxrFTQJitARwEPUONbDKlvM.SpotvObj =usUPjwMxhBacOvzWdpfQTRrmoyGniY() 
 def addon_noti(BWXsHSeaxrFTQJitARwEPUONbDKlvM,sting):
  try:
   BWXsHSeaxrFTQJitARwEPUONbDKlvI=xbmcgui.Dialog()
   BWXsHSeaxrFTQJitARwEPUONbDKlvI.notification(__addonname__,sting)
  except:
   BWXsHSeaxrFTQJitARwEPUONbDKlMI
 def addon_log(BWXsHSeaxrFTQJitARwEPUONbDKlvM,string):
  try:
   BWXsHSeaxrFTQJitARwEPUONbDKlvy=string.encode('utf-8','ignore')
  except:
   BWXsHSeaxrFTQJitARwEPUONbDKlvy='addonException: addon_log'
  BWXsHSeaxrFTQJitARwEPUONbDKlvo=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,BWXsHSeaxrFTQJitARwEPUONbDKlvy),level=BWXsHSeaxrFTQJitARwEPUONbDKlvo)
 def get_keyboard_input(BWXsHSeaxrFTQJitARwEPUONbDKlvM,BWXsHSeaxrFTQJitARwEPUONbDKlvh):
  BWXsHSeaxrFTQJitARwEPUONbDKlvg=BWXsHSeaxrFTQJitARwEPUONbDKlMI
  kb=xbmc.Keyboard()
  kb.setHeading(BWXsHSeaxrFTQJitARwEPUONbDKlvh)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   BWXsHSeaxrFTQJitARwEPUONbDKlvg=kb.getText()
  return BWXsHSeaxrFTQJitARwEPUONbDKlvg
 def get_settings_account(BWXsHSeaxrFTQJitARwEPUONbDKlvM):
  BWXsHSeaxrFTQJitARwEPUONbDKlvc =__addon__.getSetting('id')
  BWXsHSeaxrFTQJitARwEPUONbDKlvq =__addon__.getSetting('pw')
  return(BWXsHSeaxrFTQJitARwEPUONbDKlvc,BWXsHSeaxrFTQJitARwEPUONbDKlvq)
 def get_settings_hidescoreyn(BWXsHSeaxrFTQJitARwEPUONbDKlvM):
  BWXsHSeaxrFTQJitARwEPUONbDKlvp =__addon__.getSetting('hidescore')
  if BWXsHSeaxrFTQJitARwEPUONbDKlvp=='false':
   return BWXsHSeaxrFTQJitARwEPUONbDKlMy
  else:
   return BWXsHSeaxrFTQJitARwEPUONbDKlMo
 def add_dir(BWXsHSeaxrFTQJitARwEPUONbDKlvM,label,sublabel='',img='',infoLabels=BWXsHSeaxrFTQJitARwEPUONbDKlMI,isFolder=BWXsHSeaxrFTQJitARwEPUONbDKlMo,params='',isLink=BWXsHSeaxrFTQJitARwEPUONbDKlMy,ContextMenu=BWXsHSeaxrFTQJitARwEPUONbDKlMI):
  BWXsHSeaxrFTQJitARwEPUONbDKlvY='%s?%s'%(BWXsHSeaxrFTQJitARwEPUONbDKlvM._addon_url,urllib.parse.urlencode(params))
  if sublabel:BWXsHSeaxrFTQJitARwEPUONbDKlvh='%s < %s >'%(label,sublabel)
  else: BWXsHSeaxrFTQJitARwEPUONbDKlvh=label
  if not img:img='DefaultFolder.png'
  BWXsHSeaxrFTQJitARwEPUONbDKlvn=xbmcgui.ListItem(BWXsHSeaxrFTQJitARwEPUONbDKlvh)
  BWXsHSeaxrFTQJitARwEPUONbDKlvn.setArt({'thumb':img,'icon':img,'poster':img})
  if BWXsHSeaxrFTQJitARwEPUONbDKlvM.SpotvObj.KodiVersion>=20:
   if infoLabels:BWXsHSeaxrFTQJitARwEPUONbDKlvM.Set_InfoTag(BWXsHSeaxrFTQJitARwEPUONbDKlvn.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:BWXsHSeaxrFTQJitARwEPUONbDKlvn.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   BWXsHSeaxrFTQJitARwEPUONbDKlvn.setProperty('IsPlayable','true')
  if ContextMenu:BWXsHSeaxrFTQJitARwEPUONbDKlvn.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(BWXsHSeaxrFTQJitARwEPUONbDKlvM._addon_handle,BWXsHSeaxrFTQJitARwEPUONbDKlvY,BWXsHSeaxrFTQJitARwEPUONbDKlvn,isFolder)
 def Set_InfoTag(BWXsHSeaxrFTQJitARwEPUONbDKlvM,video_InfoTag:xbmc.InfoTagVideo,BWXsHSeaxrFTQJitARwEPUONbDKljL):
  for BWXsHSeaxrFTQJitARwEPUONbDKlvC,value in BWXsHSeaxrFTQJitARwEPUONbDKljL.items():
   if BWXsHSeaxrFTQJitARwEPUONbDKlvm[BWXsHSeaxrFTQJitARwEPUONbDKlvC]['type']=='string':
    BWXsHSeaxrFTQJitARwEPUONbDKlMg(video_InfoTag,BWXsHSeaxrFTQJitARwEPUONbDKlvm[BWXsHSeaxrFTQJitARwEPUONbDKlvC]['func'])(value)
   elif BWXsHSeaxrFTQJitARwEPUONbDKlvm[BWXsHSeaxrFTQJitARwEPUONbDKlvC]['type']=='int':
    if BWXsHSeaxrFTQJitARwEPUONbDKlMc(value)==BWXsHSeaxrFTQJitARwEPUONbDKlMq:
     BWXsHSeaxrFTQJitARwEPUONbDKlvz=BWXsHSeaxrFTQJitARwEPUONbDKlMq(value)
    else:
     BWXsHSeaxrFTQJitARwEPUONbDKlvz=0
    BWXsHSeaxrFTQJitARwEPUONbDKlMg(video_InfoTag,BWXsHSeaxrFTQJitARwEPUONbDKlvm[BWXsHSeaxrFTQJitARwEPUONbDKlvC]['func'])(BWXsHSeaxrFTQJitARwEPUONbDKlvz)
   elif BWXsHSeaxrFTQJitARwEPUONbDKlvm[BWXsHSeaxrFTQJitARwEPUONbDKlvC]['type']=='actor':
    if value!=[]:
     BWXsHSeaxrFTQJitARwEPUONbDKlMg(video_InfoTag,BWXsHSeaxrFTQJitARwEPUONbDKlvm[BWXsHSeaxrFTQJitARwEPUONbDKlvC]['func'])([xbmc.Actor(name)for name in value])
   elif BWXsHSeaxrFTQJitARwEPUONbDKlvm[BWXsHSeaxrFTQJitARwEPUONbDKlvC]['type']=='list':
    if BWXsHSeaxrFTQJitARwEPUONbDKlMc(value)==BWXsHSeaxrFTQJitARwEPUONbDKlMp:
     BWXsHSeaxrFTQJitARwEPUONbDKlMg(video_InfoTag,BWXsHSeaxrFTQJitARwEPUONbDKlvm[BWXsHSeaxrFTQJitARwEPUONbDKlvC]['func'])(value)
    else:
     BWXsHSeaxrFTQJitARwEPUONbDKlMg(video_InfoTag,BWXsHSeaxrFTQJitARwEPUONbDKlvm[BWXsHSeaxrFTQJitARwEPUONbDKlvC]['func'])([value])
 def get_selQuality(BWXsHSeaxrFTQJitARwEPUONbDKlvM,etype):
  try:
   BWXsHSeaxrFTQJitARwEPUONbDKlvV='selected_quality'
   BWXsHSeaxrFTQJitARwEPUONbDKljv=[1080,720,540]
   BWXsHSeaxrFTQJitARwEPUONbDKljf=BWXsHSeaxrFTQJitARwEPUONbDKlMq(__addon__.getSetting(BWXsHSeaxrFTQJitARwEPUONbDKlvV))
   return BWXsHSeaxrFTQJitARwEPUONbDKljv[BWXsHSeaxrFTQJitARwEPUONbDKljf]
  except:
   BWXsHSeaxrFTQJitARwEPUONbDKlMI
  return 1080 
 def dp_Main_List(BWXsHSeaxrFTQJitARwEPUONbDKlvM):
  for BWXsHSeaxrFTQJitARwEPUONbDKljm in BWXsHSeaxrFTQJitARwEPUONbDKlvf:
   BWXsHSeaxrFTQJitARwEPUONbDKlvh=BWXsHSeaxrFTQJitARwEPUONbDKljm.get('title')
   BWXsHSeaxrFTQJitARwEPUONbDKljG=''
   BWXsHSeaxrFTQJitARwEPUONbDKljM={'mode':BWXsHSeaxrFTQJitARwEPUONbDKljm.get('mode'),'page':'1'}
   if BWXsHSeaxrFTQJitARwEPUONbDKljm.get('mode')=='XXX':
    BWXsHSeaxrFTQJitARwEPUONbDKlju=BWXsHSeaxrFTQJitARwEPUONbDKlMy
    BWXsHSeaxrFTQJitARwEPUONbDKljd =BWXsHSeaxrFTQJitARwEPUONbDKlMo
   else:
    BWXsHSeaxrFTQJitARwEPUONbDKlju=BWXsHSeaxrFTQJitARwEPUONbDKlMo
    BWXsHSeaxrFTQJitARwEPUONbDKljd =BWXsHSeaxrFTQJitARwEPUONbDKlMy
   BWXsHSeaxrFTQJitARwEPUONbDKljL={'title':BWXsHSeaxrFTQJitARwEPUONbDKlvh,'plot':BWXsHSeaxrFTQJitARwEPUONbDKlvh}
   if BWXsHSeaxrFTQJitARwEPUONbDKljm.get('mode')=='XXX':BWXsHSeaxrFTQJitARwEPUONbDKljL=BWXsHSeaxrFTQJitARwEPUONbDKlMI
   if 'icon' in BWXsHSeaxrFTQJitARwEPUONbDKljm:BWXsHSeaxrFTQJitARwEPUONbDKljG=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',BWXsHSeaxrFTQJitARwEPUONbDKljm.get('icon')) 
   BWXsHSeaxrFTQJitARwEPUONbDKlvM.add_dir(BWXsHSeaxrFTQJitARwEPUONbDKlvh,sublabel='',img=BWXsHSeaxrFTQJitARwEPUONbDKljG,infoLabels=BWXsHSeaxrFTQJitARwEPUONbDKljL,isFolder=BWXsHSeaxrFTQJitARwEPUONbDKlju,params=BWXsHSeaxrFTQJitARwEPUONbDKljM,isLink=BWXsHSeaxrFTQJitARwEPUONbDKljd)
  if BWXsHSeaxrFTQJitARwEPUONbDKlMY(BWXsHSeaxrFTQJitARwEPUONbDKlvf)>0:xbmcplugin.endOfDirectory(BWXsHSeaxrFTQJitARwEPUONbDKlvM._addon_handle,cacheToDisc=BWXsHSeaxrFTQJitARwEPUONbDKlMy)
 def dp_MainLeague_List(BWXsHSeaxrFTQJitARwEPUONbDKlvM,args):
  BWXsHSeaxrFTQJitARwEPUONbDKlvM.addon_log('dp_MainLeague_List')
  BWXsHSeaxrFTQJitARwEPUONbDKljI=BWXsHSeaxrFTQJitARwEPUONbDKlvM.SpotvObj.GetTitleGroupList()
  BWXsHSeaxrFTQJitARwEPUONbDKlvM.addon_log('dp_MainLeague_List cnt : '+BWXsHSeaxrFTQJitARwEPUONbDKlMh(BWXsHSeaxrFTQJitARwEPUONbDKlMY(BWXsHSeaxrFTQJitARwEPUONbDKljI)))
  for BWXsHSeaxrFTQJitARwEPUONbDKljy in BWXsHSeaxrFTQJitARwEPUONbDKljI:
   BWXsHSeaxrFTQJitARwEPUONbDKlvh =BWXsHSeaxrFTQJitARwEPUONbDKljy.get('title')
   BWXsHSeaxrFTQJitARwEPUONbDKljo =BWXsHSeaxrFTQJitARwEPUONbDKljy.get('logo')
   BWXsHSeaxrFTQJitARwEPUONbDKljg =BWXsHSeaxrFTQJitARwEPUONbDKljy.get('reagueId')
   BWXsHSeaxrFTQJitARwEPUONbDKljc =BWXsHSeaxrFTQJitARwEPUONbDKljy.get('subGame')
   BWXsHSeaxrFTQJitARwEPUONbDKljq={'mediatype':'episode','plot':'%s\n\n%s'%(BWXsHSeaxrFTQJitARwEPUONbDKlvh,BWXsHSeaxrFTQJitARwEPUONbDKljc)}
   BWXsHSeaxrFTQJitARwEPUONbDKljM={'mode':'LEAGUE_GROUP','reagueId':BWXsHSeaxrFTQJitARwEPUONbDKljg}
   BWXsHSeaxrFTQJitARwEPUONbDKlvM.add_dir(BWXsHSeaxrFTQJitARwEPUONbDKlvh,sublabel=BWXsHSeaxrFTQJitARwEPUONbDKlMI,img=BWXsHSeaxrFTQJitARwEPUONbDKljo,infoLabels=BWXsHSeaxrFTQJitARwEPUONbDKljq,isFolder=BWXsHSeaxrFTQJitARwEPUONbDKlMo,params=BWXsHSeaxrFTQJitARwEPUONbDKljM)
  if BWXsHSeaxrFTQJitARwEPUONbDKlMY(BWXsHSeaxrFTQJitARwEPUONbDKljI)>0:xbmcplugin.endOfDirectory(BWXsHSeaxrFTQJitARwEPUONbDKlvM._addon_handle,cacheToDisc=BWXsHSeaxrFTQJitARwEPUONbDKlMy)
 def dp_NowVod_GroupList(BWXsHSeaxrFTQJitARwEPUONbDKlvM,args):
  BWXsHSeaxrFTQJitARwEPUONbDKljp=BWXsHSeaxrFTQJitARwEPUONbDKlMq(args.get('page'))
  BWXsHSeaxrFTQJitARwEPUONbDKlvM.addon_log('dp_NowVod_GroupList page : '+BWXsHSeaxrFTQJitARwEPUONbDKlMh(BWXsHSeaxrFTQJitARwEPUONbDKljp))
  BWXsHSeaxrFTQJitARwEPUONbDKljI,BWXsHSeaxrFTQJitARwEPUONbDKljY=BWXsHSeaxrFTQJitARwEPUONbDKlvM.SpotvObj.Get_NowVod_GroupList(BWXsHSeaxrFTQJitARwEPUONbDKljp)
  BWXsHSeaxrFTQJitARwEPUONbDKlvM.addon_log('dp_NowVod_GroupList cnt : '+BWXsHSeaxrFTQJitARwEPUONbDKlMh(BWXsHSeaxrFTQJitARwEPUONbDKlMY(BWXsHSeaxrFTQJitARwEPUONbDKljI)))
  for BWXsHSeaxrFTQJitARwEPUONbDKljy in BWXsHSeaxrFTQJitARwEPUONbDKljI:
   BWXsHSeaxrFTQJitARwEPUONbDKljh =BWXsHSeaxrFTQJitARwEPUONbDKljy.get('vodTitle')
   BWXsHSeaxrFTQJitARwEPUONbDKljn =BWXsHSeaxrFTQJitARwEPUONbDKljy.get('vodId')
   BWXsHSeaxrFTQJitARwEPUONbDKljC =BWXsHSeaxrFTQJitARwEPUONbDKljy.get('vodType')
   BWXsHSeaxrFTQJitARwEPUONbDKljo=BWXsHSeaxrFTQJitARwEPUONbDKljy.get('thumbnail')
   BWXsHSeaxrFTQJitARwEPUONbDKljz =BWXsHSeaxrFTQJitARwEPUONbDKljy.get('vtypeId')
   BWXsHSeaxrFTQJitARwEPUONbDKljV =BWXsHSeaxrFTQJitARwEPUONbDKljy.get('duration')
   BWXsHSeaxrFTQJitARwEPUONbDKljq={'mediatype':'episode','duration':BWXsHSeaxrFTQJitARwEPUONbDKljV,'plot':BWXsHSeaxrFTQJitARwEPUONbDKljh}
   BWXsHSeaxrFTQJitARwEPUONbDKljM={'mode':'NOW_VOD','mediacode':BWXsHSeaxrFTQJitARwEPUONbDKljn,'mediatype':'vod','vtypeId':BWXsHSeaxrFTQJitARwEPUONbDKljz}
   BWXsHSeaxrFTQJitARwEPUONbDKlvM.add_dir(BWXsHSeaxrFTQJitARwEPUONbDKljh,sublabel=BWXsHSeaxrFTQJitARwEPUONbDKljC,img=BWXsHSeaxrFTQJitARwEPUONbDKljo,infoLabels=BWXsHSeaxrFTQJitARwEPUONbDKljq,isFolder=BWXsHSeaxrFTQJitARwEPUONbDKlMy,params=BWXsHSeaxrFTQJitARwEPUONbDKljM)
  if BWXsHSeaxrFTQJitARwEPUONbDKljY:
   BWXsHSeaxrFTQJitARwEPUONbDKljM['mode'] ='NOW_GROUP' 
   BWXsHSeaxrFTQJitARwEPUONbDKljM['page'] =BWXsHSeaxrFTQJitARwEPUONbDKlMh(BWXsHSeaxrFTQJitARwEPUONbDKljp+1)
   BWXsHSeaxrFTQJitARwEPUONbDKlvh='[B]%s >>[/B]'%'다음 페이지'
   BWXsHSeaxrFTQJitARwEPUONbDKlfv=BWXsHSeaxrFTQJitARwEPUONbDKlMh(BWXsHSeaxrFTQJitARwEPUONbDKljp+1)
   BWXsHSeaxrFTQJitARwEPUONbDKljG=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   BWXsHSeaxrFTQJitARwEPUONbDKlvM.add_dir(BWXsHSeaxrFTQJitARwEPUONbDKlvh,sublabel=BWXsHSeaxrFTQJitARwEPUONbDKlfv,img=BWXsHSeaxrFTQJitARwEPUONbDKljG,infoLabels=BWXsHSeaxrFTQJitARwEPUONbDKlMI,isFolder=BWXsHSeaxrFTQJitARwEPUONbDKlMo,params=BWXsHSeaxrFTQJitARwEPUONbDKljM)
  xbmcplugin.setContent(BWXsHSeaxrFTQJitARwEPUONbDKlvM._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(BWXsHSeaxrFTQJitARwEPUONbDKlvM._addon_handle,cacheToDisc=BWXsHSeaxrFTQJitARwEPUONbDKlMy)
 def dp_PopVod_GroupList(BWXsHSeaxrFTQJitARwEPUONbDKlvM,args):
  BWXsHSeaxrFTQJitARwEPUONbDKlvM.addon_log('dp_PopVod_GroupList ')
  BWXsHSeaxrFTQJitARwEPUONbDKljI=BWXsHSeaxrFTQJitARwEPUONbDKlvM.SpotvObj.GetPopularGroupList()
  BWXsHSeaxrFTQJitARwEPUONbDKlvM.addon_log('dp_PopVod_GroupList cnt : '+BWXsHSeaxrFTQJitARwEPUONbDKlMh(BWXsHSeaxrFTQJitARwEPUONbDKlMY(BWXsHSeaxrFTQJitARwEPUONbDKljI)))
  for BWXsHSeaxrFTQJitARwEPUONbDKljy in BWXsHSeaxrFTQJitARwEPUONbDKljI:
   BWXsHSeaxrFTQJitARwEPUONbDKljh =BWXsHSeaxrFTQJitARwEPUONbDKljy.get('vodTitle')
   BWXsHSeaxrFTQJitARwEPUONbDKljn =BWXsHSeaxrFTQJitARwEPUONbDKljy.get('vodId')
   BWXsHSeaxrFTQJitARwEPUONbDKljC =BWXsHSeaxrFTQJitARwEPUONbDKljy.get('vodType')
   BWXsHSeaxrFTQJitARwEPUONbDKljo=BWXsHSeaxrFTQJitARwEPUONbDKljy.get('thumbnail')
   BWXsHSeaxrFTQJitARwEPUONbDKljz =BWXsHSeaxrFTQJitARwEPUONbDKljy.get('vtypeId')
   BWXsHSeaxrFTQJitARwEPUONbDKljV =BWXsHSeaxrFTQJitARwEPUONbDKljy.get('duration')
   BWXsHSeaxrFTQJitARwEPUONbDKljq={'mediatype':'episode','duration':BWXsHSeaxrFTQJitARwEPUONbDKljV,'plot':BWXsHSeaxrFTQJitARwEPUONbDKljh}
   BWXsHSeaxrFTQJitARwEPUONbDKljM={'mode':'POP_VOD','mediacode':BWXsHSeaxrFTQJitARwEPUONbDKljn,'mediatype':'vod','vtypeId':BWXsHSeaxrFTQJitARwEPUONbDKljz}
   BWXsHSeaxrFTQJitARwEPUONbDKlvM.add_dir(BWXsHSeaxrFTQJitARwEPUONbDKljh,sublabel=BWXsHSeaxrFTQJitARwEPUONbDKljC,img=BWXsHSeaxrFTQJitARwEPUONbDKljo,infoLabels=BWXsHSeaxrFTQJitARwEPUONbDKljq,isFolder=BWXsHSeaxrFTQJitARwEPUONbDKlMy,params=BWXsHSeaxrFTQJitARwEPUONbDKljM)
  xbmcplugin.setContent(BWXsHSeaxrFTQJitARwEPUONbDKlvM._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(BWXsHSeaxrFTQJitARwEPUONbDKlvM._addon_handle,cacheToDisc=BWXsHSeaxrFTQJitARwEPUONbDKlMy)
 def dp_Season_List(BWXsHSeaxrFTQJitARwEPUONbDKlvM,args):
  BWXsHSeaxrFTQJitARwEPUONbDKljg=args.get('reagueId')
  BWXsHSeaxrFTQJitARwEPUONbDKlvM.addon_log('Season_List - reagueId : '+BWXsHSeaxrFTQJitARwEPUONbDKljg)
  BWXsHSeaxrFTQJitARwEPUONbDKljI=BWXsHSeaxrFTQJitARwEPUONbDKlvM.SpotvObj.GetSeasonList(BWXsHSeaxrFTQJitARwEPUONbDKljg)
  for BWXsHSeaxrFTQJitARwEPUONbDKljy in BWXsHSeaxrFTQJitARwEPUONbDKljI:
   BWXsHSeaxrFTQJitARwEPUONbDKlfm =BWXsHSeaxrFTQJitARwEPUONbDKljy.get('reagueName')
   BWXsHSeaxrFTQJitARwEPUONbDKlfG =BWXsHSeaxrFTQJitARwEPUONbDKljy.get('gameTypeId')
   BWXsHSeaxrFTQJitARwEPUONbDKlfM =BWXsHSeaxrFTQJitARwEPUONbDKljy.get('seasonName')
   BWXsHSeaxrFTQJitARwEPUONbDKlfu =BWXsHSeaxrFTQJitARwEPUONbDKljy.get('seasonId')
   BWXsHSeaxrFTQJitARwEPUONbDKljq={'mediatype':'episode','plot':'%s - %s'%(BWXsHSeaxrFTQJitARwEPUONbDKlfm,BWXsHSeaxrFTQJitARwEPUONbDKlfM)}
   BWXsHSeaxrFTQJitARwEPUONbDKljM={'mode':'SEASON_GROUP','reagueId':BWXsHSeaxrFTQJitARwEPUONbDKljg,'seasonId':BWXsHSeaxrFTQJitARwEPUONbDKlfu,'gameTypeId':BWXsHSeaxrFTQJitARwEPUONbDKlfG,'page':'1'}
   BWXsHSeaxrFTQJitARwEPUONbDKlvM.add_dir(BWXsHSeaxrFTQJitARwEPUONbDKlfm,sublabel=BWXsHSeaxrFTQJitARwEPUONbDKlfM,img='',infoLabels=BWXsHSeaxrFTQJitARwEPUONbDKljq,isFolder=BWXsHSeaxrFTQJitARwEPUONbDKlMo,params=BWXsHSeaxrFTQJitARwEPUONbDKljM)
  if BWXsHSeaxrFTQJitARwEPUONbDKlMY(BWXsHSeaxrFTQJitARwEPUONbDKljI)>0:xbmcplugin.endOfDirectory(BWXsHSeaxrFTQJitARwEPUONbDKlvM._addon_handle,cacheToDisc=BWXsHSeaxrFTQJitARwEPUONbDKlMy)
 def dp_Game_List(BWXsHSeaxrFTQJitARwEPUONbDKlvM,args):
  BWXsHSeaxrFTQJitARwEPUONbDKlfG=args.get('gameTypeId')
  BWXsHSeaxrFTQJitARwEPUONbDKljg =args.get('reagueId')
  BWXsHSeaxrFTQJitARwEPUONbDKlfu =args.get('seasonId')
  BWXsHSeaxrFTQJitARwEPUONbDKljp =BWXsHSeaxrFTQJitARwEPUONbDKlMq(args.get('page'))
  BWXsHSeaxrFTQJitARwEPUONbDKlvM.addon_log('Game_List - gameTypeId : '+BWXsHSeaxrFTQJitARwEPUONbDKlfG)
  BWXsHSeaxrFTQJitARwEPUONbDKlvM.addon_log('Game_List - reagueId   : '+BWXsHSeaxrFTQJitARwEPUONbDKljg)
  BWXsHSeaxrFTQJitARwEPUONbDKlvM.addon_log('Game_List - seasonId   : '+BWXsHSeaxrFTQJitARwEPUONbDKlfu)
  BWXsHSeaxrFTQJitARwEPUONbDKljI,BWXsHSeaxrFTQJitARwEPUONbDKljY=BWXsHSeaxrFTQJitARwEPUONbDKlvM.SpotvObj.GetGameList(BWXsHSeaxrFTQJitARwEPUONbDKlfG,BWXsHSeaxrFTQJitARwEPUONbDKljg,BWXsHSeaxrFTQJitARwEPUONbDKlfu,BWXsHSeaxrFTQJitARwEPUONbDKljp,hidescore=BWXsHSeaxrFTQJitARwEPUONbDKlvM.get_settings_hidescoreyn())
  for BWXsHSeaxrFTQJitARwEPUONbDKljy in BWXsHSeaxrFTQJitARwEPUONbDKljI:
   BWXsHSeaxrFTQJitARwEPUONbDKlfd =BWXsHSeaxrFTQJitARwEPUONbDKljy.get('gameTitle')
   BWXsHSeaxrFTQJitARwEPUONbDKlfL =BWXsHSeaxrFTQJitARwEPUONbDKljy.get('beginDate')
   BWXsHSeaxrFTQJitARwEPUONbDKljo =BWXsHSeaxrFTQJitARwEPUONbDKljy.get('thumbnail')
   BWXsHSeaxrFTQJitARwEPUONbDKlfk =BWXsHSeaxrFTQJitARwEPUONbDKljy.get('gameId')
   BWXsHSeaxrFTQJitARwEPUONbDKlfI =BWXsHSeaxrFTQJitARwEPUONbDKljy.get('totVodCnt')
   BWXsHSeaxrFTQJitARwEPUONbDKlfy =BWXsHSeaxrFTQJitARwEPUONbDKljy.get('leaguenm')
   BWXsHSeaxrFTQJitARwEPUONbDKlfo =BWXsHSeaxrFTQJitARwEPUONbDKljy.get('seasonnm')
   BWXsHSeaxrFTQJitARwEPUONbDKlfg =BWXsHSeaxrFTQJitARwEPUONbDKljy.get('roundnm')
   BWXsHSeaxrFTQJitARwEPUONbDKlfc =BWXsHSeaxrFTQJitARwEPUONbDKljy.get('info_plot')
   BWXsHSeaxrFTQJitARwEPUONbDKlfq ='%s < %s >'%(BWXsHSeaxrFTQJitARwEPUONbDKlfd,BWXsHSeaxrFTQJitARwEPUONbDKlfL)
   BWXsHSeaxrFTQJitARwEPUONbDKljq={'mediatype':'video','plot':BWXsHSeaxrFTQJitARwEPUONbDKlfc}
   BWXsHSeaxrFTQJitARwEPUONbDKljM={'mode':'GAME_VOD_GROUP' if BWXsHSeaxrFTQJitARwEPUONbDKlfI!=0 else 'XXX','saveTitle':BWXsHSeaxrFTQJitARwEPUONbDKlfq,'saveImg':BWXsHSeaxrFTQJitARwEPUONbDKljo,'saveInfo':BWXsHSeaxrFTQJitARwEPUONbDKljq['plot'],'gameid':BWXsHSeaxrFTQJitARwEPUONbDKlfk,'totVodCnt':BWXsHSeaxrFTQJitARwEPUONbDKlfI,}
   BWXsHSeaxrFTQJitARwEPUONbDKlvM.add_dir(BWXsHSeaxrFTQJitARwEPUONbDKlfd,sublabel=BWXsHSeaxrFTQJitARwEPUONbDKlfL,img=BWXsHSeaxrFTQJitARwEPUONbDKljo,infoLabels=BWXsHSeaxrFTQJitARwEPUONbDKljq,isFolder=BWXsHSeaxrFTQJitARwEPUONbDKlMo,params=BWXsHSeaxrFTQJitARwEPUONbDKljM)
  if BWXsHSeaxrFTQJitARwEPUONbDKljY:
   BWXsHSeaxrFTQJitARwEPUONbDKljM['mode'] ='SEASON_GROUP' 
   BWXsHSeaxrFTQJitARwEPUONbDKljM['reagueId'] =BWXsHSeaxrFTQJitARwEPUONbDKljg
   BWXsHSeaxrFTQJitARwEPUONbDKljM['seasonId'] =BWXsHSeaxrFTQJitARwEPUONbDKlfu
   BWXsHSeaxrFTQJitARwEPUONbDKljM['gameTypeId']=BWXsHSeaxrFTQJitARwEPUONbDKlfG
   BWXsHSeaxrFTQJitARwEPUONbDKljM['page'] =BWXsHSeaxrFTQJitARwEPUONbDKlMh(BWXsHSeaxrFTQJitARwEPUONbDKljp+1)
   BWXsHSeaxrFTQJitARwEPUONbDKlvh='[B]%s >>[/B]'%'다음 페이지'
   BWXsHSeaxrFTQJitARwEPUONbDKlfv=BWXsHSeaxrFTQJitARwEPUONbDKlMh(BWXsHSeaxrFTQJitARwEPUONbDKljp+1)
   BWXsHSeaxrFTQJitARwEPUONbDKljG=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   BWXsHSeaxrFTQJitARwEPUONbDKlvM.add_dir(BWXsHSeaxrFTQJitARwEPUONbDKlvh,sublabel=BWXsHSeaxrFTQJitARwEPUONbDKlfv,img=BWXsHSeaxrFTQJitARwEPUONbDKljG,infoLabels=BWXsHSeaxrFTQJitARwEPUONbDKlMI,isFolder=BWXsHSeaxrFTQJitARwEPUONbDKlMo,params=BWXsHSeaxrFTQJitARwEPUONbDKljM)
  if BWXsHSeaxrFTQJitARwEPUONbDKlMY(BWXsHSeaxrFTQJitARwEPUONbDKljI)>0:xbmcplugin.endOfDirectory(BWXsHSeaxrFTQJitARwEPUONbDKlvM._addon_handle,cacheToDisc=BWXsHSeaxrFTQJitARwEPUONbDKlMy)
 def dp_GameVod_List(BWXsHSeaxrFTQJitARwEPUONbDKlvM,args):
  BWXsHSeaxrFTQJitARwEPUONbDKlfp =args.get('gameid')
  BWXsHSeaxrFTQJitARwEPUONbDKlfq=args.get('saveTitle')
  BWXsHSeaxrFTQJitARwEPUONbDKlfY =args.get('saveImg')
  BWXsHSeaxrFTQJitARwEPUONbDKlfh =args.get('saveInfo')
  BWXsHSeaxrFTQJitARwEPUONbDKljI=BWXsHSeaxrFTQJitARwEPUONbDKlvM.SpotvObj.GetGameVodList(BWXsHSeaxrFTQJitARwEPUONbDKlfp)
  for BWXsHSeaxrFTQJitARwEPUONbDKljy in BWXsHSeaxrFTQJitARwEPUONbDKljI:
   BWXsHSeaxrFTQJitARwEPUONbDKljh =BWXsHSeaxrFTQJitARwEPUONbDKljy.get('vodTitle')
   BWXsHSeaxrFTQJitARwEPUONbDKljn =BWXsHSeaxrFTQJitARwEPUONbDKljy.get('vodId')
   BWXsHSeaxrFTQJitARwEPUONbDKljC =BWXsHSeaxrFTQJitARwEPUONbDKljy.get('vodType')
   BWXsHSeaxrFTQJitARwEPUONbDKljo=BWXsHSeaxrFTQJitARwEPUONbDKljy.get('thumbnail')
   BWXsHSeaxrFTQJitARwEPUONbDKljz =BWXsHSeaxrFTQJitARwEPUONbDKljy.get('vtypeId')
   BWXsHSeaxrFTQJitARwEPUONbDKljV =BWXsHSeaxrFTQJitARwEPUONbDKljy.get('duration')
   BWXsHSeaxrFTQJitARwEPUONbDKljq={'mediatype':'episode','duration':BWXsHSeaxrFTQJitARwEPUONbDKljV,'plot':'%s \n\n %s'%(BWXsHSeaxrFTQJitARwEPUONbDKljh,BWXsHSeaxrFTQJitARwEPUONbDKlfh)}
   BWXsHSeaxrFTQJitARwEPUONbDKljM={'mode':'GAME_VOD','saveTitle':BWXsHSeaxrFTQJitARwEPUONbDKlfq,'saveImg':BWXsHSeaxrFTQJitARwEPUONbDKlfY,'saveId':BWXsHSeaxrFTQJitARwEPUONbDKlfp,'saveInfo':BWXsHSeaxrFTQJitARwEPUONbDKlfh,'mediacode':BWXsHSeaxrFTQJitARwEPUONbDKljn,'mediatype':'vod','vtypeId':BWXsHSeaxrFTQJitARwEPUONbDKljz}
   BWXsHSeaxrFTQJitARwEPUONbDKlvM.add_dir(BWXsHSeaxrFTQJitARwEPUONbDKljh,sublabel=BWXsHSeaxrFTQJitARwEPUONbDKljC,img=BWXsHSeaxrFTQJitARwEPUONbDKljo,infoLabels=BWXsHSeaxrFTQJitARwEPUONbDKljq,isFolder=BWXsHSeaxrFTQJitARwEPUONbDKlMy,params=BWXsHSeaxrFTQJitARwEPUONbDKljM)
  xbmcplugin.setContent(BWXsHSeaxrFTQJitARwEPUONbDKlvM._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(BWXsHSeaxrFTQJitARwEPUONbDKlvM._addon_handle,cacheToDisc=BWXsHSeaxrFTQJitARwEPUONbDKlMy)
 def login_main(BWXsHSeaxrFTQJitARwEPUONbDKlvM):
  (BWXsHSeaxrFTQJitARwEPUONbDKlfn,BWXsHSeaxrFTQJitARwEPUONbDKlfC)=BWXsHSeaxrFTQJitARwEPUONbDKlvM.get_settings_account()
  if not(BWXsHSeaxrFTQJitARwEPUONbDKlfn and BWXsHSeaxrFTQJitARwEPUONbDKlfC):
   BWXsHSeaxrFTQJitARwEPUONbDKlvI=xbmcgui.Dialog()
   BWXsHSeaxrFTQJitARwEPUONbDKlfz=BWXsHSeaxrFTQJitARwEPUONbDKlvI.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if BWXsHSeaxrFTQJitARwEPUONbDKlfz==BWXsHSeaxrFTQJitARwEPUONbDKlMo:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if BWXsHSeaxrFTQJitARwEPUONbDKlvM.cookiefile_check():return
  if xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINWAIT')=='TRUE':
   BWXsHSeaxrFTQJitARwEPUONbDKlfV=0
   while BWXsHSeaxrFTQJitARwEPUONbDKlMo:
    BWXsHSeaxrFTQJitARwEPUONbDKlfV+=1
    time.sleep(0.05)
    if BWXsHSeaxrFTQJitARwEPUONbDKlfV>600:return
  else:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','TRUE')
  BWXsHSeaxrFTQJitARwEPUONbDKlmv=BWXsHSeaxrFTQJitARwEPUONbDKlvM.SpotvObj.GetCredential_new(BWXsHSeaxrFTQJitARwEPUONbDKlfn,BWXsHSeaxrFTQJitARwEPUONbDKlfC)
  if BWXsHSeaxrFTQJitARwEPUONbDKlmv:BWXsHSeaxrFTQJitARwEPUONbDKlvM.cookiefile_save()
  xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
  if BWXsHSeaxrFTQJitARwEPUONbDKlmv==BWXsHSeaxrFTQJitARwEPUONbDKlMy:
   BWXsHSeaxrFTQJitARwEPUONbDKlvM.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_LiveChannel_List(BWXsHSeaxrFTQJitARwEPUONbDKlvM,args):
  BWXsHSeaxrFTQJitARwEPUONbDKlmj=BWXsHSeaxrFTQJitARwEPUONbDKlvM.SpotvObj.GetLiveChannelList()
  for BWXsHSeaxrFTQJitARwEPUONbDKlmf in BWXsHSeaxrFTQJitARwEPUONbDKlmj:
   BWXsHSeaxrFTQJitARwEPUONbDKlMn =BWXsHSeaxrFTQJitARwEPUONbDKlmf.get('id')
   BWXsHSeaxrFTQJitARwEPUONbDKlvh =BWXsHSeaxrFTQJitARwEPUONbDKlmf.get('name')
   BWXsHSeaxrFTQJitARwEPUONbDKljk =BWXsHSeaxrFTQJitARwEPUONbDKlmf.get('programName')
   BWXsHSeaxrFTQJitARwEPUONbDKljo =BWXsHSeaxrFTQJitARwEPUONbDKlmf.get('logo')
   BWXsHSeaxrFTQJitARwEPUONbDKlmG=BWXsHSeaxrFTQJitARwEPUONbDKlmf.get('channelepg')
   BWXsHSeaxrFTQJitARwEPUONbDKlmM =BWXsHSeaxrFTQJitARwEPUONbDKlmf.get('free')
   BWXsHSeaxrFTQJitARwEPUONbDKljq={'plot':'%s\n\n%s'%(BWXsHSeaxrFTQJitARwEPUONbDKlvh,BWXsHSeaxrFTQJitARwEPUONbDKlmG),'mediatype':'episode',}
   BWXsHSeaxrFTQJitARwEPUONbDKljM={'mode':'LIVE','mediacode':BWXsHSeaxrFTQJitARwEPUONbDKlMn,'free':BWXsHSeaxrFTQJitARwEPUONbDKlmM,'mediatype':'live'}
   if BWXsHSeaxrFTQJitARwEPUONbDKlmM:BWXsHSeaxrFTQJitARwEPUONbDKlvh+=' [free]'
   BWXsHSeaxrFTQJitARwEPUONbDKlvM.add_dir(BWXsHSeaxrFTQJitARwEPUONbDKlvh,sublabel=BWXsHSeaxrFTQJitARwEPUONbDKljk,img=BWXsHSeaxrFTQJitARwEPUONbDKljo,infoLabels=BWXsHSeaxrFTQJitARwEPUONbDKljq,isFolder=BWXsHSeaxrFTQJitARwEPUONbDKlMy,params=BWXsHSeaxrFTQJitARwEPUONbDKljM)
  xbmcplugin.setContent(BWXsHSeaxrFTQJitARwEPUONbDKlvM._addon_handle,'episodes')
  if BWXsHSeaxrFTQJitARwEPUONbDKlMY(BWXsHSeaxrFTQJitARwEPUONbDKlmj)>0:xbmcplugin.endOfDirectory(BWXsHSeaxrFTQJitARwEPUONbDKlvM._addon_handle,cacheToDisc=BWXsHSeaxrFTQJitARwEPUONbDKlMy)
 def dp_EventLiveChannel_List(BWXsHSeaxrFTQJitARwEPUONbDKlvM,args):
  BWXsHSeaxrFTQJitARwEPUONbDKlmj,BWXsHSeaxrFTQJitARwEPUONbDKlmu=BWXsHSeaxrFTQJitARwEPUONbDKlvM.SpotvObj.GetEventLiveList()
  if BWXsHSeaxrFTQJitARwEPUONbDKlmu!=401 and BWXsHSeaxrFTQJitARwEPUONbDKlMY(BWXsHSeaxrFTQJitARwEPUONbDKlmj)==0:
   BWXsHSeaxrFTQJitARwEPUONbDKlvM.addon_noti(__language__(30907).encode('utf8'))
  for BWXsHSeaxrFTQJitARwEPUONbDKlmf in BWXsHSeaxrFTQJitARwEPUONbDKlmj:
   BWXsHSeaxrFTQJitARwEPUONbDKlvh =BWXsHSeaxrFTQJitARwEPUONbDKlmf.get('title')
   BWXsHSeaxrFTQJitARwEPUONbDKljk =BWXsHSeaxrFTQJitARwEPUONbDKlmf.get('startTime')
   BWXsHSeaxrFTQJitARwEPUONbDKljo =BWXsHSeaxrFTQJitARwEPUONbDKlmf.get('logo')
   BWXsHSeaxrFTQJitARwEPUONbDKlmM =BWXsHSeaxrFTQJitARwEPUONbDKlmf.get('free')
   BWXsHSeaxrFTQJitARwEPUONbDKljq={'mediatype':'episode','plot':'%s\n\n%s'%(BWXsHSeaxrFTQJitARwEPUONbDKlvh,BWXsHSeaxrFTQJitARwEPUONbDKljk)}
   BWXsHSeaxrFTQJitARwEPUONbDKljM={'mode':'ELIVE','mediacode':BWXsHSeaxrFTQJitARwEPUONbDKlmf.get('liveId'),'free':BWXsHSeaxrFTQJitARwEPUONbDKlmM,'mediatype':'live'}
   if BWXsHSeaxrFTQJitARwEPUONbDKlmM:BWXsHSeaxrFTQJitARwEPUONbDKlvh+=' [free]'
   BWXsHSeaxrFTQJitARwEPUONbDKlvM.add_dir(BWXsHSeaxrFTQJitARwEPUONbDKlvh,sublabel=BWXsHSeaxrFTQJitARwEPUONbDKljk,img=BWXsHSeaxrFTQJitARwEPUONbDKljo,infoLabels=BWXsHSeaxrFTQJitARwEPUONbDKljq,isFolder=BWXsHSeaxrFTQJitARwEPUONbDKlMy,params=BWXsHSeaxrFTQJitARwEPUONbDKljM)
  xbmcplugin.setContent(BWXsHSeaxrFTQJitARwEPUONbDKlvM._addon_handle,'episodes')
  if BWXsHSeaxrFTQJitARwEPUONbDKlMY(BWXsHSeaxrFTQJitARwEPUONbDKlmj)>0:xbmcplugin.endOfDirectory(BWXsHSeaxrFTQJitARwEPUONbDKlvM._addon_handle,cacheToDisc=BWXsHSeaxrFTQJitARwEPUONbDKlMy)
  return BWXsHSeaxrFTQJitARwEPUONbDKlmu
 def make_stream_header(BWXsHSeaxrFTQJitARwEPUONbDKlvM,BWXsHSeaxrFTQJitARwEPUONbDKlmI,cookies):
  BWXsHSeaxrFTQJitARwEPUONbDKlmd=''
  if cookies not in[{},BWXsHSeaxrFTQJitARwEPUONbDKlMI,'']:
   BWXsHSeaxrFTQJitARwEPUONbDKlmL=BWXsHSeaxrFTQJitARwEPUONbDKlMY(cookies)
   for BWXsHSeaxrFTQJitARwEPUONbDKlvC,BWXsHSeaxrFTQJitARwEPUONbDKlmk in cookies.items():
    BWXsHSeaxrFTQJitARwEPUONbDKlmd+='{}={}'.format(BWXsHSeaxrFTQJitARwEPUONbDKlvC,BWXsHSeaxrFTQJitARwEPUONbDKlmk)
    BWXsHSeaxrFTQJitARwEPUONbDKlmL+=-1
    if BWXsHSeaxrFTQJitARwEPUONbDKlmL>0:BWXsHSeaxrFTQJitARwEPUONbDKlmd+='; '
   BWXsHSeaxrFTQJitARwEPUONbDKlmI['cookie']=BWXsHSeaxrFTQJitARwEPUONbDKlmd
  BWXsHSeaxrFTQJitARwEPUONbDKlmy=''
  i=0
  for BWXsHSeaxrFTQJitARwEPUONbDKlvC,BWXsHSeaxrFTQJitARwEPUONbDKlmk in BWXsHSeaxrFTQJitARwEPUONbDKlmI.items():
   i=i+1
   if i>1:BWXsHSeaxrFTQJitARwEPUONbDKlmy+='&'
   BWXsHSeaxrFTQJitARwEPUONbDKlmy+='{}={}'.format(BWXsHSeaxrFTQJitARwEPUONbDKlvC,urllib.parse.quote(BWXsHSeaxrFTQJitARwEPUONbDKlmk))
  return BWXsHSeaxrFTQJitARwEPUONbDKlmy
 def play_VIDEO(BWXsHSeaxrFTQJitARwEPUONbDKlvM,args):
  BWXsHSeaxrFTQJitARwEPUONbDKlmo =args.get('mode')
  BWXsHSeaxrFTQJitARwEPUONbDKlmg =args.get('mediacode')
  BWXsHSeaxrFTQJitARwEPUONbDKlmc =args.get('mediatype')
  BWXsHSeaxrFTQJitARwEPUONbDKljz =args.get('vtypeId')
  BWXsHSeaxrFTQJitARwEPUONbDKlmq =args.get('hlsUrl')
  if BWXsHSeaxrFTQJitARwEPUONbDKlmo=='LIVE':
   if args.get('free')=='False':
    if BWXsHSeaxrFTQJitARwEPUONbDKlvM.SpotvObj.CheckSubEnd()==BWXsHSeaxrFTQJitARwEPUONbDKlMy:
     BWXsHSeaxrFTQJitARwEPUONbDKlvM.addon_noti(__language__(30908).encode('utf8'))
     return
  elif BWXsHSeaxrFTQJitARwEPUONbDKlmo=='ELIVE':
   if args.get('free')=='False':
    if BWXsHSeaxrFTQJitARwEPUONbDKlvM.SpotvObj.CheckSubEnd()==BWXsHSeaxrFTQJitARwEPUONbDKlMy:
     BWXsHSeaxrFTQJitARwEPUONbDKlvM.addon_noti(__language__(30908).encode('utf8'))
     return
  if BWXsHSeaxrFTQJitARwEPUONbDKlmg=='' or BWXsHSeaxrFTQJitARwEPUONbDKlmg==BWXsHSeaxrFTQJitARwEPUONbDKlMI:
   BWXsHSeaxrFTQJitARwEPUONbDKlvM.addon_noti(__language__(30907).encode('utf8'))
   return
  if BWXsHSeaxrFTQJitARwEPUONbDKlmo=='LIVE':
   BWXsHSeaxrFTQJitARwEPUONbDKlmp,BWXsHSeaxrFTQJitARwEPUONbDKlmY=BWXsHSeaxrFTQJitARwEPUONbDKlvM.SpotvObj.GetHlsUrl(BWXsHSeaxrFTQJitARwEPUONbDKlmg)
  else:
   BWXsHSeaxrFTQJitARwEPUONbDKlvM.addon_log('mediacode : '+BWXsHSeaxrFTQJitARwEPUONbDKlmg)
   BWXsHSeaxrFTQJitARwEPUONbDKlvM.addon_log('mediatype : '+BWXsHSeaxrFTQJitARwEPUONbDKlmc)
   BWXsHSeaxrFTQJitARwEPUONbDKlvM.addon_log('vtypeId   : '+BWXsHSeaxrFTQJitARwEPUONbDKlMh(BWXsHSeaxrFTQJitARwEPUONbDKljz))
   BWXsHSeaxrFTQJitARwEPUONbDKlmp,BWXsHSeaxrFTQJitARwEPUONbDKlmY=BWXsHSeaxrFTQJitARwEPUONbDKlvM.SpotvObj.GetBroadURL(BWXsHSeaxrFTQJitARwEPUONbDKlmg,BWXsHSeaxrFTQJitARwEPUONbDKlmc,BWXsHSeaxrFTQJitARwEPUONbDKljz)
  if BWXsHSeaxrFTQJitARwEPUONbDKlmY=='':
   BWXsHSeaxrFTQJitARwEPUONbDKlvM.addon_noti(__language__(30908).encode('utf8'))
   return
  BWXsHSeaxrFTQJitARwEPUONbDKlmh=BWXsHSeaxrFTQJitARwEPUONbDKlmY
  try:
   BWXsHSeaxrFTQJitARwEPUONbDKlvM.addon_log('mainMode  = '+BWXsHSeaxrFTQJitARwEPUONbDKlmo)
  except:
   BWXsHSeaxrFTQJitARwEPUONbDKlMI
  BWXsHSeaxrFTQJitARwEPUONbDKlvM.addon_log(BWXsHSeaxrFTQJitARwEPUONbDKlmh)
  BWXsHSeaxrFTQJitARwEPUONbDKlmn=xbmcgui.ListItem(path=BWXsHSeaxrFTQJitARwEPUONbDKlmh)
  if BWXsHSeaxrFTQJitARwEPUONbDKlmo in['LIVE','ELIVE']:
   BWXsHSeaxrFTQJitARwEPUONbDKlmC={}
   BWXsHSeaxrFTQJitARwEPUONbDKlmC['content-type']='application/octet-stream' 
   BWXsHSeaxrFTQJitARwEPUONbDKlmC['user-agent'] =BWXsHSeaxrFTQJitARwEPUONbDKlvM.SpotvObj.USER_AGENT
   BWXsHSeaxrFTQJitARwEPUONbDKlmz ='https://www.spotvnow.co.kr/drm/widevine/{}/{}'.format(BWXsHSeaxrFTQJitARwEPUONbDKlmp,BWXsHSeaxrFTQJitARwEPUONbDKlvM.SpotvObj.ST['cookies']['spotv_sessionid'])
   BWXsHSeaxrFTQJitARwEPUONbDKlmV=BWXsHSeaxrFTQJitARwEPUONbDKlmz+'|'+urllib.parse.urlencode(BWXsHSeaxrFTQJitARwEPUONbDKlmC)+'|R{SSM}|'
   BWXsHSeaxrFTQJitARwEPUONbDKlGv=BWXsHSeaxrFTQJitARwEPUONbDKlvM.make_stream_header(BWXsHSeaxrFTQJitARwEPUONbDKlmC,BWXsHSeaxrFTQJitARwEPUONbDKlMI)
   BWXsHSeaxrFTQJitARwEPUONbDKlvM.addon_log(BWXsHSeaxrFTQJitARwEPUONbDKlmz)
   inputstreamhelper.Helper('hls',drm='com.widevine.alpha').check_inputstream()
   BWXsHSeaxrFTQJitARwEPUONbDKlmn.setProperty('inputstream','inputstream.adaptive')
   if BWXsHSeaxrFTQJitARwEPUONbDKlvM.SpotvObj.KodiVersion<=20:
    BWXsHSeaxrFTQJitARwEPUONbDKlmn.setProperty('inputstream.adaptive.manifest_type','hls')
   BWXsHSeaxrFTQJitARwEPUONbDKlmn.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
   BWXsHSeaxrFTQJitARwEPUONbDKlmn.setProperty('inputstream.adaptive.license_key',BWXsHSeaxrFTQJitARwEPUONbDKlmV)
   BWXsHSeaxrFTQJitARwEPUONbDKlmn.setProperty('inputstream.adaptive.stream_headers',BWXsHSeaxrFTQJitARwEPUONbDKlGv)
   BWXsHSeaxrFTQJitARwEPUONbDKlmn.setProperty('inputstream.adaptive.manifest_headers',BWXsHSeaxrFTQJitARwEPUONbDKlGv)
  xbmcplugin.setResolvedUrl(BWXsHSeaxrFTQJitARwEPUONbDKlvM._addon_handle,BWXsHSeaxrFTQJitARwEPUONbDKlMo,BWXsHSeaxrFTQJitARwEPUONbDKlmn)
  try:
   if BWXsHSeaxrFTQJitARwEPUONbDKlmc=='vod' and BWXsHSeaxrFTQJitARwEPUONbDKlmo not in['POP_VOD','NOW_VOD']:
    BWXsHSeaxrFTQJitARwEPUONbDKljM={'code':args.get('saveId'),'img':args.get('saveImg'),'title':args.get('saveTitle'),'info':args.get('saveInfo')}
    BWXsHSeaxrFTQJitARwEPUONbDKlvM.Save_Watched_List(BWXsHSeaxrFTQJitARwEPUONbDKlmc,BWXsHSeaxrFTQJitARwEPUONbDKljM)
  except:
   BWXsHSeaxrFTQJitARwEPUONbDKlMI
 def logout(BWXsHSeaxrFTQJitARwEPUONbDKlvM):
  BWXsHSeaxrFTQJitARwEPUONbDKlvI=xbmcgui.Dialog()
  BWXsHSeaxrFTQJitARwEPUONbDKlfz=BWXsHSeaxrFTQJitARwEPUONbDKlvI.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if BWXsHSeaxrFTQJitARwEPUONbDKlfz==BWXsHSeaxrFTQJitARwEPUONbDKlMy:sys.exit()
  BWXsHSeaxrFTQJitARwEPUONbDKlvM.SpotvObj.Init_ST_Total()
  if os.path.isfile(BWXsHSeaxrFTQJitARwEPUONbDKlvG):os.remove(BWXsHSeaxrFTQJitARwEPUONbDKlvG)
  BWXsHSeaxrFTQJitARwEPUONbDKlvM.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(BWXsHSeaxrFTQJitARwEPUONbDKlvM):
  BWXsHSeaxrFTQJitARwEPUONbDKlGf =BWXsHSeaxrFTQJitARwEPUONbDKlvM.SpotvObj.Get_Now_Datetime()
  BWXsHSeaxrFTQJitARwEPUONbDKlGm=BWXsHSeaxrFTQJitARwEPUONbDKlGf+datetime.timedelta(days=0)
  (BWXsHSeaxrFTQJitARwEPUONbDKlfn,BWXsHSeaxrFTQJitARwEPUONbDKlfC)=BWXsHSeaxrFTQJitARwEPUONbDKlvM.get_settings_account()
  BWXsHSeaxrFTQJitARwEPUONbDKlvM.SpotvObj.Save_session_acount(BWXsHSeaxrFTQJitARwEPUONbDKlfn,BWXsHSeaxrFTQJitARwEPUONbDKlfC)
  BWXsHSeaxrFTQJitARwEPUONbDKlvM.SpotvObj.ST['account']['token_limit']=BWXsHSeaxrFTQJitARwEPUONbDKlGm.strftime('%Y%m%d')
  BWXsHSeaxrFTQJitARwEPUONbDKlvM.SpotvObj.JsonFile_Save(BWXsHSeaxrFTQJitARwEPUONbDKlvG,BWXsHSeaxrFTQJitARwEPUONbDKlvM.SpotvObj.ST)
 def cookiefile_check(BWXsHSeaxrFTQJitARwEPUONbDKlvM):
  BWXsHSeaxrFTQJitARwEPUONbDKlvM.SpotvObj.ST=BWXsHSeaxrFTQJitARwEPUONbDKlvM.SpotvObj.JsonFile_Load(BWXsHSeaxrFTQJitARwEPUONbDKlvG)
  if 'account' not in BWXsHSeaxrFTQJitARwEPUONbDKlvM.SpotvObj.ST:
   BWXsHSeaxrFTQJitARwEPUONbDKlvM.SpotvObj.Init_ST_Total()
   return BWXsHSeaxrFTQJitARwEPUONbDKlMy
  (BWXsHSeaxrFTQJitARwEPUONbDKlGM,BWXsHSeaxrFTQJitARwEPUONbDKlGu)=BWXsHSeaxrFTQJitARwEPUONbDKlvM.get_settings_account()
  (BWXsHSeaxrFTQJitARwEPUONbDKlGd,BWXsHSeaxrFTQJitARwEPUONbDKlGL)=BWXsHSeaxrFTQJitARwEPUONbDKlvM.SpotvObj.Load_session_acount()
  if BWXsHSeaxrFTQJitARwEPUONbDKlGM!=BWXsHSeaxrFTQJitARwEPUONbDKlGd or BWXsHSeaxrFTQJitARwEPUONbDKlGu!=BWXsHSeaxrFTQJitARwEPUONbDKlGL:
   BWXsHSeaxrFTQJitARwEPUONbDKlvM.SpotvObj.Init_ST_Total()
   return BWXsHSeaxrFTQJitARwEPUONbDKlMy
  if BWXsHSeaxrFTQJitARwEPUONbDKlMq(BWXsHSeaxrFTQJitARwEPUONbDKlvM.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))>BWXsHSeaxrFTQJitARwEPUONbDKlMq(BWXsHSeaxrFTQJitARwEPUONbDKlvM.SpotvObj.ST['account']['token_limit']):
   BWXsHSeaxrFTQJitARwEPUONbDKlvM.SpotvObj.Init_ST_Total()
   return BWXsHSeaxrFTQJitARwEPUONbDKlMy
  return BWXsHSeaxrFTQJitARwEPUONbDKlMo
 def dp_History_Remove(BWXsHSeaxrFTQJitARwEPUONbDKlvM,args):
  BWXsHSeaxrFTQJitARwEPUONbDKlGk=args.get('delType')
  BWXsHSeaxrFTQJitARwEPUONbDKlGI =args.get('sKey')
  BWXsHSeaxrFTQJitARwEPUONbDKlGy =args.get('vType')
  BWXsHSeaxrFTQJitARwEPUONbDKlvI=xbmcgui.Dialog()
  if BWXsHSeaxrFTQJitARwEPUONbDKlGk=='WATCH_ALL':
   BWXsHSeaxrFTQJitARwEPUONbDKlfz=BWXsHSeaxrFTQJitARwEPUONbDKlvI.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif BWXsHSeaxrFTQJitARwEPUONbDKlGk=='WATCH_ONE':
   BWXsHSeaxrFTQJitARwEPUONbDKlfz=BWXsHSeaxrFTQJitARwEPUONbDKlvI.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  if BWXsHSeaxrFTQJitARwEPUONbDKlfz==BWXsHSeaxrFTQJitARwEPUONbDKlMy:sys.exit()
  if BWXsHSeaxrFTQJitARwEPUONbDKlGk=='WATCH_ALL':
   BWXsHSeaxrFTQJitARwEPUONbDKlGo=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%BWXsHSeaxrFTQJitARwEPUONbDKlGy))
   if os.path.isfile(BWXsHSeaxrFTQJitARwEPUONbDKlGo):os.remove(BWXsHSeaxrFTQJitARwEPUONbDKlGo)
  elif BWXsHSeaxrFTQJitARwEPUONbDKlGk=='WATCH_ONE':
   BWXsHSeaxrFTQJitARwEPUONbDKlGo=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%BWXsHSeaxrFTQJitARwEPUONbDKlGy))
   try:
    BWXsHSeaxrFTQJitARwEPUONbDKlGg=BWXsHSeaxrFTQJitARwEPUONbDKlvM.Load_List_File(BWXsHSeaxrFTQJitARwEPUONbDKlGy) 
    fp=BWXsHSeaxrFTQJitARwEPUONbDKlMC(BWXsHSeaxrFTQJitARwEPUONbDKlGo,'w',-1,'utf-8')
    for BWXsHSeaxrFTQJitARwEPUONbDKlGc in BWXsHSeaxrFTQJitARwEPUONbDKlGg:
     BWXsHSeaxrFTQJitARwEPUONbDKlGq=BWXsHSeaxrFTQJitARwEPUONbDKlMz(urllib.parse.parse_qsl(BWXsHSeaxrFTQJitARwEPUONbDKlGc))
     BWXsHSeaxrFTQJitARwEPUONbDKlGp=BWXsHSeaxrFTQJitARwEPUONbDKlGq.get('code').strip()
     if BWXsHSeaxrFTQJitARwEPUONbDKlGI!=BWXsHSeaxrFTQJitARwEPUONbDKlGp:
      fp.write(BWXsHSeaxrFTQJitARwEPUONbDKlGc)
    fp.close()
   except:
    BWXsHSeaxrFTQJitARwEPUONbDKlMI
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(BWXsHSeaxrFTQJitARwEPUONbDKlvM,BWXsHSeaxrFTQJitARwEPUONbDKlmc):
  try:
   BWXsHSeaxrFTQJitARwEPUONbDKlGY=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%BWXsHSeaxrFTQJitARwEPUONbDKlmc))
   fp=BWXsHSeaxrFTQJitARwEPUONbDKlMC(BWXsHSeaxrFTQJitARwEPUONbDKlGY,'r',-1,'utf-8')
   BWXsHSeaxrFTQJitARwEPUONbDKlGh=fp.readlines()
   fp.close()
  except:
   BWXsHSeaxrFTQJitARwEPUONbDKlGh=[]
  return BWXsHSeaxrFTQJitARwEPUONbDKlGh
 def Save_Watched_List(BWXsHSeaxrFTQJitARwEPUONbDKlvM,stype,BWXsHSeaxrFTQJitARwEPUONbDKlvL):
  try:
   BWXsHSeaxrFTQJitARwEPUONbDKlGY=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   BWXsHSeaxrFTQJitARwEPUONbDKlGg=BWXsHSeaxrFTQJitARwEPUONbDKlvM.Load_List_File(stype) 
   fp=BWXsHSeaxrFTQJitARwEPUONbDKlMC(BWXsHSeaxrFTQJitARwEPUONbDKlGY,'w',-1,'utf-8')
   BWXsHSeaxrFTQJitARwEPUONbDKlGn=urllib.parse.urlencode(BWXsHSeaxrFTQJitARwEPUONbDKlvL)
   BWXsHSeaxrFTQJitARwEPUONbDKlGn=BWXsHSeaxrFTQJitARwEPUONbDKlGn+'\n'
   fp.write(BWXsHSeaxrFTQJitARwEPUONbDKlGn)
   BWXsHSeaxrFTQJitARwEPUONbDKlGC=0
   for BWXsHSeaxrFTQJitARwEPUONbDKlGc in BWXsHSeaxrFTQJitARwEPUONbDKlGg:
    BWXsHSeaxrFTQJitARwEPUONbDKlGq=BWXsHSeaxrFTQJitARwEPUONbDKlMz(urllib.parse.parse_qsl(BWXsHSeaxrFTQJitARwEPUONbDKlGc))
    BWXsHSeaxrFTQJitARwEPUONbDKlGz=BWXsHSeaxrFTQJitARwEPUONbDKlvL.get('code')
    BWXsHSeaxrFTQJitARwEPUONbDKlGV=BWXsHSeaxrFTQJitARwEPUONbDKlGq.get('code')
    if BWXsHSeaxrFTQJitARwEPUONbDKlGz!=BWXsHSeaxrFTQJitARwEPUONbDKlGV:
     fp.write(BWXsHSeaxrFTQJitARwEPUONbDKlGc)
     BWXsHSeaxrFTQJitARwEPUONbDKlGC+=1
     if BWXsHSeaxrFTQJitARwEPUONbDKlGC>=50:break
   fp.close()
  except:
   BWXsHSeaxrFTQJitARwEPUONbDKlMI
 def dp_Watch_List(BWXsHSeaxrFTQJitARwEPUONbDKlvM,args):
  BWXsHSeaxrFTQJitARwEPUONbDKlmc ='vod'
  if BWXsHSeaxrFTQJitARwEPUONbDKlmc=='vod':
   BWXsHSeaxrFTQJitARwEPUONbDKlMv=BWXsHSeaxrFTQJitARwEPUONbDKlvM.Load_List_File(BWXsHSeaxrFTQJitARwEPUONbDKlmc)
   for BWXsHSeaxrFTQJitARwEPUONbDKlMj in BWXsHSeaxrFTQJitARwEPUONbDKlMv:
    BWXsHSeaxrFTQJitARwEPUONbDKlMf=BWXsHSeaxrFTQJitARwEPUONbDKlMz(urllib.parse.parse_qsl(BWXsHSeaxrFTQJitARwEPUONbDKlMj))
    BWXsHSeaxrFTQJitARwEPUONbDKlvh =BWXsHSeaxrFTQJitARwEPUONbDKlMf.get('title')
    BWXsHSeaxrFTQJitARwEPUONbDKljo=BWXsHSeaxrFTQJitARwEPUONbDKlMf.get('img')
    BWXsHSeaxrFTQJitARwEPUONbDKlmg=BWXsHSeaxrFTQJitARwEPUONbDKlMf.get('code')
    BWXsHSeaxrFTQJitARwEPUONbDKlMm =BWXsHSeaxrFTQJitARwEPUONbDKlMf.get('info')
    BWXsHSeaxrFTQJitARwEPUONbDKljq={}
    BWXsHSeaxrFTQJitARwEPUONbDKljq['plot'] =BWXsHSeaxrFTQJitARwEPUONbDKlMm
    BWXsHSeaxrFTQJitARwEPUONbDKljq['mediatype']='tvshow'
    BWXsHSeaxrFTQJitARwEPUONbDKljM={'mode':'GAME_VOD_GROUP','gameid':BWXsHSeaxrFTQJitARwEPUONbDKlmg,'saveTitle':BWXsHSeaxrFTQJitARwEPUONbDKlvh,'saveImg':BWXsHSeaxrFTQJitARwEPUONbDKljo,'saveInfo':BWXsHSeaxrFTQJitARwEPUONbDKlMm,'mediatype':BWXsHSeaxrFTQJitARwEPUONbDKlmc}
    BWXsHSeaxrFTQJitARwEPUONbDKlMG={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':BWXsHSeaxrFTQJitARwEPUONbDKlmg,'vType':BWXsHSeaxrFTQJitARwEPUONbDKlmc,}
    BWXsHSeaxrFTQJitARwEPUONbDKlMu=urllib.parse.urlencode(BWXsHSeaxrFTQJitARwEPUONbDKlMG)
    BWXsHSeaxrFTQJitARwEPUONbDKlMd=[('선택된 시청이력 ( %s ) 삭제'%(BWXsHSeaxrFTQJitARwEPUONbDKlvh),'RunPlugin(plugin://plugin.video.spotvm/?%s)'%(BWXsHSeaxrFTQJitARwEPUONbDKlMu))]
    BWXsHSeaxrFTQJitARwEPUONbDKlvM.add_dir(BWXsHSeaxrFTQJitARwEPUONbDKlvh,sublabel='',img=BWXsHSeaxrFTQJitARwEPUONbDKljo,infoLabels=BWXsHSeaxrFTQJitARwEPUONbDKljq,isFolder=BWXsHSeaxrFTQJitARwEPUONbDKlMo,params=BWXsHSeaxrFTQJitARwEPUONbDKljM,ContextMenu=BWXsHSeaxrFTQJitARwEPUONbDKlMd)
   BWXsHSeaxrFTQJitARwEPUONbDKljq={'plot':'시청목록을 삭제합니다.'}
   BWXsHSeaxrFTQJitARwEPUONbDKlvh='*** 시청목록 삭제 ***'
   BWXsHSeaxrFTQJitARwEPUONbDKljM={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':BWXsHSeaxrFTQJitARwEPUONbDKlmc,}
   BWXsHSeaxrFTQJitARwEPUONbDKljG=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   BWXsHSeaxrFTQJitARwEPUONbDKlvM.add_dir(BWXsHSeaxrFTQJitARwEPUONbDKlvh,sublabel='',img=BWXsHSeaxrFTQJitARwEPUONbDKljG,infoLabels=BWXsHSeaxrFTQJitARwEPUONbDKljq,isFolder=BWXsHSeaxrFTQJitARwEPUONbDKlMy,params=BWXsHSeaxrFTQJitARwEPUONbDKljM,isLink=BWXsHSeaxrFTQJitARwEPUONbDKlMo)
   xbmcplugin.endOfDirectory(BWXsHSeaxrFTQJitARwEPUONbDKlvM._addon_handle,cacheToDisc=BWXsHSeaxrFTQJitARwEPUONbDKlMy)
 def spotv_main(BWXsHSeaxrFTQJitARwEPUONbDKlvM):
  BWXsHSeaxrFTQJitARwEPUONbDKlvM.SpotvObj.KodiVersion=BWXsHSeaxrFTQJitARwEPUONbDKlMq(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  BWXsHSeaxrFTQJitARwEPUONbDKlML=BWXsHSeaxrFTQJitARwEPUONbDKlvM.main_params.get('mode',BWXsHSeaxrFTQJitARwEPUONbDKlMI)
  if BWXsHSeaxrFTQJitARwEPUONbDKlML=='LOGOUT':
   BWXsHSeaxrFTQJitARwEPUONbDKlvM.logout()
   return
  BWXsHSeaxrFTQJitARwEPUONbDKlvM.login_main()
  if BWXsHSeaxrFTQJitARwEPUONbDKlML is BWXsHSeaxrFTQJitARwEPUONbDKlMI:
   BWXsHSeaxrFTQJitARwEPUONbDKlvM.dp_Main_List()
  elif BWXsHSeaxrFTQJitARwEPUONbDKlML=='LIVE_GROUP':
   BWXsHSeaxrFTQJitARwEPUONbDKlvM.dp_LiveChannel_List(BWXsHSeaxrFTQJitARwEPUONbDKlvM.main_params)
  elif BWXsHSeaxrFTQJitARwEPUONbDKlML=='ELIVE_GROUP':
   BWXsHSeaxrFTQJitARwEPUONbDKlmu=BWXsHSeaxrFTQJitARwEPUONbDKlvM.dp_EventLiveChannel_List(BWXsHSeaxrFTQJitARwEPUONbDKlvM.main_params)
   if BWXsHSeaxrFTQJitARwEPUONbDKlmu==401:
    if os.path.isfile(BWXsHSeaxrFTQJitARwEPUONbDKlvG):os.remove(BWXsHSeaxrFTQJitARwEPUONbDKlvG)
    BWXsHSeaxrFTQJitARwEPUONbDKlvM.login_main()
    BWXsHSeaxrFTQJitARwEPUONbDKlvM.dp_EventLiveChannel_List(BWXsHSeaxrFTQJitARwEPUONbDKlvM.main_params)
  elif BWXsHSeaxrFTQJitARwEPUONbDKlML in['LIVE','GAME_VOD','POP_VOD','NOW_VOD','ELIVE']:
   BWXsHSeaxrFTQJitARwEPUONbDKlvM.play_VIDEO(BWXsHSeaxrFTQJitARwEPUONbDKlvM.main_params)
  elif BWXsHSeaxrFTQJitARwEPUONbDKlML=='VOD_GROUP':
   BWXsHSeaxrFTQJitARwEPUONbDKlvM.dp_MainLeague_List(BWXsHSeaxrFTQJitARwEPUONbDKlvM.main_params)
  elif BWXsHSeaxrFTQJitARwEPUONbDKlML=='NOW_GROUP':
   BWXsHSeaxrFTQJitARwEPUONbDKlvM.dp_NowVod_GroupList(BWXsHSeaxrFTQJitARwEPUONbDKlvM.main_params)
  elif BWXsHSeaxrFTQJitARwEPUONbDKlML=='POP_GROUP':
   BWXsHSeaxrFTQJitARwEPUONbDKlvM.dp_PopVod_GroupList(BWXsHSeaxrFTQJitARwEPUONbDKlvM.main_params)
  elif BWXsHSeaxrFTQJitARwEPUONbDKlML=='LEAGUE_GROUP':
   BWXsHSeaxrFTQJitARwEPUONbDKlvM.dp_Season_List(BWXsHSeaxrFTQJitARwEPUONbDKlvM.main_params)
  elif BWXsHSeaxrFTQJitARwEPUONbDKlML=='SEASON_GROUP':
   BWXsHSeaxrFTQJitARwEPUONbDKlvM.dp_Game_List(BWXsHSeaxrFTQJitARwEPUONbDKlvM.main_params)
  elif BWXsHSeaxrFTQJitARwEPUONbDKlML=='GAME_VOD_GROUP':
   BWXsHSeaxrFTQJitARwEPUONbDKlvM.dp_GameVod_List(BWXsHSeaxrFTQJitARwEPUONbDKlvM.main_params)
  elif BWXsHSeaxrFTQJitARwEPUONbDKlML=='WATCH':
   BWXsHSeaxrFTQJitARwEPUONbDKlvM.dp_Watch_List(BWXsHSeaxrFTQJitARwEPUONbDKlvM.main_params)
  elif BWXsHSeaxrFTQJitARwEPUONbDKlML=='MYVIEW_REMOVE':
   BWXsHSeaxrFTQJitARwEPUONbDKlvM.dp_History_Remove(BWXsHSeaxrFTQJitARwEPUONbDKlvM.main_params)
  else:
   BWXsHSeaxrFTQJitARwEPUONbDKlMI
# Created by pyminifier (https://github.com/liftoff/pyminifier)
