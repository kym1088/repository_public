__author__="NightRain"
usUPjwMxhBacOvzWdpfQTRrmoyGnJl=object
usUPjwMxhBacOvzWdpfQTRrmoyGnJI=print
usUPjwMxhBacOvzWdpfQTRrmoyGnJS=None
usUPjwMxhBacOvzWdpfQTRrmoyGnJq=False
usUPjwMxhBacOvzWdpfQTRrmoyGnJL=str
usUPjwMxhBacOvzWdpfQTRrmoyGnJD=open
usUPjwMxhBacOvzWdpfQTRrmoyGnJg=True
usUPjwMxhBacOvzWdpfQTRrmoyGnJE=int
usUPjwMxhBacOvzWdpfQTRrmoyGnJH=Exception
usUPjwMxhBacOvzWdpfQTRrmoyGnJN=len
usUPjwMxhBacOvzWdpfQTRrmoyGnJt=range
import urllib
import re
import json
import sys
import time
import requests
import datetime
import base64
import random
usUPjwMxhBacOvzWdpfQTRrmoyGnik={'stream50':1080,'stream40':720,'stream30':540}
class usUPjwMxhBacOvzWdpfQTRrmoyGniY(usUPjwMxhBacOvzWdpfQTRrmoyGnJl):
 def __init__(usUPjwMxhBacOvzWdpfQTRrmoyGnie):
  usUPjwMxhBacOvzWdpfQTRrmoyGnie.SPOTV_PMCODE ='987'
  usUPjwMxhBacOvzWdpfQTRrmoyGnie.SPOTV_PMSIZE =3
  usUPjwMxhBacOvzWdpfQTRrmoyGnie.GAMELIST_LIMIT =10
  usUPjwMxhBacOvzWdpfQTRrmoyGnie.API_DOMAIN ='https://www.spotvnow.co.kr'
  usUPjwMxhBacOvzWdpfQTRrmoyGnie.BC_DOMAIN ='https://players.brightcove.net'
  usUPjwMxhBacOvzWdpfQTRrmoyGnie.PLAYER_DOMAIN ='https://edge.api.brightcove.com'
  usUPjwMxhBacOvzWdpfQTRrmoyGnie.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36'
  usUPjwMxhBacOvzWdpfQTRrmoyGnie.DEFAULT_HEADER ={'user-agent':usUPjwMxhBacOvzWdpfQTRrmoyGnie.USER_AGENT}
  usUPjwMxhBacOvzWdpfQTRrmoyGnie.COOKIE_FILE_NAME=''
  usUPjwMxhBacOvzWdpfQTRrmoyGnie.KodiVersion =20
  usUPjwMxhBacOvzWdpfQTRrmoyGnie.SP_CONTEXTJSON_FILE1 =''
  usUPjwMxhBacOvzWdpfQTRrmoyGnie.SP_CONTEXTJSON_FILE2 =''
  usUPjwMxhBacOvzWdpfQTRrmoyGnie.ST ={}
  usUPjwMxhBacOvzWdpfQTRrmoyGnie.Init_ST_Total()
 def Init_ST_Total(usUPjwMxhBacOvzWdpfQTRrmoyGnie):
  usUPjwMxhBacOvzWdpfQTRrmoyGnie.ST={'account':{},'cookies':{},}
 def addon_log(usUPjwMxhBacOvzWdpfQTRrmoyGnie,string):
  try:
   import xbmcaddon,xbmc
   __version__=xbmcaddon.Addon().getAddonInfo('version')
   __addonid__=xbmcaddon.Addon().getAddonInfo('id')
   usUPjwMxhBacOvzWdpfQTRrmoyGniJ=string.encode('utf-8','ignore')
   usUPjwMxhBacOvzWdpfQTRrmoyGniX=xbmc.LOGINFO
   xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,usUPjwMxhBacOvzWdpfQTRrmoyGniJ),level=usUPjwMxhBacOvzWdpfQTRrmoyGniX)
  except:
   usUPjwMxhBacOvzWdpfQTRrmoyGnJI(string)
 def callRequestCookies(usUPjwMxhBacOvzWdpfQTRrmoyGnie,jobtype,usUPjwMxhBacOvzWdpfQTRrmoyGniN,payload=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,json=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,params=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,headers=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,cookies=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,redirects=usUPjwMxhBacOvzWdpfQTRrmoyGnJq):
  usUPjwMxhBacOvzWdpfQTRrmoyGniA=usUPjwMxhBacOvzWdpfQTRrmoyGnie.DEFAULT_HEADER
  if headers:usUPjwMxhBacOvzWdpfQTRrmoyGniA.update(headers)
  if jobtype=='Get':
   usUPjwMxhBacOvzWdpfQTRrmoyGnib=requests.get(usUPjwMxhBacOvzWdpfQTRrmoyGniN,params=params,headers=usUPjwMxhBacOvzWdpfQTRrmoyGniA,cookies=cookies,allow_redirects=redirects)
  else:
   usUPjwMxhBacOvzWdpfQTRrmoyGnib=requests.post(usUPjwMxhBacOvzWdpfQTRrmoyGniN,data=payload,json=json,params=params,headers=usUPjwMxhBacOvzWdpfQTRrmoyGniA,cookies=cookies,allow_redirects=redirects)
  try:
   usUPjwMxhBacOvzWdpfQTRrmoyGnie.addon_log(usUPjwMxhBacOvzWdpfQTRrmoyGnJL(usUPjwMxhBacOvzWdpfQTRrmoyGnib.status_code)+' : '+usUPjwMxhBacOvzWdpfQTRrmoyGnib.url)
  except:
   usUPjwMxhBacOvzWdpfQTRrmoyGnJS
  return usUPjwMxhBacOvzWdpfQTRrmoyGnib
 def JsonFile_Save(usUPjwMxhBacOvzWdpfQTRrmoyGnie,filename,usUPjwMxhBacOvzWdpfQTRrmoyGnil):
  if filename=='':return usUPjwMxhBacOvzWdpfQTRrmoyGnJq
  try:
   fp=usUPjwMxhBacOvzWdpfQTRrmoyGnJD(filename,'w',-1,'utf-8')
   json.dump(usUPjwMxhBacOvzWdpfQTRrmoyGnil,fp,indent=4,ensure_ascii=usUPjwMxhBacOvzWdpfQTRrmoyGnJq)
   fp.close()
  except:
   return usUPjwMxhBacOvzWdpfQTRrmoyGnJq
  return usUPjwMxhBacOvzWdpfQTRrmoyGnJg
 def JsonFile_Load(usUPjwMxhBacOvzWdpfQTRrmoyGnie,filename):
  if filename=='':return{}
  try:
   fp=usUPjwMxhBacOvzWdpfQTRrmoyGnJD(filename,'r',-1,'utf-8')
   usUPjwMxhBacOvzWdpfQTRrmoyGniS=json.load(fp)
   fp.close()
  except:
   return{}
  return usUPjwMxhBacOvzWdpfQTRrmoyGniS
 def Save_session_acount(usUPjwMxhBacOvzWdpfQTRrmoyGnie,usUPjwMxhBacOvzWdpfQTRrmoyGniq,usUPjwMxhBacOvzWdpfQTRrmoyGniL):
  usUPjwMxhBacOvzWdpfQTRrmoyGnie.ST['account']['stid'] =base64.standard_b64encode(usUPjwMxhBacOvzWdpfQTRrmoyGniq.encode()).decode('utf-8')
  usUPjwMxhBacOvzWdpfQTRrmoyGnie.ST['account']['stpw'] =base64.standard_b64encode(usUPjwMxhBacOvzWdpfQTRrmoyGniL.encode()).decode('utf-8')
 def Load_session_acount(usUPjwMxhBacOvzWdpfQTRrmoyGnie):
  try:
   usUPjwMxhBacOvzWdpfQTRrmoyGniq =base64.standard_b64decode(usUPjwMxhBacOvzWdpfQTRrmoyGnie.ST['account']['stid']).decode('utf-8')
   usUPjwMxhBacOvzWdpfQTRrmoyGniL =base64.standard_b64decode(usUPjwMxhBacOvzWdpfQTRrmoyGnie.ST['account']['stpw']).decode('utf-8')
  except:
   return '',''
  return usUPjwMxhBacOvzWdpfQTRrmoyGniq,usUPjwMxhBacOvzWdpfQTRrmoyGniL
 def makeDefaultCookies(usUPjwMxhBacOvzWdpfQTRrmoyGnie):
  usUPjwMxhBacOvzWdpfQTRrmoyGniD={'id_token':usUPjwMxhBacOvzWdpfQTRrmoyGnie.ST['cookies']['id_token'],}
  return usUPjwMxhBacOvzWdpfQTRrmoyGniD
 def makeDefaultHeaders(usUPjwMxhBacOvzWdpfQTRrmoyGnie):
  usUPjwMxhBacOvzWdpfQTRrmoyGnig={'accept':'application/json;pk={}'.format(usUPjwMxhBacOvzWdpfQTRrmoyGnie.ST['cookies']['spotv_policyKey'])}
  return usUPjwMxhBacOvzWdpfQTRrmoyGnig
 def xmlText(usUPjwMxhBacOvzWdpfQTRrmoyGnie,in_text):
  usUPjwMxhBacOvzWdpfQTRrmoyGniE=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;')
  return usUPjwMxhBacOvzWdpfQTRrmoyGniE
 def GetNoCache(usUPjwMxhBacOvzWdpfQTRrmoyGnie,timetype=1):
  if timetype==1:
   return usUPjwMxhBacOvzWdpfQTRrmoyGnJE(time.time())
  else:
   return usUPjwMxhBacOvzWdpfQTRrmoyGnJE(time.time()*1000)
 def GetCredential_new(usUPjwMxhBacOvzWdpfQTRrmoyGnie,user_id,user_pw):
  usUPjwMxhBacOvzWdpfQTRrmoyGniH=requests.session()
  try:
   usUPjwMxhBacOvzWdpfQTRrmoyGniN='https://nid.spotvnow.co.kr/api/v3/oauth2/authorize/spotvnow?return_url=https%3A%2F%2Fwww.spotvnow.co.kr%2F&err_return_url=https%3A%2F%2Fwww.spotvnow.co.kr%2Fabout&logout_url=https%3A%2F%2Fwww.spotvnow.co.kr%2Fintro'
   usUPjwMxhBacOvzWdpfQTRrmoyGnig={'Referer':'https://www.spotvnow.co.kr/login','User-Agent':usUPjwMxhBacOvzWdpfQTRrmoyGnie.USER_AGENT,}
   while(usUPjwMxhBacOvzWdpfQTRrmoyGniN not in['',usUPjwMxhBacOvzWdpfQTRrmoyGnJS]):
    usUPjwMxhBacOvzWdpfQTRrmoyGnit=usUPjwMxhBacOvzWdpfQTRrmoyGniH.get(usUPjwMxhBacOvzWdpfQTRrmoyGniN,params=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,headers=usUPjwMxhBacOvzWdpfQTRrmoyGnig,cookies=usUPjwMxhBacOvzWdpfQTRrmoyGnie.ST['cookies'],allow_redirects=usUPjwMxhBacOvzWdpfQTRrmoyGnJq)
    usUPjwMxhBacOvzWdpfQTRrmoyGniN =usUPjwMxhBacOvzWdpfQTRrmoyGnit.headers.get('location')
    for usUPjwMxhBacOvzWdpfQTRrmoyGniC in usUPjwMxhBacOvzWdpfQTRrmoyGnit.cookies:
     if usUPjwMxhBacOvzWdpfQTRrmoyGniC.value not in['',usUPjwMxhBacOvzWdpfQTRrmoyGnJS]:
      usUPjwMxhBacOvzWdpfQTRrmoyGnie.ST['cookies'][usUPjwMxhBacOvzWdpfQTRrmoyGniC.name]=usUPjwMxhBacOvzWdpfQTRrmoyGniC.value
    if usUPjwMxhBacOvzWdpfQTRrmoyGnit.status_code==200:break
   if usUPjwMxhBacOvzWdpfQTRrmoyGnie.ST['cookies']['login_challenge']=='':
    usUPjwMxhBacOvzWdpfQTRrmoyGnie.Init_ST_Total()
    return usUPjwMxhBacOvzWdpfQTRrmoyGnJq
  except usUPjwMxhBacOvzWdpfQTRrmoyGnJH as exception:
   usUPjwMxhBacOvzWdpfQTRrmoyGnJI(exception)
   usUPjwMxhBacOvzWdpfQTRrmoyGnie.Init_ST_Total()
   return usUPjwMxhBacOvzWdpfQTRrmoyGnJq
  usUPjwMxhBacOvzWdpfQTRrmoyGnie.addon_log('login : step 1') 
  try:
   usUPjwMxhBacOvzWdpfQTRrmoyGniV=base64.standard_b64encode(user_id.encode('UTF-8')).decode('utf-8')
   usUPjwMxhBacOvzWdpfQTRrmoyGniK=base64.standard_b64encode(user_pw.encode('UTF-8')).decode('utf-8')
   usUPjwMxhBacOvzWdpfQTRrmoyGniN='https://nid.spotvnow.co.kr/api/v3/user-auth/login'
   usUPjwMxhBacOvzWdpfQTRrmoyGnig={'User-Agent':usUPjwMxhBacOvzWdpfQTRrmoyGnie.USER_AGENT,'Referer':'https://www.spotvnow.co.kr/',}
   usUPjwMxhBacOvzWdpfQTRrmoyGniF={'username':usUPjwMxhBacOvzWdpfQTRrmoyGniV,'password':usUPjwMxhBacOvzWdpfQTRrmoyGniK,'remember':usUPjwMxhBacOvzWdpfQTRrmoyGnJq,'err_return_url':'https://www.spotvnow.co.kr/intro',}
   usUPjwMxhBacOvzWdpfQTRrmoyGnit=usUPjwMxhBacOvzWdpfQTRrmoyGniH.post(usUPjwMxhBacOvzWdpfQTRrmoyGniN,data=usUPjwMxhBacOvzWdpfQTRrmoyGniF,params=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,headers=usUPjwMxhBacOvzWdpfQTRrmoyGnig,cookies=usUPjwMxhBacOvzWdpfQTRrmoyGnie.ST['cookies'],allow_redirects=usUPjwMxhBacOvzWdpfQTRrmoyGnJq)
   for usUPjwMxhBacOvzWdpfQTRrmoyGniC in usUPjwMxhBacOvzWdpfQTRrmoyGnit.cookies:
    if usUPjwMxhBacOvzWdpfQTRrmoyGniC.value not in['',usUPjwMxhBacOvzWdpfQTRrmoyGnJS]:
     usUPjwMxhBacOvzWdpfQTRrmoyGnie.ST['cookies'][usUPjwMxhBacOvzWdpfQTRrmoyGniC.name]=usUPjwMxhBacOvzWdpfQTRrmoyGniC.value
   usUPjwMxhBacOvzWdpfQTRrmoyGniN=usUPjwMxhBacOvzWdpfQTRrmoyGnit.headers.get('location')
   while(usUPjwMxhBacOvzWdpfQTRrmoyGniN not in['',usUPjwMxhBacOvzWdpfQTRrmoyGnJS]):
    usUPjwMxhBacOvzWdpfQTRrmoyGnit=usUPjwMxhBacOvzWdpfQTRrmoyGniH.get(usUPjwMxhBacOvzWdpfQTRrmoyGniN,params=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,headers=usUPjwMxhBacOvzWdpfQTRrmoyGnig,cookies=usUPjwMxhBacOvzWdpfQTRrmoyGnie.ST['cookies'],allow_redirects=usUPjwMxhBacOvzWdpfQTRrmoyGnJq)
    usUPjwMxhBacOvzWdpfQTRrmoyGniN =usUPjwMxhBacOvzWdpfQTRrmoyGnit.headers.get('location')
    for usUPjwMxhBacOvzWdpfQTRrmoyGniC in usUPjwMxhBacOvzWdpfQTRrmoyGnit.cookies:
     if usUPjwMxhBacOvzWdpfQTRrmoyGniC.value not in['',usUPjwMxhBacOvzWdpfQTRrmoyGnJS]:
      usUPjwMxhBacOvzWdpfQTRrmoyGnie.ST['cookies'][usUPjwMxhBacOvzWdpfQTRrmoyGniC.name]=usUPjwMxhBacOvzWdpfQTRrmoyGniC.value
    if usUPjwMxhBacOvzWdpfQTRrmoyGnit.status_code==200:break
   if usUPjwMxhBacOvzWdpfQTRrmoyGnie.ST['cookies']['id_token']=='':
    usUPjwMxhBacOvzWdpfQTRrmoyGnie.Init_ST_Total()
    return usUPjwMxhBacOvzWdpfQTRrmoyGnJq
  except usUPjwMxhBacOvzWdpfQTRrmoyGnJH as exception:
   usUPjwMxhBacOvzWdpfQTRrmoyGnJI(exception)
   usUPjwMxhBacOvzWdpfQTRrmoyGnie.Init_ST_Total()
   return usUPjwMxhBacOvzWdpfQTRrmoyGnJq
  usUPjwMxhBacOvzWdpfQTRrmoyGnie.addon_log('login : step 2')
  try:
   usUPjwMxhBacOvzWdpfQTRrmoyGniN=usUPjwMxhBacOvzWdpfQTRrmoyGnie.API_DOMAIN+'/api/v3/session' 
   usUPjwMxhBacOvzWdpfQTRrmoyGniD=usUPjwMxhBacOvzWdpfQTRrmoyGnie.makeDefaultCookies()
   usUPjwMxhBacOvzWdpfQTRrmoyGnit=usUPjwMxhBacOvzWdpfQTRrmoyGnie.callRequestCookies('Get',usUPjwMxhBacOvzWdpfQTRrmoyGniN,params=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,headers=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,cookies=usUPjwMxhBacOvzWdpfQTRrmoyGniD)
   usUPjwMxhBacOvzWdpfQTRrmoyGnYi=json.loads(usUPjwMxhBacOvzWdpfQTRrmoyGnit.text)
   usUPjwMxhBacOvzWdpfQTRrmoyGnie.ST['cookies']['spotv_sessionid']=usUPjwMxhBacOvzWdpfQTRrmoyGnYi.get('userId') 
   usUPjwMxhBacOvzWdpfQTRrmoyGnYk=usUPjwMxhBacOvzWdpfQTRrmoyGnie.SPOTV_PMCODE+usUPjwMxhBacOvzWdpfQTRrmoyGnJL(usUPjwMxhBacOvzWdpfQTRrmoyGnYi['subEndTime'])
   usUPjwMxhBacOvzWdpfQTRrmoyGnie.ST['cookies']['spotv_subend'] =base64.standard_b64encode(usUPjwMxhBacOvzWdpfQTRrmoyGnYk.encode()).decode('utf-8')
  except usUPjwMxhBacOvzWdpfQTRrmoyGnJH as exception:
   usUPjwMxhBacOvzWdpfQTRrmoyGnJI(exception)
   usUPjwMxhBacOvzWdpfQTRrmoyGnie.Init_ST_Total()
   return usUPjwMxhBacOvzWdpfQTRrmoyGnJq
  usUPjwMxhBacOvzWdpfQTRrmoyGnie.addon_log('login : step 3')
  try:
   if usUPjwMxhBacOvzWdpfQTRrmoyGnYi['subEndTime']in[0,'0',usUPjwMxhBacOvzWdpfQTRrmoyGnJS]:
    usUPjwMxhBacOvzWdpfQTRrmoyGniN=usUPjwMxhBacOvzWdpfQTRrmoyGnie.API_DOMAIN+'/api/v3/user/sub/scope' 
    usUPjwMxhBacOvzWdpfQTRrmoyGniD=usUPjwMxhBacOvzWdpfQTRrmoyGnie.makeDefaultCookies()
    usUPjwMxhBacOvzWdpfQTRrmoyGnit=usUPjwMxhBacOvzWdpfQTRrmoyGnie.callRequestCookies('Get',usUPjwMxhBacOvzWdpfQTRrmoyGniN,params=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,headers=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,cookies=usUPjwMxhBacOvzWdpfQTRrmoyGniD)
    usUPjwMxhBacOvzWdpfQTRrmoyGnYi=json.loads(usUPjwMxhBacOvzWdpfQTRrmoyGnit.text)
    if usUPjwMxhBacOvzWdpfQTRrmoyGnYi.get('endDate')==usUPjwMxhBacOvzWdpfQTRrmoyGnJS:
     usUPjwMxhBacOvzWdpfQTRrmoyGnYk=usUPjwMxhBacOvzWdpfQTRrmoyGnie.SPOTV_PMCODE+'0'
     usUPjwMxhBacOvzWdpfQTRrmoyGnie.ST['cookies']['spotv_subend'] =base64.standard_b64encode(usUPjwMxhBacOvzWdpfQTRrmoyGnYk.encode()).decode('utf-8')
    else:
     usUPjwMxhBacOvzWdpfQTRrmoyGnYe=datetime.datetime.strptime(usUPjwMxhBacOvzWdpfQTRrmoyGnYi.get('endDate'),'%Y-%m-%d %H:%M:%S')
     usUPjwMxhBacOvzWdpfQTRrmoyGnYk=usUPjwMxhBacOvzWdpfQTRrmoyGnJE(time.mktime(usUPjwMxhBacOvzWdpfQTRrmoyGnYe.timetuple()))
     usUPjwMxhBacOvzWdpfQTRrmoyGnYk=usUPjwMxhBacOvzWdpfQTRrmoyGnie.SPOTV_PMCODE+usUPjwMxhBacOvzWdpfQTRrmoyGnJL(usUPjwMxhBacOvzWdpfQTRrmoyGnYk)+'000'
     usUPjwMxhBacOvzWdpfQTRrmoyGnie.ST['cookies']['spotv_subend'] =base64.standard_b64encode(usUPjwMxhBacOvzWdpfQTRrmoyGnYk.encode()).decode('utf-8')
  except usUPjwMxhBacOvzWdpfQTRrmoyGnJH as exception:
   usUPjwMxhBacOvzWdpfQTRrmoyGnJI(exception)
   usUPjwMxhBacOvzWdpfQTRrmoyGnie.Init_ST_Total()
   return usUPjwMxhBacOvzWdpfQTRrmoyGnJq
  usUPjwMxhBacOvzWdpfQTRrmoyGnie.addon_log('login : step 4')
  if usUPjwMxhBacOvzWdpfQTRrmoyGnie.GetPolicyKey()==usUPjwMxhBacOvzWdpfQTRrmoyGnJq:
   usUPjwMxhBacOvzWdpfQTRrmoyGnie.Init_ST_Total()
   return usUPjwMxhBacOvzWdpfQTRrmoyGnJq
  '''
  https://cdn.spotvnow.co.kr/dist/js/6ca348bfe80d471db7ef.js
    bc: {accountId: "5764318566001", policyKey: "BCpkADawqM0U3mi_PT566m5lvtapzMq3Uy7ICGGjGB6v4Ske7ZX_ynzj8ePedQJhH36nym_5mbvSYeyyHOOdUsZovyg2XlhV6rRspyYPw_USVNLaR0fB_AAL2HSQlfuetIPiEzbUs1tpNF9NtQxt3BAPvXdOAsvy1ltLPWMVzJHiw9slpLRgI2NUufc" }  
  '''  
  usUPjwMxhBacOvzWdpfQTRrmoyGnie.addon_log('login : step 5')
  return usUPjwMxhBacOvzWdpfQTRrmoyGnJg
 def GetPolicyKey(usUPjwMxhBacOvzWdpfQTRrmoyGnie):
  try:
   usUPjwMxhBacOvzWdpfQTRrmoyGniN=usUPjwMxhBacOvzWdpfQTRrmoyGnie.GetMainJspath()
   if usUPjwMxhBacOvzWdpfQTRrmoyGniN=='':return usUPjwMxhBacOvzWdpfQTRrmoyGnJq
   usUPjwMxhBacOvzWdpfQTRrmoyGnit=usUPjwMxhBacOvzWdpfQTRrmoyGnie.callRequestCookies('Get',usUPjwMxhBacOvzWdpfQTRrmoyGniN,payload=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,params=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,headers=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,cookies=usUPjwMxhBacOvzWdpfQTRrmoyGnJS)
   usUPjwMxhBacOvzWdpfQTRrmoyGnYJ=usUPjwMxhBacOvzWdpfQTRrmoyGnit.text
   usUPjwMxhBacOvzWdpfQTRrmoyGnYX =re.findall('accountId:\s*\"\d{13}\",\s*policyKey:\s*\".[^(){}]{100,300}\"',usUPjwMxhBacOvzWdpfQTRrmoyGnYJ)[0]
   usUPjwMxhBacOvzWdpfQTRrmoyGnYX =usUPjwMxhBacOvzWdpfQTRrmoyGnYX.replace('accountId','"accountId"')
   usUPjwMxhBacOvzWdpfQTRrmoyGnYX =usUPjwMxhBacOvzWdpfQTRrmoyGnYX.replace('policyKey','"policyKey"')
   usUPjwMxhBacOvzWdpfQTRrmoyGnYX ='{'+usUPjwMxhBacOvzWdpfQTRrmoyGnYX+'}'
   usUPjwMxhBacOvzWdpfQTRrmoyGnYA=json.loads(usUPjwMxhBacOvzWdpfQTRrmoyGnYX)
   usUPjwMxhBacOvzWdpfQTRrmoyGnie.ST['cookies']['spotv_accountId']=usUPjwMxhBacOvzWdpfQTRrmoyGnYA['accountId']
   usUPjwMxhBacOvzWdpfQTRrmoyGnie.ST['cookies']['spotv_policyKey']=usUPjwMxhBacOvzWdpfQTRrmoyGnYA['policyKey']
  except usUPjwMxhBacOvzWdpfQTRrmoyGnJH as exception:
   usUPjwMxhBacOvzWdpfQTRrmoyGnJI(exception)
   return usUPjwMxhBacOvzWdpfQTRrmoyGnJq
  return usUPjwMxhBacOvzWdpfQTRrmoyGnJg
 def GetMainJspath(usUPjwMxhBacOvzWdpfQTRrmoyGnie):
  usUPjwMxhBacOvzWdpfQTRrmoyGnYb=''
  try:
   usUPjwMxhBacOvzWdpfQTRrmoyGniN=usUPjwMxhBacOvzWdpfQTRrmoyGnie.API_DOMAIN
   usUPjwMxhBacOvzWdpfQTRrmoyGnit=usUPjwMxhBacOvzWdpfQTRrmoyGnie.callRequestCookies('Get',usUPjwMxhBacOvzWdpfQTRrmoyGniN,payload=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,params=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,headers=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,cookies=usUPjwMxhBacOvzWdpfQTRrmoyGnJS)
   usUPjwMxhBacOvzWdpfQTRrmoyGnYJ=usUPjwMxhBacOvzWdpfQTRrmoyGnit.text
   usUPjwMxhBacOvzWdpfQTRrmoyGnYX =re.findall('https://cdn.spotvnow.co.kr/dist/js/.{20}\.js',usUPjwMxhBacOvzWdpfQTRrmoyGnYJ)[0]
   usUPjwMxhBacOvzWdpfQTRrmoyGnYb=usUPjwMxhBacOvzWdpfQTRrmoyGnYX
  except usUPjwMxhBacOvzWdpfQTRrmoyGnJH as exception:
   usUPjwMxhBacOvzWdpfQTRrmoyGnJI(exception)
  return usUPjwMxhBacOvzWdpfQTRrmoyGnYb
 def Get_Now_Datetime(usUPjwMxhBacOvzWdpfQTRrmoyGnie):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetLiveChannelList(usUPjwMxhBacOvzWdpfQTRrmoyGnie):
  usUPjwMxhBacOvzWdpfQTRrmoyGnYI=[]
  usUPjwMxhBacOvzWdpfQTRrmoyGnYS ={}
  try:
   usUPjwMxhBacOvzWdpfQTRrmoyGniN=usUPjwMxhBacOvzWdpfQTRrmoyGnie.API_DOMAIN+'/api/v3/channel'
   usUPjwMxhBacOvzWdpfQTRrmoyGnit=usUPjwMxhBacOvzWdpfQTRrmoyGnie.callRequestCookies('Get',usUPjwMxhBacOvzWdpfQTRrmoyGniN,payload=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,params=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,headers=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,cookies=usUPjwMxhBacOvzWdpfQTRrmoyGnJS)
   usUPjwMxhBacOvzWdpfQTRrmoyGnYq=json.loads(usUPjwMxhBacOvzWdpfQTRrmoyGnit.text)
   usUPjwMxhBacOvzWdpfQTRrmoyGnYS=usUPjwMxhBacOvzWdpfQTRrmoyGnie.GetEPGList()
   for usUPjwMxhBacOvzWdpfQTRrmoyGnYL in usUPjwMxhBacOvzWdpfQTRrmoyGnYq:
    usUPjwMxhBacOvzWdpfQTRrmoyGnYD={'id':usUPjwMxhBacOvzWdpfQTRrmoyGnYL['id'],'name':usUPjwMxhBacOvzWdpfQTRrmoyGnYL['name'],'logo':usUPjwMxhBacOvzWdpfQTRrmoyGnYL['logo'],'free':usUPjwMxhBacOvzWdpfQTRrmoyGnYL['free'],'programName':usUPjwMxhBacOvzWdpfQTRrmoyGnYL['programName'],'channelepg':usUPjwMxhBacOvzWdpfQTRrmoyGnYS.get(usUPjwMxhBacOvzWdpfQTRrmoyGnYL['id']),}
    usUPjwMxhBacOvzWdpfQTRrmoyGnYI.append(usUPjwMxhBacOvzWdpfQTRrmoyGnYD)
  except usUPjwMxhBacOvzWdpfQTRrmoyGnJH as exception:
   usUPjwMxhBacOvzWdpfQTRrmoyGnJI(exception)
  return usUPjwMxhBacOvzWdpfQTRrmoyGnYI
 def GetHlsUrl(usUPjwMxhBacOvzWdpfQTRrmoyGnie,mediacode):
  usUPjwMxhBacOvzWdpfQTRrmoyGnYg=''
  try:
   usUPjwMxhBacOvzWdpfQTRrmoyGniN='{}/api/v3/channel/di/con/sec/web/{}'.format(usUPjwMxhBacOvzWdpfQTRrmoyGnie.API_DOMAIN,mediacode)
   usUPjwMxhBacOvzWdpfQTRrmoyGnit=usUPjwMxhBacOvzWdpfQTRrmoyGnie.callRequestCookies('Get',usUPjwMxhBacOvzWdpfQTRrmoyGniN,payload=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,params=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,headers=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,cookies=usUPjwMxhBacOvzWdpfQTRrmoyGnJS)
   usUPjwMxhBacOvzWdpfQTRrmoyGnYi=json.loads(usUPjwMxhBacOvzWdpfQTRrmoyGnit.text)
   usUPjwMxhBacOvzWdpfQTRrmoyGnYg=usUPjwMxhBacOvzWdpfQTRrmoyGnYi['hlsDrmUrl']
   usUPjwMxhBacOvzWdpfQTRrmoyGnYE =usUPjwMxhBacOvzWdpfQTRrmoyGnYi['cid']
  except usUPjwMxhBacOvzWdpfQTRrmoyGnJH as exception:
   usUPjwMxhBacOvzWdpfQTRrmoyGnJI(exception)
  return usUPjwMxhBacOvzWdpfQTRrmoyGnYE,usUPjwMxhBacOvzWdpfQTRrmoyGnYg
 def GetEPGList(usUPjwMxhBacOvzWdpfQTRrmoyGnie):
  usUPjwMxhBacOvzWdpfQTRrmoyGnYH={}
  usUPjwMxhBacOvzWdpfQTRrmoyGnYN=usUPjwMxhBacOvzWdpfQTRrmoyGnie.Get_Now_Datetime()
  usUPjwMxhBacOvzWdpfQTRrmoyGnYt=usUPjwMxhBacOvzWdpfQTRrmoyGnYN.strftime('%Y%m%d%H%M')
  usUPjwMxhBacOvzWdpfQTRrmoyGnYC='%s-%s-%s'%(usUPjwMxhBacOvzWdpfQTRrmoyGnYt[0:4],usUPjwMxhBacOvzWdpfQTRrmoyGnYt[4:6],usUPjwMxhBacOvzWdpfQTRrmoyGnYt[6:8])
  usUPjwMxhBacOvzWdpfQTRrmoyGnYV=(usUPjwMxhBacOvzWdpfQTRrmoyGnYN+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M')
  try:
   usUPjwMxhBacOvzWdpfQTRrmoyGniN=usUPjwMxhBacOvzWdpfQTRrmoyGnie.API_DOMAIN+'/api/v3/program/'+usUPjwMxhBacOvzWdpfQTRrmoyGnYC
   usUPjwMxhBacOvzWdpfQTRrmoyGnit=usUPjwMxhBacOvzWdpfQTRrmoyGnie.callRequestCookies('Get',usUPjwMxhBacOvzWdpfQTRrmoyGniN,payload=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,params=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,headers=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,cookies=usUPjwMxhBacOvzWdpfQTRrmoyGnJS)
   usUPjwMxhBacOvzWdpfQTRrmoyGnYq=json.loads(usUPjwMxhBacOvzWdpfQTRrmoyGnit.text)
   usUPjwMxhBacOvzWdpfQTRrmoyGnYK=-1 
   usUPjwMxhBacOvzWdpfQTRrmoyGnYF =''
   for usUPjwMxhBacOvzWdpfQTRrmoyGnYL in usUPjwMxhBacOvzWdpfQTRrmoyGnYq:
    usUPjwMxhBacOvzWdpfQTRrmoyGnki=usUPjwMxhBacOvzWdpfQTRrmoyGnYL['channelId']
    usUPjwMxhBacOvzWdpfQTRrmoyGnkY =usUPjwMxhBacOvzWdpfQTRrmoyGnYL['startTime'].replace('-','').replace(' ','').replace(':','')
    usUPjwMxhBacOvzWdpfQTRrmoyGnke =usUPjwMxhBacOvzWdpfQTRrmoyGnYL['endTime'].replace('-','').replace(' ','').replace(':','')
    if usUPjwMxhBacOvzWdpfQTRrmoyGnJE(usUPjwMxhBacOvzWdpfQTRrmoyGnYt)>usUPjwMxhBacOvzWdpfQTRrmoyGnJE(usUPjwMxhBacOvzWdpfQTRrmoyGnke) :continue
    if usUPjwMxhBacOvzWdpfQTRrmoyGnJE(usUPjwMxhBacOvzWdpfQTRrmoyGnYV)<usUPjwMxhBacOvzWdpfQTRrmoyGnJE(usUPjwMxhBacOvzWdpfQTRrmoyGnkY):continue
    if usUPjwMxhBacOvzWdpfQTRrmoyGnYK!=usUPjwMxhBacOvzWdpfQTRrmoyGnki:
     if usUPjwMxhBacOvzWdpfQTRrmoyGnYF!='':usUPjwMxhBacOvzWdpfQTRrmoyGnYH[usUPjwMxhBacOvzWdpfQTRrmoyGnYK]=usUPjwMxhBacOvzWdpfQTRrmoyGnYF
     usUPjwMxhBacOvzWdpfQTRrmoyGnYK=usUPjwMxhBacOvzWdpfQTRrmoyGnki
     usUPjwMxhBacOvzWdpfQTRrmoyGnYF =''
    if usUPjwMxhBacOvzWdpfQTRrmoyGnYF:usUPjwMxhBacOvzWdpfQTRrmoyGnYF+='\n'
    usUPjwMxhBacOvzWdpfQTRrmoyGnYF+=usUPjwMxhBacOvzWdpfQTRrmoyGnYL['title']+'\n'
    usUPjwMxhBacOvzWdpfQTRrmoyGnYF+=' [%s ~ %s]'%(usUPjwMxhBacOvzWdpfQTRrmoyGnYL['startTime'][-5:],usUPjwMxhBacOvzWdpfQTRrmoyGnYL['endTime'][-5:])+'\n'
   if usUPjwMxhBacOvzWdpfQTRrmoyGnYF:usUPjwMxhBacOvzWdpfQTRrmoyGnYH[usUPjwMxhBacOvzWdpfQTRrmoyGnYK]=usUPjwMxhBacOvzWdpfQTRrmoyGnYF
  except usUPjwMxhBacOvzWdpfQTRrmoyGnJH as exception:
   usUPjwMxhBacOvzWdpfQTRrmoyGnJI(exception)
  return usUPjwMxhBacOvzWdpfQTRrmoyGnYH
 def GetEPGList_new(usUPjwMxhBacOvzWdpfQTRrmoyGnie):
  usUPjwMxhBacOvzWdpfQTRrmoyGnYH={}
  usUPjwMxhBacOvzWdpfQTRrmoyGnYN=usUPjwMxhBacOvzWdpfQTRrmoyGnie.Get_Now_Datetime()
  usUPjwMxhBacOvzWdpfQTRrmoyGnYt=usUPjwMxhBacOvzWdpfQTRrmoyGnYN.strftime('%Y%m%d%H%M00')
  usUPjwMxhBacOvzWdpfQTRrmoyGnYC='%s%s%s'%(usUPjwMxhBacOvzWdpfQTRrmoyGnYt[0:4],usUPjwMxhBacOvzWdpfQTRrmoyGnYt[4:6],usUPjwMxhBacOvzWdpfQTRrmoyGnYt[6:8])
  usUPjwMxhBacOvzWdpfQTRrmoyGnYV=(usUPjwMxhBacOvzWdpfQTRrmoyGnYN+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M00')
  try:
   for usUPjwMxhBacOvzWdpfQTRrmoyGnYL in LIVETV_LIST:
    usUPjwMxhBacOvzWdpfQTRrmoyGnkJ =usUPjwMxhBacOvzWdpfQTRrmoyGnYL['videoId']
    if usUPjwMxhBacOvzWdpfQTRrmoyGnYL['epgtype']=='spotvon':
     usUPjwMxhBacOvzWdpfQTRrmoyGnYF=usUPjwMxhBacOvzWdpfQTRrmoyGnie.Get_EpgInfo_Spotv_spotvon(usUPjwMxhBacOvzWdpfQTRrmoyGnkJ,usUPjwMxhBacOvzWdpfQTRrmoyGnYL['epgnm'],usUPjwMxhBacOvzWdpfQTRrmoyGnYC)
     usUPjwMxhBacOvzWdpfQTRrmoyGnYH[usUPjwMxhBacOvzWdpfQTRrmoyGnkJ]=usUPjwMxhBacOvzWdpfQTRrmoyGnYF
    if usUPjwMxhBacOvzWdpfQTRrmoyGnYL['epgtype']=='spotvnet':
     usUPjwMxhBacOvzWdpfQTRrmoyGnYF=usUPjwMxhBacOvzWdpfQTRrmoyGnie.Get_EpgInfo_Spotv_spotvnet(usUPjwMxhBacOvzWdpfQTRrmoyGnkJ,usUPjwMxhBacOvzWdpfQTRrmoyGnYL['epgnm'],usUPjwMxhBacOvzWdpfQTRrmoyGnYC)
     usUPjwMxhBacOvzWdpfQTRrmoyGnYH[usUPjwMxhBacOvzWdpfQTRrmoyGnkJ]=usUPjwMxhBacOvzWdpfQTRrmoyGnYF
   for usUPjwMxhBacOvzWdpfQTRrmoyGnkX in usUPjwMxhBacOvzWdpfQTRrmoyGnYH.keys():
    if usUPjwMxhBacOvzWdpfQTRrmoyGnJN(usUPjwMxhBacOvzWdpfQTRrmoyGnYH.get(usUPjwMxhBacOvzWdpfQTRrmoyGnkX))==0:continue
    usUPjwMxhBacOvzWdpfQTRrmoyGnYF =''
    usUPjwMxhBacOvzWdpfQTRrmoyGnkA=''
    for usUPjwMxhBacOvzWdpfQTRrmoyGnkb in usUPjwMxhBacOvzWdpfQTRrmoyGnYH.get(usUPjwMxhBacOvzWdpfQTRrmoyGnkX):
     usUPjwMxhBacOvzWdpfQTRrmoyGnkY =usUPjwMxhBacOvzWdpfQTRrmoyGnkb['startTime']
     usUPjwMxhBacOvzWdpfQTRrmoyGnke =usUPjwMxhBacOvzWdpfQTRrmoyGnkb['endTime']
     if usUPjwMxhBacOvzWdpfQTRrmoyGnJE(usUPjwMxhBacOvzWdpfQTRrmoyGnYt)>usUPjwMxhBacOvzWdpfQTRrmoyGnJE(usUPjwMxhBacOvzWdpfQTRrmoyGnke) :continue
     if usUPjwMxhBacOvzWdpfQTRrmoyGnJE(usUPjwMxhBacOvzWdpfQTRrmoyGnYV)<usUPjwMxhBacOvzWdpfQTRrmoyGnJE(usUPjwMxhBacOvzWdpfQTRrmoyGnkY):continue
     if usUPjwMxhBacOvzWdpfQTRrmoyGnJE(usUPjwMxhBacOvzWdpfQTRrmoyGnYt)>=usUPjwMxhBacOvzWdpfQTRrmoyGnJE(usUPjwMxhBacOvzWdpfQTRrmoyGnkY)and usUPjwMxhBacOvzWdpfQTRrmoyGnJE(usUPjwMxhBacOvzWdpfQTRrmoyGnYt)<usUPjwMxhBacOvzWdpfQTRrmoyGnJE(usUPjwMxhBacOvzWdpfQTRrmoyGnke):usUPjwMxhBacOvzWdpfQTRrmoyGnkA=usUPjwMxhBacOvzWdpfQTRrmoyGnie.xmlText(usUPjwMxhBacOvzWdpfQTRrmoyGnkb['title'])
     if usUPjwMxhBacOvzWdpfQTRrmoyGnYF:usUPjwMxhBacOvzWdpfQTRrmoyGnYF+='\n'
     usUPjwMxhBacOvzWdpfQTRrmoyGnYF+=usUPjwMxhBacOvzWdpfQTRrmoyGnie.xmlText(usUPjwMxhBacOvzWdpfQTRrmoyGnkb['title'])+'\n'
     usUPjwMxhBacOvzWdpfQTRrmoyGnYF+=' [%s:%s ~ %s:%s]'%(usUPjwMxhBacOvzWdpfQTRrmoyGnkb['startTime'][8:10],usUPjwMxhBacOvzWdpfQTRrmoyGnkb['startTime'][10:12],usUPjwMxhBacOvzWdpfQTRrmoyGnkb['endTime'][8:10],usUPjwMxhBacOvzWdpfQTRrmoyGnkb['endTime'][10:12])+'\n'
    usUPjwMxhBacOvzWdpfQTRrmoyGnYH[usUPjwMxhBacOvzWdpfQTRrmoyGnkX]={'epg':usUPjwMxhBacOvzWdpfQTRrmoyGnYF,'title':usUPjwMxhBacOvzWdpfQTRrmoyGnkA}
  except usUPjwMxhBacOvzWdpfQTRrmoyGnJH as exception:
   usUPjwMxhBacOvzWdpfQTRrmoyGnJI(exception)
  return usUPjwMxhBacOvzWdpfQTRrmoyGnYH
 def Get_EpgInfo_Spotv_spotvon(usUPjwMxhBacOvzWdpfQTRrmoyGnie,usUPjwMxhBacOvzWdpfQTRrmoyGnkJ,epgnm,now_day):
  usUPjwMxhBacOvzWdpfQTRrmoyGnYH =[]
  try:
   usUPjwMxhBacOvzWdpfQTRrmoyGniN='https://www.spotvon.co.kr/data/onAir/%s/Daily/D%s.asp'%(epgnm,now_day)
   usUPjwMxhBacOvzWdpfQTRrmoyGnit=usUPjwMxhBacOvzWdpfQTRrmoyGnie.callRequestCookies('Get',usUPjwMxhBacOvzWdpfQTRrmoyGniN,payload=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,params=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,headers=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,cookies=usUPjwMxhBacOvzWdpfQTRrmoyGnJS)
   usUPjwMxhBacOvzWdpfQTRrmoyGnYi=json.loads(usUPjwMxhBacOvzWdpfQTRrmoyGnit.text)
   for usUPjwMxhBacOvzWdpfQTRrmoyGnYL in usUPjwMxhBacOvzWdpfQTRrmoyGnYi:
    usUPjwMxhBacOvzWdpfQTRrmoyGnYD={'title':usUPjwMxhBacOvzWdpfQTRrmoyGnYL['title'],'startTime':usUPjwMxhBacOvzWdpfQTRrmoyGnYL['sch_date'].replace('-','')+usUPjwMxhBacOvzWdpfQTRrmoyGnJL(usUPjwMxhBacOvzWdpfQTRrmoyGnYL['sch_hour']).zfill(2)+usUPjwMxhBacOvzWdpfQTRrmoyGnYL['sch_min']+'00'}
    usUPjwMxhBacOvzWdpfQTRrmoyGnYH.append(usUPjwMxhBacOvzWdpfQTRrmoyGnYD)
   for i in usUPjwMxhBacOvzWdpfQTRrmoyGnJt(usUPjwMxhBacOvzWdpfQTRrmoyGnJN(usUPjwMxhBacOvzWdpfQTRrmoyGnYH)):
    if i>0:usUPjwMxhBacOvzWdpfQTRrmoyGnYH[i-1]['endTime']=usUPjwMxhBacOvzWdpfQTRrmoyGnYH[i]['startTime']
    if i==usUPjwMxhBacOvzWdpfQTRrmoyGnJN(usUPjwMxhBacOvzWdpfQTRrmoyGnYH)-1: usUPjwMxhBacOvzWdpfQTRrmoyGnYH[i]['endTime']=now_day+'240000'
  except usUPjwMxhBacOvzWdpfQTRrmoyGnJH as exception:
   usUPjwMxhBacOvzWdpfQTRrmoyGnJI(exception)
   return[]
  return usUPjwMxhBacOvzWdpfQTRrmoyGnYH
 def Get_EpgInfo_Spotv_spotvnet(usUPjwMxhBacOvzWdpfQTRrmoyGnie,usUPjwMxhBacOvzWdpfQTRrmoyGnkJ,epgnm,now_day):
  usUPjwMxhBacOvzWdpfQTRrmoyGnYH =[]
  try:
   usUPjwMxhBacOvzWdpfQTRrmoyGniN='https://www.spotv.net/data/json/schedule/%s/Daily/D%s.json'%(epgnm,now_day)
   usUPjwMxhBacOvzWdpfQTRrmoyGnit=usUPjwMxhBacOvzWdpfQTRrmoyGnie.callRequestCookies('Get',usUPjwMxhBacOvzWdpfQTRrmoyGniN,payload=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,params=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,headers=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,cookies=usUPjwMxhBacOvzWdpfQTRrmoyGnJS)
   usUPjwMxhBacOvzWdpfQTRrmoyGnYi=json.loads(usUPjwMxhBacOvzWdpfQTRrmoyGnit.text)
   for usUPjwMxhBacOvzWdpfQTRrmoyGnYL in usUPjwMxhBacOvzWdpfQTRrmoyGnYi:
    usUPjwMxhBacOvzWdpfQTRrmoyGnYD={'title':usUPjwMxhBacOvzWdpfQTRrmoyGnYL['title'],'startTime':usUPjwMxhBacOvzWdpfQTRrmoyGnYL['sch_date'].replace('-','')+usUPjwMxhBacOvzWdpfQTRrmoyGnJL(usUPjwMxhBacOvzWdpfQTRrmoyGnYL['sch_hour']).zfill(2)+usUPjwMxhBacOvzWdpfQTRrmoyGnYL['sch_min']+'00'}
    usUPjwMxhBacOvzWdpfQTRrmoyGnYH.append(usUPjwMxhBacOvzWdpfQTRrmoyGnYD)
   for i in usUPjwMxhBacOvzWdpfQTRrmoyGnJt(usUPjwMxhBacOvzWdpfQTRrmoyGnJN(usUPjwMxhBacOvzWdpfQTRrmoyGnYH)):
    if i>0:usUPjwMxhBacOvzWdpfQTRrmoyGnYH[i-1]['endTime']=usUPjwMxhBacOvzWdpfQTRrmoyGnYH[i]['startTime']
    if i==usUPjwMxhBacOvzWdpfQTRrmoyGnJN(usUPjwMxhBacOvzWdpfQTRrmoyGnYH)-1: usUPjwMxhBacOvzWdpfQTRrmoyGnYH[i]['endTime']=now_day+'240000'
  except usUPjwMxhBacOvzWdpfQTRrmoyGnJH as exception:
   usUPjwMxhBacOvzWdpfQTRrmoyGnJI(exception)
   return[]
  return usUPjwMxhBacOvzWdpfQTRrmoyGnYH
 def GetEventLiveList(usUPjwMxhBacOvzWdpfQTRrmoyGnie):
  usUPjwMxhBacOvzWdpfQTRrmoyGnYI=[]
  usUPjwMxhBacOvzWdpfQTRrmoyGnkl =0
  try:
   usUPjwMxhBacOvzWdpfQTRrmoyGnkI=usUPjwMxhBacOvzWdpfQTRrmoyGnie.Get_Now_Datetime()
   usUPjwMxhBacOvzWdpfQTRrmoyGnkS=usUPjwMxhBacOvzWdpfQTRrmoyGnkI.strftime('%Y-%m-%d')
  except usUPjwMxhBacOvzWdpfQTRrmoyGnJH as exception:
   usUPjwMxhBacOvzWdpfQTRrmoyGnJI(exception)
   return usUPjwMxhBacOvzWdpfQTRrmoyGnYI,usUPjwMxhBacOvzWdpfQTRrmoyGnkl
  usUPjwMxhBacOvzWdpfQTRrmoyGniN=usUPjwMxhBacOvzWdpfQTRrmoyGnie.API_DOMAIN+'/api/v3/player/lives/'+usUPjwMxhBacOvzWdpfQTRrmoyGnkS 
  usUPjwMxhBacOvzWdpfQTRrmoyGniD=usUPjwMxhBacOvzWdpfQTRrmoyGnie.makeDefaultCookies()
  usUPjwMxhBacOvzWdpfQTRrmoyGnit=usUPjwMxhBacOvzWdpfQTRrmoyGnie.callRequestCookies('Get',usUPjwMxhBacOvzWdpfQTRrmoyGniN,payload=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,params=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,headers=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,cookies=usUPjwMxhBacOvzWdpfQTRrmoyGniD)
  usUPjwMxhBacOvzWdpfQTRrmoyGnkl=usUPjwMxhBacOvzWdpfQTRrmoyGnit.status_code 
  if usUPjwMxhBacOvzWdpfQTRrmoyGnkl!=200:return usUPjwMxhBacOvzWdpfQTRrmoyGnYI,usUPjwMxhBacOvzWdpfQTRrmoyGnkl
  usUPjwMxhBacOvzWdpfQTRrmoyGnYq=json.loads(usUPjwMxhBacOvzWdpfQTRrmoyGnit.text)
  for usUPjwMxhBacOvzWdpfQTRrmoyGnkq in usUPjwMxhBacOvzWdpfQTRrmoyGnYq:
   for usUPjwMxhBacOvzWdpfQTRrmoyGnYL in usUPjwMxhBacOvzWdpfQTRrmoyGnkq['liveNowList']:
    if usUPjwMxhBacOvzWdpfQTRrmoyGnYL['gameDesc']['title']==usUPjwMxhBacOvzWdpfQTRrmoyGnJS or usUPjwMxhBacOvzWdpfQTRrmoyGnYL['gameDesc']['title']=='':
     usUPjwMxhBacOvzWdpfQTRrmoyGnkL='%s ( %s : %s )'%(usUPjwMxhBacOvzWdpfQTRrmoyGnYL['leagueName'],usUPjwMxhBacOvzWdpfQTRrmoyGnYL['homeNameShort'],usUPjwMxhBacOvzWdpfQTRrmoyGnYL['awayNameShort'])
    else:
     usUPjwMxhBacOvzWdpfQTRrmoyGnkL=usUPjwMxhBacOvzWdpfQTRrmoyGnYL['gameDesc']['title']
    usUPjwMxhBacOvzWdpfQTRrmoyGnYD={'liveId':usUPjwMxhBacOvzWdpfQTRrmoyGnYL['liveId'],'title':usUPjwMxhBacOvzWdpfQTRrmoyGnkL,'logo':usUPjwMxhBacOvzWdpfQTRrmoyGnYL['gameDesc']['leagueLogo'],'free':usUPjwMxhBacOvzWdpfQTRrmoyGnYL['isFree'],'startTime':usUPjwMxhBacOvzWdpfQTRrmoyGnYL['startTime']}
    usUPjwMxhBacOvzWdpfQTRrmoyGnYI.append(usUPjwMxhBacOvzWdpfQTRrmoyGnYD)
  return usUPjwMxhBacOvzWdpfQTRrmoyGnYI,usUPjwMxhBacOvzWdpfQTRrmoyGnkl
 def GetEventLive_videoId(usUPjwMxhBacOvzWdpfQTRrmoyGnie,liveId):
  usUPjwMxhBacOvzWdpfQTRrmoyGnkD=''
  try:
   usUPjwMxhBacOvzWdpfQTRrmoyGniN=usUPjwMxhBacOvzWdpfQTRrmoyGnie.API_DOMAIN+'/api/v3/live/'+liveId
   usUPjwMxhBacOvzWdpfQTRrmoyGnit=usUPjwMxhBacOvzWdpfQTRrmoyGnie.callRequestCookies('Get',usUPjwMxhBacOvzWdpfQTRrmoyGniN,payload=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,params=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,headers=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,cookies=usUPjwMxhBacOvzWdpfQTRrmoyGnJS)
   usUPjwMxhBacOvzWdpfQTRrmoyGnYq=json.loads(usUPjwMxhBacOvzWdpfQTRrmoyGnit.text)
   usUPjwMxhBacOvzWdpfQTRrmoyGnkg=usUPjwMxhBacOvzWdpfQTRrmoyGnYq['videoId']
   usUPjwMxhBacOvzWdpfQTRrmoyGnkD=usUPjwMxhBacOvzWdpfQTRrmoyGnkg.replace('ref:','')
  except usUPjwMxhBacOvzWdpfQTRrmoyGnJH as exception:
   usUPjwMxhBacOvzWdpfQTRrmoyGnJI(exception)
  return usUPjwMxhBacOvzWdpfQTRrmoyGnkD
 def CheckMainEnd(usUPjwMxhBacOvzWdpfQTRrmoyGnie):
  usUPjwMxhBacOvzWdpfQTRrmoyGnkE=usUPjwMxhBacOvzWdpfQTRrmoyGnie.SPOTV_PMCODE+usUPjwMxhBacOvzWdpfQTRrmoyGnJL(usUPjwMxhBacOvzWdpfQTRrmoyGnie.ST['cookies']['spotv_sessionid'])
  usUPjwMxhBacOvzWdpfQTRrmoyGnkE=base64.standard_b64encode(usUPjwMxhBacOvzWdpfQTRrmoyGnkE.encode()).decode('utf-8')
  if usUPjwMxhBacOvzWdpfQTRrmoyGnkE=='OTg3MTgzMzM0Ng==' or usUPjwMxhBacOvzWdpfQTRrmoyGnkE=='OTg3MTgzMzExNw==':return usUPjwMxhBacOvzWdpfQTRrmoyGnJg
  return usUPjwMxhBacOvzWdpfQTRrmoyGnJq
 def CheckSubEnd(usUPjwMxhBacOvzWdpfQTRrmoyGnie):
  usUPjwMxhBacOvzWdpfQTRrmoyGniS=usUPjwMxhBacOvzWdpfQTRrmoyGnJq
  try:
   if usUPjwMxhBacOvzWdpfQTRrmoyGnie.CheckMainEnd():return usUPjwMxhBacOvzWdpfQTRrmoyGnJg 
   usUPjwMxhBacOvzWdpfQTRrmoyGnkH=base64.standard_b64decode(usUPjwMxhBacOvzWdpfQTRrmoyGnie.ST['cookies']['spotv_subend']).decode('utf-8')[usUPjwMxhBacOvzWdpfQTRrmoyGnie.SPOTV_PMSIZE:]
   if usUPjwMxhBacOvzWdpfQTRrmoyGnkH=='0':return usUPjwMxhBacOvzWdpfQTRrmoyGniS
   usUPjwMxhBacOvzWdpfQTRrmoyGnkN =usUPjwMxhBacOvzWdpfQTRrmoyGnJE(usUPjwMxhBacOvzWdpfQTRrmoyGnie.Get_Now_Datetime().strftime('%Y%m%d'))
   usUPjwMxhBacOvzWdpfQTRrmoyGnkt =usUPjwMxhBacOvzWdpfQTRrmoyGnJE(usUPjwMxhBacOvzWdpfQTRrmoyGnkH)/1000
   usUPjwMxhBacOvzWdpfQTRrmoyGnkC =usUPjwMxhBacOvzWdpfQTRrmoyGnJE(datetime.datetime.fromtimestamp(usUPjwMxhBacOvzWdpfQTRrmoyGnkt,datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul')).strftime('%Y%m%d'))
   if usUPjwMxhBacOvzWdpfQTRrmoyGnkN<=usUPjwMxhBacOvzWdpfQTRrmoyGnkC:usUPjwMxhBacOvzWdpfQTRrmoyGniS=usUPjwMxhBacOvzWdpfQTRrmoyGnJg
  except usUPjwMxhBacOvzWdpfQTRrmoyGnJH as exception:
   usUPjwMxhBacOvzWdpfQTRrmoyGnJI(exception)
   return usUPjwMxhBacOvzWdpfQTRrmoyGniS
  return usUPjwMxhBacOvzWdpfQTRrmoyGniS
 def GetBroadURL(usUPjwMxhBacOvzWdpfQTRrmoyGnie,usUPjwMxhBacOvzWdpfQTRrmoyGnkD,mediatype,usUPjwMxhBacOvzWdpfQTRrmoyGneA):
  usUPjwMxhBacOvzWdpfQTRrmoyGnkV=''
  try:
   if mediatype=='live':
    usUPjwMxhBacOvzWdpfQTRrmoyGniN='{}/api/v3/live/di/con/sec/web/{}'.format(usUPjwMxhBacOvzWdpfQTRrmoyGnie.API_DOMAIN,usUPjwMxhBacOvzWdpfQTRrmoyGnkD)
   else:
    usUPjwMxhBacOvzWdpfQTRrmoyGnkD=usUPjwMxhBacOvzWdpfQTRrmoyGnie.GetReplay_UrlId(usUPjwMxhBacOvzWdpfQTRrmoyGnkD,usUPjwMxhBacOvzWdpfQTRrmoyGneA)
    if usUPjwMxhBacOvzWdpfQTRrmoyGnkD=='':return usUPjwMxhBacOvzWdpfQTRrmoyGnkV
    usUPjwMxhBacOvzWdpfQTRrmoyGniN=usUPjwMxhBacOvzWdpfQTRrmoyGnie.PLAYER_DOMAIN+'/playback/v1/accounts/'+usUPjwMxhBacOvzWdpfQTRrmoyGnJL(usUPjwMxhBacOvzWdpfQTRrmoyGnie.ST['cookies']['spotv_accountId'])+'/videos/'+usUPjwMxhBacOvzWdpfQTRrmoyGnkD
   usUPjwMxhBacOvzWdpfQTRrmoyGnig=usUPjwMxhBacOvzWdpfQTRrmoyGnie.makeDefaultHeaders()
   usUPjwMxhBacOvzWdpfQTRrmoyGnit=usUPjwMxhBacOvzWdpfQTRrmoyGnie.callRequestCookies('Get',usUPjwMxhBacOvzWdpfQTRrmoyGniN,payload=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,params=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,headers=usUPjwMxhBacOvzWdpfQTRrmoyGnig,cookies=usUPjwMxhBacOvzWdpfQTRrmoyGnJS)
   usUPjwMxhBacOvzWdpfQTRrmoyGnYi=json.loads(usUPjwMxhBacOvzWdpfQTRrmoyGnit.text)
   usUPjwMxhBacOvzWdpfQTRrmoyGnJI(usUPjwMxhBacOvzWdpfQTRrmoyGniN)
   if mediatype=='live':
    usUPjwMxhBacOvzWdpfQTRrmoyGnkV=usUPjwMxhBacOvzWdpfQTRrmoyGnYi['hlsDrmUrl']
    usUPjwMxhBacOvzWdpfQTRrmoyGnYE =usUPjwMxhBacOvzWdpfQTRrmoyGnYi['cid']
   else:
    usUPjwMxhBacOvzWdpfQTRrmoyGnkV=usUPjwMxhBacOvzWdpfQTRrmoyGnYi['sources'][0]['src']
    usUPjwMxhBacOvzWdpfQTRrmoyGnYE =''
   usUPjwMxhBacOvzWdpfQTRrmoyGnkV=usUPjwMxhBacOvzWdpfQTRrmoyGnkV.replace('http://','https://')
  except usUPjwMxhBacOvzWdpfQTRrmoyGnJH as exception:
   usUPjwMxhBacOvzWdpfQTRrmoyGnJI(exception)
  return usUPjwMxhBacOvzWdpfQTRrmoyGnYE,usUPjwMxhBacOvzWdpfQTRrmoyGnkV
 def GetTitleGroupList(usUPjwMxhBacOvzWdpfQTRrmoyGnie):
  usUPjwMxhBacOvzWdpfQTRrmoyGnYI=[]
  usUPjwMxhBacOvzWdpfQTRrmoyGniN=usUPjwMxhBacOvzWdpfQTRrmoyGnie.API_DOMAIN+'/api/v3/home/web'
  usUPjwMxhBacOvzWdpfQTRrmoyGnit=usUPjwMxhBacOvzWdpfQTRrmoyGnie.callRequestCookies('Get',usUPjwMxhBacOvzWdpfQTRrmoyGniN,payload=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,params=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,headers=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,cookies=usUPjwMxhBacOvzWdpfQTRrmoyGnJS)
  usUPjwMxhBacOvzWdpfQTRrmoyGnYq=json.loads(usUPjwMxhBacOvzWdpfQTRrmoyGnit.text)
  for usUPjwMxhBacOvzWdpfQTRrmoyGnYL in usUPjwMxhBacOvzWdpfQTRrmoyGnYq:
   if usUPjwMxhBacOvzWdpfQTRrmoyGnJL(usUPjwMxhBacOvzWdpfQTRrmoyGnYL['type'])=='3':
    usUPjwMxhBacOvzWdpfQTRrmoyGnkK=''
    for usUPjwMxhBacOvzWdpfQTRrmoyGnkF in usUPjwMxhBacOvzWdpfQTRrmoyGnYL['data']['list']:
     usUPjwMxhBacOvzWdpfQTRrmoyGnei='[%s] %s vs %s\n<%s>\n\n'%(usUPjwMxhBacOvzWdpfQTRrmoyGnkF['gameDesc']['roundName'],usUPjwMxhBacOvzWdpfQTRrmoyGnkF['gameDesc']['homeNameShort'],usUPjwMxhBacOvzWdpfQTRrmoyGnkF['gameDesc']['awayNameShort'],usUPjwMxhBacOvzWdpfQTRrmoyGnkF['gameDesc']['beginDate'])
     usUPjwMxhBacOvzWdpfQTRrmoyGnkK+=usUPjwMxhBacOvzWdpfQTRrmoyGnei
    usUPjwMxhBacOvzWdpfQTRrmoyGnYD={'title':usUPjwMxhBacOvzWdpfQTRrmoyGnYL['title'],'logo':usUPjwMxhBacOvzWdpfQTRrmoyGnYL['logo'],'reagueId':usUPjwMxhBacOvzWdpfQTRrmoyGnJL(usUPjwMxhBacOvzWdpfQTRrmoyGnYL['destId']),'subGame':usUPjwMxhBacOvzWdpfQTRrmoyGnkK,}
    usUPjwMxhBacOvzWdpfQTRrmoyGnYI.append(usUPjwMxhBacOvzWdpfQTRrmoyGnYD)
  return usUPjwMxhBacOvzWdpfQTRrmoyGnYI
 def GetPopularGroupList(usUPjwMxhBacOvzWdpfQTRrmoyGnie):
  usUPjwMxhBacOvzWdpfQTRrmoyGnYI=[]
  usUPjwMxhBacOvzWdpfQTRrmoyGniN=usUPjwMxhBacOvzWdpfQTRrmoyGnie.API_DOMAIN+'/api/v3/home/web'
  usUPjwMxhBacOvzWdpfQTRrmoyGnit=usUPjwMxhBacOvzWdpfQTRrmoyGnie.callRequestCookies('Get',usUPjwMxhBacOvzWdpfQTRrmoyGniN,payload=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,params=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,headers=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,cookies=usUPjwMxhBacOvzWdpfQTRrmoyGnJS)
  usUPjwMxhBacOvzWdpfQTRrmoyGnYq=json.loads(usUPjwMxhBacOvzWdpfQTRrmoyGnit.text)
  for usUPjwMxhBacOvzWdpfQTRrmoyGnYL in usUPjwMxhBacOvzWdpfQTRrmoyGnYq:
   if usUPjwMxhBacOvzWdpfQTRrmoyGnJL(usUPjwMxhBacOvzWdpfQTRrmoyGnYL['type'])=='1' and usUPjwMxhBacOvzWdpfQTRrmoyGnJL(usUPjwMxhBacOvzWdpfQTRrmoyGnYL['destId'])=='4':
    for usUPjwMxhBacOvzWdpfQTRrmoyGnkF in usUPjwMxhBacOvzWdpfQTRrmoyGnYL['data']['list']:
     usUPjwMxhBacOvzWdpfQTRrmoyGneY =usUPjwMxhBacOvzWdpfQTRrmoyGnkF['title']
     usUPjwMxhBacOvzWdpfQTRrmoyGnek =usUPjwMxhBacOvzWdpfQTRrmoyGnkF['id']
     usUPjwMxhBacOvzWdpfQTRrmoyGneJ =usUPjwMxhBacOvzWdpfQTRrmoyGnkF['vtype']
     usUPjwMxhBacOvzWdpfQTRrmoyGneX =usUPjwMxhBacOvzWdpfQTRrmoyGnkF['imgUrl']
     usUPjwMxhBacOvzWdpfQTRrmoyGneA =usUPjwMxhBacOvzWdpfQTRrmoyGnkF['vtypeId']
     usUPjwMxhBacOvzWdpfQTRrmoyGnYD={'vodTitle':usUPjwMxhBacOvzWdpfQTRrmoyGneY,'vodId':usUPjwMxhBacOvzWdpfQTRrmoyGnek,'vodType':usUPjwMxhBacOvzWdpfQTRrmoyGneJ,'thumbnail':usUPjwMxhBacOvzWdpfQTRrmoyGneX,'vtypeId':usUPjwMxhBacOvzWdpfQTRrmoyGnJL(usUPjwMxhBacOvzWdpfQTRrmoyGneA),'duration':usUPjwMxhBacOvzWdpfQTRrmoyGnJE(usUPjwMxhBacOvzWdpfQTRrmoyGnkF['duration']/1000),}
     usUPjwMxhBacOvzWdpfQTRrmoyGnYI.append(usUPjwMxhBacOvzWdpfQTRrmoyGnYD)
  return usUPjwMxhBacOvzWdpfQTRrmoyGnYI
 def Get_NowVod_GroupList(usUPjwMxhBacOvzWdpfQTRrmoyGnie,page_int):
  usUPjwMxhBacOvzWdpfQTRrmoyGnYI=[]
  usUPjwMxhBacOvzWdpfQTRrmoyGneb=usUPjwMxhBacOvzWdpfQTRrmoyGnJq
  usUPjwMxhBacOvzWdpfQTRrmoyGniN=usUPjwMxhBacOvzWdpfQTRrmoyGnie.API_DOMAIN+'/api/v3/theme/14/list'
  usUPjwMxhBacOvzWdpfQTRrmoyGnel={'pageItem':'10','pageNo':usUPjwMxhBacOvzWdpfQTRrmoyGnJL(page_int)}
  usUPjwMxhBacOvzWdpfQTRrmoyGnit=usUPjwMxhBacOvzWdpfQTRrmoyGnie.callRequestCookies('Get',usUPjwMxhBacOvzWdpfQTRrmoyGniN,payload=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,params=usUPjwMxhBacOvzWdpfQTRrmoyGnel,headers=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,cookies=usUPjwMxhBacOvzWdpfQTRrmoyGnJS)
  usUPjwMxhBacOvzWdpfQTRrmoyGnYq=json.loads(usUPjwMxhBacOvzWdpfQTRrmoyGnit.text)
  for usUPjwMxhBacOvzWdpfQTRrmoyGnYL in usUPjwMxhBacOvzWdpfQTRrmoyGnYq['list']:
   usUPjwMxhBacOvzWdpfQTRrmoyGneY =usUPjwMxhBacOvzWdpfQTRrmoyGnYL['title']
   usUPjwMxhBacOvzWdpfQTRrmoyGnek =usUPjwMxhBacOvzWdpfQTRrmoyGnYL['id']
   usUPjwMxhBacOvzWdpfQTRrmoyGneJ =usUPjwMxhBacOvzWdpfQTRrmoyGnYL['vtype']
   usUPjwMxhBacOvzWdpfQTRrmoyGneX =usUPjwMxhBacOvzWdpfQTRrmoyGnYL['imgUrl']
   usUPjwMxhBacOvzWdpfQTRrmoyGneA =usUPjwMxhBacOvzWdpfQTRrmoyGnYL['vtypeId']
   usUPjwMxhBacOvzWdpfQTRrmoyGnYD={'vodTitle':usUPjwMxhBacOvzWdpfQTRrmoyGneY,'vodId':usUPjwMxhBacOvzWdpfQTRrmoyGnek,'vodType':usUPjwMxhBacOvzWdpfQTRrmoyGneJ,'thumbnail':usUPjwMxhBacOvzWdpfQTRrmoyGneX,'vtypeId':usUPjwMxhBacOvzWdpfQTRrmoyGnJL(usUPjwMxhBacOvzWdpfQTRrmoyGneA),'duration':usUPjwMxhBacOvzWdpfQTRrmoyGnJE(usUPjwMxhBacOvzWdpfQTRrmoyGnYL['duration']/1000),}
   usUPjwMxhBacOvzWdpfQTRrmoyGnYI.append(usUPjwMxhBacOvzWdpfQTRrmoyGnYD)
   if usUPjwMxhBacOvzWdpfQTRrmoyGnYq['count']>page_int*usUPjwMxhBacOvzWdpfQTRrmoyGnie.GAMELIST_LIMIT:usUPjwMxhBacOvzWdpfQTRrmoyGneb=usUPjwMxhBacOvzWdpfQTRrmoyGnJg
  return usUPjwMxhBacOvzWdpfQTRrmoyGnYI,usUPjwMxhBacOvzWdpfQTRrmoyGneb
 def GetSeasonList(usUPjwMxhBacOvzWdpfQTRrmoyGnie,leagueId):
  usUPjwMxhBacOvzWdpfQTRrmoyGnYI=[]
  usUPjwMxhBacOvzWdpfQTRrmoyGneI=usUPjwMxhBacOvzWdpfQTRrmoyGneS=''
  try:
   usUPjwMxhBacOvzWdpfQTRrmoyGniN=usUPjwMxhBacOvzWdpfQTRrmoyGnie.API_DOMAIN+'/api/v3/game/league/'+leagueId
   usUPjwMxhBacOvzWdpfQTRrmoyGnit=usUPjwMxhBacOvzWdpfQTRrmoyGnie.callRequestCookies('Get',usUPjwMxhBacOvzWdpfQTRrmoyGniN,payload=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,params=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,headers=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,cookies=usUPjwMxhBacOvzWdpfQTRrmoyGnJS)
   usUPjwMxhBacOvzWdpfQTRrmoyGnYq=json.loads(usUPjwMxhBacOvzWdpfQTRrmoyGnit.text)
   usUPjwMxhBacOvzWdpfQTRrmoyGneI=usUPjwMxhBacOvzWdpfQTRrmoyGnYq['name']
   usUPjwMxhBacOvzWdpfQTRrmoyGneS=usUPjwMxhBacOvzWdpfQTRrmoyGnJL(usUPjwMxhBacOvzWdpfQTRrmoyGnYq['gameTypeId'])
  except usUPjwMxhBacOvzWdpfQTRrmoyGnJH as exception:
   usUPjwMxhBacOvzWdpfQTRrmoyGnJI(exception)
   return usUPjwMxhBacOvzWdpfQTRrmoyGnYI
  if usUPjwMxhBacOvzWdpfQTRrmoyGneS in['2','5','6','8']:
   try:
    usUPjwMxhBacOvzWdpfQTRrmoyGniN=usUPjwMxhBacOvzWdpfQTRrmoyGnie.API_DOMAIN+'/api/v3/year/'+leagueId
    usUPjwMxhBacOvzWdpfQTRrmoyGnit=usUPjwMxhBacOvzWdpfQTRrmoyGnie.callRequestCookies('Get',usUPjwMxhBacOvzWdpfQTRrmoyGniN,payload=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,params=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,headers=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,cookies=usUPjwMxhBacOvzWdpfQTRrmoyGnJS)
    usUPjwMxhBacOvzWdpfQTRrmoyGnYq=json.loads(usUPjwMxhBacOvzWdpfQTRrmoyGnit.text)
    for usUPjwMxhBacOvzWdpfQTRrmoyGnYL in usUPjwMxhBacOvzWdpfQTRrmoyGnYq:
     usUPjwMxhBacOvzWdpfQTRrmoyGnYD={'reagueName':usUPjwMxhBacOvzWdpfQTRrmoyGneI,'gameTypeId':usUPjwMxhBacOvzWdpfQTRrmoyGneS,'seasonName':usUPjwMxhBacOvzWdpfQTRrmoyGnJL(usUPjwMxhBacOvzWdpfQTRrmoyGnYL),'seasonId':usUPjwMxhBacOvzWdpfQTRrmoyGnJL(usUPjwMxhBacOvzWdpfQTRrmoyGnYL)}
     usUPjwMxhBacOvzWdpfQTRrmoyGnYI.append(usUPjwMxhBacOvzWdpfQTRrmoyGnYD)
   except usUPjwMxhBacOvzWdpfQTRrmoyGnJH as exception:
    usUPjwMxhBacOvzWdpfQTRrmoyGnJI(exception)
    return[]
  else:
   try:
    usUPjwMxhBacOvzWdpfQTRrmoyGniN=usUPjwMxhBacOvzWdpfQTRrmoyGnie.API_DOMAIN+'/api/v3/season/'+leagueId
    usUPjwMxhBacOvzWdpfQTRrmoyGnit=usUPjwMxhBacOvzWdpfQTRrmoyGnie.callRequestCookies('Get',usUPjwMxhBacOvzWdpfQTRrmoyGniN,payload=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,params=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,headers=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,cookies=usUPjwMxhBacOvzWdpfQTRrmoyGnJS)
    usUPjwMxhBacOvzWdpfQTRrmoyGnYq=json.loads(usUPjwMxhBacOvzWdpfQTRrmoyGnit.text)
    for usUPjwMxhBacOvzWdpfQTRrmoyGnYL in usUPjwMxhBacOvzWdpfQTRrmoyGnYq:
     usUPjwMxhBacOvzWdpfQTRrmoyGnYD={'reagueName':usUPjwMxhBacOvzWdpfQTRrmoyGneI,'gameTypeId':usUPjwMxhBacOvzWdpfQTRrmoyGneS,'seasonName':usUPjwMxhBacOvzWdpfQTRrmoyGnYL['name'],'seasonId':usUPjwMxhBacOvzWdpfQTRrmoyGnJL(usUPjwMxhBacOvzWdpfQTRrmoyGnYL['id'])}
     usUPjwMxhBacOvzWdpfQTRrmoyGnYI.append(usUPjwMxhBacOvzWdpfQTRrmoyGnYD)
   except usUPjwMxhBacOvzWdpfQTRrmoyGnJH as exception:
    usUPjwMxhBacOvzWdpfQTRrmoyGnJI(exception)
    return[]
  return usUPjwMxhBacOvzWdpfQTRrmoyGnYI
 def GetGameList(usUPjwMxhBacOvzWdpfQTRrmoyGnie,usUPjwMxhBacOvzWdpfQTRrmoyGneS,leagueId,seasonId,page_int,hidescore=usUPjwMxhBacOvzWdpfQTRrmoyGnJg):
  usUPjwMxhBacOvzWdpfQTRrmoyGnYI=[]
  usUPjwMxhBacOvzWdpfQTRrmoyGneb=usUPjwMxhBacOvzWdpfQTRrmoyGnJq
  try:
   usUPjwMxhBacOvzWdpfQTRrmoyGniN=usUPjwMxhBacOvzWdpfQTRrmoyGnie.API_DOMAIN+'/api/v3/vod/league/detail'
   usUPjwMxhBacOvzWdpfQTRrmoyGnel={'gameType':usUPjwMxhBacOvzWdpfQTRrmoyGneS,'leagueId':leagueId,'seasonId':seasonId if usUPjwMxhBacOvzWdpfQTRrmoyGneS not in['2','5','6','8']else '','teamId':'','roundId':'','year':'' if usUPjwMxhBacOvzWdpfQTRrmoyGneS not in['2','5','6','8']else seasonId,'pageNo':usUPjwMxhBacOvzWdpfQTRrmoyGnJL(page_int)}
   usUPjwMxhBacOvzWdpfQTRrmoyGnit=usUPjwMxhBacOvzWdpfQTRrmoyGnie.callRequestCookies('Get',usUPjwMxhBacOvzWdpfQTRrmoyGniN,payload=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,params=usUPjwMxhBacOvzWdpfQTRrmoyGnel,headers=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,cookies=usUPjwMxhBacOvzWdpfQTRrmoyGnJS)
   usUPjwMxhBacOvzWdpfQTRrmoyGnYq=json.loads(usUPjwMxhBacOvzWdpfQTRrmoyGnit.text)
   usUPjwMxhBacOvzWdpfQTRrmoyGnkq=usUPjwMxhBacOvzWdpfQTRrmoyGnYq['list']
   for usUPjwMxhBacOvzWdpfQTRrmoyGneq in usUPjwMxhBacOvzWdpfQTRrmoyGnkq:
    for usUPjwMxhBacOvzWdpfQTRrmoyGnYL in usUPjwMxhBacOvzWdpfQTRrmoyGneq['list']:
     if usUPjwMxhBacOvzWdpfQTRrmoyGnYL['gameDesc']['title']==usUPjwMxhBacOvzWdpfQTRrmoyGnJS or usUPjwMxhBacOvzWdpfQTRrmoyGnYL['gameDesc']['title']=='':
      usUPjwMxhBacOvzWdpfQTRrmoyGnkL ='%s vs %s'%(usUPjwMxhBacOvzWdpfQTRrmoyGnYL['gameDesc']['homeNameShort'],usUPjwMxhBacOvzWdpfQTRrmoyGnYL['gameDesc']['awayNameShort'])
     else:
      usUPjwMxhBacOvzWdpfQTRrmoyGnkL =usUPjwMxhBacOvzWdpfQTRrmoyGnYL['gameDesc']['title']
     usUPjwMxhBacOvzWdpfQTRrmoyGneL =usUPjwMxhBacOvzWdpfQTRrmoyGnYL['gameDesc']['beginDate']
     usUPjwMxhBacOvzWdpfQTRrmoyGneD =usUPjwMxhBacOvzWdpfQTRrmoyGnYL['gameDesc']['id']
     usUPjwMxhBacOvzWdpfQTRrmoyGneg =usUPjwMxhBacOvzWdpfQTRrmoyGnYL['gameDesc']['leagueNameFull']
     usUPjwMxhBacOvzWdpfQTRrmoyGneE =usUPjwMxhBacOvzWdpfQTRrmoyGnYL['gameDesc']['seasonName']
     usUPjwMxhBacOvzWdpfQTRrmoyGneH =usUPjwMxhBacOvzWdpfQTRrmoyGnYL['gameDesc']['roundName']
     usUPjwMxhBacOvzWdpfQTRrmoyGneN =usUPjwMxhBacOvzWdpfQTRrmoyGnYL['gameDesc']['homeName']
     usUPjwMxhBacOvzWdpfQTRrmoyGnet =usUPjwMxhBacOvzWdpfQTRrmoyGnYL['gameDesc']['awayName']
     usUPjwMxhBacOvzWdpfQTRrmoyGneC =usUPjwMxhBacOvzWdpfQTRrmoyGnYL['gameDesc']['homeScore']
     usUPjwMxhBacOvzWdpfQTRrmoyGneV =usUPjwMxhBacOvzWdpfQTRrmoyGnYL['gameDesc']['awayScore']
     if hidescore==usUPjwMxhBacOvzWdpfQTRrmoyGnJg:
      usUPjwMxhBacOvzWdpfQTRrmoyGneK ='%s\n - %s (%s)\n - %s\n\nhome : %s\n\naway : %s'%(usUPjwMxhBacOvzWdpfQTRrmoyGneg,usUPjwMxhBacOvzWdpfQTRrmoyGneE,usUPjwMxhBacOvzWdpfQTRrmoyGneH,usUPjwMxhBacOvzWdpfQTRrmoyGneL,usUPjwMxhBacOvzWdpfQTRrmoyGneN,usUPjwMxhBacOvzWdpfQTRrmoyGnet)
     else:
      usUPjwMxhBacOvzWdpfQTRrmoyGneK ='%s\n - %s (%s)\n - %s\n\nhome : %s (Score %s)\n\naway : %s (Score %s)'%(usUPjwMxhBacOvzWdpfQTRrmoyGneg,usUPjwMxhBacOvzWdpfQTRrmoyGneE,usUPjwMxhBacOvzWdpfQTRrmoyGneH,usUPjwMxhBacOvzWdpfQTRrmoyGneL,usUPjwMxhBacOvzWdpfQTRrmoyGneN,usUPjwMxhBacOvzWdpfQTRrmoyGneC,usUPjwMxhBacOvzWdpfQTRrmoyGnet,usUPjwMxhBacOvzWdpfQTRrmoyGneV)
     usUPjwMxhBacOvzWdpfQTRrmoyGneF=usUPjwMxhBacOvzWdpfQTRrmoyGneK
     usUPjwMxhBacOvzWdpfQTRrmoyGnJi =usUPjwMxhBacOvzWdpfQTRrmoyGnYL['replayVod']['count']
     usUPjwMxhBacOvzWdpfQTRrmoyGnJY=usUPjwMxhBacOvzWdpfQTRrmoyGnYL['highlightVod']['count']
     usUPjwMxhBacOvzWdpfQTRrmoyGnJk =usUPjwMxhBacOvzWdpfQTRrmoyGnYL['vods']['count']
     usUPjwMxhBacOvzWdpfQTRrmoyGneX='' 
     usUPjwMxhBacOvzWdpfQTRrmoyGnJe=usUPjwMxhBacOvzWdpfQTRrmoyGnJi+usUPjwMxhBacOvzWdpfQTRrmoyGnJY+usUPjwMxhBacOvzWdpfQTRrmoyGnJk
     if usUPjwMxhBacOvzWdpfQTRrmoyGnJe==0:
      if usUPjwMxhBacOvzWdpfQTRrmoyGneS=='2':
       usUPjwMxhBacOvzWdpfQTRrmoyGnkL='----- %s -----'%(usUPjwMxhBacOvzWdpfQTRrmoyGneE)
       usUPjwMxhBacOvzWdpfQTRrmoyGneL=''
      else:
       usUPjwMxhBacOvzWdpfQTRrmoyGnkL+=' - 관련영상 없음'
       usUPjwMxhBacOvzWdpfQTRrmoyGneF+='\n\n ** 관련영상 없음 **'
     else:
      if usUPjwMxhBacOvzWdpfQTRrmoyGnJi!=0:
       usUPjwMxhBacOvzWdpfQTRrmoyGneX =usUPjwMxhBacOvzWdpfQTRrmoyGnYL['replayVod']['list'][0]['imgUrl']
      elif usUPjwMxhBacOvzWdpfQTRrmoyGnJY!=0:
       usUPjwMxhBacOvzWdpfQTRrmoyGneX =usUPjwMxhBacOvzWdpfQTRrmoyGnYL['highlightVod']['list'][0]['imgUrl']
      else:
       usUPjwMxhBacOvzWdpfQTRrmoyGneX =usUPjwMxhBacOvzWdpfQTRrmoyGnYL['vods']['list'][0]['imgUrl']
     usUPjwMxhBacOvzWdpfQTRrmoyGnYD={'gameTitle':usUPjwMxhBacOvzWdpfQTRrmoyGnkL,'gameId':usUPjwMxhBacOvzWdpfQTRrmoyGneD,'beginDate':usUPjwMxhBacOvzWdpfQTRrmoyGneL[:11],'thumbnail':usUPjwMxhBacOvzWdpfQTRrmoyGneX,'info_plot':usUPjwMxhBacOvzWdpfQTRrmoyGneF,'leaguenm':usUPjwMxhBacOvzWdpfQTRrmoyGneg,'seasonnm':usUPjwMxhBacOvzWdpfQTRrmoyGneE,'roundnm':usUPjwMxhBacOvzWdpfQTRrmoyGneH,'totVodCnt':usUPjwMxhBacOvzWdpfQTRrmoyGnJe}
     usUPjwMxhBacOvzWdpfQTRrmoyGnYI.append(usUPjwMxhBacOvzWdpfQTRrmoyGnYD)
  except usUPjwMxhBacOvzWdpfQTRrmoyGnJH as exception:
   usUPjwMxhBacOvzWdpfQTRrmoyGnJI(exception)
  if usUPjwMxhBacOvzWdpfQTRrmoyGnYq['count']>page_int*usUPjwMxhBacOvzWdpfQTRrmoyGnie.GAMELIST_LIMIT:usUPjwMxhBacOvzWdpfQTRrmoyGneb=usUPjwMxhBacOvzWdpfQTRrmoyGnJg
  return usUPjwMxhBacOvzWdpfQTRrmoyGnYI,usUPjwMxhBacOvzWdpfQTRrmoyGneb
 def GetGameVodList(usUPjwMxhBacOvzWdpfQTRrmoyGnie,usUPjwMxhBacOvzWdpfQTRrmoyGneD,vodCount=1000):
  usUPjwMxhBacOvzWdpfQTRrmoyGnYI=[]
  usUPjwMxhBacOvzWdpfQTRrmoyGnJX=''
  try:
   usUPjwMxhBacOvzWdpfQTRrmoyGniN=usUPjwMxhBacOvzWdpfQTRrmoyGnie.API_DOMAIN+'/api/v3/vod/game'
   usUPjwMxhBacOvzWdpfQTRrmoyGnel={'gameId':usUPjwMxhBacOvzWdpfQTRrmoyGneD,'pageItem':usUPjwMxhBacOvzWdpfQTRrmoyGnJL(vodCount)}
   usUPjwMxhBacOvzWdpfQTRrmoyGnit=usUPjwMxhBacOvzWdpfQTRrmoyGnie.callRequestCookies('Get',usUPjwMxhBacOvzWdpfQTRrmoyGniN,payload=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,params=usUPjwMxhBacOvzWdpfQTRrmoyGnel,headers=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,cookies=usUPjwMxhBacOvzWdpfQTRrmoyGnJS)
   usUPjwMxhBacOvzWdpfQTRrmoyGnYq=json.loads(usUPjwMxhBacOvzWdpfQTRrmoyGnit.text)
   usUPjwMxhBacOvzWdpfQTRrmoyGneq=usUPjwMxhBacOvzWdpfQTRrmoyGnYq['list']
   for usUPjwMxhBacOvzWdpfQTRrmoyGnYL in usUPjwMxhBacOvzWdpfQTRrmoyGneq:
    usUPjwMxhBacOvzWdpfQTRrmoyGneY =usUPjwMxhBacOvzWdpfQTRrmoyGnYL['title']
    usUPjwMxhBacOvzWdpfQTRrmoyGnek =usUPjwMxhBacOvzWdpfQTRrmoyGnYL['id']
    usUPjwMxhBacOvzWdpfQTRrmoyGneJ =usUPjwMxhBacOvzWdpfQTRrmoyGnYL['vtype']
    usUPjwMxhBacOvzWdpfQTRrmoyGneX =usUPjwMxhBacOvzWdpfQTRrmoyGnYL['imgUrl']
    usUPjwMxhBacOvzWdpfQTRrmoyGneA =usUPjwMxhBacOvzWdpfQTRrmoyGnYL['vtypeId']
    usUPjwMxhBacOvzWdpfQTRrmoyGnJA =usUPjwMxhBacOvzWdpfQTRrmoyGnYL['isFree']
    usUPjwMxhBacOvzWdpfQTRrmoyGnYD={'vodTitle':usUPjwMxhBacOvzWdpfQTRrmoyGneY,'vodId':usUPjwMxhBacOvzWdpfQTRrmoyGnek,'vodType':usUPjwMxhBacOvzWdpfQTRrmoyGneJ,'thumbnail':usUPjwMxhBacOvzWdpfQTRrmoyGneX,'vtypeId':usUPjwMxhBacOvzWdpfQTRrmoyGnJL(usUPjwMxhBacOvzWdpfQTRrmoyGneA),'duration':usUPjwMxhBacOvzWdpfQTRrmoyGnJE(usUPjwMxhBacOvzWdpfQTRrmoyGnYL['duration']/1000),'isFree':usUPjwMxhBacOvzWdpfQTRrmoyGnJA}
    usUPjwMxhBacOvzWdpfQTRrmoyGnYI.append(usUPjwMxhBacOvzWdpfQTRrmoyGnYD)
  except usUPjwMxhBacOvzWdpfQTRrmoyGnJH as exception:
   usUPjwMxhBacOvzWdpfQTRrmoyGnJI(exception)
  return usUPjwMxhBacOvzWdpfQTRrmoyGnYI
 def GetReplay_UrlId(usUPjwMxhBacOvzWdpfQTRrmoyGnie,usUPjwMxhBacOvzWdpfQTRrmoyGnJX,usUPjwMxhBacOvzWdpfQTRrmoyGneA):
  usUPjwMxhBacOvzWdpfQTRrmoyGnJb=''
  try:
   usUPjwMxhBacOvzWdpfQTRrmoyGniN=usUPjwMxhBacOvzWdpfQTRrmoyGnie.API_DOMAIN+'/api/v3/vod/'+usUPjwMxhBacOvzWdpfQTRrmoyGnJX
   usUPjwMxhBacOvzWdpfQTRrmoyGnit=usUPjwMxhBacOvzWdpfQTRrmoyGnie.callRequestCookies('Get',usUPjwMxhBacOvzWdpfQTRrmoyGniN,payload=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,params=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,headers=usUPjwMxhBacOvzWdpfQTRrmoyGnJS,cookies=usUPjwMxhBacOvzWdpfQTRrmoyGnJS)
   usUPjwMxhBacOvzWdpfQTRrmoyGnYq=json.loads(usUPjwMxhBacOvzWdpfQTRrmoyGnit.text)
   usUPjwMxhBacOvzWdpfQTRrmoyGnJb=usUPjwMxhBacOvzWdpfQTRrmoyGnYq['videoId']
  except usUPjwMxhBacOvzWdpfQTRrmoyGnJH as exception:
   usUPjwMxhBacOvzWdpfQTRrmoyGnJI(exception)
  return usUPjwMxhBacOvzWdpfQTRrmoyGnJb
# Created by pyminifier (https://github.com/liftoff/pyminifier)
