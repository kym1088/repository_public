_w='/api/v3/vod/'
_v='gameId'
_u='pageNo'
_t='pageItem'
_s='destId'
_r='roundName'
_q='/api/v3/home/web'
_p='240000'
_o='sch_min'
_n='sch_hour'
_m='sch_date'
_l='hlsDrmUrl'
_k='Asia/Seoul'
_j='spotv_sessionid'
_i='seasonId'
_h='seasonName'
_g='vodType'
_f='vodId'
_e='vodTitle'
_d='vtype'
_c='beginDate'
_b='isFree'
_a='awayNameShort'
_Z='homeNameShort'
_Y='videoId'
_X='free'
_W='thumbnail'
_V='name'
_U='spotv_subend'
_T='count'
_S='logo'
_R='account'
_Q='duration'
_P='vtypeId'
_O='imgUrl'
_N='\n'
_M='id_token'
_L='list'
_K='endTime'
_J='id'
_I='startTime'
_H=True
_G='utf-8'
_F='title'
_E='cookies'
_D='gameDesc'
_C='Get'
_B=False
_A=None
__author__='NightRain'
import urllib,re,json,sys,time,requests,datetime,base64,random
QUALITY_LIST={'stream50':1080,'stream40':720,'stream30':540}
class Spotv:
	def __init__(A):A.SPOTV_PMCODE='987';A.SPOTV_PMSIZE=3;A.GAMELIST_LIMIT=10;A.API_DOMAIN='https://www.spotvnow.co.kr';A.BC_DOMAIN='https://players.brightcove.net';A.PLAYER_DOMAIN='https://edge.api.brightcove.com';A.USER_AGENT='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36';A.DEFAULT_HEADER={'user-agent':A.USER_AGENT};A.COOKIE_FILE_NAME='';A.KodiVersion=20;A.SP_CONTEXTJSON_FILE1='';A.SP_CONTEXTJSON_FILE2='';A.ST={};A.Init_ST_Total()
	def Init_ST_Total(A):A.ST={_R:{},_E:{}}
	def addon_log(F,string):
		A=string
		try:import xbmcaddon as B,xbmc as C;__version__=B.Addon().getAddonInfo('version');__addonid__=B.Addon().getAddonInfo(_J);D=A.encode(_G,'ignore');E=C.LOGINFO;C.log('[%s-%s]: %s'%(__addonid__,__version__,D),level=E)
		except:print(A)
	def callRequestCookies(C,jobtype,url,payload=_A,json=_A,params=_A,headers=_A,cookies=_A,redirects=_B):
		G=redirects;F=cookies;E=headers;D=params;B=C.DEFAULT_HEADER
		if E:B.update(E)
		if jobtype==_C:A=requests.get(url,params=D,headers=B,cookies=F,allow_redirects=G)
		else:A=requests.post(url,data=payload,json=json,params=D,headers=B,cookies=F,allow_redirects=G)
		try:C.addon_log(str(A.status_code)+' : '+A.url)
		except:_A
		return A
	def JsonFile_Save(C,filename,dic):
		A=filename
		if A=='':return _B
		try:B=open(A,'w',-1,_G);json.dump(dic,B,indent=4,ensure_ascii=_B);B.close()
		except:return _B
		return _H
	def JsonFile_Load(D,filename):
		A=filename
		if A=='':return{}
		try:B=open(A,'r',-1,_G);C=json.load(B);B.close()
		except:return{}
		return C
	def TextFile_Save(C,filename,resText):
		A=filename
		if A=='':return _B
		try:B=open(A,'w',-1,_G);B.write(resText);B.close()
		except:return _B
		return _H
	def Save_session_acount(A,stid,stpw):A.ST[_R]['stid']=base64.standard_b64encode(stid.encode()).decode(_G);A.ST[_R]['stpw']=base64.standard_b64encode(stpw.encode()).decode(_G)
	def Load_session_acount(A):
		try:B=base64.standard_b64decode(A.ST[_R]['stid']).decode(_G);C=base64.standard_b64decode(A.ST[_R]['stpw']).decode(_G)
		except:return'',''
		return B,C
	def makeDefaultCookies(A):B={_M:A.ST[_E][_M]};return B
	def makeDefaultHeaders(B):A={'accept':'application/json'};return A
	def xmlText(B,in_text):A=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;');return A
	def GetNoCache(A,timetype=1):
		if timetype==1:return int(time.time())
		else:return int(time.time()*1000)
	def GetCredential_new(A,user_id,user_pw):
		P='endDate';O='subEndTime';N='UTF-8';M='User-Agent';L='Referer';K='location';I=requests.session()
		try:
			C='https://nid.spotvnow.co.kr/api/v3/oauth2/authorize/spotvnow?return_url=https%3A%2F%2Fwww.spotvnow.co.kr%2F&err_return_url=https%3A%2F%2Fwww.spotvnow.co.kr%2Fabout&logout_url=https%3A%2F%2Fwww.spotvnow.co.kr%2Fintro';H={L:'https://www.spotvnow.co.kr/login',M:A.USER_AGENT}
			while C not in['',_A]:
				B=I.get(C,params=_A,headers=H,cookies=A.ST[_E],allow_redirects=_B);C=B.headers.get(K)
				for D in B.cookies:
					if D.value not in['',_A]:A.ST[_E][D.name]=D.value
				if B.status_code==200:break
			if A.ST[_E]['login_challenge']=='':A.Init_ST_Total();return _B
		except Exception as E:print(E);A.Init_ST_Total();return _B
		A.addon_log('login : step 1')
		try:
			Q=base64.standard_b64encode(user_id.encode(N)).decode(_G);R=base64.standard_b64encode(user_pw.encode(N)).decode(_G);C='https://nid.spotvnow.co.kr/api/v3/user-auth/login';H={M:A.USER_AGENT,L:'https://www.spotvnow.co.kr/'};S={'username':Q,'password':R,'remember':_B,'err_return_url':'https://www.spotvnow.co.kr/intro'};B=I.post(C,data=S,params=_A,headers=H,cookies=A.ST[_E],allow_redirects=_B)
			for D in B.cookies:
				if D.value not in['',_A]:A.ST[_E][D.name]=D.value
			C=B.headers.get(K)
			while C not in['',_A]:
				B=I.get(C,params=_A,headers=H,cookies=A.ST[_E],allow_redirects=_B);C=B.headers.get(K)
				for D in B.cookies:
					if D.value not in['',_A]:A.ST[_E][D.name]=D.value
				if B.status_code==200:break
			if A.ST[_E][_M]=='':A.Init_ST_Total();return _B
		except Exception as E:print(E);A.Init_ST_Total();return _B
		A.addon_log('login : step 2')
		try:C=A.API_DOMAIN+'/api/v3/session';J=A.makeDefaultCookies();B=A.callRequestCookies(_C,C,params=_A,headers=_A,cookies=J);G=json.loads(B.text);A.ST[_E][_j]=G.get('userId');F=A.SPOTV_PMCODE+str(G[O]);A.ST[_E][_U]=base64.standard_b64encode(F.encode()).decode(_G)
		except Exception as E:print(E);A.Init_ST_Total();return _B
		A.addon_log('login : step 3')
		try:
			if G[O]in[0,'0',_A]:
				C=A.API_DOMAIN+'/api/v3/user/sub/scope';J=A.makeDefaultCookies();B=A.callRequestCookies(_C,C,params=_A,headers=_A,cookies=J);G=json.loads(B.text)
				if G.get(P)==_A:F=A.SPOTV_PMCODE+'0';A.ST[_E][_U]=base64.standard_b64encode(F.encode()).decode(_G)
				else:T=datetime.datetime.strptime(G.get(P),'%Y-%m-%d %H:%M:%S');F=int(time.mktime(T.timetuple()));F=A.SPOTV_PMCODE+str(F)+'000';A.ST[_E][_U]=base64.standard_b64encode(F.encode()).decode(_G)
		except Exception as E:print(E);A.Init_ST_Total();return _B
		A.addon_log('login : step 4')
		if A.GetPolicyKey()==_B:A.Init_ST_Total();return _B
		'\n\t\thttps://cdn.spotvnow.co.kr/dist/js/6ca348bfe80d471db7ef.js\n  \t\tbc: {\n                accountId: "5764318566001",\n                policyKey: "BCpkADawqM0U3mi_PT566m5lvtapzMq3Uy7ICGGjGB6v4Ske7ZX_ynzj8ePedQJhH36nym_5mbvSYeyyHOOdUsZovyg2XlhV6rRspyYPw_USVNLaR0fB_AAL2HSQlfuetIPiEzbUs1tpNF9NtQxt3BAPvXdOAsvy1ltLPWMVzJHiw9slpLRgI2NUufc"\n            }\t\t\n\t\t';A.addon_log('login : step 5');return _H
	def GetPolicyKey(B):
		F='policyKey';E='accountId'
		try:
			C=B.GetMainJspath()
			if C=='':return _B
			G=B.callRequestCookies(_C,C,payload=_A,params=_A,headers=_A,cookies=_A);H=G.text;A=re.findall('accountId:\\s*"\\d{13}",\\s*policyKey:\\s*".[^(){}]{100,300}"',H)[0];A=A.replace(E,'"accountId"');A=A.replace(F,'"policyKey"');A='{'+A+'}';D=json.loads(A);B.ST[_E]['spotv_accountId']=D[E];B.ST[_E]['spotv_policyKey']=D[F]
		except Exception as I:print(I);return _B
		return _H
	def GetMainJspath(A):
		B=''
		try:C=A.API_DOMAIN;D=A.callRequestCookies(_C,C,payload=_A,params=_A,headers=_A,cookies=_A);E=D.text;F=re.findall('https://cdn.spotvnow.co.kr/dist/js/.{20}\\.js',E)[0];B=F
		except Exception as G:print(G)
		return B
	def Get_Now_Datetime(A):return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),_k))
	def GetLiveChannelList(B):
		E='programName';C=[];D={}
		try:
			F=B.API_DOMAIN+'/api/v3/channel';G=B.callRequestCookies(_C,F,payload=_A,params=_A,headers=_A,cookies=_A);H=json.loads(G.text);D=B.GetEPGList()
			for A in H:I={_J:A[_J],_V:A[_V],_S:A[_S],_X:A[_X],E:A[E],'channelepg':D.get(A[_J])};C.append(I)
		except Exception as J:print(J)
		return C
	def GetHlsUrl(A,mediacode):
		B=''
		try:D='{}/api/v3/channel/di/con/sec/web/{}'.format(A.API_DOMAIN,mediacode);E={_M:A.ST[_E][_M]};F=A.callRequestCookies(_C,D,payload=_A,params=_A,headers=_A,cookies=E);C=json.loads(F.text);B=C[_l];G=C['cid']
		except Exception as H:print(H)
		return G,B
	def GetEPGList(E):
		I='%Y%m%d%H%M';F={};G=E.Get_Now_Datetime();C=G.strftime(I);J='%s-%s-%s'%(C[0:4],C[4:6],C[6:8]);K=(G+datetime.timedelta(hours=4)).strftime(I)
		try:
			L=E.API_DOMAIN+'/api/v3/program/'+J;M=E.callRequestCookies(_C,L,payload=_A,params=_A,headers=_A,cookies=_A);N=json.loads(M.text);D=-1;A=''
			for B in N:
				H=B['channelId'];O=B[_I].replace('-','').replace(' ','').replace(':','');P=B[_K].replace('-','').replace(' ','').replace(':','')
				if int(C)>int(P):continue
				if int(K)<int(O):continue
				if D!=H:
					if A!='':F[D]=A
					D=H;A=''
				if A:A+=_N
				A+=B[_F]+_N;A+=' [%s ~ %s]'%(B[_I][-5:],B[_K][-5:])+_N
			if A:F[D]=A
		except Exception as Q:print(Q)
		return F
	def GetEPGList_new(E):
		P='epgnm';O='epgtype';N='%Y%m%d%H%M00';C={};I=E.Get_Now_Datetime();D=I.strftime(N);J='%s%s%s'%(D[0:4],D[4:6],D[6:8]);Q=(I+datetime.timedelta(hours=4)).strftime(N)
		try:
			for F in LIVETV_LIST:
				G=F[_Y]
				if F[O]=='spotvon':A=E.Get_EpgInfo_Spotv_spotvon(G,F[P],J);C[G]=A
				if F[O]=='spotvnet':A=E.Get_EpgInfo_Spotv_spotvnet(G,F[P],J);C[G]=A
			for H in C.keys():
				if len(C.get(H))==0:continue
				A='';K=''
				for B in C.get(H):
					L=B[_I];M=B[_K]
					if int(D)>int(M):continue
					if int(Q)<int(L):continue
					if int(D)>=int(L)and int(D)<int(M):K=E.xmlText(B[_F])
					if A:A+=_N
					A+=E.xmlText(B[_F])+_N;A+=' [%s:%s ~ %s:%s]'%(B[_I][8:10],B[_I][10:12],B[_K][8:10],B[_K][10:12])+_N
				C[H]={'epg':A,_F:K}
		except Exception as R:print(R)
		return C
	def Get_EpgInfo_Spotv_spotvon(E,channelid,epgnm,now_day):
		D=now_day;A=[]
		try:
			F='https://www.spotvon.co.kr/data/onAir/%s/Daily/D%s.asp'%(epgnm,D);G=E.callRequestCookies(_C,F,payload=_A,params=_A,headers=_A,cookies=_A);H=json.loads(G.text)
			for C in H:I={_F:C[_F],_I:C[_m].replace('-','')+str(C[_n]).zfill(2)+C[_o]+'00'};A.append(I)
			for B in range(len(A)):
				if B>0:A[B-1][_K]=A[B][_I]
				if B==len(A)-1:A[B][_K]=D+_p
		except Exception as J:print(J);return[]
		return A
	def Get_EpgInfo_Spotv_spotvnet(E,channelid,epgnm,now_day):
		D=now_day;A=[]
		try:
			F='https://www.spotv.net/data/json/schedule/%s/Daily/D%s.json'%(epgnm,D);G=E.callRequestCookies(_C,F,payload=_A,params=_A,headers=_A,cookies=_A);H=json.loads(G.text)
			for C in H:I={_F:C[_F],_I:C[_m].replace('-','')+str(C[_n]).zfill(2)+C[_o]+'00'};A.append(I)
			for B in range(len(A)):
				if B>0:A[B-1][_K]=A[B][_I]
				if B==len(A)-1:A[B][_K]=D+_p
		except Exception as J:print(J);return[]
		return A
	def GetEventLiveList(C):
		G='liveId';D=[];B=0
		try:H=C.Get_Now_Datetime();I=H.strftime('%Y-%m-%d')
		except Exception as J:print(J);return D,B
		K=C.API_DOMAIN+'/api/v3/player/lives/'+I;L=C.makeDefaultCookies();E=C.callRequestCookies(_C,K,payload=_A,params=_A,headers=_A,cookies=L);B=E.status_code
		if B!=200:return D,B
		M=json.loads(E.text)
		for N in M:
			for A in N['liveNowList']:
				if A[_D][_F]==_A or A[_D][_F]=='':F='%s ( %s : %s )'%(A['leagueName'],A[_Z],A[_a])
				else:F=A[_D][_F]
				O={G:A[G],_F:F,_S:A[_D]['leagueLogo'],_X:A[_b],_I:A[_I]};D.append(O)
		return D,B
	def GetEventLive_videoId(A,liveId):
		B=''
		try:C=A.API_DOMAIN+'/api/v3/live/'+liveId;D=A.callRequestCookies(_C,C,payload=_A,params=_A,headers=_A,cookies=_A);E=json.loads(D.text);F=E[_Y];B=F.replace('ref:','')
		except Exception as G:print(G)
		return B
	def CheckMainEnd(B):
		A=B.SPOTV_PMCODE+str(B.ST[_E][_j]);A=base64.standard_b64encode(A.encode()).decode(_G)
		if A=='OTg3MTgzMzM0Ng=='or A=='OTg3MTgzMzExNw==':return _H
		return _B
	def CheckSubEnd(A):
		D='%Y%m%d';B=_B
		try:
			if A.CheckMainEnd():return _H
			C=base64.standard_b64decode(A.ST[_E][_U]).decode(_G)[A.SPOTV_PMSIZE:]
			if C=='0':return B
			E=int(A.Get_Now_Datetime().strftime(D));F=int(C)/1000;G=int(datetime.datetime.fromtimestamp(F,datetime.timezone(datetime.timedelta(hours=9),_k)).strftime(D))
			if E<=G:B=_H
		except Exception as H:print(H);return B
		return B
	def GetBroadURL(A,videoId,mediatype,vtypeId):
		D=videoId;B='';C=''
		try:
			if mediatype=='live':E='{}/api/v3/live/di/con/sec/web/{}'.format(A.API_DOMAIN,D);G=A.makeDefaultHeaders();H={_M:A.ST.get(_E).get(_M)};I=A.callRequestCookies(_C,E,payload=_A,params=_A,headers=G,cookies=H);F=json.loads(I.text);A.addon_log(E);B=F[_l];C=F['cid']
			else:B=A.GetReplay_Url(D);C=''
			B=B.replace('http://','https://')
		except Exception as J:print(J)
		return C,B
	def GetTitleGroupList(C):
		D=[];F=C.API_DOMAIN+_q;G=C.callRequestCookies(_C,F,payload=_A,params=_A,headers=_A,cookies=_A);H=json.loads(G.text)
		for A in H:
			if str(A['type'])=='3':
				E=''
				for B in A['data'][_L]:I='[%s] %s vs %s\n<%s>\n\n'%(B[_D][_r],B[_D][_Z],B[_D][_a],B[_D][_c]);E+=I
				J={_F:A[_F],_S:A[_S],'reagueId':str(A[_s]),'subGame':E};D.append(J)
		return D
	def GetPopularGroupList(C):
		D=[];E=C.API_DOMAIN+_q;F=C.callRequestCookies(_C,E,payload=_A,params=_A,headers=_A,cookies=_A);G=json.loads(F.text)
		for B in G:
			if str(B['type'])=='1'and str(B[_s])=='4':
				for A in B['data'][_L]:H=A[_F];I=A[_J];J=A[_d];K=A[_O];L=A[_P];M={_e:H,_f:I,_g:J,_W:K,_P:str(L),_Q:int(A[_Q]/1000)};D.append(M)
		return D
	def Get_NowVod_GroupList(B,page_int):
		C=page_int;D=[];E=_B;G=B.API_DOMAIN+'/api/v3/theme/14/list';H={_t:'10',_u:str(C)};I=B.callRequestCookies(_C,G,payload=_A,params=H,headers=_A,cookies=_A);F=json.loads(I.text)
		for A in F[_L]:
			J=A[_F];K=A[_J];L=A[_d];M=A[_O];N=A[_P];O={_e:J,_f:K,_g:L,_W:M,_P:str(N),_Q:int(A[_Q]/1000)};D.append(O)
			if F[_T]>C*B.GAMELIST_LIMIT:E=_H
		return D,E
	def GetSeasonList(A,leagueId):
		M='reagueName';L='gameTypeId';I=leagueId;G=[];J=H=''
		try:C=A.API_DOMAIN+'/api/v3/game/league/'+I;D=A.callRequestCookies(_C,C,payload=_A,params=_A,headers=_A,cookies=_A);B=json.loads(D.text);J=B[_V];H=str(B[L])
		except Exception as E:print(E);return G
		if H in['2','5','6','8']:
			try:
				C=A.API_DOMAIN+'/api/v3/year/'+I;D=A.callRequestCookies(_C,C,payload=_A,params=_A,headers=_A,cookies=_A);B=json.loads(D.text)
				for F in B:K={M:J,L:H,_h:str(F),_i:str(F)};G.append(K)
			except Exception as E:print(E);return[]
		else:
			try:
				C=A.API_DOMAIN+'/api/v3/season/'+I;D=A.callRequestCookies(_C,C,payload=_A,params=_A,headers=_A,cookies=_A);B=json.loads(D.text)
				for F in B:K={M:J,L:H,_h:F[_V],_i:str(F[_J])};G.append(K)
			except Exception as E:print(E);return[]
		return G
	def GetGameList(G,gameTypeId,leagueId,seasonId,page_int,hidescore=_H):
		X='vods';W='highlightVod';V='replayVod';K=page_int;J=seasonId;B=gameTypeId;L=[];M=_B
		try:
			Y=G.API_DOMAIN+'/api/v3/vod/league/detail';Z={'gameType':B,'leagueId':leagueId,_i:J if B not in['2','5','6','8']else'','teamId':'','roundId':'','year':''if B not in['2','5','6','8']else J,_u:str(K)};a=G.callRequestCookies(_C,Y,payload=_A,params=Z,headers=_A,cookies=_A);N=json.loads(a.text);b=N[_L]
			for c in b:
				for A in c[_L]:
					if A[_D][_F]==_A or A[_D][_F]=='':C='%s vs %s'%(A[_D][_Z],A[_D][_a])
					else:C=A[_D][_F]
					D=A[_D][_c];d=A[_D][_J];H=A[_D]['leagueNameFull'];E=A[_D][_h];I=A[_D][_r];O=A[_D]['homeName'];P=A[_D]['awayName'];e=A[_D]['homeScore'];f=A[_D]['awayScore']
					if hidescore==_H:Q='%s\n - %s (%s)\n - %s\n\nhome : %s\n\naway : %s'%(H,E,I,D,O,P)
					else:Q='%s\n - %s (%s)\n - %s\n\nhome : %s (Score %s)\n\naway : %s (Score %s)'%(H,E,I,D,O,e,P,f)
					R=Q;S=A[V][_T];T=A[W][_T];g=A[X][_T];F='';U=S+T+g
					if U==0:
						if B=='2':C='----- %s -----'%E;D=''
						else:C+=' - 관련영상 없음';R+='\n\n ** 관련영상 없음 **'
					elif S!=0:F=A[V][_L][0][_O]
					elif T!=0:F=A[W][_L][0][_O]
					else:F=A[X][_L][0][_O]
					h={'gameTitle':C,_v:d,_c:D[:11],_W:F,'info_plot':R,'leaguenm':H,'seasonnm':E,'roundnm':I,'totVodCnt':U};L.append(h)
		except Exception as i:print(i)
		if N[_T]>K*G.GAMELIST_LIMIT:M=_H
		return L,M
	def GetGameVodList(B,gameId,vodCount=1000):
		C=[];Q=''
		try:
			D=B.API_DOMAIN+'/api/v3/vod/game';E={_v:gameId,_t:str(vodCount)};F=B.callRequestCookies(_C,D,payload=_A,params=E,headers=_A,cookies=_A);G=json.loads(F.text);H=G[_L]
			for A in H:I=A[_F];J=A[_J];K=A[_d];L=A[_O];M=A[_P];N=A[_b];O={_e:I,_f:J,_g:K,_W:L,_P:str(M),_Q:int(A[_Q]/1000),_b:N};C.append(O)
		except Exception as P:print(P)
		return C
	def GetReplay_UrlId(A,replayId,vtypeId):
		B=''
		try:C=A.API_DOMAIN+_w+replayId;D=A.callRequestCookies(_C,C,payload=_A,params=_A,headers=_A,cookies=_A);E=json.loads(D.text);B=E[_Y]
		except Exception as F:print(F)
		return B
	def GetReplay_Url(A,replayId):
		B=''
		try:C=A.API_DOMAIN+_w+replayId;D=A.callRequestCookies(_C,C,payload=_A,params=_A,headers=_A,cookies=_A);E=json.loads(D.text);B=E['hlsUrl']
		except Exception as F:print(F)
		return B