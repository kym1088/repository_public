_AA='token_limit'
_A9='[B]%s >>[/B]'
_A8='LEAGUE_GROUP'
_A7='%s < %s >'
_A6='VOD_GROUP'
_A5='POP_GROUP'
_A4='-----------------'
_A3='ELIVE_GROUP'
_A2='LIVE_GROUP'
_A1='MYVIEW_REMOVE'
_A0='WATCH_ONE'
_z='WATCH_ALL'
_y='vType'
_x='delType'
_w='account'
_v='GAME_VOD_GROUP'
_u='gameid'
_t='SEASON_GROUP'
_s='POP_VOD'
_r='NOW_VOD'
_q='vodType'
_p='vodId'
_o='vodTitle'
_n='%s\n\n%s'
_m='logo'
_l='NOW_GROUP'
_k='watchedlist_%s.txt'
_j='ELIVE'
_i='seasonId'
_h='gameTypeId'
_g='thumbnail'
_f='path'
_e='code'
_d='LIVE'
_c='saveInfo'
_b='saveImg'
_a='saveTitle'
_Z='episodes'
_Y='utf-8'
_X='list'
_W='int'
_V='XXX'
_U='free'
_T='vod'
_S='mediacode'
_R='reagueId'
_Q='img'
_P='page'
_O='icon'
_N='vtypeId'
_M='duration'
_L='string'
_K='episode'
_J='plot'
_I='utf8'
_H=True
_G='title'
_F='mediatype'
_E=None
_D='type'
_C='func'
_B='mode'
_A=False
__author__='NightRain'
import os,xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs,sys,inputstreamhelper,datetime,time,urllib,base64
__addon__=xbmcaddon.Addon()
__language__=__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
MAIN_GROUP=[{_G:'TV 채널 (유료사용자만 지원)',_B:_A2,_O:'live.png'},{_G:'Live중계 (경기중에만 재생)',_B:_A3,_O:'live.png'},{_G:_A4,_B:_V},{_G:'오늘의 추천 VOD',_B:_l},{_G:'인기영상 5',_B:_A5},{_G:_A4,_B:_V},{_G:'VOD (리그, 경기별)',_B:_A6},{_G:'Watched (시청목록)',_B:'WATCH',_O:'history.png'}]
INFO_CONVERT_KEY={_G:{_C:'setTitle',_D:_L},_J:{_C:'setPlot',_D:_L},'mpaa':{_C:'setMpaa',_D:_L},_F:{_C:'setMediaType',_D:_L},'tvshowtitle':{_C:'setTvShowTitle',_D:_L},'premiered':{_C:'setPremiered',_D:_L},'aired':{_C:'setFirstAired',_D:_L},'year':{_C:'setYear',_D:_W},_M:{_C:'setDuration',_D:_W},_K:{_C:'setEpisode',_D:_W},'season':{_C:'setSeason',_D:_W},'studio':{_C:'setStudios',_D:_X},'genre':{_C:'setGenres',_D:_X},'country':{_C:'setCountries',_D:_X},'cast':{_C:'setCast',_D:'actor'},'director':{_C:'setDirectors',_D:_X}}
COOKIE_FILE_NAME=xbmcvfs.translatePath(os.path.join(__profile__,'spotv_cookies.json'))
from spotvCore import*
class SpotvRun:
	def __init__(self,in_addonurl,in_handle,in_params):self._addon_url=in_addonurl;self._addon_handle=in_handle;self.main_params=in_params;self.SpotvObj=Spotv()
	def addon_noti(self,sting):
		try:dialog=xbmcgui.Dialog();dialog.notification(__addonname__,sting)
		except:_E
	def addon_log(self,string):
		try:log_message=string.encode(_Y,'ignore')
		except:log_message='addonException: addon_log'
		level=xbmc.LOGINFO;xbmc.log('[%s-%s]: %s'%(__addonid__,__version__,log_message),level=level)
	def get_keyboard_input(self,title):
		input_text=_E;kb=xbmc.Keyboard();kb.setHeading(title);xbmc.sleep(1000);kb.doModal()
		if kb.isConfirmed():input_text=kb.getText()
		return input_text
	def get_settings_account(self):uid=__addon__.getSetting('id');pwd=__addon__.getSetting('pw');return uid,pwd
	def get_settings_hidescoreyn(self):
		hidescore=__addon__.getSetting('hidescore')
		if hidescore=='false':return _A
		else:return _H
	def add_dir(self,label,sublabel='',img='',infoLabels=_E,isFolder=_H,params='',isLink=_A,ContextMenu=_E):
		url='%s?%s'%(self._addon_url,urllib.parse.urlencode(params))
		if sublabel:title=_A7%(label,sublabel)
		else:title=label
		if not img:img='DefaultFolder.png'
		listitem=xbmcgui.ListItem(title);listitem.setArt({'thumb':img,_O:img,'poster':img})
		if self.SpotvObj.KodiVersion>=20:
			if infoLabels:self.Set_InfoTag(listitem.getVideoInfoTag(),infoLabels)
		elif infoLabels:listitem.setInfo('Video',infoLabels)
		if not isFolder and not isLink:listitem.setProperty('IsPlayable','true')
		if ContextMenu:listitem.addContextMenuItems(ContextMenu)
		xbmcplugin.addDirectoryItem(self._addon_handle,url,listitem,isFolder)
	def Set_InfoTag(self,video_InfoTag,infoLabels):
		for(key,value)in infoLabels.items():
			if INFO_CONVERT_KEY[key][_D]==_L:getattr(video_InfoTag,INFO_CONVERT_KEY[key][_C])(value)
			elif INFO_CONVERT_KEY[key][_D]==_W:
				if type(value)==int:intValue=int(value)
				else:intValue=0
				getattr(video_InfoTag,INFO_CONVERT_KEY[key][_C])(intValue)
			elif INFO_CONVERT_KEY[key][_D]=='actor':
				if value!=[]:getattr(video_InfoTag,INFO_CONVERT_KEY[key][_C])([xbmc.Actor(name)for name in value])
			elif INFO_CONVERT_KEY[key][_D]==_X:
				if type(value)==list:getattr(video_InfoTag,INFO_CONVERT_KEY[key][_C])(value)
				else:getattr(video_InfoTag,INFO_CONVERT_KEY[key][_C])([value])
	def get_selQuality(self,etype):
		try:quality_type='selected_quality';QT_LIST=[1080,720,540];sel_quality_idx=int(__addon__.getSetting(quality_type));return QT_LIST[sel_quality_idx]
		except:_E
		return 1080
	def dp_Main_List(self):
		for main_group in MAIN_GROUP:
			title=main_group.get(_G);icon_img='';params={_B:main_group.get(_B),_P:'1'}
			if main_group.get(_B)==_V:isFolder=_A;isLink=_H
			else:isFolder=_H;isLink=_A
			infoLabels={_G:title,_J:title}
			if main_group.get(_B)==_V:infoLabels=_E
			if _O in main_group:icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo(_f),_Q,main_group.get(_O))
			self.add_dir(title,sublabel='',img=icon_img,infoLabels=infoLabels,isFolder=isFolder,params=params,isLink=isLink)
		if len(MAIN_GROUP)>0:xbmcplugin.endOfDirectory(self._addon_handle,cacheToDisc=_A)
	def dp_MainLeague_List(self,args):
		self.addon_log('dp_MainLeague_List');GROUP_LIST=self.SpotvObj.GetTitleGroupList();self.addon_log('dp_MainLeague_List cnt : '+str(len(GROUP_LIST)))
		for group_list in GROUP_LIST:title=group_list.get(_G);thumbnail=group_list.get(_m);reagueId=group_list.get(_R);subGame=group_list.get('subGame');info={_F:_K,_J:_n%(title,subGame)};params={_B:_A8,_R:reagueId};self.add_dir(title,sublabel=_E,img=thumbnail,infoLabels=info,isFolder=_H,params=params)
		if len(GROUP_LIST)>0:xbmcplugin.endOfDirectory(self._addon_handle,cacheToDisc=_A)
	def dp_NowVod_GroupList(self,args):
		page_int=int(args.get(_P));self.addon_log('dp_NowVod_GroupList page : '+str(page_int));GROUP_LIST,more_page=self.SpotvObj.Get_NowVod_GroupList(page_int);self.addon_log('dp_NowVod_GroupList cnt : '+str(len(GROUP_LIST)))
		for group_list in GROUP_LIST:vodTitle=group_list.get(_o);vodId=group_list.get(_p);vodType=group_list.get(_q);thumbnail=group_list.get(_g);vtypeId=group_list.get(_N);duration=group_list.get(_M);info={_F:_K,_M:duration,_J:vodTitle};params={_B:_r,_S:vodId,_F:_T,_N:vtypeId};self.add_dir(vodTitle,sublabel=vodType,img=thumbnail,infoLabels=info,isFolder=_A,params=params)
		if more_page:params[_B]=_l;params[_P]=str(page_int+1);title=_A9%'다음 페이지';subtitle=str(page_int+1);icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo(_f),_Q,'next.png');self.add_dir(title,sublabel=subtitle,img=icon_img,infoLabels=_E,isFolder=_H,params=params)
		xbmcplugin.setContent(self._addon_handle,_Z);xbmcplugin.endOfDirectory(self._addon_handle,cacheToDisc=_A)
	def dp_PopVod_GroupList(self,args):
		self.addon_log('dp_PopVod_GroupList ');GROUP_LIST=self.SpotvObj.GetPopularGroupList();self.addon_log('dp_PopVod_GroupList cnt : '+str(len(GROUP_LIST)))
		for group_list in GROUP_LIST:vodTitle=group_list.get(_o);vodId=group_list.get(_p);vodType=group_list.get(_q);thumbnail=group_list.get(_g);vtypeId=group_list.get(_N);duration=group_list.get(_M);info={_F:_K,_M:duration,_J:vodTitle};params={_B:_s,_S:vodId,_F:_T,_N:vtypeId};self.add_dir(vodTitle,sublabel=vodType,img=thumbnail,infoLabels=info,isFolder=_A,params=params)
		xbmcplugin.setContent(self._addon_handle,_Z);xbmcplugin.endOfDirectory(self._addon_handle,cacheToDisc=_A)
	def dp_Season_List(self,args):
		reagueId=args.get(_R);self.addon_log('Season_List - reagueId : '+reagueId);GROUP_LIST=self.SpotvObj.GetSeasonList(reagueId)
		for group_list in GROUP_LIST:reagueName=group_list.get('reagueName');gameTypeId=group_list.get(_h);seasonName=group_list.get('seasonName');seasonId=group_list.get(_i);info={_F:_K,_J:'%s - %s'%(reagueName,seasonName)};params={_B:_t,_R:reagueId,_i:seasonId,_h:gameTypeId,_P:'1'};self.add_dir(reagueName,sublabel=seasonName,img='',infoLabels=info,isFolder=_H,params=params)
		if len(GROUP_LIST)>0:xbmcplugin.endOfDirectory(self._addon_handle,cacheToDisc=_A)
	def dp_Game_List(self,args):
		A='totVodCnt';gameTypeId=args.get(_h);reagueId=args.get(_R);seasonId=args.get(_i);page_int=int(args.get(_P));self.addon_log('Game_List - gameTypeId : '+gameTypeId);self.addon_log('Game_List - reagueId   : '+reagueId);self.addon_log('Game_List - seasonId   : '+seasonId);GROUP_LIST,more_page=self.SpotvObj.GetGameList(gameTypeId,reagueId,seasonId,page_int,hidescore=self.get_settings_hidescoreyn())
		for group_list in GROUP_LIST:gameTitle=group_list.get('gameTitle');beginDate=group_list.get('beginDate');thumbnail=group_list.get(_g);gameId=group_list.get('gameId');totVodCnt=group_list.get(A);leaguenm=group_list.get('leaguenm');seasonnm=group_list.get('seasonnm');roundnm=group_list.get('roundnm');plot=group_list.get('info_plot');saveTitle=_A7%(gameTitle,beginDate);info={_F:'video',_J:plot};params={_B:_v if totVodCnt!=0 else _V,_a:saveTitle,_b:thumbnail,_c:info[_J],_u:gameId,A:totVodCnt};self.add_dir(gameTitle,sublabel=beginDate,img=thumbnail,infoLabels=info,isFolder=_H,params=params)
		if more_page:params[_B]=_t;params[_R]=reagueId;params[_i]=seasonId;params[_h]=gameTypeId;params[_P]=str(page_int+1);title=_A9%'다음 페이지';subtitle=str(page_int+1);icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo(_f),_Q,'next.png');self.add_dir(title,sublabel=subtitle,img=icon_img,infoLabels=_E,isFolder=_H,params=params)
		if len(GROUP_LIST)>0:xbmcplugin.endOfDirectory(self._addon_handle,cacheToDisc=_A)
	def dp_GameVod_List(self,args):
		gameid=args.get(_u);saveTitle=args.get(_a);saveImg=args.get(_b);saveInfo=args.get(_c);GROUP_LIST=self.SpotvObj.GetGameVodList(gameid)
		for group_list in GROUP_LIST:vodTitle=group_list.get(_o);vodId=group_list.get(_p);vodType=group_list.get(_q);thumbnail=group_list.get(_g);vtypeId=group_list.get(_N);duration=group_list.get(_M);info={_F:_K,_M:duration,_J:'%s \n\n %s'%(vodTitle,saveInfo)};params={_B:'GAME_VOD',_a:saveTitle,_b:saveImg,'saveId':gameid,_c:saveInfo,_S:vodId,_F:_T,_N:vtypeId};self.add_dir(vodTitle,sublabel=vodType,img=thumbnail,infoLabels=info,isFolder=_A,params=params)
		xbmcplugin.setContent(self._addon_handle,_Z);xbmcplugin.endOfDirectory(self._addon_handle,cacheToDisc=_A)
	def login_main(self):
		B='TRUE';A='SPOTV_M_LOGINWAIT';spotv_id,spotv_pw=self.get_settings_account()
		if not(spotv_id and spotv_pw):
			dialog=xbmcgui.Dialog();ret=dialog.yesno(__language__(30901).encode(_I),__language__(30902).encode(_I))
			if ret==_H:__addon__.openSettings();sys.exit()
			else:sys.exit()
		if self.cookiefile_check():return
		if xbmcgui.Window(10000).getProperty(A)==B:
			wait_cnt=0
			while _H:
				wait_cnt+=1;time.sleep(.05)
				if wait_cnt>600:return
		else:xbmcgui.Window(10000).setProperty(A,B)
		loginResult=self.SpotvObj.GetCredential_new(spotv_id,spotv_pw)
		if loginResult:self.cookiefile_save()
		xbmcgui.Window(10000).setProperty(A,'FALSE')
		if loginResult==_A:self.addon_noti(__language__(30903).encode(_I));sys.exit()
	def dp_LiveChannel_List(self,args):
		LIVE_LIST=self.SpotvObj.GetLiveChannelList()
		for live_list in LIVE_LIST:
			id=live_list.get('id');title=live_list.get('name');sublabel=live_list.get('programName');thumbnail=live_list.get(_m);channelepg=live_list.get('channelepg');free=live_list.get(_U);info={_J:_n%(title,channelepg),_F:_K};params={_B:_d,_S:id,_U:free,_F:'live'}
			if free:title+=' [free]'
			self.add_dir(title,sublabel=sublabel,img=thumbnail,infoLabels=info,isFolder=_A,params=params)
		xbmcplugin.setContent(self._addon_handle,_Z)
		if len(LIVE_LIST)>0:xbmcplugin.endOfDirectory(self._addon_handle,cacheToDisc=_A)
	def dp_EventLiveChannel_List(self,args):
		LIVE_LIST,returnCode=self.SpotvObj.GetEventLiveList()
		if returnCode!=401 and len(LIVE_LIST)==0:self.addon_noti(__language__(30907).encode(_I))
		for live_list in LIVE_LIST:
			title=live_list.get(_G);sublabel=live_list.get('startTime');thumbnail=live_list.get(_m);free=live_list.get(_U);info={_F:_K,_J:_n%(title,sublabel)};params={_B:_j,_S:live_list.get('liveId'),_U:free,_F:'live'}
			if free:title+=' [free]'
			self.add_dir(title,sublabel=sublabel,img=thumbnail,infoLabels=info,isFolder=_A,params=params)
		xbmcplugin.setContent(self._addon_handle,_Z)
		if len(LIVE_LIST)>0:xbmcplugin.endOfDirectory(self._addon_handle,cacheToDisc=_A)
		return returnCode
	def make_stream_header(self,headers,cookies):
		A='{}={}';cookie_str=''
		if cookies not in[{},_E,'']:
			cookies_cnt=len(cookies)
			for(key,element)in cookies.items():
				cookie_str+=A.format(key,element);cookies_cnt+=-1
				if cookies_cnt>0:cookie_str+='; '
			headers['cookie']=cookie_str
		header_str='';i=0
		for(key,element)in headers.items():
			i=i+1
			if i>1:header_str+='&'
			header_str+=A.format(key,urllib.parse.quote(element))
		return header_str
	def play_VIDEO(self,args):
		C='com.widevine.alpha';B='hls';A='False';mainMode=args.get(_B);mediacode=args.get(_S);mediatype=args.get(_F);vtypeId=args.get(_N)
		if mainMode==_d:
			if args.get(_U)==A:
				if self.SpotvObj.CheckSubEnd()==_A:self.addon_noti(__language__(30908).encode(_I));return
		elif mainMode==_j:
			if args.get(_U)==A:
				if self.SpotvObj.CheckSubEnd()==_A:self.addon_noti(__language__(30908).encode(_I));return
		if mediacode==''or mediacode==_E:self.addon_noti(__language__(30907).encode(_I));return
		if mainMode==_d:cid,streaming_url=self.SpotvObj.GetHlsUrl(mediacode)
		else:self.addon_log('mediacode : '+mediacode);self.addon_log('mediatype : '+mediatype);self.addon_log('vtypeId   : '+str(vtypeId));cid,streaming_url=self.SpotvObj.GetBroadURL(mediacode,mediatype,vtypeId)
		if streaming_url=='':self.addon_noti(__language__(30908).encode(_I));return
		surl=streaming_url
		try:self.addon_log('mainMode  = '+mainMode)
		except:_E
		self.addon_log(surl);item=xbmcgui.ListItem(path=surl)
		if mainMode in[_d,_j]:
			raw_headers={};raw_headers['content-type']='application/octet-stream';raw_headers['user-agent']=self.SpotvObj.USER_AGENT;DRMHOST='https://www.spotvnow.co.kr/drm/widevine/{}/{}'.format(cid,self.SpotvObj.ST['cookies']['spotv_sessionid']);LICENSE_KEY=DRMHOST+'|'+urllib.parse.urlencode(raw_headers)+'|R{SSM}|';stream_headers=self.make_stream_header(raw_headers,_E);self.addon_log(DRMHOST);inputstreamhelper.Helper(B,drm=C).check_inputstream();item.setProperty('inputstream','inputstream.adaptive')
			if self.SpotvObj.KodiVersion<=20:item.setProperty('inputstream.adaptive.manifest_type',B)
			item.setProperty('inputstream.adaptive.license_type',C);item.setProperty('inputstream.adaptive.license_key',LICENSE_KEY);item.setProperty('inputstream.adaptive.stream_headers',stream_headers);item.setProperty('inputstream.adaptive.manifest_headers',stream_headers)
		xbmcplugin.setResolvedUrl(self._addon_handle,_H,item)
		try:
			if mediatype==_T and mainMode not in[_s,_r]:params={_e:args.get('saveId'),_Q:args.get(_b),_G:args.get(_a),'info':args.get(_c)};self.Save_Watched_List(mediatype,params)
		except:_E
	def logout(self):
		dialog=xbmcgui.Dialog();ret=dialog.yesno(__language__(30910).encode(_I),__language__(30905).encode(_I))
		if ret==_A:sys.exit()
		self.SpotvObj.Init_ST_Total()
		if os.path.isfile(COOKIE_FILE_NAME):os.remove(COOKIE_FILE_NAME)
		self.addon_noti(__language__(30909).encode(_Y))
	def cookiefile_save(self):current=self.SpotvObj.Get_Now_Datetime();limit_date=current+datetime.timedelta(days=0);spotv_id,spotv_pw=self.get_settings_account();self.SpotvObj.Save_session_acount(spotv_id,spotv_pw);self.SpotvObj.ST[_w][_AA]=limit_date.strftime('%Y%m%d');self.SpotvObj.JsonFile_Save(COOKIE_FILE_NAME,self.SpotvObj.ST)
	def cookiefile_check(self):
		self.SpotvObj.ST=self.SpotvObj.JsonFile_Load(COOKIE_FILE_NAME)
		if _w not in self.SpotvObj.ST:self.SpotvObj.Init_ST_Total();return _A
		cf_id,cf_pw=self.get_settings_account();ck_id,ck_pw=self.SpotvObj.Load_session_acount()
		if cf_id!=ck_id or cf_pw!=ck_pw:self.SpotvObj.Init_ST_Total();return _A
		if int(self.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))>int(self.SpotvObj.ST[_w][_AA]):self.SpotvObj.Init_ST_Total();return _A
		return _H
	def dp_History_Remove(self,args):
		delType=args.get(_x);sKey=args.get('sKey');vType=args.get(_y);dialog=xbmcgui.Dialog()
		if delType==_z:ret=dialog.yesno(__language__(30904).encode(_I),__language__(30905).encode(_I))
		elif delType==_A0:ret=dialog.yesno(__language__(30911).encode(_I),__language__(30905).encode(_I))
		if ret==_A:sys.exit()
		if delType==_z:
			filename=xbmcvfs.translatePath(os.path.join(__profile__,_k%vType))
			if os.path.isfile(filename):os.remove(filename)
		elif delType==_A0:
			filename=xbmcvfs.translatePath(os.path.join(__profile__,_k%vType))
			try:
				oldlist=self.Load_List_File(vType);fp=open(filename,'w',-1,_Y)
				for olditem in oldlist:
					old_dic=dict(urllib.parse.parse_qsl(olditem));old_skey=old_dic.get(_e).strip()
					if sKey!=old_skey:fp.write(olditem)
				fp.close()
			except:_E
		xbmc.executebuiltin('Container.Refresh')
	def Load_List_File(self,mediatype):
		try:watchfile=xbmcvfs.translatePath(os.path.join(__profile__,_k%mediatype));fp=open(watchfile,'r',-1,_Y);result=fp.readlines();fp.close()
		except:result=[]
		return result
	def Save_Watched_List(self,stype,in_params):
		try:
			watchfile=xbmcvfs.translatePath(os.path.join(__profile__,_k%stype));oldlist=self.Load_List_File(stype);fp=open(watchfile,'w',-1,_Y);newlist=urllib.parse.urlencode(in_params);newlist=newlist+'\n';fp.write(newlist);addcount=0
			for olditem in oldlist:
				old_dic=dict(urllib.parse.parse_qsl(olditem));new_id=in_params.get(_e);old_id=old_dic.get(_e)
				if new_id!=old_id:
					fp.write(olditem);addcount+=1
					if addcount>=50:break
			fp.close()
		except:_E
	def dp_Watch_List(self,args):
		mediatype=_T
		if mediatype==_T:
			WATCHLIST=self.Load_List_File(mediatype)
			for watchlist in WATCHLIST:hist_params=dict(urllib.parse.parse_qsl(watchlist));title=hist_params.get(_G);thumbnail=hist_params.get(_Q);mediacode=hist_params.get(_e);gameinfo=hist_params.get('info');info={};info[_J]=gameinfo;info[_F]='tvshow';params={_B:_v,_u:mediacode,_a:title,_b:thumbnail,_c:gameinfo,_F:mediatype};menu_param={_B:_A1,_x:_A0,'sKey':mediacode,_y:mediatype};menu_param_str=urllib.parse.urlencode(menu_param);ContextMenu=[('선택된 시청이력 ( %s ) 삭제'%title,'RunPlugin(plugin://plugin.video.spotvm/?%s)'%menu_param_str)];self.add_dir(title,sublabel='',img=thumbnail,infoLabels=info,isFolder=_H,params=params,ContextMenu=ContextMenu)
			info={_J:'시청목록을 삭제합니다.'};title='*** 시청목록 삭제 ***';params={_B:_A1,_x:_z,'skey':'-',_y:mediatype};icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo(_f),_Q,'delete.png');self.add_dir(title,sublabel='',img=icon_img,infoLabels=info,isFolder=_A,params=params,isLink=_H);xbmcplugin.endOfDirectory(self._addon_handle,cacheToDisc=_A)
	def spotv_main(self):
		self.SpotvObj.KodiVersion=int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0]);mode=self.main_params.get(_B,_E)
		if mode=='LOGOUT':self.logout();return
		self.login_main()
		if mode is _E:self.dp_Main_List()
		elif mode==_A2:self.dp_LiveChannel_List(self.main_params)
		elif mode==_A3:
			returnCode=self.dp_EventLiveChannel_List(self.main_params)
			if returnCode==401:
				if os.path.isfile(COOKIE_FILE_NAME):os.remove(COOKIE_FILE_NAME)
				self.login_main();self.dp_EventLiveChannel_List(self.main_params)
		elif mode in[_d,'GAME_VOD',_s,_r,_j]:self.play_VIDEO(self.main_params)
		elif mode==_A6:self.dp_MainLeague_List(self.main_params)
		elif mode==_l:self.dp_NowVod_GroupList(self.main_params)
		elif mode==_A5:self.dp_PopVod_GroupList(self.main_params)
		elif mode==_A8:self.dp_Season_List(self.main_params)
		elif mode==_t:self.dp_Game_List(self.main_params)
		elif mode==_v:self.dp_GameVod_List(self.main_params)
		elif mode=='WATCH':self.dp_Watch_List(self.main_params)
		elif mode==_A1:self.dp_History_Remove(self.main_params)
		else:_E