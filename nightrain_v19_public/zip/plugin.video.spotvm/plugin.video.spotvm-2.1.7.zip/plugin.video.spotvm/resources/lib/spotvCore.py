__author__="NightRain"
njkbDgcMYsEuHKtvqQwFhLVmXaOrxB=False
njkbDgcMYsEuHKtvqQwFhLVmXaOrxP=object
njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ=None
njkbDgcMYsEuHKtvqQwFhLVmXaOrxz=print
njkbDgcMYsEuHKtvqQwFhLVmXaOrxi=str
njkbDgcMYsEuHKtvqQwFhLVmXaOrxp=True
njkbDgcMYsEuHKtvqQwFhLVmXaOrxA=Exception
njkbDgcMYsEuHKtvqQwFhLVmXaOrxl=int
njkbDgcMYsEuHKtvqQwFhLVmXaOrxR=len
njkbDgcMYsEuHKtvqQwFhLVmXaOrxS=range
import urllib
import re
import json
import sys
import time
import requests
import datetime
import base64
njkbDgcMYsEuHKtvqQwFhLVmXaOrWd={'stream50':1080,'stream40':720,'stream30':540}
njkbDgcMYsEuHKtvqQwFhLVmXaOrWy=[{'name':'NOW','videoId':'ch_spotvnow1','epgtype':'spotvon','epgnm':'spotvon','free':njkbDgcMYsEuHKtvqQwFhLVmXaOrxB,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/ccdb36ce757afc1ca15fc38357d498e4.png'},{'name':'NOW2','videoId':'ch_spotvnow2','epgtype':'spotvon','epgnm':'spotvon2','free':njkbDgcMYsEuHKtvqQwFhLVmXaOrxB,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/8b6bdf6213a715eeba719b2cb9b2c747.png'},{'name':'NBA TV','videoId':'ch_nbatv','epgtype':'-','epgnm':'-','free':njkbDgcMYsEuHKtvqQwFhLVmXaOrxB,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/5036e56d5c6594ea606f7159f59779fe.png'},{'name':'SPOTV','videoId':'ch_spotv','epgtype':'spotvnet','epgnm':'SPOTV','free':njkbDgcMYsEuHKtvqQwFhLVmXaOrxB,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/56688c2e527c6e1b8d68e338057a7dfc.png'},{'name':'SPOTV2','videoId':'ch_spotv2','epgtype':'spotvnet','epgnm':'SPOTV2','free':njkbDgcMYsEuHKtvqQwFhLVmXaOrxB,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20201209/ca6e7a213c84e629985e609ddcda6b17.png'},{'name':'SPOTV Golf & Health','videoId':'ch_spotvplus','epgtype':'spotvnet','epgnm':'SPOTVP','free':njkbDgcMYsEuHKtvqQwFhLVmXaOrxB,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/7aa87953f1211313c3e110cace2628ff.png'},]
njkbDgcMYsEuHKtvqQwFhLVmXaOrWx={'ch_spotvnow1':{'lv':'abf18bbf3b3f4a0db4a41dd2af7f75c6','rv':'__nn__=5981484117001&hdnea=st=1609407000~exp=1609410600~acl=/abf18bbf3b3f4a0db4a41dd2af7f75c6/ap-northeast-1/5764318566001/*~hmac=e28a244d1b6b77d4e0101010816d4cd6ca89d9d31fe6a5290039d2395d81bc03'},'ch_spotvnow2':{'lv':'3054522000fc4d60aabe23d6e5911275','rv':'__nn__=5981484117001&hdnea=st=1609408800~exp=1609412400~acl=/3054522000fc4d60aabe23d6e5911275/ap-northeast-1/5764318566001/*~hmac=323b2deea8e3455fa77405f37b19231c6f0b48a5690b7218df875171ac2d6be6'},'ch_nbatv':{'lv':'31f99a0a6067413ea1b390c41a5c12be','rv':'__nn__=5981484117001&hdnea=st=1609408800~exp=1609412400~acl=/31f99a0a6067413ea1b390c41a5c12be/ap-northeast-1/5764318566001/*~hmac=b7ac24bc4772e3ad2669000919058bba64a6f001c69c8846341c326b089c306c'},'ch_spotv':{'lv':'1f2651c2fea34be9850bfdedf8d9cfdb','rv':'__nn__=5981484117001&hdnea=st=1609408800~exp=1609412400~acl=/1f2651c2fea34be9850bfdedf8d9cfdb/ap-northeast-1/5764318566001/*~hmac=e1f6c44d1be5459cfc40af1e1b204ac9b513bb7405e070da2bff8f115f298133'},'ch_spotv2':{'lv':'7bf3fb8685854892b01e1fc897e7e9b0','rv':'__nn__=5981484117001&hdnea=st=1609408800~exp=1609412400~acl=/7bf3fb8685854892b01e1fc897e7e9b0/ap-northeast-1/5764318566001/*~hmac=e9bb30991cfab98b1976aacabafcd51b63769ede40148f7cc289ffed15398e81'},'ch_spotvplus':{'lv':'242b2b6c0c654f47a07f4e2420f9c184','rv':'__nn__=5981484117001&hdnea=st=1609408800~exp=1609412400~acl=/242b2b6c0c654f47a07f4e2420f9c184/ap-northeast-1/5764318566001/*~hmac=5e4ce0553e709eb60d880bf37bc2e99661767b0a38ecee037fb4d7dce757b922'},}
class njkbDgcMYsEuHKtvqQwFhLVmXaOrWo(njkbDgcMYsEuHKtvqQwFhLVmXaOrxP):
 def __init__(njkbDgcMYsEuHKtvqQwFhLVmXaOrWI):
  njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.SPOTV_SESSIONID=''
  njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.SPOTV_SESSION =''
  njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.SPOTV_ACCOUNTID=''
  njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.SPOTV_POLICYKEY=''
  njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.SPOTV_SUBEND =''
  njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.SPOTV_PMCODE ='987'
  njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.SPOTV_PMSIZE =3
  njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.GAMELIST_LIMIT =10
  njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.API_DOMAIN ='https://www.spotvnow.co.kr'
  njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.BC_DOMAIN ='https://players.brightcove.net'
  njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.PLAYER_DOMAIN ='https://edge.api.brightcove.com'
  njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.STREAM_DOMAIN ='https://gtm-spotv.brightcovecdn.com'
  njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.STREAM_M3U8 ='ap-northeast-1/5764318566001/playlist_dvr'
  njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36'
  njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.DEFAULT_HEADER ={'user-agent':njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.USER_AGENT}
 def callRequestCookies(njkbDgcMYsEuHKtvqQwFhLVmXaOrWI,jobtype,njkbDgcMYsEuHKtvqQwFhLVmXaOroC,payload=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,params=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,headers=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,cookies=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,redirects=njkbDgcMYsEuHKtvqQwFhLVmXaOrxB):
  njkbDgcMYsEuHKtvqQwFhLVmXaOrWe=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.DEFAULT_HEADER
  if headers:njkbDgcMYsEuHKtvqQwFhLVmXaOrWe.update(headers)
  if jobtype=='Get':
   njkbDgcMYsEuHKtvqQwFhLVmXaOrWU=requests.get(njkbDgcMYsEuHKtvqQwFhLVmXaOroC,params=params,headers=njkbDgcMYsEuHKtvqQwFhLVmXaOrWe,cookies=cookies,allow_redirects=redirects)
  else:
   njkbDgcMYsEuHKtvqQwFhLVmXaOrWU=requests.post(njkbDgcMYsEuHKtvqQwFhLVmXaOroC,data=payload,params=params,headers=njkbDgcMYsEuHKtvqQwFhLVmXaOrWe,cookies=cookies,allow_redirects=redirects)
  return njkbDgcMYsEuHKtvqQwFhLVmXaOrWU
 def makeDefaultCookies(njkbDgcMYsEuHKtvqQwFhLVmXaOrWI):
  njkbDgcMYsEuHKtvqQwFhLVmXaOrWC={'SESSION':njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.SPOTV_SESSION}
  return njkbDgcMYsEuHKtvqQwFhLVmXaOrWC
 def xmlText(njkbDgcMYsEuHKtvqQwFhLVmXaOrWI,in_text):
  njkbDgcMYsEuHKtvqQwFhLVmXaOrWG=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;')
  return njkbDgcMYsEuHKtvqQwFhLVmXaOrWG
 def GetCredential(njkbDgcMYsEuHKtvqQwFhLVmXaOrWI,user_id,user_pw):
  njkbDgcMYsEuHKtvqQwFhLVmXaOrWf=njkbDgcMYsEuHKtvqQwFhLVmXaOrxB
  njkbDgcMYsEuHKtvqQwFhLVmXaOrWT=njkbDgcMYsEuHKtvqQwFhLVmXaOrWp=njkbDgcMYsEuHKtvqQwFhLVmXaOrWR=njkbDgcMYsEuHKtvqQwFhLVmXaOrWS=njkbDgcMYsEuHKtvqQwFhLVmXaOrWl=''
  try:
   njkbDgcMYsEuHKtvqQwFhLVmXaOrWN=base64.standard_b64encode(user_id.encode("UTF-8")).decode('utf-8')
   njkbDgcMYsEuHKtvqQwFhLVmXaOrWB=base64.standard_b64encode(user_pw.encode("UTF-8")).decode('utf-8')
   njkbDgcMYsEuHKtvqQwFhLVmXaOrWP=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.API_DOMAIN+'/api/v2/login'
   njkbDgcMYsEuHKtvqQwFhLVmXaOrWJ={'username':njkbDgcMYsEuHKtvqQwFhLVmXaOrWN,'password':njkbDgcMYsEuHKtvqQwFhLVmXaOrWB}
   njkbDgcMYsEuHKtvqQwFhLVmXaOrWJ=json.dumps(njkbDgcMYsEuHKtvqQwFhLVmXaOrWJ)
   njkbDgcMYsEuHKtvqQwFhLVmXaOrWz=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.callRequestCookies('Post',njkbDgcMYsEuHKtvqQwFhLVmXaOrWP,payload=njkbDgcMYsEuHKtvqQwFhLVmXaOrWJ,params=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,headers=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,cookies=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ)
   njkbDgcMYsEuHKtvqQwFhLVmXaOrxz(njkbDgcMYsEuHKtvqQwFhLVmXaOrWz.status_code)
   for njkbDgcMYsEuHKtvqQwFhLVmXaOrWi in njkbDgcMYsEuHKtvqQwFhLVmXaOrWz.cookies:
    if njkbDgcMYsEuHKtvqQwFhLVmXaOrWi.name=='SESSION':
     njkbDgcMYsEuHKtvqQwFhLVmXaOrWp=njkbDgcMYsEuHKtvqQwFhLVmXaOrWi.value
     break
   if njkbDgcMYsEuHKtvqQwFhLVmXaOrWp=='':return njkbDgcMYsEuHKtvqQwFhLVmXaOrWf
   njkbDgcMYsEuHKtvqQwFhLVmXaOrWA=json.loads(njkbDgcMYsEuHKtvqQwFhLVmXaOrWz.text)
   if not('userId' in njkbDgcMYsEuHKtvqQwFhLVmXaOrWA):return njkbDgcMYsEuHKtvqQwFhLVmXaOrWf
   njkbDgcMYsEuHKtvqQwFhLVmXaOrWT=njkbDgcMYsEuHKtvqQwFhLVmXaOrxi(njkbDgcMYsEuHKtvqQwFhLVmXaOrWA['userId'])
   njkbDgcMYsEuHKtvqQwFhLVmXaOrWl =njkbDgcMYsEuHKtvqQwFhLVmXaOrxi(njkbDgcMYsEuHKtvqQwFhLVmXaOrWA['subEndTime'])
   njkbDgcMYsEuHKtvqQwFhLVmXaOrWR,njkbDgcMYsEuHKtvqQwFhLVmXaOrWS=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.GetPolicyKey()
   if njkbDgcMYsEuHKtvqQwFhLVmXaOrWS=='':return njkbDgcMYsEuHKtvqQwFhLVmXaOrWf
   njkbDgcMYsEuHKtvqQwFhLVmXaOrWf=njkbDgcMYsEuHKtvqQwFhLVmXaOrxp
  except njkbDgcMYsEuHKtvqQwFhLVmXaOrxA as exception:
   njkbDgcMYsEuHKtvqQwFhLVmXaOrWT=njkbDgcMYsEuHKtvqQwFhLVmXaOrWp='' 
   njkbDgcMYsEuHKtvqQwFhLVmXaOrxz(exception)
  njkbDgcMYsEuHKtvqQwFhLVmXaOroW={'spotv_sessionid':njkbDgcMYsEuHKtvqQwFhLVmXaOrWT,'spotv_session':njkbDgcMYsEuHKtvqQwFhLVmXaOrWp,'spotv_accountId':njkbDgcMYsEuHKtvqQwFhLVmXaOrWR,'spotv_policyKey':njkbDgcMYsEuHKtvqQwFhLVmXaOrWS,'spotv_subend':njkbDgcMYsEuHKtvqQwFhLVmXaOrWl}
  njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.SaveCredential(njkbDgcMYsEuHKtvqQwFhLVmXaOroW)
  return njkbDgcMYsEuHKtvqQwFhLVmXaOrWf
 def SaveCredential(njkbDgcMYsEuHKtvqQwFhLVmXaOrWI,njkbDgcMYsEuHKtvqQwFhLVmXaOroW):
  njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.SPOTV_SESSIONID=njkbDgcMYsEuHKtvqQwFhLVmXaOroW.get('spotv_sessionid')
  njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.SPOTV_SESSION =njkbDgcMYsEuHKtvqQwFhLVmXaOroW.get('spotv_session')
  njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.SPOTV_ACCOUNTID=njkbDgcMYsEuHKtvqQwFhLVmXaOroW.get('spotv_accountId')
  njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.SPOTV_POLICYKEY=njkbDgcMYsEuHKtvqQwFhLVmXaOroW.get('spotv_policyKey')
  njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.SPOTV_SUBEND =njkbDgcMYsEuHKtvqQwFhLVmXaOroW.get('spotv_subend')
 def LoadCredential(njkbDgcMYsEuHKtvqQwFhLVmXaOrWI):
  njkbDgcMYsEuHKtvqQwFhLVmXaOroW={'spotv_sessionid':njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.SPOTV_SESSIONID,'spotv_session':njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.SPOTV_SESSION,'spotv_accountId':njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.SPOTV_ACCOUNTID,'spotv_policyKey':njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.SPOTV_POLICYKEY,'spotv_subend':njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.SPOTV_SUBEND}
  return njkbDgcMYsEuHKtvqQwFhLVmXaOroW
 def Get_Now_Datetime(njkbDgcMYsEuHKtvqQwFhLVmXaOrWI):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_Streamurl_Make(njkbDgcMYsEuHKtvqQwFhLVmXaOrWI,njkbDgcMYsEuHKtvqQwFhLVmXaOrdU):
  njkbDgcMYsEuHKtvqQwFhLVmXaOroy='%s/%s/%s.m3u8?%s'%(njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.STREAM_DOMAIN,njkbDgcMYsEuHKtvqQwFhLVmXaOrWx.get(njkbDgcMYsEuHKtvqQwFhLVmXaOrdU).get('lv'),njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.STREAM_M3U8,njkbDgcMYsEuHKtvqQwFhLVmXaOrWx.get(njkbDgcMYsEuHKtvqQwFhLVmXaOrdU).get('rv'))
  return njkbDgcMYsEuHKtvqQwFhLVmXaOroy
 def GetLiveChannelList(njkbDgcMYsEuHKtvqQwFhLVmXaOrWI):
  njkbDgcMYsEuHKtvqQwFhLVmXaOrox=[]
  njkbDgcMYsEuHKtvqQwFhLVmXaOroI ={}
  try:
   njkbDgcMYsEuHKtvqQwFhLVmXaOroI=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.GetEPGList_new()
   for njkbDgcMYsEuHKtvqQwFhLVmXaOroe in njkbDgcMYsEuHKtvqQwFhLVmXaOrWy:
    njkbDgcMYsEuHKtvqQwFhLVmXaOroU={'name':njkbDgcMYsEuHKtvqQwFhLVmXaOroe['name'],'logo':njkbDgcMYsEuHKtvqQwFhLVmXaOroe['logo'],'videoId':njkbDgcMYsEuHKtvqQwFhLVmXaOroe['videoId'],'free':njkbDgcMYsEuHKtvqQwFhLVmXaOroe['free'],'channelepg':njkbDgcMYsEuHKtvqQwFhLVmXaOroI.get(njkbDgcMYsEuHKtvqQwFhLVmXaOroe['videoId'])}
    njkbDgcMYsEuHKtvqQwFhLVmXaOrox.append(njkbDgcMYsEuHKtvqQwFhLVmXaOroU)
  except njkbDgcMYsEuHKtvqQwFhLVmXaOrxA as exception:
   njkbDgcMYsEuHKtvqQwFhLVmXaOrxz(exception)
  return njkbDgcMYsEuHKtvqQwFhLVmXaOrox
 def CheckLiveChannel(njkbDgcMYsEuHKtvqQwFhLVmXaOrWI,njkbDgcMYsEuHKtvqQwFhLVmXaOroA):
  try:
   njkbDgcMYsEuHKtvqQwFhLVmXaOroC=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.API_DOMAIN+'/api/v2/channel'
   njkbDgcMYsEuHKtvqQwFhLVmXaOrWz=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.callRequestCookies('Get',njkbDgcMYsEuHKtvqQwFhLVmXaOroC,payload=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,params=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,headers=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,cookies=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ)
   njkbDgcMYsEuHKtvqQwFhLVmXaOrWA=json.loads(njkbDgcMYsEuHKtvqQwFhLVmXaOrWz.text)
   for njkbDgcMYsEuHKtvqQwFhLVmXaOroe in njkbDgcMYsEuHKtvqQwFhLVmXaOrWA:
    if njkbDgcMYsEuHKtvqQwFhLVmXaOroe['videoId'].replace('ref:','')==njkbDgcMYsEuHKtvqQwFhLVmXaOroA:
     return njkbDgcMYsEuHKtvqQwFhLVmXaOroe['free']
  except njkbDgcMYsEuHKtvqQwFhLVmXaOrxA as exception:
   njkbDgcMYsEuHKtvqQwFhLVmXaOrxz(exception)
  return njkbDgcMYsEuHKtvqQwFhLVmXaOrxB
 def GetEPGList(njkbDgcMYsEuHKtvqQwFhLVmXaOrWI):
  njkbDgcMYsEuHKtvqQwFhLVmXaOroG={}
  njkbDgcMYsEuHKtvqQwFhLVmXaOrof=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.Get_Now_Datetime()
  njkbDgcMYsEuHKtvqQwFhLVmXaOroT=njkbDgcMYsEuHKtvqQwFhLVmXaOrof.strftime('%Y%m%d%H%M')
  njkbDgcMYsEuHKtvqQwFhLVmXaOroN='%s-%s-%s'%(njkbDgcMYsEuHKtvqQwFhLVmXaOroT[0:4],njkbDgcMYsEuHKtvqQwFhLVmXaOroT[4:6],njkbDgcMYsEuHKtvqQwFhLVmXaOroT[6:8])
  njkbDgcMYsEuHKtvqQwFhLVmXaOroB=(njkbDgcMYsEuHKtvqQwFhLVmXaOrof+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M')
  try:
   njkbDgcMYsEuHKtvqQwFhLVmXaOroC=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.API_DOMAIN+'/api/v2/program/'+njkbDgcMYsEuHKtvqQwFhLVmXaOroN
   njkbDgcMYsEuHKtvqQwFhLVmXaOrWz=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.callRequestCookies('Get',njkbDgcMYsEuHKtvqQwFhLVmXaOroC,payload=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,params=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,headers=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,cookies=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ)
   njkbDgcMYsEuHKtvqQwFhLVmXaOrWA=json.loads(njkbDgcMYsEuHKtvqQwFhLVmXaOrWz.text)
   njkbDgcMYsEuHKtvqQwFhLVmXaOroP=-1 
   njkbDgcMYsEuHKtvqQwFhLVmXaOroJ =''
   for njkbDgcMYsEuHKtvqQwFhLVmXaOroe in njkbDgcMYsEuHKtvqQwFhLVmXaOrWA:
    njkbDgcMYsEuHKtvqQwFhLVmXaOroz=njkbDgcMYsEuHKtvqQwFhLVmXaOroe['channelId']
    njkbDgcMYsEuHKtvqQwFhLVmXaOroi =njkbDgcMYsEuHKtvqQwFhLVmXaOroe['startTime'].replace('-','').replace(' ','').replace(':','')
    njkbDgcMYsEuHKtvqQwFhLVmXaOrop =njkbDgcMYsEuHKtvqQwFhLVmXaOroe['endTime'].replace('-','').replace(' ','').replace(':','')
    if njkbDgcMYsEuHKtvqQwFhLVmXaOrxl(njkbDgcMYsEuHKtvqQwFhLVmXaOroT)>njkbDgcMYsEuHKtvqQwFhLVmXaOrxl(njkbDgcMYsEuHKtvqQwFhLVmXaOrop) :continue
    if njkbDgcMYsEuHKtvqQwFhLVmXaOrxl(njkbDgcMYsEuHKtvqQwFhLVmXaOroB)<njkbDgcMYsEuHKtvqQwFhLVmXaOrxl(njkbDgcMYsEuHKtvqQwFhLVmXaOroi):continue
    if njkbDgcMYsEuHKtvqQwFhLVmXaOroP!=njkbDgcMYsEuHKtvqQwFhLVmXaOroz:
     if njkbDgcMYsEuHKtvqQwFhLVmXaOroJ!='':njkbDgcMYsEuHKtvqQwFhLVmXaOroG[njkbDgcMYsEuHKtvqQwFhLVmXaOroP]=njkbDgcMYsEuHKtvqQwFhLVmXaOroJ
     njkbDgcMYsEuHKtvqQwFhLVmXaOroP=njkbDgcMYsEuHKtvqQwFhLVmXaOroz
     njkbDgcMYsEuHKtvqQwFhLVmXaOroJ =''
    if njkbDgcMYsEuHKtvqQwFhLVmXaOroJ:njkbDgcMYsEuHKtvqQwFhLVmXaOroJ+='\n'
    njkbDgcMYsEuHKtvqQwFhLVmXaOroJ+=njkbDgcMYsEuHKtvqQwFhLVmXaOroe['title']+'\n'
    njkbDgcMYsEuHKtvqQwFhLVmXaOroJ+=' [%s ~ %s]'%(njkbDgcMYsEuHKtvqQwFhLVmXaOroe['startTime'][-5:],njkbDgcMYsEuHKtvqQwFhLVmXaOroe['endTime'][-5:])+'\n'
   if njkbDgcMYsEuHKtvqQwFhLVmXaOroJ:njkbDgcMYsEuHKtvqQwFhLVmXaOroG[njkbDgcMYsEuHKtvqQwFhLVmXaOroP]=njkbDgcMYsEuHKtvqQwFhLVmXaOroJ
  except njkbDgcMYsEuHKtvqQwFhLVmXaOrxA as exception:
   njkbDgcMYsEuHKtvqQwFhLVmXaOrxz(exception)
  return njkbDgcMYsEuHKtvqQwFhLVmXaOroG
 def GetEPGList_new(njkbDgcMYsEuHKtvqQwFhLVmXaOrWI):
  njkbDgcMYsEuHKtvqQwFhLVmXaOroG={}
  njkbDgcMYsEuHKtvqQwFhLVmXaOrof=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.Get_Now_Datetime()
  njkbDgcMYsEuHKtvqQwFhLVmXaOroT=njkbDgcMYsEuHKtvqQwFhLVmXaOrof.strftime('%Y%m%d%H%M00')
  njkbDgcMYsEuHKtvqQwFhLVmXaOroN='%s%s%s'%(njkbDgcMYsEuHKtvqQwFhLVmXaOroT[0:4],njkbDgcMYsEuHKtvqQwFhLVmXaOroT[4:6],njkbDgcMYsEuHKtvqQwFhLVmXaOroT[6:8])
  njkbDgcMYsEuHKtvqQwFhLVmXaOroB=(njkbDgcMYsEuHKtvqQwFhLVmXaOrof+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M00')
  try:
   for njkbDgcMYsEuHKtvqQwFhLVmXaOroe in njkbDgcMYsEuHKtvqQwFhLVmXaOrWy:
    njkbDgcMYsEuHKtvqQwFhLVmXaOroA =njkbDgcMYsEuHKtvqQwFhLVmXaOroe['videoId']
    if njkbDgcMYsEuHKtvqQwFhLVmXaOroe['epgtype']=='spotvon':
     njkbDgcMYsEuHKtvqQwFhLVmXaOroJ=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.Get_EpgInfo_Spotv_spotvon(njkbDgcMYsEuHKtvqQwFhLVmXaOroA,njkbDgcMYsEuHKtvqQwFhLVmXaOroe['epgnm'],njkbDgcMYsEuHKtvqQwFhLVmXaOroN)
     njkbDgcMYsEuHKtvqQwFhLVmXaOroG[njkbDgcMYsEuHKtvqQwFhLVmXaOroA]=njkbDgcMYsEuHKtvqQwFhLVmXaOroJ
    if njkbDgcMYsEuHKtvqQwFhLVmXaOroe['epgtype']=='spotvnet':
     njkbDgcMYsEuHKtvqQwFhLVmXaOroJ=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.Get_EpgInfo_Spotv_spotvnet(njkbDgcMYsEuHKtvqQwFhLVmXaOroA,njkbDgcMYsEuHKtvqQwFhLVmXaOroe['epgnm'],njkbDgcMYsEuHKtvqQwFhLVmXaOroN)
     njkbDgcMYsEuHKtvqQwFhLVmXaOroG[njkbDgcMYsEuHKtvqQwFhLVmXaOroA]=njkbDgcMYsEuHKtvqQwFhLVmXaOroJ
   for njkbDgcMYsEuHKtvqQwFhLVmXaOrol in njkbDgcMYsEuHKtvqQwFhLVmXaOroG.keys():
    if njkbDgcMYsEuHKtvqQwFhLVmXaOrxR(njkbDgcMYsEuHKtvqQwFhLVmXaOroG.get(njkbDgcMYsEuHKtvqQwFhLVmXaOrol))==0:continue
    njkbDgcMYsEuHKtvqQwFhLVmXaOroJ =''
    njkbDgcMYsEuHKtvqQwFhLVmXaOroR=''
    for njkbDgcMYsEuHKtvqQwFhLVmXaOroS in njkbDgcMYsEuHKtvqQwFhLVmXaOroG.get(njkbDgcMYsEuHKtvqQwFhLVmXaOrol):
     njkbDgcMYsEuHKtvqQwFhLVmXaOroi =njkbDgcMYsEuHKtvqQwFhLVmXaOroS['startTime']
     njkbDgcMYsEuHKtvqQwFhLVmXaOrop =njkbDgcMYsEuHKtvqQwFhLVmXaOroS['endTime']
     if njkbDgcMYsEuHKtvqQwFhLVmXaOrxl(njkbDgcMYsEuHKtvqQwFhLVmXaOroT)>njkbDgcMYsEuHKtvqQwFhLVmXaOrxl(njkbDgcMYsEuHKtvqQwFhLVmXaOrop) :continue
     if njkbDgcMYsEuHKtvqQwFhLVmXaOrxl(njkbDgcMYsEuHKtvqQwFhLVmXaOroB)<njkbDgcMYsEuHKtvqQwFhLVmXaOrxl(njkbDgcMYsEuHKtvqQwFhLVmXaOroi):continue
     if njkbDgcMYsEuHKtvqQwFhLVmXaOrxl(njkbDgcMYsEuHKtvqQwFhLVmXaOroT)>=njkbDgcMYsEuHKtvqQwFhLVmXaOrxl(njkbDgcMYsEuHKtvqQwFhLVmXaOroi)and njkbDgcMYsEuHKtvqQwFhLVmXaOrxl(njkbDgcMYsEuHKtvqQwFhLVmXaOroT)<njkbDgcMYsEuHKtvqQwFhLVmXaOrxl(njkbDgcMYsEuHKtvqQwFhLVmXaOrop):njkbDgcMYsEuHKtvqQwFhLVmXaOroR=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.xmlText(njkbDgcMYsEuHKtvqQwFhLVmXaOroS['title'])
     if njkbDgcMYsEuHKtvqQwFhLVmXaOroJ:njkbDgcMYsEuHKtvqQwFhLVmXaOroJ+='\n'
     njkbDgcMYsEuHKtvqQwFhLVmXaOroJ+=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.xmlText(njkbDgcMYsEuHKtvqQwFhLVmXaOroS['title'])+'\n'
     njkbDgcMYsEuHKtvqQwFhLVmXaOroJ+=' [%s:%s ~ %s:%s]'%(njkbDgcMYsEuHKtvqQwFhLVmXaOroS['startTime'][8:10],njkbDgcMYsEuHKtvqQwFhLVmXaOroS['startTime'][10:12],njkbDgcMYsEuHKtvqQwFhLVmXaOroS['endTime'][8:10],njkbDgcMYsEuHKtvqQwFhLVmXaOroS['endTime'][10:12])+'\n'
    njkbDgcMYsEuHKtvqQwFhLVmXaOroG[njkbDgcMYsEuHKtvqQwFhLVmXaOrol]={'epg':njkbDgcMYsEuHKtvqQwFhLVmXaOroJ,'title':njkbDgcMYsEuHKtvqQwFhLVmXaOroR}
  except njkbDgcMYsEuHKtvqQwFhLVmXaOrxA as exception:
   njkbDgcMYsEuHKtvqQwFhLVmXaOrxz(exception)
  return njkbDgcMYsEuHKtvqQwFhLVmXaOroG
 def Get_EpgInfo_Spotv_spotvon(njkbDgcMYsEuHKtvqQwFhLVmXaOrWI,njkbDgcMYsEuHKtvqQwFhLVmXaOroA,epgnm,now_day):
  njkbDgcMYsEuHKtvqQwFhLVmXaOroG =[]
  try:
   njkbDgcMYsEuHKtvqQwFhLVmXaOroC='https://www.spotvon.co.kr/data/onAir/%s/Daily/D%s.asp'%(epgnm,now_day)
   njkbDgcMYsEuHKtvqQwFhLVmXaOrWz=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.callRequestCookies('Get',njkbDgcMYsEuHKtvqQwFhLVmXaOroC,payload=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,params=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,headers=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,cookies=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ)
   njkbDgcMYsEuHKtvqQwFhLVmXaOrdW=json.loads(njkbDgcMYsEuHKtvqQwFhLVmXaOrWz.text)
   for njkbDgcMYsEuHKtvqQwFhLVmXaOroe in njkbDgcMYsEuHKtvqQwFhLVmXaOrdW:
    njkbDgcMYsEuHKtvqQwFhLVmXaOroU={'title':njkbDgcMYsEuHKtvqQwFhLVmXaOroe['title'],'startTime':njkbDgcMYsEuHKtvqQwFhLVmXaOroe['sch_date'].replace('-','')+njkbDgcMYsEuHKtvqQwFhLVmXaOrxi(njkbDgcMYsEuHKtvqQwFhLVmXaOroe['sch_hour']).zfill(2)+njkbDgcMYsEuHKtvqQwFhLVmXaOroe['sch_min']+'00'}
    njkbDgcMYsEuHKtvqQwFhLVmXaOroG.append(njkbDgcMYsEuHKtvqQwFhLVmXaOroU)
   for i in njkbDgcMYsEuHKtvqQwFhLVmXaOrxS(njkbDgcMYsEuHKtvqQwFhLVmXaOrxR(njkbDgcMYsEuHKtvqQwFhLVmXaOroG)):
    if i>0:njkbDgcMYsEuHKtvqQwFhLVmXaOroG[i-1]['endTime']=njkbDgcMYsEuHKtvqQwFhLVmXaOroG[i]['startTime']
    if i==njkbDgcMYsEuHKtvqQwFhLVmXaOrxR(njkbDgcMYsEuHKtvqQwFhLVmXaOroG)-1: njkbDgcMYsEuHKtvqQwFhLVmXaOroG[i]['endTime']=now_day+'240000'
  except njkbDgcMYsEuHKtvqQwFhLVmXaOrxA as exception:
   njkbDgcMYsEuHKtvqQwFhLVmXaOrxz(exception)
   return[]
  return njkbDgcMYsEuHKtvqQwFhLVmXaOroG
 def Get_EpgInfo_Spotv_spotvnet(njkbDgcMYsEuHKtvqQwFhLVmXaOrWI,njkbDgcMYsEuHKtvqQwFhLVmXaOroA,epgnm,now_day):
  njkbDgcMYsEuHKtvqQwFhLVmXaOroG =[]
  try:
   njkbDgcMYsEuHKtvqQwFhLVmXaOroC='https://www.spotv.net/data/json/schedule/%s/Daily/D%s.json'%(epgnm,now_day)
   njkbDgcMYsEuHKtvqQwFhLVmXaOrWz=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.callRequestCookies('Get',njkbDgcMYsEuHKtvqQwFhLVmXaOroC,payload=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,params=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,headers=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,cookies=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ)
   njkbDgcMYsEuHKtvqQwFhLVmXaOrdW=json.loads(njkbDgcMYsEuHKtvqQwFhLVmXaOrWz.text)
   for njkbDgcMYsEuHKtvqQwFhLVmXaOroe in njkbDgcMYsEuHKtvqQwFhLVmXaOrdW:
    njkbDgcMYsEuHKtvqQwFhLVmXaOroU={'title':njkbDgcMYsEuHKtvqQwFhLVmXaOroe['title'],'startTime':njkbDgcMYsEuHKtvqQwFhLVmXaOroe['sch_date'].replace('-','')+njkbDgcMYsEuHKtvqQwFhLVmXaOrxi(njkbDgcMYsEuHKtvqQwFhLVmXaOroe['sch_hour']).zfill(2)+njkbDgcMYsEuHKtvqQwFhLVmXaOroe['sch_min']+'00'}
    njkbDgcMYsEuHKtvqQwFhLVmXaOroG.append(njkbDgcMYsEuHKtvqQwFhLVmXaOroU)
   for i in njkbDgcMYsEuHKtvqQwFhLVmXaOrxS(njkbDgcMYsEuHKtvqQwFhLVmXaOrxR(njkbDgcMYsEuHKtvqQwFhLVmXaOroG)):
    if i>0:njkbDgcMYsEuHKtvqQwFhLVmXaOroG[i-1]['endTime']=njkbDgcMYsEuHKtvqQwFhLVmXaOroG[i]['startTime']
    if i==njkbDgcMYsEuHKtvqQwFhLVmXaOrxR(njkbDgcMYsEuHKtvqQwFhLVmXaOroG)-1: njkbDgcMYsEuHKtvqQwFhLVmXaOroG[i]['endTime']=now_day+'240000'
  except njkbDgcMYsEuHKtvqQwFhLVmXaOrxA as exception:
   njkbDgcMYsEuHKtvqQwFhLVmXaOrxz(exception)
   return[]
  return njkbDgcMYsEuHKtvqQwFhLVmXaOroG
 def GetEventLiveList(njkbDgcMYsEuHKtvqQwFhLVmXaOrWI):
  njkbDgcMYsEuHKtvqQwFhLVmXaOrox=[]
  njkbDgcMYsEuHKtvqQwFhLVmXaOrdo =0
  try:
   njkbDgcMYsEuHKtvqQwFhLVmXaOrdy=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.Get_Now_Datetime()
   njkbDgcMYsEuHKtvqQwFhLVmXaOrdx=njkbDgcMYsEuHKtvqQwFhLVmXaOrdy.strftime('%Y-%m-%d')
  except njkbDgcMYsEuHKtvqQwFhLVmXaOrxA as exception:
   njkbDgcMYsEuHKtvqQwFhLVmXaOrxz(exception)
   return njkbDgcMYsEuHKtvqQwFhLVmXaOrox,njkbDgcMYsEuHKtvqQwFhLVmXaOrdo
  try:
   njkbDgcMYsEuHKtvqQwFhLVmXaOroC=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.API_DOMAIN+'/api/v2/player/lives/'+njkbDgcMYsEuHKtvqQwFhLVmXaOrdx 
   njkbDgcMYsEuHKtvqQwFhLVmXaOrWC=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.makeDefaultCookies()
   njkbDgcMYsEuHKtvqQwFhLVmXaOrWz=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.callRequestCookies('Get',njkbDgcMYsEuHKtvqQwFhLVmXaOroC,payload=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,params=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,headers=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,cookies=njkbDgcMYsEuHKtvqQwFhLVmXaOrWC)
   njkbDgcMYsEuHKtvqQwFhLVmXaOrdo=njkbDgcMYsEuHKtvqQwFhLVmXaOrWz.status_code 
   njkbDgcMYsEuHKtvqQwFhLVmXaOrWA=json.loads(njkbDgcMYsEuHKtvqQwFhLVmXaOrWz.text)
   for njkbDgcMYsEuHKtvqQwFhLVmXaOrdI in njkbDgcMYsEuHKtvqQwFhLVmXaOrWA:
    for njkbDgcMYsEuHKtvqQwFhLVmXaOroe in njkbDgcMYsEuHKtvqQwFhLVmXaOrdI['liveNowList']:
     if njkbDgcMYsEuHKtvqQwFhLVmXaOroe['gameDesc']['title']==njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ or njkbDgcMYsEuHKtvqQwFhLVmXaOroe['gameDesc']['title']=='':
      njkbDgcMYsEuHKtvqQwFhLVmXaOrde='%s ( %s : %s )'%(njkbDgcMYsEuHKtvqQwFhLVmXaOroe['leagueName'],njkbDgcMYsEuHKtvqQwFhLVmXaOroe['homeNameShort'],njkbDgcMYsEuHKtvqQwFhLVmXaOroe['awayNameShort'])
     else:
      njkbDgcMYsEuHKtvqQwFhLVmXaOrde=njkbDgcMYsEuHKtvqQwFhLVmXaOroe['gameDesc']['title']
     njkbDgcMYsEuHKtvqQwFhLVmXaOroU={'liveId':njkbDgcMYsEuHKtvqQwFhLVmXaOroe['liveId'],'title':njkbDgcMYsEuHKtvqQwFhLVmXaOrde,'logo':njkbDgcMYsEuHKtvqQwFhLVmXaOroe['gameDesc']['leagueLogo'],'free':njkbDgcMYsEuHKtvqQwFhLVmXaOroe['isFree'],'startTime':njkbDgcMYsEuHKtvqQwFhLVmXaOroe['startTime']}
     njkbDgcMYsEuHKtvqQwFhLVmXaOrox.append(njkbDgcMYsEuHKtvqQwFhLVmXaOroU)
  except njkbDgcMYsEuHKtvqQwFhLVmXaOrxA as exception:
   njkbDgcMYsEuHKtvqQwFhLVmXaOrxz(exception)
  return njkbDgcMYsEuHKtvqQwFhLVmXaOrox,njkbDgcMYsEuHKtvqQwFhLVmXaOrdo
 def GetEventLive_videoId(njkbDgcMYsEuHKtvqQwFhLVmXaOrWI,liveId):
  njkbDgcMYsEuHKtvqQwFhLVmXaOrdU=''
  try:
   njkbDgcMYsEuHKtvqQwFhLVmXaOroC=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.API_DOMAIN+'/api/v2/live/'+liveId
   njkbDgcMYsEuHKtvqQwFhLVmXaOrWz=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.callRequestCookies('Get',njkbDgcMYsEuHKtvqQwFhLVmXaOroC,payload=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,params=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,headers=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,cookies=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ)
   njkbDgcMYsEuHKtvqQwFhLVmXaOrWA=json.loads(njkbDgcMYsEuHKtvqQwFhLVmXaOrWz.text)
   njkbDgcMYsEuHKtvqQwFhLVmXaOrdC=njkbDgcMYsEuHKtvqQwFhLVmXaOrWA['videoId']
   njkbDgcMYsEuHKtvqQwFhLVmXaOrdU=njkbDgcMYsEuHKtvqQwFhLVmXaOrdC.replace('ref:','')
  except njkbDgcMYsEuHKtvqQwFhLVmXaOrxA as exception:
   njkbDgcMYsEuHKtvqQwFhLVmXaOrxz(exception)
  return njkbDgcMYsEuHKtvqQwFhLVmXaOrdU
 def CheckMainEnd(njkbDgcMYsEuHKtvqQwFhLVmXaOrWI):
  njkbDgcMYsEuHKtvqQwFhLVmXaOrdG=base64.standard_b64encode((njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.SPOTV_PMCODE+njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.SPOTV_SESSIONID).encode()).decode('utf-8')
  if njkbDgcMYsEuHKtvqQwFhLVmXaOrdG=='OTg3MTgzMzM0Ng==' or njkbDgcMYsEuHKtvqQwFhLVmXaOrdG=='OTg3MTgzMzExNw==':return njkbDgcMYsEuHKtvqQwFhLVmXaOrxp
  return njkbDgcMYsEuHKtvqQwFhLVmXaOrxB
 def CheckSubEnd(njkbDgcMYsEuHKtvqQwFhLVmXaOrWI):
  njkbDgcMYsEuHKtvqQwFhLVmXaOrdf=njkbDgcMYsEuHKtvqQwFhLVmXaOrxB
  try:
   if njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.CheckMainEnd():return njkbDgcMYsEuHKtvqQwFhLVmXaOrxp 
   if njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.SPOTV_SUBEND=='0':return njkbDgcMYsEuHKtvqQwFhLVmXaOrdf
   njkbDgcMYsEuHKtvqQwFhLVmXaOrdT =njkbDgcMYsEuHKtvqQwFhLVmXaOrxl(njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.Get_Now_Datetime().strftime('%Y%m%d'))
   njkbDgcMYsEuHKtvqQwFhLVmXaOrdN =njkbDgcMYsEuHKtvqQwFhLVmXaOrxl(njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.SPOTV_SUBEND)/1000
   njkbDgcMYsEuHKtvqQwFhLVmXaOrdB =njkbDgcMYsEuHKtvqQwFhLVmXaOrxl(datetime.datetime.fromtimestamp(njkbDgcMYsEuHKtvqQwFhLVmXaOrdN,datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul')).strftime('%Y%m%d'))
   if njkbDgcMYsEuHKtvqQwFhLVmXaOrdT<=njkbDgcMYsEuHKtvqQwFhLVmXaOrdB:njkbDgcMYsEuHKtvqQwFhLVmXaOrdf=njkbDgcMYsEuHKtvqQwFhLVmXaOrxp
  except njkbDgcMYsEuHKtvqQwFhLVmXaOrxA as exception:
   njkbDgcMYsEuHKtvqQwFhLVmXaOrxz(exception)
   return njkbDgcMYsEuHKtvqQwFhLVmXaOrdf
  return njkbDgcMYsEuHKtvqQwFhLVmXaOrdf
 def GetMainJspath(njkbDgcMYsEuHKtvqQwFhLVmXaOrWI):
  njkbDgcMYsEuHKtvqQwFhLVmXaOrdP=''
  try:
   njkbDgcMYsEuHKtvqQwFhLVmXaOroC=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.API_DOMAIN
   njkbDgcMYsEuHKtvqQwFhLVmXaOrWz=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.callRequestCookies('Get',njkbDgcMYsEuHKtvqQwFhLVmXaOroC,payload=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,params=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,headers=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,cookies=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ)
   njkbDgcMYsEuHKtvqQwFhLVmXaOrdJ=njkbDgcMYsEuHKtvqQwFhLVmXaOrWz.text
   njkbDgcMYsEuHKtvqQwFhLVmXaOrdz =re.findall('https://cdn.spotvnow.co.kr/dist/js/.{20}\.js',njkbDgcMYsEuHKtvqQwFhLVmXaOrdJ)[0]
   njkbDgcMYsEuHKtvqQwFhLVmXaOrdP=njkbDgcMYsEuHKtvqQwFhLVmXaOrdz
  except njkbDgcMYsEuHKtvqQwFhLVmXaOrxA as exception:
   njkbDgcMYsEuHKtvqQwFhLVmXaOrxz(exception)
  return njkbDgcMYsEuHKtvqQwFhLVmXaOrdP
 def GetBcPlayerUrl(njkbDgcMYsEuHKtvqQwFhLVmXaOrWI):
  njkbDgcMYsEuHKtvqQwFhLVmXaOrdi=''
  try:
   njkbDgcMYsEuHKtvqQwFhLVmXaOroC=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.GetMainJspath()
   if njkbDgcMYsEuHKtvqQwFhLVmXaOroC=='':return njkbDgcMYsEuHKtvqQwFhLVmXaOrdi
   njkbDgcMYsEuHKtvqQwFhLVmXaOrWz=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.callRequestCookies('Get',njkbDgcMYsEuHKtvqQwFhLVmXaOroC,payload=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,params=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,headers=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,cookies=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ)
   njkbDgcMYsEuHKtvqQwFhLVmXaOrdJ=njkbDgcMYsEuHKtvqQwFhLVmXaOrWz.text
   njkbDgcMYsEuHKtvqQwFhLVmXaOrdp =re.findall('bc:\s*\"\d{13}\",\s*player:\s*\".{9}\"',njkbDgcMYsEuHKtvqQwFhLVmXaOrdJ)[0]
   njkbDgcMYsEuHKtvqQwFhLVmXaOrdp =njkbDgcMYsEuHKtvqQwFhLVmXaOrdp.replace('bc','"bc"')
   njkbDgcMYsEuHKtvqQwFhLVmXaOrdp =njkbDgcMYsEuHKtvqQwFhLVmXaOrdp.replace('player','"player"')
   njkbDgcMYsEuHKtvqQwFhLVmXaOrdp ='{'+njkbDgcMYsEuHKtvqQwFhLVmXaOrdp+'}'
   njkbDgcMYsEuHKtvqQwFhLVmXaOrdp =json.loads(njkbDgcMYsEuHKtvqQwFhLVmXaOrdp)
   bc =njkbDgcMYsEuHKtvqQwFhLVmXaOrdp['bc']
   njkbDgcMYsEuHKtvqQwFhLVmXaOrdA =njkbDgcMYsEuHKtvqQwFhLVmXaOrdp['player']
   njkbDgcMYsEuHKtvqQwFhLVmXaOrdi="%s/%s/%s_default/index.min.js"%(njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.BC_DOMAIN,bc,njkbDgcMYsEuHKtvqQwFhLVmXaOrdA)
  except njkbDgcMYsEuHKtvqQwFhLVmXaOrxA as exception:
   njkbDgcMYsEuHKtvqQwFhLVmXaOrxz(exception)
  return njkbDgcMYsEuHKtvqQwFhLVmXaOrdi
 def GetPolicyKey(njkbDgcMYsEuHKtvqQwFhLVmXaOrWI):
  njkbDgcMYsEuHKtvqQwFhLVmXaOrdl=policykey=''
  try:
   njkbDgcMYsEuHKtvqQwFhLVmXaOroC=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.GetBcPlayerUrl()
   if njkbDgcMYsEuHKtvqQwFhLVmXaOroC=='':return njkbDgcMYsEuHKtvqQwFhLVmXaOrdl,njkbDgcMYsEuHKtvqQwFhLVmXaOrdS
   njkbDgcMYsEuHKtvqQwFhLVmXaOrWz=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.callRequestCookies('Get',njkbDgcMYsEuHKtvqQwFhLVmXaOroC,payload=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,params=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,headers=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,cookies=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ)
   njkbDgcMYsEuHKtvqQwFhLVmXaOrdJ=njkbDgcMYsEuHKtvqQwFhLVmXaOrWz.text
   njkbDgcMYsEuHKtvqQwFhLVmXaOrdz =re.findall('accountId:\s*\"\d{13}\",\s*policyKey:\s*\".[^(){}]{100,300}\"',njkbDgcMYsEuHKtvqQwFhLVmXaOrdJ)[0]
   njkbDgcMYsEuHKtvqQwFhLVmXaOrdz =njkbDgcMYsEuHKtvqQwFhLVmXaOrdz.replace('accountId','"accountId"')
   njkbDgcMYsEuHKtvqQwFhLVmXaOrdz =njkbDgcMYsEuHKtvqQwFhLVmXaOrdz.replace('policyKey','"policyKey"')
   njkbDgcMYsEuHKtvqQwFhLVmXaOrdz ='{'+njkbDgcMYsEuHKtvqQwFhLVmXaOrdz+'}'
   njkbDgcMYsEuHKtvqQwFhLVmXaOrdR=json.loads(njkbDgcMYsEuHKtvqQwFhLVmXaOrdz)
   njkbDgcMYsEuHKtvqQwFhLVmXaOrdl =njkbDgcMYsEuHKtvqQwFhLVmXaOrdR['accountId']
   njkbDgcMYsEuHKtvqQwFhLVmXaOrdS =njkbDgcMYsEuHKtvqQwFhLVmXaOrdR['policyKey']
  except njkbDgcMYsEuHKtvqQwFhLVmXaOrxA as exception:
   njkbDgcMYsEuHKtvqQwFhLVmXaOrxz(exception)
  return njkbDgcMYsEuHKtvqQwFhLVmXaOrdl,njkbDgcMYsEuHKtvqQwFhLVmXaOrdS
 def GetBroadURL(njkbDgcMYsEuHKtvqQwFhLVmXaOrWI,njkbDgcMYsEuHKtvqQwFhLVmXaOrdU,mediatype,njkbDgcMYsEuHKtvqQwFhLVmXaOryT):
  njkbDgcMYsEuHKtvqQwFhLVmXaOryW=''
  try:
   if mediatype=='live':
    njkbDgcMYsEuHKtvqQwFhLVmXaOrdU='ref%3A'+njkbDgcMYsEuHKtvqQwFhLVmXaOrdU
   else:
    njkbDgcMYsEuHKtvqQwFhLVmXaOrdU=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.GetReplay_UrlId(njkbDgcMYsEuHKtvqQwFhLVmXaOrdU,njkbDgcMYsEuHKtvqQwFhLVmXaOryT)
    if njkbDgcMYsEuHKtvqQwFhLVmXaOrdU=='':return njkbDgcMYsEuHKtvqQwFhLVmXaOryW
   njkbDgcMYsEuHKtvqQwFhLVmXaOroC=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.PLAYER_DOMAIN+'/playback/v1/accounts/'+njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.SPOTV_ACCOUNTID+'/videos/'+njkbDgcMYsEuHKtvqQwFhLVmXaOrdU
   njkbDgcMYsEuHKtvqQwFhLVmXaOryo={'accept':'application/json;pk='+njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.SPOTV_POLICYKEY}
   njkbDgcMYsEuHKtvqQwFhLVmXaOrWz=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.callRequestCookies('Get',njkbDgcMYsEuHKtvqQwFhLVmXaOroC,payload=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,params=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,headers=njkbDgcMYsEuHKtvqQwFhLVmXaOryo,cookies=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ)
   njkbDgcMYsEuHKtvqQwFhLVmXaOrdW=json.loads(njkbDgcMYsEuHKtvqQwFhLVmXaOrWz.text)
   njkbDgcMYsEuHKtvqQwFhLVmXaOryW=njkbDgcMYsEuHKtvqQwFhLVmXaOrdW['sources'][0]['src']
   if mediatype=='live':
    njkbDgcMYsEuHKtvqQwFhLVmXaOryW=njkbDgcMYsEuHKtvqQwFhLVmXaOryW.replace('playlist.m3u8','playlist_dvr.m3u8')
   njkbDgcMYsEuHKtvqQwFhLVmXaOryW=njkbDgcMYsEuHKtvqQwFhLVmXaOryW.replace('http://','https://')
  except njkbDgcMYsEuHKtvqQwFhLVmXaOrxA as exception:
   njkbDgcMYsEuHKtvqQwFhLVmXaOrxz(exception)
  return njkbDgcMYsEuHKtvqQwFhLVmXaOryW
 def GetTitleGroupList(njkbDgcMYsEuHKtvqQwFhLVmXaOrWI):
  njkbDgcMYsEuHKtvqQwFhLVmXaOrox=[]
  njkbDgcMYsEuHKtvqQwFhLVmXaOryd=njkbDgcMYsEuHKtvqQwFhLVmXaOrxB
  try:
   njkbDgcMYsEuHKtvqQwFhLVmXaOroC=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.API_DOMAIN+'/api/v2/home/web'
   njkbDgcMYsEuHKtvqQwFhLVmXaOrWz=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.callRequestCookies('Get',njkbDgcMYsEuHKtvqQwFhLVmXaOroC,payload=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,params=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,headers=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,cookies=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ)
   njkbDgcMYsEuHKtvqQwFhLVmXaOrWA=json.loads(njkbDgcMYsEuHKtvqQwFhLVmXaOrWz.text)
   for njkbDgcMYsEuHKtvqQwFhLVmXaOroe in njkbDgcMYsEuHKtvqQwFhLVmXaOrWA:
    if njkbDgcMYsEuHKtvqQwFhLVmXaOrxi(njkbDgcMYsEuHKtvqQwFhLVmXaOroe['type'])=='3':
     njkbDgcMYsEuHKtvqQwFhLVmXaOryx=''
     for njkbDgcMYsEuHKtvqQwFhLVmXaOryI in njkbDgcMYsEuHKtvqQwFhLVmXaOroe['data']['list']:
      njkbDgcMYsEuHKtvqQwFhLVmXaOrye='[%s] %s vs %s\n<%s>\n\n'%(njkbDgcMYsEuHKtvqQwFhLVmXaOryI['gameDesc']['roundName'],njkbDgcMYsEuHKtvqQwFhLVmXaOryI['gameDesc']['homeNameShort'],njkbDgcMYsEuHKtvqQwFhLVmXaOryI['gameDesc']['awayNameShort'],njkbDgcMYsEuHKtvqQwFhLVmXaOryI['gameDesc']['beginDate'])
      njkbDgcMYsEuHKtvqQwFhLVmXaOryx+=njkbDgcMYsEuHKtvqQwFhLVmXaOrye
     njkbDgcMYsEuHKtvqQwFhLVmXaOroU={'title':njkbDgcMYsEuHKtvqQwFhLVmXaOroe['title'],'logo':njkbDgcMYsEuHKtvqQwFhLVmXaOroe['logo'],'reagueId':njkbDgcMYsEuHKtvqQwFhLVmXaOrxi(njkbDgcMYsEuHKtvqQwFhLVmXaOroe['destId']),'subGame':njkbDgcMYsEuHKtvqQwFhLVmXaOryx}
     njkbDgcMYsEuHKtvqQwFhLVmXaOrox.append(njkbDgcMYsEuHKtvqQwFhLVmXaOroU)
     if njkbDgcMYsEuHKtvqQwFhLVmXaOrxi(njkbDgcMYsEuHKtvqQwFhLVmXaOroe['destId'])=='13':njkbDgcMYsEuHKtvqQwFhLVmXaOryd=njkbDgcMYsEuHKtvqQwFhLVmXaOrxp
   if njkbDgcMYsEuHKtvqQwFhLVmXaOryd==njkbDgcMYsEuHKtvqQwFhLVmXaOrxB:
    njkbDgcMYsEuHKtvqQwFhLVmXaOroU={'title':'UFC','logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200928/a643c7cf1c285fb0b4469c07d4c09c28.png','reagueId':'13','subGame':''}
    njkbDgcMYsEuHKtvqQwFhLVmXaOrox.append(njkbDgcMYsEuHKtvqQwFhLVmXaOroU)
  except njkbDgcMYsEuHKtvqQwFhLVmXaOrxA as exception:
   njkbDgcMYsEuHKtvqQwFhLVmXaOrxz(exception)
  return njkbDgcMYsEuHKtvqQwFhLVmXaOrox
 def GetPopularGroupList(njkbDgcMYsEuHKtvqQwFhLVmXaOrWI):
  njkbDgcMYsEuHKtvqQwFhLVmXaOrox=[]
  try:
   njkbDgcMYsEuHKtvqQwFhLVmXaOroC=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.API_DOMAIN+'/api/v2/home/web'
   njkbDgcMYsEuHKtvqQwFhLVmXaOrWz=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.callRequestCookies('Get',njkbDgcMYsEuHKtvqQwFhLVmXaOroC,payload=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,params=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,headers=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,cookies=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ)
   njkbDgcMYsEuHKtvqQwFhLVmXaOrWA=json.loads(njkbDgcMYsEuHKtvqQwFhLVmXaOrWz.text)
   for njkbDgcMYsEuHKtvqQwFhLVmXaOroe in njkbDgcMYsEuHKtvqQwFhLVmXaOrWA:
    if njkbDgcMYsEuHKtvqQwFhLVmXaOrxi(njkbDgcMYsEuHKtvqQwFhLVmXaOroe['type'])=='1' and njkbDgcMYsEuHKtvqQwFhLVmXaOrxi(njkbDgcMYsEuHKtvqQwFhLVmXaOroe['destId'])=='4':
     for njkbDgcMYsEuHKtvqQwFhLVmXaOryI in njkbDgcMYsEuHKtvqQwFhLVmXaOroe['data']['list']:
      njkbDgcMYsEuHKtvqQwFhLVmXaOryU =njkbDgcMYsEuHKtvqQwFhLVmXaOryI['title']
      njkbDgcMYsEuHKtvqQwFhLVmXaOryC =njkbDgcMYsEuHKtvqQwFhLVmXaOryI['id']
      njkbDgcMYsEuHKtvqQwFhLVmXaOryG =njkbDgcMYsEuHKtvqQwFhLVmXaOryI['vtype']
      njkbDgcMYsEuHKtvqQwFhLVmXaOryf =njkbDgcMYsEuHKtvqQwFhLVmXaOryI['imgUrl']
      njkbDgcMYsEuHKtvqQwFhLVmXaOryT =njkbDgcMYsEuHKtvqQwFhLVmXaOryI['vtypeId']
      njkbDgcMYsEuHKtvqQwFhLVmXaOroU={'vodTitle':njkbDgcMYsEuHKtvqQwFhLVmXaOryU,'vodId':njkbDgcMYsEuHKtvqQwFhLVmXaOryC,'vodType':njkbDgcMYsEuHKtvqQwFhLVmXaOryG,'thumbnail':njkbDgcMYsEuHKtvqQwFhLVmXaOryf,'vtypeId':njkbDgcMYsEuHKtvqQwFhLVmXaOrxi(njkbDgcMYsEuHKtvqQwFhLVmXaOryT),'duration':njkbDgcMYsEuHKtvqQwFhLVmXaOrxl(njkbDgcMYsEuHKtvqQwFhLVmXaOryI['duration']/1000)}
      njkbDgcMYsEuHKtvqQwFhLVmXaOrox.append(njkbDgcMYsEuHKtvqQwFhLVmXaOroU)
  except njkbDgcMYsEuHKtvqQwFhLVmXaOrxA as exception:
   njkbDgcMYsEuHKtvqQwFhLVmXaOrxz(exception)
  return njkbDgcMYsEuHKtvqQwFhLVmXaOrox
 def Get_NowVod_GroupList(njkbDgcMYsEuHKtvqQwFhLVmXaOrWI,page_int):
  njkbDgcMYsEuHKtvqQwFhLVmXaOrox=[]
  njkbDgcMYsEuHKtvqQwFhLVmXaOryN=njkbDgcMYsEuHKtvqQwFhLVmXaOrxB
  try:
   njkbDgcMYsEuHKtvqQwFhLVmXaOroC=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.API_DOMAIN+'/api/v2/theme/14/list'
   njkbDgcMYsEuHKtvqQwFhLVmXaOryB={'pageItem':'10','pageNo':njkbDgcMYsEuHKtvqQwFhLVmXaOrxi(page_int)}
   njkbDgcMYsEuHKtvqQwFhLVmXaOrWz=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.callRequestCookies('Get',njkbDgcMYsEuHKtvqQwFhLVmXaOroC,payload=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,params=njkbDgcMYsEuHKtvqQwFhLVmXaOryB,headers=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,cookies=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ)
   njkbDgcMYsEuHKtvqQwFhLVmXaOrWA=json.loads(njkbDgcMYsEuHKtvqQwFhLVmXaOrWz.text)
   for njkbDgcMYsEuHKtvqQwFhLVmXaOroe in njkbDgcMYsEuHKtvqQwFhLVmXaOrWA['list']:
    njkbDgcMYsEuHKtvqQwFhLVmXaOryU =njkbDgcMYsEuHKtvqQwFhLVmXaOroe['title']
    njkbDgcMYsEuHKtvqQwFhLVmXaOryC =njkbDgcMYsEuHKtvqQwFhLVmXaOroe['id']
    njkbDgcMYsEuHKtvqQwFhLVmXaOryG =njkbDgcMYsEuHKtvqQwFhLVmXaOroe['vtype']
    njkbDgcMYsEuHKtvqQwFhLVmXaOryf =njkbDgcMYsEuHKtvqQwFhLVmXaOroe['imgUrl']
    njkbDgcMYsEuHKtvqQwFhLVmXaOryT =njkbDgcMYsEuHKtvqQwFhLVmXaOroe['vtypeId']
    njkbDgcMYsEuHKtvqQwFhLVmXaOroU={'vodTitle':njkbDgcMYsEuHKtvqQwFhLVmXaOryU,'vodId':njkbDgcMYsEuHKtvqQwFhLVmXaOryC,'vodType':njkbDgcMYsEuHKtvqQwFhLVmXaOryG,'thumbnail':njkbDgcMYsEuHKtvqQwFhLVmXaOryf,'vtypeId':njkbDgcMYsEuHKtvqQwFhLVmXaOrxi(njkbDgcMYsEuHKtvqQwFhLVmXaOryT),'duration':njkbDgcMYsEuHKtvqQwFhLVmXaOrxl(njkbDgcMYsEuHKtvqQwFhLVmXaOroe['duration']/1000),}
    njkbDgcMYsEuHKtvqQwFhLVmXaOrox.append(njkbDgcMYsEuHKtvqQwFhLVmXaOroU)
    if njkbDgcMYsEuHKtvqQwFhLVmXaOrWA['count']>page_int*njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.GAMELIST_LIMIT:njkbDgcMYsEuHKtvqQwFhLVmXaOryN=njkbDgcMYsEuHKtvqQwFhLVmXaOrxp
  except njkbDgcMYsEuHKtvqQwFhLVmXaOrxA as exception:
   njkbDgcMYsEuHKtvqQwFhLVmXaOrxz(exception)
  return njkbDgcMYsEuHKtvqQwFhLVmXaOrox,njkbDgcMYsEuHKtvqQwFhLVmXaOryN
 def GetSeasonList(njkbDgcMYsEuHKtvqQwFhLVmXaOrWI,leagueId):
  njkbDgcMYsEuHKtvqQwFhLVmXaOrox=[]
  njkbDgcMYsEuHKtvqQwFhLVmXaOryP=njkbDgcMYsEuHKtvqQwFhLVmXaOryJ=''
  try:
   njkbDgcMYsEuHKtvqQwFhLVmXaOroC=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.API_DOMAIN+'/api/v2/game/league/'+leagueId
   njkbDgcMYsEuHKtvqQwFhLVmXaOrWz=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.callRequestCookies('Get',njkbDgcMYsEuHKtvqQwFhLVmXaOroC,payload=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,params=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,headers=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,cookies=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ)
   njkbDgcMYsEuHKtvqQwFhLVmXaOrWA=json.loads(njkbDgcMYsEuHKtvqQwFhLVmXaOrWz.text)
   njkbDgcMYsEuHKtvqQwFhLVmXaOryP=njkbDgcMYsEuHKtvqQwFhLVmXaOrWA['name']
   njkbDgcMYsEuHKtvqQwFhLVmXaOryJ=njkbDgcMYsEuHKtvqQwFhLVmXaOrxi(njkbDgcMYsEuHKtvqQwFhLVmXaOrWA['gameTypeId'])
  except njkbDgcMYsEuHKtvqQwFhLVmXaOrxA as exception:
   njkbDgcMYsEuHKtvqQwFhLVmXaOrxz(exception)
   return njkbDgcMYsEuHKtvqQwFhLVmXaOrox
  if njkbDgcMYsEuHKtvqQwFhLVmXaOryJ=='2':
   try:
    njkbDgcMYsEuHKtvqQwFhLVmXaOroC=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.API_DOMAIN+'/api/v2/year/'+leagueId
    njkbDgcMYsEuHKtvqQwFhLVmXaOrWz=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.callRequestCookies('Get',njkbDgcMYsEuHKtvqQwFhLVmXaOroC,payload=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,params=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,headers=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,cookies=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ)
    njkbDgcMYsEuHKtvqQwFhLVmXaOrWA=json.loads(njkbDgcMYsEuHKtvqQwFhLVmXaOrWz.text)
    for njkbDgcMYsEuHKtvqQwFhLVmXaOroe in njkbDgcMYsEuHKtvqQwFhLVmXaOrWA:
     njkbDgcMYsEuHKtvqQwFhLVmXaOroU={'reagueName':njkbDgcMYsEuHKtvqQwFhLVmXaOryP,'gameTypeId':njkbDgcMYsEuHKtvqQwFhLVmXaOryJ,'seasonName':njkbDgcMYsEuHKtvqQwFhLVmXaOrxi(njkbDgcMYsEuHKtvqQwFhLVmXaOroe),'seasonId':njkbDgcMYsEuHKtvqQwFhLVmXaOrxi(njkbDgcMYsEuHKtvqQwFhLVmXaOroe)}
     njkbDgcMYsEuHKtvqQwFhLVmXaOrox.append(njkbDgcMYsEuHKtvqQwFhLVmXaOroU)
   except njkbDgcMYsEuHKtvqQwFhLVmXaOrxA as exception:
    njkbDgcMYsEuHKtvqQwFhLVmXaOrxz(exception)
    return[]
  else:
   try:
    njkbDgcMYsEuHKtvqQwFhLVmXaOroC=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.API_DOMAIN+'/api/v2/season/'+leagueId
    njkbDgcMYsEuHKtvqQwFhLVmXaOrWz=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.callRequestCookies('Get',njkbDgcMYsEuHKtvqQwFhLVmXaOroC,payload=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,params=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,headers=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,cookies=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ)
    njkbDgcMYsEuHKtvqQwFhLVmXaOrWA=json.loads(njkbDgcMYsEuHKtvqQwFhLVmXaOrWz.text)
    for njkbDgcMYsEuHKtvqQwFhLVmXaOroe in njkbDgcMYsEuHKtvqQwFhLVmXaOrWA:
     njkbDgcMYsEuHKtvqQwFhLVmXaOroU={'reagueName':njkbDgcMYsEuHKtvqQwFhLVmXaOryP,'gameTypeId':njkbDgcMYsEuHKtvqQwFhLVmXaOryJ,'seasonName':njkbDgcMYsEuHKtvqQwFhLVmXaOroe['name'],'seasonId':njkbDgcMYsEuHKtvqQwFhLVmXaOrxi(njkbDgcMYsEuHKtvqQwFhLVmXaOroe['id'])}
     njkbDgcMYsEuHKtvqQwFhLVmXaOrox.append(njkbDgcMYsEuHKtvqQwFhLVmXaOroU)
   except njkbDgcMYsEuHKtvqQwFhLVmXaOrxA as exception:
    njkbDgcMYsEuHKtvqQwFhLVmXaOrxz(exception)
    return[]
  return njkbDgcMYsEuHKtvqQwFhLVmXaOrox
 def GetGameList(njkbDgcMYsEuHKtvqQwFhLVmXaOrWI,njkbDgcMYsEuHKtvqQwFhLVmXaOryJ,leagueId,seasonId,page_int,hidescore=njkbDgcMYsEuHKtvqQwFhLVmXaOrxp):
  njkbDgcMYsEuHKtvqQwFhLVmXaOrox=[]
  njkbDgcMYsEuHKtvqQwFhLVmXaOryN=njkbDgcMYsEuHKtvqQwFhLVmXaOrxB
  try:
   njkbDgcMYsEuHKtvqQwFhLVmXaOroC=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.API_DOMAIN+'/api/v2/vod/league/detail'
   njkbDgcMYsEuHKtvqQwFhLVmXaOryB={'gameType':njkbDgcMYsEuHKtvqQwFhLVmXaOryJ,'leagueId':leagueId,'seasonId':seasonId if njkbDgcMYsEuHKtvqQwFhLVmXaOryJ!='2' else '','teamId':'','roundId':'','year':'' if njkbDgcMYsEuHKtvqQwFhLVmXaOryJ!='2' else seasonId,'pageNo':njkbDgcMYsEuHKtvqQwFhLVmXaOrxi(page_int)}
   njkbDgcMYsEuHKtvqQwFhLVmXaOrWz=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.callRequestCookies('Get',njkbDgcMYsEuHKtvqQwFhLVmXaOroC,payload=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,params=njkbDgcMYsEuHKtvqQwFhLVmXaOryB,headers=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,cookies=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ)
   njkbDgcMYsEuHKtvqQwFhLVmXaOrWA=json.loads(njkbDgcMYsEuHKtvqQwFhLVmXaOrWz.text)
   njkbDgcMYsEuHKtvqQwFhLVmXaOrdI=njkbDgcMYsEuHKtvqQwFhLVmXaOrWA['list']
   for njkbDgcMYsEuHKtvqQwFhLVmXaOryz in njkbDgcMYsEuHKtvqQwFhLVmXaOrdI:
    for njkbDgcMYsEuHKtvqQwFhLVmXaOroe in njkbDgcMYsEuHKtvqQwFhLVmXaOryz['list']:
     if njkbDgcMYsEuHKtvqQwFhLVmXaOroe['gameDesc']['title']==njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ or njkbDgcMYsEuHKtvqQwFhLVmXaOroe['gameDesc']['title']=='':
      njkbDgcMYsEuHKtvqQwFhLVmXaOrde ='%s vs %s'%(njkbDgcMYsEuHKtvqQwFhLVmXaOroe['gameDesc']['homeNameShort'],njkbDgcMYsEuHKtvqQwFhLVmXaOroe['gameDesc']['awayNameShort'])
     else:
      njkbDgcMYsEuHKtvqQwFhLVmXaOrde =njkbDgcMYsEuHKtvqQwFhLVmXaOroe['gameDesc']['title']
     njkbDgcMYsEuHKtvqQwFhLVmXaOryi =njkbDgcMYsEuHKtvqQwFhLVmXaOroe['gameDesc']['beginDate']
     njkbDgcMYsEuHKtvqQwFhLVmXaOryp =njkbDgcMYsEuHKtvqQwFhLVmXaOroe['gameDesc']['id']
     njkbDgcMYsEuHKtvqQwFhLVmXaOryA =njkbDgcMYsEuHKtvqQwFhLVmXaOroe['gameDesc']['leagueNameFull']
     njkbDgcMYsEuHKtvqQwFhLVmXaOryl =njkbDgcMYsEuHKtvqQwFhLVmXaOroe['gameDesc']['seasonName']
     njkbDgcMYsEuHKtvqQwFhLVmXaOryR =njkbDgcMYsEuHKtvqQwFhLVmXaOroe['gameDesc']['roundName']
     njkbDgcMYsEuHKtvqQwFhLVmXaOryS =njkbDgcMYsEuHKtvqQwFhLVmXaOroe['gameDesc']['homeName']
     njkbDgcMYsEuHKtvqQwFhLVmXaOrxW =njkbDgcMYsEuHKtvqQwFhLVmXaOroe['gameDesc']['awayName']
     njkbDgcMYsEuHKtvqQwFhLVmXaOrxo =njkbDgcMYsEuHKtvqQwFhLVmXaOroe['gameDesc']['homeScore']
     njkbDgcMYsEuHKtvqQwFhLVmXaOrxd =njkbDgcMYsEuHKtvqQwFhLVmXaOroe['gameDesc']['awayScore']
     if hidescore==njkbDgcMYsEuHKtvqQwFhLVmXaOrxp:
      njkbDgcMYsEuHKtvqQwFhLVmXaOrxy ='%s\n - %s (%s)\n - %s\n\nhome : %s\n\naway : %s'%(njkbDgcMYsEuHKtvqQwFhLVmXaOryA,njkbDgcMYsEuHKtvqQwFhLVmXaOryl,njkbDgcMYsEuHKtvqQwFhLVmXaOryR,njkbDgcMYsEuHKtvqQwFhLVmXaOryi,njkbDgcMYsEuHKtvqQwFhLVmXaOryS,njkbDgcMYsEuHKtvqQwFhLVmXaOrxW)
     else:
      njkbDgcMYsEuHKtvqQwFhLVmXaOrxy ='%s\n - %s (%s)\n - %s\n\nhome : %s (Score %s)\n\naway : %s (Score %s)'%(njkbDgcMYsEuHKtvqQwFhLVmXaOryA,njkbDgcMYsEuHKtvqQwFhLVmXaOryl,njkbDgcMYsEuHKtvqQwFhLVmXaOryR,njkbDgcMYsEuHKtvqQwFhLVmXaOryi,njkbDgcMYsEuHKtvqQwFhLVmXaOryS,njkbDgcMYsEuHKtvqQwFhLVmXaOrxo,njkbDgcMYsEuHKtvqQwFhLVmXaOrxW,njkbDgcMYsEuHKtvqQwFhLVmXaOrxd)
     njkbDgcMYsEuHKtvqQwFhLVmXaOrxI=njkbDgcMYsEuHKtvqQwFhLVmXaOrxy
     njkbDgcMYsEuHKtvqQwFhLVmXaOrxe =njkbDgcMYsEuHKtvqQwFhLVmXaOroe['replayVod']['count']
     njkbDgcMYsEuHKtvqQwFhLVmXaOrxU=njkbDgcMYsEuHKtvqQwFhLVmXaOroe['highlightVod']['count']
     njkbDgcMYsEuHKtvqQwFhLVmXaOrxC =njkbDgcMYsEuHKtvqQwFhLVmXaOroe['vods']['count']
     njkbDgcMYsEuHKtvqQwFhLVmXaOryf='' 
     njkbDgcMYsEuHKtvqQwFhLVmXaOrxG=njkbDgcMYsEuHKtvqQwFhLVmXaOrxe+njkbDgcMYsEuHKtvqQwFhLVmXaOrxU+njkbDgcMYsEuHKtvqQwFhLVmXaOrxC
     if njkbDgcMYsEuHKtvqQwFhLVmXaOrxG==0:
      if njkbDgcMYsEuHKtvqQwFhLVmXaOryJ=='2':
       njkbDgcMYsEuHKtvqQwFhLVmXaOrde='----- %s -----'%(njkbDgcMYsEuHKtvqQwFhLVmXaOryl)
       njkbDgcMYsEuHKtvqQwFhLVmXaOryi=''
      else:
       njkbDgcMYsEuHKtvqQwFhLVmXaOrde+=' - 관련영상 없음'
       njkbDgcMYsEuHKtvqQwFhLVmXaOrxI+='\n\n ** 관련영상 없음 **'
     else:
      if njkbDgcMYsEuHKtvqQwFhLVmXaOrxe!=0:
       njkbDgcMYsEuHKtvqQwFhLVmXaOryf =njkbDgcMYsEuHKtvqQwFhLVmXaOroe['replayVod']['list'][0]['imgUrl']
      elif njkbDgcMYsEuHKtvqQwFhLVmXaOrxU!=0:
       njkbDgcMYsEuHKtvqQwFhLVmXaOryf =njkbDgcMYsEuHKtvqQwFhLVmXaOroe['highlightVod']['list'][0]['imgUrl']
      else:
       njkbDgcMYsEuHKtvqQwFhLVmXaOryf =njkbDgcMYsEuHKtvqQwFhLVmXaOroe['vods']['list'][0]['imgUrl']
     njkbDgcMYsEuHKtvqQwFhLVmXaOroU={'gameTitle':njkbDgcMYsEuHKtvqQwFhLVmXaOrde,'gameId':njkbDgcMYsEuHKtvqQwFhLVmXaOryp,'beginDate':njkbDgcMYsEuHKtvqQwFhLVmXaOryi[:11],'thumbnail':njkbDgcMYsEuHKtvqQwFhLVmXaOryf,'info_plot':njkbDgcMYsEuHKtvqQwFhLVmXaOrxI,'leaguenm':njkbDgcMYsEuHKtvqQwFhLVmXaOryA,'seasonnm':njkbDgcMYsEuHKtvqQwFhLVmXaOryl,'roundnm':njkbDgcMYsEuHKtvqQwFhLVmXaOryR,'totVodCnt':njkbDgcMYsEuHKtvqQwFhLVmXaOrxG}
     njkbDgcMYsEuHKtvqQwFhLVmXaOrox.append(njkbDgcMYsEuHKtvqQwFhLVmXaOroU)
  except njkbDgcMYsEuHKtvqQwFhLVmXaOrxA as exception:
   njkbDgcMYsEuHKtvqQwFhLVmXaOrxz(exception)
  try:
   if njkbDgcMYsEuHKtvqQwFhLVmXaOryJ=='2':
    if njkbDgcMYsEuHKtvqQwFhLVmXaOrWA['count']>page_int*njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.GAMELIST_LIMIT:njkbDgcMYsEuHKtvqQwFhLVmXaOryN=njkbDgcMYsEuHKtvqQwFhLVmXaOrxp
   else:
    if njkbDgcMYsEuHKtvqQwFhLVmXaOrWA['count']>page_int*njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.GAMELIST_LIMIT:njkbDgcMYsEuHKtvqQwFhLVmXaOryN=njkbDgcMYsEuHKtvqQwFhLVmXaOrxp
  except:
   njkbDgcMYsEuHKtvqQwFhLVmXaOrxz(exception)
  return njkbDgcMYsEuHKtvqQwFhLVmXaOrox,njkbDgcMYsEuHKtvqQwFhLVmXaOryN
 def GetGameVodList(njkbDgcMYsEuHKtvqQwFhLVmXaOrWI,njkbDgcMYsEuHKtvqQwFhLVmXaOryp):
  njkbDgcMYsEuHKtvqQwFhLVmXaOrox=[]
  njkbDgcMYsEuHKtvqQwFhLVmXaOrxf=''
  try:
   njkbDgcMYsEuHKtvqQwFhLVmXaOroC=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.API_DOMAIN+'/api/v2/vod/game'
   njkbDgcMYsEuHKtvqQwFhLVmXaOryB={'gameId':njkbDgcMYsEuHKtvqQwFhLVmXaOryp,'pageItem':'1000'}
   njkbDgcMYsEuHKtvqQwFhLVmXaOrWz=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.callRequestCookies('Get',njkbDgcMYsEuHKtvqQwFhLVmXaOroC,payload=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,params=njkbDgcMYsEuHKtvqQwFhLVmXaOryB,headers=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,cookies=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ)
   njkbDgcMYsEuHKtvqQwFhLVmXaOrWA=json.loads(njkbDgcMYsEuHKtvqQwFhLVmXaOrWz.text)
   njkbDgcMYsEuHKtvqQwFhLVmXaOryz=njkbDgcMYsEuHKtvqQwFhLVmXaOrWA['list']
   for njkbDgcMYsEuHKtvqQwFhLVmXaOroe in njkbDgcMYsEuHKtvqQwFhLVmXaOryz:
    njkbDgcMYsEuHKtvqQwFhLVmXaOryU =njkbDgcMYsEuHKtvqQwFhLVmXaOroe['title']
    njkbDgcMYsEuHKtvqQwFhLVmXaOryC =njkbDgcMYsEuHKtvqQwFhLVmXaOroe['id']
    njkbDgcMYsEuHKtvqQwFhLVmXaOryG =njkbDgcMYsEuHKtvqQwFhLVmXaOroe['vtype']
    njkbDgcMYsEuHKtvqQwFhLVmXaOryf =njkbDgcMYsEuHKtvqQwFhLVmXaOroe['imgUrl']
    njkbDgcMYsEuHKtvqQwFhLVmXaOryT =njkbDgcMYsEuHKtvqQwFhLVmXaOroe['vtypeId']
    njkbDgcMYsEuHKtvqQwFhLVmXaOroU={'vodTitle':njkbDgcMYsEuHKtvqQwFhLVmXaOryU,'vodId':njkbDgcMYsEuHKtvqQwFhLVmXaOryC,'vodType':njkbDgcMYsEuHKtvqQwFhLVmXaOryG,'thumbnail':njkbDgcMYsEuHKtvqQwFhLVmXaOryf,'vtypeId':njkbDgcMYsEuHKtvqQwFhLVmXaOrxi(njkbDgcMYsEuHKtvqQwFhLVmXaOryT),'duration':njkbDgcMYsEuHKtvqQwFhLVmXaOrxl(njkbDgcMYsEuHKtvqQwFhLVmXaOroe['duration']/1000)}
    njkbDgcMYsEuHKtvqQwFhLVmXaOrox.append(njkbDgcMYsEuHKtvqQwFhLVmXaOroU)
  except njkbDgcMYsEuHKtvqQwFhLVmXaOrxA as exception:
   njkbDgcMYsEuHKtvqQwFhLVmXaOrxz(exception)
  return njkbDgcMYsEuHKtvqQwFhLVmXaOrox
 def GetReplay_UrlId(njkbDgcMYsEuHKtvqQwFhLVmXaOrWI,njkbDgcMYsEuHKtvqQwFhLVmXaOrxf,njkbDgcMYsEuHKtvqQwFhLVmXaOryT):
  njkbDgcMYsEuHKtvqQwFhLVmXaOrxT=njkbDgcMYsEuHKtvqQwFhLVmXaOrdU=''
  njkbDgcMYsEuHKtvqQwFhLVmXaOrxN=''
  try:
   njkbDgcMYsEuHKtvqQwFhLVmXaOroC=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.API_DOMAIN+'/api/v2/vod/'+njkbDgcMYsEuHKtvqQwFhLVmXaOrxf
   njkbDgcMYsEuHKtvqQwFhLVmXaOrWz=njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.callRequestCookies('Get',njkbDgcMYsEuHKtvqQwFhLVmXaOroC,payload=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,params=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,headers=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ,cookies=njkbDgcMYsEuHKtvqQwFhLVmXaOrxJ)
   njkbDgcMYsEuHKtvqQwFhLVmXaOrWA=json.loads(njkbDgcMYsEuHKtvqQwFhLVmXaOrWz.text)
   njkbDgcMYsEuHKtvqQwFhLVmXaOrxT =njkbDgcMYsEuHKtvqQwFhLVmXaOrWA['clipId']
   njkbDgcMYsEuHKtvqQwFhLVmXaOrdU=njkbDgcMYsEuHKtvqQwFhLVmXaOrWA['videoId']
   njkbDgcMYsEuHKtvqQwFhLVmXaOrxN=njkbDgcMYsEuHKtvqQwFhLVmXaOrxT
   if njkbDgcMYsEuHKtvqQwFhLVmXaOrWI.CheckSubEnd()or njkbDgcMYsEuHKtvqQwFhLVmXaOryT!='1':njkbDgcMYsEuHKtvqQwFhLVmXaOrxN=njkbDgcMYsEuHKtvqQwFhLVmXaOrdU 
  except njkbDgcMYsEuHKtvqQwFhLVmXaOrxA as exception:
   njkbDgcMYsEuHKtvqQwFhLVmXaOrxz(exception)
  return njkbDgcMYsEuHKtvqQwFhLVmXaOrxN
# Created by pyminifier (https://github.com/liftoff/pyminifier)
