__author__="NightRain"
mlHJndpAhMsCExfNGOYDVgPKiWaoQL=object
mlHJndpAhMsCExfNGOYDVgPKiWaoQv=None
mlHJndpAhMsCExfNGOYDVgPKiWaoQc=False
mlHJndpAhMsCExfNGOYDVgPKiWaoQb=True
mlHJndpAhMsCExfNGOYDVgPKiWaoQR=int
mlHJndpAhMsCExfNGOYDVgPKiWaoQj=len
mlHJndpAhMsCExfNGOYDVgPKiWaoQr=str
mlHJndpAhMsCExfNGOYDVgPKiWaoQz=open
mlHJndpAhMsCExfNGOYDVgPKiWaoQt=Exception
mlHJndpAhMsCExfNGOYDVgPKiWaoQu=print
mlHJndpAhMsCExfNGOYDVgPKiWaoQF=dict
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
mlHJndpAhMsCExfNGOYDVgPKiWaoTS=[{'title':'Live중계 (경기중에만 재생)','mode':'ELIVE_GROUP','icon':'live.png'},{'title':'-----------------','mode':'XXX'},{'title':'오늘의 추천 VOD','mode':'NOW_GROUP'},{'title':'인기영상 5','mode':'POP_GROUP'},{'title':'-----------------','mode':'XXX'},{'title':'VOD (리그, 경기별)','mode':'VOD_GROUP'},{'title':'Watched (시청목록)','mode':'WATCH','icon':'history.png'},]
mlHJndpAhMsCExfNGOYDVgPKiWaoTX=xbmcvfs.translatePath(os.path.join(__profile__,'spotv_cookies.json'))
from spotvCore import*
class mlHJndpAhMsCExfNGOYDVgPKiWaoTk(mlHJndpAhMsCExfNGOYDVgPKiWaoQL):
 def __init__(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ,mlHJndpAhMsCExfNGOYDVgPKiWaoTe,mlHJndpAhMsCExfNGOYDVgPKiWaoTy,mlHJndpAhMsCExfNGOYDVgPKiWaoTq):
  mlHJndpAhMsCExfNGOYDVgPKiWaoTQ._addon_url =mlHJndpAhMsCExfNGOYDVgPKiWaoTe
  mlHJndpAhMsCExfNGOYDVgPKiWaoTQ._addon_handle=mlHJndpAhMsCExfNGOYDVgPKiWaoTy
  mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.main_params =mlHJndpAhMsCExfNGOYDVgPKiWaoTq
  mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.SpotvObj =njkbDgcMYsEuHKtvqQwFhLVmXaOrWo() 
 def addon_noti(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ,sting):
  try:
   mlHJndpAhMsCExfNGOYDVgPKiWaoTI=xbmcgui.Dialog()
   mlHJndpAhMsCExfNGOYDVgPKiWaoTI.notification(__addonname__,sting)
  except:
   mlHJndpAhMsCExfNGOYDVgPKiWaoQv
 def addon_log(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ,string):
  try:
   mlHJndpAhMsCExfNGOYDVgPKiWaoTL=string.encode('utf-8','ignore')
  except:
   mlHJndpAhMsCExfNGOYDVgPKiWaoTL='addonException: addon_log'
  mlHJndpAhMsCExfNGOYDVgPKiWaoTv=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,mlHJndpAhMsCExfNGOYDVgPKiWaoTL),level=mlHJndpAhMsCExfNGOYDVgPKiWaoTv)
 def get_keyboard_input(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ,mlHJndpAhMsCExfNGOYDVgPKiWaoTu):
  mlHJndpAhMsCExfNGOYDVgPKiWaoTc=mlHJndpAhMsCExfNGOYDVgPKiWaoQv
  kb=xbmc.Keyboard()
  kb.setHeading(mlHJndpAhMsCExfNGOYDVgPKiWaoTu)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   mlHJndpAhMsCExfNGOYDVgPKiWaoTc=kb.getText()
  return mlHJndpAhMsCExfNGOYDVgPKiWaoTc
 def get_settings_login_info(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ):
  mlHJndpAhMsCExfNGOYDVgPKiWaoTb =__addon__.getSetting('id')
  mlHJndpAhMsCExfNGOYDVgPKiWaoTR =__addon__.getSetting('pw')
  return(mlHJndpAhMsCExfNGOYDVgPKiWaoTb,mlHJndpAhMsCExfNGOYDVgPKiWaoTR)
 def get_settings_hidescoreyn(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ):
  mlHJndpAhMsCExfNGOYDVgPKiWaoTj =__addon__.getSetting('hidescore')
  if mlHJndpAhMsCExfNGOYDVgPKiWaoTj=='false':
   return mlHJndpAhMsCExfNGOYDVgPKiWaoQc
  else:
   return mlHJndpAhMsCExfNGOYDVgPKiWaoQb
 def set_winCredential(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ,credential):
  mlHJndpAhMsCExfNGOYDVgPKiWaoTr=xbmcgui.Window(10000)
  mlHJndpAhMsCExfNGOYDVgPKiWaoTr.setProperty('SPOTV_M_SESSIONID',credential.get('spotv_sessionid'))
  mlHJndpAhMsCExfNGOYDVgPKiWaoTr.setProperty('SPOTV_M_SESSION',credential.get('spotv_session'))
  mlHJndpAhMsCExfNGOYDVgPKiWaoTr.setProperty('SPOTV_M_ACCOUNTID',credential.get('spotv_accountId'))
  mlHJndpAhMsCExfNGOYDVgPKiWaoTr.setProperty('SPOTV_M_POLICYKEY',credential.get('spotv_policyKey'))
  mlHJndpAhMsCExfNGOYDVgPKiWaoTr.setProperty('SPOTV_M_SUBEND',credential.get('spotv_subend'))
  mlHJndpAhMsCExfNGOYDVgPKiWaoTr.setProperty('SPOTV_M_LOGINTIME',mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.SpotvObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ):
  mlHJndpAhMsCExfNGOYDVgPKiWaoTr=xbmcgui.Window(10000)
  mlHJndpAhMsCExfNGOYDVgPKiWaoTz={'spotv_sessionid':mlHJndpAhMsCExfNGOYDVgPKiWaoTr.getProperty('SPOTV_M_SESSIONID'),'spotv_session':mlHJndpAhMsCExfNGOYDVgPKiWaoTr.getProperty('SPOTV_M_SESSION'),'spotv_accountId':mlHJndpAhMsCExfNGOYDVgPKiWaoTr.getProperty('SPOTV_M_ACCOUNTID'),'spotv_policyKey':mlHJndpAhMsCExfNGOYDVgPKiWaoTr.getProperty('SPOTV_M_POLICYKEY'),'spotv_subend':mlHJndpAhMsCExfNGOYDVgPKiWaoTr.getProperty('SPOTV_M_SUBEND')}
  return mlHJndpAhMsCExfNGOYDVgPKiWaoTz
 def add_dir(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ,label,sublabel='',img='',infoLabels=mlHJndpAhMsCExfNGOYDVgPKiWaoQv,isFolder=mlHJndpAhMsCExfNGOYDVgPKiWaoQb,params='',isLink=mlHJndpAhMsCExfNGOYDVgPKiWaoQc,ContextMenu=mlHJndpAhMsCExfNGOYDVgPKiWaoQv):
  mlHJndpAhMsCExfNGOYDVgPKiWaoTt='%s?%s'%(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ._addon_url,urllib.parse.urlencode(params))
  if sublabel:mlHJndpAhMsCExfNGOYDVgPKiWaoTu='%s < %s >'%(label,sublabel)
  else: mlHJndpAhMsCExfNGOYDVgPKiWaoTu=label
  if not img:img='DefaultFolder.png'
  mlHJndpAhMsCExfNGOYDVgPKiWaoTF=xbmcgui.ListItem(mlHJndpAhMsCExfNGOYDVgPKiWaoTu)
  mlHJndpAhMsCExfNGOYDVgPKiWaoTF.setArt({'thumb':img,'icon':img,'poster':img})
  if infoLabels:mlHJndpAhMsCExfNGOYDVgPKiWaoTF.setInfo(type="Video",infoLabels=infoLabels)
  if not isFolder and not isLink:
   mlHJndpAhMsCExfNGOYDVgPKiWaoTF.setProperty('IsPlayable','true')
  if ContextMenu:mlHJndpAhMsCExfNGOYDVgPKiWaoTF.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ._addon_handle,mlHJndpAhMsCExfNGOYDVgPKiWaoTt,mlHJndpAhMsCExfNGOYDVgPKiWaoTF,isFolder)
 def get_selQuality(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ,etype):
  try:
   mlHJndpAhMsCExfNGOYDVgPKiWaoTU='selected_quality'
   mlHJndpAhMsCExfNGOYDVgPKiWaoTw=[1080,720,540]
   mlHJndpAhMsCExfNGOYDVgPKiWaokT=mlHJndpAhMsCExfNGOYDVgPKiWaoQR(__addon__.getSetting(mlHJndpAhMsCExfNGOYDVgPKiWaoTU))
   return mlHJndpAhMsCExfNGOYDVgPKiWaoTw[mlHJndpAhMsCExfNGOYDVgPKiWaokT]
  except:
   mlHJndpAhMsCExfNGOYDVgPKiWaoQv
  return 1080 
 def dp_Main_List(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ):
  for mlHJndpAhMsCExfNGOYDVgPKiWaokS in mlHJndpAhMsCExfNGOYDVgPKiWaoTS:
   mlHJndpAhMsCExfNGOYDVgPKiWaoTu=mlHJndpAhMsCExfNGOYDVgPKiWaokS.get('title')
   mlHJndpAhMsCExfNGOYDVgPKiWaokX=''
   mlHJndpAhMsCExfNGOYDVgPKiWaokQ={'mode':mlHJndpAhMsCExfNGOYDVgPKiWaokS.get('mode'),'page':'1'}
   if mlHJndpAhMsCExfNGOYDVgPKiWaokS.get('mode')=='XXX':
    mlHJndpAhMsCExfNGOYDVgPKiWaoke=mlHJndpAhMsCExfNGOYDVgPKiWaoQc
    mlHJndpAhMsCExfNGOYDVgPKiWaoky =mlHJndpAhMsCExfNGOYDVgPKiWaoQb
   else:
    mlHJndpAhMsCExfNGOYDVgPKiWaoke=mlHJndpAhMsCExfNGOYDVgPKiWaoQb
    mlHJndpAhMsCExfNGOYDVgPKiWaoky =mlHJndpAhMsCExfNGOYDVgPKiWaoQc
   if 'icon' in mlHJndpAhMsCExfNGOYDVgPKiWaokS:mlHJndpAhMsCExfNGOYDVgPKiWaokX=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',mlHJndpAhMsCExfNGOYDVgPKiWaokS.get('icon')) 
   mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.add_dir(mlHJndpAhMsCExfNGOYDVgPKiWaoTu,sublabel='',img=mlHJndpAhMsCExfNGOYDVgPKiWaokX,infoLabels=mlHJndpAhMsCExfNGOYDVgPKiWaoQv,isFolder=mlHJndpAhMsCExfNGOYDVgPKiWaoke,params=mlHJndpAhMsCExfNGOYDVgPKiWaokQ,isLink=mlHJndpAhMsCExfNGOYDVgPKiWaoky)
  if mlHJndpAhMsCExfNGOYDVgPKiWaoQj(mlHJndpAhMsCExfNGOYDVgPKiWaoTS)>0:xbmcplugin.endOfDirectory(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ._addon_handle)
 def dp_MainLeague_List(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ,args):
  mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.SpotvObj.SaveCredential(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.get_winCredential())
  mlHJndpAhMsCExfNGOYDVgPKiWaokB=mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.SpotvObj.GetTitleGroupList()
  for mlHJndpAhMsCExfNGOYDVgPKiWaokI in mlHJndpAhMsCExfNGOYDVgPKiWaokB:
   mlHJndpAhMsCExfNGOYDVgPKiWaoTu =mlHJndpAhMsCExfNGOYDVgPKiWaokI.get('title')
   mlHJndpAhMsCExfNGOYDVgPKiWaokL =mlHJndpAhMsCExfNGOYDVgPKiWaokI.get('logo')
   mlHJndpAhMsCExfNGOYDVgPKiWaokv =mlHJndpAhMsCExfNGOYDVgPKiWaokI.get('reagueId')
   mlHJndpAhMsCExfNGOYDVgPKiWaokc =mlHJndpAhMsCExfNGOYDVgPKiWaokI.get('subGame')
   mlHJndpAhMsCExfNGOYDVgPKiWaokb={'mediatype':'episode','plot':'%s\n\n%s'%(mlHJndpAhMsCExfNGOYDVgPKiWaoTu,mlHJndpAhMsCExfNGOYDVgPKiWaokc)}
   mlHJndpAhMsCExfNGOYDVgPKiWaokQ={'mode':'LEAGUE_GROUP','reagueId':mlHJndpAhMsCExfNGOYDVgPKiWaokv}
   mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.add_dir(mlHJndpAhMsCExfNGOYDVgPKiWaoTu,sublabel=mlHJndpAhMsCExfNGOYDVgPKiWaoQv,img=mlHJndpAhMsCExfNGOYDVgPKiWaokL,infoLabels=mlHJndpAhMsCExfNGOYDVgPKiWaokb,isFolder=mlHJndpAhMsCExfNGOYDVgPKiWaoQb,params=mlHJndpAhMsCExfNGOYDVgPKiWaokQ)
  if mlHJndpAhMsCExfNGOYDVgPKiWaoQj(mlHJndpAhMsCExfNGOYDVgPKiWaokB)>0:xbmcplugin.endOfDirectory(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ._addon_handle,cacheToDisc=mlHJndpAhMsCExfNGOYDVgPKiWaoQc)
 def dp_NowVod_GroupList(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ,args):
  mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.SpotvObj.SaveCredential(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.get_winCredential())
  mlHJndpAhMsCExfNGOYDVgPKiWaokR=mlHJndpAhMsCExfNGOYDVgPKiWaoQR(args.get('page'))
  mlHJndpAhMsCExfNGOYDVgPKiWaokB,mlHJndpAhMsCExfNGOYDVgPKiWaokj=mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.SpotvObj.Get_NowVod_GroupList(mlHJndpAhMsCExfNGOYDVgPKiWaokR)
  for mlHJndpAhMsCExfNGOYDVgPKiWaokI in mlHJndpAhMsCExfNGOYDVgPKiWaokB:
   mlHJndpAhMsCExfNGOYDVgPKiWaokr =mlHJndpAhMsCExfNGOYDVgPKiWaokI.get('vodTitle')
   mlHJndpAhMsCExfNGOYDVgPKiWaokz =mlHJndpAhMsCExfNGOYDVgPKiWaokI.get('vodId')
   mlHJndpAhMsCExfNGOYDVgPKiWaokt =mlHJndpAhMsCExfNGOYDVgPKiWaokI.get('vodType')
   mlHJndpAhMsCExfNGOYDVgPKiWaokL=mlHJndpAhMsCExfNGOYDVgPKiWaokI.get('thumbnail')
   mlHJndpAhMsCExfNGOYDVgPKiWaoku =mlHJndpAhMsCExfNGOYDVgPKiWaokI.get('vtypeId')
   mlHJndpAhMsCExfNGOYDVgPKiWaokF =mlHJndpAhMsCExfNGOYDVgPKiWaokI.get('duration')
   mlHJndpAhMsCExfNGOYDVgPKiWaokb={'mediatype':'video','duration':mlHJndpAhMsCExfNGOYDVgPKiWaokF,'plot':mlHJndpAhMsCExfNGOYDVgPKiWaokr}
   mlHJndpAhMsCExfNGOYDVgPKiWaokQ={'mode':'NOW_VOD','mediacode':mlHJndpAhMsCExfNGOYDVgPKiWaokz,'mediatype':'vod','vtypeId':mlHJndpAhMsCExfNGOYDVgPKiWaoku}
   mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.add_dir(mlHJndpAhMsCExfNGOYDVgPKiWaokr,sublabel=mlHJndpAhMsCExfNGOYDVgPKiWaokt,img=mlHJndpAhMsCExfNGOYDVgPKiWaokL,infoLabels=mlHJndpAhMsCExfNGOYDVgPKiWaokb,isFolder=mlHJndpAhMsCExfNGOYDVgPKiWaoQc,params=mlHJndpAhMsCExfNGOYDVgPKiWaokQ)
  if mlHJndpAhMsCExfNGOYDVgPKiWaokj:
   mlHJndpAhMsCExfNGOYDVgPKiWaokQ['mode'] ='NOW_GROUP' 
   mlHJndpAhMsCExfNGOYDVgPKiWaokQ['page'] =mlHJndpAhMsCExfNGOYDVgPKiWaoQr(mlHJndpAhMsCExfNGOYDVgPKiWaokR+1)
   mlHJndpAhMsCExfNGOYDVgPKiWaoTu='[B]%s >>[/B]'%'다음 페이지'
   mlHJndpAhMsCExfNGOYDVgPKiWaokU=mlHJndpAhMsCExfNGOYDVgPKiWaoQr(mlHJndpAhMsCExfNGOYDVgPKiWaokR+1)
   mlHJndpAhMsCExfNGOYDVgPKiWaokX=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.add_dir(mlHJndpAhMsCExfNGOYDVgPKiWaoTu,sublabel=mlHJndpAhMsCExfNGOYDVgPKiWaokU,img=mlHJndpAhMsCExfNGOYDVgPKiWaokX,infoLabels=mlHJndpAhMsCExfNGOYDVgPKiWaoQv,isFolder=mlHJndpAhMsCExfNGOYDVgPKiWaoQb,params=mlHJndpAhMsCExfNGOYDVgPKiWaokQ)
  if mlHJndpAhMsCExfNGOYDVgPKiWaoQj(mlHJndpAhMsCExfNGOYDVgPKiWaokB)>0:xbmcplugin.endOfDirectory(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ._addon_handle,cacheToDisc=mlHJndpAhMsCExfNGOYDVgPKiWaoQc)
 def dp_PopVod_GroupList(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ,args):
  mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.SpotvObj.SaveCredential(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.get_winCredential())
  mlHJndpAhMsCExfNGOYDVgPKiWaokB=mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.SpotvObj.GetPopularGroupList()
  for mlHJndpAhMsCExfNGOYDVgPKiWaokI in mlHJndpAhMsCExfNGOYDVgPKiWaokB:
   mlHJndpAhMsCExfNGOYDVgPKiWaokr =mlHJndpAhMsCExfNGOYDVgPKiWaokI.get('vodTitle')
   mlHJndpAhMsCExfNGOYDVgPKiWaokz =mlHJndpAhMsCExfNGOYDVgPKiWaokI.get('vodId')
   mlHJndpAhMsCExfNGOYDVgPKiWaokt =mlHJndpAhMsCExfNGOYDVgPKiWaokI.get('vodType')
   mlHJndpAhMsCExfNGOYDVgPKiWaokL=mlHJndpAhMsCExfNGOYDVgPKiWaokI.get('thumbnail')
   mlHJndpAhMsCExfNGOYDVgPKiWaoku =mlHJndpAhMsCExfNGOYDVgPKiWaokI.get('vtypeId')
   mlHJndpAhMsCExfNGOYDVgPKiWaokF =mlHJndpAhMsCExfNGOYDVgPKiWaokI.get('duration')
   mlHJndpAhMsCExfNGOYDVgPKiWaokb={'mediatype':'video','duration':mlHJndpAhMsCExfNGOYDVgPKiWaokF,'plot':mlHJndpAhMsCExfNGOYDVgPKiWaokr}
   mlHJndpAhMsCExfNGOYDVgPKiWaokQ={'mode':'POP_VOD','mediacode':mlHJndpAhMsCExfNGOYDVgPKiWaokz,'mediatype':'vod','vtypeId':mlHJndpAhMsCExfNGOYDVgPKiWaoku}
   mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.add_dir(mlHJndpAhMsCExfNGOYDVgPKiWaokr,sublabel=mlHJndpAhMsCExfNGOYDVgPKiWaokt,img=mlHJndpAhMsCExfNGOYDVgPKiWaokL,infoLabels=mlHJndpAhMsCExfNGOYDVgPKiWaokb,isFolder=mlHJndpAhMsCExfNGOYDVgPKiWaoQc,params=mlHJndpAhMsCExfNGOYDVgPKiWaokQ)
  if mlHJndpAhMsCExfNGOYDVgPKiWaoQj(mlHJndpAhMsCExfNGOYDVgPKiWaokB)>0:xbmcplugin.endOfDirectory(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ._addon_handle,cacheToDisc=mlHJndpAhMsCExfNGOYDVgPKiWaoQc)
 def dp_Season_List(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ,args):
  mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.SpotvObj.SaveCredential(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.get_winCredential())
  mlHJndpAhMsCExfNGOYDVgPKiWaokv=args.get('reagueId')
  mlHJndpAhMsCExfNGOYDVgPKiWaokB=mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.SpotvObj.GetSeasonList(mlHJndpAhMsCExfNGOYDVgPKiWaokv)
  for mlHJndpAhMsCExfNGOYDVgPKiWaokI in mlHJndpAhMsCExfNGOYDVgPKiWaokB:
   mlHJndpAhMsCExfNGOYDVgPKiWaokw =mlHJndpAhMsCExfNGOYDVgPKiWaokI.get('reagueName')
   mlHJndpAhMsCExfNGOYDVgPKiWaoST =mlHJndpAhMsCExfNGOYDVgPKiWaokI.get('gameTypeId')
   mlHJndpAhMsCExfNGOYDVgPKiWaoSk =mlHJndpAhMsCExfNGOYDVgPKiWaokI.get('seasonName')
   mlHJndpAhMsCExfNGOYDVgPKiWaoSX =mlHJndpAhMsCExfNGOYDVgPKiWaokI.get('seasonId')
   mlHJndpAhMsCExfNGOYDVgPKiWaokb={'mediatype':'episode','plot':'%s - %s'%(mlHJndpAhMsCExfNGOYDVgPKiWaokw,mlHJndpAhMsCExfNGOYDVgPKiWaoSk)}
   mlHJndpAhMsCExfNGOYDVgPKiWaokQ={'mode':'SEASON_GROUP','reagueId':mlHJndpAhMsCExfNGOYDVgPKiWaokv,'seasonId':mlHJndpAhMsCExfNGOYDVgPKiWaoSX,'gameTypeId':mlHJndpAhMsCExfNGOYDVgPKiWaoST,'page':'1'}
   mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.add_dir(mlHJndpAhMsCExfNGOYDVgPKiWaokw,sublabel=mlHJndpAhMsCExfNGOYDVgPKiWaoSk,img='',infoLabels=mlHJndpAhMsCExfNGOYDVgPKiWaokb,isFolder=mlHJndpAhMsCExfNGOYDVgPKiWaoQb,params=mlHJndpAhMsCExfNGOYDVgPKiWaokQ)
  if mlHJndpAhMsCExfNGOYDVgPKiWaoQj(mlHJndpAhMsCExfNGOYDVgPKiWaokB)>0:xbmcplugin.endOfDirectory(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ._addon_handle,cacheToDisc=mlHJndpAhMsCExfNGOYDVgPKiWaoQb)
 def dp_Game_List(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ,args):
  mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.SpotvObj.SaveCredential(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.get_winCredential())
  mlHJndpAhMsCExfNGOYDVgPKiWaoST=args.get('gameTypeId')
  mlHJndpAhMsCExfNGOYDVgPKiWaokv =args.get('reagueId')
  mlHJndpAhMsCExfNGOYDVgPKiWaoSX =args.get('seasonId')
  mlHJndpAhMsCExfNGOYDVgPKiWaokR =mlHJndpAhMsCExfNGOYDVgPKiWaoQR(args.get('page'))
  mlHJndpAhMsCExfNGOYDVgPKiWaokB,mlHJndpAhMsCExfNGOYDVgPKiWaokj=mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.SpotvObj.GetGameList(mlHJndpAhMsCExfNGOYDVgPKiWaoST,mlHJndpAhMsCExfNGOYDVgPKiWaokv,mlHJndpAhMsCExfNGOYDVgPKiWaoSX,mlHJndpAhMsCExfNGOYDVgPKiWaokR,hidescore=mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.get_settings_hidescoreyn())
  for mlHJndpAhMsCExfNGOYDVgPKiWaokI in mlHJndpAhMsCExfNGOYDVgPKiWaokB:
   mlHJndpAhMsCExfNGOYDVgPKiWaoSQ =mlHJndpAhMsCExfNGOYDVgPKiWaokI.get('gameTitle')
   mlHJndpAhMsCExfNGOYDVgPKiWaoSe =mlHJndpAhMsCExfNGOYDVgPKiWaokI.get('beginDate')
   mlHJndpAhMsCExfNGOYDVgPKiWaokL =mlHJndpAhMsCExfNGOYDVgPKiWaokI.get('thumbnail')
   mlHJndpAhMsCExfNGOYDVgPKiWaoSy =mlHJndpAhMsCExfNGOYDVgPKiWaokI.get('gameId')
   mlHJndpAhMsCExfNGOYDVgPKiWaoSq =mlHJndpAhMsCExfNGOYDVgPKiWaokI.get('totVodCnt')
   mlHJndpAhMsCExfNGOYDVgPKiWaoSB =mlHJndpAhMsCExfNGOYDVgPKiWaokI.get('leaguenm')
   mlHJndpAhMsCExfNGOYDVgPKiWaoSI =mlHJndpAhMsCExfNGOYDVgPKiWaokI.get('seasonnm')
   mlHJndpAhMsCExfNGOYDVgPKiWaoSL =mlHJndpAhMsCExfNGOYDVgPKiWaokI.get('roundnm')
   mlHJndpAhMsCExfNGOYDVgPKiWaoSv =mlHJndpAhMsCExfNGOYDVgPKiWaokI.get('info_plot')
   mlHJndpAhMsCExfNGOYDVgPKiWaoSc ='%s < %s >'%(mlHJndpAhMsCExfNGOYDVgPKiWaoSQ,mlHJndpAhMsCExfNGOYDVgPKiWaoSe)
   mlHJndpAhMsCExfNGOYDVgPKiWaokb={'mediatype':'video','plot':mlHJndpAhMsCExfNGOYDVgPKiWaoSv}
   mlHJndpAhMsCExfNGOYDVgPKiWaokQ={'mode':'GAME_VOD_GROUP' if mlHJndpAhMsCExfNGOYDVgPKiWaoSq!=0 else 'XXX','saveTitle':mlHJndpAhMsCExfNGOYDVgPKiWaoSc,'saveImg':mlHJndpAhMsCExfNGOYDVgPKiWaokL,'saveInfo':mlHJndpAhMsCExfNGOYDVgPKiWaokb['plot'],'gameid':mlHJndpAhMsCExfNGOYDVgPKiWaoSy}
   mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.add_dir(mlHJndpAhMsCExfNGOYDVgPKiWaoSQ,sublabel=mlHJndpAhMsCExfNGOYDVgPKiWaoSe,img=mlHJndpAhMsCExfNGOYDVgPKiWaokL,infoLabels=mlHJndpAhMsCExfNGOYDVgPKiWaokb,isFolder=mlHJndpAhMsCExfNGOYDVgPKiWaoQb,params=mlHJndpAhMsCExfNGOYDVgPKiWaokQ)
  if mlHJndpAhMsCExfNGOYDVgPKiWaokj:
   mlHJndpAhMsCExfNGOYDVgPKiWaokQ['mode'] ='SEASON_GROUP' 
   mlHJndpAhMsCExfNGOYDVgPKiWaokQ['reagueId'] =mlHJndpAhMsCExfNGOYDVgPKiWaokv
   mlHJndpAhMsCExfNGOYDVgPKiWaokQ['seasonId'] =mlHJndpAhMsCExfNGOYDVgPKiWaoSX
   mlHJndpAhMsCExfNGOYDVgPKiWaokQ['gameTypeId']=mlHJndpAhMsCExfNGOYDVgPKiWaoST
   mlHJndpAhMsCExfNGOYDVgPKiWaokQ['page'] =mlHJndpAhMsCExfNGOYDVgPKiWaoQr(mlHJndpAhMsCExfNGOYDVgPKiWaokR+1)
   mlHJndpAhMsCExfNGOYDVgPKiWaoTu='[B]%s >>[/B]'%'다음 페이지'
   mlHJndpAhMsCExfNGOYDVgPKiWaokU=mlHJndpAhMsCExfNGOYDVgPKiWaoQr(mlHJndpAhMsCExfNGOYDVgPKiWaokR+1)
   mlHJndpAhMsCExfNGOYDVgPKiWaokX=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.add_dir(mlHJndpAhMsCExfNGOYDVgPKiWaoTu,sublabel=mlHJndpAhMsCExfNGOYDVgPKiWaokU,img=mlHJndpAhMsCExfNGOYDVgPKiWaokX,infoLabels=mlHJndpAhMsCExfNGOYDVgPKiWaoQv,isFolder=mlHJndpAhMsCExfNGOYDVgPKiWaoQb,params=mlHJndpAhMsCExfNGOYDVgPKiWaokQ)
  if mlHJndpAhMsCExfNGOYDVgPKiWaoQj(mlHJndpAhMsCExfNGOYDVgPKiWaokB)>0:xbmcplugin.endOfDirectory(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ._addon_handle,cacheToDisc=mlHJndpAhMsCExfNGOYDVgPKiWaoQc)
 def dp_GameVod_List(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ,args):
  mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.SpotvObj.SaveCredential(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.get_winCredential())
  mlHJndpAhMsCExfNGOYDVgPKiWaoSb =args.get('gameid')
  mlHJndpAhMsCExfNGOYDVgPKiWaoSc=args.get('saveTitle')
  mlHJndpAhMsCExfNGOYDVgPKiWaoSR =args.get('saveImg')
  mlHJndpAhMsCExfNGOYDVgPKiWaoSj =args.get('saveInfo')
  mlHJndpAhMsCExfNGOYDVgPKiWaokB=mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.SpotvObj.GetGameVodList(mlHJndpAhMsCExfNGOYDVgPKiWaoSb)
  for mlHJndpAhMsCExfNGOYDVgPKiWaokI in mlHJndpAhMsCExfNGOYDVgPKiWaokB:
   mlHJndpAhMsCExfNGOYDVgPKiWaokr =mlHJndpAhMsCExfNGOYDVgPKiWaokI.get('vodTitle')
   mlHJndpAhMsCExfNGOYDVgPKiWaokz =mlHJndpAhMsCExfNGOYDVgPKiWaokI.get('vodId')
   mlHJndpAhMsCExfNGOYDVgPKiWaokt =mlHJndpAhMsCExfNGOYDVgPKiWaokI.get('vodType')
   mlHJndpAhMsCExfNGOYDVgPKiWaokL=mlHJndpAhMsCExfNGOYDVgPKiWaokI.get('thumbnail')
   mlHJndpAhMsCExfNGOYDVgPKiWaoku =mlHJndpAhMsCExfNGOYDVgPKiWaokI.get('vtypeId')
   mlHJndpAhMsCExfNGOYDVgPKiWaokF =mlHJndpAhMsCExfNGOYDVgPKiWaokI.get('duration')
   mlHJndpAhMsCExfNGOYDVgPKiWaokb={'mediatype':'video','duration':mlHJndpAhMsCExfNGOYDVgPKiWaokF,'plot':'%s \n\n %s'%(mlHJndpAhMsCExfNGOYDVgPKiWaokr,mlHJndpAhMsCExfNGOYDVgPKiWaoSj)}
   mlHJndpAhMsCExfNGOYDVgPKiWaokQ={'mode':'GAME_VOD','saveTitle':mlHJndpAhMsCExfNGOYDVgPKiWaoSc,'saveImg':mlHJndpAhMsCExfNGOYDVgPKiWaoSR,'saveId':mlHJndpAhMsCExfNGOYDVgPKiWaoSb,'saveInfo':mlHJndpAhMsCExfNGOYDVgPKiWaoSj,'mediacode':mlHJndpAhMsCExfNGOYDVgPKiWaokz,'mediatype':'vod','vtypeId':mlHJndpAhMsCExfNGOYDVgPKiWaoku}
   mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.add_dir(mlHJndpAhMsCExfNGOYDVgPKiWaokr,sublabel=mlHJndpAhMsCExfNGOYDVgPKiWaokt,img=mlHJndpAhMsCExfNGOYDVgPKiWaokL,infoLabels=mlHJndpAhMsCExfNGOYDVgPKiWaokb,isFolder=mlHJndpAhMsCExfNGOYDVgPKiWaoQc,params=mlHJndpAhMsCExfNGOYDVgPKiWaokQ)
  if mlHJndpAhMsCExfNGOYDVgPKiWaoQj(mlHJndpAhMsCExfNGOYDVgPKiWaokB)>0:xbmcplugin.endOfDirectory(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ._addon_handle,cacheToDisc=mlHJndpAhMsCExfNGOYDVgPKiWaoQc)
 def login_main(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ):
  (mlHJndpAhMsCExfNGOYDVgPKiWaoSr,mlHJndpAhMsCExfNGOYDVgPKiWaoSz)=mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.get_settings_login_info()
  if not(mlHJndpAhMsCExfNGOYDVgPKiWaoSr and mlHJndpAhMsCExfNGOYDVgPKiWaoSz):
   mlHJndpAhMsCExfNGOYDVgPKiWaoTI=xbmcgui.Dialog()
   mlHJndpAhMsCExfNGOYDVgPKiWaoSt=mlHJndpAhMsCExfNGOYDVgPKiWaoTI.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if mlHJndpAhMsCExfNGOYDVgPKiWaoSt==mlHJndpAhMsCExfNGOYDVgPKiWaoQb:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.cookiefile_check():return
  mlHJndpAhMsCExfNGOYDVgPKiWaoSu =mlHJndpAhMsCExfNGOYDVgPKiWaoQR(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))
  mlHJndpAhMsCExfNGOYDVgPKiWaoSF=xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINTIME')
  if mlHJndpAhMsCExfNGOYDVgPKiWaoSF==mlHJndpAhMsCExfNGOYDVgPKiWaoQv or mlHJndpAhMsCExfNGOYDVgPKiWaoSF=='':
   mlHJndpAhMsCExfNGOYDVgPKiWaoSF=mlHJndpAhMsCExfNGOYDVgPKiWaoQR('19000101')
  else:
   mlHJndpAhMsCExfNGOYDVgPKiWaoSF=mlHJndpAhMsCExfNGOYDVgPKiWaoQR(re.sub('-','',mlHJndpAhMsCExfNGOYDVgPKiWaoSF))
  if xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINWAIT')=='TRUE':
   mlHJndpAhMsCExfNGOYDVgPKiWaoSU=0
   while mlHJndpAhMsCExfNGOYDVgPKiWaoQb:
    mlHJndpAhMsCExfNGOYDVgPKiWaoSU+=1
    time.sleep(0.05)
    if mlHJndpAhMsCExfNGOYDVgPKiWaoSF>=mlHJndpAhMsCExfNGOYDVgPKiWaoSu:return
    if mlHJndpAhMsCExfNGOYDVgPKiWaoSU>600:return
  else:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','TRUE')
  if mlHJndpAhMsCExfNGOYDVgPKiWaoSF>=mlHJndpAhMsCExfNGOYDVgPKiWaoSu:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
   return
  if not mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.SpotvObj.GetCredential(mlHJndpAhMsCExfNGOYDVgPKiWaoSr,mlHJndpAhMsCExfNGOYDVgPKiWaoSz):
   mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
   sys.exit()
  mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.set_winCredential(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.SpotvObj.LoadCredential())
  mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.cookiefile_save()
  xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
 def dp_LiveChannel_List(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ,args):
  mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.SpotvObj.SaveCredential(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.get_winCredential())
  mlHJndpAhMsCExfNGOYDVgPKiWaoSw=mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.SpotvObj.GetLiveChannelList()
  for mlHJndpAhMsCExfNGOYDVgPKiWaoXT in mlHJndpAhMsCExfNGOYDVgPKiWaoSw:
   mlHJndpAhMsCExfNGOYDVgPKiWaoTu =mlHJndpAhMsCExfNGOYDVgPKiWaoXT.get('name')
   mlHJndpAhMsCExfNGOYDVgPKiWaokL =mlHJndpAhMsCExfNGOYDVgPKiWaoXT.get('logo')
   mlHJndpAhMsCExfNGOYDVgPKiWaoXk=mlHJndpAhMsCExfNGOYDVgPKiWaoXT.get('channelepg')
   mlHJndpAhMsCExfNGOYDVgPKiWaoXS =mlHJndpAhMsCExfNGOYDVgPKiWaoXT.get('free')
   if mlHJndpAhMsCExfNGOYDVgPKiWaoXk:
    mlHJndpAhMsCExfNGOYDVgPKiWaoXQ =mlHJndpAhMsCExfNGOYDVgPKiWaoXk['epg']
    mlHJndpAhMsCExfNGOYDVgPKiWaoXe=mlHJndpAhMsCExfNGOYDVgPKiWaoXk['title']
   else:
    mlHJndpAhMsCExfNGOYDVgPKiWaoXQ =''
    mlHJndpAhMsCExfNGOYDVgPKiWaoXe=''
   mlHJndpAhMsCExfNGOYDVgPKiWaokb={'plot':'%s\n\n%s'%(mlHJndpAhMsCExfNGOYDVgPKiWaoTu,mlHJndpAhMsCExfNGOYDVgPKiWaoXQ),'mediatype':'video'}
   mlHJndpAhMsCExfNGOYDVgPKiWaokQ={'mode':'LIVE','mediacode':mlHJndpAhMsCExfNGOYDVgPKiWaoXT.get('videoId'),'free':mlHJndpAhMsCExfNGOYDVgPKiWaoXS,'mediatype':'live'}
   if mlHJndpAhMsCExfNGOYDVgPKiWaoXS:mlHJndpAhMsCExfNGOYDVgPKiWaoTu+=' [free]'
   mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.add_dir(mlHJndpAhMsCExfNGOYDVgPKiWaoTu,sublabel=mlHJndpAhMsCExfNGOYDVgPKiWaoXe,img=mlHJndpAhMsCExfNGOYDVgPKiWaokL,infoLabels=mlHJndpAhMsCExfNGOYDVgPKiWaokb,isFolder=mlHJndpAhMsCExfNGOYDVgPKiWaoQc,params=mlHJndpAhMsCExfNGOYDVgPKiWaokQ)
  if mlHJndpAhMsCExfNGOYDVgPKiWaoQj(mlHJndpAhMsCExfNGOYDVgPKiWaoSw)>0:xbmcplugin.endOfDirectory(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ._addon_handle,cacheToDisc=mlHJndpAhMsCExfNGOYDVgPKiWaoQc)
 def dp_EventLiveChannel_List(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ,args):
  mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.SpotvObj.SaveCredential(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.get_winCredential())
  mlHJndpAhMsCExfNGOYDVgPKiWaoSw,mlHJndpAhMsCExfNGOYDVgPKiWaoXy=mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.SpotvObj.GetEventLiveList()
  if mlHJndpAhMsCExfNGOYDVgPKiWaoXy!=401 and mlHJndpAhMsCExfNGOYDVgPKiWaoQj(mlHJndpAhMsCExfNGOYDVgPKiWaoSw)==0:
   mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.addon_noti(__language__(30907).encode('utf8'))
  for mlHJndpAhMsCExfNGOYDVgPKiWaoXT in mlHJndpAhMsCExfNGOYDVgPKiWaoSw:
   mlHJndpAhMsCExfNGOYDVgPKiWaoTu =mlHJndpAhMsCExfNGOYDVgPKiWaoXT.get('title')
   mlHJndpAhMsCExfNGOYDVgPKiWaokq =mlHJndpAhMsCExfNGOYDVgPKiWaoXT.get('startTime')
   mlHJndpAhMsCExfNGOYDVgPKiWaokL =mlHJndpAhMsCExfNGOYDVgPKiWaoXT.get('logo')
   mlHJndpAhMsCExfNGOYDVgPKiWaoXS =mlHJndpAhMsCExfNGOYDVgPKiWaoXT.get('free')
   mlHJndpAhMsCExfNGOYDVgPKiWaokb={'mediatype':'video','plot':'%s\n\n%s'%(mlHJndpAhMsCExfNGOYDVgPKiWaoTu,mlHJndpAhMsCExfNGOYDVgPKiWaokq)}
   mlHJndpAhMsCExfNGOYDVgPKiWaokQ={'mode':'ELIVE','mediaid':mlHJndpAhMsCExfNGOYDVgPKiWaoXT.get('liveId'),'mediacode':'','free':mlHJndpAhMsCExfNGOYDVgPKiWaoXS,'mediatype':'live'}
   if mlHJndpAhMsCExfNGOYDVgPKiWaoXS:mlHJndpAhMsCExfNGOYDVgPKiWaoTu+=' [free]'
   mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.add_dir(mlHJndpAhMsCExfNGOYDVgPKiWaoTu,sublabel=mlHJndpAhMsCExfNGOYDVgPKiWaokq,img=mlHJndpAhMsCExfNGOYDVgPKiWaokL,infoLabels=mlHJndpAhMsCExfNGOYDVgPKiWaokb,isFolder=mlHJndpAhMsCExfNGOYDVgPKiWaoQc,params=mlHJndpAhMsCExfNGOYDVgPKiWaokQ)
  if mlHJndpAhMsCExfNGOYDVgPKiWaoQj(mlHJndpAhMsCExfNGOYDVgPKiWaoSw)>0:xbmcplugin.endOfDirectory(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ._addon_handle,cacheToDisc=mlHJndpAhMsCExfNGOYDVgPKiWaoQb)
  return mlHJndpAhMsCExfNGOYDVgPKiWaoXy
 def play_VIDEO(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ,args):
  mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.SpotvObj.SaveCredential(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.get_winCredential())
  mlHJndpAhMsCExfNGOYDVgPKiWaoXq =args.get('mode')
  mlHJndpAhMsCExfNGOYDVgPKiWaoXB =args.get('mediacode')
  mlHJndpAhMsCExfNGOYDVgPKiWaoXI =args.get('mediatype')
  mlHJndpAhMsCExfNGOYDVgPKiWaoku =args.get('vtypeId')
  if mlHJndpAhMsCExfNGOYDVgPKiWaoXq=='LIVE':
   if args.get('free')=='False':
    if mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.SpotvObj.CheckSubEnd()==mlHJndpAhMsCExfNGOYDVgPKiWaoQc:
     mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.addon_noti(__language__(30908).encode('utf8'))
     return
  elif mlHJndpAhMsCExfNGOYDVgPKiWaoXq=='ELIVE':
   if args.get('free')=='False':
    if mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.SpotvObj.CheckSubEnd()==mlHJndpAhMsCExfNGOYDVgPKiWaoQc:
     mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.addon_noti(__language__(30908).encode('utf8'))
     return
   mlHJndpAhMsCExfNGOYDVgPKiWaoXB=mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.SpotvObj.GetEventLive_videoId(args.get('mediaid'))
  if mlHJndpAhMsCExfNGOYDVgPKiWaoXB=='' or mlHJndpAhMsCExfNGOYDVgPKiWaoXB==mlHJndpAhMsCExfNGOYDVgPKiWaoQv:
   mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.addon_noti(__language__(30907).encode('utf8'))
   return
  if mlHJndpAhMsCExfNGOYDVgPKiWaoXq=='LIVE':
   mlHJndpAhMsCExfNGOYDVgPKiWaoXL=mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.SpotvObj.Get_Streamurl_Make(args.get('mediacode'))
  else:
   mlHJndpAhMsCExfNGOYDVgPKiWaoXL=mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.SpotvObj.GetBroadURL(mlHJndpAhMsCExfNGOYDVgPKiWaoXB,mlHJndpAhMsCExfNGOYDVgPKiWaoXI,mlHJndpAhMsCExfNGOYDVgPKiWaoku)
  if mlHJndpAhMsCExfNGOYDVgPKiWaoXL=='':
   mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.addon_noti(__language__(30908).encode('utf8'))
   return
  mlHJndpAhMsCExfNGOYDVgPKiWaoXv=mlHJndpAhMsCExfNGOYDVgPKiWaoXL
  mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.addon_log(mlHJndpAhMsCExfNGOYDVgPKiWaoXv)
  mlHJndpAhMsCExfNGOYDVgPKiWaoXc=xbmcgui.ListItem(path=mlHJndpAhMsCExfNGOYDVgPKiWaoXv)
  xbmcplugin.setResolvedUrl(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ._addon_handle,mlHJndpAhMsCExfNGOYDVgPKiWaoQb,mlHJndpAhMsCExfNGOYDVgPKiWaoXc)
  try:
   if mlHJndpAhMsCExfNGOYDVgPKiWaoXI=='vod' and mlHJndpAhMsCExfNGOYDVgPKiWaoXq not in['POP_VOD','NOW_VOD']:
    mlHJndpAhMsCExfNGOYDVgPKiWaokQ={'code':args.get('saveId'),'img':args.get('saveImg'),'title':args.get('saveTitle'),'info':args.get('saveInfo')}
    mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.Save_Watched_List(mlHJndpAhMsCExfNGOYDVgPKiWaoXI,mlHJndpAhMsCExfNGOYDVgPKiWaokQ)
  except:
   mlHJndpAhMsCExfNGOYDVgPKiWaoQv
 def logout(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ):
  mlHJndpAhMsCExfNGOYDVgPKiWaoTI=xbmcgui.Dialog()
  mlHJndpAhMsCExfNGOYDVgPKiWaoSt=mlHJndpAhMsCExfNGOYDVgPKiWaoTI.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if mlHJndpAhMsCExfNGOYDVgPKiWaoSt==mlHJndpAhMsCExfNGOYDVgPKiWaoQc:sys.exit()
  mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.wininfo_clear()
  if os.path.isfile(mlHJndpAhMsCExfNGOYDVgPKiWaoTX):os.remove(mlHJndpAhMsCExfNGOYDVgPKiWaoTX)
  mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ):
  mlHJndpAhMsCExfNGOYDVgPKiWaoTr=xbmcgui.Window(10000)
  mlHJndpAhMsCExfNGOYDVgPKiWaoTr.setProperty('SPOTV_M_SESSIONID','')
  mlHJndpAhMsCExfNGOYDVgPKiWaoTr.setProperty('SPOTV_M_SESSION','')
  mlHJndpAhMsCExfNGOYDVgPKiWaoTr.setProperty('SPOTV_M_ACCOUNTID','')
  mlHJndpAhMsCExfNGOYDVgPKiWaoTr.setProperty('SPOTV_M_POLICYKEY','')
  mlHJndpAhMsCExfNGOYDVgPKiWaoTr.setProperty('SPOTV_M_SUBEND','')
  mlHJndpAhMsCExfNGOYDVgPKiWaoTr.setProperty('SPOTV_M_LOGINTIME','')
 def cookiefile_save(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ):
  mlHJndpAhMsCExfNGOYDVgPKiWaoXb =mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.SpotvObj.Get_Now_Datetime()
  mlHJndpAhMsCExfNGOYDVgPKiWaoXR=mlHJndpAhMsCExfNGOYDVgPKiWaoXb+datetime.timedelta(days=mlHJndpAhMsCExfNGOYDVgPKiWaoQR(__addon__.getSetting('cache_ttl')))
  mlHJndpAhMsCExfNGOYDVgPKiWaoTr=xbmcgui.Window(10000)
  mlHJndpAhMsCExfNGOYDVgPKiWaoXj={'spotv_sessionid':mlHJndpAhMsCExfNGOYDVgPKiWaoTr.getProperty('SPOTV_M_SESSIONID'),'spotv_session':mlHJndpAhMsCExfNGOYDVgPKiWaoTr.getProperty('SPOTV_M_SESSION'),'spotv_accountId':mlHJndpAhMsCExfNGOYDVgPKiWaoTr.getProperty('SPOTV_M_ACCOUNTID'),'spotv_policyKey':base64.standard_b64encode(mlHJndpAhMsCExfNGOYDVgPKiWaoTr.getProperty('SPOTV_M_POLICYKEY').encode()).decode('utf-8'),'spotv_subend':base64.standard_b64encode((mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.SpotvObj.SPOTV_PMCODE+mlHJndpAhMsCExfNGOYDVgPKiWaoTr.getProperty('SPOTV_M_SUBEND')).encode()).decode('utf-8'),'spotv_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'spotv_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'spotv_limitdate':mlHJndpAhMsCExfNGOYDVgPKiWaoXR.strftime('%Y-%m-%d')}
  try: 
   fp=mlHJndpAhMsCExfNGOYDVgPKiWaoQz(mlHJndpAhMsCExfNGOYDVgPKiWaoTX,'w',-1,'utf-8')
   json.dump(mlHJndpAhMsCExfNGOYDVgPKiWaoXj,fp)
   fp.close()
  except mlHJndpAhMsCExfNGOYDVgPKiWaoQt as exception:
   mlHJndpAhMsCExfNGOYDVgPKiWaoQu(exception)
 def cookiefile_check(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ):
  mlHJndpAhMsCExfNGOYDVgPKiWaoXj={}
  try: 
   fp=mlHJndpAhMsCExfNGOYDVgPKiWaoQz(mlHJndpAhMsCExfNGOYDVgPKiWaoTX,'r',-1,'utf-8')
   mlHJndpAhMsCExfNGOYDVgPKiWaoXj= json.load(fp)
   fp.close()
  except mlHJndpAhMsCExfNGOYDVgPKiWaoQt as exception:
   mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.wininfo_clear()
   return mlHJndpAhMsCExfNGOYDVgPKiWaoQc
  mlHJndpAhMsCExfNGOYDVgPKiWaoSr =__addon__.getSetting('id')
  mlHJndpAhMsCExfNGOYDVgPKiWaoSz =__addon__.getSetting('pw')
  mlHJndpAhMsCExfNGOYDVgPKiWaoXj['spotv_id'] =base64.standard_b64decode(mlHJndpAhMsCExfNGOYDVgPKiWaoXj['spotv_id']).decode('utf-8')
  mlHJndpAhMsCExfNGOYDVgPKiWaoXj['spotv_pw'] =base64.standard_b64decode(mlHJndpAhMsCExfNGOYDVgPKiWaoXj['spotv_pw']).decode('utf-8')
  mlHJndpAhMsCExfNGOYDVgPKiWaoXj['spotv_policyKey']=base64.standard_b64decode(mlHJndpAhMsCExfNGOYDVgPKiWaoXj['spotv_policyKey']).decode('utf-8')
  mlHJndpAhMsCExfNGOYDVgPKiWaoXj['spotv_subend']=base64.standard_b64decode(mlHJndpAhMsCExfNGOYDVgPKiWaoXj['spotv_subend']).decode('utf-8')[mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.SpotvObj.SPOTV_PMSIZE:]
  if mlHJndpAhMsCExfNGOYDVgPKiWaoSr!=mlHJndpAhMsCExfNGOYDVgPKiWaoXj['spotv_id']or mlHJndpAhMsCExfNGOYDVgPKiWaoSz!=mlHJndpAhMsCExfNGOYDVgPKiWaoXj['spotv_pw']:
   mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.wininfo_clear()
   return mlHJndpAhMsCExfNGOYDVgPKiWaoQc
  mlHJndpAhMsCExfNGOYDVgPKiWaoSu =mlHJndpAhMsCExfNGOYDVgPKiWaoQR(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))
  mlHJndpAhMsCExfNGOYDVgPKiWaoXr=mlHJndpAhMsCExfNGOYDVgPKiWaoXj['spotv_limitdate']
  mlHJndpAhMsCExfNGOYDVgPKiWaoSF =mlHJndpAhMsCExfNGOYDVgPKiWaoQR(re.sub('-','',mlHJndpAhMsCExfNGOYDVgPKiWaoXr))
  if mlHJndpAhMsCExfNGOYDVgPKiWaoSF<mlHJndpAhMsCExfNGOYDVgPKiWaoSu:
   mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.wininfo_clear()
   return mlHJndpAhMsCExfNGOYDVgPKiWaoQc
  mlHJndpAhMsCExfNGOYDVgPKiWaoTr=xbmcgui.Window(10000)
  mlHJndpAhMsCExfNGOYDVgPKiWaoTr.setProperty('SPOTV_M_SESSIONID',mlHJndpAhMsCExfNGOYDVgPKiWaoXj['spotv_sessionid'])
  mlHJndpAhMsCExfNGOYDVgPKiWaoTr.setProperty('SPOTV_M_SESSION',mlHJndpAhMsCExfNGOYDVgPKiWaoXj['spotv_session'])
  mlHJndpAhMsCExfNGOYDVgPKiWaoTr.setProperty('SPOTV_M_ACCOUNTID',mlHJndpAhMsCExfNGOYDVgPKiWaoXj['spotv_accountId'])
  mlHJndpAhMsCExfNGOYDVgPKiWaoTr.setProperty('SPOTV_M_POLICYKEY',mlHJndpAhMsCExfNGOYDVgPKiWaoXj['spotv_policyKey'])
  mlHJndpAhMsCExfNGOYDVgPKiWaoTr.setProperty('SPOTV_M_SUBEND',mlHJndpAhMsCExfNGOYDVgPKiWaoXj['spotv_subend'])
  mlHJndpAhMsCExfNGOYDVgPKiWaoTr.setProperty('SPOTV_M_LOGINTIME',mlHJndpAhMsCExfNGOYDVgPKiWaoXr)
  return mlHJndpAhMsCExfNGOYDVgPKiWaoQb
 def dp_WatchList_Delete(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ,args):
  mlHJndpAhMsCExfNGOYDVgPKiWaoXI=args.get('mediatype')
  mlHJndpAhMsCExfNGOYDVgPKiWaoTI=xbmcgui.Dialog()
  mlHJndpAhMsCExfNGOYDVgPKiWaoSt=mlHJndpAhMsCExfNGOYDVgPKiWaoTI.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if mlHJndpAhMsCExfNGOYDVgPKiWaoSt==mlHJndpAhMsCExfNGOYDVgPKiWaoQc:sys.exit()
  mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.Delete_Watched_List(mlHJndpAhMsCExfNGOYDVgPKiWaoXI)
  xbmc.executebuiltin("Container.Refresh")
 def Delete_Watched_List(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ,mlHJndpAhMsCExfNGOYDVgPKiWaoXI):
  try:
   mlHJndpAhMsCExfNGOYDVgPKiWaoXz=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%mlHJndpAhMsCExfNGOYDVgPKiWaoXI))
   fp=mlHJndpAhMsCExfNGOYDVgPKiWaoQz(mlHJndpAhMsCExfNGOYDVgPKiWaoXz,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   mlHJndpAhMsCExfNGOYDVgPKiWaoQv
 def Load_Watched_List(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ,mlHJndpAhMsCExfNGOYDVgPKiWaoXI):
  try:
   mlHJndpAhMsCExfNGOYDVgPKiWaoXz=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%mlHJndpAhMsCExfNGOYDVgPKiWaoXI))
   fp=mlHJndpAhMsCExfNGOYDVgPKiWaoQz(mlHJndpAhMsCExfNGOYDVgPKiWaoXz,'r',-1,'utf-8')
   mlHJndpAhMsCExfNGOYDVgPKiWaoXt=fp.readlines()
   fp.close()
  except:
   mlHJndpAhMsCExfNGOYDVgPKiWaoXt=[]
  return mlHJndpAhMsCExfNGOYDVgPKiWaoXt
 def Save_Watched_List(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ,stype,mlHJndpAhMsCExfNGOYDVgPKiWaoTq):
  try:
   mlHJndpAhMsCExfNGOYDVgPKiWaoXz=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   mlHJndpAhMsCExfNGOYDVgPKiWaoXu=mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.Load_Watched_List(stype) 
   fp=mlHJndpAhMsCExfNGOYDVgPKiWaoQz(mlHJndpAhMsCExfNGOYDVgPKiWaoXz,'w',-1,'utf-8')
   mlHJndpAhMsCExfNGOYDVgPKiWaoXF=urllib.parse.urlencode(mlHJndpAhMsCExfNGOYDVgPKiWaoTq)
   mlHJndpAhMsCExfNGOYDVgPKiWaoXF=mlHJndpAhMsCExfNGOYDVgPKiWaoXF+'\n'
   fp.write(mlHJndpAhMsCExfNGOYDVgPKiWaoXF)
   mlHJndpAhMsCExfNGOYDVgPKiWaoXU=0
   for mlHJndpAhMsCExfNGOYDVgPKiWaoXw in mlHJndpAhMsCExfNGOYDVgPKiWaoXu:
    mlHJndpAhMsCExfNGOYDVgPKiWaoQT=mlHJndpAhMsCExfNGOYDVgPKiWaoQF(urllib.parse.parse_qsl(mlHJndpAhMsCExfNGOYDVgPKiWaoXw))
    mlHJndpAhMsCExfNGOYDVgPKiWaoQk=mlHJndpAhMsCExfNGOYDVgPKiWaoTq.get('code')
    mlHJndpAhMsCExfNGOYDVgPKiWaoQS=mlHJndpAhMsCExfNGOYDVgPKiWaoQT.get('code')
    if mlHJndpAhMsCExfNGOYDVgPKiWaoQk!=mlHJndpAhMsCExfNGOYDVgPKiWaoQS:
     fp.write(mlHJndpAhMsCExfNGOYDVgPKiWaoXw)
     mlHJndpAhMsCExfNGOYDVgPKiWaoXU+=1
     if mlHJndpAhMsCExfNGOYDVgPKiWaoXU>=50:break
   fp.close()
  except:
   mlHJndpAhMsCExfNGOYDVgPKiWaoQv
 def dp_Watch_List(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ,args):
  mlHJndpAhMsCExfNGOYDVgPKiWaoXI ='vod'
  if mlHJndpAhMsCExfNGOYDVgPKiWaoXI=='vod':
   mlHJndpAhMsCExfNGOYDVgPKiWaoQX=mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.Load_Watched_List(mlHJndpAhMsCExfNGOYDVgPKiWaoXI)
   for mlHJndpAhMsCExfNGOYDVgPKiWaoQe in mlHJndpAhMsCExfNGOYDVgPKiWaoQX:
    mlHJndpAhMsCExfNGOYDVgPKiWaoQy=mlHJndpAhMsCExfNGOYDVgPKiWaoQF(urllib.parse.parse_qsl(mlHJndpAhMsCExfNGOYDVgPKiWaoQe))
    mlHJndpAhMsCExfNGOYDVgPKiWaoTu =mlHJndpAhMsCExfNGOYDVgPKiWaoQy.get('title')
    mlHJndpAhMsCExfNGOYDVgPKiWaokL=mlHJndpAhMsCExfNGOYDVgPKiWaoQy.get('img')
    mlHJndpAhMsCExfNGOYDVgPKiWaoXB=mlHJndpAhMsCExfNGOYDVgPKiWaoQy.get('code')
    mlHJndpAhMsCExfNGOYDVgPKiWaoQq =mlHJndpAhMsCExfNGOYDVgPKiWaoQy.get('info')
    mlHJndpAhMsCExfNGOYDVgPKiWaokb={}
    mlHJndpAhMsCExfNGOYDVgPKiWaokb['plot']=mlHJndpAhMsCExfNGOYDVgPKiWaoQq
    mlHJndpAhMsCExfNGOYDVgPKiWaokQ={'mode':'GAME_VOD_GROUP','gameid':mlHJndpAhMsCExfNGOYDVgPKiWaoXB,'saveTitle':mlHJndpAhMsCExfNGOYDVgPKiWaoTu,'saveImg':mlHJndpAhMsCExfNGOYDVgPKiWaokL,'saveInfo':mlHJndpAhMsCExfNGOYDVgPKiWaoQq,'mediatype':mlHJndpAhMsCExfNGOYDVgPKiWaoXI}
    mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.add_dir(mlHJndpAhMsCExfNGOYDVgPKiWaoTu,sublabel='',img=mlHJndpAhMsCExfNGOYDVgPKiWaokL,infoLabels=mlHJndpAhMsCExfNGOYDVgPKiWaokb,isFolder=mlHJndpAhMsCExfNGOYDVgPKiWaoQb,params=mlHJndpAhMsCExfNGOYDVgPKiWaokQ)
   mlHJndpAhMsCExfNGOYDVgPKiWaokb={'plot':'시청목록을 삭제합니다.'}
   mlHJndpAhMsCExfNGOYDVgPKiWaoTu='*** 시청목록 삭제 ***'
   mlHJndpAhMsCExfNGOYDVgPKiWaokQ={'mode':'MYVIEW_REMOVE','mediatype':mlHJndpAhMsCExfNGOYDVgPKiWaoXI}
   mlHJndpAhMsCExfNGOYDVgPKiWaokX=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.add_dir(mlHJndpAhMsCExfNGOYDVgPKiWaoTu,sublabel='',img=mlHJndpAhMsCExfNGOYDVgPKiWaokX,infoLabels=mlHJndpAhMsCExfNGOYDVgPKiWaokb,isFolder=mlHJndpAhMsCExfNGOYDVgPKiWaoQc,params=mlHJndpAhMsCExfNGOYDVgPKiWaokQ,isLink=mlHJndpAhMsCExfNGOYDVgPKiWaoQb)
   xbmcplugin.endOfDirectory(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ._addon_handle,cacheToDisc=mlHJndpAhMsCExfNGOYDVgPKiWaoQc)
 def spotv_main(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ):
  mlHJndpAhMsCExfNGOYDVgPKiWaoQI=mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.main_params.get('mode',mlHJndpAhMsCExfNGOYDVgPKiWaoQv)
  if mlHJndpAhMsCExfNGOYDVgPKiWaoQI=='LOGOUT':
   mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.logout()
   return
  mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.login_main()
  if mlHJndpAhMsCExfNGOYDVgPKiWaoQI is mlHJndpAhMsCExfNGOYDVgPKiWaoQv:
   mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.dp_Main_List()
  elif mlHJndpAhMsCExfNGOYDVgPKiWaoQI=='LIVE_GROUP':
   mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.dp_LiveChannel_List(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.main_params)
  elif mlHJndpAhMsCExfNGOYDVgPKiWaoQI=='ELIVE_GROUP':
   mlHJndpAhMsCExfNGOYDVgPKiWaoXy=mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.dp_EventLiveChannel_List(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.main_params)
   if mlHJndpAhMsCExfNGOYDVgPKiWaoXy==401:
    if os.path.isfile(mlHJndpAhMsCExfNGOYDVgPKiWaoTX):os.remove(mlHJndpAhMsCExfNGOYDVgPKiWaoTX)
    mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.login_main()
    mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.dp_EventLiveChannel_List(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.main_params)
  elif mlHJndpAhMsCExfNGOYDVgPKiWaoQI in['LIVE','GAME_VOD','POP_VOD','NOW_VOD','ELIVE']:
   mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.play_VIDEO(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.main_params)
  elif mlHJndpAhMsCExfNGOYDVgPKiWaoQI=='VOD_GROUP':
   mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.dp_MainLeague_List(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.main_params)
  elif mlHJndpAhMsCExfNGOYDVgPKiWaoQI=='NOW_GROUP':
   mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.dp_NowVod_GroupList(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.main_params)
  elif mlHJndpAhMsCExfNGOYDVgPKiWaoQI=='POP_GROUP':
   mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.dp_PopVod_GroupList(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.main_params)
  elif mlHJndpAhMsCExfNGOYDVgPKiWaoQI=='LEAGUE_GROUP':
   mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.dp_Season_List(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.main_params)
  elif mlHJndpAhMsCExfNGOYDVgPKiWaoQI=='SEASON_GROUP':
   mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.dp_Game_List(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.main_params)
  elif mlHJndpAhMsCExfNGOYDVgPKiWaoQI=='GAME_VOD_GROUP':
   mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.dp_GameVod_List(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.main_params)
  elif mlHJndpAhMsCExfNGOYDVgPKiWaoQI=='WATCH':
   mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.dp_Watch_List(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.main_params)
  elif mlHJndpAhMsCExfNGOYDVgPKiWaoQI=='MYVIEW_REMOVE':
   mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.dp_WatchList_Delete(mlHJndpAhMsCExfNGOYDVgPKiWaoTQ.main_params)
  else:
   mlHJndpAhMsCExfNGOYDVgPKiWaoQv
# Created by pyminifier (https://github.com/liftoff/pyminifier)
