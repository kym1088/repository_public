__author__="NightRain"
gpwQNWHGCIPSATVufDkxXYmvzyBbca=object
gpwQNWHGCIPSATVufDkxXYmvzyBbch=None
gpwQNWHGCIPSATVufDkxXYmvzyBbcq=True
gpwQNWHGCIPSATVufDkxXYmvzyBbcs=int
gpwQNWHGCIPSATVufDkxXYmvzyBbcd=False
gpwQNWHGCIPSATVufDkxXYmvzyBbci=len
gpwQNWHGCIPSATVufDkxXYmvzyBbcl=str
gpwQNWHGCIPSATVufDkxXYmvzyBbcJ=open
gpwQNWHGCIPSATVufDkxXYmvzyBbcL=Exception
gpwQNWHGCIPSATVufDkxXYmvzyBbcE=print
gpwQNWHGCIPSATVufDkxXYmvzyBbct=dict
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmc.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
gpwQNWHGCIPSATVufDkxXYmvzyBbKR=[{'title':'TV 채널','mode':'LIVE_GROUP'},{'title':'Live중계 (독점,현지)','mode':'ELIVE_GROUP'},{'title':'-----------------','mode':'XXX'},{'title':'인기영상5','mode':'POP_GROUP'},{'title':'VOD 영상','mode':'VOD_GROUP'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH'}]
gpwQNWHGCIPSATVufDkxXYmvzyBbKa ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36'
gpwQNWHGCIPSATVufDkxXYmvzyBbKc=xbmc.translatePath(os.path.join(__profile__,'spotv_cookies.json'))
from spotvCore import*
class gpwQNWHGCIPSATVufDkxXYmvzyBbKF(gpwQNWHGCIPSATVufDkxXYmvzyBbca):
 def __init__(gpwQNWHGCIPSATVufDkxXYmvzyBbKh,gpwQNWHGCIPSATVufDkxXYmvzyBbKq,gpwQNWHGCIPSATVufDkxXYmvzyBbKs,gpwQNWHGCIPSATVufDkxXYmvzyBbKd):
  gpwQNWHGCIPSATVufDkxXYmvzyBbKh._addon_url =gpwQNWHGCIPSATVufDkxXYmvzyBbKq
  gpwQNWHGCIPSATVufDkxXYmvzyBbKh._addon_handle=gpwQNWHGCIPSATVufDkxXYmvzyBbKs
  gpwQNWHGCIPSATVufDkxXYmvzyBbKh.main_params =gpwQNWHGCIPSATVufDkxXYmvzyBbKd
  gpwQNWHGCIPSATVufDkxXYmvzyBbKh.SpotvObj =uWUzXdGwEvPKftOSbNITHkjCVFqJex() 
 def addon_noti(gpwQNWHGCIPSATVufDkxXYmvzyBbKh,sting):
  try:
   gpwQNWHGCIPSATVufDkxXYmvzyBbKl=xbmcgui.Dialog()
   gpwQNWHGCIPSATVufDkxXYmvzyBbKl.notification(__addonname__,sting)
  except:
   gpwQNWHGCIPSATVufDkxXYmvzyBbch
 def addon_log(gpwQNWHGCIPSATVufDkxXYmvzyBbKh,string):
  try:
   gpwQNWHGCIPSATVufDkxXYmvzyBbKJ=string.encode('utf-8','ignore')
  except:
   gpwQNWHGCIPSATVufDkxXYmvzyBbKJ='addonException: addon_log'
  gpwQNWHGCIPSATVufDkxXYmvzyBbKL=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,gpwQNWHGCIPSATVufDkxXYmvzyBbKJ),level=gpwQNWHGCIPSATVufDkxXYmvzyBbKL)
 def get_keyboard_input(gpwQNWHGCIPSATVufDkxXYmvzyBbKh,gpwQNWHGCIPSATVufDkxXYmvzyBbKM):
  gpwQNWHGCIPSATVufDkxXYmvzyBbKE=gpwQNWHGCIPSATVufDkxXYmvzyBbch
  kb=xbmc.Keyboard()
  kb.setHeading(gpwQNWHGCIPSATVufDkxXYmvzyBbKM)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   gpwQNWHGCIPSATVufDkxXYmvzyBbKE=kb.getText()
  return gpwQNWHGCIPSATVufDkxXYmvzyBbKE
 def get_settings_login_info(gpwQNWHGCIPSATVufDkxXYmvzyBbKh):
  gpwQNWHGCIPSATVufDkxXYmvzyBbKt =__addon__.getSetting('id')
  gpwQNWHGCIPSATVufDkxXYmvzyBbKU =__addon__.getSetting('pw')
  return(gpwQNWHGCIPSATVufDkxXYmvzyBbKt,gpwQNWHGCIPSATVufDkxXYmvzyBbKU)
 def set_winCredential(gpwQNWHGCIPSATVufDkxXYmvzyBbKh,credential):
  gpwQNWHGCIPSATVufDkxXYmvzyBbKr=xbmcgui.Window(10000)
  gpwQNWHGCIPSATVufDkxXYmvzyBbKr.setProperty('SPOTV_M_SESSIONID',credential.get('spotv_sessionid'))
  gpwQNWHGCIPSATVufDkxXYmvzyBbKr.setProperty('SPOTV_M_SESSION',credential.get('spotv_session'))
  gpwQNWHGCIPSATVufDkxXYmvzyBbKr.setProperty('SPOTV_M_ACCOUNTID',credential.get('spotv_accountId'))
  gpwQNWHGCIPSATVufDkxXYmvzyBbKr.setProperty('SPOTV_M_POLICYKEY',credential.get('spotv_policyKey'))
  gpwQNWHGCIPSATVufDkxXYmvzyBbKr.setProperty('SPOTV_M_SUBEND',credential.get('spotv_subend'))
  gpwQNWHGCIPSATVufDkxXYmvzyBbKr.setProperty('SPOTV_M_LOGINTIME',gpwQNWHGCIPSATVufDkxXYmvzyBbKh.SpotvObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(gpwQNWHGCIPSATVufDkxXYmvzyBbKh):
  gpwQNWHGCIPSATVufDkxXYmvzyBbKr=xbmcgui.Window(10000)
  gpwQNWHGCIPSATVufDkxXYmvzyBbKj={'spotv_sessionid':gpwQNWHGCIPSATVufDkxXYmvzyBbKr.getProperty('SPOTV_M_SESSIONID'),'spotv_session':gpwQNWHGCIPSATVufDkxXYmvzyBbKr.getProperty('SPOTV_M_SESSION'),'spotv_accountId':gpwQNWHGCIPSATVufDkxXYmvzyBbKr.getProperty('SPOTV_M_ACCOUNTID'),'spotv_policyKey':gpwQNWHGCIPSATVufDkxXYmvzyBbKr.getProperty('SPOTV_M_POLICYKEY'),'spotv_subend':gpwQNWHGCIPSATVufDkxXYmvzyBbKr.getProperty('SPOTV_M_SUBEND')}
  return gpwQNWHGCIPSATVufDkxXYmvzyBbKj
 def add_dir(gpwQNWHGCIPSATVufDkxXYmvzyBbKh,label,sublabel='',img='',infoLabels=gpwQNWHGCIPSATVufDkxXYmvzyBbch,isFolder=gpwQNWHGCIPSATVufDkxXYmvzyBbcq,params=''):
  gpwQNWHGCIPSATVufDkxXYmvzyBbKO='%s?%s'%(gpwQNWHGCIPSATVufDkxXYmvzyBbKh._addon_url,urllib.parse.urlencode(params))
  if sublabel:gpwQNWHGCIPSATVufDkxXYmvzyBbKM='%s < %s >'%(label,sublabel)
  else: gpwQNWHGCIPSATVufDkxXYmvzyBbKM=label
  if not img:img='DefaultFolder.png'
  gpwQNWHGCIPSATVufDkxXYmvzyBbKe=xbmcgui.ListItem(gpwQNWHGCIPSATVufDkxXYmvzyBbKM)
  gpwQNWHGCIPSATVufDkxXYmvzyBbKe.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:gpwQNWHGCIPSATVufDkxXYmvzyBbKe.setInfo(type="Video",infoLabels=infoLabels)
  if not isFolder:gpwQNWHGCIPSATVufDkxXYmvzyBbKe.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(gpwQNWHGCIPSATVufDkxXYmvzyBbKh._addon_handle,gpwQNWHGCIPSATVufDkxXYmvzyBbKO,gpwQNWHGCIPSATVufDkxXYmvzyBbKe,isFolder)
 def get_selQuality(gpwQNWHGCIPSATVufDkxXYmvzyBbKh,etype):
  try:
   gpwQNWHGCIPSATVufDkxXYmvzyBbKo='selected_quality'
   gpwQNWHGCIPSATVufDkxXYmvzyBbKn=[1080,720,540]
   gpwQNWHGCIPSATVufDkxXYmvzyBbFK=gpwQNWHGCIPSATVufDkxXYmvzyBbcs(__addon__.getSetting(gpwQNWHGCIPSATVufDkxXYmvzyBbKo))
   return gpwQNWHGCIPSATVufDkxXYmvzyBbKn[gpwQNWHGCIPSATVufDkxXYmvzyBbFK]
  except:
   gpwQNWHGCIPSATVufDkxXYmvzyBbch
  return 1080 
 def dp_Main_List(gpwQNWHGCIPSATVufDkxXYmvzyBbKh):
  for gpwQNWHGCIPSATVufDkxXYmvzyBbFR in gpwQNWHGCIPSATVufDkxXYmvzyBbKR:
   gpwQNWHGCIPSATVufDkxXYmvzyBbKM=gpwQNWHGCIPSATVufDkxXYmvzyBbFR.get('title')
   gpwQNWHGCIPSATVufDkxXYmvzyBbFa={'mode':gpwQNWHGCIPSATVufDkxXYmvzyBbFR.get('mode')}
   if gpwQNWHGCIPSATVufDkxXYmvzyBbFR.get('mode')=='XXX':
    gpwQNWHGCIPSATVufDkxXYmvzyBbFc=gpwQNWHGCIPSATVufDkxXYmvzyBbcd
   else:
    gpwQNWHGCIPSATVufDkxXYmvzyBbFc=gpwQNWHGCIPSATVufDkxXYmvzyBbcq
   gpwQNWHGCIPSATVufDkxXYmvzyBbKh.add_dir(gpwQNWHGCIPSATVufDkxXYmvzyBbKM,sublabel='',img='',infoLabels=gpwQNWHGCIPSATVufDkxXYmvzyBbch,isFolder=gpwQNWHGCIPSATVufDkxXYmvzyBbFc,params=gpwQNWHGCIPSATVufDkxXYmvzyBbFa)
  if gpwQNWHGCIPSATVufDkxXYmvzyBbci(gpwQNWHGCIPSATVufDkxXYmvzyBbKR)>0:xbmcplugin.endOfDirectory(gpwQNWHGCIPSATVufDkxXYmvzyBbKh._addon_handle)
 def dp_MainLeague_List(gpwQNWHGCIPSATVufDkxXYmvzyBbKh,args):
  gpwQNWHGCIPSATVufDkxXYmvzyBbKh.SpotvObj.SaveCredential(gpwQNWHGCIPSATVufDkxXYmvzyBbKh.get_winCredential())
  gpwQNWHGCIPSATVufDkxXYmvzyBbFq=gpwQNWHGCIPSATVufDkxXYmvzyBbKh.SpotvObj.GetTitleGroupList()
  for gpwQNWHGCIPSATVufDkxXYmvzyBbFs in gpwQNWHGCIPSATVufDkxXYmvzyBbFq:
   gpwQNWHGCIPSATVufDkxXYmvzyBbKM =gpwQNWHGCIPSATVufDkxXYmvzyBbFs.get('title')
   gpwQNWHGCIPSATVufDkxXYmvzyBbFd =gpwQNWHGCIPSATVufDkxXYmvzyBbFs.get('logo')
   gpwQNWHGCIPSATVufDkxXYmvzyBbFi =gpwQNWHGCIPSATVufDkxXYmvzyBbFs.get('reagueId')
   gpwQNWHGCIPSATVufDkxXYmvzyBbFl =gpwQNWHGCIPSATVufDkxXYmvzyBbFs.get('subGame')
   gpwQNWHGCIPSATVufDkxXYmvzyBbFJ=gpwQNWHGCIPSATVufDkxXYmvzyBbFs.get('info')
   gpwQNWHGCIPSATVufDkxXYmvzyBbFJ['plot']='%s\n\n%s'%(gpwQNWHGCIPSATVufDkxXYmvzyBbKM,gpwQNWHGCIPSATVufDkxXYmvzyBbFl)
   gpwQNWHGCIPSATVufDkxXYmvzyBbFa={'mode':'LEAGUE_GROUP','reagueId':gpwQNWHGCIPSATVufDkxXYmvzyBbFi}
   gpwQNWHGCIPSATVufDkxXYmvzyBbKh.add_dir(gpwQNWHGCIPSATVufDkxXYmvzyBbKM,sublabel=gpwQNWHGCIPSATVufDkxXYmvzyBbch,img=gpwQNWHGCIPSATVufDkxXYmvzyBbFd,infoLabels=gpwQNWHGCIPSATVufDkxXYmvzyBbFJ,isFolder=gpwQNWHGCIPSATVufDkxXYmvzyBbcq,params=gpwQNWHGCIPSATVufDkxXYmvzyBbFa)
  if gpwQNWHGCIPSATVufDkxXYmvzyBbci(gpwQNWHGCIPSATVufDkxXYmvzyBbFq)>0:xbmcplugin.endOfDirectory(gpwQNWHGCIPSATVufDkxXYmvzyBbKh._addon_handle,cacheToDisc=gpwQNWHGCIPSATVufDkxXYmvzyBbcd)
 def dp_PopVod_GroupList(gpwQNWHGCIPSATVufDkxXYmvzyBbKh,args):
  gpwQNWHGCIPSATVufDkxXYmvzyBbKh.SpotvObj.SaveCredential(gpwQNWHGCIPSATVufDkxXYmvzyBbKh.get_winCredential())
  gpwQNWHGCIPSATVufDkxXYmvzyBbFq=gpwQNWHGCIPSATVufDkxXYmvzyBbKh.SpotvObj.GetPopularGroupList()
  for gpwQNWHGCIPSATVufDkxXYmvzyBbFs in gpwQNWHGCIPSATVufDkxXYmvzyBbFq:
   gpwQNWHGCIPSATVufDkxXYmvzyBbFL =gpwQNWHGCIPSATVufDkxXYmvzyBbFs.get('vodTitle')
   gpwQNWHGCIPSATVufDkxXYmvzyBbFE =gpwQNWHGCIPSATVufDkxXYmvzyBbFs.get('vodId')
   gpwQNWHGCIPSATVufDkxXYmvzyBbFt =gpwQNWHGCIPSATVufDkxXYmvzyBbFs.get('vodType')
   gpwQNWHGCIPSATVufDkxXYmvzyBbFd=gpwQNWHGCIPSATVufDkxXYmvzyBbFs.get('thumbnail')
   gpwQNWHGCIPSATVufDkxXYmvzyBbFU =gpwQNWHGCIPSATVufDkxXYmvzyBbFs.get('vtypeId')
   gpwQNWHGCIPSATVufDkxXYmvzyBbFJ=gpwQNWHGCIPSATVufDkxXYmvzyBbFs.get('info')
   gpwQNWHGCIPSATVufDkxXYmvzyBbFJ['plot']=gpwQNWHGCIPSATVufDkxXYmvzyBbFL
   gpwQNWHGCIPSATVufDkxXYmvzyBbFa={'mode':'POP_VOD','mediacode':gpwQNWHGCIPSATVufDkxXYmvzyBbFE,'mediatype':'vod','vtypeId':gpwQNWHGCIPSATVufDkxXYmvzyBbFU}
   gpwQNWHGCIPSATVufDkxXYmvzyBbKh.add_dir(gpwQNWHGCIPSATVufDkxXYmvzyBbFL,sublabel=gpwQNWHGCIPSATVufDkxXYmvzyBbFt,img=gpwQNWHGCIPSATVufDkxXYmvzyBbFd,infoLabels=gpwQNWHGCIPSATVufDkxXYmvzyBbFJ,isFolder=gpwQNWHGCIPSATVufDkxXYmvzyBbcd,params=gpwQNWHGCIPSATVufDkxXYmvzyBbFa)
  if gpwQNWHGCIPSATVufDkxXYmvzyBbci(gpwQNWHGCIPSATVufDkxXYmvzyBbFq)>0:xbmcplugin.endOfDirectory(gpwQNWHGCIPSATVufDkxXYmvzyBbKh._addon_handle,cacheToDisc=gpwQNWHGCIPSATVufDkxXYmvzyBbcd)
 def dp_Season_List(gpwQNWHGCIPSATVufDkxXYmvzyBbKh,args):
  gpwQNWHGCIPSATVufDkxXYmvzyBbKh.SpotvObj.SaveCredential(gpwQNWHGCIPSATVufDkxXYmvzyBbKh.get_winCredential())
  gpwQNWHGCIPSATVufDkxXYmvzyBbFi=args.get('reagueId')
  gpwQNWHGCIPSATVufDkxXYmvzyBbFq=gpwQNWHGCIPSATVufDkxXYmvzyBbKh.SpotvObj.GetSeasonList(gpwQNWHGCIPSATVufDkxXYmvzyBbFi)
  for gpwQNWHGCIPSATVufDkxXYmvzyBbFs in gpwQNWHGCIPSATVufDkxXYmvzyBbFq:
   gpwQNWHGCIPSATVufDkxXYmvzyBbFr =gpwQNWHGCIPSATVufDkxXYmvzyBbFs.get('reagueName')
   gpwQNWHGCIPSATVufDkxXYmvzyBbFj =gpwQNWHGCIPSATVufDkxXYmvzyBbFs.get('gameTypeId')
   gpwQNWHGCIPSATVufDkxXYmvzyBbFO =gpwQNWHGCIPSATVufDkxXYmvzyBbFs.get('seasonName')
   gpwQNWHGCIPSATVufDkxXYmvzyBbFM =gpwQNWHGCIPSATVufDkxXYmvzyBbFs.get('seasonId')
   gpwQNWHGCIPSATVufDkxXYmvzyBbFJ=gpwQNWHGCIPSATVufDkxXYmvzyBbFs.get('info')
   gpwQNWHGCIPSATVufDkxXYmvzyBbFJ['plot']='%s - %s'%(gpwQNWHGCIPSATVufDkxXYmvzyBbFr,gpwQNWHGCIPSATVufDkxXYmvzyBbFO)
   gpwQNWHGCIPSATVufDkxXYmvzyBbFa={'mode':'SEASON_GROUP','reagueId':gpwQNWHGCIPSATVufDkxXYmvzyBbFi,'seasonId':gpwQNWHGCIPSATVufDkxXYmvzyBbFM,'gameTypeId':gpwQNWHGCIPSATVufDkxXYmvzyBbFj,'page':'1'}
   gpwQNWHGCIPSATVufDkxXYmvzyBbKh.add_dir(gpwQNWHGCIPSATVufDkxXYmvzyBbFr,sublabel=gpwQNWHGCIPSATVufDkxXYmvzyBbFO,img='',infoLabels=gpwQNWHGCIPSATVufDkxXYmvzyBbFJ,isFolder=gpwQNWHGCIPSATVufDkxXYmvzyBbcq,params=gpwQNWHGCIPSATVufDkxXYmvzyBbFa)
  if gpwQNWHGCIPSATVufDkxXYmvzyBbci(gpwQNWHGCIPSATVufDkxXYmvzyBbFq)>0:xbmcplugin.endOfDirectory(gpwQNWHGCIPSATVufDkxXYmvzyBbKh._addon_handle,cacheToDisc=gpwQNWHGCIPSATVufDkxXYmvzyBbcq)
 def dp_Game_List(gpwQNWHGCIPSATVufDkxXYmvzyBbKh,args):
  gpwQNWHGCIPSATVufDkxXYmvzyBbKh.SpotvObj.SaveCredential(gpwQNWHGCIPSATVufDkxXYmvzyBbKh.get_winCredential())
  gpwQNWHGCIPSATVufDkxXYmvzyBbFj=args.get('gameTypeId')
  gpwQNWHGCIPSATVufDkxXYmvzyBbFi =args.get('reagueId')
  gpwQNWHGCIPSATVufDkxXYmvzyBbFM =args.get('seasonId')
  gpwQNWHGCIPSATVufDkxXYmvzyBbFe =gpwQNWHGCIPSATVufDkxXYmvzyBbcs(args.get('page'))
  gpwQNWHGCIPSATVufDkxXYmvzyBbFq,gpwQNWHGCIPSATVufDkxXYmvzyBbFo=gpwQNWHGCIPSATVufDkxXYmvzyBbKh.SpotvObj.GetGameList(gpwQNWHGCIPSATVufDkxXYmvzyBbFj,gpwQNWHGCIPSATVufDkxXYmvzyBbFi,gpwQNWHGCIPSATVufDkxXYmvzyBbFM,gpwQNWHGCIPSATVufDkxXYmvzyBbFe)
  for gpwQNWHGCIPSATVufDkxXYmvzyBbFs in gpwQNWHGCIPSATVufDkxXYmvzyBbFq:
   gpwQNWHGCIPSATVufDkxXYmvzyBbFn =gpwQNWHGCIPSATVufDkxXYmvzyBbFs.get('gameTitle')
   gpwQNWHGCIPSATVufDkxXYmvzyBbRK =gpwQNWHGCIPSATVufDkxXYmvzyBbFs.get('beginDate')
   gpwQNWHGCIPSATVufDkxXYmvzyBbFd =gpwQNWHGCIPSATVufDkxXYmvzyBbFs.get('thumbnail')
   gpwQNWHGCIPSATVufDkxXYmvzyBbRF =gpwQNWHGCIPSATVufDkxXYmvzyBbFs.get('gameId')
   gpwQNWHGCIPSATVufDkxXYmvzyBbRa =gpwQNWHGCIPSATVufDkxXYmvzyBbFs.get('totVodCnt')
   gpwQNWHGCIPSATVufDkxXYmvzyBbRc =gpwQNWHGCIPSATVufDkxXYmvzyBbFs.get('leaguenm')
   gpwQNWHGCIPSATVufDkxXYmvzyBbRh =gpwQNWHGCIPSATVufDkxXYmvzyBbFs.get('seasonnm')
   gpwQNWHGCIPSATVufDkxXYmvzyBbRq =gpwQNWHGCIPSATVufDkxXYmvzyBbFs.get('roundnm')
   gpwQNWHGCIPSATVufDkxXYmvzyBbRs ='%s < %s >'%(gpwQNWHGCIPSATVufDkxXYmvzyBbFn,gpwQNWHGCIPSATVufDkxXYmvzyBbRK)
   gpwQNWHGCIPSATVufDkxXYmvzyBbFJ=gpwQNWHGCIPSATVufDkxXYmvzyBbFs.get('info')
   gpwQNWHGCIPSATVufDkxXYmvzyBbFa={'mode':'GAME_VOD_GROUP' if gpwQNWHGCIPSATVufDkxXYmvzyBbRa!=0 else 'XXX','saveTitle':gpwQNWHGCIPSATVufDkxXYmvzyBbRs,'saveImg':gpwQNWHGCIPSATVufDkxXYmvzyBbFd,'saveInfo':gpwQNWHGCIPSATVufDkxXYmvzyBbFJ['plot'],'gameid':gpwQNWHGCIPSATVufDkxXYmvzyBbRF}
   gpwQNWHGCIPSATVufDkxXYmvzyBbKh.add_dir(gpwQNWHGCIPSATVufDkxXYmvzyBbFn,sublabel=gpwQNWHGCIPSATVufDkxXYmvzyBbRK,img=gpwQNWHGCIPSATVufDkxXYmvzyBbFd,infoLabels=gpwQNWHGCIPSATVufDkxXYmvzyBbFJ,isFolder=gpwQNWHGCIPSATVufDkxXYmvzyBbcq,params=gpwQNWHGCIPSATVufDkxXYmvzyBbFa)
  if gpwQNWHGCIPSATVufDkxXYmvzyBbFo:
   gpwQNWHGCIPSATVufDkxXYmvzyBbFa['mode'] ='SEASON_GROUP' 
   gpwQNWHGCIPSATVufDkxXYmvzyBbFa['reagueId'] =gpwQNWHGCIPSATVufDkxXYmvzyBbFi
   gpwQNWHGCIPSATVufDkxXYmvzyBbFa['seasonId'] =gpwQNWHGCIPSATVufDkxXYmvzyBbFM
   gpwQNWHGCIPSATVufDkxXYmvzyBbFa['gameTypeId']=gpwQNWHGCIPSATVufDkxXYmvzyBbFj
   gpwQNWHGCIPSATVufDkxXYmvzyBbFa['page'] =gpwQNWHGCIPSATVufDkxXYmvzyBbcl(gpwQNWHGCIPSATVufDkxXYmvzyBbFe+1)
   gpwQNWHGCIPSATVufDkxXYmvzyBbKM='[B]%s >>[/B]'%'다음 페이지'
   gpwQNWHGCIPSATVufDkxXYmvzyBbRd=gpwQNWHGCIPSATVufDkxXYmvzyBbcl(gpwQNWHGCIPSATVufDkxXYmvzyBbFe+1)
   gpwQNWHGCIPSATVufDkxXYmvzyBbKh.add_dir(gpwQNWHGCIPSATVufDkxXYmvzyBbKM,sublabel=gpwQNWHGCIPSATVufDkxXYmvzyBbRd,img='',infoLabels=gpwQNWHGCIPSATVufDkxXYmvzyBbch,isFolder=gpwQNWHGCIPSATVufDkxXYmvzyBbcq,params=gpwQNWHGCIPSATVufDkxXYmvzyBbFa)
  if gpwQNWHGCIPSATVufDkxXYmvzyBbci(gpwQNWHGCIPSATVufDkxXYmvzyBbFq)>0:xbmcplugin.endOfDirectory(gpwQNWHGCIPSATVufDkxXYmvzyBbKh._addon_handle,cacheToDisc=gpwQNWHGCIPSATVufDkxXYmvzyBbcd)
 def dp_GameVod_List(gpwQNWHGCIPSATVufDkxXYmvzyBbKh,args):
  gpwQNWHGCIPSATVufDkxXYmvzyBbKh.SpotvObj.SaveCredential(gpwQNWHGCIPSATVufDkxXYmvzyBbKh.get_winCredential())
  gpwQNWHGCIPSATVufDkxXYmvzyBbRi =args.get('gameid')
  gpwQNWHGCIPSATVufDkxXYmvzyBbRs=args.get('saveTitle')
  gpwQNWHGCIPSATVufDkxXYmvzyBbRl =args.get('saveImg')
  gpwQNWHGCIPSATVufDkxXYmvzyBbRJ =args.get('saveInfo')
  gpwQNWHGCIPSATVufDkxXYmvzyBbFq=gpwQNWHGCIPSATVufDkxXYmvzyBbKh.SpotvObj.GetGameVodList(gpwQNWHGCIPSATVufDkxXYmvzyBbRi)
  for gpwQNWHGCIPSATVufDkxXYmvzyBbFs in gpwQNWHGCIPSATVufDkxXYmvzyBbFq:
   gpwQNWHGCIPSATVufDkxXYmvzyBbFL =gpwQNWHGCIPSATVufDkxXYmvzyBbFs.get('vodTitle')
   gpwQNWHGCIPSATVufDkxXYmvzyBbFE =gpwQNWHGCIPSATVufDkxXYmvzyBbFs.get('vodId')
   gpwQNWHGCIPSATVufDkxXYmvzyBbFt =gpwQNWHGCIPSATVufDkxXYmvzyBbFs.get('vodType')
   gpwQNWHGCIPSATVufDkxXYmvzyBbFd=gpwQNWHGCIPSATVufDkxXYmvzyBbFs.get('thumbnail')
   gpwQNWHGCIPSATVufDkxXYmvzyBbFU =gpwQNWHGCIPSATVufDkxXYmvzyBbFs.get('vtypeId')
   gpwQNWHGCIPSATVufDkxXYmvzyBbFJ=gpwQNWHGCIPSATVufDkxXYmvzyBbFs.get('info')
   gpwQNWHGCIPSATVufDkxXYmvzyBbFJ['plot']='%s \n\n %s'%(gpwQNWHGCIPSATVufDkxXYmvzyBbFL,gpwQNWHGCIPSATVufDkxXYmvzyBbRJ)
   gpwQNWHGCIPSATVufDkxXYmvzyBbFa={'mode':'GAME_VOD','saveTitle':gpwQNWHGCIPSATVufDkxXYmvzyBbRs,'saveImg':gpwQNWHGCIPSATVufDkxXYmvzyBbRl,'saveId':gpwQNWHGCIPSATVufDkxXYmvzyBbRi,'saveInfo':gpwQNWHGCIPSATVufDkxXYmvzyBbRJ,'mediacode':gpwQNWHGCIPSATVufDkxXYmvzyBbFE,'mediatype':'vod','vtypeId':gpwQNWHGCIPSATVufDkxXYmvzyBbFU}
   gpwQNWHGCIPSATVufDkxXYmvzyBbKh.add_dir(gpwQNWHGCIPSATVufDkxXYmvzyBbFL,sublabel=gpwQNWHGCIPSATVufDkxXYmvzyBbFt,img=gpwQNWHGCIPSATVufDkxXYmvzyBbFd,infoLabels=gpwQNWHGCIPSATVufDkxXYmvzyBbFJ,isFolder=gpwQNWHGCIPSATVufDkxXYmvzyBbcd,params=gpwQNWHGCIPSATVufDkxXYmvzyBbFa)
  if gpwQNWHGCIPSATVufDkxXYmvzyBbci(gpwQNWHGCIPSATVufDkxXYmvzyBbFq)>0:xbmcplugin.endOfDirectory(gpwQNWHGCIPSATVufDkxXYmvzyBbKh._addon_handle,cacheToDisc=gpwQNWHGCIPSATVufDkxXYmvzyBbcd)
 def login_main(gpwQNWHGCIPSATVufDkxXYmvzyBbKh):
  (gpwQNWHGCIPSATVufDkxXYmvzyBbRL,gpwQNWHGCIPSATVufDkxXYmvzyBbRE)=gpwQNWHGCIPSATVufDkxXYmvzyBbKh.get_settings_login_info()
  if not(gpwQNWHGCIPSATVufDkxXYmvzyBbRL and gpwQNWHGCIPSATVufDkxXYmvzyBbRE):
   gpwQNWHGCIPSATVufDkxXYmvzyBbKl=xbmcgui.Dialog()
   gpwQNWHGCIPSATVufDkxXYmvzyBbRt=gpwQNWHGCIPSATVufDkxXYmvzyBbKl.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if gpwQNWHGCIPSATVufDkxXYmvzyBbRt==gpwQNWHGCIPSATVufDkxXYmvzyBbcq:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if gpwQNWHGCIPSATVufDkxXYmvzyBbKh.cookiefile_check():return
  gpwQNWHGCIPSATVufDkxXYmvzyBbRU =gpwQNWHGCIPSATVufDkxXYmvzyBbcs(gpwQNWHGCIPSATVufDkxXYmvzyBbKh.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))
  gpwQNWHGCIPSATVufDkxXYmvzyBbRr=xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINTIME')
  if gpwQNWHGCIPSATVufDkxXYmvzyBbRr==gpwQNWHGCIPSATVufDkxXYmvzyBbch or gpwQNWHGCIPSATVufDkxXYmvzyBbRr=='':
   gpwQNWHGCIPSATVufDkxXYmvzyBbRr=gpwQNWHGCIPSATVufDkxXYmvzyBbcs('19000101')
  else:
   gpwQNWHGCIPSATVufDkxXYmvzyBbRr=gpwQNWHGCIPSATVufDkxXYmvzyBbcs(re.sub('-','',gpwQNWHGCIPSATVufDkxXYmvzyBbRr))
  if xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINWAIT')=='TRUE':
   gpwQNWHGCIPSATVufDkxXYmvzyBbRj=0
   while gpwQNWHGCIPSATVufDkxXYmvzyBbcq:
    gpwQNWHGCIPSATVufDkxXYmvzyBbRj+=1
    time.sleep(0.05)
    if gpwQNWHGCIPSATVufDkxXYmvzyBbRr>=gpwQNWHGCIPSATVufDkxXYmvzyBbRU:return
    if gpwQNWHGCIPSATVufDkxXYmvzyBbRj>600:return
  else:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','TRUE')
  if gpwQNWHGCIPSATVufDkxXYmvzyBbRr>=gpwQNWHGCIPSATVufDkxXYmvzyBbRU:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
   return
  if not gpwQNWHGCIPSATVufDkxXYmvzyBbKh.SpotvObj.GetCredential(gpwQNWHGCIPSATVufDkxXYmvzyBbRL,gpwQNWHGCIPSATVufDkxXYmvzyBbRE):
   gpwQNWHGCIPSATVufDkxXYmvzyBbKh.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
   sys.exit()
  gpwQNWHGCIPSATVufDkxXYmvzyBbKh.set_winCredential(gpwQNWHGCIPSATVufDkxXYmvzyBbKh.SpotvObj.LoadCredential())
  gpwQNWHGCIPSATVufDkxXYmvzyBbKh.cookiefile_save()
  xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
 def dp_LiveChannel_List(gpwQNWHGCIPSATVufDkxXYmvzyBbKh,args):
  gpwQNWHGCIPSATVufDkxXYmvzyBbKh.SpotvObj.SaveCredential(gpwQNWHGCIPSATVufDkxXYmvzyBbKh.get_winCredential())
  gpwQNWHGCIPSATVufDkxXYmvzyBbRO=gpwQNWHGCIPSATVufDkxXYmvzyBbKh.SpotvObj.GetLiveChannelList()
  for gpwQNWHGCIPSATVufDkxXYmvzyBbRM in gpwQNWHGCIPSATVufDkxXYmvzyBbRO:
   gpwQNWHGCIPSATVufDkxXYmvzyBbKM =gpwQNWHGCIPSATVufDkxXYmvzyBbRM.get('name')
   gpwQNWHGCIPSATVufDkxXYmvzyBbFh =gpwQNWHGCIPSATVufDkxXYmvzyBbRM.get('programName')
   gpwQNWHGCIPSATVufDkxXYmvzyBbFd =gpwQNWHGCIPSATVufDkxXYmvzyBbRM.get('logo')
   gpwQNWHGCIPSATVufDkxXYmvzyBbRe=gpwQNWHGCIPSATVufDkxXYmvzyBbRM.get('channelepg')
   gpwQNWHGCIPSATVufDkxXYmvzyBbRo =gpwQNWHGCIPSATVufDkxXYmvzyBbRM.get('free')
   gpwQNWHGCIPSATVufDkxXYmvzyBbFJ=gpwQNWHGCIPSATVufDkxXYmvzyBbRM.get('info')
   gpwQNWHGCIPSATVufDkxXYmvzyBbFJ['plot']='%s'%(gpwQNWHGCIPSATVufDkxXYmvzyBbRe)
   gpwQNWHGCIPSATVufDkxXYmvzyBbFa={'mode':'LIVE','mediaid':gpwQNWHGCIPSATVufDkxXYmvzyBbRM.get('id'),'mediacode':gpwQNWHGCIPSATVufDkxXYmvzyBbRM.get('videoId'),'free':gpwQNWHGCIPSATVufDkxXYmvzyBbRo,'mediatype':'live'}
   if gpwQNWHGCIPSATVufDkxXYmvzyBbRo:gpwQNWHGCIPSATVufDkxXYmvzyBbKM+=' [free]'
   gpwQNWHGCIPSATVufDkxXYmvzyBbKh.add_dir(gpwQNWHGCIPSATVufDkxXYmvzyBbKM,sublabel=gpwQNWHGCIPSATVufDkxXYmvzyBbFh,img=gpwQNWHGCIPSATVufDkxXYmvzyBbFd,infoLabels=gpwQNWHGCIPSATVufDkxXYmvzyBbFJ,isFolder=gpwQNWHGCIPSATVufDkxXYmvzyBbcd,params=gpwQNWHGCIPSATVufDkxXYmvzyBbFa)
  if gpwQNWHGCIPSATVufDkxXYmvzyBbci(gpwQNWHGCIPSATVufDkxXYmvzyBbRO)>0:xbmcplugin.endOfDirectory(gpwQNWHGCIPSATVufDkxXYmvzyBbKh._addon_handle,cacheToDisc=gpwQNWHGCIPSATVufDkxXYmvzyBbcd)
 def dp_EventLiveChannel_List(gpwQNWHGCIPSATVufDkxXYmvzyBbKh,args):
  gpwQNWHGCIPSATVufDkxXYmvzyBbKh.SpotvObj.SaveCredential(gpwQNWHGCIPSATVufDkxXYmvzyBbKh.get_winCredential())
  gpwQNWHGCIPSATVufDkxXYmvzyBbRO,gpwQNWHGCIPSATVufDkxXYmvzyBbRn=gpwQNWHGCIPSATVufDkxXYmvzyBbKh.SpotvObj.GetEventLiveList()
  if gpwQNWHGCIPSATVufDkxXYmvzyBbRn!=401 and gpwQNWHGCIPSATVufDkxXYmvzyBbci(gpwQNWHGCIPSATVufDkxXYmvzyBbRO)==0:
   gpwQNWHGCIPSATVufDkxXYmvzyBbKh.addon_noti(__language__(30907).encode('utf8'))
  for gpwQNWHGCIPSATVufDkxXYmvzyBbRM in gpwQNWHGCIPSATVufDkxXYmvzyBbRO:
   gpwQNWHGCIPSATVufDkxXYmvzyBbKM =gpwQNWHGCIPSATVufDkxXYmvzyBbRM.get('title')
   gpwQNWHGCIPSATVufDkxXYmvzyBbFh =gpwQNWHGCIPSATVufDkxXYmvzyBbRM.get('startTime')
   gpwQNWHGCIPSATVufDkxXYmvzyBbFd =gpwQNWHGCIPSATVufDkxXYmvzyBbRM.get('logo')
   gpwQNWHGCIPSATVufDkxXYmvzyBbRo =gpwQNWHGCIPSATVufDkxXYmvzyBbRM.get('free')
   gpwQNWHGCIPSATVufDkxXYmvzyBbFJ=gpwQNWHGCIPSATVufDkxXYmvzyBbRM.get('info')
   gpwQNWHGCIPSATVufDkxXYmvzyBbFJ['plot']='%s\n\n%s'%(gpwQNWHGCIPSATVufDkxXYmvzyBbKM,gpwQNWHGCIPSATVufDkxXYmvzyBbFh)
   gpwQNWHGCIPSATVufDkxXYmvzyBbFa={'mode':'ELIVE','mediaid':gpwQNWHGCIPSATVufDkxXYmvzyBbRM.get('liveId'),'mediacode':'','free':gpwQNWHGCIPSATVufDkxXYmvzyBbRo,'mediatype':'live'}
   if gpwQNWHGCIPSATVufDkxXYmvzyBbRo:gpwQNWHGCIPSATVufDkxXYmvzyBbKM+=' [free]'
   gpwQNWHGCIPSATVufDkxXYmvzyBbKh.add_dir(gpwQNWHGCIPSATVufDkxXYmvzyBbKM,sublabel=gpwQNWHGCIPSATVufDkxXYmvzyBbFh,img=gpwQNWHGCIPSATVufDkxXYmvzyBbFd,infoLabels=gpwQNWHGCIPSATVufDkxXYmvzyBbFJ,isFolder=gpwQNWHGCIPSATVufDkxXYmvzyBbcd,params=gpwQNWHGCIPSATVufDkxXYmvzyBbFa)
  if gpwQNWHGCIPSATVufDkxXYmvzyBbci(gpwQNWHGCIPSATVufDkxXYmvzyBbRO)>0:xbmcplugin.endOfDirectory(gpwQNWHGCIPSATVufDkxXYmvzyBbKh._addon_handle,cacheToDisc=gpwQNWHGCIPSATVufDkxXYmvzyBbcq)
  return gpwQNWHGCIPSATVufDkxXYmvzyBbRn
 def play_VIDEO(gpwQNWHGCIPSATVufDkxXYmvzyBbKh,args):
  gpwQNWHGCIPSATVufDkxXYmvzyBbKh.SpotvObj.SaveCredential(gpwQNWHGCIPSATVufDkxXYmvzyBbKh.get_winCredential())
  if args.get('free')=='False':
   if gpwQNWHGCIPSATVufDkxXYmvzyBbKh.SpotvObj.CheckSubEnd()==gpwQNWHGCIPSATVufDkxXYmvzyBbcd:
    gpwQNWHGCIPSATVufDkxXYmvzyBbKh.addon_noti(__language__(30908).encode('utf8'))
    return
  gpwQNWHGCIPSATVufDkxXYmvzyBbaK =args.get('mode')
  gpwQNWHGCIPSATVufDkxXYmvzyBbaF =args.get('mediacode')
  gpwQNWHGCIPSATVufDkxXYmvzyBbaR =args.get('mediatype')
  gpwQNWHGCIPSATVufDkxXYmvzyBbFU =args.get('vtypeId')
  if args.get('mode')=='ELIVE':
   gpwQNWHGCIPSATVufDkxXYmvzyBbaF=gpwQNWHGCIPSATVufDkxXYmvzyBbKh.SpotvObj.GetEventLive_videoId(args.get('mediaid'))
  if gpwQNWHGCIPSATVufDkxXYmvzyBbaF=='' or gpwQNWHGCIPSATVufDkxXYmvzyBbaF==gpwQNWHGCIPSATVufDkxXYmvzyBbch:
   gpwQNWHGCIPSATVufDkxXYmvzyBbKh.addon_noti(__language__(30907).encode('utf8'))
   return
  gpwQNWHGCIPSATVufDkxXYmvzyBbac=gpwQNWHGCIPSATVufDkxXYmvzyBbKh.SpotvObj.GetBroadURL(gpwQNWHGCIPSATVufDkxXYmvzyBbaF,gpwQNWHGCIPSATVufDkxXYmvzyBbaR,gpwQNWHGCIPSATVufDkxXYmvzyBbFU)
  if gpwQNWHGCIPSATVufDkxXYmvzyBbac=='':
   gpwQNWHGCIPSATVufDkxXYmvzyBbKh.addon_noti(__language__(30908).encode('utf8'))
   return
  gpwQNWHGCIPSATVufDkxXYmvzyBbah=gpwQNWHGCIPSATVufDkxXYmvzyBbac
  gpwQNWHGCIPSATVufDkxXYmvzyBbKh.addon_log(gpwQNWHGCIPSATVufDkxXYmvzyBbah)
  gpwQNWHGCIPSATVufDkxXYmvzyBbaq=xbmcgui.ListItem(path=gpwQNWHGCIPSATVufDkxXYmvzyBbah)
  xbmcplugin.setResolvedUrl(gpwQNWHGCIPSATVufDkxXYmvzyBbKh._addon_handle,gpwQNWHGCIPSATVufDkxXYmvzyBbcq,gpwQNWHGCIPSATVufDkxXYmvzyBbaq)
  try:
   if gpwQNWHGCIPSATVufDkxXYmvzyBbaR=='vod' and gpwQNWHGCIPSATVufDkxXYmvzyBbaK!='POP_VOD':
    gpwQNWHGCIPSATVufDkxXYmvzyBbFa={'code':args.get('saveId'),'img':args.get('saveImg'),'title':args.get('saveTitle'),'info':args.get('saveInfo')}
    gpwQNWHGCIPSATVufDkxXYmvzyBbKh.Save_Watched_List(gpwQNWHGCIPSATVufDkxXYmvzyBbaR,gpwQNWHGCIPSATVufDkxXYmvzyBbFa)
  except:
   gpwQNWHGCIPSATVufDkxXYmvzyBbch
 def logout(gpwQNWHGCIPSATVufDkxXYmvzyBbKh):
  gpwQNWHGCIPSATVufDkxXYmvzyBbKl=xbmcgui.Dialog()
  gpwQNWHGCIPSATVufDkxXYmvzyBbRt=gpwQNWHGCIPSATVufDkxXYmvzyBbKl.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if gpwQNWHGCIPSATVufDkxXYmvzyBbRt==gpwQNWHGCIPSATVufDkxXYmvzyBbcd:sys.exit()
  gpwQNWHGCIPSATVufDkxXYmvzyBbKh.wininfo_clear()
  if os.path.isfile(gpwQNWHGCIPSATVufDkxXYmvzyBbKc):os.remove(gpwQNWHGCIPSATVufDkxXYmvzyBbKc)
  gpwQNWHGCIPSATVufDkxXYmvzyBbKh.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(gpwQNWHGCIPSATVufDkxXYmvzyBbKh):
  gpwQNWHGCIPSATVufDkxXYmvzyBbKr=xbmcgui.Window(10000)
  gpwQNWHGCIPSATVufDkxXYmvzyBbKr.setProperty('SPOTV_M_SESSIONID','')
  gpwQNWHGCIPSATVufDkxXYmvzyBbKr.setProperty('SPOTV_M_SESSION','')
  gpwQNWHGCIPSATVufDkxXYmvzyBbKr.setProperty('SPOTV_M_ACCOUNTID','')
  gpwQNWHGCIPSATVufDkxXYmvzyBbKr.setProperty('SPOTV_M_POLICYKEY','')
  gpwQNWHGCIPSATVufDkxXYmvzyBbKr.setProperty('SPOTV_M_SUBEND','')
  gpwQNWHGCIPSATVufDkxXYmvzyBbKr.setProperty('SPOTV_M_LOGINTIME','')
 def cookiefile_save(gpwQNWHGCIPSATVufDkxXYmvzyBbKh):
  gpwQNWHGCIPSATVufDkxXYmvzyBbas =gpwQNWHGCIPSATVufDkxXYmvzyBbKh.SpotvObj.Get_Now_Datetime()
  gpwQNWHGCIPSATVufDkxXYmvzyBbad=gpwQNWHGCIPSATVufDkxXYmvzyBbas+datetime.timedelta(days=gpwQNWHGCIPSATVufDkxXYmvzyBbcs(__addon__.getSetting('cache_ttl')))
  gpwQNWHGCIPSATVufDkxXYmvzyBbKr=xbmcgui.Window(10000)
  gpwQNWHGCIPSATVufDkxXYmvzyBbai={'spotv_sessionid':gpwQNWHGCIPSATVufDkxXYmvzyBbKr.getProperty('SPOTV_M_SESSIONID'),'spotv_session':gpwQNWHGCIPSATVufDkxXYmvzyBbKr.getProperty('SPOTV_M_SESSION'),'spotv_accountId':gpwQNWHGCIPSATVufDkxXYmvzyBbKr.getProperty('SPOTV_M_ACCOUNTID'),'spotv_policyKey':base64.standard_b64encode(gpwQNWHGCIPSATVufDkxXYmvzyBbKr.getProperty('SPOTV_M_POLICYKEY').encode()).decode('utf-8'),'spotv_subend':base64.standard_b64encode((gpwQNWHGCIPSATVufDkxXYmvzyBbKh.SpotvObj.SPOTV_PMCODE+gpwQNWHGCIPSATVufDkxXYmvzyBbKr.getProperty('SPOTV_M_SUBEND')).encode()).decode('utf-8'),'spotv_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'spotv_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'spotv_limitdate':gpwQNWHGCIPSATVufDkxXYmvzyBbad.strftime('%Y-%m-%d')}
  try: 
   fp=gpwQNWHGCIPSATVufDkxXYmvzyBbcJ(gpwQNWHGCIPSATVufDkxXYmvzyBbKc,'w',-1,'utf-8')
   json.dump(gpwQNWHGCIPSATVufDkxXYmvzyBbai,fp)
   fp.close()
  except gpwQNWHGCIPSATVufDkxXYmvzyBbcL as exception:
   gpwQNWHGCIPSATVufDkxXYmvzyBbcE(exception)
 def cookiefile_check(gpwQNWHGCIPSATVufDkxXYmvzyBbKh):
  gpwQNWHGCIPSATVufDkxXYmvzyBbai={}
  try: 
   fp=gpwQNWHGCIPSATVufDkxXYmvzyBbcJ(gpwQNWHGCIPSATVufDkxXYmvzyBbKc,'r',-1,'utf-8')
   gpwQNWHGCIPSATVufDkxXYmvzyBbai= json.load(fp)
   fp.close()
  except gpwQNWHGCIPSATVufDkxXYmvzyBbcL as exception:
   gpwQNWHGCIPSATVufDkxXYmvzyBbKh.wininfo_clear()
   return gpwQNWHGCIPSATVufDkxXYmvzyBbcd
  gpwQNWHGCIPSATVufDkxXYmvzyBbRL =__addon__.getSetting('id')
  gpwQNWHGCIPSATVufDkxXYmvzyBbRE =__addon__.getSetting('pw')
  gpwQNWHGCIPSATVufDkxXYmvzyBbai['spotv_id'] =base64.standard_b64decode(gpwQNWHGCIPSATVufDkxXYmvzyBbai['spotv_id']).decode('utf-8')
  gpwQNWHGCIPSATVufDkxXYmvzyBbai['spotv_pw'] =base64.standard_b64decode(gpwQNWHGCIPSATVufDkxXYmvzyBbai['spotv_pw']).decode('utf-8')
  gpwQNWHGCIPSATVufDkxXYmvzyBbai['spotv_policyKey']=base64.standard_b64decode(gpwQNWHGCIPSATVufDkxXYmvzyBbai['spotv_policyKey']).decode('utf-8')
  gpwQNWHGCIPSATVufDkxXYmvzyBbai['spotv_subend']=base64.standard_b64decode(gpwQNWHGCIPSATVufDkxXYmvzyBbai['spotv_subend']).decode('utf-8')[gpwQNWHGCIPSATVufDkxXYmvzyBbKh.SpotvObj.SPOTV_PMSIZE:]
  if gpwQNWHGCIPSATVufDkxXYmvzyBbRL!=gpwQNWHGCIPSATVufDkxXYmvzyBbai['spotv_id']or gpwQNWHGCIPSATVufDkxXYmvzyBbRE!=gpwQNWHGCIPSATVufDkxXYmvzyBbai['spotv_pw']:
   gpwQNWHGCIPSATVufDkxXYmvzyBbKh.wininfo_clear()
   return gpwQNWHGCIPSATVufDkxXYmvzyBbcd
  gpwQNWHGCIPSATVufDkxXYmvzyBbRU =gpwQNWHGCIPSATVufDkxXYmvzyBbcs(gpwQNWHGCIPSATVufDkxXYmvzyBbKh.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))
  gpwQNWHGCIPSATVufDkxXYmvzyBbal=gpwQNWHGCIPSATVufDkxXYmvzyBbai['spotv_limitdate']
  gpwQNWHGCIPSATVufDkxXYmvzyBbRr =gpwQNWHGCIPSATVufDkxXYmvzyBbcs(re.sub('-','',gpwQNWHGCIPSATVufDkxXYmvzyBbal))
  if gpwQNWHGCIPSATVufDkxXYmvzyBbRr<gpwQNWHGCIPSATVufDkxXYmvzyBbRU:
   gpwQNWHGCIPSATVufDkxXYmvzyBbKh.wininfo_clear()
   return gpwQNWHGCIPSATVufDkxXYmvzyBbcd
  gpwQNWHGCIPSATVufDkxXYmvzyBbKr=xbmcgui.Window(10000)
  gpwQNWHGCIPSATVufDkxXYmvzyBbKr.setProperty('SPOTV_M_SESSIONID',gpwQNWHGCIPSATVufDkxXYmvzyBbai['spotv_sessionid'])
  gpwQNWHGCIPSATVufDkxXYmvzyBbKr.setProperty('SPOTV_M_SESSION',gpwQNWHGCIPSATVufDkxXYmvzyBbai['spotv_session'])
  gpwQNWHGCIPSATVufDkxXYmvzyBbKr.setProperty('SPOTV_M_ACCOUNTID',gpwQNWHGCIPSATVufDkxXYmvzyBbai['spotv_accountId'])
  gpwQNWHGCIPSATVufDkxXYmvzyBbKr.setProperty('SPOTV_M_POLICYKEY',gpwQNWHGCIPSATVufDkxXYmvzyBbai['spotv_policyKey'])
  gpwQNWHGCIPSATVufDkxXYmvzyBbKr.setProperty('SPOTV_M_SUBEND',gpwQNWHGCIPSATVufDkxXYmvzyBbai['spotv_subend'])
  gpwQNWHGCIPSATVufDkxXYmvzyBbKr.setProperty('SPOTV_M_LOGINTIME',gpwQNWHGCIPSATVufDkxXYmvzyBbal)
  return gpwQNWHGCIPSATVufDkxXYmvzyBbcq
 def dp_WatchList_Delete(gpwQNWHGCIPSATVufDkxXYmvzyBbKh,args):
  gpwQNWHGCIPSATVufDkxXYmvzyBbaR=args.get('mediatype')
  gpwQNWHGCIPSATVufDkxXYmvzyBbKl=xbmcgui.Dialog()
  gpwQNWHGCIPSATVufDkxXYmvzyBbRt=gpwQNWHGCIPSATVufDkxXYmvzyBbKl.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if gpwQNWHGCIPSATVufDkxXYmvzyBbRt==gpwQNWHGCIPSATVufDkxXYmvzyBbcd:sys.exit()
  gpwQNWHGCIPSATVufDkxXYmvzyBbKh.Delete_Watched_List(gpwQNWHGCIPSATVufDkxXYmvzyBbaR)
  xbmc.executebuiltin("Container.Refresh")
 def Delete_Watched_List(gpwQNWHGCIPSATVufDkxXYmvzyBbKh,gpwQNWHGCIPSATVufDkxXYmvzyBbaR):
  try:
   gpwQNWHGCIPSATVufDkxXYmvzyBbaJ=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%gpwQNWHGCIPSATVufDkxXYmvzyBbaR))
   fp=gpwQNWHGCIPSATVufDkxXYmvzyBbcJ(gpwQNWHGCIPSATVufDkxXYmvzyBbaJ,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   gpwQNWHGCIPSATVufDkxXYmvzyBbch
 def Load_Watched_List(gpwQNWHGCIPSATVufDkxXYmvzyBbKh,gpwQNWHGCIPSATVufDkxXYmvzyBbaR):
  try:
   gpwQNWHGCIPSATVufDkxXYmvzyBbaJ=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%gpwQNWHGCIPSATVufDkxXYmvzyBbaR))
   fp=gpwQNWHGCIPSATVufDkxXYmvzyBbcJ(gpwQNWHGCIPSATVufDkxXYmvzyBbaJ,'r',-1,'utf-8')
   gpwQNWHGCIPSATVufDkxXYmvzyBbaL=fp.readlines()
   fp.close()
  except:
   gpwQNWHGCIPSATVufDkxXYmvzyBbaL=[]
  return gpwQNWHGCIPSATVufDkxXYmvzyBbaL
 def Save_Watched_List(gpwQNWHGCIPSATVufDkxXYmvzyBbKh,stype,gpwQNWHGCIPSATVufDkxXYmvzyBbKd):
  try:
   gpwQNWHGCIPSATVufDkxXYmvzyBbaJ=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   gpwQNWHGCIPSATVufDkxXYmvzyBbaE=gpwQNWHGCIPSATVufDkxXYmvzyBbKh.Load_Watched_List(stype) 
   fp=gpwQNWHGCIPSATVufDkxXYmvzyBbcJ(gpwQNWHGCIPSATVufDkxXYmvzyBbaJ,'w',-1,'utf-8')
   gpwQNWHGCIPSATVufDkxXYmvzyBbat=urllib.parse.urlencode(gpwQNWHGCIPSATVufDkxXYmvzyBbKd)
   gpwQNWHGCIPSATVufDkxXYmvzyBbat=gpwQNWHGCIPSATVufDkxXYmvzyBbat+'\n'
   fp.write(gpwQNWHGCIPSATVufDkxXYmvzyBbat)
   gpwQNWHGCIPSATVufDkxXYmvzyBbaU=0
   for gpwQNWHGCIPSATVufDkxXYmvzyBbar in gpwQNWHGCIPSATVufDkxXYmvzyBbaE:
    gpwQNWHGCIPSATVufDkxXYmvzyBbaj=gpwQNWHGCIPSATVufDkxXYmvzyBbct(urllib.parse.parse_qsl(gpwQNWHGCIPSATVufDkxXYmvzyBbar))
    gpwQNWHGCIPSATVufDkxXYmvzyBbaO=gpwQNWHGCIPSATVufDkxXYmvzyBbKd.get('code')
    gpwQNWHGCIPSATVufDkxXYmvzyBbaM=gpwQNWHGCIPSATVufDkxXYmvzyBbaj.get('code')
    if gpwQNWHGCIPSATVufDkxXYmvzyBbaO!=gpwQNWHGCIPSATVufDkxXYmvzyBbaM:
     fp.write(gpwQNWHGCIPSATVufDkxXYmvzyBbar)
     gpwQNWHGCIPSATVufDkxXYmvzyBbaU+=1
     if gpwQNWHGCIPSATVufDkxXYmvzyBbaU>=50:break
   fp.close()
  except:
   gpwQNWHGCIPSATVufDkxXYmvzyBbch
 def dp_Watch_List(gpwQNWHGCIPSATVufDkxXYmvzyBbKh,args):
  gpwQNWHGCIPSATVufDkxXYmvzyBbaR ='vod'
  if gpwQNWHGCIPSATVufDkxXYmvzyBbaR=='vod':
   gpwQNWHGCIPSATVufDkxXYmvzyBbae=gpwQNWHGCIPSATVufDkxXYmvzyBbKh.Load_Watched_List(gpwQNWHGCIPSATVufDkxXYmvzyBbaR)
   for gpwQNWHGCIPSATVufDkxXYmvzyBbao in gpwQNWHGCIPSATVufDkxXYmvzyBbae:
    gpwQNWHGCIPSATVufDkxXYmvzyBban=gpwQNWHGCIPSATVufDkxXYmvzyBbct(urllib.parse.parse_qsl(gpwQNWHGCIPSATVufDkxXYmvzyBbao))
    gpwQNWHGCIPSATVufDkxXYmvzyBbKM =gpwQNWHGCIPSATVufDkxXYmvzyBban.get('title')
    gpwQNWHGCIPSATVufDkxXYmvzyBbFd=gpwQNWHGCIPSATVufDkxXYmvzyBban.get('img')
    gpwQNWHGCIPSATVufDkxXYmvzyBbaF=gpwQNWHGCIPSATVufDkxXYmvzyBban.get('code')
    gpwQNWHGCIPSATVufDkxXYmvzyBbcK =gpwQNWHGCIPSATVufDkxXYmvzyBban.get('info')
    gpwQNWHGCIPSATVufDkxXYmvzyBbFJ={}
    gpwQNWHGCIPSATVufDkxXYmvzyBbFJ['plot']=gpwQNWHGCIPSATVufDkxXYmvzyBbcK
    gpwQNWHGCIPSATVufDkxXYmvzyBbFa={'mode':'GAME_VOD_GROUP','gameid':gpwQNWHGCIPSATVufDkxXYmvzyBbaF,'saveTitle':gpwQNWHGCIPSATVufDkxXYmvzyBbKM,'saveImg':gpwQNWHGCIPSATVufDkxXYmvzyBbFd,'saveInfo':gpwQNWHGCIPSATVufDkxXYmvzyBbcK,'mediatype':gpwQNWHGCIPSATVufDkxXYmvzyBbaR}
    gpwQNWHGCIPSATVufDkxXYmvzyBbKh.add_dir(gpwQNWHGCIPSATVufDkxXYmvzyBbKM,sublabel='',img=gpwQNWHGCIPSATVufDkxXYmvzyBbFd,infoLabels=gpwQNWHGCIPSATVufDkxXYmvzyBbFJ,isFolder=gpwQNWHGCIPSATVufDkxXYmvzyBbcq,params=gpwQNWHGCIPSATVufDkxXYmvzyBbFa)
   gpwQNWHGCIPSATVufDkxXYmvzyBbFJ={'plot':'시청목록을 삭제합니다.'}
   gpwQNWHGCIPSATVufDkxXYmvzyBbKM='*** 시청목록 삭제 ***'
   gpwQNWHGCIPSATVufDkxXYmvzyBbFa={'mode':'MYVIEW_REMOVE','mediatype':gpwQNWHGCIPSATVufDkxXYmvzyBbaR}
   gpwQNWHGCIPSATVufDkxXYmvzyBbKh.add_dir(gpwQNWHGCIPSATVufDkxXYmvzyBbKM,sublabel='',img='',infoLabels=gpwQNWHGCIPSATVufDkxXYmvzyBbFJ,isFolder=gpwQNWHGCIPSATVufDkxXYmvzyBbcd,params=gpwQNWHGCIPSATVufDkxXYmvzyBbFa)
   xbmcplugin.endOfDirectory(gpwQNWHGCIPSATVufDkxXYmvzyBbKh._addon_handle,cacheToDisc=gpwQNWHGCIPSATVufDkxXYmvzyBbcd)
 def spotv_main(gpwQNWHGCIPSATVufDkxXYmvzyBbKh):
  gpwQNWHGCIPSATVufDkxXYmvzyBbcR=gpwQNWHGCIPSATVufDkxXYmvzyBbKh.main_params.get('mode',gpwQNWHGCIPSATVufDkxXYmvzyBbch)
  if gpwQNWHGCIPSATVufDkxXYmvzyBbcR=='LOGOUT':
   gpwQNWHGCIPSATVufDkxXYmvzyBbKh.logout()
   return
  gpwQNWHGCIPSATVufDkxXYmvzyBbKh.login_main()
  if gpwQNWHGCIPSATVufDkxXYmvzyBbcR is gpwQNWHGCIPSATVufDkxXYmvzyBbch:
   gpwQNWHGCIPSATVufDkxXYmvzyBbKh.dp_Main_List()
  elif gpwQNWHGCIPSATVufDkxXYmvzyBbcR=='LIVE_GROUP':
   gpwQNWHGCIPSATVufDkxXYmvzyBbKh.dp_LiveChannel_List(gpwQNWHGCIPSATVufDkxXYmvzyBbKh.main_params)
  elif gpwQNWHGCIPSATVufDkxXYmvzyBbcR=='ELIVE_GROUP':
   gpwQNWHGCIPSATVufDkxXYmvzyBbRn=gpwQNWHGCIPSATVufDkxXYmvzyBbKh.dp_EventLiveChannel_List(gpwQNWHGCIPSATVufDkxXYmvzyBbKh.main_params)
   if gpwQNWHGCIPSATVufDkxXYmvzyBbRn==401:
    if os.path.isfile(gpwQNWHGCIPSATVufDkxXYmvzyBbKc):os.remove(gpwQNWHGCIPSATVufDkxXYmvzyBbKc)
    gpwQNWHGCIPSATVufDkxXYmvzyBbKh.login_main()
    gpwQNWHGCIPSATVufDkxXYmvzyBbKh.dp_EventLiveChannel_List(gpwQNWHGCIPSATVufDkxXYmvzyBbKh.main_params)
  elif gpwQNWHGCIPSATVufDkxXYmvzyBbcR in['LIVE','GAME_VOD','POP_VOD','ELIVE']:
   gpwQNWHGCIPSATVufDkxXYmvzyBbKh.play_VIDEO(gpwQNWHGCIPSATVufDkxXYmvzyBbKh.main_params)
  elif gpwQNWHGCIPSATVufDkxXYmvzyBbcR=='VOD_GROUP':
   gpwQNWHGCIPSATVufDkxXYmvzyBbKh.dp_MainLeague_List(gpwQNWHGCIPSATVufDkxXYmvzyBbKh.main_params)
  elif gpwQNWHGCIPSATVufDkxXYmvzyBbcR=='POP_GROUP':
   gpwQNWHGCIPSATVufDkxXYmvzyBbKh.dp_PopVod_GroupList(gpwQNWHGCIPSATVufDkxXYmvzyBbKh.main_params)
  elif gpwQNWHGCIPSATVufDkxXYmvzyBbcR=='LEAGUE_GROUP':
   gpwQNWHGCIPSATVufDkxXYmvzyBbKh.dp_Season_List(gpwQNWHGCIPSATVufDkxXYmvzyBbKh.main_params)
  elif gpwQNWHGCIPSATVufDkxXYmvzyBbcR=='SEASON_GROUP':
   gpwQNWHGCIPSATVufDkxXYmvzyBbKh.dp_Game_List(gpwQNWHGCIPSATVufDkxXYmvzyBbKh.main_params)
  elif gpwQNWHGCIPSATVufDkxXYmvzyBbcR=='GAME_VOD_GROUP':
   gpwQNWHGCIPSATVufDkxXYmvzyBbKh.dp_GameVod_List(gpwQNWHGCIPSATVufDkxXYmvzyBbKh.main_params)
  elif gpwQNWHGCIPSATVufDkxXYmvzyBbcR=='WATCH':
   gpwQNWHGCIPSATVufDkxXYmvzyBbKh.dp_Watch_List(gpwQNWHGCIPSATVufDkxXYmvzyBbKh.main_params)
  elif gpwQNWHGCIPSATVufDkxXYmvzyBbcR=='MYVIEW_REMOVE':
   gpwQNWHGCIPSATVufDkxXYmvzyBbKh.dp_WatchList_Delete(gpwQNWHGCIPSATVufDkxXYmvzyBbKh.main_params)
  else:
   gpwQNWHGCIPSATVufDkxXYmvzyBbch
# Created by pyminifier (https://github.com/liftoff/pyminifier)
