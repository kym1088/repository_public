__author__="NightRain"
uWUzXdGwEvPKftOSbNITHkjCVFqJaA=object
uWUzXdGwEvPKftOSbNITHkjCVFqJas=None
uWUzXdGwEvPKftOSbNITHkjCVFqJan=False
uWUzXdGwEvPKftOSbNITHkjCVFqJaL=print
uWUzXdGwEvPKftOSbNITHkjCVFqJaR=str
uWUzXdGwEvPKftOSbNITHkjCVFqJaB=True
uWUzXdGwEvPKftOSbNITHkjCVFqJaQ=Exception
uWUzXdGwEvPKftOSbNITHkjCVFqJac=range
uWUzXdGwEvPKftOSbNITHkjCVFqJai=int
import urllib
import http.cookiejar 
import re
import json
import sys
import time
import requests
import datetime
import base64
uWUzXdGwEvPKftOSbNITHkjCVFqJeY ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36'
uWUzXdGwEvPKftOSbNITHkjCVFqJep={'stream50':1080,'stream40':720,'stream30':540}
class uWUzXdGwEvPKftOSbNITHkjCVFqJex(uWUzXdGwEvPKftOSbNITHkjCVFqJaA):
 def __init__(uWUzXdGwEvPKftOSbNITHkjCVFqJea):
  uWUzXdGwEvPKftOSbNITHkjCVFqJea.SPOTV_SESSIONID=''
  uWUzXdGwEvPKftOSbNITHkjCVFqJea.SPOTV_SESSION =''
  uWUzXdGwEvPKftOSbNITHkjCVFqJea.SPOTV_ACCOUNTID=''
  uWUzXdGwEvPKftOSbNITHkjCVFqJea.SPOTV_POLICYKEY=''
  uWUzXdGwEvPKftOSbNITHkjCVFqJea.SPOTV_SUBEND =''
  uWUzXdGwEvPKftOSbNITHkjCVFqJea.SPOTV_PMCODE ='987'
  uWUzXdGwEvPKftOSbNITHkjCVFqJea.SPOTV_PMSIZE =3
  uWUzXdGwEvPKftOSbNITHkjCVFqJea.GAMELIST_LIMIT =10
  uWUzXdGwEvPKftOSbNITHkjCVFqJea.API_DOMAIN ='https://www.spotvnow.co.kr'
  uWUzXdGwEvPKftOSbNITHkjCVFqJea.BC_DOMAIN ='https://players.brightcove.net'
  uWUzXdGwEvPKftOSbNITHkjCVFqJea.PLAYER_DOMAIN ='https://edge.api.brightcove.com'
  uWUzXdGwEvPKftOSbNITHkjCVFqJea.DEFAULT_HEADER ={'user-agent':uWUzXdGwEvPKftOSbNITHkjCVFqJeY}
 def callRequestCookies(uWUzXdGwEvPKftOSbNITHkjCVFqJea,jobtype,uWUzXdGwEvPKftOSbNITHkjCVFqJxp,payload=uWUzXdGwEvPKftOSbNITHkjCVFqJas,params=uWUzXdGwEvPKftOSbNITHkjCVFqJas,headers=uWUzXdGwEvPKftOSbNITHkjCVFqJas,cookies=uWUzXdGwEvPKftOSbNITHkjCVFqJas,redirects=uWUzXdGwEvPKftOSbNITHkjCVFqJan):
  uWUzXdGwEvPKftOSbNITHkjCVFqJer=uWUzXdGwEvPKftOSbNITHkjCVFqJea.DEFAULT_HEADER
  if headers:uWUzXdGwEvPKftOSbNITHkjCVFqJer.update(headers)
  if jobtype=='Get':
   uWUzXdGwEvPKftOSbNITHkjCVFqJeA=requests.get(uWUzXdGwEvPKftOSbNITHkjCVFqJxp,params=params,headers=uWUzXdGwEvPKftOSbNITHkjCVFqJer,cookies=cookies,allow_redirects=redirects)
  else:
   uWUzXdGwEvPKftOSbNITHkjCVFqJeA=requests.post(uWUzXdGwEvPKftOSbNITHkjCVFqJxp,data=payload,params=params,headers=uWUzXdGwEvPKftOSbNITHkjCVFqJer,cookies=cookies,allow_redirects=redirects)
  return uWUzXdGwEvPKftOSbNITHkjCVFqJeA
 def makeDefaultCookies(uWUzXdGwEvPKftOSbNITHkjCVFqJea):
  uWUzXdGwEvPKftOSbNITHkjCVFqJes={'SESSION':uWUzXdGwEvPKftOSbNITHkjCVFqJea.SPOTV_SESSION}
  return uWUzXdGwEvPKftOSbNITHkjCVFqJes
 def GetCredential(uWUzXdGwEvPKftOSbNITHkjCVFqJea,user_id,user_pw):
  uWUzXdGwEvPKftOSbNITHkjCVFqJen=uWUzXdGwEvPKftOSbNITHkjCVFqJan
  uWUzXdGwEvPKftOSbNITHkjCVFqJeL=uWUzXdGwEvPKftOSbNITHkjCVFqJeD=uWUzXdGwEvPKftOSbNITHkjCVFqJeg=uWUzXdGwEvPKftOSbNITHkjCVFqJey=uWUzXdGwEvPKftOSbNITHkjCVFqJeo=''
  try:
   uWUzXdGwEvPKftOSbNITHkjCVFqJeR=base64.standard_b64encode(user_id.encode("UTF-8")).decode('utf-8')
   uWUzXdGwEvPKftOSbNITHkjCVFqJeB=base64.standard_b64encode(user_pw.encode("UTF-8")).decode('utf-8')
   uWUzXdGwEvPKftOSbNITHkjCVFqJeQ=uWUzXdGwEvPKftOSbNITHkjCVFqJea.API_DOMAIN+'/api/v2/login'
   uWUzXdGwEvPKftOSbNITHkjCVFqJec={'username':uWUzXdGwEvPKftOSbNITHkjCVFqJeR,'password':uWUzXdGwEvPKftOSbNITHkjCVFqJeB}
   uWUzXdGwEvPKftOSbNITHkjCVFqJec=json.dumps(uWUzXdGwEvPKftOSbNITHkjCVFqJec)
   uWUzXdGwEvPKftOSbNITHkjCVFqJei=uWUzXdGwEvPKftOSbNITHkjCVFqJea.callRequestCookies('Post',uWUzXdGwEvPKftOSbNITHkjCVFqJeQ,payload=uWUzXdGwEvPKftOSbNITHkjCVFqJec,params=uWUzXdGwEvPKftOSbNITHkjCVFqJas,headers=uWUzXdGwEvPKftOSbNITHkjCVFqJas,cookies=uWUzXdGwEvPKftOSbNITHkjCVFqJas)
   uWUzXdGwEvPKftOSbNITHkjCVFqJaL(uWUzXdGwEvPKftOSbNITHkjCVFqJei.status_code)
   for uWUzXdGwEvPKftOSbNITHkjCVFqJeM in uWUzXdGwEvPKftOSbNITHkjCVFqJei.cookies:
    if uWUzXdGwEvPKftOSbNITHkjCVFqJeM.name=='SESSION':
     uWUzXdGwEvPKftOSbNITHkjCVFqJeD=uWUzXdGwEvPKftOSbNITHkjCVFqJeM.value
     break
   if uWUzXdGwEvPKftOSbNITHkjCVFqJeD=='':return uWUzXdGwEvPKftOSbNITHkjCVFqJen
   uWUzXdGwEvPKftOSbNITHkjCVFqJeh=json.loads(uWUzXdGwEvPKftOSbNITHkjCVFqJei.text)
   if not('userId' in uWUzXdGwEvPKftOSbNITHkjCVFqJeh):return uWUzXdGwEvPKftOSbNITHkjCVFqJen
   uWUzXdGwEvPKftOSbNITHkjCVFqJeL=uWUzXdGwEvPKftOSbNITHkjCVFqJaR(uWUzXdGwEvPKftOSbNITHkjCVFqJeh['userId'])
   uWUzXdGwEvPKftOSbNITHkjCVFqJeo =uWUzXdGwEvPKftOSbNITHkjCVFqJaR(uWUzXdGwEvPKftOSbNITHkjCVFqJeh['subEndTime'])
   uWUzXdGwEvPKftOSbNITHkjCVFqJeg,uWUzXdGwEvPKftOSbNITHkjCVFqJey=uWUzXdGwEvPKftOSbNITHkjCVFqJea.GetPolicyKey()
   if uWUzXdGwEvPKftOSbNITHkjCVFqJey=='':return uWUzXdGwEvPKftOSbNITHkjCVFqJen
   uWUzXdGwEvPKftOSbNITHkjCVFqJen=uWUzXdGwEvPKftOSbNITHkjCVFqJaB
  except uWUzXdGwEvPKftOSbNITHkjCVFqJaQ as exception:
   uWUzXdGwEvPKftOSbNITHkjCVFqJeL=uWUzXdGwEvPKftOSbNITHkjCVFqJeD='' 
   uWUzXdGwEvPKftOSbNITHkjCVFqJaL(exception)
  uWUzXdGwEvPKftOSbNITHkjCVFqJem={'spotv_sessionid':uWUzXdGwEvPKftOSbNITHkjCVFqJeL,'spotv_session':uWUzXdGwEvPKftOSbNITHkjCVFqJeD,'spotv_accountId':uWUzXdGwEvPKftOSbNITHkjCVFqJeg,'spotv_policyKey':uWUzXdGwEvPKftOSbNITHkjCVFqJey,'spotv_subend':uWUzXdGwEvPKftOSbNITHkjCVFqJeo}
  uWUzXdGwEvPKftOSbNITHkjCVFqJea.SaveCredential(uWUzXdGwEvPKftOSbNITHkjCVFqJem)
  return uWUzXdGwEvPKftOSbNITHkjCVFqJen
 def SaveCredential(uWUzXdGwEvPKftOSbNITHkjCVFqJea,uWUzXdGwEvPKftOSbNITHkjCVFqJem):
  uWUzXdGwEvPKftOSbNITHkjCVFqJea.SPOTV_SESSIONID=uWUzXdGwEvPKftOSbNITHkjCVFqJem.get('spotv_sessionid')
  uWUzXdGwEvPKftOSbNITHkjCVFqJea.SPOTV_SESSION =uWUzXdGwEvPKftOSbNITHkjCVFqJem.get('spotv_session')
  uWUzXdGwEvPKftOSbNITHkjCVFqJea.SPOTV_ACCOUNTID=uWUzXdGwEvPKftOSbNITHkjCVFqJem.get('spotv_accountId')
  uWUzXdGwEvPKftOSbNITHkjCVFqJea.SPOTV_POLICYKEY=uWUzXdGwEvPKftOSbNITHkjCVFqJem.get('spotv_policyKey')
  uWUzXdGwEvPKftOSbNITHkjCVFqJea.SPOTV_SUBEND =uWUzXdGwEvPKftOSbNITHkjCVFqJem.get('spotv_subend')
 def LoadCredential(uWUzXdGwEvPKftOSbNITHkjCVFqJea):
  uWUzXdGwEvPKftOSbNITHkjCVFqJem={'spotv_sessionid':uWUzXdGwEvPKftOSbNITHkjCVFqJea.SPOTV_SESSIONID,'spotv_session':uWUzXdGwEvPKftOSbNITHkjCVFqJea.SPOTV_SESSION,'spotv_accountId':uWUzXdGwEvPKftOSbNITHkjCVFqJea.SPOTV_ACCOUNTID,'spotv_policyKey':uWUzXdGwEvPKftOSbNITHkjCVFqJea.SPOTV_POLICYKEY,'spotv_subend':uWUzXdGwEvPKftOSbNITHkjCVFqJea.SPOTV_SUBEND}
  return uWUzXdGwEvPKftOSbNITHkjCVFqJem
 def Get_Now_Datetime(uWUzXdGwEvPKftOSbNITHkjCVFqJea):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetLiveChannelList(uWUzXdGwEvPKftOSbNITHkjCVFqJea):
  uWUzXdGwEvPKftOSbNITHkjCVFqJxe=[]
  uWUzXdGwEvPKftOSbNITHkjCVFqJxY ={}
  try:
   uWUzXdGwEvPKftOSbNITHkjCVFqJxp=uWUzXdGwEvPKftOSbNITHkjCVFqJea.API_DOMAIN+'/api/v2/channel'
   uWUzXdGwEvPKftOSbNITHkjCVFqJei=uWUzXdGwEvPKftOSbNITHkjCVFqJea.callRequestCookies('Get',uWUzXdGwEvPKftOSbNITHkjCVFqJxp,payload=uWUzXdGwEvPKftOSbNITHkjCVFqJas,params=uWUzXdGwEvPKftOSbNITHkjCVFqJas,headers=uWUzXdGwEvPKftOSbNITHkjCVFqJas,cookies=uWUzXdGwEvPKftOSbNITHkjCVFqJas)
   uWUzXdGwEvPKftOSbNITHkjCVFqJeh=json.loads(uWUzXdGwEvPKftOSbNITHkjCVFqJei.text)
   uWUzXdGwEvPKftOSbNITHkjCVFqJxY=uWUzXdGwEvPKftOSbNITHkjCVFqJea.GetEPGList()
   for i in uWUzXdGwEvPKftOSbNITHkjCVFqJac(2):
    for uWUzXdGwEvPKftOSbNITHkjCVFqJxa in uWUzXdGwEvPKftOSbNITHkjCVFqJeh:
     uWUzXdGwEvPKftOSbNITHkjCVFqJxr={}
     uWUzXdGwEvPKftOSbNITHkjCVFqJxr['mediatype']='video'
     uWUzXdGwEvPKftOSbNITHkjCVFqJxr['title'] =uWUzXdGwEvPKftOSbNITHkjCVFqJxa['programName']
     uWUzXdGwEvPKftOSbNITHkjCVFqJxr['studio'] =uWUzXdGwEvPKftOSbNITHkjCVFqJxa['name']
     uWUzXdGwEvPKftOSbNITHkjCVFqJxA={'id':uWUzXdGwEvPKftOSbNITHkjCVFqJxa['id'],'name':uWUzXdGwEvPKftOSbNITHkjCVFqJxa['name'],'logo':uWUzXdGwEvPKftOSbNITHkjCVFqJxa['logo'],'videoId':uWUzXdGwEvPKftOSbNITHkjCVFqJxa['videoId'].replace('ref:',''),'free':uWUzXdGwEvPKftOSbNITHkjCVFqJxa['free'],'programName':uWUzXdGwEvPKftOSbNITHkjCVFqJxa['programName'],'channelepg':uWUzXdGwEvPKftOSbNITHkjCVFqJxY.get(uWUzXdGwEvPKftOSbNITHkjCVFqJxa['id']),'info':uWUzXdGwEvPKftOSbNITHkjCVFqJxr}
     if i==0:
      if uWUzXdGwEvPKftOSbNITHkjCVFqJxa['free']==uWUzXdGwEvPKftOSbNITHkjCVFqJan:uWUzXdGwEvPKftOSbNITHkjCVFqJxe.append(uWUzXdGwEvPKftOSbNITHkjCVFqJxA)
     else:
      if uWUzXdGwEvPKftOSbNITHkjCVFqJxa['free']==uWUzXdGwEvPKftOSbNITHkjCVFqJaB:uWUzXdGwEvPKftOSbNITHkjCVFqJxe.append(uWUzXdGwEvPKftOSbNITHkjCVFqJxA)
  except uWUzXdGwEvPKftOSbNITHkjCVFqJaQ as exception:
   uWUzXdGwEvPKftOSbNITHkjCVFqJaL(exception)
  return uWUzXdGwEvPKftOSbNITHkjCVFqJxe
 def GetEPGList(uWUzXdGwEvPKftOSbNITHkjCVFqJea):
  uWUzXdGwEvPKftOSbNITHkjCVFqJxs={}
  uWUzXdGwEvPKftOSbNITHkjCVFqJxn=uWUzXdGwEvPKftOSbNITHkjCVFqJea.Get_Now_Datetime()
  uWUzXdGwEvPKftOSbNITHkjCVFqJxL=uWUzXdGwEvPKftOSbNITHkjCVFqJxn.strftime('%Y%m%d%H%M')
  uWUzXdGwEvPKftOSbNITHkjCVFqJxR='%s-%s-%s'%(uWUzXdGwEvPKftOSbNITHkjCVFqJxL[0:4],uWUzXdGwEvPKftOSbNITHkjCVFqJxL[4:6],uWUzXdGwEvPKftOSbNITHkjCVFqJxL[6:8])
  uWUzXdGwEvPKftOSbNITHkjCVFqJxB=(uWUzXdGwEvPKftOSbNITHkjCVFqJxn+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M')
  try:
   uWUzXdGwEvPKftOSbNITHkjCVFqJxp=uWUzXdGwEvPKftOSbNITHkjCVFqJea.API_DOMAIN+'/api/v2/program/'+uWUzXdGwEvPKftOSbNITHkjCVFqJxR
   uWUzXdGwEvPKftOSbNITHkjCVFqJei=uWUzXdGwEvPKftOSbNITHkjCVFqJea.callRequestCookies('Get',uWUzXdGwEvPKftOSbNITHkjCVFqJxp,payload=uWUzXdGwEvPKftOSbNITHkjCVFqJas,params=uWUzXdGwEvPKftOSbNITHkjCVFqJas,headers=uWUzXdGwEvPKftOSbNITHkjCVFqJas,cookies=uWUzXdGwEvPKftOSbNITHkjCVFqJas)
   uWUzXdGwEvPKftOSbNITHkjCVFqJeh=json.loads(uWUzXdGwEvPKftOSbNITHkjCVFqJei.text)
   uWUzXdGwEvPKftOSbNITHkjCVFqJxQ=-1 
   uWUzXdGwEvPKftOSbNITHkjCVFqJxc =''
   for uWUzXdGwEvPKftOSbNITHkjCVFqJxa in uWUzXdGwEvPKftOSbNITHkjCVFqJeh:
    uWUzXdGwEvPKftOSbNITHkjCVFqJxi=uWUzXdGwEvPKftOSbNITHkjCVFqJxa['channelId']
    uWUzXdGwEvPKftOSbNITHkjCVFqJxM =uWUzXdGwEvPKftOSbNITHkjCVFqJxa['startTime'].replace('-','').replace(' ','').replace(':','')
    uWUzXdGwEvPKftOSbNITHkjCVFqJxD =uWUzXdGwEvPKftOSbNITHkjCVFqJxa['endTime'].replace('-','').replace(' ','').replace(':','')
    if uWUzXdGwEvPKftOSbNITHkjCVFqJai(uWUzXdGwEvPKftOSbNITHkjCVFqJxL)>uWUzXdGwEvPKftOSbNITHkjCVFqJai(uWUzXdGwEvPKftOSbNITHkjCVFqJxD) :continue
    if uWUzXdGwEvPKftOSbNITHkjCVFqJai(uWUzXdGwEvPKftOSbNITHkjCVFqJxB)<uWUzXdGwEvPKftOSbNITHkjCVFqJai(uWUzXdGwEvPKftOSbNITHkjCVFqJxM):continue
    if uWUzXdGwEvPKftOSbNITHkjCVFqJxQ!=uWUzXdGwEvPKftOSbNITHkjCVFqJxi:
     if uWUzXdGwEvPKftOSbNITHkjCVFqJxc!='':uWUzXdGwEvPKftOSbNITHkjCVFqJxs[uWUzXdGwEvPKftOSbNITHkjCVFqJxQ]=uWUzXdGwEvPKftOSbNITHkjCVFqJxc
     uWUzXdGwEvPKftOSbNITHkjCVFqJxQ=uWUzXdGwEvPKftOSbNITHkjCVFqJxi
     uWUzXdGwEvPKftOSbNITHkjCVFqJxc =''
    if uWUzXdGwEvPKftOSbNITHkjCVFqJxc:uWUzXdGwEvPKftOSbNITHkjCVFqJxc+='\n'
    uWUzXdGwEvPKftOSbNITHkjCVFqJxc+=uWUzXdGwEvPKftOSbNITHkjCVFqJxa['title']+'\n'
    uWUzXdGwEvPKftOSbNITHkjCVFqJxc+=' [%s ~ %s]'%(uWUzXdGwEvPKftOSbNITHkjCVFqJxa['startTime'][-5:],uWUzXdGwEvPKftOSbNITHkjCVFqJxa['endTime'][-5:])+'\n'
   if uWUzXdGwEvPKftOSbNITHkjCVFqJxc:uWUzXdGwEvPKftOSbNITHkjCVFqJxs[uWUzXdGwEvPKftOSbNITHkjCVFqJxQ]=uWUzXdGwEvPKftOSbNITHkjCVFqJxc
  except uWUzXdGwEvPKftOSbNITHkjCVFqJaQ as exception:
   uWUzXdGwEvPKftOSbNITHkjCVFqJaL(exception)
  return uWUzXdGwEvPKftOSbNITHkjCVFqJxs
 def GetEventLiveList(uWUzXdGwEvPKftOSbNITHkjCVFqJea):
  uWUzXdGwEvPKftOSbNITHkjCVFqJxe=[]
  uWUzXdGwEvPKftOSbNITHkjCVFqJxh =0
  try:
   uWUzXdGwEvPKftOSbNITHkjCVFqJxo=uWUzXdGwEvPKftOSbNITHkjCVFqJea.Get_Now_Datetime()
   uWUzXdGwEvPKftOSbNITHkjCVFqJxg=uWUzXdGwEvPKftOSbNITHkjCVFqJxo.strftime('%Y-%m-%d')
  except uWUzXdGwEvPKftOSbNITHkjCVFqJaQ as exception:
   uWUzXdGwEvPKftOSbNITHkjCVFqJaL(exception)
   return uWUzXdGwEvPKftOSbNITHkjCVFqJxe,uWUzXdGwEvPKftOSbNITHkjCVFqJxh
  try:
   uWUzXdGwEvPKftOSbNITHkjCVFqJxp=uWUzXdGwEvPKftOSbNITHkjCVFqJea.API_DOMAIN+'/api/v2/player/lives/'+uWUzXdGwEvPKftOSbNITHkjCVFqJxg 
   uWUzXdGwEvPKftOSbNITHkjCVFqJes=uWUzXdGwEvPKftOSbNITHkjCVFqJea.makeDefaultCookies()
   uWUzXdGwEvPKftOSbNITHkjCVFqJei=uWUzXdGwEvPKftOSbNITHkjCVFqJea.callRequestCookies('Get',uWUzXdGwEvPKftOSbNITHkjCVFqJxp,payload=uWUzXdGwEvPKftOSbNITHkjCVFqJas,params=uWUzXdGwEvPKftOSbNITHkjCVFqJas,headers=uWUzXdGwEvPKftOSbNITHkjCVFqJas,cookies=uWUzXdGwEvPKftOSbNITHkjCVFqJes)
   uWUzXdGwEvPKftOSbNITHkjCVFqJxh=uWUzXdGwEvPKftOSbNITHkjCVFqJei.status_code 
   uWUzXdGwEvPKftOSbNITHkjCVFqJeh=json.loads(uWUzXdGwEvPKftOSbNITHkjCVFqJei.text)
   for uWUzXdGwEvPKftOSbNITHkjCVFqJxy in uWUzXdGwEvPKftOSbNITHkjCVFqJeh:
    for uWUzXdGwEvPKftOSbNITHkjCVFqJxa in uWUzXdGwEvPKftOSbNITHkjCVFqJxy['liveNowList']:
     uWUzXdGwEvPKftOSbNITHkjCVFqJxr={}
     uWUzXdGwEvPKftOSbNITHkjCVFqJxr['mediatype']='video'
     if uWUzXdGwEvPKftOSbNITHkjCVFqJxa['gameDesc']['title']==uWUzXdGwEvPKftOSbNITHkjCVFqJas or uWUzXdGwEvPKftOSbNITHkjCVFqJxa['gameDesc']['title']=='':
      uWUzXdGwEvPKftOSbNITHkjCVFqJxm='%s ( %s : %s )'%(uWUzXdGwEvPKftOSbNITHkjCVFqJxa['leagueName'],uWUzXdGwEvPKftOSbNITHkjCVFqJxa['homeNameShort'],uWUzXdGwEvPKftOSbNITHkjCVFqJxa['awayNameShort'])
     else:
      uWUzXdGwEvPKftOSbNITHkjCVFqJxm=uWUzXdGwEvPKftOSbNITHkjCVFqJxa['gameDesc']['title']
     uWUzXdGwEvPKftOSbNITHkjCVFqJxA={'liveId':uWUzXdGwEvPKftOSbNITHkjCVFqJxa['liveId'],'title':uWUzXdGwEvPKftOSbNITHkjCVFqJxm,'logo':uWUzXdGwEvPKftOSbNITHkjCVFqJxa['gameDesc']['leagueLogo'],'free':uWUzXdGwEvPKftOSbNITHkjCVFqJxa['isFree'],'startTime':uWUzXdGwEvPKftOSbNITHkjCVFqJxa['startTime'],'info':uWUzXdGwEvPKftOSbNITHkjCVFqJxr}
     uWUzXdGwEvPKftOSbNITHkjCVFqJxe.append(uWUzXdGwEvPKftOSbNITHkjCVFqJxA)
  except uWUzXdGwEvPKftOSbNITHkjCVFqJaQ as exception:
   uWUzXdGwEvPKftOSbNITHkjCVFqJaL(exception)
  return uWUzXdGwEvPKftOSbNITHkjCVFqJxe,uWUzXdGwEvPKftOSbNITHkjCVFqJxh
 def GetEventLiveList_sub(uWUzXdGwEvPKftOSbNITHkjCVFqJea,tDate):
  uWUzXdGwEvPKftOSbNITHkjCVFqJxe=[]
  try:
   uWUzXdGwEvPKftOSbNITHkjCVFqJxp=uWUzXdGwEvPKftOSbNITHkjCVFqJea.API_DOMAIN+'/api/v2/player/lives/'+tDate
   uWUzXdGwEvPKftOSbNITHkjCVFqJes=uWUzXdGwEvPKftOSbNITHkjCVFqJea.makeDefaultCookies()
   uWUzXdGwEvPKftOSbNITHkjCVFqJei=uWUzXdGwEvPKftOSbNITHkjCVFqJea.callRequestCookies('Get',uWUzXdGwEvPKftOSbNITHkjCVFqJxp,payload=uWUzXdGwEvPKftOSbNITHkjCVFqJas,params=uWUzXdGwEvPKftOSbNITHkjCVFqJas,headers=uWUzXdGwEvPKftOSbNITHkjCVFqJas,cookies=uWUzXdGwEvPKftOSbNITHkjCVFqJes)
   uWUzXdGwEvPKftOSbNITHkjCVFqJeh=json.loads(uWUzXdGwEvPKftOSbNITHkjCVFqJei.text)
   for uWUzXdGwEvPKftOSbNITHkjCVFqJxy in uWUzXdGwEvPKftOSbNITHkjCVFqJeh:
    for uWUzXdGwEvPKftOSbNITHkjCVFqJxa in uWUzXdGwEvPKftOSbNITHkjCVFqJxy['liveNowList']:
     uWUzXdGwEvPKftOSbNITHkjCVFqJxr={}
     uWUzXdGwEvPKftOSbNITHkjCVFqJxr['mediatype']='video'
     if uWUzXdGwEvPKftOSbNITHkjCVFqJxa['gameDesc']['title']==uWUzXdGwEvPKftOSbNITHkjCVFqJas or uWUzXdGwEvPKftOSbNITHkjCVFqJxa['gameDesc']['title']=='':
      uWUzXdGwEvPKftOSbNITHkjCVFqJxm='%s ( %s : %s )'%(uWUzXdGwEvPKftOSbNITHkjCVFqJxa['leagueName'],uWUzXdGwEvPKftOSbNITHkjCVFqJxa['homeNameShort'],uWUzXdGwEvPKftOSbNITHkjCVFqJxa['awayNameShort'])
     else:
      uWUzXdGwEvPKftOSbNITHkjCVFqJxm=uWUzXdGwEvPKftOSbNITHkjCVFqJxa['gameDesc']['title']
     uWUzXdGwEvPKftOSbNITHkjCVFqJxA={'liveId':uWUzXdGwEvPKftOSbNITHkjCVFqJxa['liveId'],'title':uWUzXdGwEvPKftOSbNITHkjCVFqJxm,'logo':uWUzXdGwEvPKftOSbNITHkjCVFqJxa['gameDesc']['leagueLogo'],'free':uWUzXdGwEvPKftOSbNITHkjCVFqJxa['isFree'],'startTime':uWUzXdGwEvPKftOSbNITHkjCVFqJxa['startTime'],'info':uWUzXdGwEvPKftOSbNITHkjCVFqJxr}
     uWUzXdGwEvPKftOSbNITHkjCVFqJxe.append(uWUzXdGwEvPKftOSbNITHkjCVFqJxA)
  except uWUzXdGwEvPKftOSbNITHkjCVFqJaQ as exception:
   uWUzXdGwEvPKftOSbNITHkjCVFqJaL(exception)
  return uWUzXdGwEvPKftOSbNITHkjCVFqJxe
 def GetEventLive_videoId(uWUzXdGwEvPKftOSbNITHkjCVFqJea,liveId):
  uWUzXdGwEvPKftOSbNITHkjCVFqJxl=''
  try:
   uWUzXdGwEvPKftOSbNITHkjCVFqJxp=uWUzXdGwEvPKftOSbNITHkjCVFqJea.API_DOMAIN+'/api/v2/live/'+liveId
   uWUzXdGwEvPKftOSbNITHkjCVFqJei=uWUzXdGwEvPKftOSbNITHkjCVFqJea.callRequestCookies('Get',uWUzXdGwEvPKftOSbNITHkjCVFqJxp,payload=uWUzXdGwEvPKftOSbNITHkjCVFqJas,params=uWUzXdGwEvPKftOSbNITHkjCVFqJas,headers=uWUzXdGwEvPKftOSbNITHkjCVFqJas,cookies=uWUzXdGwEvPKftOSbNITHkjCVFqJas)
   uWUzXdGwEvPKftOSbNITHkjCVFqJeh=json.loads(uWUzXdGwEvPKftOSbNITHkjCVFqJei.text)
   uWUzXdGwEvPKftOSbNITHkjCVFqJYe=uWUzXdGwEvPKftOSbNITHkjCVFqJeh['videoId']
   uWUzXdGwEvPKftOSbNITHkjCVFqJxl=uWUzXdGwEvPKftOSbNITHkjCVFqJYe.replace('ref:','')
  except uWUzXdGwEvPKftOSbNITHkjCVFqJaQ as exception:
   uWUzXdGwEvPKftOSbNITHkjCVFqJaL(exception)
  return uWUzXdGwEvPKftOSbNITHkjCVFqJxl
 def CheckMainEnd(uWUzXdGwEvPKftOSbNITHkjCVFqJea):
  uWUzXdGwEvPKftOSbNITHkjCVFqJYx=base64.standard_b64encode((uWUzXdGwEvPKftOSbNITHkjCVFqJea.SPOTV_PMCODE+uWUzXdGwEvPKftOSbNITHkjCVFqJea.SPOTV_SESSIONID).encode()).decode('utf-8')
  if uWUzXdGwEvPKftOSbNITHkjCVFqJYx=='OTg3MTgzMzM0Ng==' or uWUzXdGwEvPKftOSbNITHkjCVFqJYx=='OTg3MTgzMzExNw==':return uWUzXdGwEvPKftOSbNITHkjCVFqJaB
  return uWUzXdGwEvPKftOSbNITHkjCVFqJan
 def CheckSubEnd(uWUzXdGwEvPKftOSbNITHkjCVFqJea):
  uWUzXdGwEvPKftOSbNITHkjCVFqJYp=uWUzXdGwEvPKftOSbNITHkjCVFqJan
  try:
   if uWUzXdGwEvPKftOSbNITHkjCVFqJea.CheckMainEnd():return uWUzXdGwEvPKftOSbNITHkjCVFqJaB 
   if uWUzXdGwEvPKftOSbNITHkjCVFqJea.SPOTV_SUBEND=='0':return uWUzXdGwEvPKftOSbNITHkjCVFqJYp
   uWUzXdGwEvPKftOSbNITHkjCVFqJYa =uWUzXdGwEvPKftOSbNITHkjCVFqJai(uWUzXdGwEvPKftOSbNITHkjCVFqJea.Get_Now_Datetime().strftime('%Y%m%d'))
   uWUzXdGwEvPKftOSbNITHkjCVFqJYr =uWUzXdGwEvPKftOSbNITHkjCVFqJai(uWUzXdGwEvPKftOSbNITHkjCVFqJea.SPOTV_SUBEND)/1000
   uWUzXdGwEvPKftOSbNITHkjCVFqJYA =uWUzXdGwEvPKftOSbNITHkjCVFqJai(datetime.datetime.fromtimestamp(uWUzXdGwEvPKftOSbNITHkjCVFqJYr,datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul')).strftime('%Y%m%d'))
   if uWUzXdGwEvPKftOSbNITHkjCVFqJYa<=uWUzXdGwEvPKftOSbNITHkjCVFqJYA:uWUzXdGwEvPKftOSbNITHkjCVFqJYp=uWUzXdGwEvPKftOSbNITHkjCVFqJaB
  except uWUzXdGwEvPKftOSbNITHkjCVFqJaQ as exception:
   uWUzXdGwEvPKftOSbNITHkjCVFqJaL(exception)
   return uWUzXdGwEvPKftOSbNITHkjCVFqJYp
  return uWUzXdGwEvPKftOSbNITHkjCVFqJYp
 def GetMainJspath(uWUzXdGwEvPKftOSbNITHkjCVFqJea):
  uWUzXdGwEvPKftOSbNITHkjCVFqJYs=''
  try:
   uWUzXdGwEvPKftOSbNITHkjCVFqJxp=uWUzXdGwEvPKftOSbNITHkjCVFqJea.API_DOMAIN
   uWUzXdGwEvPKftOSbNITHkjCVFqJei=uWUzXdGwEvPKftOSbNITHkjCVFqJea.callRequestCookies('Get',uWUzXdGwEvPKftOSbNITHkjCVFqJxp,payload=uWUzXdGwEvPKftOSbNITHkjCVFqJas,params=uWUzXdGwEvPKftOSbNITHkjCVFqJas,headers=uWUzXdGwEvPKftOSbNITHkjCVFqJas,cookies=uWUzXdGwEvPKftOSbNITHkjCVFqJas)
   uWUzXdGwEvPKftOSbNITHkjCVFqJYn=uWUzXdGwEvPKftOSbNITHkjCVFqJei.text
   uWUzXdGwEvPKftOSbNITHkjCVFqJYL =re.findall('https://cdn.spotvnow.co.kr/dist/js/.{20}\.js',uWUzXdGwEvPKftOSbNITHkjCVFqJYn)[0]
   uWUzXdGwEvPKftOSbNITHkjCVFqJYs=uWUzXdGwEvPKftOSbNITHkjCVFqJYL
  except uWUzXdGwEvPKftOSbNITHkjCVFqJaQ as exception:
   uWUzXdGwEvPKftOSbNITHkjCVFqJaL(exception)
  return uWUzXdGwEvPKftOSbNITHkjCVFqJYs
 def GetBcPlayerUrl(uWUzXdGwEvPKftOSbNITHkjCVFqJea):
  uWUzXdGwEvPKftOSbNITHkjCVFqJYR=''
  try:
   uWUzXdGwEvPKftOSbNITHkjCVFqJxp=uWUzXdGwEvPKftOSbNITHkjCVFqJea.GetMainJspath()
   if uWUzXdGwEvPKftOSbNITHkjCVFqJxp=='':return uWUzXdGwEvPKftOSbNITHkjCVFqJYR
   uWUzXdGwEvPKftOSbNITHkjCVFqJei=uWUzXdGwEvPKftOSbNITHkjCVFqJea.callRequestCookies('Get',uWUzXdGwEvPKftOSbNITHkjCVFqJxp,payload=uWUzXdGwEvPKftOSbNITHkjCVFqJas,params=uWUzXdGwEvPKftOSbNITHkjCVFqJas,headers=uWUzXdGwEvPKftOSbNITHkjCVFqJas,cookies=uWUzXdGwEvPKftOSbNITHkjCVFqJas)
   uWUzXdGwEvPKftOSbNITHkjCVFqJYn=uWUzXdGwEvPKftOSbNITHkjCVFqJei.text
   uWUzXdGwEvPKftOSbNITHkjCVFqJYB =re.findall('bc:\s*\"\d{13}\",\s*player:\s*\".{9}\"',uWUzXdGwEvPKftOSbNITHkjCVFqJYn)[0]
   uWUzXdGwEvPKftOSbNITHkjCVFqJYB =uWUzXdGwEvPKftOSbNITHkjCVFqJYB.replace('bc','"bc"')
   uWUzXdGwEvPKftOSbNITHkjCVFqJYB =uWUzXdGwEvPKftOSbNITHkjCVFqJYB.replace('player','"player"')
   uWUzXdGwEvPKftOSbNITHkjCVFqJYB ='{'+uWUzXdGwEvPKftOSbNITHkjCVFqJYB+'}'
   uWUzXdGwEvPKftOSbNITHkjCVFqJYB =json.loads(uWUzXdGwEvPKftOSbNITHkjCVFqJYB)
   bc =uWUzXdGwEvPKftOSbNITHkjCVFqJYB['bc']
   uWUzXdGwEvPKftOSbNITHkjCVFqJYQ =uWUzXdGwEvPKftOSbNITHkjCVFqJYB['player']
   uWUzXdGwEvPKftOSbNITHkjCVFqJYR="%s/%s/%s_default/index.min.js"%(uWUzXdGwEvPKftOSbNITHkjCVFqJea.BC_DOMAIN,bc,uWUzXdGwEvPKftOSbNITHkjCVFqJYQ)
  except uWUzXdGwEvPKftOSbNITHkjCVFqJaQ as exception:
   uWUzXdGwEvPKftOSbNITHkjCVFqJaL(exception)
  return uWUzXdGwEvPKftOSbNITHkjCVFqJYR
 def GetPolicyKey(uWUzXdGwEvPKftOSbNITHkjCVFqJea):
  uWUzXdGwEvPKftOSbNITHkjCVFqJYc=policykey=''
  try:
   uWUzXdGwEvPKftOSbNITHkjCVFqJxp=uWUzXdGwEvPKftOSbNITHkjCVFqJea.GetBcPlayerUrl()
   if uWUzXdGwEvPKftOSbNITHkjCVFqJxp=='':return uWUzXdGwEvPKftOSbNITHkjCVFqJYc,uWUzXdGwEvPKftOSbNITHkjCVFqJYM
   uWUzXdGwEvPKftOSbNITHkjCVFqJei=uWUzXdGwEvPKftOSbNITHkjCVFqJea.callRequestCookies('Get',uWUzXdGwEvPKftOSbNITHkjCVFqJxp,payload=uWUzXdGwEvPKftOSbNITHkjCVFqJas,params=uWUzXdGwEvPKftOSbNITHkjCVFqJas,headers=uWUzXdGwEvPKftOSbNITHkjCVFqJas,cookies=uWUzXdGwEvPKftOSbNITHkjCVFqJas)
   uWUzXdGwEvPKftOSbNITHkjCVFqJYn=uWUzXdGwEvPKftOSbNITHkjCVFqJei.text
   uWUzXdGwEvPKftOSbNITHkjCVFqJYL =re.findall('accountId:\s*\"\d{13}\",\s*policyKey:\s*\".[^(){}]{100,300}\"',uWUzXdGwEvPKftOSbNITHkjCVFqJYn)[0]
   uWUzXdGwEvPKftOSbNITHkjCVFqJYL =uWUzXdGwEvPKftOSbNITHkjCVFqJYL.replace('accountId','"accountId"')
   uWUzXdGwEvPKftOSbNITHkjCVFqJYL =uWUzXdGwEvPKftOSbNITHkjCVFqJYL.replace('policyKey','"policyKey"')
   uWUzXdGwEvPKftOSbNITHkjCVFqJYL ='{'+uWUzXdGwEvPKftOSbNITHkjCVFqJYL+'}'
   uWUzXdGwEvPKftOSbNITHkjCVFqJYi=json.loads(uWUzXdGwEvPKftOSbNITHkjCVFqJYL)
   uWUzXdGwEvPKftOSbNITHkjCVFqJYc =uWUzXdGwEvPKftOSbNITHkjCVFqJYi['accountId']
   uWUzXdGwEvPKftOSbNITHkjCVFqJYM =uWUzXdGwEvPKftOSbNITHkjCVFqJYi['policyKey']
  except uWUzXdGwEvPKftOSbNITHkjCVFqJaQ as exception:
   uWUzXdGwEvPKftOSbNITHkjCVFqJaL(exception)
  return uWUzXdGwEvPKftOSbNITHkjCVFqJYc,uWUzXdGwEvPKftOSbNITHkjCVFqJYM
 def GetBroadURL(uWUzXdGwEvPKftOSbNITHkjCVFqJea,uWUzXdGwEvPKftOSbNITHkjCVFqJxl,mediatype,uWUzXdGwEvPKftOSbNITHkjCVFqJpr):
  uWUzXdGwEvPKftOSbNITHkjCVFqJYD=''
  try:
   if mediatype=='live':
    uWUzXdGwEvPKftOSbNITHkjCVFqJxl='ref%3A'+uWUzXdGwEvPKftOSbNITHkjCVFqJxl
   else:
    uWUzXdGwEvPKftOSbNITHkjCVFqJxl=uWUzXdGwEvPKftOSbNITHkjCVFqJea.GetReplay_UrlId(uWUzXdGwEvPKftOSbNITHkjCVFqJxl,uWUzXdGwEvPKftOSbNITHkjCVFqJpr)
    if uWUzXdGwEvPKftOSbNITHkjCVFqJxl=='':return uWUzXdGwEvPKftOSbNITHkjCVFqJYD
   uWUzXdGwEvPKftOSbNITHkjCVFqJxp=uWUzXdGwEvPKftOSbNITHkjCVFqJea.PLAYER_DOMAIN+'/playback/v1/accounts/'+uWUzXdGwEvPKftOSbNITHkjCVFqJea.SPOTV_ACCOUNTID+'/videos/'+uWUzXdGwEvPKftOSbNITHkjCVFqJxl
   uWUzXdGwEvPKftOSbNITHkjCVFqJYh={'accept':'application/json;pk='+uWUzXdGwEvPKftOSbNITHkjCVFqJea.SPOTV_POLICYKEY}
   uWUzXdGwEvPKftOSbNITHkjCVFqJei=uWUzXdGwEvPKftOSbNITHkjCVFqJea.callRequestCookies('Get',uWUzXdGwEvPKftOSbNITHkjCVFqJxp,payload=uWUzXdGwEvPKftOSbNITHkjCVFqJas,params=uWUzXdGwEvPKftOSbNITHkjCVFqJas,headers=uWUzXdGwEvPKftOSbNITHkjCVFqJYh,cookies=uWUzXdGwEvPKftOSbNITHkjCVFqJas)
   uWUzXdGwEvPKftOSbNITHkjCVFqJYo=json.loads(uWUzXdGwEvPKftOSbNITHkjCVFqJei.text)
   uWUzXdGwEvPKftOSbNITHkjCVFqJYD=uWUzXdGwEvPKftOSbNITHkjCVFqJYo['sources'][0]['src']
   if mediatype=='live':
    uWUzXdGwEvPKftOSbNITHkjCVFqJYD=uWUzXdGwEvPKftOSbNITHkjCVFqJYD.replace('playlist.m3u8','playlist_dvr.m3u8')
   uWUzXdGwEvPKftOSbNITHkjCVFqJYD=uWUzXdGwEvPKftOSbNITHkjCVFqJYD.replace('http://','https://')
  except uWUzXdGwEvPKftOSbNITHkjCVFqJaQ as exception:
   uWUzXdGwEvPKftOSbNITHkjCVFqJaL(exception)
  return uWUzXdGwEvPKftOSbNITHkjCVFqJYD
 def GetTitleGroupList(uWUzXdGwEvPKftOSbNITHkjCVFqJea):
  uWUzXdGwEvPKftOSbNITHkjCVFqJxe=[]
  uWUzXdGwEvPKftOSbNITHkjCVFqJYg=uWUzXdGwEvPKftOSbNITHkjCVFqJan
  try:
   uWUzXdGwEvPKftOSbNITHkjCVFqJxp=uWUzXdGwEvPKftOSbNITHkjCVFqJea.API_DOMAIN+'/api/v2/home/web'
   uWUzXdGwEvPKftOSbNITHkjCVFqJei=uWUzXdGwEvPKftOSbNITHkjCVFqJea.callRequestCookies('Get',uWUzXdGwEvPKftOSbNITHkjCVFqJxp,payload=uWUzXdGwEvPKftOSbNITHkjCVFqJas,params=uWUzXdGwEvPKftOSbNITHkjCVFqJas,headers=uWUzXdGwEvPKftOSbNITHkjCVFqJas,cookies=uWUzXdGwEvPKftOSbNITHkjCVFqJas)
   uWUzXdGwEvPKftOSbNITHkjCVFqJeh=json.loads(uWUzXdGwEvPKftOSbNITHkjCVFqJei.text)
   for uWUzXdGwEvPKftOSbNITHkjCVFqJxa in uWUzXdGwEvPKftOSbNITHkjCVFqJeh:
    uWUzXdGwEvPKftOSbNITHkjCVFqJxr={}
    uWUzXdGwEvPKftOSbNITHkjCVFqJxr['mediatype']='episode'
    if uWUzXdGwEvPKftOSbNITHkjCVFqJaR(uWUzXdGwEvPKftOSbNITHkjCVFqJxa['type'])=='3':
     uWUzXdGwEvPKftOSbNITHkjCVFqJYy=''
     for uWUzXdGwEvPKftOSbNITHkjCVFqJYm in uWUzXdGwEvPKftOSbNITHkjCVFqJxa['data']['list']:
      uWUzXdGwEvPKftOSbNITHkjCVFqJYl='[%s] %s vs %s\n<%s>\n\n'%(uWUzXdGwEvPKftOSbNITHkjCVFqJYm['gameDesc']['roundName'],uWUzXdGwEvPKftOSbNITHkjCVFqJYm['gameDesc']['homeNameShort'],uWUzXdGwEvPKftOSbNITHkjCVFqJYm['gameDesc']['awayNameShort'],uWUzXdGwEvPKftOSbNITHkjCVFqJYm['gameDesc']['beginDate'])
      uWUzXdGwEvPKftOSbNITHkjCVFqJYy+=uWUzXdGwEvPKftOSbNITHkjCVFqJYl
     uWUzXdGwEvPKftOSbNITHkjCVFqJxA={'title':uWUzXdGwEvPKftOSbNITHkjCVFqJxa['title'],'logo':uWUzXdGwEvPKftOSbNITHkjCVFqJxa['logo'],'reagueId':uWUzXdGwEvPKftOSbNITHkjCVFqJaR(uWUzXdGwEvPKftOSbNITHkjCVFqJxa['destId']),'subGame':uWUzXdGwEvPKftOSbNITHkjCVFqJYy,'info':uWUzXdGwEvPKftOSbNITHkjCVFqJxr}
     uWUzXdGwEvPKftOSbNITHkjCVFqJxe.append(uWUzXdGwEvPKftOSbNITHkjCVFqJxA)
     if uWUzXdGwEvPKftOSbNITHkjCVFqJaR(uWUzXdGwEvPKftOSbNITHkjCVFqJxa['destId'])=='13':uWUzXdGwEvPKftOSbNITHkjCVFqJYg=uWUzXdGwEvPKftOSbNITHkjCVFqJaB
   if uWUzXdGwEvPKftOSbNITHkjCVFqJYg==uWUzXdGwEvPKftOSbNITHkjCVFqJan:
    uWUzXdGwEvPKftOSbNITHkjCVFqJxr={'mediatype':'episode'}
    uWUzXdGwEvPKftOSbNITHkjCVFqJxA={'title':'UFC','logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200928/a643c7cf1c285fb0b4469c07d4c09c28.png','reagueId':'13','subGame':'','info':uWUzXdGwEvPKftOSbNITHkjCVFqJxr}
    uWUzXdGwEvPKftOSbNITHkjCVFqJxe.append(uWUzXdGwEvPKftOSbNITHkjCVFqJxA)
  except uWUzXdGwEvPKftOSbNITHkjCVFqJaQ as exception:
   uWUzXdGwEvPKftOSbNITHkjCVFqJaL(exception)
  return uWUzXdGwEvPKftOSbNITHkjCVFqJxe
 def GetPopularGroupList(uWUzXdGwEvPKftOSbNITHkjCVFqJea):
  uWUzXdGwEvPKftOSbNITHkjCVFqJxe=[]
  try:
   uWUzXdGwEvPKftOSbNITHkjCVFqJxp=uWUzXdGwEvPKftOSbNITHkjCVFqJea.API_DOMAIN+'/api/v2/home/web'
   uWUzXdGwEvPKftOSbNITHkjCVFqJei=uWUzXdGwEvPKftOSbNITHkjCVFqJea.callRequestCookies('Get',uWUzXdGwEvPKftOSbNITHkjCVFqJxp,payload=uWUzXdGwEvPKftOSbNITHkjCVFqJas,params=uWUzXdGwEvPKftOSbNITHkjCVFqJas,headers=uWUzXdGwEvPKftOSbNITHkjCVFqJas,cookies=uWUzXdGwEvPKftOSbNITHkjCVFqJas)
   uWUzXdGwEvPKftOSbNITHkjCVFqJeh=json.loads(uWUzXdGwEvPKftOSbNITHkjCVFqJei.text)
   for uWUzXdGwEvPKftOSbNITHkjCVFqJxa in uWUzXdGwEvPKftOSbNITHkjCVFqJeh:
    uWUzXdGwEvPKftOSbNITHkjCVFqJxr={}
    uWUzXdGwEvPKftOSbNITHkjCVFqJxr['mediatype']='episode'
    if uWUzXdGwEvPKftOSbNITHkjCVFqJaR(uWUzXdGwEvPKftOSbNITHkjCVFqJxa['type'])=='1' and uWUzXdGwEvPKftOSbNITHkjCVFqJaR(uWUzXdGwEvPKftOSbNITHkjCVFqJxa['destId'])=='4':
     for uWUzXdGwEvPKftOSbNITHkjCVFqJYm in uWUzXdGwEvPKftOSbNITHkjCVFqJxa['data']['list']:
      uWUzXdGwEvPKftOSbNITHkjCVFqJxr={}
      uWUzXdGwEvPKftOSbNITHkjCVFqJxr['mediatype']='video'
      uWUzXdGwEvPKftOSbNITHkjCVFqJpe =uWUzXdGwEvPKftOSbNITHkjCVFqJYm['title']
      uWUzXdGwEvPKftOSbNITHkjCVFqJpx =uWUzXdGwEvPKftOSbNITHkjCVFqJYm['id']
      uWUzXdGwEvPKftOSbNITHkjCVFqJpY =uWUzXdGwEvPKftOSbNITHkjCVFqJYm['vtype']
      uWUzXdGwEvPKftOSbNITHkjCVFqJpa =uWUzXdGwEvPKftOSbNITHkjCVFqJYm['imgUrl']
      uWUzXdGwEvPKftOSbNITHkjCVFqJpr =uWUzXdGwEvPKftOSbNITHkjCVFqJYm['vtypeId']
      uWUzXdGwEvPKftOSbNITHkjCVFqJxr['duration'] =uWUzXdGwEvPKftOSbNITHkjCVFqJai(uWUzXdGwEvPKftOSbNITHkjCVFqJYm['duration']/1000)
      uWUzXdGwEvPKftOSbNITHkjCVFqJxA={'vodTitle':uWUzXdGwEvPKftOSbNITHkjCVFqJpe,'vodId':uWUzXdGwEvPKftOSbNITHkjCVFqJpx,'vodType':uWUzXdGwEvPKftOSbNITHkjCVFqJpY,'thumbnail':uWUzXdGwEvPKftOSbNITHkjCVFqJpa,'info':uWUzXdGwEvPKftOSbNITHkjCVFqJxr,'vtypeId':uWUzXdGwEvPKftOSbNITHkjCVFqJaR(uWUzXdGwEvPKftOSbNITHkjCVFqJpr)}
      uWUzXdGwEvPKftOSbNITHkjCVFqJxe.append(uWUzXdGwEvPKftOSbNITHkjCVFqJxA)
  except uWUzXdGwEvPKftOSbNITHkjCVFqJaQ as exception:
   uWUzXdGwEvPKftOSbNITHkjCVFqJaL(exception)
  return uWUzXdGwEvPKftOSbNITHkjCVFqJxe
 def GetSeasonList(uWUzXdGwEvPKftOSbNITHkjCVFqJea,leagueId):
  uWUzXdGwEvPKftOSbNITHkjCVFqJxe=[]
  uWUzXdGwEvPKftOSbNITHkjCVFqJpA=uWUzXdGwEvPKftOSbNITHkjCVFqJps=''
  try:
   uWUzXdGwEvPKftOSbNITHkjCVFqJxp=uWUzXdGwEvPKftOSbNITHkjCVFqJea.API_DOMAIN+'/api/v2/game/league/'+leagueId
   uWUzXdGwEvPKftOSbNITHkjCVFqJei=uWUzXdGwEvPKftOSbNITHkjCVFqJea.callRequestCookies('Get',uWUzXdGwEvPKftOSbNITHkjCVFqJxp,payload=uWUzXdGwEvPKftOSbNITHkjCVFqJas,params=uWUzXdGwEvPKftOSbNITHkjCVFqJas,headers=uWUzXdGwEvPKftOSbNITHkjCVFqJas,cookies=uWUzXdGwEvPKftOSbNITHkjCVFqJas)
   uWUzXdGwEvPKftOSbNITHkjCVFqJeh=json.loads(uWUzXdGwEvPKftOSbNITHkjCVFqJei.text)
   uWUzXdGwEvPKftOSbNITHkjCVFqJpA=uWUzXdGwEvPKftOSbNITHkjCVFqJeh['name']
   uWUzXdGwEvPKftOSbNITHkjCVFqJps=uWUzXdGwEvPKftOSbNITHkjCVFqJaR(uWUzXdGwEvPKftOSbNITHkjCVFqJeh['gameTypeId'])
  except uWUzXdGwEvPKftOSbNITHkjCVFqJaQ as exception:
   uWUzXdGwEvPKftOSbNITHkjCVFqJaL(exception)
   return uWUzXdGwEvPKftOSbNITHkjCVFqJxe
  if uWUzXdGwEvPKftOSbNITHkjCVFqJps=='2':
   try:
    uWUzXdGwEvPKftOSbNITHkjCVFqJxp=uWUzXdGwEvPKftOSbNITHkjCVFqJea.API_DOMAIN+'/api/v2/year/'+leagueId
    uWUzXdGwEvPKftOSbNITHkjCVFqJei=uWUzXdGwEvPKftOSbNITHkjCVFqJea.callRequestCookies('Get',uWUzXdGwEvPKftOSbNITHkjCVFqJxp,payload=uWUzXdGwEvPKftOSbNITHkjCVFqJas,params=uWUzXdGwEvPKftOSbNITHkjCVFqJas,headers=uWUzXdGwEvPKftOSbNITHkjCVFqJas,cookies=uWUzXdGwEvPKftOSbNITHkjCVFqJas)
    uWUzXdGwEvPKftOSbNITHkjCVFqJeh=json.loads(uWUzXdGwEvPKftOSbNITHkjCVFqJei.text)
    for uWUzXdGwEvPKftOSbNITHkjCVFqJxa in uWUzXdGwEvPKftOSbNITHkjCVFqJeh:
     uWUzXdGwEvPKftOSbNITHkjCVFqJxr={}
     uWUzXdGwEvPKftOSbNITHkjCVFqJxr['mediatype']='episode'
     uWUzXdGwEvPKftOSbNITHkjCVFqJxA={'reagueName':uWUzXdGwEvPKftOSbNITHkjCVFqJpA,'gameTypeId':uWUzXdGwEvPKftOSbNITHkjCVFqJps,'seasonName':uWUzXdGwEvPKftOSbNITHkjCVFqJaR(uWUzXdGwEvPKftOSbNITHkjCVFqJxa),'seasonId':uWUzXdGwEvPKftOSbNITHkjCVFqJaR(uWUzXdGwEvPKftOSbNITHkjCVFqJxa),'info':uWUzXdGwEvPKftOSbNITHkjCVFqJxr}
     uWUzXdGwEvPKftOSbNITHkjCVFqJxe.append(uWUzXdGwEvPKftOSbNITHkjCVFqJxA)
   except uWUzXdGwEvPKftOSbNITHkjCVFqJaQ as exception:
    uWUzXdGwEvPKftOSbNITHkjCVFqJaL(exception)
    return[]
  else:
   try:
    uWUzXdGwEvPKftOSbNITHkjCVFqJxp=uWUzXdGwEvPKftOSbNITHkjCVFqJea.API_DOMAIN+'/api/v2/season/'+leagueId
    uWUzXdGwEvPKftOSbNITHkjCVFqJei=uWUzXdGwEvPKftOSbNITHkjCVFqJea.callRequestCookies('Get',uWUzXdGwEvPKftOSbNITHkjCVFqJxp,payload=uWUzXdGwEvPKftOSbNITHkjCVFqJas,params=uWUzXdGwEvPKftOSbNITHkjCVFqJas,headers=uWUzXdGwEvPKftOSbNITHkjCVFqJas,cookies=uWUzXdGwEvPKftOSbNITHkjCVFqJas)
    uWUzXdGwEvPKftOSbNITHkjCVFqJeh=json.loads(uWUzXdGwEvPKftOSbNITHkjCVFqJei.text)
    for uWUzXdGwEvPKftOSbNITHkjCVFqJxa in uWUzXdGwEvPKftOSbNITHkjCVFqJeh:
     uWUzXdGwEvPKftOSbNITHkjCVFqJxr={}
     uWUzXdGwEvPKftOSbNITHkjCVFqJxr['mediatype']='episode'
     uWUzXdGwEvPKftOSbNITHkjCVFqJxA={'reagueName':uWUzXdGwEvPKftOSbNITHkjCVFqJpA,'gameTypeId':uWUzXdGwEvPKftOSbNITHkjCVFqJps,'seasonName':uWUzXdGwEvPKftOSbNITHkjCVFqJxa['name'],'seasonId':uWUzXdGwEvPKftOSbNITHkjCVFqJaR(uWUzXdGwEvPKftOSbNITHkjCVFqJxa['id']),'info':uWUzXdGwEvPKftOSbNITHkjCVFqJxr}
     uWUzXdGwEvPKftOSbNITHkjCVFqJxe.append(uWUzXdGwEvPKftOSbNITHkjCVFqJxA)
   except uWUzXdGwEvPKftOSbNITHkjCVFqJaQ as exception:
    uWUzXdGwEvPKftOSbNITHkjCVFqJaL(exception)
    return[]
  return uWUzXdGwEvPKftOSbNITHkjCVFqJxe
 def GetGameList(uWUzXdGwEvPKftOSbNITHkjCVFqJea,uWUzXdGwEvPKftOSbNITHkjCVFqJps,leagueId,seasonId,page_int):
  uWUzXdGwEvPKftOSbNITHkjCVFqJxe=[]
  uWUzXdGwEvPKftOSbNITHkjCVFqJpn=uWUzXdGwEvPKftOSbNITHkjCVFqJan
  try:
   uWUzXdGwEvPKftOSbNITHkjCVFqJxp=uWUzXdGwEvPKftOSbNITHkjCVFqJea.API_DOMAIN+'/api/v2/vod/league/detail'
   uWUzXdGwEvPKftOSbNITHkjCVFqJpL={'gameType':uWUzXdGwEvPKftOSbNITHkjCVFqJps,'leagueId':leagueId,'seasonId':seasonId if uWUzXdGwEvPKftOSbNITHkjCVFqJps!='2' else '','teamId':'','roundId':'','year':'' if uWUzXdGwEvPKftOSbNITHkjCVFqJps!='2' else seasonId,'pageNo':uWUzXdGwEvPKftOSbNITHkjCVFqJaR(page_int)}
   uWUzXdGwEvPKftOSbNITHkjCVFqJei=uWUzXdGwEvPKftOSbNITHkjCVFqJea.callRequestCookies('Get',uWUzXdGwEvPKftOSbNITHkjCVFqJxp,payload=uWUzXdGwEvPKftOSbNITHkjCVFqJas,params=uWUzXdGwEvPKftOSbNITHkjCVFqJpL,headers=uWUzXdGwEvPKftOSbNITHkjCVFqJas,cookies=uWUzXdGwEvPKftOSbNITHkjCVFqJas)
   uWUzXdGwEvPKftOSbNITHkjCVFqJeh=json.loads(uWUzXdGwEvPKftOSbNITHkjCVFqJei.text)
   uWUzXdGwEvPKftOSbNITHkjCVFqJxy=uWUzXdGwEvPKftOSbNITHkjCVFqJeh['list']
   for uWUzXdGwEvPKftOSbNITHkjCVFqJpR in uWUzXdGwEvPKftOSbNITHkjCVFqJxy:
    for uWUzXdGwEvPKftOSbNITHkjCVFqJxa in uWUzXdGwEvPKftOSbNITHkjCVFqJpR['list']:
     uWUzXdGwEvPKftOSbNITHkjCVFqJxr={}
     uWUzXdGwEvPKftOSbNITHkjCVFqJxr['mediatype']='video'
     if uWUzXdGwEvPKftOSbNITHkjCVFqJxa['gameDesc']['title']==uWUzXdGwEvPKftOSbNITHkjCVFqJas or uWUzXdGwEvPKftOSbNITHkjCVFqJxa['gameDesc']['title']=='':
      uWUzXdGwEvPKftOSbNITHkjCVFqJxm ='%s vs %s'%(uWUzXdGwEvPKftOSbNITHkjCVFqJxa['gameDesc']['homeNameShort'],uWUzXdGwEvPKftOSbNITHkjCVFqJxa['gameDesc']['awayNameShort'])
     else:
      uWUzXdGwEvPKftOSbNITHkjCVFqJxm =uWUzXdGwEvPKftOSbNITHkjCVFqJxa['gameDesc']['title']
     uWUzXdGwEvPKftOSbNITHkjCVFqJpB =uWUzXdGwEvPKftOSbNITHkjCVFqJxa['gameDesc']['beginDate']
     uWUzXdGwEvPKftOSbNITHkjCVFqJpQ =uWUzXdGwEvPKftOSbNITHkjCVFqJxa['gameDesc']['id']
     uWUzXdGwEvPKftOSbNITHkjCVFqJpc =uWUzXdGwEvPKftOSbNITHkjCVFqJxa['gameDesc']['leagueNameFull']
     uWUzXdGwEvPKftOSbNITHkjCVFqJpi =uWUzXdGwEvPKftOSbNITHkjCVFqJxa['gameDesc']['seasonName']
     uWUzXdGwEvPKftOSbNITHkjCVFqJpM =uWUzXdGwEvPKftOSbNITHkjCVFqJxa['gameDesc']['roundName']
     uWUzXdGwEvPKftOSbNITHkjCVFqJpD =uWUzXdGwEvPKftOSbNITHkjCVFqJxa['gameDesc']['homeName']
     uWUzXdGwEvPKftOSbNITHkjCVFqJph =uWUzXdGwEvPKftOSbNITHkjCVFqJxa['gameDesc']['awayName']
     uWUzXdGwEvPKftOSbNITHkjCVFqJpo =uWUzXdGwEvPKftOSbNITHkjCVFqJxa['gameDesc']['homeScore']
     uWUzXdGwEvPKftOSbNITHkjCVFqJpg =uWUzXdGwEvPKftOSbNITHkjCVFqJxa['gameDesc']['awayScore']
     uWUzXdGwEvPKftOSbNITHkjCVFqJpy ='%s\n - %s (%s)\n - %s\n\nhome : %s (Score %s)\n\naway : %s (Score %s)'%(uWUzXdGwEvPKftOSbNITHkjCVFqJpc,uWUzXdGwEvPKftOSbNITHkjCVFqJpi,uWUzXdGwEvPKftOSbNITHkjCVFqJpM,uWUzXdGwEvPKftOSbNITHkjCVFqJpB,uWUzXdGwEvPKftOSbNITHkjCVFqJpD,uWUzXdGwEvPKftOSbNITHkjCVFqJpo,uWUzXdGwEvPKftOSbNITHkjCVFqJph,uWUzXdGwEvPKftOSbNITHkjCVFqJpg)
     uWUzXdGwEvPKftOSbNITHkjCVFqJxr['plot']=uWUzXdGwEvPKftOSbNITHkjCVFqJpy
     uWUzXdGwEvPKftOSbNITHkjCVFqJpm =uWUzXdGwEvPKftOSbNITHkjCVFqJxa['replayVod']['count']
     uWUzXdGwEvPKftOSbNITHkjCVFqJpl=uWUzXdGwEvPKftOSbNITHkjCVFqJxa['highlightVod']['count']
     uWUzXdGwEvPKftOSbNITHkjCVFqJae =uWUzXdGwEvPKftOSbNITHkjCVFqJxa['vods']['count']
     uWUzXdGwEvPKftOSbNITHkjCVFqJpa='' 
     uWUzXdGwEvPKftOSbNITHkjCVFqJax=uWUzXdGwEvPKftOSbNITHkjCVFqJpm+uWUzXdGwEvPKftOSbNITHkjCVFqJpl+uWUzXdGwEvPKftOSbNITHkjCVFqJae
     if uWUzXdGwEvPKftOSbNITHkjCVFqJax==0:
      if uWUzXdGwEvPKftOSbNITHkjCVFqJps=='2':
       uWUzXdGwEvPKftOSbNITHkjCVFqJxm='----- %s -----'%(uWUzXdGwEvPKftOSbNITHkjCVFqJpi)
       uWUzXdGwEvPKftOSbNITHkjCVFqJpB=''
      else:
       uWUzXdGwEvPKftOSbNITHkjCVFqJxm+=' - 관련영상 없음'
       uWUzXdGwEvPKftOSbNITHkjCVFqJxr['plot']+='\n\n ** 관련영상 없음 **'
     else:
      if uWUzXdGwEvPKftOSbNITHkjCVFqJpm!=0:
       uWUzXdGwEvPKftOSbNITHkjCVFqJpa =uWUzXdGwEvPKftOSbNITHkjCVFqJxa['replayVod']['list'][0]['imgUrl']
      elif uWUzXdGwEvPKftOSbNITHkjCVFqJpl!=0:
       uWUzXdGwEvPKftOSbNITHkjCVFqJpa =uWUzXdGwEvPKftOSbNITHkjCVFqJxa['highlightVod']['list'][0]['imgUrl']
      else:
       uWUzXdGwEvPKftOSbNITHkjCVFqJpa =uWUzXdGwEvPKftOSbNITHkjCVFqJxa['vods']['list'][0]['imgUrl']
     uWUzXdGwEvPKftOSbNITHkjCVFqJxA={'gameTitle':uWUzXdGwEvPKftOSbNITHkjCVFqJxm,'gameId':uWUzXdGwEvPKftOSbNITHkjCVFqJpQ,'beginDate':uWUzXdGwEvPKftOSbNITHkjCVFqJpB[:11],'thumbnail':uWUzXdGwEvPKftOSbNITHkjCVFqJpa,'info':uWUzXdGwEvPKftOSbNITHkjCVFqJxr,'leaguenm':uWUzXdGwEvPKftOSbNITHkjCVFqJpc,'seasonnm':uWUzXdGwEvPKftOSbNITHkjCVFqJpi,'roundnm':uWUzXdGwEvPKftOSbNITHkjCVFqJpM,'totVodCnt':uWUzXdGwEvPKftOSbNITHkjCVFqJax}
     uWUzXdGwEvPKftOSbNITHkjCVFqJxe.append(uWUzXdGwEvPKftOSbNITHkjCVFqJxA)
   if uWUzXdGwEvPKftOSbNITHkjCVFqJps=='2':
    if uWUzXdGwEvPKftOSbNITHkjCVFqJeh['count']>page_int*uWUzXdGwEvPKftOSbNITHkjCVFqJea.GAMELIST_LIMIT:uWUzXdGwEvPKftOSbNITHkjCVFqJpn=uWUzXdGwEvPKftOSbNITHkjCVFqJaB
   else:
    if uWUzXdGwEvPKftOSbNITHkjCVFqJeh['list'][0]['count']>page_int*uWUzXdGwEvPKftOSbNITHkjCVFqJea.GAMELIST_LIMIT:uWUzXdGwEvPKftOSbNITHkjCVFqJpn=uWUzXdGwEvPKftOSbNITHkjCVFqJaB
  except uWUzXdGwEvPKftOSbNITHkjCVFqJaQ as exception:
   uWUzXdGwEvPKftOSbNITHkjCVFqJaL(exception)
  return uWUzXdGwEvPKftOSbNITHkjCVFqJxe,uWUzXdGwEvPKftOSbNITHkjCVFqJpn
 def GetGameVodList(uWUzXdGwEvPKftOSbNITHkjCVFqJea,uWUzXdGwEvPKftOSbNITHkjCVFqJpQ):
  uWUzXdGwEvPKftOSbNITHkjCVFqJxe=[]
  uWUzXdGwEvPKftOSbNITHkjCVFqJaY=''
  try:
   uWUzXdGwEvPKftOSbNITHkjCVFqJxp=uWUzXdGwEvPKftOSbNITHkjCVFqJea.API_DOMAIN+'/api/v2/vod/game'
   uWUzXdGwEvPKftOSbNITHkjCVFqJpL={'gameId':uWUzXdGwEvPKftOSbNITHkjCVFqJpQ,'pageItem':'1000'}
   uWUzXdGwEvPKftOSbNITHkjCVFqJei=uWUzXdGwEvPKftOSbNITHkjCVFqJea.callRequestCookies('Get',uWUzXdGwEvPKftOSbNITHkjCVFqJxp,payload=uWUzXdGwEvPKftOSbNITHkjCVFqJas,params=uWUzXdGwEvPKftOSbNITHkjCVFqJpL,headers=uWUzXdGwEvPKftOSbNITHkjCVFqJas,cookies=uWUzXdGwEvPKftOSbNITHkjCVFqJas)
   uWUzXdGwEvPKftOSbNITHkjCVFqJeh=json.loads(uWUzXdGwEvPKftOSbNITHkjCVFqJei.text)
   uWUzXdGwEvPKftOSbNITHkjCVFqJpR=uWUzXdGwEvPKftOSbNITHkjCVFqJeh['list']
   for uWUzXdGwEvPKftOSbNITHkjCVFqJxa in uWUzXdGwEvPKftOSbNITHkjCVFqJpR:
    uWUzXdGwEvPKftOSbNITHkjCVFqJxr={}
    uWUzXdGwEvPKftOSbNITHkjCVFqJxr['mediatype']='video'
    uWUzXdGwEvPKftOSbNITHkjCVFqJpe =uWUzXdGwEvPKftOSbNITHkjCVFqJxa['title']
    uWUzXdGwEvPKftOSbNITHkjCVFqJpx =uWUzXdGwEvPKftOSbNITHkjCVFqJxa['id']
    uWUzXdGwEvPKftOSbNITHkjCVFqJpY =uWUzXdGwEvPKftOSbNITHkjCVFqJxa['vtype']
    uWUzXdGwEvPKftOSbNITHkjCVFqJpa =uWUzXdGwEvPKftOSbNITHkjCVFqJxa['imgUrl']
    uWUzXdGwEvPKftOSbNITHkjCVFqJpr =uWUzXdGwEvPKftOSbNITHkjCVFqJxa['vtypeId']
    uWUzXdGwEvPKftOSbNITHkjCVFqJxr['duration'] =uWUzXdGwEvPKftOSbNITHkjCVFqJai(uWUzXdGwEvPKftOSbNITHkjCVFqJxa['duration']/1000)
    uWUzXdGwEvPKftOSbNITHkjCVFqJxA={'vodTitle':uWUzXdGwEvPKftOSbNITHkjCVFqJpe,'vodId':uWUzXdGwEvPKftOSbNITHkjCVFqJpx,'vodType':uWUzXdGwEvPKftOSbNITHkjCVFqJpY,'thumbnail':uWUzXdGwEvPKftOSbNITHkjCVFqJpa,'info':uWUzXdGwEvPKftOSbNITHkjCVFqJxr,'vtypeId':uWUzXdGwEvPKftOSbNITHkjCVFqJaR(uWUzXdGwEvPKftOSbNITHkjCVFqJpr)}
    uWUzXdGwEvPKftOSbNITHkjCVFqJxe.append(uWUzXdGwEvPKftOSbNITHkjCVFqJxA)
  except uWUzXdGwEvPKftOSbNITHkjCVFqJaQ as exception:
   uWUzXdGwEvPKftOSbNITHkjCVFqJaL(exception)
  return uWUzXdGwEvPKftOSbNITHkjCVFqJxe
 def GetReplay_UrlId(uWUzXdGwEvPKftOSbNITHkjCVFqJea,uWUzXdGwEvPKftOSbNITHkjCVFqJaY,uWUzXdGwEvPKftOSbNITHkjCVFqJpr):
  uWUzXdGwEvPKftOSbNITHkjCVFqJap=uWUzXdGwEvPKftOSbNITHkjCVFqJxl=''
  uWUzXdGwEvPKftOSbNITHkjCVFqJar=''
  try:
   uWUzXdGwEvPKftOSbNITHkjCVFqJxp=uWUzXdGwEvPKftOSbNITHkjCVFqJea.API_DOMAIN+'/api/v2/vod/'+uWUzXdGwEvPKftOSbNITHkjCVFqJaY
   uWUzXdGwEvPKftOSbNITHkjCVFqJei=uWUzXdGwEvPKftOSbNITHkjCVFqJea.callRequestCookies('Get',uWUzXdGwEvPKftOSbNITHkjCVFqJxp,payload=uWUzXdGwEvPKftOSbNITHkjCVFqJas,params=uWUzXdGwEvPKftOSbNITHkjCVFqJas,headers=uWUzXdGwEvPKftOSbNITHkjCVFqJas,cookies=uWUzXdGwEvPKftOSbNITHkjCVFqJas)
   uWUzXdGwEvPKftOSbNITHkjCVFqJeh=json.loads(uWUzXdGwEvPKftOSbNITHkjCVFqJei.text)
   uWUzXdGwEvPKftOSbNITHkjCVFqJap =uWUzXdGwEvPKftOSbNITHkjCVFqJeh['clipId']
   uWUzXdGwEvPKftOSbNITHkjCVFqJxl=uWUzXdGwEvPKftOSbNITHkjCVFqJeh['videoId']
   uWUzXdGwEvPKftOSbNITHkjCVFqJar=uWUzXdGwEvPKftOSbNITHkjCVFqJap
   if uWUzXdGwEvPKftOSbNITHkjCVFqJea.CheckSubEnd()or uWUzXdGwEvPKftOSbNITHkjCVFqJpr!='1':uWUzXdGwEvPKftOSbNITHkjCVFqJar=uWUzXdGwEvPKftOSbNITHkjCVFqJxl 
  except uWUzXdGwEvPKftOSbNITHkjCVFqJaQ as exception:
   uWUzXdGwEvPKftOSbNITHkjCVFqJaL(exception)
  return uWUzXdGwEvPKftOSbNITHkjCVFqJar
# Created by pyminifier (https://github.com/liftoff/pyminifier)
