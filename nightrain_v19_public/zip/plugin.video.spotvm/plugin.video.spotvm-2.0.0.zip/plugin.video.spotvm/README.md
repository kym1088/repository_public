# spotvM-v19
 스포티비 나우 애드온 for Kodi19

###
* [Korea OTT Package for Kodi 19 (public)-19.0.0.zip](https://github.com/kym1088/repository_public/raw/master/repository.nightrain_v19_public.zip)
* [Korea OTT Package for Kodi 18 (public)-18.0.0.zip](https://github.com/kym1088/repository_public/raw/master/repository.nightrain_v18_public.zip)
###


# 공통
- 본 애드온은 kodi19 버전용만 개발하였습니다.


## Version 2.0.0 (2020.09.16)
- kodi 19 라이브채널 재생
