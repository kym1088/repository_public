__author__="NightRain"
KbYLQSkmIfJUEuAvnxaHCDpBhgijqO=object
KbYLQSkmIfJUEuAvnxaHCDpBhgijqc=None
KbYLQSkmIfJUEuAvnxaHCDpBhgijqz=False
KbYLQSkmIfJUEuAvnxaHCDpBhgijqw=print
KbYLQSkmIfJUEuAvnxaHCDpBhgijqW=str
KbYLQSkmIfJUEuAvnxaHCDpBhgijql=True
KbYLQSkmIfJUEuAvnxaHCDpBhgijqo=Exception
KbYLQSkmIfJUEuAvnxaHCDpBhgijqN=int
import urllib
import http.cookiejar 
import re
import json
import sys
import time
import requests
import datetime
import base64
KbYLQSkmIfJUEuAvnxaHCDpBhgijMq ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36'
KbYLQSkmIfJUEuAvnxaHCDpBhgijMd={'stream50':1080,'stream40':720,'stream30':540}
class KbYLQSkmIfJUEuAvnxaHCDpBhgijMR(KbYLQSkmIfJUEuAvnxaHCDpBhgijqO):
 def __init__(KbYLQSkmIfJUEuAvnxaHCDpBhgijMe):
  KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.SPOTV_SESSIONID=''
  KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.SPOTV_SESSION =''
  KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.SPOTV_ACCOUNTID=''
  KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.SPOTV_POLICYKEY=''
  KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.SPOTV_SUBEND =''
  KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.SPOTV_PMCODE ='987'
  KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.SPOTV_PMSIZE =3
  KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.API_DOMAIN ='https://www.spotvnow.co.kr'
  KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.BC_DOMAIN ='https://players.brightcove.net'
  KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.PLAYER_DOMAIN ='https://edge.api.brightcove.com'
  KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.DEFAULT_HEADER ={'user-agent':KbYLQSkmIfJUEuAvnxaHCDpBhgijMq}
 def callRequestCookies(KbYLQSkmIfJUEuAvnxaHCDpBhgijMe,jobtype,KbYLQSkmIfJUEuAvnxaHCDpBhgijRd,payload=KbYLQSkmIfJUEuAvnxaHCDpBhgijqc,params=KbYLQSkmIfJUEuAvnxaHCDpBhgijqc,headers=KbYLQSkmIfJUEuAvnxaHCDpBhgijqc,cookies=KbYLQSkmIfJUEuAvnxaHCDpBhgijqc,redirects=KbYLQSkmIfJUEuAvnxaHCDpBhgijqz):
  KbYLQSkmIfJUEuAvnxaHCDpBhgijMG=KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.DEFAULT_HEADER
  if headers:KbYLQSkmIfJUEuAvnxaHCDpBhgijMG.update(headers)
  if jobtype=='Get':
   KbYLQSkmIfJUEuAvnxaHCDpBhgijMV=requests.get(KbYLQSkmIfJUEuAvnxaHCDpBhgijRd,params=params,headers=KbYLQSkmIfJUEuAvnxaHCDpBhgijMG,cookies=cookies,allow_redirects=redirects)
  else:
   KbYLQSkmIfJUEuAvnxaHCDpBhgijMV=requests.post(KbYLQSkmIfJUEuAvnxaHCDpBhgijRd,data=payload,params=params,headers=KbYLQSkmIfJUEuAvnxaHCDpBhgijMG,cookies=cookies,allow_redirects=redirects)
  return KbYLQSkmIfJUEuAvnxaHCDpBhgijMV
 def makeDefaultCookies(KbYLQSkmIfJUEuAvnxaHCDpBhgijMe):
  KbYLQSkmIfJUEuAvnxaHCDpBhgijMT={'SESSION':KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.SPOTV_SESSION}
  return KbYLQSkmIfJUEuAvnxaHCDpBhgijMT
 def GetCredential(KbYLQSkmIfJUEuAvnxaHCDpBhgijMe,user_id,user_pw):
  KbYLQSkmIfJUEuAvnxaHCDpBhgijMr=KbYLQSkmIfJUEuAvnxaHCDpBhgijqz
  KbYLQSkmIfJUEuAvnxaHCDpBhgijMO=KbYLQSkmIfJUEuAvnxaHCDpBhgijMN=KbYLQSkmIfJUEuAvnxaHCDpBhgijMt=KbYLQSkmIfJUEuAvnxaHCDpBhgijMP=KbYLQSkmIfJUEuAvnxaHCDpBhgijMF=''
  try:
   KbYLQSkmIfJUEuAvnxaHCDpBhgijMc=base64.standard_b64encode(user_id.encode("UTF-8")).decode('utf-8')
   KbYLQSkmIfJUEuAvnxaHCDpBhgijMz=base64.standard_b64encode(user_pw.encode("UTF-8")).decode('utf-8')
   KbYLQSkmIfJUEuAvnxaHCDpBhgijMw=KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.API_DOMAIN+'/api/v2/login'
   KbYLQSkmIfJUEuAvnxaHCDpBhgijMW={'username':KbYLQSkmIfJUEuAvnxaHCDpBhgijMc,'password':KbYLQSkmIfJUEuAvnxaHCDpBhgijMz}
   KbYLQSkmIfJUEuAvnxaHCDpBhgijMW=json.dumps(KbYLQSkmIfJUEuAvnxaHCDpBhgijMW)
   KbYLQSkmIfJUEuAvnxaHCDpBhgijMl=KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.callRequestCookies('Post',KbYLQSkmIfJUEuAvnxaHCDpBhgijMw,payload=KbYLQSkmIfJUEuAvnxaHCDpBhgijMW,params=KbYLQSkmIfJUEuAvnxaHCDpBhgijqc,headers=KbYLQSkmIfJUEuAvnxaHCDpBhgijqc,cookies=KbYLQSkmIfJUEuAvnxaHCDpBhgijqc)
   KbYLQSkmIfJUEuAvnxaHCDpBhgijqw(KbYLQSkmIfJUEuAvnxaHCDpBhgijMl.status_code)
   for KbYLQSkmIfJUEuAvnxaHCDpBhgijMo in KbYLQSkmIfJUEuAvnxaHCDpBhgijMl.cookies:
    if KbYLQSkmIfJUEuAvnxaHCDpBhgijMo.name=='SESSION':
     KbYLQSkmIfJUEuAvnxaHCDpBhgijMN=KbYLQSkmIfJUEuAvnxaHCDpBhgijMo.value
     break
   if KbYLQSkmIfJUEuAvnxaHCDpBhgijMN=='':return KbYLQSkmIfJUEuAvnxaHCDpBhgijMr
   KbYLQSkmIfJUEuAvnxaHCDpBhgijMs=json.loads(KbYLQSkmIfJUEuAvnxaHCDpBhgijMl.text)
   if not('userId' in KbYLQSkmIfJUEuAvnxaHCDpBhgijMs):return KbYLQSkmIfJUEuAvnxaHCDpBhgijMr
   KbYLQSkmIfJUEuAvnxaHCDpBhgijMO=KbYLQSkmIfJUEuAvnxaHCDpBhgijqW(KbYLQSkmIfJUEuAvnxaHCDpBhgijMs['userId'])
   KbYLQSkmIfJUEuAvnxaHCDpBhgijMF =KbYLQSkmIfJUEuAvnxaHCDpBhgijqW(KbYLQSkmIfJUEuAvnxaHCDpBhgijMs['subEndTime'])
   KbYLQSkmIfJUEuAvnxaHCDpBhgijMt,KbYLQSkmIfJUEuAvnxaHCDpBhgijMP=KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.GetPolicyKey()
   if KbYLQSkmIfJUEuAvnxaHCDpBhgijMP=='':return KbYLQSkmIfJUEuAvnxaHCDpBhgijMr
   KbYLQSkmIfJUEuAvnxaHCDpBhgijMr=KbYLQSkmIfJUEuAvnxaHCDpBhgijql
  except KbYLQSkmIfJUEuAvnxaHCDpBhgijqo as exception:
   KbYLQSkmIfJUEuAvnxaHCDpBhgijMO=KbYLQSkmIfJUEuAvnxaHCDpBhgijMN='' 
   KbYLQSkmIfJUEuAvnxaHCDpBhgijqw(exception)
  KbYLQSkmIfJUEuAvnxaHCDpBhgijMy={'spotv_sessionid':KbYLQSkmIfJUEuAvnxaHCDpBhgijMO,'spotv_session':KbYLQSkmIfJUEuAvnxaHCDpBhgijMN,'spotv_accountId':KbYLQSkmIfJUEuAvnxaHCDpBhgijMt,'spotv_policyKey':KbYLQSkmIfJUEuAvnxaHCDpBhgijMP,'spotv_subend':KbYLQSkmIfJUEuAvnxaHCDpBhgijMF}
  KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.SaveCredential(KbYLQSkmIfJUEuAvnxaHCDpBhgijMy)
  return KbYLQSkmIfJUEuAvnxaHCDpBhgijMr
 def SaveCredential(KbYLQSkmIfJUEuAvnxaHCDpBhgijMe,KbYLQSkmIfJUEuAvnxaHCDpBhgijMy):
  KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.SPOTV_SESSIONID=KbYLQSkmIfJUEuAvnxaHCDpBhgijMy.get('spotv_sessionid')
  KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.SPOTV_SESSION =KbYLQSkmIfJUEuAvnxaHCDpBhgijMy.get('spotv_session')
  KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.SPOTV_ACCOUNTID=KbYLQSkmIfJUEuAvnxaHCDpBhgijMy.get('spotv_accountId')
  KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.SPOTV_POLICYKEY=KbYLQSkmIfJUEuAvnxaHCDpBhgijMy.get('spotv_policyKey')
  KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.SPOTV_SUBEND =KbYLQSkmIfJUEuAvnxaHCDpBhgijMy.get('spotv_subend')
 def LoadCredential(KbYLQSkmIfJUEuAvnxaHCDpBhgijMe):
  KbYLQSkmIfJUEuAvnxaHCDpBhgijMy={'spotv_sessionid':KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.SPOTV_SESSIONID,'spotv_session':KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.SPOTV_SESSION,'spotv_accountId':KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.SPOTV_ACCOUNTID,'spotv_policyKey':KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.SPOTV_POLICYKEY,'spotv_subend':KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.SPOTV_SUBEND}
  return KbYLQSkmIfJUEuAvnxaHCDpBhgijMy
 def Get_Now_Datetime(KbYLQSkmIfJUEuAvnxaHCDpBhgijMe):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetLiveChannelList(KbYLQSkmIfJUEuAvnxaHCDpBhgijMe):
  KbYLQSkmIfJUEuAvnxaHCDpBhgijRM=[]
  KbYLQSkmIfJUEuAvnxaHCDpBhgijRq ={}
  try:
   KbYLQSkmIfJUEuAvnxaHCDpBhgijRd=KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.API_DOMAIN+'/api/v2/channel'
   KbYLQSkmIfJUEuAvnxaHCDpBhgijMT=KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.makeDefaultCookies()
   KbYLQSkmIfJUEuAvnxaHCDpBhgijMl=KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.callRequestCookies('Get',KbYLQSkmIfJUEuAvnxaHCDpBhgijRd,payload=KbYLQSkmIfJUEuAvnxaHCDpBhgijqc,params=KbYLQSkmIfJUEuAvnxaHCDpBhgijqc,headers=KbYLQSkmIfJUEuAvnxaHCDpBhgijqc,cookies=KbYLQSkmIfJUEuAvnxaHCDpBhgijMT)
   KbYLQSkmIfJUEuAvnxaHCDpBhgijMs=json.loads(KbYLQSkmIfJUEuAvnxaHCDpBhgijMl.text)
   KbYLQSkmIfJUEuAvnxaHCDpBhgijRq=KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.GetEPGList()
   for KbYLQSkmIfJUEuAvnxaHCDpBhgijRe in KbYLQSkmIfJUEuAvnxaHCDpBhgijMs:
    KbYLQSkmIfJUEuAvnxaHCDpBhgijRG={}
    KbYLQSkmIfJUEuAvnxaHCDpBhgijRG['mediatype']='video'
    KbYLQSkmIfJUEuAvnxaHCDpBhgijRG['title'] =KbYLQSkmIfJUEuAvnxaHCDpBhgijRe['programName']
    KbYLQSkmIfJUEuAvnxaHCDpBhgijRG['studio'] =KbYLQSkmIfJUEuAvnxaHCDpBhgijRe['name']
    KbYLQSkmIfJUEuAvnxaHCDpBhgijRV={'id':KbYLQSkmIfJUEuAvnxaHCDpBhgijRe['id'],'name':KbYLQSkmIfJUEuAvnxaHCDpBhgijRe['name'],'logo':KbYLQSkmIfJUEuAvnxaHCDpBhgijRe['logo'],'videoId':KbYLQSkmIfJUEuAvnxaHCDpBhgijRe['videoId'].replace('ref:',''),'free':KbYLQSkmIfJUEuAvnxaHCDpBhgijRe['free'],'programName':KbYLQSkmIfJUEuAvnxaHCDpBhgijRe['programName'],'channelepg':KbYLQSkmIfJUEuAvnxaHCDpBhgijRq.get(KbYLQSkmIfJUEuAvnxaHCDpBhgijRe['id']),'info':KbYLQSkmIfJUEuAvnxaHCDpBhgijRG}
    KbYLQSkmIfJUEuAvnxaHCDpBhgijRM.append(KbYLQSkmIfJUEuAvnxaHCDpBhgijRV)
  except KbYLQSkmIfJUEuAvnxaHCDpBhgijqo as exception:
   KbYLQSkmIfJUEuAvnxaHCDpBhgijqw(exception)
  return KbYLQSkmIfJUEuAvnxaHCDpBhgijRM
 def GetEPGList(KbYLQSkmIfJUEuAvnxaHCDpBhgijMe):
  KbYLQSkmIfJUEuAvnxaHCDpBhgijRT={}
  KbYLQSkmIfJUEuAvnxaHCDpBhgijRr=KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.Get_Now_Datetime()
  KbYLQSkmIfJUEuAvnxaHCDpBhgijRO=KbYLQSkmIfJUEuAvnxaHCDpBhgijRr.strftime('%Y%m%d%H%M')
  KbYLQSkmIfJUEuAvnxaHCDpBhgijRc='%s-%s-%s'%(KbYLQSkmIfJUEuAvnxaHCDpBhgijRO[0:4],KbYLQSkmIfJUEuAvnxaHCDpBhgijRO[4:6],KbYLQSkmIfJUEuAvnxaHCDpBhgijRO[6:8])
  KbYLQSkmIfJUEuAvnxaHCDpBhgijRz=(KbYLQSkmIfJUEuAvnxaHCDpBhgijRr+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M')
  try:
   KbYLQSkmIfJUEuAvnxaHCDpBhgijRd=KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.API_DOMAIN+'/api/v2/program/'+KbYLQSkmIfJUEuAvnxaHCDpBhgijRc
   KbYLQSkmIfJUEuAvnxaHCDpBhgijMT=KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.makeDefaultCookies()
   KbYLQSkmIfJUEuAvnxaHCDpBhgijMl=KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.callRequestCookies('Get',KbYLQSkmIfJUEuAvnxaHCDpBhgijRd,payload=KbYLQSkmIfJUEuAvnxaHCDpBhgijqc,params=KbYLQSkmIfJUEuAvnxaHCDpBhgijqc,headers=KbYLQSkmIfJUEuAvnxaHCDpBhgijqc,cookies=KbYLQSkmIfJUEuAvnxaHCDpBhgijMT)
   KbYLQSkmIfJUEuAvnxaHCDpBhgijMs=json.loads(KbYLQSkmIfJUEuAvnxaHCDpBhgijMl.text)
   KbYLQSkmIfJUEuAvnxaHCDpBhgijRw=-1 
   KbYLQSkmIfJUEuAvnxaHCDpBhgijRW =''
   for KbYLQSkmIfJUEuAvnxaHCDpBhgijRe in KbYLQSkmIfJUEuAvnxaHCDpBhgijMs:
    KbYLQSkmIfJUEuAvnxaHCDpBhgijRl=KbYLQSkmIfJUEuAvnxaHCDpBhgijRe['channelId']
    KbYLQSkmIfJUEuAvnxaHCDpBhgijRo =KbYLQSkmIfJUEuAvnxaHCDpBhgijRe['startTime'].replace('-','').replace(' ','').replace(':','')
    KbYLQSkmIfJUEuAvnxaHCDpBhgijRN =KbYLQSkmIfJUEuAvnxaHCDpBhgijRe['endTime'].replace('-','').replace(' ','').replace(':','')
    if KbYLQSkmIfJUEuAvnxaHCDpBhgijqN(KbYLQSkmIfJUEuAvnxaHCDpBhgijRO)>KbYLQSkmIfJUEuAvnxaHCDpBhgijqN(KbYLQSkmIfJUEuAvnxaHCDpBhgijRN) :continue
    if KbYLQSkmIfJUEuAvnxaHCDpBhgijqN(KbYLQSkmIfJUEuAvnxaHCDpBhgijRz)<KbYLQSkmIfJUEuAvnxaHCDpBhgijqN(KbYLQSkmIfJUEuAvnxaHCDpBhgijRo):continue
    if KbYLQSkmIfJUEuAvnxaHCDpBhgijRw!=KbYLQSkmIfJUEuAvnxaHCDpBhgijRl:
     if KbYLQSkmIfJUEuAvnxaHCDpBhgijRW!='':KbYLQSkmIfJUEuAvnxaHCDpBhgijRT[KbYLQSkmIfJUEuAvnxaHCDpBhgijRw]=KbYLQSkmIfJUEuAvnxaHCDpBhgijRW
     KbYLQSkmIfJUEuAvnxaHCDpBhgijRw=KbYLQSkmIfJUEuAvnxaHCDpBhgijRl
     KbYLQSkmIfJUEuAvnxaHCDpBhgijRW =''
    if KbYLQSkmIfJUEuAvnxaHCDpBhgijRW:KbYLQSkmIfJUEuAvnxaHCDpBhgijRW+='\n'
    KbYLQSkmIfJUEuAvnxaHCDpBhgijRW+=KbYLQSkmIfJUEuAvnxaHCDpBhgijRe['title']+'\n'
    KbYLQSkmIfJUEuAvnxaHCDpBhgijRW+=' [%s ~ %s]'%(KbYLQSkmIfJUEuAvnxaHCDpBhgijRe['startTime'][-5:],KbYLQSkmIfJUEuAvnxaHCDpBhgijRe['endTime'][-5:])+'\n'
   if KbYLQSkmIfJUEuAvnxaHCDpBhgijRW:KbYLQSkmIfJUEuAvnxaHCDpBhgijRT[KbYLQSkmIfJUEuAvnxaHCDpBhgijRw]=KbYLQSkmIfJUEuAvnxaHCDpBhgijRW
  except KbYLQSkmIfJUEuAvnxaHCDpBhgijqo as exception:
   KbYLQSkmIfJUEuAvnxaHCDpBhgijqw(exception)
  return KbYLQSkmIfJUEuAvnxaHCDpBhgijRT
 def CheckMainEnd(KbYLQSkmIfJUEuAvnxaHCDpBhgijMe):
  KbYLQSkmIfJUEuAvnxaHCDpBhgijRs=base64.standard_b64encode((KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.SPOTV_PMCODE+KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.SPOTV_SESSIONID).encode()).decode('utf-8')
  if KbYLQSkmIfJUEuAvnxaHCDpBhgijRs=='OTg3MTgzMzM0Ng==' or KbYLQSkmIfJUEuAvnxaHCDpBhgijRs=='OTg3MTgzMzExNw==':return KbYLQSkmIfJUEuAvnxaHCDpBhgijql
  return KbYLQSkmIfJUEuAvnxaHCDpBhgijqz
 def CheckSubEnd(KbYLQSkmIfJUEuAvnxaHCDpBhgijMe):
  KbYLQSkmIfJUEuAvnxaHCDpBhgijRF=KbYLQSkmIfJUEuAvnxaHCDpBhgijqz
  try:
   if KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.CheckMainEnd():return KbYLQSkmIfJUEuAvnxaHCDpBhgijql 
   if KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.SPOTV_SUBEND=='0':return KbYLQSkmIfJUEuAvnxaHCDpBhgijRF
  except:
   return KbYLQSkmIfJUEuAvnxaHCDpBhgijRF
  return KbYLQSkmIfJUEuAvnxaHCDpBhgijRF
 def GetMainJspath(KbYLQSkmIfJUEuAvnxaHCDpBhgijMe):
  KbYLQSkmIfJUEuAvnxaHCDpBhgijRt=''
  try:
   KbYLQSkmIfJUEuAvnxaHCDpBhgijRd=KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.API_DOMAIN
   KbYLQSkmIfJUEuAvnxaHCDpBhgijMl=KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.callRequestCookies('Get',KbYLQSkmIfJUEuAvnxaHCDpBhgijRd,payload=KbYLQSkmIfJUEuAvnxaHCDpBhgijqc,params=KbYLQSkmIfJUEuAvnxaHCDpBhgijqc,headers=KbYLQSkmIfJUEuAvnxaHCDpBhgijqc,cookies=KbYLQSkmIfJUEuAvnxaHCDpBhgijqc)
   KbYLQSkmIfJUEuAvnxaHCDpBhgijRP=KbYLQSkmIfJUEuAvnxaHCDpBhgijMl.text
   KbYLQSkmIfJUEuAvnxaHCDpBhgijRy =re.findall('https://cdn.spotvnow.co.kr/dist/js/.{20}\.js',KbYLQSkmIfJUEuAvnxaHCDpBhgijRP)[0]
   KbYLQSkmIfJUEuAvnxaHCDpBhgijRt=KbYLQSkmIfJUEuAvnxaHCDpBhgijRy
  except KbYLQSkmIfJUEuAvnxaHCDpBhgijqo as exception:
   KbYLQSkmIfJUEuAvnxaHCDpBhgijqw(exception)
  return KbYLQSkmIfJUEuAvnxaHCDpBhgijRt
 def GetBcPlayerUrl(KbYLQSkmIfJUEuAvnxaHCDpBhgijMe):
  KbYLQSkmIfJUEuAvnxaHCDpBhgijRX=''
  try:
   KbYLQSkmIfJUEuAvnxaHCDpBhgijRd=KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.GetMainJspath()
   if KbYLQSkmIfJUEuAvnxaHCDpBhgijRd=='':return KbYLQSkmIfJUEuAvnxaHCDpBhgijRX
   KbYLQSkmIfJUEuAvnxaHCDpBhgijMl=KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.callRequestCookies('Get',KbYLQSkmIfJUEuAvnxaHCDpBhgijRd,payload=KbYLQSkmIfJUEuAvnxaHCDpBhgijqc,params=KbYLQSkmIfJUEuAvnxaHCDpBhgijqc,headers=KbYLQSkmIfJUEuAvnxaHCDpBhgijqc,cookies=KbYLQSkmIfJUEuAvnxaHCDpBhgijqc)
   KbYLQSkmIfJUEuAvnxaHCDpBhgijRP=KbYLQSkmIfJUEuAvnxaHCDpBhgijMl.text
   KbYLQSkmIfJUEuAvnxaHCDpBhgijqM =re.findall('bc:\s*\"\d{13}\",\s*player:\s*\".{9}\"',KbYLQSkmIfJUEuAvnxaHCDpBhgijRP)[0]
   KbYLQSkmIfJUEuAvnxaHCDpBhgijqM =KbYLQSkmIfJUEuAvnxaHCDpBhgijqM.replace('bc','"bc"')
   KbYLQSkmIfJUEuAvnxaHCDpBhgijqM =KbYLQSkmIfJUEuAvnxaHCDpBhgijqM.replace('player','"player"')
   KbYLQSkmIfJUEuAvnxaHCDpBhgijqM ='{'+KbYLQSkmIfJUEuAvnxaHCDpBhgijqM+'}'
   KbYLQSkmIfJUEuAvnxaHCDpBhgijqM =json.loads(KbYLQSkmIfJUEuAvnxaHCDpBhgijqM)
   bc =KbYLQSkmIfJUEuAvnxaHCDpBhgijqM['bc']
   KbYLQSkmIfJUEuAvnxaHCDpBhgijqR =KbYLQSkmIfJUEuAvnxaHCDpBhgijqM['player']
   KbYLQSkmIfJUEuAvnxaHCDpBhgijRX="%s/%s/%s_default/index.min.js"%(KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.BC_DOMAIN,bc,KbYLQSkmIfJUEuAvnxaHCDpBhgijqR)
  except KbYLQSkmIfJUEuAvnxaHCDpBhgijqo as exception:
   KbYLQSkmIfJUEuAvnxaHCDpBhgijqw(exception)
  return KbYLQSkmIfJUEuAvnxaHCDpBhgijRX
 def GetPolicyKey(KbYLQSkmIfJUEuAvnxaHCDpBhgijMe):
  KbYLQSkmIfJUEuAvnxaHCDpBhgijqd=policykey=''
  try:
   KbYLQSkmIfJUEuAvnxaHCDpBhgijRd=KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.GetBcPlayerUrl()
   if KbYLQSkmIfJUEuAvnxaHCDpBhgijRd=='':return KbYLQSkmIfJUEuAvnxaHCDpBhgijqd,KbYLQSkmIfJUEuAvnxaHCDpBhgijqG
   KbYLQSkmIfJUEuAvnxaHCDpBhgijMl=KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.callRequestCookies('Get',KbYLQSkmIfJUEuAvnxaHCDpBhgijRd,payload=KbYLQSkmIfJUEuAvnxaHCDpBhgijqc,params=KbYLQSkmIfJUEuAvnxaHCDpBhgijqc,headers=KbYLQSkmIfJUEuAvnxaHCDpBhgijqc,cookies=KbYLQSkmIfJUEuAvnxaHCDpBhgijqc)
   KbYLQSkmIfJUEuAvnxaHCDpBhgijRP=KbYLQSkmIfJUEuAvnxaHCDpBhgijMl.text
   KbYLQSkmIfJUEuAvnxaHCDpBhgijRy =re.findall('accountId:\s*\"\d{13}\",\s*policyKey:\s*\".[^(){}]{100,300}\"',KbYLQSkmIfJUEuAvnxaHCDpBhgijRP)[0]
   KbYLQSkmIfJUEuAvnxaHCDpBhgijRy =KbYLQSkmIfJUEuAvnxaHCDpBhgijRy.replace('accountId','"accountId"')
   KbYLQSkmIfJUEuAvnxaHCDpBhgijRy =KbYLQSkmIfJUEuAvnxaHCDpBhgijRy.replace('policyKey','"policyKey"')
   KbYLQSkmIfJUEuAvnxaHCDpBhgijRy ='{'+KbYLQSkmIfJUEuAvnxaHCDpBhgijRy+'}'
   KbYLQSkmIfJUEuAvnxaHCDpBhgijqe=json.loads(KbYLQSkmIfJUEuAvnxaHCDpBhgijRy)
   KbYLQSkmIfJUEuAvnxaHCDpBhgijqd =KbYLQSkmIfJUEuAvnxaHCDpBhgijqe['accountId']
   KbYLQSkmIfJUEuAvnxaHCDpBhgijqG =KbYLQSkmIfJUEuAvnxaHCDpBhgijqe['policyKey']
  except KbYLQSkmIfJUEuAvnxaHCDpBhgijqo as exception:
   KbYLQSkmIfJUEuAvnxaHCDpBhgijqw(exception)
  return KbYLQSkmIfJUEuAvnxaHCDpBhgijqd,KbYLQSkmIfJUEuAvnxaHCDpBhgijqG
 def GetBroadURL(KbYLQSkmIfJUEuAvnxaHCDpBhgijMe,videoId):
  KbYLQSkmIfJUEuAvnxaHCDpBhgijqV=''
  try:
   KbYLQSkmIfJUEuAvnxaHCDpBhgijRd=KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.PLAYER_DOMAIN+'/playback/v1/accounts/'+KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.SPOTV_ACCOUNTID+'/videos/ref%3A'+videoId
   KbYLQSkmIfJUEuAvnxaHCDpBhgijqT={'accept':'application/json;pk='+KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.SPOTV_POLICYKEY}
   KbYLQSkmIfJUEuAvnxaHCDpBhgijMl=KbYLQSkmIfJUEuAvnxaHCDpBhgijMe.callRequestCookies('Get',KbYLQSkmIfJUEuAvnxaHCDpBhgijRd,payload=KbYLQSkmIfJUEuAvnxaHCDpBhgijqc,params=KbYLQSkmIfJUEuAvnxaHCDpBhgijqc,headers=KbYLQSkmIfJUEuAvnxaHCDpBhgijqT,cookies=KbYLQSkmIfJUEuAvnxaHCDpBhgijqc)
   KbYLQSkmIfJUEuAvnxaHCDpBhgijqr=json.loads(KbYLQSkmIfJUEuAvnxaHCDpBhgijMl.text)
   KbYLQSkmIfJUEuAvnxaHCDpBhgijqV=KbYLQSkmIfJUEuAvnxaHCDpBhgijqr['sources'][0]['src']
   KbYLQSkmIfJUEuAvnxaHCDpBhgijqV=KbYLQSkmIfJUEuAvnxaHCDpBhgijqV.replace('playlist.m3u8','playlist_dvr.m3u8')
  except KbYLQSkmIfJUEuAvnxaHCDpBhgijqo as exception:
   KbYLQSkmIfJUEuAvnxaHCDpBhgijqw(exception)
  return KbYLQSkmIfJUEuAvnxaHCDpBhgijqV
# Created by pyminifier (https://github.com/liftoff/pyminifier)
