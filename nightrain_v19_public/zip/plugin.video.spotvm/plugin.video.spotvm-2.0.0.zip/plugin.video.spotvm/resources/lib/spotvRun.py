__author__="NightRain"
VqYjxiHQNGLCnceUDPgrJalvRuWEys=object
VqYjxiHQNGLCnceUDPgrJalvRuWEyB=None
VqYjxiHQNGLCnceUDPgrJalvRuWEyt=False
VqYjxiHQNGLCnceUDPgrJalvRuWEyz=True
VqYjxiHQNGLCnceUDPgrJalvRuWEyT=int
VqYjxiHQNGLCnceUDPgrJalvRuWEyF=len
VqYjxiHQNGLCnceUDPgrJalvRuWEyp=open
VqYjxiHQNGLCnceUDPgrJalvRuWEyb=Exception
VqYjxiHQNGLCnceUDPgrJalvRuWEyA=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmc.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
VqYjxiHQNGLCnceUDPgrJalvRuWEKy=[{'title':'LIVE 채널','mode':'CHANNEL'}]
VqYjxiHQNGLCnceUDPgrJalvRuWEKk ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36'
VqYjxiHQNGLCnceUDPgrJalvRuWEKS=xbmc.translatePath(os.path.join(__profile__,'spotv_cookies.json'))
from spotvCore import*
class VqYjxiHQNGLCnceUDPgrJalvRuWEKf(VqYjxiHQNGLCnceUDPgrJalvRuWEys):
 def __init__(VqYjxiHQNGLCnceUDPgrJalvRuWEKX,VqYjxiHQNGLCnceUDPgrJalvRuWEKs,VqYjxiHQNGLCnceUDPgrJalvRuWEKB,VqYjxiHQNGLCnceUDPgrJalvRuWEKt):
  VqYjxiHQNGLCnceUDPgrJalvRuWEKX._addon_url =VqYjxiHQNGLCnceUDPgrJalvRuWEKs
  VqYjxiHQNGLCnceUDPgrJalvRuWEKX._addon_handle=VqYjxiHQNGLCnceUDPgrJalvRuWEKB
  VqYjxiHQNGLCnceUDPgrJalvRuWEKX.main_params =VqYjxiHQNGLCnceUDPgrJalvRuWEKt
  VqYjxiHQNGLCnceUDPgrJalvRuWEKX.SpotvObj =KbYLQSkmIfJUEuAvnxaHCDpBhgijMR() 
 def addon_noti(VqYjxiHQNGLCnceUDPgrJalvRuWEKX,sting):
  try:
   VqYjxiHQNGLCnceUDPgrJalvRuWEKT=xbmcgui.Dialog()
   VqYjxiHQNGLCnceUDPgrJalvRuWEKT.notification(__addonname__,sting)
  except:
   VqYjxiHQNGLCnceUDPgrJalvRuWEyB
 def addon_log(VqYjxiHQNGLCnceUDPgrJalvRuWEKX,string,isDebug=VqYjxiHQNGLCnceUDPgrJalvRuWEyt):
  try:
   VqYjxiHQNGLCnceUDPgrJalvRuWEKF=string.encode('utf-8','ignore')
  except:
   VqYjxiHQNGLCnceUDPgrJalvRuWEKF='addonException: addon_log'
  if isDebug:VqYjxiHQNGLCnceUDPgrJalvRuWEKp=xbmc.LOGDEBUG
  else:VqYjxiHQNGLCnceUDPgrJalvRuWEKp=xbmc.LOGNOTICE
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,VqYjxiHQNGLCnceUDPgrJalvRuWEKF),level=VqYjxiHQNGLCnceUDPgrJalvRuWEKp)
 def get_keyboard_input(VqYjxiHQNGLCnceUDPgrJalvRuWEKX,VqYjxiHQNGLCnceUDPgrJalvRuWEKI):
  VqYjxiHQNGLCnceUDPgrJalvRuWEKb=VqYjxiHQNGLCnceUDPgrJalvRuWEyB
  kb=xbmc.Keyboard()
  kb.setHeading(VqYjxiHQNGLCnceUDPgrJalvRuWEKI)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   VqYjxiHQNGLCnceUDPgrJalvRuWEKb=kb.getText()
  return VqYjxiHQNGLCnceUDPgrJalvRuWEKb
 def get_settings_login_info(VqYjxiHQNGLCnceUDPgrJalvRuWEKX):
  VqYjxiHQNGLCnceUDPgrJalvRuWEKA =__addon__.getSetting('id')
  VqYjxiHQNGLCnceUDPgrJalvRuWEKw =__addon__.getSetting('pw')
  return(VqYjxiHQNGLCnceUDPgrJalvRuWEKA,VqYjxiHQNGLCnceUDPgrJalvRuWEKw)
 def set_winCredential(VqYjxiHQNGLCnceUDPgrJalvRuWEKX,credential):
  VqYjxiHQNGLCnceUDPgrJalvRuWEKo=xbmcgui.Window(10000)
  VqYjxiHQNGLCnceUDPgrJalvRuWEKo.setProperty('SPOTV_M_SESSIONID',credential.get('spotv_sessionid'))
  VqYjxiHQNGLCnceUDPgrJalvRuWEKo.setProperty('SPOTV_M_SESSION',credential.get('spotv_session'))
  VqYjxiHQNGLCnceUDPgrJalvRuWEKo.setProperty('SPOTV_M_ACCOUNTID',credential.get('spotv_accountId'))
  VqYjxiHQNGLCnceUDPgrJalvRuWEKo.setProperty('SPOTV_M_POLICYKEY',credential.get('spotv_policyKey'))
  VqYjxiHQNGLCnceUDPgrJalvRuWEKo.setProperty('SPOTV_M_SUBEND',credential.get('spotv_subend'))
  VqYjxiHQNGLCnceUDPgrJalvRuWEKo.setProperty('SPOTV_M_LOGINTIME',VqYjxiHQNGLCnceUDPgrJalvRuWEKX.SpotvObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(VqYjxiHQNGLCnceUDPgrJalvRuWEKX):
  VqYjxiHQNGLCnceUDPgrJalvRuWEKo=xbmcgui.Window(10000)
  VqYjxiHQNGLCnceUDPgrJalvRuWEKM={'spotv_sessionid':VqYjxiHQNGLCnceUDPgrJalvRuWEKo.getProperty('SPOTV_M_SESSIONID'),'spotv_session':VqYjxiHQNGLCnceUDPgrJalvRuWEKo.getProperty('SPOTV_M_SESSION'),'spotv_accountId':VqYjxiHQNGLCnceUDPgrJalvRuWEKo.getProperty('SPOTV_M_ACCOUNTID'),'spotv_policyKey':VqYjxiHQNGLCnceUDPgrJalvRuWEKo.getProperty('SPOTV_M_POLICYKEY'),'spotv_subend':VqYjxiHQNGLCnceUDPgrJalvRuWEKo.getProperty('SPOTV_M_SUBEND')}
  return VqYjxiHQNGLCnceUDPgrJalvRuWEKM
 def add_dir(VqYjxiHQNGLCnceUDPgrJalvRuWEKX,label,sublabel='',img='',infoLabels=VqYjxiHQNGLCnceUDPgrJalvRuWEyB,isFolder=VqYjxiHQNGLCnceUDPgrJalvRuWEyz,params=''):
  VqYjxiHQNGLCnceUDPgrJalvRuWEKO='%s?%s'%(VqYjxiHQNGLCnceUDPgrJalvRuWEKX._addon_url,urllib.parse.urlencode(params))
  if sublabel:VqYjxiHQNGLCnceUDPgrJalvRuWEKI='%s < %s >'%(label,sublabel)
  else: VqYjxiHQNGLCnceUDPgrJalvRuWEKI=label
  if not img:img='DefaultFolder.png'
  VqYjxiHQNGLCnceUDPgrJalvRuWEKm=xbmcgui.ListItem(VqYjxiHQNGLCnceUDPgrJalvRuWEKI)
  VqYjxiHQNGLCnceUDPgrJalvRuWEKm.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:VqYjxiHQNGLCnceUDPgrJalvRuWEKm.setInfo(type="Video",infoLabels=infoLabels)
  if not isFolder:VqYjxiHQNGLCnceUDPgrJalvRuWEKm.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(VqYjxiHQNGLCnceUDPgrJalvRuWEKX._addon_handle,VqYjxiHQNGLCnceUDPgrJalvRuWEKO,VqYjxiHQNGLCnceUDPgrJalvRuWEKm,isFolder)
 def get_selQuality(VqYjxiHQNGLCnceUDPgrJalvRuWEKX,etype):
  try:
   VqYjxiHQNGLCnceUDPgrJalvRuWEKh='selected_quality'
   VqYjxiHQNGLCnceUDPgrJalvRuWEKd=[1080,720,540]
   VqYjxiHQNGLCnceUDPgrJalvRuWEfK=VqYjxiHQNGLCnceUDPgrJalvRuWEyT(__addon__.getSetting(VqYjxiHQNGLCnceUDPgrJalvRuWEKh))
   return VqYjxiHQNGLCnceUDPgrJalvRuWEKd[VqYjxiHQNGLCnceUDPgrJalvRuWEfK]
  except:
   VqYjxiHQNGLCnceUDPgrJalvRuWEyB
  return 1080 
 def dp_Main_List(VqYjxiHQNGLCnceUDPgrJalvRuWEKX):
  for VqYjxiHQNGLCnceUDPgrJalvRuWEfy in VqYjxiHQNGLCnceUDPgrJalvRuWEKy:
   VqYjxiHQNGLCnceUDPgrJalvRuWEKI=VqYjxiHQNGLCnceUDPgrJalvRuWEfy.get('title')
   VqYjxiHQNGLCnceUDPgrJalvRuWEfk={'mode':VqYjxiHQNGLCnceUDPgrJalvRuWEfy.get('mode')}
   if VqYjxiHQNGLCnceUDPgrJalvRuWEfy.get('mode')=='XXX':
    VqYjxiHQNGLCnceUDPgrJalvRuWEfk['mode']='XXX'
    VqYjxiHQNGLCnceUDPgrJalvRuWEfS=VqYjxiHQNGLCnceUDPgrJalvRuWEyt
   else:
    VqYjxiHQNGLCnceUDPgrJalvRuWEfS=VqYjxiHQNGLCnceUDPgrJalvRuWEyz
   VqYjxiHQNGLCnceUDPgrJalvRuWEKX.add_dir(VqYjxiHQNGLCnceUDPgrJalvRuWEKI,sublabel='',img='',infoLabels=VqYjxiHQNGLCnceUDPgrJalvRuWEyB,isFolder=VqYjxiHQNGLCnceUDPgrJalvRuWEfS,params=VqYjxiHQNGLCnceUDPgrJalvRuWEfk)
  if VqYjxiHQNGLCnceUDPgrJalvRuWEyF(VqYjxiHQNGLCnceUDPgrJalvRuWEKy)>0:xbmcplugin.endOfDirectory(VqYjxiHQNGLCnceUDPgrJalvRuWEKX._addon_handle)
 def login_main(VqYjxiHQNGLCnceUDPgrJalvRuWEKX):
  (VqYjxiHQNGLCnceUDPgrJalvRuWEfs,VqYjxiHQNGLCnceUDPgrJalvRuWEfB)=VqYjxiHQNGLCnceUDPgrJalvRuWEKX.get_settings_login_info()
  if not(VqYjxiHQNGLCnceUDPgrJalvRuWEfs and VqYjxiHQNGLCnceUDPgrJalvRuWEfB):
   VqYjxiHQNGLCnceUDPgrJalvRuWEKT=xbmcgui.Dialog()
   VqYjxiHQNGLCnceUDPgrJalvRuWEft=VqYjxiHQNGLCnceUDPgrJalvRuWEKT.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if VqYjxiHQNGLCnceUDPgrJalvRuWEft==VqYjxiHQNGLCnceUDPgrJalvRuWEyz:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if VqYjxiHQNGLCnceUDPgrJalvRuWEKX.cookiefile_check():return
  VqYjxiHQNGLCnceUDPgrJalvRuWEfz =VqYjxiHQNGLCnceUDPgrJalvRuWEyT(VqYjxiHQNGLCnceUDPgrJalvRuWEKX.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))
  VqYjxiHQNGLCnceUDPgrJalvRuWEfT=xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINTIME')
  if VqYjxiHQNGLCnceUDPgrJalvRuWEfT==VqYjxiHQNGLCnceUDPgrJalvRuWEyB or VqYjxiHQNGLCnceUDPgrJalvRuWEfT=='':VqYjxiHQNGLCnceUDPgrJalvRuWEfT=VqYjxiHQNGLCnceUDPgrJalvRuWEyT('19000101')
  if xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINWAIT')=='TRUE':
   VqYjxiHQNGLCnceUDPgrJalvRuWEfF=0
   while VqYjxiHQNGLCnceUDPgrJalvRuWEyz:
    VqYjxiHQNGLCnceUDPgrJalvRuWEfF+=1
    time.sleep(0.05)
    if VqYjxiHQNGLCnceUDPgrJalvRuWEfT>=VqYjxiHQNGLCnceUDPgrJalvRuWEfz:return
    if VqYjxiHQNGLCnceUDPgrJalvRuWEfF>600:return
  else:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','TRUE')
  if VqYjxiHQNGLCnceUDPgrJalvRuWEfT>=VqYjxiHQNGLCnceUDPgrJalvRuWEfz:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
   return
  if not VqYjxiHQNGLCnceUDPgrJalvRuWEKX.SpotvObj.GetCredential(VqYjxiHQNGLCnceUDPgrJalvRuWEfs,VqYjxiHQNGLCnceUDPgrJalvRuWEfB):
   VqYjxiHQNGLCnceUDPgrJalvRuWEKX.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
   sys.exit()
  VqYjxiHQNGLCnceUDPgrJalvRuWEKX.set_winCredential(VqYjxiHQNGLCnceUDPgrJalvRuWEKX.SpotvObj.LoadCredential())
  VqYjxiHQNGLCnceUDPgrJalvRuWEKX.cookiefile_save()
  xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
 def dp_LiveChannel_List(VqYjxiHQNGLCnceUDPgrJalvRuWEKX,args):
  VqYjxiHQNGLCnceUDPgrJalvRuWEKX.SpotvObj.SaveCredential(VqYjxiHQNGLCnceUDPgrJalvRuWEKX.get_winCredential())
  VqYjxiHQNGLCnceUDPgrJalvRuWEfp=VqYjxiHQNGLCnceUDPgrJalvRuWEKX.SpotvObj.GetLiveChannelList()
  for VqYjxiHQNGLCnceUDPgrJalvRuWEfb in VqYjxiHQNGLCnceUDPgrJalvRuWEfp:
   VqYjxiHQNGLCnceUDPgrJalvRuWEKI =VqYjxiHQNGLCnceUDPgrJalvRuWEfb.get('name')
   VqYjxiHQNGLCnceUDPgrJalvRuWEfX =VqYjxiHQNGLCnceUDPgrJalvRuWEfb.get('programName')
   VqYjxiHQNGLCnceUDPgrJalvRuWEfA =VqYjxiHQNGLCnceUDPgrJalvRuWEfb.get('logo')
   VqYjxiHQNGLCnceUDPgrJalvRuWEfw=VqYjxiHQNGLCnceUDPgrJalvRuWEfb.get('channelepg')
   VqYjxiHQNGLCnceUDPgrJalvRuWEfo =VqYjxiHQNGLCnceUDPgrJalvRuWEfb.get('free')
   VqYjxiHQNGLCnceUDPgrJalvRuWEfM=VqYjxiHQNGLCnceUDPgrJalvRuWEfb.get('info')
   VqYjxiHQNGLCnceUDPgrJalvRuWEfM['plot']='%s'%(VqYjxiHQNGLCnceUDPgrJalvRuWEfw)
   VqYjxiHQNGLCnceUDPgrJalvRuWEfk={'mode':'LIVE','mediaid':VqYjxiHQNGLCnceUDPgrJalvRuWEfb.get('id'),'mediacode':VqYjxiHQNGLCnceUDPgrJalvRuWEfb.get('videoId'),'free':VqYjxiHQNGLCnceUDPgrJalvRuWEfo}
   if VqYjxiHQNGLCnceUDPgrJalvRuWEfo:VqYjxiHQNGLCnceUDPgrJalvRuWEKI+=' [free]'
   VqYjxiHQNGLCnceUDPgrJalvRuWEKX.add_dir(VqYjxiHQNGLCnceUDPgrJalvRuWEKI,sublabel=VqYjxiHQNGLCnceUDPgrJalvRuWEfX,img=VqYjxiHQNGLCnceUDPgrJalvRuWEfA,infoLabels=VqYjxiHQNGLCnceUDPgrJalvRuWEfM,isFolder=VqYjxiHQNGLCnceUDPgrJalvRuWEyt,params=VqYjxiHQNGLCnceUDPgrJalvRuWEfk)
  if VqYjxiHQNGLCnceUDPgrJalvRuWEyF(VqYjxiHQNGLCnceUDPgrJalvRuWEfp)>0:xbmcplugin.endOfDirectory(VqYjxiHQNGLCnceUDPgrJalvRuWEKX._addon_handle,cacheToDisc=VqYjxiHQNGLCnceUDPgrJalvRuWEyt)
 def play_VIDEO(VqYjxiHQNGLCnceUDPgrJalvRuWEKX,args):
  VqYjxiHQNGLCnceUDPgrJalvRuWEKX.SpotvObj.SaveCredential(VqYjxiHQNGLCnceUDPgrJalvRuWEKX.get_winCredential())
  if args.get('free')=='False':
   if VqYjxiHQNGLCnceUDPgrJalvRuWEKX.SpotvObj.CheckSubEnd()==VqYjxiHQNGLCnceUDPgrJalvRuWEyt:
    VqYjxiHQNGLCnceUDPgrJalvRuWEKX.addon_noti(__language__(30908).encode('utf8'))
    return
  VqYjxiHQNGLCnceUDPgrJalvRuWEfO =args.get('mediacode')
  VqYjxiHQNGLCnceUDPgrJalvRuWEfI=VqYjxiHQNGLCnceUDPgrJalvRuWEKX.SpotvObj.GetBroadURL(VqYjxiHQNGLCnceUDPgrJalvRuWEfO)
  if VqYjxiHQNGLCnceUDPgrJalvRuWEfI=='':
   VqYjxiHQNGLCnceUDPgrJalvRuWEKX.addon_noti(__language__(30908).encode('utf8'))
   return
  VqYjxiHQNGLCnceUDPgrJalvRuWEfm=VqYjxiHQNGLCnceUDPgrJalvRuWEfI
  VqYjxiHQNGLCnceUDPgrJalvRuWEKX.addon_log(VqYjxiHQNGLCnceUDPgrJalvRuWEfm,VqYjxiHQNGLCnceUDPgrJalvRuWEyt)
  VqYjxiHQNGLCnceUDPgrJalvRuWEfh=xbmcgui.ListItem(path=VqYjxiHQNGLCnceUDPgrJalvRuWEfm)
  xbmcplugin.setResolvedUrl(VqYjxiHQNGLCnceUDPgrJalvRuWEKX._addon_handle,VqYjxiHQNGLCnceUDPgrJalvRuWEyz,VqYjxiHQNGLCnceUDPgrJalvRuWEfh)
 def logout(VqYjxiHQNGLCnceUDPgrJalvRuWEKX):
  VqYjxiHQNGLCnceUDPgrJalvRuWEKT=xbmcgui.Dialog()
  VqYjxiHQNGLCnceUDPgrJalvRuWEft=VqYjxiHQNGLCnceUDPgrJalvRuWEKT.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if VqYjxiHQNGLCnceUDPgrJalvRuWEft==VqYjxiHQNGLCnceUDPgrJalvRuWEyt:sys.exit()
  VqYjxiHQNGLCnceUDPgrJalvRuWEKX.wininfo_clear()
  if os.path.isfile(VqYjxiHQNGLCnceUDPgrJalvRuWEKS):os.remove(VqYjxiHQNGLCnceUDPgrJalvRuWEKS)
  VqYjxiHQNGLCnceUDPgrJalvRuWEKX.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(VqYjxiHQNGLCnceUDPgrJalvRuWEKX):
  VqYjxiHQNGLCnceUDPgrJalvRuWEKo=xbmcgui.Window(10000)
  VqYjxiHQNGLCnceUDPgrJalvRuWEKo.setProperty('SPOTV_M_SESSIONID','')
  VqYjxiHQNGLCnceUDPgrJalvRuWEKo.setProperty('SPOTV_M_SESSION','')
  VqYjxiHQNGLCnceUDPgrJalvRuWEKo.setProperty('SPOTV_M_ACCOUNTID','')
  VqYjxiHQNGLCnceUDPgrJalvRuWEKo.setProperty('SPOTV_M_POLICYKEY','')
  VqYjxiHQNGLCnceUDPgrJalvRuWEKo.setProperty('SPOTV_M_SUBEND','')
  VqYjxiHQNGLCnceUDPgrJalvRuWEKo.setProperty('SPOTV_M_LOGINTIME','')
 def cookiefile_save(VqYjxiHQNGLCnceUDPgrJalvRuWEKX):
  VqYjxiHQNGLCnceUDPgrJalvRuWEfd =VqYjxiHQNGLCnceUDPgrJalvRuWEKX.SpotvObj.Get_Now_Datetime()
  VqYjxiHQNGLCnceUDPgrJalvRuWEyK=VqYjxiHQNGLCnceUDPgrJalvRuWEfd+datetime.timedelta(days=VqYjxiHQNGLCnceUDPgrJalvRuWEyT(__addon__.getSetting('cache_ttl')))
  VqYjxiHQNGLCnceUDPgrJalvRuWEKo=xbmcgui.Window(10000)
  VqYjxiHQNGLCnceUDPgrJalvRuWEyf={'spotv_sessionid':VqYjxiHQNGLCnceUDPgrJalvRuWEKo.getProperty('SPOTV_M_SESSIONID'),'spotv_session':VqYjxiHQNGLCnceUDPgrJalvRuWEKo.getProperty('SPOTV_M_SESSION'),'spotv_accountId':VqYjxiHQNGLCnceUDPgrJalvRuWEKo.getProperty('SPOTV_M_ACCOUNTID'),'spotv_policyKey':base64.standard_b64encode(VqYjxiHQNGLCnceUDPgrJalvRuWEKo.getProperty('SPOTV_M_POLICYKEY').encode()).decode('utf-8'),'spotv_subend':base64.standard_b64encode((VqYjxiHQNGLCnceUDPgrJalvRuWEKX.SpotvObj.SPOTV_PMCODE+VqYjxiHQNGLCnceUDPgrJalvRuWEKo.getProperty('SPOTV_M_SUBEND')).encode()).decode('utf-8'),'spotv_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'spotv_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'spotv_limitdate':VqYjxiHQNGLCnceUDPgrJalvRuWEyK.strftime('%Y-%m-%d')}
  try: 
   with VqYjxiHQNGLCnceUDPgrJalvRuWEyp(VqYjxiHQNGLCnceUDPgrJalvRuWEKS,'w',-1,'utf-8')as fp:
    VqYjxiHQNGLCnceUDPgrJalvRuWEyk.dump(VqYjxiHQNGLCnceUDPgrJalvRuWEyf,fp)
  except VqYjxiHQNGLCnceUDPgrJalvRuWEyb as exception:
   VqYjxiHQNGLCnceUDPgrJalvRuWEyA(exception)
 def cookiefile_check(VqYjxiHQNGLCnceUDPgrJalvRuWEKX):
  VqYjxiHQNGLCnceUDPgrJalvRuWEyf={}
  try: 
   with VqYjxiHQNGLCnceUDPgrJalvRuWEyp(VqYjxiHQNGLCnceUDPgrJalvRuWEKS,'r',-1,'utf-8')as fp:
    VqYjxiHQNGLCnceUDPgrJalvRuWEyf= VqYjxiHQNGLCnceUDPgrJalvRuWEyk.load(fp)
  except VqYjxiHQNGLCnceUDPgrJalvRuWEyb as exception:
   VqYjxiHQNGLCnceUDPgrJalvRuWEKX.wininfo_clear()
   return VqYjxiHQNGLCnceUDPgrJalvRuWEyt
  VqYjxiHQNGLCnceUDPgrJalvRuWEfs =__addon__.getSetting('id')
  VqYjxiHQNGLCnceUDPgrJalvRuWEfB =__addon__.getSetting('pw')
  VqYjxiHQNGLCnceUDPgrJalvRuWEyf['spotv_id'] =base64.standard_b64decode(VqYjxiHQNGLCnceUDPgrJalvRuWEyf['spotv_id']).decode('utf-8')
  VqYjxiHQNGLCnceUDPgrJalvRuWEyf['spotv_pw'] =base64.standard_b64decode(VqYjxiHQNGLCnceUDPgrJalvRuWEyf['spotv_pw']).decode('utf-8')
  VqYjxiHQNGLCnceUDPgrJalvRuWEyf['spotv_policyKey']=base64.standard_b64decode(VqYjxiHQNGLCnceUDPgrJalvRuWEyf['spotv_policyKey']).decode('utf-8')
  VqYjxiHQNGLCnceUDPgrJalvRuWEyf['spotv_subend']=base64.standard_b64decode(VqYjxiHQNGLCnceUDPgrJalvRuWEyf['spotv_subend']).decode('utf-8')[VqYjxiHQNGLCnceUDPgrJalvRuWEKX.SpotvObj.SPOTV_PMSIZE:]
  if VqYjxiHQNGLCnceUDPgrJalvRuWEfs!=VqYjxiHQNGLCnceUDPgrJalvRuWEyf['spotv_id']or VqYjxiHQNGLCnceUDPgrJalvRuWEfB!=VqYjxiHQNGLCnceUDPgrJalvRuWEyf['spotv_pw']:
   VqYjxiHQNGLCnceUDPgrJalvRuWEKX.wininfo_clear()
   return VqYjxiHQNGLCnceUDPgrJalvRuWEyt
  VqYjxiHQNGLCnceUDPgrJalvRuWEfz =VqYjxiHQNGLCnceUDPgrJalvRuWEyT(VqYjxiHQNGLCnceUDPgrJalvRuWEKX.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))
  VqYjxiHQNGLCnceUDPgrJalvRuWEyS=VqYjxiHQNGLCnceUDPgrJalvRuWEyf['spotv_limitdate']
  VqYjxiHQNGLCnceUDPgrJalvRuWEfT =VqYjxiHQNGLCnceUDPgrJalvRuWEyT(re.sub('-','',VqYjxiHQNGLCnceUDPgrJalvRuWEyS))
  if VqYjxiHQNGLCnceUDPgrJalvRuWEfT<VqYjxiHQNGLCnceUDPgrJalvRuWEfz:
   VqYjxiHQNGLCnceUDPgrJalvRuWEKX.wininfo_clear()
   return VqYjxiHQNGLCnceUDPgrJalvRuWEyt
  VqYjxiHQNGLCnceUDPgrJalvRuWEKo=xbmcgui.Window(10000)
  VqYjxiHQNGLCnceUDPgrJalvRuWEKo.setProperty('SPOTV_M_SESSIONID',VqYjxiHQNGLCnceUDPgrJalvRuWEyf['spotv_sessionid'])
  VqYjxiHQNGLCnceUDPgrJalvRuWEKo.setProperty('SPOTV_M_SESSION',VqYjxiHQNGLCnceUDPgrJalvRuWEyf['spotv_session'])
  VqYjxiHQNGLCnceUDPgrJalvRuWEKo.setProperty('SPOTV_M_ACCOUNTID',VqYjxiHQNGLCnceUDPgrJalvRuWEyf['spotv_accountId'])
  VqYjxiHQNGLCnceUDPgrJalvRuWEKo.setProperty('SPOTV_M_POLICYKEY',VqYjxiHQNGLCnceUDPgrJalvRuWEyf['spotv_policyKey'])
  VqYjxiHQNGLCnceUDPgrJalvRuWEKo.setProperty('SPOTV_M_SUBEND',VqYjxiHQNGLCnceUDPgrJalvRuWEyf['spotv_subend'])
  VqYjxiHQNGLCnceUDPgrJalvRuWEKo.setProperty('SPOTV_M_LOGINTIME',VqYjxiHQNGLCnceUDPgrJalvRuWEyS)
  return VqYjxiHQNGLCnceUDPgrJalvRuWEyz
 def spotv_main(VqYjxiHQNGLCnceUDPgrJalvRuWEKX):
  VqYjxiHQNGLCnceUDPgrJalvRuWEyX=VqYjxiHQNGLCnceUDPgrJalvRuWEKX.main_params.get('mode',VqYjxiHQNGLCnceUDPgrJalvRuWEyB)
  if VqYjxiHQNGLCnceUDPgrJalvRuWEyX=='LOGOUT':
   VqYjxiHQNGLCnceUDPgrJalvRuWEKX.logout()
   return
  VqYjxiHQNGLCnceUDPgrJalvRuWEKX.login_main()
  if VqYjxiHQNGLCnceUDPgrJalvRuWEyX is VqYjxiHQNGLCnceUDPgrJalvRuWEyB:
   VqYjxiHQNGLCnceUDPgrJalvRuWEKX.dp_Main_List()
  elif VqYjxiHQNGLCnceUDPgrJalvRuWEyX=='CHANNEL':
   VqYjxiHQNGLCnceUDPgrJalvRuWEKX.dp_LiveChannel_List(VqYjxiHQNGLCnceUDPgrJalvRuWEKX.main_params)
  elif VqYjxiHQNGLCnceUDPgrJalvRuWEyX in['LIVE']:
   VqYjxiHQNGLCnceUDPgrJalvRuWEKX.play_VIDEO(VqYjxiHQNGLCnceUDPgrJalvRuWEKX.main_params)
  elif VqYjxiHQNGLCnceUDPgrJalvRuWEyX=='LOGOUT':
   VqYjxiHQNGLCnceUDPgrJalvRuWEKX.logout()
  else:
   VqYjxiHQNGLCnceUDPgrJalvRuWEyB
# Created by pyminifier (https://github.com/liftoff/pyminifier)
