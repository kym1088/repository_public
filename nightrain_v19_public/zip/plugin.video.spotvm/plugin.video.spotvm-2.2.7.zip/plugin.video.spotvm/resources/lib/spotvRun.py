__author__="NightRain"
pLYdumiQzKnOrEklasWhtxJXNMSgHT=object
pLYdumiQzKnOrEklasWhtxJXNMSgHy=None
pLYdumiQzKnOrEklasWhtxJXNMSgHv=False
pLYdumiQzKnOrEklasWhtxJXNMSgwq=True
pLYdumiQzKnOrEklasWhtxJXNMSgwc=getattr
pLYdumiQzKnOrEklasWhtxJXNMSgwU=type
pLYdumiQzKnOrEklasWhtxJXNMSgwo=int
pLYdumiQzKnOrEklasWhtxJXNMSgwH=list
pLYdumiQzKnOrEklasWhtxJXNMSgwB=len
pLYdumiQzKnOrEklasWhtxJXNMSgwC=str
pLYdumiQzKnOrEklasWhtxJXNMSgwF=id
pLYdumiQzKnOrEklasWhtxJXNMSgwR=open
pLYdumiQzKnOrEklasWhtxJXNMSgwe=dict
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
pLYdumiQzKnOrEklasWhtxJXNMSgqU=[{'title':'TV 채널 (유료사용자만 지원)','mode':'LIVE_GROUP','icon':'live.png'},{'title':'Live중계 (경기중에만 재생)','mode':'ELIVE_GROUP','icon':'live.png'},{'title':'-----------------','mode':'XXX'},{'title':'오늘의 추천 VOD','mode':'NOW_GROUP'},{'title':'인기영상 5','mode':'POP_GROUP'},{'title':'-----------------','mode':'XXX'},{'title':'VOD (리그, 경기별)','mode':'VOD_GROUP'},{'title':'Watched (시청목록)','mode':'WATCH','icon':'history.png'},]
pLYdumiQzKnOrEklasWhtxJXNMSgqo={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
pLYdumiQzKnOrEklasWhtxJXNMSgqH=xbmcvfs.translatePath(os.path.join(__profile__,'spotv_cookies.json'))
from spotvCore import*
class pLYdumiQzKnOrEklasWhtxJXNMSgqc(pLYdumiQzKnOrEklasWhtxJXNMSgHT):
 def __init__(pLYdumiQzKnOrEklasWhtxJXNMSgqw,pLYdumiQzKnOrEklasWhtxJXNMSgqB,pLYdumiQzKnOrEklasWhtxJXNMSgqC,pLYdumiQzKnOrEklasWhtxJXNMSgqF):
  pLYdumiQzKnOrEklasWhtxJXNMSgqw._addon_url =pLYdumiQzKnOrEklasWhtxJXNMSgqB
  pLYdumiQzKnOrEklasWhtxJXNMSgqw._addon_handle=pLYdumiQzKnOrEklasWhtxJXNMSgqC
  pLYdumiQzKnOrEklasWhtxJXNMSgqw.main_params =pLYdumiQzKnOrEklasWhtxJXNMSgqF
  pLYdumiQzKnOrEklasWhtxJXNMSgqw.SpotvObj =CtKSbPvNdaIXTBJjiRflpALwVrqhOM() 
 def addon_noti(pLYdumiQzKnOrEklasWhtxJXNMSgqw,sting):
  try:
   pLYdumiQzKnOrEklasWhtxJXNMSgqe=xbmcgui.Dialog()
   pLYdumiQzKnOrEklasWhtxJXNMSgqe.notification(__addonname__,sting)
  except:
   pLYdumiQzKnOrEklasWhtxJXNMSgHy
 def addon_log(pLYdumiQzKnOrEklasWhtxJXNMSgqw,string):
  try:
   pLYdumiQzKnOrEklasWhtxJXNMSgqb=string.encode('utf-8','ignore')
  except:
   pLYdumiQzKnOrEklasWhtxJXNMSgqb='addonException: addon_log'
  pLYdumiQzKnOrEklasWhtxJXNMSgqj=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,pLYdumiQzKnOrEklasWhtxJXNMSgqb),level=pLYdumiQzKnOrEklasWhtxJXNMSgqj)
 def get_keyboard_input(pLYdumiQzKnOrEklasWhtxJXNMSgqw,pLYdumiQzKnOrEklasWhtxJXNMSgqG):
  pLYdumiQzKnOrEklasWhtxJXNMSgqP=pLYdumiQzKnOrEklasWhtxJXNMSgHy
  kb=xbmc.Keyboard()
  kb.setHeading(pLYdumiQzKnOrEklasWhtxJXNMSgqG)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   pLYdumiQzKnOrEklasWhtxJXNMSgqP=kb.getText()
  return pLYdumiQzKnOrEklasWhtxJXNMSgqP
 def get_settings_account(pLYdumiQzKnOrEklasWhtxJXNMSgqw):
  pLYdumiQzKnOrEklasWhtxJXNMSgqA =__addon__.getSetting('id')
  pLYdumiQzKnOrEklasWhtxJXNMSgqf =__addon__.getSetting('pw')
  return(pLYdumiQzKnOrEklasWhtxJXNMSgqA,pLYdumiQzKnOrEklasWhtxJXNMSgqf)
 def get_settings_hidescoreyn(pLYdumiQzKnOrEklasWhtxJXNMSgqw):
  pLYdumiQzKnOrEklasWhtxJXNMSgqD =__addon__.getSetting('hidescore')
  if pLYdumiQzKnOrEklasWhtxJXNMSgqD=='false':
   return pLYdumiQzKnOrEklasWhtxJXNMSgHv
  else:
   return pLYdumiQzKnOrEklasWhtxJXNMSgwq
 def add_dir(pLYdumiQzKnOrEklasWhtxJXNMSgqw,label,sublabel='',img='',infoLabels=pLYdumiQzKnOrEklasWhtxJXNMSgHy,isFolder=pLYdumiQzKnOrEklasWhtxJXNMSgwq,params='',isLink=pLYdumiQzKnOrEklasWhtxJXNMSgHv,ContextMenu=pLYdumiQzKnOrEklasWhtxJXNMSgHy):
  pLYdumiQzKnOrEklasWhtxJXNMSgqV='%s?%s'%(pLYdumiQzKnOrEklasWhtxJXNMSgqw._addon_url,urllib.parse.urlencode(params))
  if sublabel:pLYdumiQzKnOrEklasWhtxJXNMSgqG='%s < %s >'%(label,sublabel)
  else: pLYdumiQzKnOrEklasWhtxJXNMSgqG=label
  if not img:img='DefaultFolder.png'
  pLYdumiQzKnOrEklasWhtxJXNMSgqI=xbmcgui.ListItem(pLYdumiQzKnOrEklasWhtxJXNMSgqG)
  pLYdumiQzKnOrEklasWhtxJXNMSgqI.setArt({'thumb':img,'icon':img,'poster':img})
  if pLYdumiQzKnOrEklasWhtxJXNMSgqw.SpotvObj.KodiVersion>=20:
   if infoLabels:pLYdumiQzKnOrEklasWhtxJXNMSgqw.Set_InfoTag(pLYdumiQzKnOrEklasWhtxJXNMSgqI.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:pLYdumiQzKnOrEklasWhtxJXNMSgqI.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   pLYdumiQzKnOrEklasWhtxJXNMSgqI.setProperty('IsPlayable','true')
  if ContextMenu:pLYdumiQzKnOrEklasWhtxJXNMSgqI.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(pLYdumiQzKnOrEklasWhtxJXNMSgqw._addon_handle,pLYdumiQzKnOrEklasWhtxJXNMSgqV,pLYdumiQzKnOrEklasWhtxJXNMSgqI,isFolder)
 def Set_InfoTag(pLYdumiQzKnOrEklasWhtxJXNMSgqw,video_InfoTag:xbmc.InfoTagVideo,pLYdumiQzKnOrEklasWhtxJXNMSgcF):
  for pLYdumiQzKnOrEklasWhtxJXNMSgqT,value in pLYdumiQzKnOrEklasWhtxJXNMSgcF.items():
   if pLYdumiQzKnOrEklasWhtxJXNMSgqo[pLYdumiQzKnOrEklasWhtxJXNMSgqT]['type']=='string':
    pLYdumiQzKnOrEklasWhtxJXNMSgwc(video_InfoTag,pLYdumiQzKnOrEklasWhtxJXNMSgqo[pLYdumiQzKnOrEklasWhtxJXNMSgqT]['func'])(value)
   elif pLYdumiQzKnOrEklasWhtxJXNMSgqo[pLYdumiQzKnOrEklasWhtxJXNMSgqT]['type']=='int':
    if pLYdumiQzKnOrEklasWhtxJXNMSgwU(value)==pLYdumiQzKnOrEklasWhtxJXNMSgwo:
     pLYdumiQzKnOrEklasWhtxJXNMSgqy=pLYdumiQzKnOrEklasWhtxJXNMSgwo(value)
    else:
     pLYdumiQzKnOrEklasWhtxJXNMSgqy=0
    pLYdumiQzKnOrEklasWhtxJXNMSgwc(video_InfoTag,pLYdumiQzKnOrEklasWhtxJXNMSgqo[pLYdumiQzKnOrEklasWhtxJXNMSgqT]['func'])(pLYdumiQzKnOrEklasWhtxJXNMSgqy)
   elif pLYdumiQzKnOrEklasWhtxJXNMSgqo[pLYdumiQzKnOrEklasWhtxJXNMSgqT]['type']=='actor':
    if value!=[]:
     pLYdumiQzKnOrEklasWhtxJXNMSgwc(video_InfoTag,pLYdumiQzKnOrEklasWhtxJXNMSgqo[pLYdumiQzKnOrEklasWhtxJXNMSgqT]['func'])([xbmc.Actor(name)for name in value])
   elif pLYdumiQzKnOrEklasWhtxJXNMSgqo[pLYdumiQzKnOrEklasWhtxJXNMSgqT]['type']=='list':
    if pLYdumiQzKnOrEklasWhtxJXNMSgwU(value)==pLYdumiQzKnOrEklasWhtxJXNMSgwH:
     pLYdumiQzKnOrEklasWhtxJXNMSgwc(video_InfoTag,pLYdumiQzKnOrEklasWhtxJXNMSgqo[pLYdumiQzKnOrEklasWhtxJXNMSgqT]['func'])(value)
    else:
     pLYdumiQzKnOrEklasWhtxJXNMSgwc(video_InfoTag,pLYdumiQzKnOrEklasWhtxJXNMSgqo[pLYdumiQzKnOrEklasWhtxJXNMSgqT]['func'])([value])
 def get_selQuality(pLYdumiQzKnOrEklasWhtxJXNMSgqw,etype):
  try:
   pLYdumiQzKnOrEklasWhtxJXNMSgqv='selected_quality'
   pLYdumiQzKnOrEklasWhtxJXNMSgcq=[1080,720,540]
   pLYdumiQzKnOrEklasWhtxJXNMSgcU=pLYdumiQzKnOrEklasWhtxJXNMSgwo(__addon__.getSetting(pLYdumiQzKnOrEklasWhtxJXNMSgqv))
   return pLYdumiQzKnOrEklasWhtxJXNMSgcq[pLYdumiQzKnOrEklasWhtxJXNMSgcU]
  except:
   pLYdumiQzKnOrEklasWhtxJXNMSgHy
  return 1080 
 def dp_Main_List(pLYdumiQzKnOrEklasWhtxJXNMSgqw):
  for pLYdumiQzKnOrEklasWhtxJXNMSgco in pLYdumiQzKnOrEklasWhtxJXNMSgqU:
   pLYdumiQzKnOrEklasWhtxJXNMSgqG=pLYdumiQzKnOrEklasWhtxJXNMSgco.get('title')
   pLYdumiQzKnOrEklasWhtxJXNMSgcH=''
   pLYdumiQzKnOrEklasWhtxJXNMSgcw={'mode':pLYdumiQzKnOrEklasWhtxJXNMSgco.get('mode'),'page':'1'}
   if pLYdumiQzKnOrEklasWhtxJXNMSgco.get('mode')=='XXX':
    pLYdumiQzKnOrEklasWhtxJXNMSgcB=pLYdumiQzKnOrEklasWhtxJXNMSgHv
    pLYdumiQzKnOrEklasWhtxJXNMSgcC =pLYdumiQzKnOrEklasWhtxJXNMSgwq
   else:
    pLYdumiQzKnOrEklasWhtxJXNMSgcB=pLYdumiQzKnOrEklasWhtxJXNMSgwq
    pLYdumiQzKnOrEklasWhtxJXNMSgcC =pLYdumiQzKnOrEklasWhtxJXNMSgHv
   pLYdumiQzKnOrEklasWhtxJXNMSgcF={'title':pLYdumiQzKnOrEklasWhtxJXNMSgqG,'plot':pLYdumiQzKnOrEklasWhtxJXNMSgqG}
   if pLYdumiQzKnOrEklasWhtxJXNMSgco.get('mode')=='XXX':pLYdumiQzKnOrEklasWhtxJXNMSgcF=pLYdumiQzKnOrEklasWhtxJXNMSgHy
   if 'icon' in pLYdumiQzKnOrEklasWhtxJXNMSgco:pLYdumiQzKnOrEklasWhtxJXNMSgcH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',pLYdumiQzKnOrEklasWhtxJXNMSgco.get('icon')) 
   pLYdumiQzKnOrEklasWhtxJXNMSgqw.add_dir(pLYdumiQzKnOrEklasWhtxJXNMSgqG,sublabel='',img=pLYdumiQzKnOrEklasWhtxJXNMSgcH,infoLabels=pLYdumiQzKnOrEklasWhtxJXNMSgcF,isFolder=pLYdumiQzKnOrEklasWhtxJXNMSgcB,params=pLYdumiQzKnOrEklasWhtxJXNMSgcw,isLink=pLYdumiQzKnOrEklasWhtxJXNMSgcC)
  if pLYdumiQzKnOrEklasWhtxJXNMSgwB(pLYdumiQzKnOrEklasWhtxJXNMSgqU)>0:xbmcplugin.endOfDirectory(pLYdumiQzKnOrEklasWhtxJXNMSgqw._addon_handle)
 def dp_MainLeague_List(pLYdumiQzKnOrEklasWhtxJXNMSgqw,args):
  pLYdumiQzKnOrEklasWhtxJXNMSgqw.addon_log('dp_MainLeague_List')
  pLYdumiQzKnOrEklasWhtxJXNMSgce=pLYdumiQzKnOrEklasWhtxJXNMSgqw.SpotvObj.GetTitleGroupList()
  pLYdumiQzKnOrEklasWhtxJXNMSgqw.addon_log('dp_MainLeague_List cnt : '+pLYdumiQzKnOrEklasWhtxJXNMSgwC(pLYdumiQzKnOrEklasWhtxJXNMSgwB(pLYdumiQzKnOrEklasWhtxJXNMSgce)))
  for pLYdumiQzKnOrEklasWhtxJXNMSgcb in pLYdumiQzKnOrEklasWhtxJXNMSgce:
   pLYdumiQzKnOrEklasWhtxJXNMSgqG =pLYdumiQzKnOrEklasWhtxJXNMSgcb.get('title')
   pLYdumiQzKnOrEklasWhtxJXNMSgcj =pLYdumiQzKnOrEklasWhtxJXNMSgcb.get('logo')
   pLYdumiQzKnOrEklasWhtxJXNMSgcP =pLYdumiQzKnOrEklasWhtxJXNMSgcb.get('reagueId')
   pLYdumiQzKnOrEklasWhtxJXNMSgcA =pLYdumiQzKnOrEklasWhtxJXNMSgcb.get('subGame')
   pLYdumiQzKnOrEklasWhtxJXNMSgcf={'mediatype':'episode','plot':'%s\n\n%s'%(pLYdumiQzKnOrEklasWhtxJXNMSgqG,pLYdumiQzKnOrEklasWhtxJXNMSgcA)}
   pLYdumiQzKnOrEklasWhtxJXNMSgcw={'mode':'LEAGUE_GROUP','reagueId':pLYdumiQzKnOrEklasWhtxJXNMSgcP}
   pLYdumiQzKnOrEklasWhtxJXNMSgqw.add_dir(pLYdumiQzKnOrEklasWhtxJXNMSgqG,sublabel=pLYdumiQzKnOrEklasWhtxJXNMSgHy,img=pLYdumiQzKnOrEklasWhtxJXNMSgcj,infoLabels=pLYdumiQzKnOrEklasWhtxJXNMSgcf,isFolder=pLYdumiQzKnOrEklasWhtxJXNMSgwq,params=pLYdumiQzKnOrEklasWhtxJXNMSgcw)
  if pLYdumiQzKnOrEklasWhtxJXNMSgwB(pLYdumiQzKnOrEklasWhtxJXNMSgce)>0:xbmcplugin.endOfDirectory(pLYdumiQzKnOrEklasWhtxJXNMSgqw._addon_handle,cacheToDisc=pLYdumiQzKnOrEklasWhtxJXNMSgHv)
 def dp_NowVod_GroupList(pLYdumiQzKnOrEklasWhtxJXNMSgqw,args):
  pLYdumiQzKnOrEklasWhtxJXNMSgcD=pLYdumiQzKnOrEklasWhtxJXNMSgwo(args.get('page'))
  pLYdumiQzKnOrEklasWhtxJXNMSgqw.addon_log('dp_NowVod_GroupList page : '+pLYdumiQzKnOrEklasWhtxJXNMSgwC(pLYdumiQzKnOrEklasWhtxJXNMSgcD))
  pLYdumiQzKnOrEklasWhtxJXNMSgce,pLYdumiQzKnOrEklasWhtxJXNMSgcV=pLYdumiQzKnOrEklasWhtxJXNMSgqw.SpotvObj.Get_NowVod_GroupList(pLYdumiQzKnOrEklasWhtxJXNMSgcD)
  pLYdumiQzKnOrEklasWhtxJXNMSgqw.addon_log('dp_NowVod_GroupList cnt : '+pLYdumiQzKnOrEklasWhtxJXNMSgwC(pLYdumiQzKnOrEklasWhtxJXNMSgwB(pLYdumiQzKnOrEklasWhtxJXNMSgce)))
  for pLYdumiQzKnOrEklasWhtxJXNMSgcb in pLYdumiQzKnOrEklasWhtxJXNMSgce:
   pLYdumiQzKnOrEklasWhtxJXNMSgcG =pLYdumiQzKnOrEklasWhtxJXNMSgcb.get('vodTitle')
   pLYdumiQzKnOrEklasWhtxJXNMSgcI =pLYdumiQzKnOrEklasWhtxJXNMSgcb.get('vodId')
   pLYdumiQzKnOrEklasWhtxJXNMSgcT =pLYdumiQzKnOrEklasWhtxJXNMSgcb.get('vodType')
   pLYdumiQzKnOrEklasWhtxJXNMSgcj=pLYdumiQzKnOrEklasWhtxJXNMSgcb.get('thumbnail')
   pLYdumiQzKnOrEklasWhtxJXNMSgcy =pLYdumiQzKnOrEklasWhtxJXNMSgcb.get('vtypeId')
   pLYdumiQzKnOrEklasWhtxJXNMSgcv =pLYdumiQzKnOrEklasWhtxJXNMSgcb.get('duration')
   pLYdumiQzKnOrEklasWhtxJXNMSgcf={'mediatype':'episode','duration':pLYdumiQzKnOrEklasWhtxJXNMSgcv,'plot':pLYdumiQzKnOrEklasWhtxJXNMSgcG}
   pLYdumiQzKnOrEklasWhtxJXNMSgcw={'mode':'NOW_VOD','mediacode':pLYdumiQzKnOrEklasWhtxJXNMSgcI,'mediatype':'vod','vtypeId':pLYdumiQzKnOrEklasWhtxJXNMSgcy}
   pLYdumiQzKnOrEklasWhtxJXNMSgqw.add_dir(pLYdumiQzKnOrEklasWhtxJXNMSgcG,sublabel=pLYdumiQzKnOrEklasWhtxJXNMSgcT,img=pLYdumiQzKnOrEklasWhtxJXNMSgcj,infoLabels=pLYdumiQzKnOrEklasWhtxJXNMSgcf,isFolder=pLYdumiQzKnOrEklasWhtxJXNMSgHv,params=pLYdumiQzKnOrEklasWhtxJXNMSgcw)
  if pLYdumiQzKnOrEklasWhtxJXNMSgcV:
   pLYdumiQzKnOrEklasWhtxJXNMSgcw['mode'] ='NOW_GROUP' 
   pLYdumiQzKnOrEklasWhtxJXNMSgcw['page'] =pLYdumiQzKnOrEklasWhtxJXNMSgwC(pLYdumiQzKnOrEklasWhtxJXNMSgcD+1)
   pLYdumiQzKnOrEklasWhtxJXNMSgqG='[B]%s >>[/B]'%'다음 페이지'
   pLYdumiQzKnOrEklasWhtxJXNMSgUq=pLYdumiQzKnOrEklasWhtxJXNMSgwC(pLYdumiQzKnOrEklasWhtxJXNMSgcD+1)
   pLYdumiQzKnOrEklasWhtxJXNMSgcH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   pLYdumiQzKnOrEklasWhtxJXNMSgqw.add_dir(pLYdumiQzKnOrEklasWhtxJXNMSgqG,sublabel=pLYdumiQzKnOrEklasWhtxJXNMSgUq,img=pLYdumiQzKnOrEklasWhtxJXNMSgcH,infoLabels=pLYdumiQzKnOrEklasWhtxJXNMSgHy,isFolder=pLYdumiQzKnOrEklasWhtxJXNMSgwq,params=pLYdumiQzKnOrEklasWhtxJXNMSgcw)
  xbmcplugin.setContent(pLYdumiQzKnOrEklasWhtxJXNMSgqw._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(pLYdumiQzKnOrEklasWhtxJXNMSgqw._addon_handle,cacheToDisc=pLYdumiQzKnOrEklasWhtxJXNMSgHv)
 def dp_PopVod_GroupList(pLYdumiQzKnOrEklasWhtxJXNMSgqw,args):
  pLYdumiQzKnOrEklasWhtxJXNMSgqw.addon_log('dp_PopVod_GroupList ')
  pLYdumiQzKnOrEklasWhtxJXNMSgce=pLYdumiQzKnOrEklasWhtxJXNMSgqw.SpotvObj.GetPopularGroupList()
  pLYdumiQzKnOrEklasWhtxJXNMSgqw.addon_log('dp_PopVod_GroupList cnt : '+pLYdumiQzKnOrEklasWhtxJXNMSgwC(pLYdumiQzKnOrEklasWhtxJXNMSgwB(pLYdumiQzKnOrEklasWhtxJXNMSgce)))
  for pLYdumiQzKnOrEklasWhtxJXNMSgcb in pLYdumiQzKnOrEklasWhtxJXNMSgce:
   pLYdumiQzKnOrEklasWhtxJXNMSgcG =pLYdumiQzKnOrEklasWhtxJXNMSgcb.get('vodTitle')
   pLYdumiQzKnOrEklasWhtxJXNMSgcI =pLYdumiQzKnOrEklasWhtxJXNMSgcb.get('vodId')
   pLYdumiQzKnOrEklasWhtxJXNMSgcT =pLYdumiQzKnOrEklasWhtxJXNMSgcb.get('vodType')
   pLYdumiQzKnOrEklasWhtxJXNMSgcj=pLYdumiQzKnOrEklasWhtxJXNMSgcb.get('thumbnail')
   pLYdumiQzKnOrEklasWhtxJXNMSgcy =pLYdumiQzKnOrEklasWhtxJXNMSgcb.get('vtypeId')
   pLYdumiQzKnOrEklasWhtxJXNMSgcv =pLYdumiQzKnOrEklasWhtxJXNMSgcb.get('duration')
   pLYdumiQzKnOrEklasWhtxJXNMSgcf={'mediatype':'episode','duration':pLYdumiQzKnOrEklasWhtxJXNMSgcv,'plot':pLYdumiQzKnOrEklasWhtxJXNMSgcG}
   pLYdumiQzKnOrEklasWhtxJXNMSgcw={'mode':'POP_VOD','mediacode':pLYdumiQzKnOrEklasWhtxJXNMSgcI,'mediatype':'vod','vtypeId':pLYdumiQzKnOrEklasWhtxJXNMSgcy}
   pLYdumiQzKnOrEklasWhtxJXNMSgqw.add_dir(pLYdumiQzKnOrEklasWhtxJXNMSgcG,sublabel=pLYdumiQzKnOrEklasWhtxJXNMSgcT,img=pLYdumiQzKnOrEklasWhtxJXNMSgcj,infoLabels=pLYdumiQzKnOrEklasWhtxJXNMSgcf,isFolder=pLYdumiQzKnOrEklasWhtxJXNMSgHv,params=pLYdumiQzKnOrEklasWhtxJXNMSgcw)
  xbmcplugin.setContent(pLYdumiQzKnOrEklasWhtxJXNMSgqw._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(pLYdumiQzKnOrEklasWhtxJXNMSgqw._addon_handle,cacheToDisc=pLYdumiQzKnOrEklasWhtxJXNMSgHv)
 def dp_Season_List(pLYdumiQzKnOrEklasWhtxJXNMSgqw,args):
  pLYdumiQzKnOrEklasWhtxJXNMSgcP=args.get('reagueId')
  pLYdumiQzKnOrEklasWhtxJXNMSgqw.addon_log('Season_List - reagueId : '+pLYdumiQzKnOrEklasWhtxJXNMSgcP)
  pLYdumiQzKnOrEklasWhtxJXNMSgce=pLYdumiQzKnOrEklasWhtxJXNMSgqw.SpotvObj.GetSeasonList(pLYdumiQzKnOrEklasWhtxJXNMSgcP)
  for pLYdumiQzKnOrEklasWhtxJXNMSgcb in pLYdumiQzKnOrEklasWhtxJXNMSgce:
   pLYdumiQzKnOrEklasWhtxJXNMSgUo =pLYdumiQzKnOrEklasWhtxJXNMSgcb.get('reagueName')
   pLYdumiQzKnOrEklasWhtxJXNMSgUH =pLYdumiQzKnOrEklasWhtxJXNMSgcb.get('gameTypeId')
   pLYdumiQzKnOrEklasWhtxJXNMSgUw =pLYdumiQzKnOrEklasWhtxJXNMSgcb.get('seasonName')
   pLYdumiQzKnOrEklasWhtxJXNMSgUB =pLYdumiQzKnOrEklasWhtxJXNMSgcb.get('seasonId')
   pLYdumiQzKnOrEklasWhtxJXNMSgcf={'mediatype':'episode','plot':'%s - %s'%(pLYdumiQzKnOrEklasWhtxJXNMSgUo,pLYdumiQzKnOrEklasWhtxJXNMSgUw)}
   pLYdumiQzKnOrEklasWhtxJXNMSgcw={'mode':'SEASON_GROUP','reagueId':pLYdumiQzKnOrEklasWhtxJXNMSgcP,'seasonId':pLYdumiQzKnOrEklasWhtxJXNMSgUB,'gameTypeId':pLYdumiQzKnOrEklasWhtxJXNMSgUH,'page':'1'}
   pLYdumiQzKnOrEklasWhtxJXNMSgqw.add_dir(pLYdumiQzKnOrEklasWhtxJXNMSgUo,sublabel=pLYdumiQzKnOrEklasWhtxJXNMSgUw,img='',infoLabels=pLYdumiQzKnOrEklasWhtxJXNMSgcf,isFolder=pLYdumiQzKnOrEklasWhtxJXNMSgwq,params=pLYdumiQzKnOrEklasWhtxJXNMSgcw)
  if pLYdumiQzKnOrEklasWhtxJXNMSgwB(pLYdumiQzKnOrEklasWhtxJXNMSgce)>0:xbmcplugin.endOfDirectory(pLYdumiQzKnOrEklasWhtxJXNMSgqw._addon_handle,cacheToDisc=pLYdumiQzKnOrEklasWhtxJXNMSgwq)
 def dp_Game_List(pLYdumiQzKnOrEklasWhtxJXNMSgqw,args):
  pLYdumiQzKnOrEklasWhtxJXNMSgUH=args.get('gameTypeId')
  pLYdumiQzKnOrEklasWhtxJXNMSgcP =args.get('reagueId')
  pLYdumiQzKnOrEklasWhtxJXNMSgUB =args.get('seasonId')
  pLYdumiQzKnOrEklasWhtxJXNMSgcD =pLYdumiQzKnOrEklasWhtxJXNMSgwo(args.get('page'))
  pLYdumiQzKnOrEklasWhtxJXNMSgqw.addon_log('Game_List - gameTypeId : '+pLYdumiQzKnOrEklasWhtxJXNMSgUH)
  pLYdumiQzKnOrEklasWhtxJXNMSgqw.addon_log('Game_List - reagueId   : '+pLYdumiQzKnOrEklasWhtxJXNMSgcP)
  pLYdumiQzKnOrEklasWhtxJXNMSgqw.addon_log('Game_List - seasonId   : '+pLYdumiQzKnOrEklasWhtxJXNMSgUB)
  pLYdumiQzKnOrEklasWhtxJXNMSgce,pLYdumiQzKnOrEklasWhtxJXNMSgcV=pLYdumiQzKnOrEklasWhtxJXNMSgqw.SpotvObj.GetGameList(pLYdumiQzKnOrEklasWhtxJXNMSgUH,pLYdumiQzKnOrEklasWhtxJXNMSgcP,pLYdumiQzKnOrEklasWhtxJXNMSgUB,pLYdumiQzKnOrEklasWhtxJXNMSgcD,hidescore=pLYdumiQzKnOrEklasWhtxJXNMSgqw.get_settings_hidescoreyn())
  for pLYdumiQzKnOrEklasWhtxJXNMSgcb in pLYdumiQzKnOrEklasWhtxJXNMSgce:
   pLYdumiQzKnOrEklasWhtxJXNMSgUC =pLYdumiQzKnOrEklasWhtxJXNMSgcb.get('gameTitle')
   pLYdumiQzKnOrEklasWhtxJXNMSgUF =pLYdumiQzKnOrEklasWhtxJXNMSgcb.get('beginDate')
   pLYdumiQzKnOrEklasWhtxJXNMSgcj =pLYdumiQzKnOrEklasWhtxJXNMSgcb.get('thumbnail')
   pLYdumiQzKnOrEklasWhtxJXNMSgUR =pLYdumiQzKnOrEklasWhtxJXNMSgcb.get('gameId')
   pLYdumiQzKnOrEklasWhtxJXNMSgUe =pLYdumiQzKnOrEklasWhtxJXNMSgcb.get('totVodCnt')
   pLYdumiQzKnOrEklasWhtxJXNMSgUb =pLYdumiQzKnOrEklasWhtxJXNMSgcb.get('leaguenm')
   pLYdumiQzKnOrEklasWhtxJXNMSgUj =pLYdumiQzKnOrEklasWhtxJXNMSgcb.get('seasonnm')
   pLYdumiQzKnOrEklasWhtxJXNMSgUP =pLYdumiQzKnOrEklasWhtxJXNMSgcb.get('roundnm')
   pLYdumiQzKnOrEklasWhtxJXNMSgUA =pLYdumiQzKnOrEklasWhtxJXNMSgcb.get('info_plot')
   pLYdumiQzKnOrEklasWhtxJXNMSgUf ='%s < %s >'%(pLYdumiQzKnOrEklasWhtxJXNMSgUC,pLYdumiQzKnOrEklasWhtxJXNMSgUF)
   pLYdumiQzKnOrEklasWhtxJXNMSgcf={'mediatype':'video','plot':pLYdumiQzKnOrEklasWhtxJXNMSgUA}
   pLYdumiQzKnOrEklasWhtxJXNMSgcw={'mode':'GAME_VOD_GROUP' if pLYdumiQzKnOrEklasWhtxJXNMSgUe!=0 else 'XXX','saveTitle':pLYdumiQzKnOrEklasWhtxJXNMSgUf,'saveImg':pLYdumiQzKnOrEklasWhtxJXNMSgcj,'saveInfo':pLYdumiQzKnOrEklasWhtxJXNMSgcf['plot'],'gameid':pLYdumiQzKnOrEklasWhtxJXNMSgUR,'totVodCnt':pLYdumiQzKnOrEklasWhtxJXNMSgUe,}
   pLYdumiQzKnOrEklasWhtxJXNMSgqw.add_dir(pLYdumiQzKnOrEklasWhtxJXNMSgUC,sublabel=pLYdumiQzKnOrEklasWhtxJXNMSgUF,img=pLYdumiQzKnOrEklasWhtxJXNMSgcj,infoLabels=pLYdumiQzKnOrEklasWhtxJXNMSgcf,isFolder=pLYdumiQzKnOrEklasWhtxJXNMSgwq,params=pLYdumiQzKnOrEklasWhtxJXNMSgcw)
  if pLYdumiQzKnOrEklasWhtxJXNMSgcV:
   pLYdumiQzKnOrEklasWhtxJXNMSgcw['mode'] ='SEASON_GROUP' 
   pLYdumiQzKnOrEklasWhtxJXNMSgcw['reagueId'] =pLYdumiQzKnOrEklasWhtxJXNMSgcP
   pLYdumiQzKnOrEklasWhtxJXNMSgcw['seasonId'] =pLYdumiQzKnOrEklasWhtxJXNMSgUB
   pLYdumiQzKnOrEklasWhtxJXNMSgcw['gameTypeId']=pLYdumiQzKnOrEklasWhtxJXNMSgUH
   pLYdumiQzKnOrEklasWhtxJXNMSgcw['page'] =pLYdumiQzKnOrEklasWhtxJXNMSgwC(pLYdumiQzKnOrEklasWhtxJXNMSgcD+1)
   pLYdumiQzKnOrEklasWhtxJXNMSgqG='[B]%s >>[/B]'%'다음 페이지'
   pLYdumiQzKnOrEklasWhtxJXNMSgUq=pLYdumiQzKnOrEklasWhtxJXNMSgwC(pLYdumiQzKnOrEklasWhtxJXNMSgcD+1)
   pLYdumiQzKnOrEklasWhtxJXNMSgcH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   pLYdumiQzKnOrEklasWhtxJXNMSgqw.add_dir(pLYdumiQzKnOrEklasWhtxJXNMSgqG,sublabel=pLYdumiQzKnOrEklasWhtxJXNMSgUq,img=pLYdumiQzKnOrEklasWhtxJXNMSgcH,infoLabels=pLYdumiQzKnOrEklasWhtxJXNMSgHy,isFolder=pLYdumiQzKnOrEklasWhtxJXNMSgwq,params=pLYdumiQzKnOrEklasWhtxJXNMSgcw)
  if pLYdumiQzKnOrEklasWhtxJXNMSgwB(pLYdumiQzKnOrEklasWhtxJXNMSgce)>0:xbmcplugin.endOfDirectory(pLYdumiQzKnOrEklasWhtxJXNMSgqw._addon_handle,cacheToDisc=pLYdumiQzKnOrEklasWhtxJXNMSgHv)
 def dp_GameVod_List(pLYdumiQzKnOrEklasWhtxJXNMSgqw,args):
  pLYdumiQzKnOrEklasWhtxJXNMSgUD =args.get('gameid')
  pLYdumiQzKnOrEklasWhtxJXNMSgUf=args.get('saveTitle')
  pLYdumiQzKnOrEklasWhtxJXNMSgUV =args.get('saveImg')
  pLYdumiQzKnOrEklasWhtxJXNMSgUG =args.get('saveInfo')
  pLYdumiQzKnOrEklasWhtxJXNMSgce=pLYdumiQzKnOrEklasWhtxJXNMSgqw.SpotvObj.GetGameVodList(pLYdumiQzKnOrEklasWhtxJXNMSgUD)
  for pLYdumiQzKnOrEklasWhtxJXNMSgcb in pLYdumiQzKnOrEklasWhtxJXNMSgce:
   pLYdumiQzKnOrEklasWhtxJXNMSgcG =pLYdumiQzKnOrEklasWhtxJXNMSgcb.get('vodTitle')
   pLYdumiQzKnOrEklasWhtxJXNMSgcI =pLYdumiQzKnOrEklasWhtxJXNMSgcb.get('vodId')
   pLYdumiQzKnOrEklasWhtxJXNMSgcT =pLYdumiQzKnOrEklasWhtxJXNMSgcb.get('vodType')
   pLYdumiQzKnOrEklasWhtxJXNMSgcj=pLYdumiQzKnOrEklasWhtxJXNMSgcb.get('thumbnail')
   pLYdumiQzKnOrEklasWhtxJXNMSgcy =pLYdumiQzKnOrEklasWhtxJXNMSgcb.get('vtypeId')
   pLYdumiQzKnOrEklasWhtxJXNMSgcv =pLYdumiQzKnOrEklasWhtxJXNMSgcb.get('duration')
   pLYdumiQzKnOrEklasWhtxJXNMSgcf={'mediatype':'episode','duration':pLYdumiQzKnOrEklasWhtxJXNMSgcv,'plot':'%s \n\n %s'%(pLYdumiQzKnOrEklasWhtxJXNMSgcG,pLYdumiQzKnOrEklasWhtxJXNMSgUG)}
   pLYdumiQzKnOrEklasWhtxJXNMSgcw={'mode':'GAME_VOD','saveTitle':pLYdumiQzKnOrEklasWhtxJXNMSgUf,'saveImg':pLYdumiQzKnOrEklasWhtxJXNMSgUV,'saveId':pLYdumiQzKnOrEklasWhtxJXNMSgUD,'saveInfo':pLYdumiQzKnOrEklasWhtxJXNMSgUG,'mediacode':pLYdumiQzKnOrEklasWhtxJXNMSgcI,'mediatype':'vod','vtypeId':pLYdumiQzKnOrEklasWhtxJXNMSgcy}
   pLYdumiQzKnOrEklasWhtxJXNMSgqw.add_dir(pLYdumiQzKnOrEklasWhtxJXNMSgcG,sublabel=pLYdumiQzKnOrEklasWhtxJXNMSgcT,img=pLYdumiQzKnOrEklasWhtxJXNMSgcj,infoLabels=pLYdumiQzKnOrEklasWhtxJXNMSgcf,isFolder=pLYdumiQzKnOrEklasWhtxJXNMSgHv,params=pLYdumiQzKnOrEklasWhtxJXNMSgcw)
  xbmcplugin.setContent(pLYdumiQzKnOrEklasWhtxJXNMSgqw._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(pLYdumiQzKnOrEklasWhtxJXNMSgqw._addon_handle,cacheToDisc=pLYdumiQzKnOrEklasWhtxJXNMSgHv)
 def login_main(pLYdumiQzKnOrEklasWhtxJXNMSgqw):
  (pLYdumiQzKnOrEklasWhtxJXNMSgUI,pLYdumiQzKnOrEklasWhtxJXNMSgUT)=pLYdumiQzKnOrEklasWhtxJXNMSgqw.get_settings_account()
  if not(pLYdumiQzKnOrEklasWhtxJXNMSgUI and pLYdumiQzKnOrEklasWhtxJXNMSgUT):
   pLYdumiQzKnOrEklasWhtxJXNMSgqe=xbmcgui.Dialog()
   pLYdumiQzKnOrEklasWhtxJXNMSgUy=pLYdumiQzKnOrEklasWhtxJXNMSgqe.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if pLYdumiQzKnOrEklasWhtxJXNMSgUy==pLYdumiQzKnOrEklasWhtxJXNMSgwq:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if pLYdumiQzKnOrEklasWhtxJXNMSgqw.cookiefile_check():return
  if xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINWAIT')=='TRUE':
   pLYdumiQzKnOrEklasWhtxJXNMSgUv=0
   while pLYdumiQzKnOrEklasWhtxJXNMSgwq:
    pLYdumiQzKnOrEklasWhtxJXNMSgUv+=1
    time.sleep(0.05)
    if pLYdumiQzKnOrEklasWhtxJXNMSgUv>600:return
  else:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','TRUE')
  pLYdumiQzKnOrEklasWhtxJXNMSgoq=pLYdumiQzKnOrEklasWhtxJXNMSgqw.SpotvObj.GetCredential_new(pLYdumiQzKnOrEklasWhtxJXNMSgUI,pLYdumiQzKnOrEklasWhtxJXNMSgUT)
  if pLYdumiQzKnOrEklasWhtxJXNMSgoq:pLYdumiQzKnOrEklasWhtxJXNMSgqw.cookiefile_save()
  xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
  if pLYdumiQzKnOrEklasWhtxJXNMSgoq==pLYdumiQzKnOrEklasWhtxJXNMSgHv:
   pLYdumiQzKnOrEklasWhtxJXNMSgqw.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_LiveChannel_List(pLYdumiQzKnOrEklasWhtxJXNMSgqw,args):
  pLYdumiQzKnOrEklasWhtxJXNMSgoc=pLYdumiQzKnOrEklasWhtxJXNMSgqw.SpotvObj.GetLiveChannelList()
  for pLYdumiQzKnOrEklasWhtxJXNMSgoU in pLYdumiQzKnOrEklasWhtxJXNMSgoc:
   pLYdumiQzKnOrEklasWhtxJXNMSgwF =pLYdumiQzKnOrEklasWhtxJXNMSgoU.get('id')
   pLYdumiQzKnOrEklasWhtxJXNMSgqG =pLYdumiQzKnOrEklasWhtxJXNMSgoU.get('name')
   pLYdumiQzKnOrEklasWhtxJXNMSgcR =pLYdumiQzKnOrEklasWhtxJXNMSgoU.get('programName')
   pLYdumiQzKnOrEklasWhtxJXNMSgcj =pLYdumiQzKnOrEklasWhtxJXNMSgoU.get('logo')
   pLYdumiQzKnOrEklasWhtxJXNMSgoH=pLYdumiQzKnOrEklasWhtxJXNMSgoU.get('channelepg')
   pLYdumiQzKnOrEklasWhtxJXNMSgow =pLYdumiQzKnOrEklasWhtxJXNMSgoU.get('free')
   pLYdumiQzKnOrEklasWhtxJXNMSgcf={'plot':'%s\n\n%s'%(pLYdumiQzKnOrEklasWhtxJXNMSgqG,pLYdumiQzKnOrEklasWhtxJXNMSgoH),'mediatype':'episode',}
   pLYdumiQzKnOrEklasWhtxJXNMSgcw={'mode':'LIVE','mediacode':pLYdumiQzKnOrEklasWhtxJXNMSgwF,'free':pLYdumiQzKnOrEklasWhtxJXNMSgow,'mediatype':'live'}
   if pLYdumiQzKnOrEklasWhtxJXNMSgow:pLYdumiQzKnOrEklasWhtxJXNMSgqG+=' [free]'
   pLYdumiQzKnOrEklasWhtxJXNMSgqw.add_dir(pLYdumiQzKnOrEklasWhtxJXNMSgqG,sublabel=pLYdumiQzKnOrEklasWhtxJXNMSgcR,img=pLYdumiQzKnOrEklasWhtxJXNMSgcj,infoLabels=pLYdumiQzKnOrEklasWhtxJXNMSgcf,isFolder=pLYdumiQzKnOrEklasWhtxJXNMSgHv,params=pLYdumiQzKnOrEklasWhtxJXNMSgcw)
  xbmcplugin.setContent(pLYdumiQzKnOrEklasWhtxJXNMSgqw._addon_handle,'episodes')
  if pLYdumiQzKnOrEklasWhtxJXNMSgwB(pLYdumiQzKnOrEklasWhtxJXNMSgoc)>0:xbmcplugin.endOfDirectory(pLYdumiQzKnOrEklasWhtxJXNMSgqw._addon_handle,cacheToDisc=pLYdumiQzKnOrEklasWhtxJXNMSgHv)
 def dp_EventLiveChannel_List(pLYdumiQzKnOrEklasWhtxJXNMSgqw,args):
  pLYdumiQzKnOrEklasWhtxJXNMSgoc,pLYdumiQzKnOrEklasWhtxJXNMSgoB=pLYdumiQzKnOrEklasWhtxJXNMSgqw.SpotvObj.GetEventLiveList()
  if pLYdumiQzKnOrEklasWhtxJXNMSgoB!=401 and pLYdumiQzKnOrEklasWhtxJXNMSgwB(pLYdumiQzKnOrEklasWhtxJXNMSgoc)==0:
   pLYdumiQzKnOrEklasWhtxJXNMSgqw.addon_noti(__language__(30907).encode('utf8'))
  for pLYdumiQzKnOrEklasWhtxJXNMSgoU in pLYdumiQzKnOrEklasWhtxJXNMSgoc:
   pLYdumiQzKnOrEklasWhtxJXNMSgqG =pLYdumiQzKnOrEklasWhtxJXNMSgoU.get('title')
   pLYdumiQzKnOrEklasWhtxJXNMSgcR =pLYdumiQzKnOrEklasWhtxJXNMSgoU.get('startTime')
   pLYdumiQzKnOrEklasWhtxJXNMSgcj =pLYdumiQzKnOrEklasWhtxJXNMSgoU.get('logo')
   pLYdumiQzKnOrEklasWhtxJXNMSgow =pLYdumiQzKnOrEklasWhtxJXNMSgoU.get('free')
   pLYdumiQzKnOrEklasWhtxJXNMSgcf={'mediatype':'episode','plot':'%s\n\n%s'%(pLYdumiQzKnOrEklasWhtxJXNMSgqG,pLYdumiQzKnOrEklasWhtxJXNMSgcR)}
   pLYdumiQzKnOrEklasWhtxJXNMSgcw={'mode':'ELIVE','mediacode':pLYdumiQzKnOrEklasWhtxJXNMSgoU.get('liveId'),'free':pLYdumiQzKnOrEklasWhtxJXNMSgow,'mediatype':'live'}
   if pLYdumiQzKnOrEklasWhtxJXNMSgow:pLYdumiQzKnOrEklasWhtxJXNMSgqG+=' [free]'
   pLYdumiQzKnOrEklasWhtxJXNMSgqw.add_dir(pLYdumiQzKnOrEklasWhtxJXNMSgqG,sublabel=pLYdumiQzKnOrEklasWhtxJXNMSgcR,img=pLYdumiQzKnOrEklasWhtxJXNMSgcj,infoLabels=pLYdumiQzKnOrEklasWhtxJXNMSgcf,isFolder=pLYdumiQzKnOrEklasWhtxJXNMSgHv,params=pLYdumiQzKnOrEklasWhtxJXNMSgcw)
  xbmcplugin.setContent(pLYdumiQzKnOrEklasWhtxJXNMSgqw._addon_handle,'episodes')
  if pLYdumiQzKnOrEklasWhtxJXNMSgwB(pLYdumiQzKnOrEklasWhtxJXNMSgoc)>0:xbmcplugin.endOfDirectory(pLYdumiQzKnOrEklasWhtxJXNMSgqw._addon_handle,cacheToDisc=pLYdumiQzKnOrEklasWhtxJXNMSgwq)
  return pLYdumiQzKnOrEklasWhtxJXNMSgoB
 def play_VIDEO(pLYdumiQzKnOrEklasWhtxJXNMSgqw,args):
  pLYdumiQzKnOrEklasWhtxJXNMSgoC =args.get('mode')
  pLYdumiQzKnOrEklasWhtxJXNMSgoF =args.get('mediacode')
  pLYdumiQzKnOrEklasWhtxJXNMSgoR =args.get('mediatype')
  pLYdumiQzKnOrEklasWhtxJXNMSgcy =args.get('vtypeId')
  pLYdumiQzKnOrEklasWhtxJXNMSgoe =args.get('hlsUrl')
  if pLYdumiQzKnOrEklasWhtxJXNMSgoC=='LIVE':
   if args.get('free')=='False':
    if pLYdumiQzKnOrEklasWhtxJXNMSgqw.SpotvObj.CheckSubEnd()==pLYdumiQzKnOrEklasWhtxJXNMSgHv:
     pLYdumiQzKnOrEklasWhtxJXNMSgqw.addon_noti(__language__(30908).encode('utf8'))
     return
  elif pLYdumiQzKnOrEklasWhtxJXNMSgoC=='ELIVE':
   if args.get('free')=='False':
    if pLYdumiQzKnOrEklasWhtxJXNMSgqw.SpotvObj.CheckSubEnd()==pLYdumiQzKnOrEklasWhtxJXNMSgHv:
     pLYdumiQzKnOrEklasWhtxJXNMSgqw.addon_noti(__language__(30908).encode('utf8'))
     return
  if pLYdumiQzKnOrEklasWhtxJXNMSgoF=='' or pLYdumiQzKnOrEklasWhtxJXNMSgoF==pLYdumiQzKnOrEklasWhtxJXNMSgHy:
   pLYdumiQzKnOrEklasWhtxJXNMSgqw.addon_noti(__language__(30907).encode('utf8'))
   return
  if pLYdumiQzKnOrEklasWhtxJXNMSgoC=='LIVE':
   pLYdumiQzKnOrEklasWhtxJXNMSgob=pLYdumiQzKnOrEklasWhtxJXNMSgqw.SpotvObj.GetHlsUrl(pLYdumiQzKnOrEklasWhtxJXNMSgoF)
  else:
   pLYdumiQzKnOrEklasWhtxJXNMSgqw.addon_log('mediacode : '+pLYdumiQzKnOrEklasWhtxJXNMSgoF)
   pLYdumiQzKnOrEklasWhtxJXNMSgqw.addon_log('mediatype : '+pLYdumiQzKnOrEklasWhtxJXNMSgoR)
   pLYdumiQzKnOrEklasWhtxJXNMSgqw.addon_log('vtypeId   : '+pLYdumiQzKnOrEklasWhtxJXNMSgwC(pLYdumiQzKnOrEklasWhtxJXNMSgcy))
   pLYdumiQzKnOrEklasWhtxJXNMSgob=pLYdumiQzKnOrEklasWhtxJXNMSgqw.SpotvObj.GetBroadURL(pLYdumiQzKnOrEklasWhtxJXNMSgoF,pLYdumiQzKnOrEklasWhtxJXNMSgoR,pLYdumiQzKnOrEklasWhtxJXNMSgcy)
  if pLYdumiQzKnOrEklasWhtxJXNMSgob=='':
   pLYdumiQzKnOrEklasWhtxJXNMSgqw.addon_noti(__language__(30908).encode('utf8'))
   return
  pLYdumiQzKnOrEklasWhtxJXNMSgoj=pLYdumiQzKnOrEklasWhtxJXNMSgob
  try:
   pLYdumiQzKnOrEklasWhtxJXNMSgqw.addon_log('mainMode  = '+pLYdumiQzKnOrEklasWhtxJXNMSgoC)
  except:
   pLYdumiQzKnOrEklasWhtxJXNMSgHy
  pLYdumiQzKnOrEklasWhtxJXNMSgqw.addon_log(pLYdumiQzKnOrEklasWhtxJXNMSgoj)
  pLYdumiQzKnOrEklasWhtxJXNMSgoP=xbmcgui.ListItem(path=pLYdumiQzKnOrEklasWhtxJXNMSgoj)
  xbmcplugin.setResolvedUrl(pLYdumiQzKnOrEklasWhtxJXNMSgqw._addon_handle,pLYdumiQzKnOrEklasWhtxJXNMSgwq,pLYdumiQzKnOrEklasWhtxJXNMSgoP)
  try:
   if pLYdumiQzKnOrEklasWhtxJXNMSgoR=='vod' and pLYdumiQzKnOrEklasWhtxJXNMSgoC not in['POP_VOD','NOW_VOD']:
    pLYdumiQzKnOrEklasWhtxJXNMSgcw={'code':args.get('saveId'),'img':args.get('saveImg'),'title':args.get('saveTitle'),'info':args.get('saveInfo')}
    pLYdumiQzKnOrEklasWhtxJXNMSgqw.Save_Watched_List(pLYdumiQzKnOrEklasWhtxJXNMSgoR,pLYdumiQzKnOrEklasWhtxJXNMSgcw)
  except:
   pLYdumiQzKnOrEklasWhtxJXNMSgHy
 def logout(pLYdumiQzKnOrEklasWhtxJXNMSgqw):
  pLYdumiQzKnOrEklasWhtxJXNMSgqe=xbmcgui.Dialog()
  pLYdumiQzKnOrEklasWhtxJXNMSgUy=pLYdumiQzKnOrEklasWhtxJXNMSgqe.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if pLYdumiQzKnOrEklasWhtxJXNMSgUy==pLYdumiQzKnOrEklasWhtxJXNMSgHv:sys.exit()
  pLYdumiQzKnOrEklasWhtxJXNMSgqw.SpotvObj.Init_ST_Total()
  if os.path.isfile(pLYdumiQzKnOrEklasWhtxJXNMSgqH):os.remove(pLYdumiQzKnOrEklasWhtxJXNMSgqH)
  pLYdumiQzKnOrEklasWhtxJXNMSgqw.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(pLYdumiQzKnOrEklasWhtxJXNMSgqw):
  pLYdumiQzKnOrEklasWhtxJXNMSgoA =pLYdumiQzKnOrEklasWhtxJXNMSgqw.SpotvObj.Get_Now_Datetime()
  pLYdumiQzKnOrEklasWhtxJXNMSgof=pLYdumiQzKnOrEklasWhtxJXNMSgoA+datetime.timedelta(days=pLYdumiQzKnOrEklasWhtxJXNMSgwo(__addon__.getSetting('cache_ttl')))
  (pLYdumiQzKnOrEklasWhtxJXNMSgUI,pLYdumiQzKnOrEklasWhtxJXNMSgUT)=pLYdumiQzKnOrEklasWhtxJXNMSgqw.get_settings_account()
  pLYdumiQzKnOrEklasWhtxJXNMSgqw.SpotvObj.Save_session_acount(pLYdumiQzKnOrEklasWhtxJXNMSgUI,pLYdumiQzKnOrEklasWhtxJXNMSgUT)
  pLYdumiQzKnOrEklasWhtxJXNMSgqw.SpotvObj.ST['account']['token_limit']=pLYdumiQzKnOrEklasWhtxJXNMSgof.strftime('%Y%m%d')
  pLYdumiQzKnOrEklasWhtxJXNMSgqw.SpotvObj.JsonFile_Save(pLYdumiQzKnOrEklasWhtxJXNMSgqH,pLYdumiQzKnOrEklasWhtxJXNMSgqw.SpotvObj.ST)
 def cookiefile_check(pLYdumiQzKnOrEklasWhtxJXNMSgqw):
  pLYdumiQzKnOrEklasWhtxJXNMSgqw.SpotvObj.ST=pLYdumiQzKnOrEklasWhtxJXNMSgqw.SpotvObj.JsonFile_Load(pLYdumiQzKnOrEklasWhtxJXNMSgqH)
  if 'account' not in pLYdumiQzKnOrEklasWhtxJXNMSgqw.SpotvObj.ST:
   pLYdumiQzKnOrEklasWhtxJXNMSgqw.SpotvObj.Init_ST_Total()
   return pLYdumiQzKnOrEklasWhtxJXNMSgHv
  (pLYdumiQzKnOrEklasWhtxJXNMSgoD,pLYdumiQzKnOrEklasWhtxJXNMSgoV)=pLYdumiQzKnOrEklasWhtxJXNMSgqw.get_settings_account()
  (pLYdumiQzKnOrEklasWhtxJXNMSgoG,pLYdumiQzKnOrEklasWhtxJXNMSgoI)=pLYdumiQzKnOrEklasWhtxJXNMSgqw.SpotvObj.Load_session_acount()
  if pLYdumiQzKnOrEklasWhtxJXNMSgoD!=pLYdumiQzKnOrEklasWhtxJXNMSgoG or pLYdumiQzKnOrEklasWhtxJXNMSgoV!=pLYdumiQzKnOrEklasWhtxJXNMSgoI:
   pLYdumiQzKnOrEklasWhtxJXNMSgqw.SpotvObj.Init_ST_Total()
   return pLYdumiQzKnOrEklasWhtxJXNMSgHv
  if pLYdumiQzKnOrEklasWhtxJXNMSgwo(pLYdumiQzKnOrEklasWhtxJXNMSgqw.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))>pLYdumiQzKnOrEklasWhtxJXNMSgwo(pLYdumiQzKnOrEklasWhtxJXNMSgqw.SpotvObj.ST['account']['token_limit']):
   pLYdumiQzKnOrEklasWhtxJXNMSgqw.SpotvObj.Init_ST_Total()
   return pLYdumiQzKnOrEklasWhtxJXNMSgHv
  return pLYdumiQzKnOrEklasWhtxJXNMSgwq
 def dp_History_Remove(pLYdumiQzKnOrEklasWhtxJXNMSgqw,args):
  pLYdumiQzKnOrEklasWhtxJXNMSgoT=args.get('delType')
  pLYdumiQzKnOrEklasWhtxJXNMSgoy =args.get('sKey')
  pLYdumiQzKnOrEklasWhtxJXNMSgov =args.get('vType')
  pLYdumiQzKnOrEklasWhtxJXNMSgqe=xbmcgui.Dialog()
  if pLYdumiQzKnOrEklasWhtxJXNMSgoT=='WATCH_ALL':
   pLYdumiQzKnOrEklasWhtxJXNMSgUy=pLYdumiQzKnOrEklasWhtxJXNMSgqe.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif pLYdumiQzKnOrEklasWhtxJXNMSgoT=='WATCH_ONE':
   pLYdumiQzKnOrEklasWhtxJXNMSgUy=pLYdumiQzKnOrEklasWhtxJXNMSgqe.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  if pLYdumiQzKnOrEklasWhtxJXNMSgUy==pLYdumiQzKnOrEklasWhtxJXNMSgHv:sys.exit()
  if pLYdumiQzKnOrEklasWhtxJXNMSgoT=='WATCH_ALL':
   pLYdumiQzKnOrEklasWhtxJXNMSgHq=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%pLYdumiQzKnOrEklasWhtxJXNMSgov))
   if os.path.isfile(pLYdumiQzKnOrEklasWhtxJXNMSgHq):os.remove(pLYdumiQzKnOrEklasWhtxJXNMSgHq)
  elif pLYdumiQzKnOrEklasWhtxJXNMSgoT=='WATCH_ONE':
   pLYdumiQzKnOrEklasWhtxJXNMSgHq=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%pLYdumiQzKnOrEklasWhtxJXNMSgov))
   try:
    pLYdumiQzKnOrEklasWhtxJXNMSgHc=pLYdumiQzKnOrEklasWhtxJXNMSgqw.Load_List_File(pLYdumiQzKnOrEklasWhtxJXNMSgov) 
    fp=pLYdumiQzKnOrEklasWhtxJXNMSgwR(pLYdumiQzKnOrEklasWhtxJXNMSgHq,'w',-1,'utf-8')
    for pLYdumiQzKnOrEklasWhtxJXNMSgHU in pLYdumiQzKnOrEklasWhtxJXNMSgHc:
     pLYdumiQzKnOrEklasWhtxJXNMSgHo=pLYdumiQzKnOrEklasWhtxJXNMSgwe(urllib.parse.parse_qsl(pLYdumiQzKnOrEklasWhtxJXNMSgHU))
     pLYdumiQzKnOrEklasWhtxJXNMSgHw=pLYdumiQzKnOrEklasWhtxJXNMSgHo.get('code').strip()
     if pLYdumiQzKnOrEklasWhtxJXNMSgoy!=pLYdumiQzKnOrEklasWhtxJXNMSgHw:
      fp.write(pLYdumiQzKnOrEklasWhtxJXNMSgHU)
    fp.close()
   except:
    pLYdumiQzKnOrEklasWhtxJXNMSgHy
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(pLYdumiQzKnOrEklasWhtxJXNMSgqw,pLYdumiQzKnOrEklasWhtxJXNMSgoR):
  try:
   pLYdumiQzKnOrEklasWhtxJXNMSgHB=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%pLYdumiQzKnOrEklasWhtxJXNMSgoR))
   fp=pLYdumiQzKnOrEklasWhtxJXNMSgwR(pLYdumiQzKnOrEklasWhtxJXNMSgHB,'r',-1,'utf-8')
   pLYdumiQzKnOrEklasWhtxJXNMSgHC=fp.readlines()
   fp.close()
  except:
   pLYdumiQzKnOrEklasWhtxJXNMSgHC=[]
  return pLYdumiQzKnOrEklasWhtxJXNMSgHC
 def Save_Watched_List(pLYdumiQzKnOrEklasWhtxJXNMSgqw,stype,pLYdumiQzKnOrEklasWhtxJXNMSgqF):
  try:
   pLYdumiQzKnOrEklasWhtxJXNMSgHB=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   pLYdumiQzKnOrEklasWhtxJXNMSgHc=pLYdumiQzKnOrEklasWhtxJXNMSgqw.Load_List_File(stype) 
   fp=pLYdumiQzKnOrEklasWhtxJXNMSgwR(pLYdumiQzKnOrEklasWhtxJXNMSgHB,'w',-1,'utf-8')
   pLYdumiQzKnOrEklasWhtxJXNMSgHF=urllib.parse.urlencode(pLYdumiQzKnOrEklasWhtxJXNMSgqF)
   pLYdumiQzKnOrEklasWhtxJXNMSgHF=pLYdumiQzKnOrEklasWhtxJXNMSgHF+'\n'
   fp.write(pLYdumiQzKnOrEklasWhtxJXNMSgHF)
   pLYdumiQzKnOrEklasWhtxJXNMSgHR=0
   for pLYdumiQzKnOrEklasWhtxJXNMSgHU in pLYdumiQzKnOrEklasWhtxJXNMSgHc:
    pLYdumiQzKnOrEklasWhtxJXNMSgHo=pLYdumiQzKnOrEklasWhtxJXNMSgwe(urllib.parse.parse_qsl(pLYdumiQzKnOrEklasWhtxJXNMSgHU))
    pLYdumiQzKnOrEklasWhtxJXNMSgHe=pLYdumiQzKnOrEklasWhtxJXNMSgqF.get('code')
    pLYdumiQzKnOrEklasWhtxJXNMSgHb=pLYdumiQzKnOrEklasWhtxJXNMSgHo.get('code')
    if pLYdumiQzKnOrEklasWhtxJXNMSgHe!=pLYdumiQzKnOrEklasWhtxJXNMSgHb:
     fp.write(pLYdumiQzKnOrEklasWhtxJXNMSgHU)
     pLYdumiQzKnOrEklasWhtxJXNMSgHR+=1
     if pLYdumiQzKnOrEklasWhtxJXNMSgHR>=50:break
   fp.close()
  except:
   pLYdumiQzKnOrEklasWhtxJXNMSgHy
 def dp_Watch_List(pLYdumiQzKnOrEklasWhtxJXNMSgqw,args):
  pLYdumiQzKnOrEklasWhtxJXNMSgoR ='vod'
  if pLYdumiQzKnOrEklasWhtxJXNMSgoR=='vod':
   pLYdumiQzKnOrEklasWhtxJXNMSgHj=pLYdumiQzKnOrEklasWhtxJXNMSgqw.Load_List_File(pLYdumiQzKnOrEklasWhtxJXNMSgoR)
   for pLYdumiQzKnOrEklasWhtxJXNMSgHP in pLYdumiQzKnOrEklasWhtxJXNMSgHj:
    pLYdumiQzKnOrEklasWhtxJXNMSgHA=pLYdumiQzKnOrEklasWhtxJXNMSgwe(urllib.parse.parse_qsl(pLYdumiQzKnOrEklasWhtxJXNMSgHP))
    pLYdumiQzKnOrEklasWhtxJXNMSgqG =pLYdumiQzKnOrEklasWhtxJXNMSgHA.get('title')
    pLYdumiQzKnOrEklasWhtxJXNMSgcj=pLYdumiQzKnOrEklasWhtxJXNMSgHA.get('img')
    pLYdumiQzKnOrEklasWhtxJXNMSgoF=pLYdumiQzKnOrEklasWhtxJXNMSgHA.get('code')
    pLYdumiQzKnOrEklasWhtxJXNMSgHf =pLYdumiQzKnOrEklasWhtxJXNMSgHA.get('info')
    pLYdumiQzKnOrEklasWhtxJXNMSgcf={}
    pLYdumiQzKnOrEklasWhtxJXNMSgcf['plot'] =pLYdumiQzKnOrEklasWhtxJXNMSgHf
    pLYdumiQzKnOrEklasWhtxJXNMSgcf['mediatype']='tvshow'
    pLYdumiQzKnOrEklasWhtxJXNMSgcw={'mode':'GAME_VOD_GROUP','gameid':pLYdumiQzKnOrEklasWhtxJXNMSgoF,'saveTitle':pLYdumiQzKnOrEklasWhtxJXNMSgqG,'saveImg':pLYdumiQzKnOrEklasWhtxJXNMSgcj,'saveInfo':pLYdumiQzKnOrEklasWhtxJXNMSgHf,'mediatype':pLYdumiQzKnOrEklasWhtxJXNMSgoR}
    pLYdumiQzKnOrEklasWhtxJXNMSgHD={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':pLYdumiQzKnOrEklasWhtxJXNMSgoF,'vType':pLYdumiQzKnOrEklasWhtxJXNMSgoR,}
    pLYdumiQzKnOrEklasWhtxJXNMSgHV=urllib.parse.urlencode(pLYdumiQzKnOrEklasWhtxJXNMSgHD)
    pLYdumiQzKnOrEklasWhtxJXNMSgHG=[('선택된 시청이력 ( %s ) 삭제'%(pLYdumiQzKnOrEklasWhtxJXNMSgqG),'RunPlugin(plugin://plugin.video.spotvm/?%s)'%(pLYdumiQzKnOrEklasWhtxJXNMSgHV))]
    pLYdumiQzKnOrEklasWhtxJXNMSgqw.add_dir(pLYdumiQzKnOrEklasWhtxJXNMSgqG,sublabel='',img=pLYdumiQzKnOrEklasWhtxJXNMSgcj,infoLabels=pLYdumiQzKnOrEklasWhtxJXNMSgcf,isFolder=pLYdumiQzKnOrEklasWhtxJXNMSgwq,params=pLYdumiQzKnOrEklasWhtxJXNMSgcw,ContextMenu=pLYdumiQzKnOrEklasWhtxJXNMSgHG)
   pLYdumiQzKnOrEklasWhtxJXNMSgcf={'plot':'시청목록을 삭제합니다.'}
   pLYdumiQzKnOrEklasWhtxJXNMSgqG='*** 시청목록 삭제 ***'
   pLYdumiQzKnOrEklasWhtxJXNMSgcw={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':pLYdumiQzKnOrEklasWhtxJXNMSgoR,}
   pLYdumiQzKnOrEklasWhtxJXNMSgcH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   pLYdumiQzKnOrEklasWhtxJXNMSgqw.add_dir(pLYdumiQzKnOrEklasWhtxJXNMSgqG,sublabel='',img=pLYdumiQzKnOrEklasWhtxJXNMSgcH,infoLabels=pLYdumiQzKnOrEklasWhtxJXNMSgcf,isFolder=pLYdumiQzKnOrEklasWhtxJXNMSgHv,params=pLYdumiQzKnOrEklasWhtxJXNMSgcw,isLink=pLYdumiQzKnOrEklasWhtxJXNMSgwq)
   xbmcplugin.endOfDirectory(pLYdumiQzKnOrEklasWhtxJXNMSgqw._addon_handle,cacheToDisc=pLYdumiQzKnOrEklasWhtxJXNMSgHv)
 def spotv_main(pLYdumiQzKnOrEklasWhtxJXNMSgqw):
  pLYdumiQzKnOrEklasWhtxJXNMSgqw.SpotvObj.KodiVersion=pLYdumiQzKnOrEklasWhtxJXNMSgwo(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  pLYdumiQzKnOrEklasWhtxJXNMSgHI=pLYdumiQzKnOrEklasWhtxJXNMSgqw.main_params.get('mode',pLYdumiQzKnOrEklasWhtxJXNMSgHy)
  if pLYdumiQzKnOrEklasWhtxJXNMSgHI=='LOGOUT':
   pLYdumiQzKnOrEklasWhtxJXNMSgqw.logout()
   return
  pLYdumiQzKnOrEklasWhtxJXNMSgqw.login_main()
  if pLYdumiQzKnOrEklasWhtxJXNMSgHI is pLYdumiQzKnOrEklasWhtxJXNMSgHy:
   pLYdumiQzKnOrEklasWhtxJXNMSgqw.dp_Main_List()
  elif pLYdumiQzKnOrEklasWhtxJXNMSgHI=='LIVE_GROUP':
   pLYdumiQzKnOrEklasWhtxJXNMSgqw.dp_LiveChannel_List(pLYdumiQzKnOrEklasWhtxJXNMSgqw.main_params)
  elif pLYdumiQzKnOrEklasWhtxJXNMSgHI=='ELIVE_GROUP':
   pLYdumiQzKnOrEklasWhtxJXNMSgoB=pLYdumiQzKnOrEklasWhtxJXNMSgqw.dp_EventLiveChannel_List(pLYdumiQzKnOrEklasWhtxJXNMSgqw.main_params)
   if pLYdumiQzKnOrEklasWhtxJXNMSgoB==401:
    if os.path.isfile(pLYdumiQzKnOrEklasWhtxJXNMSgqH):os.remove(pLYdumiQzKnOrEklasWhtxJXNMSgqH)
    pLYdumiQzKnOrEklasWhtxJXNMSgqw.login_main()
    pLYdumiQzKnOrEklasWhtxJXNMSgqw.dp_EventLiveChannel_List(pLYdumiQzKnOrEklasWhtxJXNMSgqw.main_params)
  elif pLYdumiQzKnOrEklasWhtxJXNMSgHI in['LIVE','GAME_VOD','POP_VOD','NOW_VOD','ELIVE']:
   pLYdumiQzKnOrEklasWhtxJXNMSgqw.play_VIDEO(pLYdumiQzKnOrEklasWhtxJXNMSgqw.main_params)
  elif pLYdumiQzKnOrEklasWhtxJXNMSgHI=='VOD_GROUP':
   pLYdumiQzKnOrEklasWhtxJXNMSgqw.dp_MainLeague_List(pLYdumiQzKnOrEklasWhtxJXNMSgqw.main_params)
  elif pLYdumiQzKnOrEklasWhtxJXNMSgHI=='NOW_GROUP':
   pLYdumiQzKnOrEklasWhtxJXNMSgqw.dp_NowVod_GroupList(pLYdumiQzKnOrEklasWhtxJXNMSgqw.main_params)
  elif pLYdumiQzKnOrEklasWhtxJXNMSgHI=='POP_GROUP':
   pLYdumiQzKnOrEklasWhtxJXNMSgqw.dp_PopVod_GroupList(pLYdumiQzKnOrEklasWhtxJXNMSgqw.main_params)
  elif pLYdumiQzKnOrEklasWhtxJXNMSgHI=='LEAGUE_GROUP':
   pLYdumiQzKnOrEklasWhtxJXNMSgqw.dp_Season_List(pLYdumiQzKnOrEklasWhtxJXNMSgqw.main_params)
  elif pLYdumiQzKnOrEklasWhtxJXNMSgHI=='SEASON_GROUP':
   pLYdumiQzKnOrEklasWhtxJXNMSgqw.dp_Game_List(pLYdumiQzKnOrEklasWhtxJXNMSgqw.main_params)
  elif pLYdumiQzKnOrEklasWhtxJXNMSgHI=='GAME_VOD_GROUP':
   pLYdumiQzKnOrEklasWhtxJXNMSgqw.dp_GameVod_List(pLYdumiQzKnOrEklasWhtxJXNMSgqw.main_params)
  elif pLYdumiQzKnOrEklasWhtxJXNMSgHI=='WATCH':
   pLYdumiQzKnOrEklasWhtxJXNMSgqw.dp_Watch_List(pLYdumiQzKnOrEklasWhtxJXNMSgqw.main_params)
  elif pLYdumiQzKnOrEklasWhtxJXNMSgHI=='MYVIEW_REMOVE':
   pLYdumiQzKnOrEklasWhtxJXNMSgqw.dp_History_Remove(pLYdumiQzKnOrEklasWhtxJXNMSgqw.main_params)
  else:
   pLYdumiQzKnOrEklasWhtxJXNMSgHy
# Created by pyminifier (https://github.com/liftoff/pyminifier)
