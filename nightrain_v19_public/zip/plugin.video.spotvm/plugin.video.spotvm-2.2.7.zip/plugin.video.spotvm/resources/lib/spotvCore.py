__author__="NightRain"
CtKSbPvNdaIXTBJjiRflpALwVrqhek=object
CtKSbPvNdaIXTBJjiRflpALwVrqhey=None
CtKSbPvNdaIXTBJjiRflpALwVrqhes=False
CtKSbPvNdaIXTBJjiRflpALwVrqhez=str
CtKSbPvNdaIXTBJjiRflpALwVrqheg=open
CtKSbPvNdaIXTBJjiRflpALwVrqheG=True
CtKSbPvNdaIXTBJjiRflpALwVrqhem=int
CtKSbPvNdaIXTBJjiRflpALwVrqhec=Exception
CtKSbPvNdaIXTBJjiRflpALwVrqhxO=print
CtKSbPvNdaIXTBJjiRflpALwVrqhxM=len
CtKSbPvNdaIXTBJjiRflpALwVrqhxF=range
import urllib
import re
import json
import sys
import time
import requests
import datetime
import base64
import random
CtKSbPvNdaIXTBJjiRflpALwVrqhOF={'stream50':1080,'stream40':720,'stream30':540}
class CtKSbPvNdaIXTBJjiRflpALwVrqhOM(CtKSbPvNdaIXTBJjiRflpALwVrqhek):
 def __init__(CtKSbPvNdaIXTBJjiRflpALwVrqhOn):
  CtKSbPvNdaIXTBJjiRflpALwVrqhOn.SPOTV_PMCODE ='987'
  CtKSbPvNdaIXTBJjiRflpALwVrqhOn.SPOTV_PMSIZE =3
  CtKSbPvNdaIXTBJjiRflpALwVrqhOn.GAMELIST_LIMIT =10
  CtKSbPvNdaIXTBJjiRflpALwVrqhOn.API_DOMAIN ='https://www.spotvnow.co.kr'
  CtKSbPvNdaIXTBJjiRflpALwVrqhOn.BC_DOMAIN ='https://players.brightcove.net'
  CtKSbPvNdaIXTBJjiRflpALwVrqhOn.PLAYER_DOMAIN ='https://edge.api.brightcove.com'
  CtKSbPvNdaIXTBJjiRflpALwVrqhOn.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36'
  CtKSbPvNdaIXTBJjiRflpALwVrqhOn.DEFAULT_HEADER ={'user-agent':CtKSbPvNdaIXTBJjiRflpALwVrqhOn.USER_AGENT}
  CtKSbPvNdaIXTBJjiRflpALwVrqhOn.COOKIE_FILE_NAME=''
  CtKSbPvNdaIXTBJjiRflpALwVrqhOn.KodiVersion =20
  CtKSbPvNdaIXTBJjiRflpALwVrqhOn.ST ={}
  CtKSbPvNdaIXTBJjiRflpALwVrqhOn.Init_ST_Total()
 def Init_ST_Total(CtKSbPvNdaIXTBJjiRflpALwVrqhOn):
  CtKSbPvNdaIXTBJjiRflpALwVrqhOn.ST={'account':{},'cookies':{},}
 def addon_log(CtKSbPvNdaIXTBJjiRflpALwVrqhOn,string):
  import xbmcaddon,xbmc
  __version__=xbmcaddon.Addon().getAddonInfo('version')
  __addonid__=xbmcaddon.Addon().getAddonInfo('id')
  try:
   CtKSbPvNdaIXTBJjiRflpALwVrqhOe=string.encode('utf-8','ignore')
  except:
   CtKSbPvNdaIXTBJjiRflpALwVrqhOe='addonException: addon_log'
  CtKSbPvNdaIXTBJjiRflpALwVrqhOx=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,CtKSbPvNdaIXTBJjiRflpALwVrqhOe),level=CtKSbPvNdaIXTBJjiRflpALwVrqhOx)
 def callRequestCookies(CtKSbPvNdaIXTBJjiRflpALwVrqhOn,jobtype,CtKSbPvNdaIXTBJjiRflpALwVrqhOs,payload=CtKSbPvNdaIXTBJjiRflpALwVrqhey,json=CtKSbPvNdaIXTBJjiRflpALwVrqhey,params=CtKSbPvNdaIXTBJjiRflpALwVrqhey,headers=CtKSbPvNdaIXTBJjiRflpALwVrqhey,cookies=CtKSbPvNdaIXTBJjiRflpALwVrqhey,redirects=CtKSbPvNdaIXTBJjiRflpALwVrqhes):
  CtKSbPvNdaIXTBJjiRflpALwVrqhOD=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.DEFAULT_HEADER
  if headers:CtKSbPvNdaIXTBJjiRflpALwVrqhOD.update(headers)
  if jobtype=='Get':
   CtKSbPvNdaIXTBJjiRflpALwVrqhOE=requests.get(CtKSbPvNdaIXTBJjiRflpALwVrqhOs,params=params,headers=CtKSbPvNdaIXTBJjiRflpALwVrqhOD,cookies=cookies,allow_redirects=redirects)
  else:
   CtKSbPvNdaIXTBJjiRflpALwVrqhOE=requests.post(CtKSbPvNdaIXTBJjiRflpALwVrqhOs,data=payload,json=json,params=params,headers=CtKSbPvNdaIXTBJjiRflpALwVrqhOD,cookies=cookies,allow_redirects=redirects)
  CtKSbPvNdaIXTBJjiRflpALwVrqhOn.addon_log(CtKSbPvNdaIXTBJjiRflpALwVrqhez(CtKSbPvNdaIXTBJjiRflpALwVrqhOE.status_code)+' : '+CtKSbPvNdaIXTBJjiRflpALwVrqhOE.url)
  return CtKSbPvNdaIXTBJjiRflpALwVrqhOE
 def JsonFile_Save(CtKSbPvNdaIXTBJjiRflpALwVrqhOn,filename,CtKSbPvNdaIXTBJjiRflpALwVrqhOH):
  if filename=='':return CtKSbPvNdaIXTBJjiRflpALwVrqhes
  try:
   fp=CtKSbPvNdaIXTBJjiRflpALwVrqheg(filename,'w',-1,'utf-8')
   json.dump(CtKSbPvNdaIXTBJjiRflpALwVrqhOH,fp,indent=4,ensure_ascii=CtKSbPvNdaIXTBJjiRflpALwVrqhes)
   fp.close()
  except:
   return CtKSbPvNdaIXTBJjiRflpALwVrqhes
  return CtKSbPvNdaIXTBJjiRflpALwVrqheG
 def JsonFile_Load(CtKSbPvNdaIXTBJjiRflpALwVrqhOn,filename):
  if filename=='':return{}
  try:
   fp=CtKSbPvNdaIXTBJjiRflpALwVrqheg(filename,'r',-1,'utf-8')
   CtKSbPvNdaIXTBJjiRflpALwVrqhOY=json.load(fp)
   fp.close()
  except:
   return{}
  return CtKSbPvNdaIXTBJjiRflpALwVrqhOY
 def Save_session_acount(CtKSbPvNdaIXTBJjiRflpALwVrqhOn,CtKSbPvNdaIXTBJjiRflpALwVrqhOu,CtKSbPvNdaIXTBJjiRflpALwVrqhOU):
  CtKSbPvNdaIXTBJjiRflpALwVrqhOn.ST['account']['stid'] =base64.standard_b64encode(CtKSbPvNdaIXTBJjiRflpALwVrqhOu.encode()).decode('utf-8')
  CtKSbPvNdaIXTBJjiRflpALwVrqhOn.ST['account']['stpw'] =base64.standard_b64encode(CtKSbPvNdaIXTBJjiRflpALwVrqhOU.encode()).decode('utf-8')
 def Load_session_acount(CtKSbPvNdaIXTBJjiRflpALwVrqhOn):
  try:
   CtKSbPvNdaIXTBJjiRflpALwVrqhOu =base64.standard_b64decode(CtKSbPvNdaIXTBJjiRflpALwVrqhOn.ST['account']['stid']).decode('utf-8')
   CtKSbPvNdaIXTBJjiRflpALwVrqhOU =base64.standard_b64decode(CtKSbPvNdaIXTBJjiRflpALwVrqhOn.ST['account']['stpw']).decode('utf-8')
  except:
   return '',''
  return CtKSbPvNdaIXTBJjiRflpALwVrqhOu,CtKSbPvNdaIXTBJjiRflpALwVrqhOU
 def makeDefaultCookies(CtKSbPvNdaIXTBJjiRflpALwVrqhOn):
  CtKSbPvNdaIXTBJjiRflpALwVrqhOo={'id_token':CtKSbPvNdaIXTBJjiRflpALwVrqhOn.ST['cookies']['id_token']}
  return CtKSbPvNdaIXTBJjiRflpALwVrqhOo
 def makeDefaultHeaders(CtKSbPvNdaIXTBJjiRflpALwVrqhOn):
  CtKSbPvNdaIXTBJjiRflpALwVrqhOQ={'accept':'application/json;pk={}'.format(CtKSbPvNdaIXTBJjiRflpALwVrqhOn.ST['cookies']['spotv_policyKey'])}
  return CtKSbPvNdaIXTBJjiRflpALwVrqhOQ
 def xmlText(CtKSbPvNdaIXTBJjiRflpALwVrqhOn,in_text):
  CtKSbPvNdaIXTBJjiRflpALwVrqhOk=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;')
  return CtKSbPvNdaIXTBJjiRflpALwVrqhOk
 def GetNoCache(CtKSbPvNdaIXTBJjiRflpALwVrqhOn,timetype=1):
  if timetype==1:
   return CtKSbPvNdaIXTBJjiRflpALwVrqhem(time.time())
  else:
   return CtKSbPvNdaIXTBJjiRflpALwVrqhem(time.time()*1000)
 def GetCredential_new(CtKSbPvNdaIXTBJjiRflpALwVrqhOn,user_id,user_pw):
  CtKSbPvNdaIXTBJjiRflpALwVrqhOy=requests.session()
  try:
   CtKSbPvNdaIXTBJjiRflpALwVrqhOs='https://nid.spotvnow.co.kr/api/v3/oauth2/authorize/spotvnow?return_url=https%3A%2F%2Fwww.spotvnow.co.kr%2Fcheck&err_return_url=https%3A%2F%2Fwww.spotvnow.co.kr%2Fabout&logout_url=https%3A%2F%2Fwww.spotvnow.co.kr%2Fintro'
   CtKSbPvNdaIXTBJjiRflpALwVrqhOQ={'User-Agent':CtKSbPvNdaIXTBJjiRflpALwVrqhOn.USER_AGENT,}
   while(CtKSbPvNdaIXTBJjiRflpALwVrqhOs not in['',CtKSbPvNdaIXTBJjiRflpALwVrqhey]):
    CtKSbPvNdaIXTBJjiRflpALwVrqhOz=CtKSbPvNdaIXTBJjiRflpALwVrqhOy.get(CtKSbPvNdaIXTBJjiRflpALwVrqhOs,params=CtKSbPvNdaIXTBJjiRflpALwVrqhey,headers=CtKSbPvNdaIXTBJjiRflpALwVrqhOQ,cookies=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.ST['cookies'],allow_redirects=CtKSbPvNdaIXTBJjiRflpALwVrqhes)
    CtKSbPvNdaIXTBJjiRflpALwVrqhOs =CtKSbPvNdaIXTBJjiRflpALwVrqhOz.headers.get('location')
    for CtKSbPvNdaIXTBJjiRflpALwVrqhOg in CtKSbPvNdaIXTBJjiRflpALwVrqhOz.cookies:
     if CtKSbPvNdaIXTBJjiRflpALwVrqhOg.value not in['',CtKSbPvNdaIXTBJjiRflpALwVrqhey]:
      CtKSbPvNdaIXTBJjiRflpALwVrqhOn.ST['cookies'][CtKSbPvNdaIXTBJjiRflpALwVrqhOg.name]=CtKSbPvNdaIXTBJjiRflpALwVrqhOg.value
    if CtKSbPvNdaIXTBJjiRflpALwVrqhOz.status_code==200:break
   if CtKSbPvNdaIXTBJjiRflpALwVrqhOn.ST['cookies']['login_challenge']=='':
    CtKSbPvNdaIXTBJjiRflpALwVrqhOn.Init_ST_Total()
    return CtKSbPvNdaIXTBJjiRflpALwVrqhes
  except CtKSbPvNdaIXTBJjiRflpALwVrqhec as exception:
   CtKSbPvNdaIXTBJjiRflpALwVrqhxO(exception)
   CtKSbPvNdaIXTBJjiRflpALwVrqhOn.Init_ST_Total()
   return CtKSbPvNdaIXTBJjiRflpALwVrqhes
  try:
   CtKSbPvNdaIXTBJjiRflpALwVrqhOG=base64.standard_b64encode(user_id.encode('UTF-8')).decode('utf-8')
   CtKSbPvNdaIXTBJjiRflpALwVrqhOm=base64.standard_b64encode(user_pw.encode('UTF-8')).decode('utf-8')
   CtKSbPvNdaIXTBJjiRflpALwVrqhOs='https://nid.spotvnow.co.kr/api/v3/user-auth/login'
   CtKSbPvNdaIXTBJjiRflpALwVrqhOQ={'User-Agent':CtKSbPvNdaIXTBJjiRflpALwVrqhOn.USER_AGENT,}
   CtKSbPvNdaIXTBJjiRflpALwVrqhOc={'username':CtKSbPvNdaIXTBJjiRflpALwVrqhOG,'password':CtKSbPvNdaIXTBJjiRflpALwVrqhOm,'remember':CtKSbPvNdaIXTBJjiRflpALwVrqheG,'err_return_url':'https://www.spotvnow.co.kr/intro',}
   CtKSbPvNdaIXTBJjiRflpALwVrqhOz=CtKSbPvNdaIXTBJjiRflpALwVrqhOy.post(CtKSbPvNdaIXTBJjiRflpALwVrqhOs,data=CtKSbPvNdaIXTBJjiRflpALwVrqhOc,params=CtKSbPvNdaIXTBJjiRflpALwVrqhey,headers=CtKSbPvNdaIXTBJjiRflpALwVrqhOQ,cookies=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.ST['cookies'],allow_redirects=CtKSbPvNdaIXTBJjiRflpALwVrqhes)
   for CtKSbPvNdaIXTBJjiRflpALwVrqhOg in CtKSbPvNdaIXTBJjiRflpALwVrqhOz.cookies:
    if CtKSbPvNdaIXTBJjiRflpALwVrqhOg.value not in['',CtKSbPvNdaIXTBJjiRflpALwVrqhey]:
     CtKSbPvNdaIXTBJjiRflpALwVrqhOn.ST['cookies'][CtKSbPvNdaIXTBJjiRflpALwVrqhOg.name]=CtKSbPvNdaIXTBJjiRflpALwVrqhOg.value
   CtKSbPvNdaIXTBJjiRflpALwVrqhOs=CtKSbPvNdaIXTBJjiRflpALwVrqhOz.headers.get('location')
   while(CtKSbPvNdaIXTBJjiRflpALwVrqhOs not in['',CtKSbPvNdaIXTBJjiRflpALwVrqhey]):
    CtKSbPvNdaIXTBJjiRflpALwVrqhOQ={'user-agent':CtKSbPvNdaIXTBJjiRflpALwVrqhOn.USER_AGENT,}
    CtKSbPvNdaIXTBJjiRflpALwVrqhOz=CtKSbPvNdaIXTBJjiRflpALwVrqhOy.get(CtKSbPvNdaIXTBJjiRflpALwVrqhOs,params=CtKSbPvNdaIXTBJjiRflpALwVrqhey,headers=CtKSbPvNdaIXTBJjiRflpALwVrqhOQ,cookies=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.ST['cookies'],allow_redirects=CtKSbPvNdaIXTBJjiRflpALwVrqhes)
    CtKSbPvNdaIXTBJjiRflpALwVrqhOs =CtKSbPvNdaIXTBJjiRflpALwVrqhOz.headers.get('location')
    for CtKSbPvNdaIXTBJjiRflpALwVrqhOg in CtKSbPvNdaIXTBJjiRflpALwVrqhOz.cookies:
     if CtKSbPvNdaIXTBJjiRflpALwVrqhOg.value not in['',CtKSbPvNdaIXTBJjiRflpALwVrqhey]:
      CtKSbPvNdaIXTBJjiRflpALwVrqhOn.ST['cookies'][CtKSbPvNdaIXTBJjiRflpALwVrqhOg.name]=CtKSbPvNdaIXTBJjiRflpALwVrqhOg.value
    if CtKSbPvNdaIXTBJjiRflpALwVrqhOz.status_code==200:break
   if CtKSbPvNdaIXTBJjiRflpALwVrqhOn.ST['cookies']['id_token']=='':
    CtKSbPvNdaIXTBJjiRflpALwVrqhOn.Init_ST_Total()
    return CtKSbPvNdaIXTBJjiRflpALwVrqhes
  except CtKSbPvNdaIXTBJjiRflpALwVrqhec as exception:
   CtKSbPvNdaIXTBJjiRflpALwVrqhxO(exception)
   CtKSbPvNdaIXTBJjiRflpALwVrqhOn.Init_ST_Total()
   return CtKSbPvNdaIXTBJjiRflpALwVrqhes
  try:
   CtKSbPvNdaIXTBJjiRflpALwVrqhOs=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.API_DOMAIN+'/api/v3/session' 
   CtKSbPvNdaIXTBJjiRflpALwVrqhOo=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.makeDefaultCookies()
   CtKSbPvNdaIXTBJjiRflpALwVrqhOz=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.callRequestCookies('Get',CtKSbPvNdaIXTBJjiRflpALwVrqhOs,params=CtKSbPvNdaIXTBJjiRflpALwVrqhey,headers=CtKSbPvNdaIXTBJjiRflpALwVrqhey,cookies=CtKSbPvNdaIXTBJjiRflpALwVrqhOo)
   CtKSbPvNdaIXTBJjiRflpALwVrqhMO=json.loads(CtKSbPvNdaIXTBJjiRflpALwVrqhOz.text)
   CtKSbPvNdaIXTBJjiRflpALwVrqhOn.ST['cookies']['spotv_sessionid']=CtKSbPvNdaIXTBJjiRflpALwVrqhMO.get('userId')
   CtKSbPvNdaIXTBJjiRflpALwVrqhMF=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.SPOTV_PMCODE+CtKSbPvNdaIXTBJjiRflpALwVrqhez(CtKSbPvNdaIXTBJjiRflpALwVrqhMO['subEndTime'])
   CtKSbPvNdaIXTBJjiRflpALwVrqhOn.ST['cookies']['spotv_subend'] =base64.standard_b64encode(CtKSbPvNdaIXTBJjiRflpALwVrqhMF.encode()).decode('utf-8')
  except CtKSbPvNdaIXTBJjiRflpALwVrqhec as exception:
   CtKSbPvNdaIXTBJjiRflpALwVrqhxO(exception)
   CtKSbPvNdaIXTBJjiRflpALwVrqhOn.Init_ST_Total()
   return CtKSbPvNdaIXTBJjiRflpALwVrqhes
  try:
   if CtKSbPvNdaIXTBJjiRflpALwVrqhMO['subEndTime']in[0,'0',CtKSbPvNdaIXTBJjiRflpALwVrqhey]:
    CtKSbPvNdaIXTBJjiRflpALwVrqhOs=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.API_DOMAIN+'/api/v3/user/sub/scope' 
    CtKSbPvNdaIXTBJjiRflpALwVrqhOo=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.makeDefaultCookies()
    CtKSbPvNdaIXTBJjiRflpALwVrqhOz=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.callRequestCookies('Get',CtKSbPvNdaIXTBJjiRflpALwVrqhOs,params=CtKSbPvNdaIXTBJjiRflpALwVrqhey,headers=CtKSbPvNdaIXTBJjiRflpALwVrqhey,cookies=CtKSbPvNdaIXTBJjiRflpALwVrqhOo)
    CtKSbPvNdaIXTBJjiRflpALwVrqhMO=json.loads(CtKSbPvNdaIXTBJjiRflpALwVrqhOz.text)
    if CtKSbPvNdaIXTBJjiRflpALwVrqhMO.get('endDate')==CtKSbPvNdaIXTBJjiRflpALwVrqhey:
     CtKSbPvNdaIXTBJjiRflpALwVrqhMF=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.SPOTV_PMCODE+'0'
     CtKSbPvNdaIXTBJjiRflpALwVrqhOn.ST['cookies']['spotv_subend'] =base64.standard_b64encode(CtKSbPvNdaIXTBJjiRflpALwVrqhMF.encode()).decode('utf-8')
    else:
     CtKSbPvNdaIXTBJjiRflpALwVrqhMn=datetime.datetime.strptime(CtKSbPvNdaIXTBJjiRflpALwVrqhMO.get('endDate'),'%Y-%m-%d %H:%M:%S')
     CtKSbPvNdaIXTBJjiRflpALwVrqhMF=CtKSbPvNdaIXTBJjiRflpALwVrqhem(time.mktime(CtKSbPvNdaIXTBJjiRflpALwVrqhMn.timetuple()))
     CtKSbPvNdaIXTBJjiRflpALwVrqhMF=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.SPOTV_PMCODE+CtKSbPvNdaIXTBJjiRflpALwVrqhez(CtKSbPvNdaIXTBJjiRflpALwVrqhMF)+'000'
     CtKSbPvNdaIXTBJjiRflpALwVrqhOn.ST['cookies']['spotv_subend'] =base64.standard_b64encode(CtKSbPvNdaIXTBJjiRflpALwVrqhMF.encode()).decode('utf-8')
  except CtKSbPvNdaIXTBJjiRflpALwVrqhec as exception:
   CtKSbPvNdaIXTBJjiRflpALwVrqhxO(exception)
   CtKSbPvNdaIXTBJjiRflpALwVrqhOn.Init_ST_Total()
   return CtKSbPvNdaIXTBJjiRflpALwVrqhes
  if CtKSbPvNdaIXTBJjiRflpALwVrqhOn.GetPolicyKey()==CtKSbPvNdaIXTBJjiRflpALwVrqhes:
   CtKSbPvNdaIXTBJjiRflpALwVrqhOn.Init_ST_Total()
   return CtKSbPvNdaIXTBJjiRflpALwVrqhes
  '''
  https://players.brightcove.net/5764318566001/2SXVGLGl4_default/index.min.js
    options: {accountId: "5764318566001", policyKey: "BCpkADawqM072_NUcqm8RBVoMGIaio2x979NvYhN4Zrs685jLKKYmCx_ssySm_0HFSnwPKQIbaekH1PnWGFk-nQCtuky-DlMgN4KNvNlPYjsojAi1fU9ozEXVSpULPylDb8STvOgPf-F941V-RbByAkzD8CgApyhBS8TNN-yDc17gnFUj82OEBP8DEo" }  
  '''  
  return CtKSbPvNdaIXTBJjiRflpALwVrqheG
 def GetCredential(CtKSbPvNdaIXTBJjiRflpALwVrqhOn,user_id,user_pw):
  try:
   CtKSbPvNdaIXTBJjiRflpALwVrqhOG=base64.standard_b64encode(user_id.encode('UTF-8')).decode('utf-8')
   CtKSbPvNdaIXTBJjiRflpALwVrqhOm=base64.standard_b64encode(user_pw.encode('UTF-8')).decode('utf-8')
   CtKSbPvNdaIXTBJjiRflpALwVrqhMe=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.API_DOMAIN+'/api/v2/login'
   CtKSbPvNdaIXTBJjiRflpALwVrqhOc={'username':CtKSbPvNdaIXTBJjiRflpALwVrqhOG,'password':CtKSbPvNdaIXTBJjiRflpALwVrqhOm}
   CtKSbPvNdaIXTBJjiRflpALwVrqhOc=json.dumps(CtKSbPvNdaIXTBJjiRflpALwVrqhOc)
   CtKSbPvNdaIXTBJjiRflpALwVrqhOz=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.callRequestCookies('Post',CtKSbPvNdaIXTBJjiRflpALwVrqhMe,payload=CtKSbPvNdaIXTBJjiRflpALwVrqhOc,params=CtKSbPvNdaIXTBJjiRflpALwVrqhey,headers=CtKSbPvNdaIXTBJjiRflpALwVrqhey,cookies=CtKSbPvNdaIXTBJjiRflpALwVrqhey)
   CtKSbPvNdaIXTBJjiRflpALwVrqhMx=json.loads(CtKSbPvNdaIXTBJjiRflpALwVrqhOz.text)
   for CtKSbPvNdaIXTBJjiRflpALwVrqhOg in CtKSbPvNdaIXTBJjiRflpALwVrqhOz.cookies:
    if CtKSbPvNdaIXTBJjiRflpALwVrqhOg.name=='SESSION':
     CtKSbPvNdaIXTBJjiRflpALwVrqhOn.ST['cookies']['spotv_session']=CtKSbPvNdaIXTBJjiRflpALwVrqhOg.value
     break
   if CtKSbPvNdaIXTBJjiRflpALwVrqhOn.ST['cookies']['spotv_session']=='':
    CtKSbPvNdaIXTBJjiRflpALwVrqhOn.Init_ST_Total()
    return CtKSbPvNdaIXTBJjiRflpALwVrqhes
   CtKSbPvNdaIXTBJjiRflpALwVrqhOn.ST['cookies']['spotv_sessionid']=CtKSbPvNdaIXTBJjiRflpALwVrqhez(CtKSbPvNdaIXTBJjiRflpALwVrqhMx['userId'])
   CtKSbPvNdaIXTBJjiRflpALwVrqhMF=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.SPOTV_PMCODE+CtKSbPvNdaIXTBJjiRflpALwVrqhez(CtKSbPvNdaIXTBJjiRflpALwVrqhMx['subEndTime'])
   CtKSbPvNdaIXTBJjiRflpALwVrqhOn.ST['cookies']['spotv_subend'] =base64.standard_b64encode(CtKSbPvNdaIXTBJjiRflpALwVrqhMF.encode()).decode('utf-8')
   if CtKSbPvNdaIXTBJjiRflpALwVrqhOn.GetPolicyKey()==CtKSbPvNdaIXTBJjiRflpALwVrqhes:
    CtKSbPvNdaIXTBJjiRflpALwVrqhOn.Init_ST_Total()
    return CtKSbPvNdaIXTBJjiRflpALwVrqhes
  except CtKSbPvNdaIXTBJjiRflpALwVrqhec as exception:
   CtKSbPvNdaIXTBJjiRflpALwVrqhxO(exception)
   CtKSbPvNdaIXTBJjiRflpALwVrqhOn.Init_ST_Total()
   return CtKSbPvNdaIXTBJjiRflpALwVrqhes
  return CtKSbPvNdaIXTBJjiRflpALwVrqheG
 def GetPolicyKey(CtKSbPvNdaIXTBJjiRflpALwVrqhOn):
  try:
   CtKSbPvNdaIXTBJjiRflpALwVrqhOs=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.GetBcPlayerUrl()
   if CtKSbPvNdaIXTBJjiRflpALwVrqhOs=='':return CtKSbPvNdaIXTBJjiRflpALwVrqhes
   CtKSbPvNdaIXTBJjiRflpALwVrqhOz=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.callRequestCookies('Get',CtKSbPvNdaIXTBJjiRflpALwVrqhOs,payload=CtKSbPvNdaIXTBJjiRflpALwVrqhey,params=CtKSbPvNdaIXTBJjiRflpALwVrqhey,headers=CtKSbPvNdaIXTBJjiRflpALwVrqhey,cookies=CtKSbPvNdaIXTBJjiRflpALwVrqhey)
   CtKSbPvNdaIXTBJjiRflpALwVrqhMD=CtKSbPvNdaIXTBJjiRflpALwVrqhOz.text
   CtKSbPvNdaIXTBJjiRflpALwVrqhME =re.findall('accountId:\s*\"\d{13}\",\s*policyKey:\s*\".[^(){}]{100,300}\"',CtKSbPvNdaIXTBJjiRflpALwVrqhMD)[0]
   CtKSbPvNdaIXTBJjiRflpALwVrqhME =CtKSbPvNdaIXTBJjiRflpALwVrqhME.replace('accountId','"accountId"')
   CtKSbPvNdaIXTBJjiRflpALwVrqhME =CtKSbPvNdaIXTBJjiRflpALwVrqhME.replace('policyKey','"policyKey"')
   CtKSbPvNdaIXTBJjiRflpALwVrqhME ='{'+CtKSbPvNdaIXTBJjiRflpALwVrqhME+'}'
   CtKSbPvNdaIXTBJjiRflpALwVrqhMH=json.loads(CtKSbPvNdaIXTBJjiRflpALwVrqhME)
   CtKSbPvNdaIXTBJjiRflpALwVrqhOn.ST['cookies']['spotv_accountId']=CtKSbPvNdaIXTBJjiRflpALwVrqhMH['accountId']
   CtKSbPvNdaIXTBJjiRflpALwVrqhOn.ST['cookies']['spotv_policyKey']=CtKSbPvNdaIXTBJjiRflpALwVrqhMH['policyKey']
  except CtKSbPvNdaIXTBJjiRflpALwVrqhec as exception:
   CtKSbPvNdaIXTBJjiRflpALwVrqhxO(exception)
   return CtKSbPvNdaIXTBJjiRflpALwVrqhes
  return CtKSbPvNdaIXTBJjiRflpALwVrqheG
 def GetBcPlayerUrl(CtKSbPvNdaIXTBJjiRflpALwVrqhOn):
  CtKSbPvNdaIXTBJjiRflpALwVrqhMW=''
  try:
   CtKSbPvNdaIXTBJjiRflpALwVrqhOs=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.GetMainJspath()
   if CtKSbPvNdaIXTBJjiRflpALwVrqhOs=='':return CtKSbPvNdaIXTBJjiRflpALwVrqhMW
   CtKSbPvNdaIXTBJjiRflpALwVrqhOz=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.callRequestCookies('Get',CtKSbPvNdaIXTBJjiRflpALwVrqhOs,payload=CtKSbPvNdaIXTBJjiRflpALwVrqhey,params=CtKSbPvNdaIXTBJjiRflpALwVrqhey,headers=CtKSbPvNdaIXTBJjiRflpALwVrqhey,cookies=CtKSbPvNdaIXTBJjiRflpALwVrqhey)
   CtKSbPvNdaIXTBJjiRflpALwVrqhMD=CtKSbPvNdaIXTBJjiRflpALwVrqhOz.text
   CtKSbPvNdaIXTBJjiRflpALwVrqhMY =r'default:{(.*?)}'
   CtKSbPvNdaIXTBJjiRflpALwVrqhMu =re.compile(CtKSbPvNdaIXTBJjiRflpALwVrqhMY).findall(CtKSbPvNdaIXTBJjiRflpALwVrqhMD)[0]
   CtKSbPvNdaIXTBJjiRflpALwVrqhMU=r'bc:"(.*?)"'
   CtKSbPvNdaIXTBJjiRflpALwVrqhMo=re.compile(CtKSbPvNdaIXTBJjiRflpALwVrqhMU).findall(CtKSbPvNdaIXTBJjiRflpALwVrqhMu)[0]
   CtKSbPvNdaIXTBJjiRflpALwVrqhMQ=r'":"(.*?)"'
   CtKSbPvNdaIXTBJjiRflpALwVrqhMk=re.compile(CtKSbPvNdaIXTBJjiRflpALwVrqhMQ).findall(CtKSbPvNdaIXTBJjiRflpALwVrqhMu)[0]
   CtKSbPvNdaIXTBJjiRflpALwVrqhMW="%s/%s/%s_default/index.min.js"%(CtKSbPvNdaIXTBJjiRflpALwVrqhOn.BC_DOMAIN,CtKSbPvNdaIXTBJjiRflpALwVrqhMo,CtKSbPvNdaIXTBJjiRflpALwVrqhMk)
  except CtKSbPvNdaIXTBJjiRflpALwVrqhec as exception:
   CtKSbPvNdaIXTBJjiRflpALwVrqhxO(exception)
  return CtKSbPvNdaIXTBJjiRflpALwVrqhMW
 def GetMainJspath(CtKSbPvNdaIXTBJjiRflpALwVrqhOn):
  CtKSbPvNdaIXTBJjiRflpALwVrqhMy=''
  try:
   CtKSbPvNdaIXTBJjiRflpALwVrqhOs=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.API_DOMAIN
   CtKSbPvNdaIXTBJjiRflpALwVrqhOz=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.callRequestCookies('Get',CtKSbPvNdaIXTBJjiRflpALwVrqhOs,payload=CtKSbPvNdaIXTBJjiRflpALwVrqhey,params=CtKSbPvNdaIXTBJjiRflpALwVrqhey,headers=CtKSbPvNdaIXTBJjiRflpALwVrqhey,cookies=CtKSbPvNdaIXTBJjiRflpALwVrqhey)
   CtKSbPvNdaIXTBJjiRflpALwVrqhMD=CtKSbPvNdaIXTBJjiRflpALwVrqhOz.text
   CtKSbPvNdaIXTBJjiRflpALwVrqhME =re.findall('https://cdn.spotvnow.co.kr/dist/js/.{20}\.js',CtKSbPvNdaIXTBJjiRflpALwVrqhMD)[0]
   CtKSbPvNdaIXTBJjiRflpALwVrqhMy=CtKSbPvNdaIXTBJjiRflpALwVrqhME
  except CtKSbPvNdaIXTBJjiRflpALwVrqhec as exception:
   CtKSbPvNdaIXTBJjiRflpALwVrqhxO(exception)
  return CtKSbPvNdaIXTBJjiRflpALwVrqhMy
 def Get_Now_Datetime(CtKSbPvNdaIXTBJjiRflpALwVrqhOn):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetLiveChannelList(CtKSbPvNdaIXTBJjiRflpALwVrqhOn):
  CtKSbPvNdaIXTBJjiRflpALwVrqhMz=[]
  CtKSbPvNdaIXTBJjiRflpALwVrqhMg ={}
  try:
   CtKSbPvNdaIXTBJjiRflpALwVrqhOs=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.API_DOMAIN+'/api/v3/channel'
   CtKSbPvNdaIXTBJjiRflpALwVrqhOz=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.callRequestCookies('Get',CtKSbPvNdaIXTBJjiRflpALwVrqhOs,payload=CtKSbPvNdaIXTBJjiRflpALwVrqhey,params=CtKSbPvNdaIXTBJjiRflpALwVrqhey,headers=CtKSbPvNdaIXTBJjiRflpALwVrqhey,cookies=CtKSbPvNdaIXTBJjiRflpALwVrqhey)
   CtKSbPvNdaIXTBJjiRflpALwVrqhMx=json.loads(CtKSbPvNdaIXTBJjiRflpALwVrqhOz.text)
   CtKSbPvNdaIXTBJjiRflpALwVrqhMg=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.GetEPGList()
   for CtKSbPvNdaIXTBJjiRflpALwVrqhMG in CtKSbPvNdaIXTBJjiRflpALwVrqhMx:
    CtKSbPvNdaIXTBJjiRflpALwVrqhMm={'id':CtKSbPvNdaIXTBJjiRflpALwVrqhMG['id'],'name':CtKSbPvNdaIXTBJjiRflpALwVrqhMG['name'],'logo':CtKSbPvNdaIXTBJjiRflpALwVrqhMG['logo'],'free':CtKSbPvNdaIXTBJjiRflpALwVrqhMG['free'],'programName':CtKSbPvNdaIXTBJjiRflpALwVrqhMG['programName'],'channelepg':CtKSbPvNdaIXTBJjiRflpALwVrqhMg.get(CtKSbPvNdaIXTBJjiRflpALwVrqhMG['id']),}
    CtKSbPvNdaIXTBJjiRflpALwVrqhMz.append(CtKSbPvNdaIXTBJjiRflpALwVrqhMm)
  except CtKSbPvNdaIXTBJjiRflpALwVrqhec as exception:
   CtKSbPvNdaIXTBJjiRflpALwVrqhxO(exception)
  return CtKSbPvNdaIXTBJjiRflpALwVrqhMz
 def GetHlsUrl(CtKSbPvNdaIXTBJjiRflpALwVrqhOn,mediacode):
  CtKSbPvNdaIXTBJjiRflpALwVrqhMc=''
  try:
   CtKSbPvNdaIXTBJjiRflpALwVrqhOs=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.API_DOMAIN+'/api/v3/channel/'+mediacode
   CtKSbPvNdaIXTBJjiRflpALwVrqhOz=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.callRequestCookies('Get',CtKSbPvNdaIXTBJjiRflpALwVrqhOs,payload=CtKSbPvNdaIXTBJjiRflpALwVrqhey,params=CtKSbPvNdaIXTBJjiRflpALwVrqhey,headers=CtKSbPvNdaIXTBJjiRflpALwVrqhey,cookies=CtKSbPvNdaIXTBJjiRflpALwVrqhey)
   CtKSbPvNdaIXTBJjiRflpALwVrqhMx=json.loads(CtKSbPvNdaIXTBJjiRflpALwVrqhOz.text)
   CtKSbPvNdaIXTBJjiRflpALwVrqhMc=CtKSbPvNdaIXTBJjiRflpALwVrqhMx['hlsUrl']
  except CtKSbPvNdaIXTBJjiRflpALwVrqhec as exception:
   CtKSbPvNdaIXTBJjiRflpALwVrqhxO(exception)
  return CtKSbPvNdaIXTBJjiRflpALwVrqhMc
 def GetEPGList(CtKSbPvNdaIXTBJjiRflpALwVrqhOn):
  CtKSbPvNdaIXTBJjiRflpALwVrqhFO={}
  CtKSbPvNdaIXTBJjiRflpALwVrqhFM=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.Get_Now_Datetime()
  CtKSbPvNdaIXTBJjiRflpALwVrqhFn=CtKSbPvNdaIXTBJjiRflpALwVrqhFM.strftime('%Y%m%d%H%M')
  CtKSbPvNdaIXTBJjiRflpALwVrqhFe='%s-%s-%s'%(CtKSbPvNdaIXTBJjiRflpALwVrqhFn[0:4],CtKSbPvNdaIXTBJjiRflpALwVrqhFn[4:6],CtKSbPvNdaIXTBJjiRflpALwVrqhFn[6:8])
  CtKSbPvNdaIXTBJjiRflpALwVrqhFx=(CtKSbPvNdaIXTBJjiRflpALwVrqhFM+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M')
  try:
   CtKSbPvNdaIXTBJjiRflpALwVrqhOs=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.API_DOMAIN+'/api/v3/program/'+CtKSbPvNdaIXTBJjiRflpALwVrqhFe
   CtKSbPvNdaIXTBJjiRflpALwVrqhOz=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.callRequestCookies('Get',CtKSbPvNdaIXTBJjiRflpALwVrqhOs,payload=CtKSbPvNdaIXTBJjiRflpALwVrqhey,params=CtKSbPvNdaIXTBJjiRflpALwVrqhey,headers=CtKSbPvNdaIXTBJjiRflpALwVrqhey,cookies=CtKSbPvNdaIXTBJjiRflpALwVrqhey)
   CtKSbPvNdaIXTBJjiRflpALwVrqhMx=json.loads(CtKSbPvNdaIXTBJjiRflpALwVrqhOz.text)
   CtKSbPvNdaIXTBJjiRflpALwVrqhFD=-1 
   CtKSbPvNdaIXTBJjiRflpALwVrqhFE =''
   for CtKSbPvNdaIXTBJjiRflpALwVrqhMG in CtKSbPvNdaIXTBJjiRflpALwVrqhMx:
    CtKSbPvNdaIXTBJjiRflpALwVrqhFH=CtKSbPvNdaIXTBJjiRflpALwVrqhMG['channelId']
    CtKSbPvNdaIXTBJjiRflpALwVrqhFW =CtKSbPvNdaIXTBJjiRflpALwVrqhMG['startTime'].replace('-','').replace(' ','').replace(':','')
    CtKSbPvNdaIXTBJjiRflpALwVrqhFY =CtKSbPvNdaIXTBJjiRflpALwVrqhMG['endTime'].replace('-','').replace(' ','').replace(':','')
    if CtKSbPvNdaIXTBJjiRflpALwVrqhem(CtKSbPvNdaIXTBJjiRflpALwVrqhFn)>CtKSbPvNdaIXTBJjiRflpALwVrqhem(CtKSbPvNdaIXTBJjiRflpALwVrqhFY) :continue
    if CtKSbPvNdaIXTBJjiRflpALwVrqhem(CtKSbPvNdaIXTBJjiRflpALwVrqhFx)<CtKSbPvNdaIXTBJjiRflpALwVrqhem(CtKSbPvNdaIXTBJjiRflpALwVrqhFW):continue
    if CtKSbPvNdaIXTBJjiRflpALwVrqhFD!=CtKSbPvNdaIXTBJjiRflpALwVrqhFH:
     if CtKSbPvNdaIXTBJjiRflpALwVrqhFE!='':CtKSbPvNdaIXTBJjiRflpALwVrqhFO[CtKSbPvNdaIXTBJjiRflpALwVrqhFD]=CtKSbPvNdaIXTBJjiRflpALwVrqhFE
     CtKSbPvNdaIXTBJjiRflpALwVrqhFD=CtKSbPvNdaIXTBJjiRflpALwVrqhFH
     CtKSbPvNdaIXTBJjiRflpALwVrqhFE =''
    if CtKSbPvNdaIXTBJjiRflpALwVrqhFE:CtKSbPvNdaIXTBJjiRflpALwVrqhFE+='\n'
    CtKSbPvNdaIXTBJjiRflpALwVrqhFE+=CtKSbPvNdaIXTBJjiRflpALwVrqhMG['title']+'\n'
    CtKSbPvNdaIXTBJjiRflpALwVrqhFE+=' [%s ~ %s]'%(CtKSbPvNdaIXTBJjiRflpALwVrqhMG['startTime'][-5:],CtKSbPvNdaIXTBJjiRflpALwVrqhMG['endTime'][-5:])+'\n'
   if CtKSbPvNdaIXTBJjiRflpALwVrqhFE:CtKSbPvNdaIXTBJjiRflpALwVrqhFO[CtKSbPvNdaIXTBJjiRflpALwVrqhFD]=CtKSbPvNdaIXTBJjiRflpALwVrqhFE
  except CtKSbPvNdaIXTBJjiRflpALwVrqhec as exception:
   CtKSbPvNdaIXTBJjiRflpALwVrqhxO(exception)
  return CtKSbPvNdaIXTBJjiRflpALwVrqhFO
 def GetEPGList_new(CtKSbPvNdaIXTBJjiRflpALwVrqhOn):
  CtKSbPvNdaIXTBJjiRflpALwVrqhFO={}
  CtKSbPvNdaIXTBJjiRflpALwVrqhFM=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.Get_Now_Datetime()
  CtKSbPvNdaIXTBJjiRflpALwVrqhFn=CtKSbPvNdaIXTBJjiRflpALwVrqhFM.strftime('%Y%m%d%H%M00')
  CtKSbPvNdaIXTBJjiRflpALwVrqhFe='%s%s%s'%(CtKSbPvNdaIXTBJjiRflpALwVrqhFn[0:4],CtKSbPvNdaIXTBJjiRflpALwVrqhFn[4:6],CtKSbPvNdaIXTBJjiRflpALwVrqhFn[6:8])
  CtKSbPvNdaIXTBJjiRflpALwVrqhFx=(CtKSbPvNdaIXTBJjiRflpALwVrqhFM+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M00')
  try:
   for CtKSbPvNdaIXTBJjiRflpALwVrqhMG in LIVETV_LIST:
    CtKSbPvNdaIXTBJjiRflpALwVrqhFu =CtKSbPvNdaIXTBJjiRflpALwVrqhMG['videoId']
    if CtKSbPvNdaIXTBJjiRflpALwVrqhMG['epgtype']=='spotvon':
     CtKSbPvNdaIXTBJjiRflpALwVrqhFE=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.Get_EpgInfo_Spotv_spotvon(CtKSbPvNdaIXTBJjiRflpALwVrqhFu,CtKSbPvNdaIXTBJjiRflpALwVrqhMG['epgnm'],CtKSbPvNdaIXTBJjiRflpALwVrqhFe)
     CtKSbPvNdaIXTBJjiRflpALwVrqhFO[CtKSbPvNdaIXTBJjiRflpALwVrqhFu]=CtKSbPvNdaIXTBJjiRflpALwVrqhFE
    if CtKSbPvNdaIXTBJjiRflpALwVrqhMG['epgtype']=='spotvnet':
     CtKSbPvNdaIXTBJjiRflpALwVrqhFE=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.Get_EpgInfo_Spotv_spotvnet(CtKSbPvNdaIXTBJjiRflpALwVrqhFu,CtKSbPvNdaIXTBJjiRflpALwVrqhMG['epgnm'],CtKSbPvNdaIXTBJjiRflpALwVrqhFe)
     CtKSbPvNdaIXTBJjiRflpALwVrqhFO[CtKSbPvNdaIXTBJjiRflpALwVrqhFu]=CtKSbPvNdaIXTBJjiRflpALwVrqhFE
   for CtKSbPvNdaIXTBJjiRflpALwVrqhFU in CtKSbPvNdaIXTBJjiRflpALwVrqhFO.keys():
    if CtKSbPvNdaIXTBJjiRflpALwVrqhxM(CtKSbPvNdaIXTBJjiRflpALwVrqhFO.get(CtKSbPvNdaIXTBJjiRflpALwVrqhFU))==0:continue
    CtKSbPvNdaIXTBJjiRflpALwVrqhFE =''
    CtKSbPvNdaIXTBJjiRflpALwVrqhFo=''
    for CtKSbPvNdaIXTBJjiRflpALwVrqhFQ in CtKSbPvNdaIXTBJjiRflpALwVrqhFO.get(CtKSbPvNdaIXTBJjiRflpALwVrqhFU):
     CtKSbPvNdaIXTBJjiRflpALwVrqhFW =CtKSbPvNdaIXTBJjiRflpALwVrqhFQ['startTime']
     CtKSbPvNdaIXTBJjiRflpALwVrqhFY =CtKSbPvNdaIXTBJjiRflpALwVrqhFQ['endTime']
     if CtKSbPvNdaIXTBJjiRflpALwVrqhem(CtKSbPvNdaIXTBJjiRflpALwVrqhFn)>CtKSbPvNdaIXTBJjiRflpALwVrqhem(CtKSbPvNdaIXTBJjiRflpALwVrqhFY) :continue
     if CtKSbPvNdaIXTBJjiRflpALwVrqhem(CtKSbPvNdaIXTBJjiRflpALwVrqhFx)<CtKSbPvNdaIXTBJjiRflpALwVrqhem(CtKSbPvNdaIXTBJjiRflpALwVrqhFW):continue
     if CtKSbPvNdaIXTBJjiRflpALwVrqhem(CtKSbPvNdaIXTBJjiRflpALwVrqhFn)>=CtKSbPvNdaIXTBJjiRflpALwVrqhem(CtKSbPvNdaIXTBJjiRflpALwVrqhFW)and CtKSbPvNdaIXTBJjiRflpALwVrqhem(CtKSbPvNdaIXTBJjiRflpALwVrqhFn)<CtKSbPvNdaIXTBJjiRflpALwVrqhem(CtKSbPvNdaIXTBJjiRflpALwVrqhFY):CtKSbPvNdaIXTBJjiRflpALwVrqhFo=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.xmlText(CtKSbPvNdaIXTBJjiRflpALwVrqhFQ['title'])
     if CtKSbPvNdaIXTBJjiRflpALwVrqhFE:CtKSbPvNdaIXTBJjiRflpALwVrqhFE+='\n'
     CtKSbPvNdaIXTBJjiRflpALwVrqhFE+=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.xmlText(CtKSbPvNdaIXTBJjiRflpALwVrqhFQ['title'])+'\n'
     CtKSbPvNdaIXTBJjiRflpALwVrqhFE+=' [%s:%s ~ %s:%s]'%(CtKSbPvNdaIXTBJjiRflpALwVrqhFQ['startTime'][8:10],CtKSbPvNdaIXTBJjiRflpALwVrqhFQ['startTime'][10:12],CtKSbPvNdaIXTBJjiRflpALwVrqhFQ['endTime'][8:10],CtKSbPvNdaIXTBJjiRflpALwVrqhFQ['endTime'][10:12])+'\n'
    CtKSbPvNdaIXTBJjiRflpALwVrqhFO[CtKSbPvNdaIXTBJjiRflpALwVrqhFU]={'epg':CtKSbPvNdaIXTBJjiRflpALwVrqhFE,'title':CtKSbPvNdaIXTBJjiRflpALwVrqhFo}
  except CtKSbPvNdaIXTBJjiRflpALwVrqhec as exception:
   CtKSbPvNdaIXTBJjiRflpALwVrqhxO(exception)
  return CtKSbPvNdaIXTBJjiRflpALwVrqhFO
 def Get_EpgInfo_Spotv_spotvon(CtKSbPvNdaIXTBJjiRflpALwVrqhOn,CtKSbPvNdaIXTBJjiRflpALwVrqhFu,epgnm,now_day):
  CtKSbPvNdaIXTBJjiRflpALwVrqhFO =[]
  try:
   CtKSbPvNdaIXTBJjiRflpALwVrqhOs='https://www.spotvon.co.kr/data/onAir/%s/Daily/D%s.asp'%(epgnm,now_day)
   CtKSbPvNdaIXTBJjiRflpALwVrqhOz=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.callRequestCookies('Get',CtKSbPvNdaIXTBJjiRflpALwVrqhOs,payload=CtKSbPvNdaIXTBJjiRflpALwVrqhey,params=CtKSbPvNdaIXTBJjiRflpALwVrqhey,headers=CtKSbPvNdaIXTBJjiRflpALwVrqhey,cookies=CtKSbPvNdaIXTBJjiRflpALwVrqhey)
   CtKSbPvNdaIXTBJjiRflpALwVrqhMO=json.loads(CtKSbPvNdaIXTBJjiRflpALwVrqhOz.text)
   for CtKSbPvNdaIXTBJjiRflpALwVrqhMG in CtKSbPvNdaIXTBJjiRflpALwVrqhMO:
    CtKSbPvNdaIXTBJjiRflpALwVrqhMm={'title':CtKSbPvNdaIXTBJjiRflpALwVrqhMG['title'],'startTime':CtKSbPvNdaIXTBJjiRflpALwVrqhMG['sch_date'].replace('-','')+CtKSbPvNdaIXTBJjiRflpALwVrqhez(CtKSbPvNdaIXTBJjiRflpALwVrqhMG['sch_hour']).zfill(2)+CtKSbPvNdaIXTBJjiRflpALwVrqhMG['sch_min']+'00'}
    CtKSbPvNdaIXTBJjiRflpALwVrqhFO.append(CtKSbPvNdaIXTBJjiRflpALwVrqhMm)
   for i in CtKSbPvNdaIXTBJjiRflpALwVrqhxF(CtKSbPvNdaIXTBJjiRflpALwVrqhxM(CtKSbPvNdaIXTBJjiRflpALwVrqhFO)):
    if i>0:CtKSbPvNdaIXTBJjiRflpALwVrqhFO[i-1]['endTime']=CtKSbPvNdaIXTBJjiRflpALwVrqhFO[i]['startTime']
    if i==CtKSbPvNdaIXTBJjiRflpALwVrqhxM(CtKSbPvNdaIXTBJjiRflpALwVrqhFO)-1: CtKSbPvNdaIXTBJjiRflpALwVrqhFO[i]['endTime']=now_day+'240000'
  except CtKSbPvNdaIXTBJjiRflpALwVrqhec as exception:
   CtKSbPvNdaIXTBJjiRflpALwVrqhxO(exception)
   return[]
  return CtKSbPvNdaIXTBJjiRflpALwVrqhFO
 def Get_EpgInfo_Spotv_spotvnet(CtKSbPvNdaIXTBJjiRflpALwVrqhOn,CtKSbPvNdaIXTBJjiRflpALwVrqhFu,epgnm,now_day):
  CtKSbPvNdaIXTBJjiRflpALwVrqhFO =[]
  try:
   CtKSbPvNdaIXTBJjiRflpALwVrqhOs='https://www.spotv.net/data/json/schedule/%s/Daily/D%s.json'%(epgnm,now_day)
   CtKSbPvNdaIXTBJjiRflpALwVrqhOz=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.callRequestCookies('Get',CtKSbPvNdaIXTBJjiRflpALwVrqhOs,payload=CtKSbPvNdaIXTBJjiRflpALwVrqhey,params=CtKSbPvNdaIXTBJjiRflpALwVrqhey,headers=CtKSbPvNdaIXTBJjiRflpALwVrqhey,cookies=CtKSbPvNdaIXTBJjiRflpALwVrqhey)
   CtKSbPvNdaIXTBJjiRflpALwVrqhMO=json.loads(CtKSbPvNdaIXTBJjiRflpALwVrqhOz.text)
   for CtKSbPvNdaIXTBJjiRflpALwVrqhMG in CtKSbPvNdaIXTBJjiRflpALwVrqhMO:
    CtKSbPvNdaIXTBJjiRflpALwVrqhMm={'title':CtKSbPvNdaIXTBJjiRflpALwVrqhMG['title'],'startTime':CtKSbPvNdaIXTBJjiRflpALwVrqhMG['sch_date'].replace('-','')+CtKSbPvNdaIXTBJjiRflpALwVrqhez(CtKSbPvNdaIXTBJjiRflpALwVrqhMG['sch_hour']).zfill(2)+CtKSbPvNdaIXTBJjiRflpALwVrqhMG['sch_min']+'00'}
    CtKSbPvNdaIXTBJjiRflpALwVrqhFO.append(CtKSbPvNdaIXTBJjiRflpALwVrqhMm)
   for i in CtKSbPvNdaIXTBJjiRflpALwVrqhxF(CtKSbPvNdaIXTBJjiRflpALwVrqhxM(CtKSbPvNdaIXTBJjiRflpALwVrqhFO)):
    if i>0:CtKSbPvNdaIXTBJjiRflpALwVrqhFO[i-1]['endTime']=CtKSbPvNdaIXTBJjiRflpALwVrqhFO[i]['startTime']
    if i==CtKSbPvNdaIXTBJjiRflpALwVrqhxM(CtKSbPvNdaIXTBJjiRflpALwVrqhFO)-1: CtKSbPvNdaIXTBJjiRflpALwVrqhFO[i]['endTime']=now_day+'240000'
  except CtKSbPvNdaIXTBJjiRflpALwVrqhec as exception:
   CtKSbPvNdaIXTBJjiRflpALwVrqhxO(exception)
   return[]
  return CtKSbPvNdaIXTBJjiRflpALwVrqhFO
 def GetEventLiveList(CtKSbPvNdaIXTBJjiRflpALwVrqhOn):
  CtKSbPvNdaIXTBJjiRflpALwVrqhMz=[]
  CtKSbPvNdaIXTBJjiRflpALwVrqhFk =0
  try:
   CtKSbPvNdaIXTBJjiRflpALwVrqhFy=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.Get_Now_Datetime()
   CtKSbPvNdaIXTBJjiRflpALwVrqhFs=CtKSbPvNdaIXTBJjiRflpALwVrqhFy.strftime('%Y-%m-%d')
  except CtKSbPvNdaIXTBJjiRflpALwVrqhec as exception:
   CtKSbPvNdaIXTBJjiRflpALwVrqhxO(exception)
   return CtKSbPvNdaIXTBJjiRflpALwVrqhMz,CtKSbPvNdaIXTBJjiRflpALwVrqhFk
  CtKSbPvNdaIXTBJjiRflpALwVrqhOs=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.API_DOMAIN+'/api/v3/player/lives/'+CtKSbPvNdaIXTBJjiRflpALwVrqhFs 
  CtKSbPvNdaIXTBJjiRflpALwVrqhOo=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.makeDefaultCookies()
  CtKSbPvNdaIXTBJjiRflpALwVrqhOz=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.callRequestCookies('Get',CtKSbPvNdaIXTBJjiRflpALwVrqhOs,payload=CtKSbPvNdaIXTBJjiRflpALwVrqhey,params=CtKSbPvNdaIXTBJjiRflpALwVrqhey,headers=CtKSbPvNdaIXTBJjiRflpALwVrqhey,cookies=CtKSbPvNdaIXTBJjiRflpALwVrqhOo)
  CtKSbPvNdaIXTBJjiRflpALwVrqhFk=CtKSbPvNdaIXTBJjiRflpALwVrqhOz.status_code 
  if CtKSbPvNdaIXTBJjiRflpALwVrqhFk!=200:return CtKSbPvNdaIXTBJjiRflpALwVrqhMz,CtKSbPvNdaIXTBJjiRflpALwVrqhFk
  CtKSbPvNdaIXTBJjiRflpALwVrqhMx=json.loads(CtKSbPvNdaIXTBJjiRflpALwVrqhOz.text)
  for CtKSbPvNdaIXTBJjiRflpALwVrqhFz in CtKSbPvNdaIXTBJjiRflpALwVrqhMx:
   for CtKSbPvNdaIXTBJjiRflpALwVrqhMG in CtKSbPvNdaIXTBJjiRflpALwVrqhFz['liveNowList']:
    if CtKSbPvNdaIXTBJjiRflpALwVrqhMG['gameDesc']['title']==CtKSbPvNdaIXTBJjiRflpALwVrqhey or CtKSbPvNdaIXTBJjiRflpALwVrqhMG['gameDesc']['title']=='':
     CtKSbPvNdaIXTBJjiRflpALwVrqhFg='%s ( %s : %s )'%(CtKSbPvNdaIXTBJjiRflpALwVrqhMG['leagueName'],CtKSbPvNdaIXTBJjiRflpALwVrqhMG['homeNameShort'],CtKSbPvNdaIXTBJjiRflpALwVrqhMG['awayNameShort'])
    else:
     CtKSbPvNdaIXTBJjiRflpALwVrqhFg=CtKSbPvNdaIXTBJjiRflpALwVrqhMG['gameDesc']['title']
    CtKSbPvNdaIXTBJjiRflpALwVrqhMm={'liveId':CtKSbPvNdaIXTBJjiRflpALwVrqhMG['liveId'],'title':CtKSbPvNdaIXTBJjiRflpALwVrqhFg,'logo':CtKSbPvNdaIXTBJjiRflpALwVrqhMG['gameDesc']['leagueLogo'],'free':CtKSbPvNdaIXTBJjiRflpALwVrqhMG['isFree'],'startTime':CtKSbPvNdaIXTBJjiRflpALwVrqhMG['startTime']}
    CtKSbPvNdaIXTBJjiRflpALwVrqhMz.append(CtKSbPvNdaIXTBJjiRflpALwVrqhMm)
  return CtKSbPvNdaIXTBJjiRflpALwVrqhMz,CtKSbPvNdaIXTBJjiRflpALwVrqhFk
 def GetEventLive_videoId(CtKSbPvNdaIXTBJjiRflpALwVrqhOn,liveId):
  CtKSbPvNdaIXTBJjiRflpALwVrqhFG=''
  try:
   CtKSbPvNdaIXTBJjiRflpALwVrqhOs=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.API_DOMAIN+'/api/v3/live/'+liveId
   CtKSbPvNdaIXTBJjiRflpALwVrqhOz=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.callRequestCookies('Get',CtKSbPvNdaIXTBJjiRflpALwVrqhOs,payload=CtKSbPvNdaIXTBJjiRflpALwVrqhey,params=CtKSbPvNdaIXTBJjiRflpALwVrqhey,headers=CtKSbPvNdaIXTBJjiRflpALwVrqhey,cookies=CtKSbPvNdaIXTBJjiRflpALwVrqhey)
   CtKSbPvNdaIXTBJjiRflpALwVrqhMx=json.loads(CtKSbPvNdaIXTBJjiRflpALwVrqhOz.text)
   CtKSbPvNdaIXTBJjiRflpALwVrqhFm=CtKSbPvNdaIXTBJjiRflpALwVrqhMx['videoId']
   CtKSbPvNdaIXTBJjiRflpALwVrqhFG=CtKSbPvNdaIXTBJjiRflpALwVrqhFm.replace('ref:','')
  except CtKSbPvNdaIXTBJjiRflpALwVrqhec as exception:
   CtKSbPvNdaIXTBJjiRflpALwVrqhxO(exception)
  return CtKSbPvNdaIXTBJjiRflpALwVrqhFG
 def CheckMainEnd(CtKSbPvNdaIXTBJjiRflpALwVrqhOn):
  CtKSbPvNdaIXTBJjiRflpALwVrqhFc=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.SPOTV_PMCODE+CtKSbPvNdaIXTBJjiRflpALwVrqhez(CtKSbPvNdaIXTBJjiRflpALwVrqhOn.ST['cookies']['spotv_sessionid'])
  CtKSbPvNdaIXTBJjiRflpALwVrqhFc=base64.standard_b64encode(CtKSbPvNdaIXTBJjiRflpALwVrqhFc.encode()).decode('utf-8')
  if CtKSbPvNdaIXTBJjiRflpALwVrqhFc=='OTg3MTgzMzM0Ng==' or CtKSbPvNdaIXTBJjiRflpALwVrqhFc=='OTg3MTgzMzExNw==':return CtKSbPvNdaIXTBJjiRflpALwVrqheG
  return CtKSbPvNdaIXTBJjiRflpALwVrqhes
 def CheckSubEnd(CtKSbPvNdaIXTBJjiRflpALwVrqhOn):
  CtKSbPvNdaIXTBJjiRflpALwVrqhOY=CtKSbPvNdaIXTBJjiRflpALwVrqhes
  try:
   if CtKSbPvNdaIXTBJjiRflpALwVrqhOn.CheckMainEnd():return CtKSbPvNdaIXTBJjiRflpALwVrqheG 
   CtKSbPvNdaIXTBJjiRflpALwVrqhnO=base64.standard_b64decode(CtKSbPvNdaIXTBJjiRflpALwVrqhOn.ST['cookies']['spotv_subend']).decode('utf-8')[CtKSbPvNdaIXTBJjiRflpALwVrqhOn.SPOTV_PMSIZE:]
   if CtKSbPvNdaIXTBJjiRflpALwVrqhnO=='0':return CtKSbPvNdaIXTBJjiRflpALwVrqhOY
   CtKSbPvNdaIXTBJjiRflpALwVrqhnM =CtKSbPvNdaIXTBJjiRflpALwVrqhem(CtKSbPvNdaIXTBJjiRflpALwVrqhOn.Get_Now_Datetime().strftime('%Y%m%d'))
   CtKSbPvNdaIXTBJjiRflpALwVrqhnF =CtKSbPvNdaIXTBJjiRflpALwVrqhem(CtKSbPvNdaIXTBJjiRflpALwVrqhnO)/1000
   CtKSbPvNdaIXTBJjiRflpALwVrqhne =CtKSbPvNdaIXTBJjiRflpALwVrqhem(datetime.datetime.fromtimestamp(CtKSbPvNdaIXTBJjiRflpALwVrqhnF,datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul')).strftime('%Y%m%d'))
   if CtKSbPvNdaIXTBJjiRflpALwVrqhnM<=CtKSbPvNdaIXTBJjiRflpALwVrqhne:CtKSbPvNdaIXTBJjiRflpALwVrqhOY=CtKSbPvNdaIXTBJjiRflpALwVrqheG
  except CtKSbPvNdaIXTBJjiRflpALwVrqhec as exception:
   CtKSbPvNdaIXTBJjiRflpALwVrqhxO(exception)
   return CtKSbPvNdaIXTBJjiRflpALwVrqhOY
  return CtKSbPvNdaIXTBJjiRflpALwVrqhOY
 def GetBroadURL(CtKSbPvNdaIXTBJjiRflpALwVrqhOn,CtKSbPvNdaIXTBJjiRflpALwVrqhFG,mediatype,CtKSbPvNdaIXTBJjiRflpALwVrqhno):
  CtKSbPvNdaIXTBJjiRflpALwVrqhnx=''
  try:
   if mediatype=='live':
    CtKSbPvNdaIXTBJjiRflpALwVrqhOs=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.API_DOMAIN+'/api/v3/live/'+CtKSbPvNdaIXTBJjiRflpALwVrqhFG
   else:
    CtKSbPvNdaIXTBJjiRflpALwVrqhFG=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.GetReplay_UrlId(CtKSbPvNdaIXTBJjiRflpALwVrqhFG,CtKSbPvNdaIXTBJjiRflpALwVrqhno)
    if CtKSbPvNdaIXTBJjiRflpALwVrqhFG=='':return CtKSbPvNdaIXTBJjiRflpALwVrqhnx
    CtKSbPvNdaIXTBJjiRflpALwVrqhOs=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.PLAYER_DOMAIN+'/playback/v1/accounts/'+CtKSbPvNdaIXTBJjiRflpALwVrqhez(CtKSbPvNdaIXTBJjiRflpALwVrqhOn.ST['cookies']['spotv_accountId'])+'/videos/'+CtKSbPvNdaIXTBJjiRflpALwVrqhFG
   CtKSbPvNdaIXTBJjiRflpALwVrqhOQ=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.makeDefaultHeaders()
   CtKSbPvNdaIXTBJjiRflpALwVrqhOz=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.callRequestCookies('Get',CtKSbPvNdaIXTBJjiRflpALwVrqhOs,payload=CtKSbPvNdaIXTBJjiRflpALwVrqhey,params=CtKSbPvNdaIXTBJjiRflpALwVrqhey,headers=CtKSbPvNdaIXTBJjiRflpALwVrqhOQ,cookies=CtKSbPvNdaIXTBJjiRflpALwVrqhey)
   CtKSbPvNdaIXTBJjiRflpALwVrqhMO=json.loads(CtKSbPvNdaIXTBJjiRflpALwVrqhOz.text)
   CtKSbPvNdaIXTBJjiRflpALwVrqhxO(CtKSbPvNdaIXTBJjiRflpALwVrqhOs)
   if mediatype=='live':
    CtKSbPvNdaIXTBJjiRflpALwVrqhnx=CtKSbPvNdaIXTBJjiRflpALwVrqhMO['hlsUrl2']or CtKSbPvNdaIXTBJjiRflpALwVrqhMO['hlsUrl']
   else:
    CtKSbPvNdaIXTBJjiRflpALwVrqhxO(CtKSbPvNdaIXTBJjiRflpALwVrqhMO)
    CtKSbPvNdaIXTBJjiRflpALwVrqhnx=CtKSbPvNdaIXTBJjiRflpALwVrqhMO['sources'][0]['src']
   CtKSbPvNdaIXTBJjiRflpALwVrqhnx=CtKSbPvNdaIXTBJjiRflpALwVrqhnx.replace('http://','https://')
  except CtKSbPvNdaIXTBJjiRflpALwVrqhec as exception:
   CtKSbPvNdaIXTBJjiRflpALwVrqhxO(exception)
  return CtKSbPvNdaIXTBJjiRflpALwVrqhnx
 def GetTitleGroupList(CtKSbPvNdaIXTBJjiRflpALwVrqhOn):
  CtKSbPvNdaIXTBJjiRflpALwVrqhMz=[]
  CtKSbPvNdaIXTBJjiRflpALwVrqhOs=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.API_DOMAIN+'/api/v3/home/web'
  CtKSbPvNdaIXTBJjiRflpALwVrqhOz=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.callRequestCookies('Get',CtKSbPvNdaIXTBJjiRflpALwVrqhOs,payload=CtKSbPvNdaIXTBJjiRflpALwVrqhey,params=CtKSbPvNdaIXTBJjiRflpALwVrqhey,headers=CtKSbPvNdaIXTBJjiRflpALwVrqhey,cookies=CtKSbPvNdaIXTBJjiRflpALwVrqhey)
  CtKSbPvNdaIXTBJjiRflpALwVrqhMx=json.loads(CtKSbPvNdaIXTBJjiRflpALwVrqhOz.text)
  for CtKSbPvNdaIXTBJjiRflpALwVrqhMG in CtKSbPvNdaIXTBJjiRflpALwVrqhMx:
   if CtKSbPvNdaIXTBJjiRflpALwVrqhez(CtKSbPvNdaIXTBJjiRflpALwVrqhMG['type'])=='3':
    CtKSbPvNdaIXTBJjiRflpALwVrqhnD=''
    for CtKSbPvNdaIXTBJjiRflpALwVrqhnE in CtKSbPvNdaIXTBJjiRflpALwVrqhMG['data']['list']:
     CtKSbPvNdaIXTBJjiRflpALwVrqhnH='[%s] %s vs %s\n<%s>\n\n'%(CtKSbPvNdaIXTBJjiRflpALwVrqhnE['gameDesc']['roundName'],CtKSbPvNdaIXTBJjiRflpALwVrqhnE['gameDesc']['homeNameShort'],CtKSbPvNdaIXTBJjiRflpALwVrqhnE['gameDesc']['awayNameShort'],CtKSbPvNdaIXTBJjiRflpALwVrqhnE['gameDesc']['beginDate'])
     CtKSbPvNdaIXTBJjiRflpALwVrqhnD+=CtKSbPvNdaIXTBJjiRflpALwVrqhnH
    CtKSbPvNdaIXTBJjiRflpALwVrqhMm={'title':CtKSbPvNdaIXTBJjiRflpALwVrqhMG['title'],'logo':CtKSbPvNdaIXTBJjiRflpALwVrqhMG['logo'],'reagueId':CtKSbPvNdaIXTBJjiRflpALwVrqhez(CtKSbPvNdaIXTBJjiRflpALwVrqhMG['destId']),'subGame':CtKSbPvNdaIXTBJjiRflpALwVrqhnD,}
    CtKSbPvNdaIXTBJjiRflpALwVrqhMz.append(CtKSbPvNdaIXTBJjiRflpALwVrqhMm)
  return CtKSbPvNdaIXTBJjiRflpALwVrqhMz
 def GetPopularGroupList(CtKSbPvNdaIXTBJjiRflpALwVrqhOn):
  CtKSbPvNdaIXTBJjiRflpALwVrqhMz=[]
  CtKSbPvNdaIXTBJjiRflpALwVrqhOs=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.API_DOMAIN+'/api/v3/home/web'
  CtKSbPvNdaIXTBJjiRflpALwVrqhOz=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.callRequestCookies('Get',CtKSbPvNdaIXTBJjiRflpALwVrqhOs,payload=CtKSbPvNdaIXTBJjiRflpALwVrqhey,params=CtKSbPvNdaIXTBJjiRflpALwVrqhey,headers=CtKSbPvNdaIXTBJjiRflpALwVrqhey,cookies=CtKSbPvNdaIXTBJjiRflpALwVrqhey)
  CtKSbPvNdaIXTBJjiRflpALwVrqhMx=json.loads(CtKSbPvNdaIXTBJjiRflpALwVrqhOz.text)
  for CtKSbPvNdaIXTBJjiRflpALwVrqhMG in CtKSbPvNdaIXTBJjiRflpALwVrqhMx:
   if CtKSbPvNdaIXTBJjiRflpALwVrqhez(CtKSbPvNdaIXTBJjiRflpALwVrqhMG['type'])=='1' and CtKSbPvNdaIXTBJjiRflpALwVrqhez(CtKSbPvNdaIXTBJjiRflpALwVrqhMG['destId'])=='4':
    for CtKSbPvNdaIXTBJjiRflpALwVrqhnE in CtKSbPvNdaIXTBJjiRflpALwVrqhMG['data']['list']:
     CtKSbPvNdaIXTBJjiRflpALwVrqhnW =CtKSbPvNdaIXTBJjiRflpALwVrqhnE['title']
     CtKSbPvNdaIXTBJjiRflpALwVrqhnY =CtKSbPvNdaIXTBJjiRflpALwVrqhnE['id']
     CtKSbPvNdaIXTBJjiRflpALwVrqhnu =CtKSbPvNdaIXTBJjiRflpALwVrqhnE['vtype']
     CtKSbPvNdaIXTBJjiRflpALwVrqhnU =CtKSbPvNdaIXTBJjiRflpALwVrqhnE['imgUrl']
     CtKSbPvNdaIXTBJjiRflpALwVrqhno =CtKSbPvNdaIXTBJjiRflpALwVrqhnE['vtypeId']
     CtKSbPvNdaIXTBJjiRflpALwVrqhMm={'vodTitle':CtKSbPvNdaIXTBJjiRflpALwVrqhnW,'vodId':CtKSbPvNdaIXTBJjiRflpALwVrqhnY,'vodType':CtKSbPvNdaIXTBJjiRflpALwVrqhnu,'thumbnail':CtKSbPvNdaIXTBJjiRflpALwVrqhnU,'vtypeId':CtKSbPvNdaIXTBJjiRflpALwVrqhez(CtKSbPvNdaIXTBJjiRflpALwVrqhno),'duration':CtKSbPvNdaIXTBJjiRflpALwVrqhem(CtKSbPvNdaIXTBJjiRflpALwVrqhnE['duration']/1000),}
     CtKSbPvNdaIXTBJjiRflpALwVrqhMz.append(CtKSbPvNdaIXTBJjiRflpALwVrqhMm)
  return CtKSbPvNdaIXTBJjiRflpALwVrqhMz
 def Get_NowVod_GroupList(CtKSbPvNdaIXTBJjiRflpALwVrqhOn,page_int):
  CtKSbPvNdaIXTBJjiRflpALwVrqhMz=[]
  CtKSbPvNdaIXTBJjiRflpALwVrqhnQ=CtKSbPvNdaIXTBJjiRflpALwVrqhes
  CtKSbPvNdaIXTBJjiRflpALwVrqhOs=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.API_DOMAIN+'/api/v3/theme/14/list'
  CtKSbPvNdaIXTBJjiRflpALwVrqhnk={'pageItem':'10','pageNo':CtKSbPvNdaIXTBJjiRflpALwVrqhez(page_int)}
  CtKSbPvNdaIXTBJjiRflpALwVrqhOz=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.callRequestCookies('Get',CtKSbPvNdaIXTBJjiRflpALwVrqhOs,payload=CtKSbPvNdaIXTBJjiRflpALwVrqhey,params=CtKSbPvNdaIXTBJjiRflpALwVrqhnk,headers=CtKSbPvNdaIXTBJjiRflpALwVrqhey,cookies=CtKSbPvNdaIXTBJjiRflpALwVrqhey)
  CtKSbPvNdaIXTBJjiRflpALwVrqhMx=json.loads(CtKSbPvNdaIXTBJjiRflpALwVrqhOz.text)
  for CtKSbPvNdaIXTBJjiRflpALwVrqhMG in CtKSbPvNdaIXTBJjiRflpALwVrqhMx['list']:
   CtKSbPvNdaIXTBJjiRflpALwVrqhnW =CtKSbPvNdaIXTBJjiRflpALwVrqhMG['title']
   CtKSbPvNdaIXTBJjiRflpALwVrqhnY =CtKSbPvNdaIXTBJjiRflpALwVrqhMG['id']
   CtKSbPvNdaIXTBJjiRflpALwVrqhnu =CtKSbPvNdaIXTBJjiRflpALwVrqhMG['vtype']
   CtKSbPvNdaIXTBJjiRflpALwVrqhnU =CtKSbPvNdaIXTBJjiRflpALwVrqhMG['imgUrl']
   CtKSbPvNdaIXTBJjiRflpALwVrqhno =CtKSbPvNdaIXTBJjiRflpALwVrqhMG['vtypeId']
   CtKSbPvNdaIXTBJjiRflpALwVrqhMm={'vodTitle':CtKSbPvNdaIXTBJjiRflpALwVrqhnW,'vodId':CtKSbPvNdaIXTBJjiRflpALwVrqhnY,'vodType':CtKSbPvNdaIXTBJjiRflpALwVrqhnu,'thumbnail':CtKSbPvNdaIXTBJjiRflpALwVrqhnU,'vtypeId':CtKSbPvNdaIXTBJjiRflpALwVrqhez(CtKSbPvNdaIXTBJjiRflpALwVrqhno),'duration':CtKSbPvNdaIXTBJjiRflpALwVrqhem(CtKSbPvNdaIXTBJjiRflpALwVrqhMG['duration']/1000),}
   CtKSbPvNdaIXTBJjiRflpALwVrqhMz.append(CtKSbPvNdaIXTBJjiRflpALwVrqhMm)
   if CtKSbPvNdaIXTBJjiRflpALwVrqhMx['count']>page_int*CtKSbPvNdaIXTBJjiRflpALwVrqhOn.GAMELIST_LIMIT:CtKSbPvNdaIXTBJjiRflpALwVrqhnQ=CtKSbPvNdaIXTBJjiRflpALwVrqheG
  return CtKSbPvNdaIXTBJjiRflpALwVrqhMz,CtKSbPvNdaIXTBJjiRflpALwVrqhnQ
 def GetSeasonList(CtKSbPvNdaIXTBJjiRflpALwVrqhOn,leagueId):
  CtKSbPvNdaIXTBJjiRflpALwVrqhMz=[]
  CtKSbPvNdaIXTBJjiRflpALwVrqhny=CtKSbPvNdaIXTBJjiRflpALwVrqhns=''
  try:
   CtKSbPvNdaIXTBJjiRflpALwVrqhOs=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.API_DOMAIN+'/api/v3/game/league/'+leagueId
   CtKSbPvNdaIXTBJjiRflpALwVrqhOz=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.callRequestCookies('Get',CtKSbPvNdaIXTBJjiRflpALwVrqhOs,payload=CtKSbPvNdaIXTBJjiRflpALwVrqhey,params=CtKSbPvNdaIXTBJjiRflpALwVrqhey,headers=CtKSbPvNdaIXTBJjiRflpALwVrqhey,cookies=CtKSbPvNdaIXTBJjiRflpALwVrqhey)
   CtKSbPvNdaIXTBJjiRflpALwVrqhMx=json.loads(CtKSbPvNdaIXTBJjiRflpALwVrqhOz.text)
   CtKSbPvNdaIXTBJjiRflpALwVrqhny=CtKSbPvNdaIXTBJjiRflpALwVrqhMx['name']
   CtKSbPvNdaIXTBJjiRflpALwVrqhns=CtKSbPvNdaIXTBJjiRflpALwVrqhez(CtKSbPvNdaIXTBJjiRflpALwVrqhMx['gameTypeId'])
  except CtKSbPvNdaIXTBJjiRflpALwVrqhec as exception:
   CtKSbPvNdaIXTBJjiRflpALwVrqhxO(exception)
   return CtKSbPvNdaIXTBJjiRflpALwVrqhMz
  if CtKSbPvNdaIXTBJjiRflpALwVrqhns in['2','5','6','8']:
   try:
    CtKSbPvNdaIXTBJjiRflpALwVrqhOs=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.API_DOMAIN+'/api/v3/year/'+leagueId
    CtKSbPvNdaIXTBJjiRflpALwVrqhOz=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.callRequestCookies('Get',CtKSbPvNdaIXTBJjiRflpALwVrqhOs,payload=CtKSbPvNdaIXTBJjiRflpALwVrqhey,params=CtKSbPvNdaIXTBJjiRflpALwVrqhey,headers=CtKSbPvNdaIXTBJjiRflpALwVrqhey,cookies=CtKSbPvNdaIXTBJjiRflpALwVrqhey)
    CtKSbPvNdaIXTBJjiRflpALwVrqhMx=json.loads(CtKSbPvNdaIXTBJjiRflpALwVrqhOz.text)
    for CtKSbPvNdaIXTBJjiRflpALwVrqhMG in CtKSbPvNdaIXTBJjiRflpALwVrqhMx:
     CtKSbPvNdaIXTBJjiRflpALwVrqhMm={'reagueName':CtKSbPvNdaIXTBJjiRflpALwVrqhny,'gameTypeId':CtKSbPvNdaIXTBJjiRflpALwVrqhns,'seasonName':CtKSbPvNdaIXTBJjiRflpALwVrqhez(CtKSbPvNdaIXTBJjiRflpALwVrqhMG),'seasonId':CtKSbPvNdaIXTBJjiRflpALwVrqhez(CtKSbPvNdaIXTBJjiRflpALwVrqhMG)}
     CtKSbPvNdaIXTBJjiRflpALwVrqhMz.append(CtKSbPvNdaIXTBJjiRflpALwVrqhMm)
   except CtKSbPvNdaIXTBJjiRflpALwVrqhec as exception:
    CtKSbPvNdaIXTBJjiRflpALwVrqhxO(exception)
    return[]
  else:
   try:
    CtKSbPvNdaIXTBJjiRflpALwVrqhOs=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.API_DOMAIN+'/api/v3/season/'+leagueId
    CtKSbPvNdaIXTBJjiRflpALwVrqhOz=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.callRequestCookies('Get',CtKSbPvNdaIXTBJjiRflpALwVrqhOs,payload=CtKSbPvNdaIXTBJjiRflpALwVrqhey,params=CtKSbPvNdaIXTBJjiRflpALwVrqhey,headers=CtKSbPvNdaIXTBJjiRflpALwVrqhey,cookies=CtKSbPvNdaIXTBJjiRflpALwVrqhey)
    CtKSbPvNdaIXTBJjiRflpALwVrqhMx=json.loads(CtKSbPvNdaIXTBJjiRflpALwVrqhOz.text)
    for CtKSbPvNdaIXTBJjiRflpALwVrqhMG in CtKSbPvNdaIXTBJjiRflpALwVrqhMx:
     CtKSbPvNdaIXTBJjiRflpALwVrqhMm={'reagueName':CtKSbPvNdaIXTBJjiRflpALwVrqhny,'gameTypeId':CtKSbPvNdaIXTBJjiRflpALwVrqhns,'seasonName':CtKSbPvNdaIXTBJjiRflpALwVrqhMG['name'],'seasonId':CtKSbPvNdaIXTBJjiRflpALwVrqhez(CtKSbPvNdaIXTBJjiRflpALwVrqhMG['id'])}
     CtKSbPvNdaIXTBJjiRflpALwVrqhMz.append(CtKSbPvNdaIXTBJjiRflpALwVrqhMm)
   except CtKSbPvNdaIXTBJjiRflpALwVrqhec as exception:
    CtKSbPvNdaIXTBJjiRflpALwVrqhxO(exception)
    return[]
  return CtKSbPvNdaIXTBJjiRflpALwVrqhMz
 def GetGameList(CtKSbPvNdaIXTBJjiRflpALwVrqhOn,CtKSbPvNdaIXTBJjiRflpALwVrqhns,leagueId,seasonId,page_int,hidescore=CtKSbPvNdaIXTBJjiRflpALwVrqheG):
  CtKSbPvNdaIXTBJjiRflpALwVrqhMz=[]
  CtKSbPvNdaIXTBJjiRflpALwVrqhnQ=CtKSbPvNdaIXTBJjiRflpALwVrqhes
  try:
   CtKSbPvNdaIXTBJjiRflpALwVrqhOs=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.API_DOMAIN+'/api/v3/vod/league/detail'
   CtKSbPvNdaIXTBJjiRflpALwVrqhnk={'gameType':CtKSbPvNdaIXTBJjiRflpALwVrqhns,'leagueId':leagueId,'seasonId':seasonId if CtKSbPvNdaIXTBJjiRflpALwVrqhns not in['2','5','6','8']else '','teamId':'','roundId':'','year':'' if CtKSbPvNdaIXTBJjiRflpALwVrqhns not in['2','5','6','8']else seasonId,'pageNo':CtKSbPvNdaIXTBJjiRflpALwVrqhez(page_int)}
   CtKSbPvNdaIXTBJjiRflpALwVrqhOz=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.callRequestCookies('Get',CtKSbPvNdaIXTBJjiRflpALwVrqhOs,payload=CtKSbPvNdaIXTBJjiRflpALwVrqhey,params=CtKSbPvNdaIXTBJjiRflpALwVrqhnk,headers=CtKSbPvNdaIXTBJjiRflpALwVrqhey,cookies=CtKSbPvNdaIXTBJjiRflpALwVrqhey)
   CtKSbPvNdaIXTBJjiRflpALwVrqhMx=json.loads(CtKSbPvNdaIXTBJjiRflpALwVrqhOz.text)
   CtKSbPvNdaIXTBJjiRflpALwVrqhFz=CtKSbPvNdaIXTBJjiRflpALwVrqhMx['list']
   for CtKSbPvNdaIXTBJjiRflpALwVrqhnz in CtKSbPvNdaIXTBJjiRflpALwVrqhFz:
    for CtKSbPvNdaIXTBJjiRflpALwVrqhMG in CtKSbPvNdaIXTBJjiRflpALwVrqhnz['list']:
     if CtKSbPvNdaIXTBJjiRflpALwVrqhMG['gameDesc']['title']==CtKSbPvNdaIXTBJjiRflpALwVrqhey or CtKSbPvNdaIXTBJjiRflpALwVrqhMG['gameDesc']['title']=='':
      CtKSbPvNdaIXTBJjiRflpALwVrqhFg ='%s vs %s'%(CtKSbPvNdaIXTBJjiRflpALwVrqhMG['gameDesc']['homeNameShort'],CtKSbPvNdaIXTBJjiRflpALwVrqhMG['gameDesc']['awayNameShort'])
     else:
      CtKSbPvNdaIXTBJjiRflpALwVrqhFg =CtKSbPvNdaIXTBJjiRflpALwVrqhMG['gameDesc']['title']
     CtKSbPvNdaIXTBJjiRflpALwVrqhng =CtKSbPvNdaIXTBJjiRflpALwVrqhMG['gameDesc']['beginDate']
     CtKSbPvNdaIXTBJjiRflpALwVrqhnG =CtKSbPvNdaIXTBJjiRflpALwVrqhMG['gameDesc']['id']
     CtKSbPvNdaIXTBJjiRflpALwVrqhnm =CtKSbPvNdaIXTBJjiRflpALwVrqhMG['gameDesc']['leagueNameFull']
     CtKSbPvNdaIXTBJjiRflpALwVrqhnc =CtKSbPvNdaIXTBJjiRflpALwVrqhMG['gameDesc']['seasonName']
     CtKSbPvNdaIXTBJjiRflpALwVrqheO =CtKSbPvNdaIXTBJjiRflpALwVrqhMG['gameDesc']['roundName']
     CtKSbPvNdaIXTBJjiRflpALwVrqheM =CtKSbPvNdaIXTBJjiRflpALwVrqhMG['gameDesc']['homeName']
     CtKSbPvNdaIXTBJjiRflpALwVrqheF =CtKSbPvNdaIXTBJjiRflpALwVrqhMG['gameDesc']['awayName']
     CtKSbPvNdaIXTBJjiRflpALwVrqhen =CtKSbPvNdaIXTBJjiRflpALwVrqhMG['gameDesc']['homeScore']
     CtKSbPvNdaIXTBJjiRflpALwVrqhex =CtKSbPvNdaIXTBJjiRflpALwVrqhMG['gameDesc']['awayScore']
     if hidescore==CtKSbPvNdaIXTBJjiRflpALwVrqheG:
      CtKSbPvNdaIXTBJjiRflpALwVrqheD ='%s\n - %s (%s)\n - %s\n\nhome : %s\n\naway : %s'%(CtKSbPvNdaIXTBJjiRflpALwVrqhnm,CtKSbPvNdaIXTBJjiRflpALwVrqhnc,CtKSbPvNdaIXTBJjiRflpALwVrqheO,CtKSbPvNdaIXTBJjiRflpALwVrqhng,CtKSbPvNdaIXTBJjiRflpALwVrqheM,CtKSbPvNdaIXTBJjiRflpALwVrqheF)
     else:
      CtKSbPvNdaIXTBJjiRflpALwVrqheD ='%s\n - %s (%s)\n - %s\n\nhome : %s (Score %s)\n\naway : %s (Score %s)'%(CtKSbPvNdaIXTBJjiRflpALwVrqhnm,CtKSbPvNdaIXTBJjiRflpALwVrqhnc,CtKSbPvNdaIXTBJjiRflpALwVrqheO,CtKSbPvNdaIXTBJjiRflpALwVrqhng,CtKSbPvNdaIXTBJjiRflpALwVrqheM,CtKSbPvNdaIXTBJjiRflpALwVrqhen,CtKSbPvNdaIXTBJjiRflpALwVrqheF,CtKSbPvNdaIXTBJjiRflpALwVrqhex)
     CtKSbPvNdaIXTBJjiRflpALwVrqheE=CtKSbPvNdaIXTBJjiRflpALwVrqheD
     CtKSbPvNdaIXTBJjiRflpALwVrqheH =CtKSbPvNdaIXTBJjiRflpALwVrqhMG['replayVod']['count']
     CtKSbPvNdaIXTBJjiRflpALwVrqheW=CtKSbPvNdaIXTBJjiRflpALwVrqhMG['highlightVod']['count']
     CtKSbPvNdaIXTBJjiRflpALwVrqheY =CtKSbPvNdaIXTBJjiRflpALwVrqhMG['vods']['count']
     CtKSbPvNdaIXTBJjiRflpALwVrqhnU='' 
     CtKSbPvNdaIXTBJjiRflpALwVrqheu=CtKSbPvNdaIXTBJjiRflpALwVrqheH+CtKSbPvNdaIXTBJjiRflpALwVrqheW+CtKSbPvNdaIXTBJjiRflpALwVrqheY
     if CtKSbPvNdaIXTBJjiRflpALwVrqheu==0:
      if CtKSbPvNdaIXTBJjiRflpALwVrqhns=='2':
       CtKSbPvNdaIXTBJjiRflpALwVrqhFg='----- %s -----'%(CtKSbPvNdaIXTBJjiRflpALwVrqhnc)
       CtKSbPvNdaIXTBJjiRflpALwVrqhng=''
      else:
       CtKSbPvNdaIXTBJjiRflpALwVrqhFg+=' - 관련영상 없음'
       CtKSbPvNdaIXTBJjiRflpALwVrqheE+='\n\n ** 관련영상 없음 **'
     else:
      if CtKSbPvNdaIXTBJjiRflpALwVrqheH!=0:
       CtKSbPvNdaIXTBJjiRflpALwVrqhnU =CtKSbPvNdaIXTBJjiRflpALwVrqhMG['replayVod']['list'][0]['imgUrl']
      elif CtKSbPvNdaIXTBJjiRflpALwVrqheW!=0:
       CtKSbPvNdaIXTBJjiRflpALwVrqhnU =CtKSbPvNdaIXTBJjiRflpALwVrqhMG['highlightVod']['list'][0]['imgUrl']
      else:
       CtKSbPvNdaIXTBJjiRflpALwVrqhnU =CtKSbPvNdaIXTBJjiRflpALwVrqhMG['vods']['list'][0]['imgUrl']
     CtKSbPvNdaIXTBJjiRflpALwVrqhMm={'gameTitle':CtKSbPvNdaIXTBJjiRflpALwVrqhFg,'gameId':CtKSbPvNdaIXTBJjiRflpALwVrqhnG,'beginDate':CtKSbPvNdaIXTBJjiRflpALwVrqhng[:11],'thumbnail':CtKSbPvNdaIXTBJjiRflpALwVrqhnU,'info_plot':CtKSbPvNdaIXTBJjiRflpALwVrqheE,'leaguenm':CtKSbPvNdaIXTBJjiRflpALwVrqhnm,'seasonnm':CtKSbPvNdaIXTBJjiRflpALwVrqhnc,'roundnm':CtKSbPvNdaIXTBJjiRflpALwVrqheO,'totVodCnt':CtKSbPvNdaIXTBJjiRflpALwVrqheu}
     CtKSbPvNdaIXTBJjiRflpALwVrqhMz.append(CtKSbPvNdaIXTBJjiRflpALwVrqhMm)
  except CtKSbPvNdaIXTBJjiRflpALwVrqhec as exception:
   CtKSbPvNdaIXTBJjiRflpALwVrqhxO(exception)
  if CtKSbPvNdaIXTBJjiRflpALwVrqhMx['count']>page_int*CtKSbPvNdaIXTBJjiRflpALwVrqhOn.GAMELIST_LIMIT:CtKSbPvNdaIXTBJjiRflpALwVrqhnQ=CtKSbPvNdaIXTBJjiRflpALwVrqheG
  return CtKSbPvNdaIXTBJjiRflpALwVrqhMz,CtKSbPvNdaIXTBJjiRflpALwVrqhnQ
 def GetGameVodList(CtKSbPvNdaIXTBJjiRflpALwVrqhOn,CtKSbPvNdaIXTBJjiRflpALwVrqhnG,vodCount=1000):
  CtKSbPvNdaIXTBJjiRflpALwVrqhMz=[]
  CtKSbPvNdaIXTBJjiRflpALwVrqheU=''
  try:
   CtKSbPvNdaIXTBJjiRflpALwVrqhOs=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.API_DOMAIN+'/api/v3/vod/game'
   CtKSbPvNdaIXTBJjiRflpALwVrqhnk={'gameId':CtKSbPvNdaIXTBJjiRflpALwVrqhnG,'pageItem':CtKSbPvNdaIXTBJjiRflpALwVrqhez(vodCount)}
   CtKSbPvNdaIXTBJjiRflpALwVrqhOz=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.callRequestCookies('Get',CtKSbPvNdaIXTBJjiRflpALwVrqhOs,payload=CtKSbPvNdaIXTBJjiRflpALwVrqhey,params=CtKSbPvNdaIXTBJjiRflpALwVrqhnk,headers=CtKSbPvNdaIXTBJjiRflpALwVrqhey,cookies=CtKSbPvNdaIXTBJjiRflpALwVrqhey)
   CtKSbPvNdaIXTBJjiRflpALwVrqhMx=json.loads(CtKSbPvNdaIXTBJjiRflpALwVrqhOz.text)
   CtKSbPvNdaIXTBJjiRflpALwVrqhnz=CtKSbPvNdaIXTBJjiRflpALwVrqhMx['list']
   for CtKSbPvNdaIXTBJjiRflpALwVrqhMG in CtKSbPvNdaIXTBJjiRflpALwVrqhnz:
    CtKSbPvNdaIXTBJjiRflpALwVrqhnW =CtKSbPvNdaIXTBJjiRflpALwVrqhMG['title']
    CtKSbPvNdaIXTBJjiRflpALwVrqhnY =CtKSbPvNdaIXTBJjiRflpALwVrqhMG['id']
    CtKSbPvNdaIXTBJjiRflpALwVrqhnu =CtKSbPvNdaIXTBJjiRflpALwVrqhMG['vtype']
    CtKSbPvNdaIXTBJjiRflpALwVrqhnU =CtKSbPvNdaIXTBJjiRflpALwVrqhMG['imgUrl']
    CtKSbPvNdaIXTBJjiRflpALwVrqhno =CtKSbPvNdaIXTBJjiRflpALwVrqhMG['vtypeId']
    CtKSbPvNdaIXTBJjiRflpALwVrqheo =CtKSbPvNdaIXTBJjiRflpALwVrqhMG['isFree']
    CtKSbPvNdaIXTBJjiRflpALwVrqhMm={'vodTitle':CtKSbPvNdaIXTBJjiRflpALwVrqhnW,'vodId':CtKSbPvNdaIXTBJjiRflpALwVrqhnY,'vodType':CtKSbPvNdaIXTBJjiRflpALwVrqhnu,'thumbnail':CtKSbPvNdaIXTBJjiRflpALwVrqhnU,'vtypeId':CtKSbPvNdaIXTBJjiRflpALwVrqhez(CtKSbPvNdaIXTBJjiRflpALwVrqhno),'duration':CtKSbPvNdaIXTBJjiRflpALwVrqhem(CtKSbPvNdaIXTBJjiRflpALwVrqhMG['duration']/1000),'isFree':CtKSbPvNdaIXTBJjiRflpALwVrqheo}
    CtKSbPvNdaIXTBJjiRflpALwVrqhMz.append(CtKSbPvNdaIXTBJjiRflpALwVrqhMm)
  except CtKSbPvNdaIXTBJjiRflpALwVrqhec as exception:
   CtKSbPvNdaIXTBJjiRflpALwVrqhxO(exception)
  return CtKSbPvNdaIXTBJjiRflpALwVrqhMz
 def GetReplay_UrlId(CtKSbPvNdaIXTBJjiRflpALwVrqhOn,CtKSbPvNdaIXTBJjiRflpALwVrqheU,CtKSbPvNdaIXTBJjiRflpALwVrqhno):
  CtKSbPvNdaIXTBJjiRflpALwVrqheQ=''
  try:
   CtKSbPvNdaIXTBJjiRflpALwVrqhOs=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.API_DOMAIN+'/api/v3/vod/'+CtKSbPvNdaIXTBJjiRflpALwVrqheU
   CtKSbPvNdaIXTBJjiRflpALwVrqhOz=CtKSbPvNdaIXTBJjiRflpALwVrqhOn.callRequestCookies('Get',CtKSbPvNdaIXTBJjiRflpALwVrqhOs,payload=CtKSbPvNdaIXTBJjiRflpALwVrqhey,params=CtKSbPvNdaIXTBJjiRflpALwVrqhey,headers=CtKSbPvNdaIXTBJjiRflpALwVrqhey,cookies=CtKSbPvNdaIXTBJjiRflpALwVrqhey)
   CtKSbPvNdaIXTBJjiRflpALwVrqhMx=json.loads(CtKSbPvNdaIXTBJjiRflpALwVrqhOz.text)
   CtKSbPvNdaIXTBJjiRflpALwVrqheQ=CtKSbPvNdaIXTBJjiRflpALwVrqhMx['videoId']
  except CtKSbPvNdaIXTBJjiRflpALwVrqhec as exception:
   CtKSbPvNdaIXTBJjiRflpALwVrqhxO(exception)
  return CtKSbPvNdaIXTBJjiRflpALwVrqheQ
# Created by pyminifier (https://github.com/liftoff/pyminifier)
