__author__="NightRain"
LfgdBCoaAnstDOEShJeHlFkGmzrRXw=object
LfgdBCoaAnstDOEShJeHlFkGmzrRXV=None
LfgdBCoaAnstDOEShJeHlFkGmzrRXY=False
LfgdBCoaAnstDOEShJeHlFkGmzrRpc=True
LfgdBCoaAnstDOEShJeHlFkGmzrRpI=getattr
LfgdBCoaAnstDOEShJeHlFkGmzrRpv=type
LfgdBCoaAnstDOEShJeHlFkGmzrRpx=int
LfgdBCoaAnstDOEShJeHlFkGmzrRpX=list
LfgdBCoaAnstDOEShJeHlFkGmzrRpP=len
LfgdBCoaAnstDOEShJeHlFkGmzrRpW=str
LfgdBCoaAnstDOEShJeHlFkGmzrRpT=id
LfgdBCoaAnstDOEShJeHlFkGmzrRpb=open
LfgdBCoaAnstDOEShJeHlFkGmzrRpq=dict
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
LfgdBCoaAnstDOEShJeHlFkGmzrRcv=[{'title':'TV 채널 (유료사용자만 지원)','mode':'LIVE_GROUP','icon':'live.png'},{'title':'Live중계 (경기중에만 재생)','mode':'ELIVE_GROUP','icon':'live.png'},{'title':'-----------------','mode':'XXX'},{'title':'오늘의 추천 VOD','mode':'NOW_GROUP'},{'title':'인기영상 5','mode':'POP_GROUP'},{'title':'-----------------','mode':'XXX'},{'title':'VOD (리그, 경기별)','mode':'VOD_GROUP'},{'title':'Watched (시청목록)','mode':'WATCH','icon':'history.png'},]
LfgdBCoaAnstDOEShJeHlFkGmzrRcx={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
LfgdBCoaAnstDOEShJeHlFkGmzrRcX=xbmcvfs.translatePath(os.path.join(__profile__,'spotv_cookies.json'))
from spotvCore import*
class LfgdBCoaAnstDOEShJeHlFkGmzrRcI(LfgdBCoaAnstDOEShJeHlFkGmzrRXw):
 def __init__(LfgdBCoaAnstDOEShJeHlFkGmzrRcp,LfgdBCoaAnstDOEShJeHlFkGmzrRcP,LfgdBCoaAnstDOEShJeHlFkGmzrRcW,LfgdBCoaAnstDOEShJeHlFkGmzrRcT):
  LfgdBCoaAnstDOEShJeHlFkGmzrRcp._addon_url =LfgdBCoaAnstDOEShJeHlFkGmzrRcP
  LfgdBCoaAnstDOEShJeHlFkGmzrRcp._addon_handle=LfgdBCoaAnstDOEShJeHlFkGmzrRcW
  LfgdBCoaAnstDOEShJeHlFkGmzrRcp.main_params =LfgdBCoaAnstDOEShJeHlFkGmzrRcT
  LfgdBCoaAnstDOEShJeHlFkGmzrRcp.SpotvObj =GvXYIpwoWuREKsTOSrNayxLCJiBVnf() 
 def addon_noti(LfgdBCoaAnstDOEShJeHlFkGmzrRcp,sting):
  try:
   LfgdBCoaAnstDOEShJeHlFkGmzrRcq=xbmcgui.Dialog()
   LfgdBCoaAnstDOEShJeHlFkGmzrRcq.notification(__addonname__,sting)
  except:
   LfgdBCoaAnstDOEShJeHlFkGmzrRXV
 def addon_log(LfgdBCoaAnstDOEShJeHlFkGmzrRcp,string):
  try:
   LfgdBCoaAnstDOEShJeHlFkGmzrRcy=string.encode('utf-8','ignore')
  except:
   LfgdBCoaAnstDOEShJeHlFkGmzrRcy='addonException: addon_log'
  LfgdBCoaAnstDOEShJeHlFkGmzrRci=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,LfgdBCoaAnstDOEShJeHlFkGmzrRcy),level=LfgdBCoaAnstDOEShJeHlFkGmzrRci)
 def get_keyboard_input(LfgdBCoaAnstDOEShJeHlFkGmzrRcp,LfgdBCoaAnstDOEShJeHlFkGmzrRcM):
  LfgdBCoaAnstDOEShJeHlFkGmzrRcQ=LfgdBCoaAnstDOEShJeHlFkGmzrRXV
  kb=xbmc.Keyboard()
  kb.setHeading(LfgdBCoaAnstDOEShJeHlFkGmzrRcM)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   LfgdBCoaAnstDOEShJeHlFkGmzrRcQ=kb.getText()
  return LfgdBCoaAnstDOEShJeHlFkGmzrRcQ
 def get_settings_account(LfgdBCoaAnstDOEShJeHlFkGmzrRcp):
  LfgdBCoaAnstDOEShJeHlFkGmzrRcN =__addon__.getSetting('id')
  LfgdBCoaAnstDOEShJeHlFkGmzrRcj =__addon__.getSetting('pw')
  return(LfgdBCoaAnstDOEShJeHlFkGmzrRcN,LfgdBCoaAnstDOEShJeHlFkGmzrRcj)
 def get_settings_hidescoreyn(LfgdBCoaAnstDOEShJeHlFkGmzrRcp):
  LfgdBCoaAnstDOEShJeHlFkGmzrRcu =__addon__.getSetting('hidescore')
  if LfgdBCoaAnstDOEShJeHlFkGmzrRcu=='false':
   return LfgdBCoaAnstDOEShJeHlFkGmzrRXY
  else:
   return LfgdBCoaAnstDOEShJeHlFkGmzrRpc
 def add_dir(LfgdBCoaAnstDOEShJeHlFkGmzrRcp,label,sublabel='',img='',infoLabels=LfgdBCoaAnstDOEShJeHlFkGmzrRXV,isFolder=LfgdBCoaAnstDOEShJeHlFkGmzrRpc,params='',isLink=LfgdBCoaAnstDOEShJeHlFkGmzrRXY,ContextMenu=LfgdBCoaAnstDOEShJeHlFkGmzrRXV):
  LfgdBCoaAnstDOEShJeHlFkGmzrRcU='%s?%s'%(LfgdBCoaAnstDOEShJeHlFkGmzrRcp._addon_url,urllib.parse.urlencode(params))
  if sublabel:LfgdBCoaAnstDOEShJeHlFkGmzrRcM='%s < %s >'%(label,sublabel)
  else: LfgdBCoaAnstDOEShJeHlFkGmzrRcM=label
  if not img:img='DefaultFolder.png'
  LfgdBCoaAnstDOEShJeHlFkGmzrRcK=xbmcgui.ListItem(LfgdBCoaAnstDOEShJeHlFkGmzrRcM)
  LfgdBCoaAnstDOEShJeHlFkGmzrRcK.setArt({'thumb':img,'icon':img,'poster':img})
  if LfgdBCoaAnstDOEShJeHlFkGmzrRcp.SpotvObj.KodiVersion>=20:
   if infoLabels:LfgdBCoaAnstDOEShJeHlFkGmzrRcp.Set_InfoTag(LfgdBCoaAnstDOEShJeHlFkGmzrRcK.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:LfgdBCoaAnstDOEShJeHlFkGmzrRcK.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   LfgdBCoaAnstDOEShJeHlFkGmzrRcK.setProperty('IsPlayable','true')
  if ContextMenu:LfgdBCoaAnstDOEShJeHlFkGmzrRcK.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(LfgdBCoaAnstDOEShJeHlFkGmzrRcp._addon_handle,LfgdBCoaAnstDOEShJeHlFkGmzrRcU,LfgdBCoaAnstDOEShJeHlFkGmzrRcK,isFolder)
 def Set_InfoTag(LfgdBCoaAnstDOEShJeHlFkGmzrRcp,video_InfoTag:xbmc.InfoTagVideo,LfgdBCoaAnstDOEShJeHlFkGmzrRIT):
  for LfgdBCoaAnstDOEShJeHlFkGmzrRcw,value in LfgdBCoaAnstDOEShJeHlFkGmzrRIT.items():
   if LfgdBCoaAnstDOEShJeHlFkGmzrRcx[LfgdBCoaAnstDOEShJeHlFkGmzrRcw]['type']=='string':
    LfgdBCoaAnstDOEShJeHlFkGmzrRpI(video_InfoTag,LfgdBCoaAnstDOEShJeHlFkGmzrRcx[LfgdBCoaAnstDOEShJeHlFkGmzrRcw]['func'])(value)
   elif LfgdBCoaAnstDOEShJeHlFkGmzrRcx[LfgdBCoaAnstDOEShJeHlFkGmzrRcw]['type']=='int':
    if LfgdBCoaAnstDOEShJeHlFkGmzrRpv(value)==LfgdBCoaAnstDOEShJeHlFkGmzrRpx:
     LfgdBCoaAnstDOEShJeHlFkGmzrRcV=LfgdBCoaAnstDOEShJeHlFkGmzrRpx(value)
    else:
     LfgdBCoaAnstDOEShJeHlFkGmzrRcV=0
    LfgdBCoaAnstDOEShJeHlFkGmzrRpI(video_InfoTag,LfgdBCoaAnstDOEShJeHlFkGmzrRcx[LfgdBCoaAnstDOEShJeHlFkGmzrRcw]['func'])(LfgdBCoaAnstDOEShJeHlFkGmzrRcV)
   elif LfgdBCoaAnstDOEShJeHlFkGmzrRcx[LfgdBCoaAnstDOEShJeHlFkGmzrRcw]['type']=='actor':
    if value!=[]:
     LfgdBCoaAnstDOEShJeHlFkGmzrRpI(video_InfoTag,LfgdBCoaAnstDOEShJeHlFkGmzrRcx[LfgdBCoaAnstDOEShJeHlFkGmzrRcw]['func'])([xbmc.Actor(name)for name in value])
   elif LfgdBCoaAnstDOEShJeHlFkGmzrRcx[LfgdBCoaAnstDOEShJeHlFkGmzrRcw]['type']=='list':
    if LfgdBCoaAnstDOEShJeHlFkGmzrRpv(value)==LfgdBCoaAnstDOEShJeHlFkGmzrRpX:
     LfgdBCoaAnstDOEShJeHlFkGmzrRpI(video_InfoTag,LfgdBCoaAnstDOEShJeHlFkGmzrRcx[LfgdBCoaAnstDOEShJeHlFkGmzrRcw]['func'])(value)
    else:
     LfgdBCoaAnstDOEShJeHlFkGmzrRpI(video_InfoTag,LfgdBCoaAnstDOEShJeHlFkGmzrRcx[LfgdBCoaAnstDOEShJeHlFkGmzrRcw]['func'])([value])
 def get_selQuality(LfgdBCoaAnstDOEShJeHlFkGmzrRcp,etype):
  try:
   LfgdBCoaAnstDOEShJeHlFkGmzrRcY='selected_quality'
   LfgdBCoaAnstDOEShJeHlFkGmzrRIc=[1080,720,540]
   LfgdBCoaAnstDOEShJeHlFkGmzrRIv=LfgdBCoaAnstDOEShJeHlFkGmzrRpx(__addon__.getSetting(LfgdBCoaAnstDOEShJeHlFkGmzrRcY))
   return LfgdBCoaAnstDOEShJeHlFkGmzrRIc[LfgdBCoaAnstDOEShJeHlFkGmzrRIv]
  except:
   LfgdBCoaAnstDOEShJeHlFkGmzrRXV
  return 1080 
 def dp_Main_List(LfgdBCoaAnstDOEShJeHlFkGmzrRcp):
  for LfgdBCoaAnstDOEShJeHlFkGmzrRIx in LfgdBCoaAnstDOEShJeHlFkGmzrRcv:
   LfgdBCoaAnstDOEShJeHlFkGmzrRcM=LfgdBCoaAnstDOEShJeHlFkGmzrRIx.get('title')
   LfgdBCoaAnstDOEShJeHlFkGmzrRIX=''
   LfgdBCoaAnstDOEShJeHlFkGmzrRIp={'mode':LfgdBCoaAnstDOEShJeHlFkGmzrRIx.get('mode'),'page':'1'}
   if LfgdBCoaAnstDOEShJeHlFkGmzrRIx.get('mode')=='XXX':
    LfgdBCoaAnstDOEShJeHlFkGmzrRIP=LfgdBCoaAnstDOEShJeHlFkGmzrRXY
    LfgdBCoaAnstDOEShJeHlFkGmzrRIW =LfgdBCoaAnstDOEShJeHlFkGmzrRpc
   else:
    LfgdBCoaAnstDOEShJeHlFkGmzrRIP=LfgdBCoaAnstDOEShJeHlFkGmzrRpc
    LfgdBCoaAnstDOEShJeHlFkGmzrRIW =LfgdBCoaAnstDOEShJeHlFkGmzrRXY
   LfgdBCoaAnstDOEShJeHlFkGmzrRIT={'title':LfgdBCoaAnstDOEShJeHlFkGmzrRcM,'plot':LfgdBCoaAnstDOEShJeHlFkGmzrRcM}
   if LfgdBCoaAnstDOEShJeHlFkGmzrRIx.get('mode')=='XXX':LfgdBCoaAnstDOEShJeHlFkGmzrRIT=LfgdBCoaAnstDOEShJeHlFkGmzrRXV
   if 'icon' in LfgdBCoaAnstDOEShJeHlFkGmzrRIx:LfgdBCoaAnstDOEShJeHlFkGmzrRIX=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',LfgdBCoaAnstDOEShJeHlFkGmzrRIx.get('icon')) 
   LfgdBCoaAnstDOEShJeHlFkGmzrRcp.add_dir(LfgdBCoaAnstDOEShJeHlFkGmzrRcM,sublabel='',img=LfgdBCoaAnstDOEShJeHlFkGmzrRIX,infoLabels=LfgdBCoaAnstDOEShJeHlFkGmzrRIT,isFolder=LfgdBCoaAnstDOEShJeHlFkGmzrRIP,params=LfgdBCoaAnstDOEShJeHlFkGmzrRIp,isLink=LfgdBCoaAnstDOEShJeHlFkGmzrRIW)
  if LfgdBCoaAnstDOEShJeHlFkGmzrRpP(LfgdBCoaAnstDOEShJeHlFkGmzrRcv)>0:xbmcplugin.endOfDirectory(LfgdBCoaAnstDOEShJeHlFkGmzrRcp._addon_handle,cacheToDisc=LfgdBCoaAnstDOEShJeHlFkGmzrRXY)
 def dp_MainLeague_List(LfgdBCoaAnstDOEShJeHlFkGmzrRcp,args):
  LfgdBCoaAnstDOEShJeHlFkGmzrRcp.addon_log('dp_MainLeague_List')
  LfgdBCoaAnstDOEShJeHlFkGmzrRIq=LfgdBCoaAnstDOEShJeHlFkGmzrRcp.SpotvObj.GetTitleGroupList()
  LfgdBCoaAnstDOEShJeHlFkGmzrRcp.addon_log('dp_MainLeague_List cnt : '+LfgdBCoaAnstDOEShJeHlFkGmzrRpW(LfgdBCoaAnstDOEShJeHlFkGmzrRpP(LfgdBCoaAnstDOEShJeHlFkGmzrRIq)))
  for LfgdBCoaAnstDOEShJeHlFkGmzrRIy in LfgdBCoaAnstDOEShJeHlFkGmzrRIq:
   LfgdBCoaAnstDOEShJeHlFkGmzrRcM =LfgdBCoaAnstDOEShJeHlFkGmzrRIy.get('title')
   LfgdBCoaAnstDOEShJeHlFkGmzrRIi =LfgdBCoaAnstDOEShJeHlFkGmzrRIy.get('logo')
   LfgdBCoaAnstDOEShJeHlFkGmzrRIQ =LfgdBCoaAnstDOEShJeHlFkGmzrRIy.get('reagueId')
   LfgdBCoaAnstDOEShJeHlFkGmzrRIN =LfgdBCoaAnstDOEShJeHlFkGmzrRIy.get('subGame')
   LfgdBCoaAnstDOEShJeHlFkGmzrRIj={'mediatype':'episode','plot':'%s\n\n%s'%(LfgdBCoaAnstDOEShJeHlFkGmzrRcM,LfgdBCoaAnstDOEShJeHlFkGmzrRIN)}
   LfgdBCoaAnstDOEShJeHlFkGmzrRIp={'mode':'LEAGUE_GROUP','reagueId':LfgdBCoaAnstDOEShJeHlFkGmzrRIQ}
   LfgdBCoaAnstDOEShJeHlFkGmzrRcp.add_dir(LfgdBCoaAnstDOEShJeHlFkGmzrRcM,sublabel=LfgdBCoaAnstDOEShJeHlFkGmzrRXV,img=LfgdBCoaAnstDOEShJeHlFkGmzrRIi,infoLabels=LfgdBCoaAnstDOEShJeHlFkGmzrRIj,isFolder=LfgdBCoaAnstDOEShJeHlFkGmzrRpc,params=LfgdBCoaAnstDOEShJeHlFkGmzrRIp)
  if LfgdBCoaAnstDOEShJeHlFkGmzrRpP(LfgdBCoaAnstDOEShJeHlFkGmzrRIq)>0:xbmcplugin.endOfDirectory(LfgdBCoaAnstDOEShJeHlFkGmzrRcp._addon_handle,cacheToDisc=LfgdBCoaAnstDOEShJeHlFkGmzrRXY)
 def dp_NowVod_GroupList(LfgdBCoaAnstDOEShJeHlFkGmzrRcp,args):
  LfgdBCoaAnstDOEShJeHlFkGmzrRIu=LfgdBCoaAnstDOEShJeHlFkGmzrRpx(args.get('page'))
  LfgdBCoaAnstDOEShJeHlFkGmzrRcp.addon_log('dp_NowVod_GroupList page : '+LfgdBCoaAnstDOEShJeHlFkGmzrRpW(LfgdBCoaAnstDOEShJeHlFkGmzrRIu))
  LfgdBCoaAnstDOEShJeHlFkGmzrRIq,LfgdBCoaAnstDOEShJeHlFkGmzrRIU=LfgdBCoaAnstDOEShJeHlFkGmzrRcp.SpotvObj.Get_NowVod_GroupList(LfgdBCoaAnstDOEShJeHlFkGmzrRIu)
  LfgdBCoaAnstDOEShJeHlFkGmzrRcp.addon_log('dp_NowVod_GroupList cnt : '+LfgdBCoaAnstDOEShJeHlFkGmzrRpW(LfgdBCoaAnstDOEShJeHlFkGmzrRpP(LfgdBCoaAnstDOEShJeHlFkGmzrRIq)))
  for LfgdBCoaAnstDOEShJeHlFkGmzrRIy in LfgdBCoaAnstDOEShJeHlFkGmzrRIq:
   LfgdBCoaAnstDOEShJeHlFkGmzrRIM =LfgdBCoaAnstDOEShJeHlFkGmzrRIy.get('vodTitle')
   LfgdBCoaAnstDOEShJeHlFkGmzrRIK =LfgdBCoaAnstDOEShJeHlFkGmzrRIy.get('vodId')
   LfgdBCoaAnstDOEShJeHlFkGmzrRIw =LfgdBCoaAnstDOEShJeHlFkGmzrRIy.get('vodType')
   LfgdBCoaAnstDOEShJeHlFkGmzrRIi=LfgdBCoaAnstDOEShJeHlFkGmzrRIy.get('thumbnail')
   LfgdBCoaAnstDOEShJeHlFkGmzrRIV =LfgdBCoaAnstDOEShJeHlFkGmzrRIy.get('vtypeId')
   LfgdBCoaAnstDOEShJeHlFkGmzrRIY =LfgdBCoaAnstDOEShJeHlFkGmzrRIy.get('duration')
   LfgdBCoaAnstDOEShJeHlFkGmzrRIj={'mediatype':'episode','duration':LfgdBCoaAnstDOEShJeHlFkGmzrRIY,'plot':LfgdBCoaAnstDOEShJeHlFkGmzrRIM}
   LfgdBCoaAnstDOEShJeHlFkGmzrRIp={'mode':'NOW_VOD','mediacode':LfgdBCoaAnstDOEShJeHlFkGmzrRIK,'mediatype':'vod','vtypeId':LfgdBCoaAnstDOEShJeHlFkGmzrRIV}
   LfgdBCoaAnstDOEShJeHlFkGmzrRcp.add_dir(LfgdBCoaAnstDOEShJeHlFkGmzrRIM,sublabel=LfgdBCoaAnstDOEShJeHlFkGmzrRIw,img=LfgdBCoaAnstDOEShJeHlFkGmzrRIi,infoLabels=LfgdBCoaAnstDOEShJeHlFkGmzrRIj,isFolder=LfgdBCoaAnstDOEShJeHlFkGmzrRXY,params=LfgdBCoaAnstDOEShJeHlFkGmzrRIp)
  if LfgdBCoaAnstDOEShJeHlFkGmzrRIU:
   LfgdBCoaAnstDOEShJeHlFkGmzrRIp['mode'] ='NOW_GROUP' 
   LfgdBCoaAnstDOEShJeHlFkGmzrRIp['page'] =LfgdBCoaAnstDOEShJeHlFkGmzrRpW(LfgdBCoaAnstDOEShJeHlFkGmzrRIu+1)
   LfgdBCoaAnstDOEShJeHlFkGmzrRcM='[B]%s >>[/B]'%'다음 페이지'
   LfgdBCoaAnstDOEShJeHlFkGmzrRvc=LfgdBCoaAnstDOEShJeHlFkGmzrRpW(LfgdBCoaAnstDOEShJeHlFkGmzrRIu+1)
   LfgdBCoaAnstDOEShJeHlFkGmzrRIX=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   LfgdBCoaAnstDOEShJeHlFkGmzrRcp.add_dir(LfgdBCoaAnstDOEShJeHlFkGmzrRcM,sublabel=LfgdBCoaAnstDOEShJeHlFkGmzrRvc,img=LfgdBCoaAnstDOEShJeHlFkGmzrRIX,infoLabels=LfgdBCoaAnstDOEShJeHlFkGmzrRXV,isFolder=LfgdBCoaAnstDOEShJeHlFkGmzrRpc,params=LfgdBCoaAnstDOEShJeHlFkGmzrRIp)
  xbmcplugin.setContent(LfgdBCoaAnstDOEShJeHlFkGmzrRcp._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(LfgdBCoaAnstDOEShJeHlFkGmzrRcp._addon_handle,cacheToDisc=LfgdBCoaAnstDOEShJeHlFkGmzrRXY)
 def dp_PopVod_GroupList(LfgdBCoaAnstDOEShJeHlFkGmzrRcp,args):
  LfgdBCoaAnstDOEShJeHlFkGmzrRcp.addon_log('dp_PopVod_GroupList ')
  LfgdBCoaAnstDOEShJeHlFkGmzrRIq=LfgdBCoaAnstDOEShJeHlFkGmzrRcp.SpotvObj.GetPopularGroupList()
  LfgdBCoaAnstDOEShJeHlFkGmzrRcp.addon_log('dp_PopVod_GroupList cnt : '+LfgdBCoaAnstDOEShJeHlFkGmzrRpW(LfgdBCoaAnstDOEShJeHlFkGmzrRpP(LfgdBCoaAnstDOEShJeHlFkGmzrRIq)))
  for LfgdBCoaAnstDOEShJeHlFkGmzrRIy in LfgdBCoaAnstDOEShJeHlFkGmzrRIq:
   LfgdBCoaAnstDOEShJeHlFkGmzrRIM =LfgdBCoaAnstDOEShJeHlFkGmzrRIy.get('vodTitle')
   LfgdBCoaAnstDOEShJeHlFkGmzrRIK =LfgdBCoaAnstDOEShJeHlFkGmzrRIy.get('vodId')
   LfgdBCoaAnstDOEShJeHlFkGmzrRIw =LfgdBCoaAnstDOEShJeHlFkGmzrRIy.get('vodType')
   LfgdBCoaAnstDOEShJeHlFkGmzrRIi=LfgdBCoaAnstDOEShJeHlFkGmzrRIy.get('thumbnail')
   LfgdBCoaAnstDOEShJeHlFkGmzrRIV =LfgdBCoaAnstDOEShJeHlFkGmzrRIy.get('vtypeId')
   LfgdBCoaAnstDOEShJeHlFkGmzrRIY =LfgdBCoaAnstDOEShJeHlFkGmzrRIy.get('duration')
   LfgdBCoaAnstDOEShJeHlFkGmzrRIj={'mediatype':'episode','duration':LfgdBCoaAnstDOEShJeHlFkGmzrRIY,'plot':LfgdBCoaAnstDOEShJeHlFkGmzrRIM}
   LfgdBCoaAnstDOEShJeHlFkGmzrRIp={'mode':'POP_VOD','mediacode':LfgdBCoaAnstDOEShJeHlFkGmzrRIK,'mediatype':'vod','vtypeId':LfgdBCoaAnstDOEShJeHlFkGmzrRIV}
   LfgdBCoaAnstDOEShJeHlFkGmzrRcp.add_dir(LfgdBCoaAnstDOEShJeHlFkGmzrRIM,sublabel=LfgdBCoaAnstDOEShJeHlFkGmzrRIw,img=LfgdBCoaAnstDOEShJeHlFkGmzrRIi,infoLabels=LfgdBCoaAnstDOEShJeHlFkGmzrRIj,isFolder=LfgdBCoaAnstDOEShJeHlFkGmzrRXY,params=LfgdBCoaAnstDOEShJeHlFkGmzrRIp)
  xbmcplugin.setContent(LfgdBCoaAnstDOEShJeHlFkGmzrRcp._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(LfgdBCoaAnstDOEShJeHlFkGmzrRcp._addon_handle,cacheToDisc=LfgdBCoaAnstDOEShJeHlFkGmzrRXY)
 def dp_Season_List(LfgdBCoaAnstDOEShJeHlFkGmzrRcp,args):
  LfgdBCoaAnstDOEShJeHlFkGmzrRIQ=args.get('reagueId')
  LfgdBCoaAnstDOEShJeHlFkGmzrRcp.addon_log('Season_List - reagueId : '+LfgdBCoaAnstDOEShJeHlFkGmzrRIQ)
  LfgdBCoaAnstDOEShJeHlFkGmzrRIq=LfgdBCoaAnstDOEShJeHlFkGmzrRcp.SpotvObj.GetSeasonList(LfgdBCoaAnstDOEShJeHlFkGmzrRIQ)
  for LfgdBCoaAnstDOEShJeHlFkGmzrRIy in LfgdBCoaAnstDOEShJeHlFkGmzrRIq:
   LfgdBCoaAnstDOEShJeHlFkGmzrRvx =LfgdBCoaAnstDOEShJeHlFkGmzrRIy.get('reagueName')
   LfgdBCoaAnstDOEShJeHlFkGmzrRvX =LfgdBCoaAnstDOEShJeHlFkGmzrRIy.get('gameTypeId')
   LfgdBCoaAnstDOEShJeHlFkGmzrRvp =LfgdBCoaAnstDOEShJeHlFkGmzrRIy.get('seasonName')
   LfgdBCoaAnstDOEShJeHlFkGmzrRvP =LfgdBCoaAnstDOEShJeHlFkGmzrRIy.get('seasonId')
   LfgdBCoaAnstDOEShJeHlFkGmzrRIj={'mediatype':'episode','plot':'%s - %s'%(LfgdBCoaAnstDOEShJeHlFkGmzrRvx,LfgdBCoaAnstDOEShJeHlFkGmzrRvp)}
   LfgdBCoaAnstDOEShJeHlFkGmzrRIp={'mode':'SEASON_GROUP','reagueId':LfgdBCoaAnstDOEShJeHlFkGmzrRIQ,'seasonId':LfgdBCoaAnstDOEShJeHlFkGmzrRvP,'gameTypeId':LfgdBCoaAnstDOEShJeHlFkGmzrRvX,'page':'1'}
   LfgdBCoaAnstDOEShJeHlFkGmzrRcp.add_dir(LfgdBCoaAnstDOEShJeHlFkGmzrRvx,sublabel=LfgdBCoaAnstDOEShJeHlFkGmzrRvp,img='',infoLabels=LfgdBCoaAnstDOEShJeHlFkGmzrRIj,isFolder=LfgdBCoaAnstDOEShJeHlFkGmzrRpc,params=LfgdBCoaAnstDOEShJeHlFkGmzrRIp)
  if LfgdBCoaAnstDOEShJeHlFkGmzrRpP(LfgdBCoaAnstDOEShJeHlFkGmzrRIq)>0:xbmcplugin.endOfDirectory(LfgdBCoaAnstDOEShJeHlFkGmzrRcp._addon_handle,cacheToDisc=LfgdBCoaAnstDOEShJeHlFkGmzrRXY)
 def dp_Game_List(LfgdBCoaAnstDOEShJeHlFkGmzrRcp,args):
  LfgdBCoaAnstDOEShJeHlFkGmzrRvX=args.get('gameTypeId')
  LfgdBCoaAnstDOEShJeHlFkGmzrRIQ =args.get('reagueId')
  LfgdBCoaAnstDOEShJeHlFkGmzrRvP =args.get('seasonId')
  LfgdBCoaAnstDOEShJeHlFkGmzrRIu =LfgdBCoaAnstDOEShJeHlFkGmzrRpx(args.get('page'))
  LfgdBCoaAnstDOEShJeHlFkGmzrRcp.addon_log('Game_List - gameTypeId : '+LfgdBCoaAnstDOEShJeHlFkGmzrRvX)
  LfgdBCoaAnstDOEShJeHlFkGmzrRcp.addon_log('Game_List - reagueId   : '+LfgdBCoaAnstDOEShJeHlFkGmzrRIQ)
  LfgdBCoaAnstDOEShJeHlFkGmzrRcp.addon_log('Game_List - seasonId   : '+LfgdBCoaAnstDOEShJeHlFkGmzrRvP)
  LfgdBCoaAnstDOEShJeHlFkGmzrRIq,LfgdBCoaAnstDOEShJeHlFkGmzrRIU=LfgdBCoaAnstDOEShJeHlFkGmzrRcp.SpotvObj.GetGameList(LfgdBCoaAnstDOEShJeHlFkGmzrRvX,LfgdBCoaAnstDOEShJeHlFkGmzrRIQ,LfgdBCoaAnstDOEShJeHlFkGmzrRvP,LfgdBCoaAnstDOEShJeHlFkGmzrRIu,hidescore=LfgdBCoaAnstDOEShJeHlFkGmzrRcp.get_settings_hidescoreyn())
  for LfgdBCoaAnstDOEShJeHlFkGmzrRIy in LfgdBCoaAnstDOEShJeHlFkGmzrRIq:
   LfgdBCoaAnstDOEShJeHlFkGmzrRvW =LfgdBCoaAnstDOEShJeHlFkGmzrRIy.get('gameTitle')
   LfgdBCoaAnstDOEShJeHlFkGmzrRvT =LfgdBCoaAnstDOEShJeHlFkGmzrRIy.get('beginDate')
   LfgdBCoaAnstDOEShJeHlFkGmzrRIi =LfgdBCoaAnstDOEShJeHlFkGmzrRIy.get('thumbnail')
   LfgdBCoaAnstDOEShJeHlFkGmzrRvb =LfgdBCoaAnstDOEShJeHlFkGmzrRIy.get('gameId')
   LfgdBCoaAnstDOEShJeHlFkGmzrRvq =LfgdBCoaAnstDOEShJeHlFkGmzrRIy.get('totVodCnt')
   LfgdBCoaAnstDOEShJeHlFkGmzrRvy =LfgdBCoaAnstDOEShJeHlFkGmzrRIy.get('leaguenm')
   LfgdBCoaAnstDOEShJeHlFkGmzrRvi =LfgdBCoaAnstDOEShJeHlFkGmzrRIy.get('seasonnm')
   LfgdBCoaAnstDOEShJeHlFkGmzrRvQ =LfgdBCoaAnstDOEShJeHlFkGmzrRIy.get('roundnm')
   LfgdBCoaAnstDOEShJeHlFkGmzrRvN =LfgdBCoaAnstDOEShJeHlFkGmzrRIy.get('info_plot')
   LfgdBCoaAnstDOEShJeHlFkGmzrRvj ='%s < %s >'%(LfgdBCoaAnstDOEShJeHlFkGmzrRvW,LfgdBCoaAnstDOEShJeHlFkGmzrRvT)
   LfgdBCoaAnstDOEShJeHlFkGmzrRIj={'mediatype':'video','plot':LfgdBCoaAnstDOEShJeHlFkGmzrRvN}
   LfgdBCoaAnstDOEShJeHlFkGmzrRIp={'mode':'GAME_VOD_GROUP' if LfgdBCoaAnstDOEShJeHlFkGmzrRvq!=0 else 'XXX','saveTitle':LfgdBCoaAnstDOEShJeHlFkGmzrRvj,'saveImg':LfgdBCoaAnstDOEShJeHlFkGmzrRIi,'saveInfo':LfgdBCoaAnstDOEShJeHlFkGmzrRIj['plot'],'gameid':LfgdBCoaAnstDOEShJeHlFkGmzrRvb,'totVodCnt':LfgdBCoaAnstDOEShJeHlFkGmzrRvq,}
   LfgdBCoaAnstDOEShJeHlFkGmzrRcp.add_dir(LfgdBCoaAnstDOEShJeHlFkGmzrRvW,sublabel=LfgdBCoaAnstDOEShJeHlFkGmzrRvT,img=LfgdBCoaAnstDOEShJeHlFkGmzrRIi,infoLabels=LfgdBCoaAnstDOEShJeHlFkGmzrRIj,isFolder=LfgdBCoaAnstDOEShJeHlFkGmzrRpc,params=LfgdBCoaAnstDOEShJeHlFkGmzrRIp)
  if LfgdBCoaAnstDOEShJeHlFkGmzrRIU:
   LfgdBCoaAnstDOEShJeHlFkGmzrRIp['mode'] ='SEASON_GROUP' 
   LfgdBCoaAnstDOEShJeHlFkGmzrRIp['reagueId'] =LfgdBCoaAnstDOEShJeHlFkGmzrRIQ
   LfgdBCoaAnstDOEShJeHlFkGmzrRIp['seasonId'] =LfgdBCoaAnstDOEShJeHlFkGmzrRvP
   LfgdBCoaAnstDOEShJeHlFkGmzrRIp['gameTypeId']=LfgdBCoaAnstDOEShJeHlFkGmzrRvX
   LfgdBCoaAnstDOEShJeHlFkGmzrRIp['page'] =LfgdBCoaAnstDOEShJeHlFkGmzrRpW(LfgdBCoaAnstDOEShJeHlFkGmzrRIu+1)
   LfgdBCoaAnstDOEShJeHlFkGmzrRcM='[B]%s >>[/B]'%'다음 페이지'
   LfgdBCoaAnstDOEShJeHlFkGmzrRvc=LfgdBCoaAnstDOEShJeHlFkGmzrRpW(LfgdBCoaAnstDOEShJeHlFkGmzrRIu+1)
   LfgdBCoaAnstDOEShJeHlFkGmzrRIX=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   LfgdBCoaAnstDOEShJeHlFkGmzrRcp.add_dir(LfgdBCoaAnstDOEShJeHlFkGmzrRcM,sublabel=LfgdBCoaAnstDOEShJeHlFkGmzrRvc,img=LfgdBCoaAnstDOEShJeHlFkGmzrRIX,infoLabels=LfgdBCoaAnstDOEShJeHlFkGmzrRXV,isFolder=LfgdBCoaAnstDOEShJeHlFkGmzrRpc,params=LfgdBCoaAnstDOEShJeHlFkGmzrRIp)
  if LfgdBCoaAnstDOEShJeHlFkGmzrRpP(LfgdBCoaAnstDOEShJeHlFkGmzrRIq)>0:xbmcplugin.endOfDirectory(LfgdBCoaAnstDOEShJeHlFkGmzrRcp._addon_handle,cacheToDisc=LfgdBCoaAnstDOEShJeHlFkGmzrRXY)
 def dp_GameVod_List(LfgdBCoaAnstDOEShJeHlFkGmzrRcp,args):
  LfgdBCoaAnstDOEShJeHlFkGmzrRvu =args.get('gameid')
  LfgdBCoaAnstDOEShJeHlFkGmzrRvj=args.get('saveTitle')
  LfgdBCoaAnstDOEShJeHlFkGmzrRvU =args.get('saveImg')
  LfgdBCoaAnstDOEShJeHlFkGmzrRvM =args.get('saveInfo')
  LfgdBCoaAnstDOEShJeHlFkGmzrRIq=LfgdBCoaAnstDOEShJeHlFkGmzrRcp.SpotvObj.GetGameVodList(LfgdBCoaAnstDOEShJeHlFkGmzrRvu)
  for LfgdBCoaAnstDOEShJeHlFkGmzrRIy in LfgdBCoaAnstDOEShJeHlFkGmzrRIq:
   LfgdBCoaAnstDOEShJeHlFkGmzrRIM =LfgdBCoaAnstDOEShJeHlFkGmzrRIy.get('vodTitle')
   LfgdBCoaAnstDOEShJeHlFkGmzrRIK =LfgdBCoaAnstDOEShJeHlFkGmzrRIy.get('vodId')
   LfgdBCoaAnstDOEShJeHlFkGmzrRIw =LfgdBCoaAnstDOEShJeHlFkGmzrRIy.get('vodType')
   LfgdBCoaAnstDOEShJeHlFkGmzrRIi=LfgdBCoaAnstDOEShJeHlFkGmzrRIy.get('thumbnail')
   LfgdBCoaAnstDOEShJeHlFkGmzrRIV =LfgdBCoaAnstDOEShJeHlFkGmzrRIy.get('vtypeId')
   LfgdBCoaAnstDOEShJeHlFkGmzrRIY =LfgdBCoaAnstDOEShJeHlFkGmzrRIy.get('duration')
   LfgdBCoaAnstDOEShJeHlFkGmzrRIj={'mediatype':'episode','duration':LfgdBCoaAnstDOEShJeHlFkGmzrRIY,'plot':'%s \n\n %s'%(LfgdBCoaAnstDOEShJeHlFkGmzrRIM,LfgdBCoaAnstDOEShJeHlFkGmzrRvM)}
   LfgdBCoaAnstDOEShJeHlFkGmzrRIp={'mode':'GAME_VOD','saveTitle':LfgdBCoaAnstDOEShJeHlFkGmzrRvj,'saveImg':LfgdBCoaAnstDOEShJeHlFkGmzrRvU,'saveId':LfgdBCoaAnstDOEShJeHlFkGmzrRvu,'saveInfo':LfgdBCoaAnstDOEShJeHlFkGmzrRvM,'mediacode':LfgdBCoaAnstDOEShJeHlFkGmzrRIK,'mediatype':'vod','vtypeId':LfgdBCoaAnstDOEShJeHlFkGmzrRIV}
   LfgdBCoaAnstDOEShJeHlFkGmzrRcp.add_dir(LfgdBCoaAnstDOEShJeHlFkGmzrRIM,sublabel=LfgdBCoaAnstDOEShJeHlFkGmzrRIw,img=LfgdBCoaAnstDOEShJeHlFkGmzrRIi,infoLabels=LfgdBCoaAnstDOEShJeHlFkGmzrRIj,isFolder=LfgdBCoaAnstDOEShJeHlFkGmzrRXY,params=LfgdBCoaAnstDOEShJeHlFkGmzrRIp)
  xbmcplugin.setContent(LfgdBCoaAnstDOEShJeHlFkGmzrRcp._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(LfgdBCoaAnstDOEShJeHlFkGmzrRcp._addon_handle,cacheToDisc=LfgdBCoaAnstDOEShJeHlFkGmzrRXY)
 def login_main(LfgdBCoaAnstDOEShJeHlFkGmzrRcp):
  (LfgdBCoaAnstDOEShJeHlFkGmzrRvK,LfgdBCoaAnstDOEShJeHlFkGmzrRvw)=LfgdBCoaAnstDOEShJeHlFkGmzrRcp.get_settings_account()
  if not(LfgdBCoaAnstDOEShJeHlFkGmzrRvK and LfgdBCoaAnstDOEShJeHlFkGmzrRvw):
   LfgdBCoaAnstDOEShJeHlFkGmzrRcq=xbmcgui.Dialog()
   LfgdBCoaAnstDOEShJeHlFkGmzrRvV=LfgdBCoaAnstDOEShJeHlFkGmzrRcq.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if LfgdBCoaAnstDOEShJeHlFkGmzrRvV==LfgdBCoaAnstDOEShJeHlFkGmzrRpc:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if LfgdBCoaAnstDOEShJeHlFkGmzrRcp.cookiefile_check():return
  if xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINWAIT')=='TRUE':
   LfgdBCoaAnstDOEShJeHlFkGmzrRvY=0
   while LfgdBCoaAnstDOEShJeHlFkGmzrRpc:
    LfgdBCoaAnstDOEShJeHlFkGmzrRvY+=1
    time.sleep(0.05)
    if LfgdBCoaAnstDOEShJeHlFkGmzrRvY>600:return
  else:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','TRUE')
  LfgdBCoaAnstDOEShJeHlFkGmzrRxc=LfgdBCoaAnstDOEShJeHlFkGmzrRcp.SpotvObj.GetCredential_new(LfgdBCoaAnstDOEShJeHlFkGmzrRvK,LfgdBCoaAnstDOEShJeHlFkGmzrRvw)
  if LfgdBCoaAnstDOEShJeHlFkGmzrRxc:LfgdBCoaAnstDOEShJeHlFkGmzrRcp.cookiefile_save()
  xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
  if LfgdBCoaAnstDOEShJeHlFkGmzrRxc==LfgdBCoaAnstDOEShJeHlFkGmzrRXY:
   LfgdBCoaAnstDOEShJeHlFkGmzrRcp.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_LiveChannel_List(LfgdBCoaAnstDOEShJeHlFkGmzrRcp,args):
  LfgdBCoaAnstDOEShJeHlFkGmzrRxI=LfgdBCoaAnstDOEShJeHlFkGmzrRcp.SpotvObj.GetLiveChannelList()
  for LfgdBCoaAnstDOEShJeHlFkGmzrRxv in LfgdBCoaAnstDOEShJeHlFkGmzrRxI:
   LfgdBCoaAnstDOEShJeHlFkGmzrRpT =LfgdBCoaAnstDOEShJeHlFkGmzrRxv.get('id')
   LfgdBCoaAnstDOEShJeHlFkGmzrRcM =LfgdBCoaAnstDOEShJeHlFkGmzrRxv.get('name')
   LfgdBCoaAnstDOEShJeHlFkGmzrRIb =LfgdBCoaAnstDOEShJeHlFkGmzrRxv.get('programName')
   LfgdBCoaAnstDOEShJeHlFkGmzrRIi =LfgdBCoaAnstDOEShJeHlFkGmzrRxv.get('logo')
   LfgdBCoaAnstDOEShJeHlFkGmzrRxX=LfgdBCoaAnstDOEShJeHlFkGmzrRxv.get('channelepg')
   LfgdBCoaAnstDOEShJeHlFkGmzrRxp =LfgdBCoaAnstDOEShJeHlFkGmzrRxv.get('free')
   LfgdBCoaAnstDOEShJeHlFkGmzrRIj={'plot':'%s\n\n%s'%(LfgdBCoaAnstDOEShJeHlFkGmzrRcM,LfgdBCoaAnstDOEShJeHlFkGmzrRxX),'mediatype':'episode',}
   LfgdBCoaAnstDOEShJeHlFkGmzrRIp={'mode':'LIVE','mediacode':LfgdBCoaAnstDOEShJeHlFkGmzrRpT,'free':LfgdBCoaAnstDOEShJeHlFkGmzrRxp,'mediatype':'live'}
   if LfgdBCoaAnstDOEShJeHlFkGmzrRxp:LfgdBCoaAnstDOEShJeHlFkGmzrRcM+=' [free]'
   LfgdBCoaAnstDOEShJeHlFkGmzrRcp.add_dir(LfgdBCoaAnstDOEShJeHlFkGmzrRcM,sublabel=LfgdBCoaAnstDOEShJeHlFkGmzrRIb,img=LfgdBCoaAnstDOEShJeHlFkGmzrRIi,infoLabels=LfgdBCoaAnstDOEShJeHlFkGmzrRIj,isFolder=LfgdBCoaAnstDOEShJeHlFkGmzrRXY,params=LfgdBCoaAnstDOEShJeHlFkGmzrRIp)
  xbmcplugin.setContent(LfgdBCoaAnstDOEShJeHlFkGmzrRcp._addon_handle,'episodes')
  if LfgdBCoaAnstDOEShJeHlFkGmzrRpP(LfgdBCoaAnstDOEShJeHlFkGmzrRxI)>0:xbmcplugin.endOfDirectory(LfgdBCoaAnstDOEShJeHlFkGmzrRcp._addon_handle,cacheToDisc=LfgdBCoaAnstDOEShJeHlFkGmzrRXY)
 def dp_EventLiveChannel_List(LfgdBCoaAnstDOEShJeHlFkGmzrRcp,args):
  LfgdBCoaAnstDOEShJeHlFkGmzrRxI,LfgdBCoaAnstDOEShJeHlFkGmzrRxP=LfgdBCoaAnstDOEShJeHlFkGmzrRcp.SpotvObj.GetEventLiveList()
  if LfgdBCoaAnstDOEShJeHlFkGmzrRxP!=401 and LfgdBCoaAnstDOEShJeHlFkGmzrRpP(LfgdBCoaAnstDOEShJeHlFkGmzrRxI)==0:
   LfgdBCoaAnstDOEShJeHlFkGmzrRcp.addon_noti(__language__(30907).encode('utf8'))
  for LfgdBCoaAnstDOEShJeHlFkGmzrRxv in LfgdBCoaAnstDOEShJeHlFkGmzrRxI:
   LfgdBCoaAnstDOEShJeHlFkGmzrRcM =LfgdBCoaAnstDOEShJeHlFkGmzrRxv.get('title')
   LfgdBCoaAnstDOEShJeHlFkGmzrRIb =LfgdBCoaAnstDOEShJeHlFkGmzrRxv.get('startTime')
   LfgdBCoaAnstDOEShJeHlFkGmzrRIi =LfgdBCoaAnstDOEShJeHlFkGmzrRxv.get('logo')
   LfgdBCoaAnstDOEShJeHlFkGmzrRxp =LfgdBCoaAnstDOEShJeHlFkGmzrRxv.get('free')
   LfgdBCoaAnstDOEShJeHlFkGmzrRIj={'mediatype':'episode','plot':'%s\n\n%s'%(LfgdBCoaAnstDOEShJeHlFkGmzrRcM,LfgdBCoaAnstDOEShJeHlFkGmzrRIb)}
   LfgdBCoaAnstDOEShJeHlFkGmzrRIp={'mode':'ELIVE','mediacode':LfgdBCoaAnstDOEShJeHlFkGmzrRxv.get('liveId'),'free':LfgdBCoaAnstDOEShJeHlFkGmzrRxp,'mediatype':'live'}
   if LfgdBCoaAnstDOEShJeHlFkGmzrRxp:LfgdBCoaAnstDOEShJeHlFkGmzrRcM+=' [free]'
   LfgdBCoaAnstDOEShJeHlFkGmzrRcp.add_dir(LfgdBCoaAnstDOEShJeHlFkGmzrRcM,sublabel=LfgdBCoaAnstDOEShJeHlFkGmzrRIb,img=LfgdBCoaAnstDOEShJeHlFkGmzrRIi,infoLabels=LfgdBCoaAnstDOEShJeHlFkGmzrRIj,isFolder=LfgdBCoaAnstDOEShJeHlFkGmzrRXY,params=LfgdBCoaAnstDOEShJeHlFkGmzrRIp)
  xbmcplugin.setContent(LfgdBCoaAnstDOEShJeHlFkGmzrRcp._addon_handle,'episodes')
  if LfgdBCoaAnstDOEShJeHlFkGmzrRpP(LfgdBCoaAnstDOEShJeHlFkGmzrRxI)>0:xbmcplugin.endOfDirectory(LfgdBCoaAnstDOEShJeHlFkGmzrRcp._addon_handle,cacheToDisc=LfgdBCoaAnstDOEShJeHlFkGmzrRXY)
  return LfgdBCoaAnstDOEShJeHlFkGmzrRxP
 def play_VIDEO(LfgdBCoaAnstDOEShJeHlFkGmzrRcp,args):
  LfgdBCoaAnstDOEShJeHlFkGmzrRxW =args.get('mode')
  LfgdBCoaAnstDOEShJeHlFkGmzrRxT =args.get('mediacode')
  LfgdBCoaAnstDOEShJeHlFkGmzrRxb =args.get('mediatype')
  LfgdBCoaAnstDOEShJeHlFkGmzrRIV =args.get('vtypeId')
  LfgdBCoaAnstDOEShJeHlFkGmzrRxq =args.get('hlsUrl')
  if LfgdBCoaAnstDOEShJeHlFkGmzrRxW=='LIVE':
   if args.get('free')=='False':
    if LfgdBCoaAnstDOEShJeHlFkGmzrRcp.SpotvObj.CheckSubEnd()==LfgdBCoaAnstDOEShJeHlFkGmzrRXY:
     LfgdBCoaAnstDOEShJeHlFkGmzrRcp.addon_noti(__language__(30908).encode('utf8'))
     return
  elif LfgdBCoaAnstDOEShJeHlFkGmzrRxW=='ELIVE':
   if args.get('free')=='False':
    if LfgdBCoaAnstDOEShJeHlFkGmzrRcp.SpotvObj.CheckSubEnd()==LfgdBCoaAnstDOEShJeHlFkGmzrRXY:
     LfgdBCoaAnstDOEShJeHlFkGmzrRcp.addon_noti(__language__(30908).encode('utf8'))
     return
  if LfgdBCoaAnstDOEShJeHlFkGmzrRxT=='' or LfgdBCoaAnstDOEShJeHlFkGmzrRxT==LfgdBCoaAnstDOEShJeHlFkGmzrRXV:
   LfgdBCoaAnstDOEShJeHlFkGmzrRcp.addon_noti(__language__(30907).encode('utf8'))
   return
  if LfgdBCoaAnstDOEShJeHlFkGmzrRxW=='LIVE':
   LfgdBCoaAnstDOEShJeHlFkGmzrRxy=LfgdBCoaAnstDOEShJeHlFkGmzrRcp.SpotvObj.GetHlsUrl(LfgdBCoaAnstDOEShJeHlFkGmzrRxT)
  else:
   LfgdBCoaAnstDOEShJeHlFkGmzrRcp.addon_log('mediacode : '+LfgdBCoaAnstDOEShJeHlFkGmzrRxT)
   LfgdBCoaAnstDOEShJeHlFkGmzrRcp.addon_log('mediatype : '+LfgdBCoaAnstDOEShJeHlFkGmzrRxb)
   LfgdBCoaAnstDOEShJeHlFkGmzrRcp.addon_log('vtypeId   : '+LfgdBCoaAnstDOEShJeHlFkGmzrRpW(LfgdBCoaAnstDOEShJeHlFkGmzrRIV))
   LfgdBCoaAnstDOEShJeHlFkGmzrRxy=LfgdBCoaAnstDOEShJeHlFkGmzrRcp.SpotvObj.GetBroadURL(LfgdBCoaAnstDOEShJeHlFkGmzrRxT,LfgdBCoaAnstDOEShJeHlFkGmzrRxb,LfgdBCoaAnstDOEShJeHlFkGmzrRIV)
  if LfgdBCoaAnstDOEShJeHlFkGmzrRxy=='':
   LfgdBCoaAnstDOEShJeHlFkGmzrRcp.addon_noti(__language__(30908).encode('utf8'))
   return
  LfgdBCoaAnstDOEShJeHlFkGmzrRxi=LfgdBCoaAnstDOEShJeHlFkGmzrRxy
  try:
   LfgdBCoaAnstDOEShJeHlFkGmzrRcp.addon_log('mainMode  = '+LfgdBCoaAnstDOEShJeHlFkGmzrRxW)
  except:
   LfgdBCoaAnstDOEShJeHlFkGmzrRXV
  LfgdBCoaAnstDOEShJeHlFkGmzrRcp.addon_log(LfgdBCoaAnstDOEShJeHlFkGmzrRxi)
  LfgdBCoaAnstDOEShJeHlFkGmzrRxQ=xbmcgui.ListItem(path=LfgdBCoaAnstDOEShJeHlFkGmzrRxi)
  xbmcplugin.setResolvedUrl(LfgdBCoaAnstDOEShJeHlFkGmzrRcp._addon_handle,LfgdBCoaAnstDOEShJeHlFkGmzrRpc,LfgdBCoaAnstDOEShJeHlFkGmzrRxQ)
  try:
   if LfgdBCoaAnstDOEShJeHlFkGmzrRxb=='vod' and LfgdBCoaAnstDOEShJeHlFkGmzrRxW not in['POP_VOD','NOW_VOD']:
    LfgdBCoaAnstDOEShJeHlFkGmzrRIp={'code':args.get('saveId'),'img':args.get('saveImg'),'title':args.get('saveTitle'),'info':args.get('saveInfo')}
    LfgdBCoaAnstDOEShJeHlFkGmzrRcp.Save_Watched_List(LfgdBCoaAnstDOEShJeHlFkGmzrRxb,LfgdBCoaAnstDOEShJeHlFkGmzrRIp)
  except:
   LfgdBCoaAnstDOEShJeHlFkGmzrRXV
 def logout(LfgdBCoaAnstDOEShJeHlFkGmzrRcp):
  LfgdBCoaAnstDOEShJeHlFkGmzrRcq=xbmcgui.Dialog()
  LfgdBCoaAnstDOEShJeHlFkGmzrRvV=LfgdBCoaAnstDOEShJeHlFkGmzrRcq.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if LfgdBCoaAnstDOEShJeHlFkGmzrRvV==LfgdBCoaAnstDOEShJeHlFkGmzrRXY:sys.exit()
  LfgdBCoaAnstDOEShJeHlFkGmzrRcp.SpotvObj.Init_ST_Total()
  if os.path.isfile(LfgdBCoaAnstDOEShJeHlFkGmzrRcX):os.remove(LfgdBCoaAnstDOEShJeHlFkGmzrRcX)
  LfgdBCoaAnstDOEShJeHlFkGmzrRcp.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(LfgdBCoaAnstDOEShJeHlFkGmzrRcp):
  LfgdBCoaAnstDOEShJeHlFkGmzrRxN =LfgdBCoaAnstDOEShJeHlFkGmzrRcp.SpotvObj.Get_Now_Datetime()
  LfgdBCoaAnstDOEShJeHlFkGmzrRxj=LfgdBCoaAnstDOEShJeHlFkGmzrRxN+datetime.timedelta(days=0)
  (LfgdBCoaAnstDOEShJeHlFkGmzrRvK,LfgdBCoaAnstDOEShJeHlFkGmzrRvw)=LfgdBCoaAnstDOEShJeHlFkGmzrRcp.get_settings_account()
  LfgdBCoaAnstDOEShJeHlFkGmzrRcp.SpotvObj.Save_session_acount(LfgdBCoaAnstDOEShJeHlFkGmzrRvK,LfgdBCoaAnstDOEShJeHlFkGmzrRvw)
  LfgdBCoaAnstDOEShJeHlFkGmzrRcp.SpotvObj.ST['account']['token_limit']=LfgdBCoaAnstDOEShJeHlFkGmzrRxj.strftime('%Y%m%d')
  LfgdBCoaAnstDOEShJeHlFkGmzrRcp.SpotvObj.JsonFile_Save(LfgdBCoaAnstDOEShJeHlFkGmzrRcX,LfgdBCoaAnstDOEShJeHlFkGmzrRcp.SpotvObj.ST)
 def cookiefile_check(LfgdBCoaAnstDOEShJeHlFkGmzrRcp):
  LfgdBCoaAnstDOEShJeHlFkGmzrRcp.SpotvObj.ST=LfgdBCoaAnstDOEShJeHlFkGmzrRcp.SpotvObj.JsonFile_Load(LfgdBCoaAnstDOEShJeHlFkGmzrRcX)
  if 'account' not in LfgdBCoaAnstDOEShJeHlFkGmzrRcp.SpotvObj.ST:
   LfgdBCoaAnstDOEShJeHlFkGmzrRcp.SpotvObj.Init_ST_Total()
   return LfgdBCoaAnstDOEShJeHlFkGmzrRXY
  (LfgdBCoaAnstDOEShJeHlFkGmzrRxu,LfgdBCoaAnstDOEShJeHlFkGmzrRxU)=LfgdBCoaAnstDOEShJeHlFkGmzrRcp.get_settings_account()
  (LfgdBCoaAnstDOEShJeHlFkGmzrRxM,LfgdBCoaAnstDOEShJeHlFkGmzrRxK)=LfgdBCoaAnstDOEShJeHlFkGmzrRcp.SpotvObj.Load_session_acount()
  if LfgdBCoaAnstDOEShJeHlFkGmzrRxu!=LfgdBCoaAnstDOEShJeHlFkGmzrRxM or LfgdBCoaAnstDOEShJeHlFkGmzrRxU!=LfgdBCoaAnstDOEShJeHlFkGmzrRxK:
   LfgdBCoaAnstDOEShJeHlFkGmzrRcp.SpotvObj.Init_ST_Total()
   return LfgdBCoaAnstDOEShJeHlFkGmzrRXY
  if LfgdBCoaAnstDOEShJeHlFkGmzrRpx(LfgdBCoaAnstDOEShJeHlFkGmzrRcp.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))>LfgdBCoaAnstDOEShJeHlFkGmzrRpx(LfgdBCoaAnstDOEShJeHlFkGmzrRcp.SpotvObj.ST['account']['token_limit']):
   LfgdBCoaAnstDOEShJeHlFkGmzrRcp.SpotvObj.Init_ST_Total()
   return LfgdBCoaAnstDOEShJeHlFkGmzrRXY
  return LfgdBCoaAnstDOEShJeHlFkGmzrRpc
 def dp_History_Remove(LfgdBCoaAnstDOEShJeHlFkGmzrRcp,args):
  LfgdBCoaAnstDOEShJeHlFkGmzrRxw=args.get('delType')
  LfgdBCoaAnstDOEShJeHlFkGmzrRxV =args.get('sKey')
  LfgdBCoaAnstDOEShJeHlFkGmzrRxY =args.get('vType')
  LfgdBCoaAnstDOEShJeHlFkGmzrRcq=xbmcgui.Dialog()
  if LfgdBCoaAnstDOEShJeHlFkGmzrRxw=='WATCH_ALL':
   LfgdBCoaAnstDOEShJeHlFkGmzrRvV=LfgdBCoaAnstDOEShJeHlFkGmzrRcq.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif LfgdBCoaAnstDOEShJeHlFkGmzrRxw=='WATCH_ONE':
   LfgdBCoaAnstDOEShJeHlFkGmzrRvV=LfgdBCoaAnstDOEShJeHlFkGmzrRcq.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  if LfgdBCoaAnstDOEShJeHlFkGmzrRvV==LfgdBCoaAnstDOEShJeHlFkGmzrRXY:sys.exit()
  if LfgdBCoaAnstDOEShJeHlFkGmzrRxw=='WATCH_ALL':
   LfgdBCoaAnstDOEShJeHlFkGmzrRXc=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%LfgdBCoaAnstDOEShJeHlFkGmzrRxY))
   if os.path.isfile(LfgdBCoaAnstDOEShJeHlFkGmzrRXc):os.remove(LfgdBCoaAnstDOEShJeHlFkGmzrRXc)
  elif LfgdBCoaAnstDOEShJeHlFkGmzrRxw=='WATCH_ONE':
   LfgdBCoaAnstDOEShJeHlFkGmzrRXc=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%LfgdBCoaAnstDOEShJeHlFkGmzrRxY))
   try:
    LfgdBCoaAnstDOEShJeHlFkGmzrRXI=LfgdBCoaAnstDOEShJeHlFkGmzrRcp.Load_List_File(LfgdBCoaAnstDOEShJeHlFkGmzrRxY) 
    fp=LfgdBCoaAnstDOEShJeHlFkGmzrRpb(LfgdBCoaAnstDOEShJeHlFkGmzrRXc,'w',-1,'utf-8')
    for LfgdBCoaAnstDOEShJeHlFkGmzrRXv in LfgdBCoaAnstDOEShJeHlFkGmzrRXI:
     LfgdBCoaAnstDOEShJeHlFkGmzrRXx=LfgdBCoaAnstDOEShJeHlFkGmzrRpq(urllib.parse.parse_qsl(LfgdBCoaAnstDOEShJeHlFkGmzrRXv))
     LfgdBCoaAnstDOEShJeHlFkGmzrRXp=LfgdBCoaAnstDOEShJeHlFkGmzrRXx.get('code').strip()
     if LfgdBCoaAnstDOEShJeHlFkGmzrRxV!=LfgdBCoaAnstDOEShJeHlFkGmzrRXp:
      fp.write(LfgdBCoaAnstDOEShJeHlFkGmzrRXv)
    fp.close()
   except:
    LfgdBCoaAnstDOEShJeHlFkGmzrRXV
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(LfgdBCoaAnstDOEShJeHlFkGmzrRcp,LfgdBCoaAnstDOEShJeHlFkGmzrRxb):
  try:
   LfgdBCoaAnstDOEShJeHlFkGmzrRXP=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%LfgdBCoaAnstDOEShJeHlFkGmzrRxb))
   fp=LfgdBCoaAnstDOEShJeHlFkGmzrRpb(LfgdBCoaAnstDOEShJeHlFkGmzrRXP,'r',-1,'utf-8')
   LfgdBCoaAnstDOEShJeHlFkGmzrRXW=fp.readlines()
   fp.close()
  except:
   LfgdBCoaAnstDOEShJeHlFkGmzrRXW=[]
  return LfgdBCoaAnstDOEShJeHlFkGmzrRXW
 def Save_Watched_List(LfgdBCoaAnstDOEShJeHlFkGmzrRcp,stype,LfgdBCoaAnstDOEShJeHlFkGmzrRcT):
  try:
   LfgdBCoaAnstDOEShJeHlFkGmzrRXP=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   LfgdBCoaAnstDOEShJeHlFkGmzrRXI=LfgdBCoaAnstDOEShJeHlFkGmzrRcp.Load_List_File(stype) 
   fp=LfgdBCoaAnstDOEShJeHlFkGmzrRpb(LfgdBCoaAnstDOEShJeHlFkGmzrRXP,'w',-1,'utf-8')
   LfgdBCoaAnstDOEShJeHlFkGmzrRXT=urllib.parse.urlencode(LfgdBCoaAnstDOEShJeHlFkGmzrRcT)
   LfgdBCoaAnstDOEShJeHlFkGmzrRXT=LfgdBCoaAnstDOEShJeHlFkGmzrRXT+'\n'
   fp.write(LfgdBCoaAnstDOEShJeHlFkGmzrRXT)
   LfgdBCoaAnstDOEShJeHlFkGmzrRXb=0
   for LfgdBCoaAnstDOEShJeHlFkGmzrRXv in LfgdBCoaAnstDOEShJeHlFkGmzrRXI:
    LfgdBCoaAnstDOEShJeHlFkGmzrRXx=LfgdBCoaAnstDOEShJeHlFkGmzrRpq(urllib.parse.parse_qsl(LfgdBCoaAnstDOEShJeHlFkGmzrRXv))
    LfgdBCoaAnstDOEShJeHlFkGmzrRXq=LfgdBCoaAnstDOEShJeHlFkGmzrRcT.get('code')
    LfgdBCoaAnstDOEShJeHlFkGmzrRXy=LfgdBCoaAnstDOEShJeHlFkGmzrRXx.get('code')
    if LfgdBCoaAnstDOEShJeHlFkGmzrRXq!=LfgdBCoaAnstDOEShJeHlFkGmzrRXy:
     fp.write(LfgdBCoaAnstDOEShJeHlFkGmzrRXv)
     LfgdBCoaAnstDOEShJeHlFkGmzrRXb+=1
     if LfgdBCoaAnstDOEShJeHlFkGmzrRXb>=50:break
   fp.close()
  except:
   LfgdBCoaAnstDOEShJeHlFkGmzrRXV
 def dp_Watch_List(LfgdBCoaAnstDOEShJeHlFkGmzrRcp,args):
  LfgdBCoaAnstDOEShJeHlFkGmzrRxb ='vod'
  if LfgdBCoaAnstDOEShJeHlFkGmzrRxb=='vod':
   LfgdBCoaAnstDOEShJeHlFkGmzrRXi=LfgdBCoaAnstDOEShJeHlFkGmzrRcp.Load_List_File(LfgdBCoaAnstDOEShJeHlFkGmzrRxb)
   for LfgdBCoaAnstDOEShJeHlFkGmzrRXQ in LfgdBCoaAnstDOEShJeHlFkGmzrRXi:
    LfgdBCoaAnstDOEShJeHlFkGmzrRXN=LfgdBCoaAnstDOEShJeHlFkGmzrRpq(urllib.parse.parse_qsl(LfgdBCoaAnstDOEShJeHlFkGmzrRXQ))
    LfgdBCoaAnstDOEShJeHlFkGmzrRcM =LfgdBCoaAnstDOEShJeHlFkGmzrRXN.get('title')
    LfgdBCoaAnstDOEShJeHlFkGmzrRIi=LfgdBCoaAnstDOEShJeHlFkGmzrRXN.get('img')
    LfgdBCoaAnstDOEShJeHlFkGmzrRxT=LfgdBCoaAnstDOEShJeHlFkGmzrRXN.get('code')
    LfgdBCoaAnstDOEShJeHlFkGmzrRXj =LfgdBCoaAnstDOEShJeHlFkGmzrRXN.get('info')
    LfgdBCoaAnstDOEShJeHlFkGmzrRIj={}
    LfgdBCoaAnstDOEShJeHlFkGmzrRIj['plot'] =LfgdBCoaAnstDOEShJeHlFkGmzrRXj
    LfgdBCoaAnstDOEShJeHlFkGmzrRIj['mediatype']='tvshow'
    LfgdBCoaAnstDOEShJeHlFkGmzrRIp={'mode':'GAME_VOD_GROUP','gameid':LfgdBCoaAnstDOEShJeHlFkGmzrRxT,'saveTitle':LfgdBCoaAnstDOEShJeHlFkGmzrRcM,'saveImg':LfgdBCoaAnstDOEShJeHlFkGmzrRIi,'saveInfo':LfgdBCoaAnstDOEShJeHlFkGmzrRXj,'mediatype':LfgdBCoaAnstDOEShJeHlFkGmzrRxb}
    LfgdBCoaAnstDOEShJeHlFkGmzrRXu={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':LfgdBCoaAnstDOEShJeHlFkGmzrRxT,'vType':LfgdBCoaAnstDOEShJeHlFkGmzrRxb,}
    LfgdBCoaAnstDOEShJeHlFkGmzrRXU=urllib.parse.urlencode(LfgdBCoaAnstDOEShJeHlFkGmzrRXu)
    LfgdBCoaAnstDOEShJeHlFkGmzrRXM=[('선택된 시청이력 ( %s ) 삭제'%(LfgdBCoaAnstDOEShJeHlFkGmzrRcM),'RunPlugin(plugin://plugin.video.spotvm/?%s)'%(LfgdBCoaAnstDOEShJeHlFkGmzrRXU))]
    LfgdBCoaAnstDOEShJeHlFkGmzrRcp.add_dir(LfgdBCoaAnstDOEShJeHlFkGmzrRcM,sublabel='',img=LfgdBCoaAnstDOEShJeHlFkGmzrRIi,infoLabels=LfgdBCoaAnstDOEShJeHlFkGmzrRIj,isFolder=LfgdBCoaAnstDOEShJeHlFkGmzrRpc,params=LfgdBCoaAnstDOEShJeHlFkGmzrRIp,ContextMenu=LfgdBCoaAnstDOEShJeHlFkGmzrRXM)
   LfgdBCoaAnstDOEShJeHlFkGmzrRIj={'plot':'시청목록을 삭제합니다.'}
   LfgdBCoaAnstDOEShJeHlFkGmzrRcM='*** 시청목록 삭제 ***'
   LfgdBCoaAnstDOEShJeHlFkGmzrRIp={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':LfgdBCoaAnstDOEShJeHlFkGmzrRxb,}
   LfgdBCoaAnstDOEShJeHlFkGmzrRIX=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   LfgdBCoaAnstDOEShJeHlFkGmzrRcp.add_dir(LfgdBCoaAnstDOEShJeHlFkGmzrRcM,sublabel='',img=LfgdBCoaAnstDOEShJeHlFkGmzrRIX,infoLabels=LfgdBCoaAnstDOEShJeHlFkGmzrRIj,isFolder=LfgdBCoaAnstDOEShJeHlFkGmzrRXY,params=LfgdBCoaAnstDOEShJeHlFkGmzrRIp,isLink=LfgdBCoaAnstDOEShJeHlFkGmzrRpc)
   xbmcplugin.endOfDirectory(LfgdBCoaAnstDOEShJeHlFkGmzrRcp._addon_handle,cacheToDisc=LfgdBCoaAnstDOEShJeHlFkGmzrRXY)
 def spotv_main(LfgdBCoaAnstDOEShJeHlFkGmzrRcp):
  LfgdBCoaAnstDOEShJeHlFkGmzrRcp.SpotvObj.KodiVersion=LfgdBCoaAnstDOEShJeHlFkGmzrRpx(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  LfgdBCoaAnstDOEShJeHlFkGmzrRXK=LfgdBCoaAnstDOEShJeHlFkGmzrRcp.main_params.get('mode',LfgdBCoaAnstDOEShJeHlFkGmzrRXV)
  if LfgdBCoaAnstDOEShJeHlFkGmzrRXK=='LOGOUT':
   LfgdBCoaAnstDOEShJeHlFkGmzrRcp.logout()
   return
  LfgdBCoaAnstDOEShJeHlFkGmzrRcp.login_main()
  if LfgdBCoaAnstDOEShJeHlFkGmzrRXK is LfgdBCoaAnstDOEShJeHlFkGmzrRXV:
   LfgdBCoaAnstDOEShJeHlFkGmzrRcp.dp_Main_List()
  elif LfgdBCoaAnstDOEShJeHlFkGmzrRXK=='LIVE_GROUP':
   LfgdBCoaAnstDOEShJeHlFkGmzrRcp.dp_LiveChannel_List(LfgdBCoaAnstDOEShJeHlFkGmzrRcp.main_params)
  elif LfgdBCoaAnstDOEShJeHlFkGmzrRXK=='ELIVE_GROUP':
   LfgdBCoaAnstDOEShJeHlFkGmzrRxP=LfgdBCoaAnstDOEShJeHlFkGmzrRcp.dp_EventLiveChannel_List(LfgdBCoaAnstDOEShJeHlFkGmzrRcp.main_params)
   if LfgdBCoaAnstDOEShJeHlFkGmzrRxP==401:
    if os.path.isfile(LfgdBCoaAnstDOEShJeHlFkGmzrRcX):os.remove(LfgdBCoaAnstDOEShJeHlFkGmzrRcX)
    LfgdBCoaAnstDOEShJeHlFkGmzrRcp.login_main()
    LfgdBCoaAnstDOEShJeHlFkGmzrRcp.dp_EventLiveChannel_List(LfgdBCoaAnstDOEShJeHlFkGmzrRcp.main_params)
  elif LfgdBCoaAnstDOEShJeHlFkGmzrRXK in['LIVE','GAME_VOD','POP_VOD','NOW_VOD','ELIVE']:
   LfgdBCoaAnstDOEShJeHlFkGmzrRcp.play_VIDEO(LfgdBCoaAnstDOEShJeHlFkGmzrRcp.main_params)
  elif LfgdBCoaAnstDOEShJeHlFkGmzrRXK=='VOD_GROUP':
   LfgdBCoaAnstDOEShJeHlFkGmzrRcp.dp_MainLeague_List(LfgdBCoaAnstDOEShJeHlFkGmzrRcp.main_params)
  elif LfgdBCoaAnstDOEShJeHlFkGmzrRXK=='NOW_GROUP':
   LfgdBCoaAnstDOEShJeHlFkGmzrRcp.dp_NowVod_GroupList(LfgdBCoaAnstDOEShJeHlFkGmzrRcp.main_params)
  elif LfgdBCoaAnstDOEShJeHlFkGmzrRXK=='POP_GROUP':
   LfgdBCoaAnstDOEShJeHlFkGmzrRcp.dp_PopVod_GroupList(LfgdBCoaAnstDOEShJeHlFkGmzrRcp.main_params)
  elif LfgdBCoaAnstDOEShJeHlFkGmzrRXK=='LEAGUE_GROUP':
   LfgdBCoaAnstDOEShJeHlFkGmzrRcp.dp_Season_List(LfgdBCoaAnstDOEShJeHlFkGmzrRcp.main_params)
  elif LfgdBCoaAnstDOEShJeHlFkGmzrRXK=='SEASON_GROUP':
   LfgdBCoaAnstDOEShJeHlFkGmzrRcp.dp_Game_List(LfgdBCoaAnstDOEShJeHlFkGmzrRcp.main_params)
  elif LfgdBCoaAnstDOEShJeHlFkGmzrRXK=='GAME_VOD_GROUP':
   LfgdBCoaAnstDOEShJeHlFkGmzrRcp.dp_GameVod_List(LfgdBCoaAnstDOEShJeHlFkGmzrRcp.main_params)
  elif LfgdBCoaAnstDOEShJeHlFkGmzrRXK=='WATCH':
   LfgdBCoaAnstDOEShJeHlFkGmzrRcp.dp_Watch_List(LfgdBCoaAnstDOEShJeHlFkGmzrRcp.main_params)
  elif LfgdBCoaAnstDOEShJeHlFkGmzrRXK=='MYVIEW_REMOVE':
   LfgdBCoaAnstDOEShJeHlFkGmzrRcp.dp_History_Remove(LfgdBCoaAnstDOEShJeHlFkGmzrRcp.main_params)
  else:
   LfgdBCoaAnstDOEShJeHlFkGmzrRXV
# Created by pyminifier (https://github.com/liftoff/pyminifier)
