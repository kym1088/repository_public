__author__="NightRain"
GvXYIpwoWuREKsTOSrNayxLCJiBVqj=object
GvXYIpwoWuREKsTOSrNayxLCJiBVqM=None
GvXYIpwoWuREKsTOSrNayxLCJiBVqc=False
GvXYIpwoWuREKsTOSrNayxLCJiBVqd=str
GvXYIpwoWuREKsTOSrNayxLCJiBVqH=open
GvXYIpwoWuREKsTOSrNayxLCJiBVqg=True
GvXYIpwoWuREKsTOSrNayxLCJiBVqt=int
GvXYIpwoWuREKsTOSrNayxLCJiBVqh=Exception
GvXYIpwoWuREKsTOSrNayxLCJiBVen=print
GvXYIpwoWuREKsTOSrNayxLCJiBVef=len
GvXYIpwoWuREKsTOSrNayxLCJiBVek=range
import urllib
import re
import json
import sys
import time
import requests
import datetime
import base64
import random
GvXYIpwoWuREKsTOSrNayxLCJiBVnk={'stream50':1080,'stream40':720,'stream30':540}
class GvXYIpwoWuREKsTOSrNayxLCJiBVnf(GvXYIpwoWuREKsTOSrNayxLCJiBVqj):
 def __init__(GvXYIpwoWuREKsTOSrNayxLCJiBVnz):
  GvXYIpwoWuREKsTOSrNayxLCJiBVnz.SPOTV_PMCODE ='987'
  GvXYIpwoWuREKsTOSrNayxLCJiBVnz.SPOTV_PMSIZE =3
  GvXYIpwoWuREKsTOSrNayxLCJiBVnz.GAMELIST_LIMIT =10
  GvXYIpwoWuREKsTOSrNayxLCJiBVnz.API_DOMAIN ='https://www.spotvnow.co.kr'
  GvXYIpwoWuREKsTOSrNayxLCJiBVnz.BC_DOMAIN ='https://players.brightcove.net'
  GvXYIpwoWuREKsTOSrNayxLCJiBVnz.PLAYER_DOMAIN ='https://edge.api.brightcove.com'
  GvXYIpwoWuREKsTOSrNayxLCJiBVnz.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36'
  GvXYIpwoWuREKsTOSrNayxLCJiBVnz.DEFAULT_HEADER ={'user-agent':GvXYIpwoWuREKsTOSrNayxLCJiBVnz.USER_AGENT}
  GvXYIpwoWuREKsTOSrNayxLCJiBVnz.COOKIE_FILE_NAME=''
  GvXYIpwoWuREKsTOSrNayxLCJiBVnz.KodiVersion =20
  GvXYIpwoWuREKsTOSrNayxLCJiBVnz.ST ={}
  GvXYIpwoWuREKsTOSrNayxLCJiBVnz.Init_ST_Total()
 def Init_ST_Total(GvXYIpwoWuREKsTOSrNayxLCJiBVnz):
  GvXYIpwoWuREKsTOSrNayxLCJiBVnz.ST={'account':{},'cookies':{},}
 def addon_log(GvXYIpwoWuREKsTOSrNayxLCJiBVnz,string):
  import xbmcaddon,xbmc
  __version__=xbmcaddon.Addon().getAddonInfo('version')
  __addonid__=xbmcaddon.Addon().getAddonInfo('id')
  try:
   GvXYIpwoWuREKsTOSrNayxLCJiBVnq=string.encode('utf-8','ignore')
  except:
   GvXYIpwoWuREKsTOSrNayxLCJiBVnq='addonException: addon_log'
  GvXYIpwoWuREKsTOSrNayxLCJiBVne=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,GvXYIpwoWuREKsTOSrNayxLCJiBVnq),level=GvXYIpwoWuREKsTOSrNayxLCJiBVne)
 def callRequestCookies(GvXYIpwoWuREKsTOSrNayxLCJiBVnz,jobtype,GvXYIpwoWuREKsTOSrNayxLCJiBVnc,payload=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,json=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,params=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,headers=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,cookies=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,redirects=GvXYIpwoWuREKsTOSrNayxLCJiBVqc):
  GvXYIpwoWuREKsTOSrNayxLCJiBVnm=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.DEFAULT_HEADER
  if headers:GvXYIpwoWuREKsTOSrNayxLCJiBVnm.update(headers)
  if jobtype=='Get':
   GvXYIpwoWuREKsTOSrNayxLCJiBVnP=requests.get(GvXYIpwoWuREKsTOSrNayxLCJiBVnc,params=params,headers=GvXYIpwoWuREKsTOSrNayxLCJiBVnm,cookies=cookies,allow_redirects=redirects)
  else:
   GvXYIpwoWuREKsTOSrNayxLCJiBVnP=requests.post(GvXYIpwoWuREKsTOSrNayxLCJiBVnc,data=payload,json=json,params=params,headers=GvXYIpwoWuREKsTOSrNayxLCJiBVnm,cookies=cookies,allow_redirects=redirects)
  try:
   GvXYIpwoWuREKsTOSrNayxLCJiBVnz.addon_log(GvXYIpwoWuREKsTOSrNayxLCJiBVqd(GvXYIpwoWuREKsTOSrNayxLCJiBVnP.status_code)+' : '+GvXYIpwoWuREKsTOSrNayxLCJiBVnP.url)
  except:
   GvXYIpwoWuREKsTOSrNayxLCJiBVqM
  return GvXYIpwoWuREKsTOSrNayxLCJiBVnP
 def JsonFile_Save(GvXYIpwoWuREKsTOSrNayxLCJiBVnz,filename,GvXYIpwoWuREKsTOSrNayxLCJiBVnQ):
  if filename=='':return GvXYIpwoWuREKsTOSrNayxLCJiBVqc
  try:
   fp=GvXYIpwoWuREKsTOSrNayxLCJiBVqH(filename,'w',-1,'utf-8')
   json.dump(GvXYIpwoWuREKsTOSrNayxLCJiBVnQ,fp,indent=4,ensure_ascii=GvXYIpwoWuREKsTOSrNayxLCJiBVqc)
   fp.close()
  except:
   return GvXYIpwoWuREKsTOSrNayxLCJiBVqc
  return GvXYIpwoWuREKsTOSrNayxLCJiBVqg
 def JsonFile_Load(GvXYIpwoWuREKsTOSrNayxLCJiBVnz,filename):
  if filename=='':return{}
  try:
   fp=GvXYIpwoWuREKsTOSrNayxLCJiBVqH(filename,'r',-1,'utf-8')
   GvXYIpwoWuREKsTOSrNayxLCJiBVnD=json.load(fp)
   fp.close()
  except:
   return{}
  return GvXYIpwoWuREKsTOSrNayxLCJiBVnD
 def Save_session_acount(GvXYIpwoWuREKsTOSrNayxLCJiBVnz,GvXYIpwoWuREKsTOSrNayxLCJiBVnl,GvXYIpwoWuREKsTOSrNayxLCJiBVnF):
  GvXYIpwoWuREKsTOSrNayxLCJiBVnz.ST['account']['stid'] =base64.standard_b64encode(GvXYIpwoWuREKsTOSrNayxLCJiBVnl.encode()).decode('utf-8')
  GvXYIpwoWuREKsTOSrNayxLCJiBVnz.ST['account']['stpw'] =base64.standard_b64encode(GvXYIpwoWuREKsTOSrNayxLCJiBVnF.encode()).decode('utf-8')
 def Load_session_acount(GvXYIpwoWuREKsTOSrNayxLCJiBVnz):
  try:
   GvXYIpwoWuREKsTOSrNayxLCJiBVnl =base64.standard_b64decode(GvXYIpwoWuREKsTOSrNayxLCJiBVnz.ST['account']['stid']).decode('utf-8')
   GvXYIpwoWuREKsTOSrNayxLCJiBVnF =base64.standard_b64decode(GvXYIpwoWuREKsTOSrNayxLCJiBVnz.ST['account']['stpw']).decode('utf-8')
  except:
   return '',''
  return GvXYIpwoWuREKsTOSrNayxLCJiBVnl,GvXYIpwoWuREKsTOSrNayxLCJiBVnF
 def makeDefaultCookies(GvXYIpwoWuREKsTOSrNayxLCJiBVnz):
  GvXYIpwoWuREKsTOSrNayxLCJiBVnU={'id_token':GvXYIpwoWuREKsTOSrNayxLCJiBVnz.ST['cookies']['id_token']}
  return GvXYIpwoWuREKsTOSrNayxLCJiBVnU
 def makeDefaultHeaders(GvXYIpwoWuREKsTOSrNayxLCJiBVnz):
  GvXYIpwoWuREKsTOSrNayxLCJiBVnA={'accept':'application/json;pk={}'.format(GvXYIpwoWuREKsTOSrNayxLCJiBVnz.ST['cookies']['spotv_policyKey'])}
  return GvXYIpwoWuREKsTOSrNayxLCJiBVnA
 def xmlText(GvXYIpwoWuREKsTOSrNayxLCJiBVnz,in_text):
  GvXYIpwoWuREKsTOSrNayxLCJiBVnj=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;')
  return GvXYIpwoWuREKsTOSrNayxLCJiBVnj
 def GetNoCache(GvXYIpwoWuREKsTOSrNayxLCJiBVnz,timetype=1):
  if timetype==1:
   return GvXYIpwoWuREKsTOSrNayxLCJiBVqt(time.time())
  else:
   return GvXYIpwoWuREKsTOSrNayxLCJiBVqt(time.time()*1000)
 def GetCredential_new(GvXYIpwoWuREKsTOSrNayxLCJiBVnz,user_id,user_pw):
  GvXYIpwoWuREKsTOSrNayxLCJiBVnM=requests.session()
  try:
   GvXYIpwoWuREKsTOSrNayxLCJiBVnc='https://nid.spotvnow.co.kr/api/v3/oauth2/authorize/spotvnow?return_url=https%3A%2F%2Fwww.spotvnow.co.kr%2Fcheck&err_return_url=https%3A%2F%2Fwww.spotvnow.co.kr%2Fabout&logout_url=https%3A%2F%2Fwww.spotvnow.co.kr%2Fintro'
   GvXYIpwoWuREKsTOSrNayxLCJiBVnA={'User-Agent':GvXYIpwoWuREKsTOSrNayxLCJiBVnz.USER_AGENT,}
   while(GvXYIpwoWuREKsTOSrNayxLCJiBVnc not in['',GvXYIpwoWuREKsTOSrNayxLCJiBVqM]):
    GvXYIpwoWuREKsTOSrNayxLCJiBVnd=GvXYIpwoWuREKsTOSrNayxLCJiBVnM.get(GvXYIpwoWuREKsTOSrNayxLCJiBVnc,params=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,headers=GvXYIpwoWuREKsTOSrNayxLCJiBVnA,cookies=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.ST['cookies'],allow_redirects=GvXYIpwoWuREKsTOSrNayxLCJiBVqc)
    GvXYIpwoWuREKsTOSrNayxLCJiBVnc =GvXYIpwoWuREKsTOSrNayxLCJiBVnd.headers.get('location')
    for GvXYIpwoWuREKsTOSrNayxLCJiBVnH in GvXYIpwoWuREKsTOSrNayxLCJiBVnd.cookies:
     if GvXYIpwoWuREKsTOSrNayxLCJiBVnH.value not in['',GvXYIpwoWuREKsTOSrNayxLCJiBVqM]:
      GvXYIpwoWuREKsTOSrNayxLCJiBVnz.ST['cookies'][GvXYIpwoWuREKsTOSrNayxLCJiBVnH.name]=GvXYIpwoWuREKsTOSrNayxLCJiBVnH.value
    if GvXYIpwoWuREKsTOSrNayxLCJiBVnd.status_code==200:break
   if GvXYIpwoWuREKsTOSrNayxLCJiBVnz.ST['cookies']['login_challenge']=='':
    GvXYIpwoWuREKsTOSrNayxLCJiBVnz.Init_ST_Total()
    return GvXYIpwoWuREKsTOSrNayxLCJiBVqc
  except GvXYIpwoWuREKsTOSrNayxLCJiBVqh as exception:
   GvXYIpwoWuREKsTOSrNayxLCJiBVen(exception)
   GvXYIpwoWuREKsTOSrNayxLCJiBVnz.Init_ST_Total()
   return GvXYIpwoWuREKsTOSrNayxLCJiBVqc
  try:
   GvXYIpwoWuREKsTOSrNayxLCJiBVng=base64.standard_b64encode(user_id.encode('UTF-8')).decode('utf-8')
   GvXYIpwoWuREKsTOSrNayxLCJiBVnt=base64.standard_b64encode(user_pw.encode('UTF-8')).decode('utf-8')
   GvXYIpwoWuREKsTOSrNayxLCJiBVnc='https://nid.spotvnow.co.kr/api/v3/user-auth/login'
   GvXYIpwoWuREKsTOSrNayxLCJiBVnA={'User-Agent':GvXYIpwoWuREKsTOSrNayxLCJiBVnz.USER_AGENT,}
   GvXYIpwoWuREKsTOSrNayxLCJiBVnh={'username':GvXYIpwoWuREKsTOSrNayxLCJiBVng,'password':GvXYIpwoWuREKsTOSrNayxLCJiBVnt,'remember':GvXYIpwoWuREKsTOSrNayxLCJiBVqg,'err_return_url':'https://www.spotvnow.co.kr/intro',}
   GvXYIpwoWuREKsTOSrNayxLCJiBVnd=GvXYIpwoWuREKsTOSrNayxLCJiBVnM.post(GvXYIpwoWuREKsTOSrNayxLCJiBVnc,data=GvXYIpwoWuREKsTOSrNayxLCJiBVnh,params=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,headers=GvXYIpwoWuREKsTOSrNayxLCJiBVnA,cookies=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.ST['cookies'],allow_redirects=GvXYIpwoWuREKsTOSrNayxLCJiBVqc)
   for GvXYIpwoWuREKsTOSrNayxLCJiBVnH in GvXYIpwoWuREKsTOSrNayxLCJiBVnd.cookies:
    if GvXYIpwoWuREKsTOSrNayxLCJiBVnH.value not in['',GvXYIpwoWuREKsTOSrNayxLCJiBVqM]:
     GvXYIpwoWuREKsTOSrNayxLCJiBVnz.ST['cookies'][GvXYIpwoWuREKsTOSrNayxLCJiBVnH.name]=GvXYIpwoWuREKsTOSrNayxLCJiBVnH.value
   GvXYIpwoWuREKsTOSrNayxLCJiBVnc=GvXYIpwoWuREKsTOSrNayxLCJiBVnd.headers.get('location')
   while(GvXYIpwoWuREKsTOSrNayxLCJiBVnc not in['',GvXYIpwoWuREKsTOSrNayxLCJiBVqM]):
    GvXYIpwoWuREKsTOSrNayxLCJiBVnA={'user-agent':GvXYIpwoWuREKsTOSrNayxLCJiBVnz.USER_AGENT,}
    GvXYIpwoWuREKsTOSrNayxLCJiBVnd=GvXYIpwoWuREKsTOSrNayxLCJiBVnM.get(GvXYIpwoWuREKsTOSrNayxLCJiBVnc,params=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,headers=GvXYIpwoWuREKsTOSrNayxLCJiBVnA,cookies=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.ST['cookies'],allow_redirects=GvXYIpwoWuREKsTOSrNayxLCJiBVqc)
    GvXYIpwoWuREKsTOSrNayxLCJiBVnc =GvXYIpwoWuREKsTOSrNayxLCJiBVnd.headers.get('location')
    for GvXYIpwoWuREKsTOSrNayxLCJiBVnH in GvXYIpwoWuREKsTOSrNayxLCJiBVnd.cookies:
     if GvXYIpwoWuREKsTOSrNayxLCJiBVnH.value not in['',GvXYIpwoWuREKsTOSrNayxLCJiBVqM]:
      GvXYIpwoWuREKsTOSrNayxLCJiBVnz.ST['cookies'][GvXYIpwoWuREKsTOSrNayxLCJiBVnH.name]=GvXYIpwoWuREKsTOSrNayxLCJiBVnH.value
    if GvXYIpwoWuREKsTOSrNayxLCJiBVnd.status_code==200:break
   if GvXYIpwoWuREKsTOSrNayxLCJiBVnz.ST['cookies']['id_token']=='':
    GvXYIpwoWuREKsTOSrNayxLCJiBVnz.Init_ST_Total()
    return GvXYIpwoWuREKsTOSrNayxLCJiBVqc
  except GvXYIpwoWuREKsTOSrNayxLCJiBVqh as exception:
   GvXYIpwoWuREKsTOSrNayxLCJiBVen(exception)
   GvXYIpwoWuREKsTOSrNayxLCJiBVnz.Init_ST_Total()
   return GvXYIpwoWuREKsTOSrNayxLCJiBVqc
  try:
   GvXYIpwoWuREKsTOSrNayxLCJiBVnc=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.API_DOMAIN+'/api/v3/session' 
   GvXYIpwoWuREKsTOSrNayxLCJiBVnU=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.makeDefaultCookies()
   GvXYIpwoWuREKsTOSrNayxLCJiBVnd=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.callRequestCookies('Get',GvXYIpwoWuREKsTOSrNayxLCJiBVnc,params=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,headers=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,cookies=GvXYIpwoWuREKsTOSrNayxLCJiBVnU)
   GvXYIpwoWuREKsTOSrNayxLCJiBVfn=json.loads(GvXYIpwoWuREKsTOSrNayxLCJiBVnd.text)
   GvXYIpwoWuREKsTOSrNayxLCJiBVnz.ST['cookies']['spotv_sessionid']=GvXYIpwoWuREKsTOSrNayxLCJiBVfn.get('userId')
   GvXYIpwoWuREKsTOSrNayxLCJiBVfk=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.SPOTV_PMCODE+GvXYIpwoWuREKsTOSrNayxLCJiBVqd(GvXYIpwoWuREKsTOSrNayxLCJiBVfn['subEndTime'])
   GvXYIpwoWuREKsTOSrNayxLCJiBVnz.ST['cookies']['spotv_subend'] =base64.standard_b64encode(GvXYIpwoWuREKsTOSrNayxLCJiBVfk.encode()).decode('utf-8')
  except GvXYIpwoWuREKsTOSrNayxLCJiBVqh as exception:
   GvXYIpwoWuREKsTOSrNayxLCJiBVen(exception)
   GvXYIpwoWuREKsTOSrNayxLCJiBVnz.Init_ST_Total()
   return GvXYIpwoWuREKsTOSrNayxLCJiBVqc
  try:
   if GvXYIpwoWuREKsTOSrNayxLCJiBVfn['subEndTime']in[0,'0',GvXYIpwoWuREKsTOSrNayxLCJiBVqM]:
    GvXYIpwoWuREKsTOSrNayxLCJiBVnc=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.API_DOMAIN+'/api/v3/user/sub/scope' 
    GvXYIpwoWuREKsTOSrNayxLCJiBVnU=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.makeDefaultCookies()
    GvXYIpwoWuREKsTOSrNayxLCJiBVnd=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.callRequestCookies('Get',GvXYIpwoWuREKsTOSrNayxLCJiBVnc,params=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,headers=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,cookies=GvXYIpwoWuREKsTOSrNayxLCJiBVnU)
    GvXYIpwoWuREKsTOSrNayxLCJiBVfn=json.loads(GvXYIpwoWuREKsTOSrNayxLCJiBVnd.text)
    if GvXYIpwoWuREKsTOSrNayxLCJiBVfn.get('endDate')==GvXYIpwoWuREKsTOSrNayxLCJiBVqM:
     GvXYIpwoWuREKsTOSrNayxLCJiBVfk=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.SPOTV_PMCODE+'0'
     GvXYIpwoWuREKsTOSrNayxLCJiBVnz.ST['cookies']['spotv_subend'] =base64.standard_b64encode(GvXYIpwoWuREKsTOSrNayxLCJiBVfk.encode()).decode('utf-8')
    else:
     GvXYIpwoWuREKsTOSrNayxLCJiBVfz=datetime.datetime.strptime(GvXYIpwoWuREKsTOSrNayxLCJiBVfn.get('endDate'),'%Y-%m-%d %H:%M:%S')
     GvXYIpwoWuREKsTOSrNayxLCJiBVfk=GvXYIpwoWuREKsTOSrNayxLCJiBVqt(time.mktime(GvXYIpwoWuREKsTOSrNayxLCJiBVfz.timetuple()))
     GvXYIpwoWuREKsTOSrNayxLCJiBVfk=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.SPOTV_PMCODE+GvXYIpwoWuREKsTOSrNayxLCJiBVqd(GvXYIpwoWuREKsTOSrNayxLCJiBVfk)+'000'
     GvXYIpwoWuREKsTOSrNayxLCJiBVnz.ST['cookies']['spotv_subend'] =base64.standard_b64encode(GvXYIpwoWuREKsTOSrNayxLCJiBVfk.encode()).decode('utf-8')
  except GvXYIpwoWuREKsTOSrNayxLCJiBVqh as exception:
   GvXYIpwoWuREKsTOSrNayxLCJiBVen(exception)
   GvXYIpwoWuREKsTOSrNayxLCJiBVnz.Init_ST_Total()
   return GvXYIpwoWuREKsTOSrNayxLCJiBVqc
  if GvXYIpwoWuREKsTOSrNayxLCJiBVnz.GetPolicyKey()==GvXYIpwoWuREKsTOSrNayxLCJiBVqc:
   GvXYIpwoWuREKsTOSrNayxLCJiBVnz.Init_ST_Total()
   return GvXYIpwoWuREKsTOSrNayxLCJiBVqc
  '''
  https://players.brightcove.net/5764318566001/2SXVGLGl4_default/index.min.js
    options: {accountId: "5764318566001", policyKey: "BCpkADawqM072_NUcqm8RBVoMGIaio2x979NvYhN4Zrs685jLKKYmCx_ssySm_0HFSnwPKQIbaekH1PnWGFk-nQCtuky-DlMgN4KNvNlPYjsojAi1fU9ozEXVSpULPylDb8STvOgPf-F941V-RbByAkzD8CgApyhBS8TNN-yDc17gnFUj82OEBP8DEo" }  
  '''  
  return GvXYIpwoWuREKsTOSrNayxLCJiBVqg
 def GetCredential(GvXYIpwoWuREKsTOSrNayxLCJiBVnz,user_id,user_pw):
  try:
   GvXYIpwoWuREKsTOSrNayxLCJiBVng=base64.standard_b64encode(user_id.encode('UTF-8')).decode('utf-8')
   GvXYIpwoWuREKsTOSrNayxLCJiBVnt=base64.standard_b64encode(user_pw.encode('UTF-8')).decode('utf-8')
   GvXYIpwoWuREKsTOSrNayxLCJiBVfq=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.API_DOMAIN+'/api/v2/login'
   GvXYIpwoWuREKsTOSrNayxLCJiBVnh={'username':GvXYIpwoWuREKsTOSrNayxLCJiBVng,'password':GvXYIpwoWuREKsTOSrNayxLCJiBVnt}
   GvXYIpwoWuREKsTOSrNayxLCJiBVnh=json.dumps(GvXYIpwoWuREKsTOSrNayxLCJiBVnh)
   GvXYIpwoWuREKsTOSrNayxLCJiBVnd=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.callRequestCookies('Post',GvXYIpwoWuREKsTOSrNayxLCJiBVfq,payload=GvXYIpwoWuREKsTOSrNayxLCJiBVnh,params=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,headers=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,cookies=GvXYIpwoWuREKsTOSrNayxLCJiBVqM)
   GvXYIpwoWuREKsTOSrNayxLCJiBVfe=json.loads(GvXYIpwoWuREKsTOSrNayxLCJiBVnd.text)
   for GvXYIpwoWuREKsTOSrNayxLCJiBVnH in GvXYIpwoWuREKsTOSrNayxLCJiBVnd.cookies:
    if GvXYIpwoWuREKsTOSrNayxLCJiBVnH.name=='SESSION':
     GvXYIpwoWuREKsTOSrNayxLCJiBVnz.ST['cookies']['spotv_session']=GvXYIpwoWuREKsTOSrNayxLCJiBVnH.value
     break
   if GvXYIpwoWuREKsTOSrNayxLCJiBVnz.ST['cookies']['spotv_session']=='':
    GvXYIpwoWuREKsTOSrNayxLCJiBVnz.Init_ST_Total()
    return GvXYIpwoWuREKsTOSrNayxLCJiBVqc
   GvXYIpwoWuREKsTOSrNayxLCJiBVnz.ST['cookies']['spotv_sessionid']=GvXYIpwoWuREKsTOSrNayxLCJiBVqd(GvXYIpwoWuREKsTOSrNayxLCJiBVfe['userId'])
   GvXYIpwoWuREKsTOSrNayxLCJiBVfk=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.SPOTV_PMCODE+GvXYIpwoWuREKsTOSrNayxLCJiBVqd(GvXYIpwoWuREKsTOSrNayxLCJiBVfe['subEndTime'])
   GvXYIpwoWuREKsTOSrNayxLCJiBVnz.ST['cookies']['spotv_subend'] =base64.standard_b64encode(GvXYIpwoWuREKsTOSrNayxLCJiBVfk.encode()).decode('utf-8')
   if GvXYIpwoWuREKsTOSrNayxLCJiBVnz.GetPolicyKey()==GvXYIpwoWuREKsTOSrNayxLCJiBVqc:
    GvXYIpwoWuREKsTOSrNayxLCJiBVnz.Init_ST_Total()
    return GvXYIpwoWuREKsTOSrNayxLCJiBVqc
  except GvXYIpwoWuREKsTOSrNayxLCJiBVqh as exception:
   GvXYIpwoWuREKsTOSrNayxLCJiBVen(exception)
   GvXYIpwoWuREKsTOSrNayxLCJiBVnz.Init_ST_Total()
   return GvXYIpwoWuREKsTOSrNayxLCJiBVqc
  return GvXYIpwoWuREKsTOSrNayxLCJiBVqg
 def GetPolicyKey(GvXYIpwoWuREKsTOSrNayxLCJiBVnz):
  try:
   GvXYIpwoWuREKsTOSrNayxLCJiBVnc=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.GetBcPlayerUrl()
   if GvXYIpwoWuREKsTOSrNayxLCJiBVnc=='':return GvXYIpwoWuREKsTOSrNayxLCJiBVqc
   GvXYIpwoWuREKsTOSrNayxLCJiBVnd=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.callRequestCookies('Get',GvXYIpwoWuREKsTOSrNayxLCJiBVnc,payload=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,params=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,headers=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,cookies=GvXYIpwoWuREKsTOSrNayxLCJiBVqM)
   GvXYIpwoWuREKsTOSrNayxLCJiBVfm=GvXYIpwoWuREKsTOSrNayxLCJiBVnd.text
   GvXYIpwoWuREKsTOSrNayxLCJiBVfP =re.findall('accountId:\s*\"\d{13}\",\s*policyKey:\s*\".[^(){}]{100,300}\"',GvXYIpwoWuREKsTOSrNayxLCJiBVfm)[0]
   GvXYIpwoWuREKsTOSrNayxLCJiBVfP =GvXYIpwoWuREKsTOSrNayxLCJiBVfP.replace('accountId','"accountId"')
   GvXYIpwoWuREKsTOSrNayxLCJiBVfP =GvXYIpwoWuREKsTOSrNayxLCJiBVfP.replace('policyKey','"policyKey"')
   GvXYIpwoWuREKsTOSrNayxLCJiBVfP ='{'+GvXYIpwoWuREKsTOSrNayxLCJiBVfP+'}'
   GvXYIpwoWuREKsTOSrNayxLCJiBVfQ=json.loads(GvXYIpwoWuREKsTOSrNayxLCJiBVfP)
   GvXYIpwoWuREKsTOSrNayxLCJiBVnz.ST['cookies']['spotv_accountId']=GvXYIpwoWuREKsTOSrNayxLCJiBVfQ['accountId']
   GvXYIpwoWuREKsTOSrNayxLCJiBVnz.ST['cookies']['spotv_policyKey']=GvXYIpwoWuREKsTOSrNayxLCJiBVfQ['policyKey']
  except GvXYIpwoWuREKsTOSrNayxLCJiBVqh as exception:
   GvXYIpwoWuREKsTOSrNayxLCJiBVen(exception)
   return GvXYIpwoWuREKsTOSrNayxLCJiBVqc
  return GvXYIpwoWuREKsTOSrNayxLCJiBVqg
 def GetBcPlayerUrl(GvXYIpwoWuREKsTOSrNayxLCJiBVnz):
  GvXYIpwoWuREKsTOSrNayxLCJiBVfb=''
  try:
   GvXYIpwoWuREKsTOSrNayxLCJiBVnc=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.GetMainJspath()
   if GvXYIpwoWuREKsTOSrNayxLCJiBVnc=='':return GvXYIpwoWuREKsTOSrNayxLCJiBVfb
   GvXYIpwoWuREKsTOSrNayxLCJiBVnd=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.callRequestCookies('Get',GvXYIpwoWuREKsTOSrNayxLCJiBVnc,payload=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,params=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,headers=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,cookies=GvXYIpwoWuREKsTOSrNayxLCJiBVqM)
   GvXYIpwoWuREKsTOSrNayxLCJiBVfm=GvXYIpwoWuREKsTOSrNayxLCJiBVnd.text
   GvXYIpwoWuREKsTOSrNayxLCJiBVfD =r'default:{(.*?)}'
   GvXYIpwoWuREKsTOSrNayxLCJiBVfl =re.compile(GvXYIpwoWuREKsTOSrNayxLCJiBVfD).findall(GvXYIpwoWuREKsTOSrNayxLCJiBVfm)[0]
   GvXYIpwoWuREKsTOSrNayxLCJiBVfF=r'bc:"(.*?)"'
   GvXYIpwoWuREKsTOSrNayxLCJiBVfU=re.compile(GvXYIpwoWuREKsTOSrNayxLCJiBVfF).findall(GvXYIpwoWuREKsTOSrNayxLCJiBVfl)[0]
   GvXYIpwoWuREKsTOSrNayxLCJiBVfA=r'":"(.*?)"'
   GvXYIpwoWuREKsTOSrNayxLCJiBVfj=re.compile(GvXYIpwoWuREKsTOSrNayxLCJiBVfA).findall(GvXYIpwoWuREKsTOSrNayxLCJiBVfl)[0]
   GvXYIpwoWuREKsTOSrNayxLCJiBVfb="%s/%s/%s_default/index.min.js"%(GvXYIpwoWuREKsTOSrNayxLCJiBVnz.BC_DOMAIN,GvXYIpwoWuREKsTOSrNayxLCJiBVfU,GvXYIpwoWuREKsTOSrNayxLCJiBVfj)
  except GvXYIpwoWuREKsTOSrNayxLCJiBVqh as exception:
   GvXYIpwoWuREKsTOSrNayxLCJiBVen(exception)
  return GvXYIpwoWuREKsTOSrNayxLCJiBVfb
 def GetMainJspath(GvXYIpwoWuREKsTOSrNayxLCJiBVnz):
  GvXYIpwoWuREKsTOSrNayxLCJiBVfM=''
  try:
   GvXYIpwoWuREKsTOSrNayxLCJiBVnc=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.API_DOMAIN
   GvXYIpwoWuREKsTOSrNayxLCJiBVnd=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.callRequestCookies('Get',GvXYIpwoWuREKsTOSrNayxLCJiBVnc,payload=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,params=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,headers=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,cookies=GvXYIpwoWuREKsTOSrNayxLCJiBVqM)
   GvXYIpwoWuREKsTOSrNayxLCJiBVfm=GvXYIpwoWuREKsTOSrNayxLCJiBVnd.text
   GvXYIpwoWuREKsTOSrNayxLCJiBVfP =re.findall('https://cdn.spotvnow.co.kr/dist/js/.{20}\.js',GvXYIpwoWuREKsTOSrNayxLCJiBVfm)[0]
   GvXYIpwoWuREKsTOSrNayxLCJiBVfM=GvXYIpwoWuREKsTOSrNayxLCJiBVfP
  except GvXYIpwoWuREKsTOSrNayxLCJiBVqh as exception:
   GvXYIpwoWuREKsTOSrNayxLCJiBVen(exception)
  return GvXYIpwoWuREKsTOSrNayxLCJiBVfM
 def Get_Now_Datetime(GvXYIpwoWuREKsTOSrNayxLCJiBVnz):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetLiveChannelList(GvXYIpwoWuREKsTOSrNayxLCJiBVnz):
  GvXYIpwoWuREKsTOSrNayxLCJiBVfd=[]
  GvXYIpwoWuREKsTOSrNayxLCJiBVfH ={}
  try:
   GvXYIpwoWuREKsTOSrNayxLCJiBVnc=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.API_DOMAIN+'/api/v3/channel'
   GvXYIpwoWuREKsTOSrNayxLCJiBVnd=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.callRequestCookies('Get',GvXYIpwoWuREKsTOSrNayxLCJiBVnc,payload=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,params=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,headers=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,cookies=GvXYIpwoWuREKsTOSrNayxLCJiBVqM)
   GvXYIpwoWuREKsTOSrNayxLCJiBVfe=json.loads(GvXYIpwoWuREKsTOSrNayxLCJiBVnd.text)
   GvXYIpwoWuREKsTOSrNayxLCJiBVfH=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.GetEPGList()
   for GvXYIpwoWuREKsTOSrNayxLCJiBVfg in GvXYIpwoWuREKsTOSrNayxLCJiBVfe:
    GvXYIpwoWuREKsTOSrNayxLCJiBVft={'id':GvXYIpwoWuREKsTOSrNayxLCJiBVfg['id'],'name':GvXYIpwoWuREKsTOSrNayxLCJiBVfg['name'],'logo':GvXYIpwoWuREKsTOSrNayxLCJiBVfg['logo'],'free':GvXYIpwoWuREKsTOSrNayxLCJiBVfg['free'],'programName':GvXYIpwoWuREKsTOSrNayxLCJiBVfg['programName'],'channelepg':GvXYIpwoWuREKsTOSrNayxLCJiBVfH.get(GvXYIpwoWuREKsTOSrNayxLCJiBVfg['id']),}
    GvXYIpwoWuREKsTOSrNayxLCJiBVfd.append(GvXYIpwoWuREKsTOSrNayxLCJiBVft)
  except GvXYIpwoWuREKsTOSrNayxLCJiBVqh as exception:
   GvXYIpwoWuREKsTOSrNayxLCJiBVen(exception)
  return GvXYIpwoWuREKsTOSrNayxLCJiBVfd
 def GetHlsUrl(GvXYIpwoWuREKsTOSrNayxLCJiBVnz,mediacode):
  GvXYIpwoWuREKsTOSrNayxLCJiBVfh=''
  try:
   GvXYIpwoWuREKsTOSrNayxLCJiBVnc=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.API_DOMAIN+'/api/v3/channel/'+mediacode
   GvXYIpwoWuREKsTOSrNayxLCJiBVnd=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.callRequestCookies('Get',GvXYIpwoWuREKsTOSrNayxLCJiBVnc,payload=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,params=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,headers=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,cookies=GvXYIpwoWuREKsTOSrNayxLCJiBVqM)
   GvXYIpwoWuREKsTOSrNayxLCJiBVfe=json.loads(GvXYIpwoWuREKsTOSrNayxLCJiBVnd.text)
   GvXYIpwoWuREKsTOSrNayxLCJiBVfh=GvXYIpwoWuREKsTOSrNayxLCJiBVfe['hlsUrl']
  except GvXYIpwoWuREKsTOSrNayxLCJiBVqh as exception:
   GvXYIpwoWuREKsTOSrNayxLCJiBVen(exception)
  return GvXYIpwoWuREKsTOSrNayxLCJiBVfh
 def GetEPGList(GvXYIpwoWuREKsTOSrNayxLCJiBVnz):
  GvXYIpwoWuREKsTOSrNayxLCJiBVkn={}
  GvXYIpwoWuREKsTOSrNayxLCJiBVkf=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.Get_Now_Datetime()
  GvXYIpwoWuREKsTOSrNayxLCJiBVkz=GvXYIpwoWuREKsTOSrNayxLCJiBVkf.strftime('%Y%m%d%H%M')
  GvXYIpwoWuREKsTOSrNayxLCJiBVkq='%s-%s-%s'%(GvXYIpwoWuREKsTOSrNayxLCJiBVkz[0:4],GvXYIpwoWuREKsTOSrNayxLCJiBVkz[4:6],GvXYIpwoWuREKsTOSrNayxLCJiBVkz[6:8])
  GvXYIpwoWuREKsTOSrNayxLCJiBVke=(GvXYIpwoWuREKsTOSrNayxLCJiBVkf+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M')
  try:
   GvXYIpwoWuREKsTOSrNayxLCJiBVnc=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.API_DOMAIN+'/api/v3/program/'+GvXYIpwoWuREKsTOSrNayxLCJiBVkq
   GvXYIpwoWuREKsTOSrNayxLCJiBVnd=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.callRequestCookies('Get',GvXYIpwoWuREKsTOSrNayxLCJiBVnc,payload=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,params=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,headers=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,cookies=GvXYIpwoWuREKsTOSrNayxLCJiBVqM)
   GvXYIpwoWuREKsTOSrNayxLCJiBVfe=json.loads(GvXYIpwoWuREKsTOSrNayxLCJiBVnd.text)
   GvXYIpwoWuREKsTOSrNayxLCJiBVkm=-1 
   GvXYIpwoWuREKsTOSrNayxLCJiBVkP =''
   for GvXYIpwoWuREKsTOSrNayxLCJiBVfg in GvXYIpwoWuREKsTOSrNayxLCJiBVfe:
    GvXYIpwoWuREKsTOSrNayxLCJiBVkQ=GvXYIpwoWuREKsTOSrNayxLCJiBVfg['channelId']
    GvXYIpwoWuREKsTOSrNayxLCJiBVkb =GvXYIpwoWuREKsTOSrNayxLCJiBVfg['startTime'].replace('-','').replace(' ','').replace(':','')
    GvXYIpwoWuREKsTOSrNayxLCJiBVkD =GvXYIpwoWuREKsTOSrNayxLCJiBVfg['endTime'].replace('-','').replace(' ','').replace(':','')
    if GvXYIpwoWuREKsTOSrNayxLCJiBVqt(GvXYIpwoWuREKsTOSrNayxLCJiBVkz)>GvXYIpwoWuREKsTOSrNayxLCJiBVqt(GvXYIpwoWuREKsTOSrNayxLCJiBVkD) :continue
    if GvXYIpwoWuREKsTOSrNayxLCJiBVqt(GvXYIpwoWuREKsTOSrNayxLCJiBVke)<GvXYIpwoWuREKsTOSrNayxLCJiBVqt(GvXYIpwoWuREKsTOSrNayxLCJiBVkb):continue
    if GvXYIpwoWuREKsTOSrNayxLCJiBVkm!=GvXYIpwoWuREKsTOSrNayxLCJiBVkQ:
     if GvXYIpwoWuREKsTOSrNayxLCJiBVkP!='':GvXYIpwoWuREKsTOSrNayxLCJiBVkn[GvXYIpwoWuREKsTOSrNayxLCJiBVkm]=GvXYIpwoWuREKsTOSrNayxLCJiBVkP
     GvXYIpwoWuREKsTOSrNayxLCJiBVkm=GvXYIpwoWuREKsTOSrNayxLCJiBVkQ
     GvXYIpwoWuREKsTOSrNayxLCJiBVkP =''
    if GvXYIpwoWuREKsTOSrNayxLCJiBVkP:GvXYIpwoWuREKsTOSrNayxLCJiBVkP+='\n'
    GvXYIpwoWuREKsTOSrNayxLCJiBVkP+=GvXYIpwoWuREKsTOSrNayxLCJiBVfg['title']+'\n'
    GvXYIpwoWuREKsTOSrNayxLCJiBVkP+=' [%s ~ %s]'%(GvXYIpwoWuREKsTOSrNayxLCJiBVfg['startTime'][-5:],GvXYIpwoWuREKsTOSrNayxLCJiBVfg['endTime'][-5:])+'\n'
   if GvXYIpwoWuREKsTOSrNayxLCJiBVkP:GvXYIpwoWuREKsTOSrNayxLCJiBVkn[GvXYIpwoWuREKsTOSrNayxLCJiBVkm]=GvXYIpwoWuREKsTOSrNayxLCJiBVkP
  except GvXYIpwoWuREKsTOSrNayxLCJiBVqh as exception:
   GvXYIpwoWuREKsTOSrNayxLCJiBVen(exception)
  return GvXYIpwoWuREKsTOSrNayxLCJiBVkn
 def GetEPGList_new(GvXYIpwoWuREKsTOSrNayxLCJiBVnz):
  GvXYIpwoWuREKsTOSrNayxLCJiBVkn={}
  GvXYIpwoWuREKsTOSrNayxLCJiBVkf=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.Get_Now_Datetime()
  GvXYIpwoWuREKsTOSrNayxLCJiBVkz=GvXYIpwoWuREKsTOSrNayxLCJiBVkf.strftime('%Y%m%d%H%M00')
  GvXYIpwoWuREKsTOSrNayxLCJiBVkq='%s%s%s'%(GvXYIpwoWuREKsTOSrNayxLCJiBVkz[0:4],GvXYIpwoWuREKsTOSrNayxLCJiBVkz[4:6],GvXYIpwoWuREKsTOSrNayxLCJiBVkz[6:8])
  GvXYIpwoWuREKsTOSrNayxLCJiBVke=(GvXYIpwoWuREKsTOSrNayxLCJiBVkf+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M00')
  try:
   for GvXYIpwoWuREKsTOSrNayxLCJiBVfg in LIVETV_LIST:
    GvXYIpwoWuREKsTOSrNayxLCJiBVkl =GvXYIpwoWuREKsTOSrNayxLCJiBVfg['videoId']
    if GvXYIpwoWuREKsTOSrNayxLCJiBVfg['epgtype']=='spotvon':
     GvXYIpwoWuREKsTOSrNayxLCJiBVkP=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.Get_EpgInfo_Spotv_spotvon(GvXYIpwoWuREKsTOSrNayxLCJiBVkl,GvXYIpwoWuREKsTOSrNayxLCJiBVfg['epgnm'],GvXYIpwoWuREKsTOSrNayxLCJiBVkq)
     GvXYIpwoWuREKsTOSrNayxLCJiBVkn[GvXYIpwoWuREKsTOSrNayxLCJiBVkl]=GvXYIpwoWuREKsTOSrNayxLCJiBVkP
    if GvXYIpwoWuREKsTOSrNayxLCJiBVfg['epgtype']=='spotvnet':
     GvXYIpwoWuREKsTOSrNayxLCJiBVkP=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.Get_EpgInfo_Spotv_spotvnet(GvXYIpwoWuREKsTOSrNayxLCJiBVkl,GvXYIpwoWuREKsTOSrNayxLCJiBVfg['epgnm'],GvXYIpwoWuREKsTOSrNayxLCJiBVkq)
     GvXYIpwoWuREKsTOSrNayxLCJiBVkn[GvXYIpwoWuREKsTOSrNayxLCJiBVkl]=GvXYIpwoWuREKsTOSrNayxLCJiBVkP
   for GvXYIpwoWuREKsTOSrNayxLCJiBVkF in GvXYIpwoWuREKsTOSrNayxLCJiBVkn.keys():
    if GvXYIpwoWuREKsTOSrNayxLCJiBVef(GvXYIpwoWuREKsTOSrNayxLCJiBVkn.get(GvXYIpwoWuREKsTOSrNayxLCJiBVkF))==0:continue
    GvXYIpwoWuREKsTOSrNayxLCJiBVkP =''
    GvXYIpwoWuREKsTOSrNayxLCJiBVkU=''
    for GvXYIpwoWuREKsTOSrNayxLCJiBVkA in GvXYIpwoWuREKsTOSrNayxLCJiBVkn.get(GvXYIpwoWuREKsTOSrNayxLCJiBVkF):
     GvXYIpwoWuREKsTOSrNayxLCJiBVkb =GvXYIpwoWuREKsTOSrNayxLCJiBVkA['startTime']
     GvXYIpwoWuREKsTOSrNayxLCJiBVkD =GvXYIpwoWuREKsTOSrNayxLCJiBVkA['endTime']
     if GvXYIpwoWuREKsTOSrNayxLCJiBVqt(GvXYIpwoWuREKsTOSrNayxLCJiBVkz)>GvXYIpwoWuREKsTOSrNayxLCJiBVqt(GvXYIpwoWuREKsTOSrNayxLCJiBVkD) :continue
     if GvXYIpwoWuREKsTOSrNayxLCJiBVqt(GvXYIpwoWuREKsTOSrNayxLCJiBVke)<GvXYIpwoWuREKsTOSrNayxLCJiBVqt(GvXYIpwoWuREKsTOSrNayxLCJiBVkb):continue
     if GvXYIpwoWuREKsTOSrNayxLCJiBVqt(GvXYIpwoWuREKsTOSrNayxLCJiBVkz)>=GvXYIpwoWuREKsTOSrNayxLCJiBVqt(GvXYIpwoWuREKsTOSrNayxLCJiBVkb)and GvXYIpwoWuREKsTOSrNayxLCJiBVqt(GvXYIpwoWuREKsTOSrNayxLCJiBVkz)<GvXYIpwoWuREKsTOSrNayxLCJiBVqt(GvXYIpwoWuREKsTOSrNayxLCJiBVkD):GvXYIpwoWuREKsTOSrNayxLCJiBVkU=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.xmlText(GvXYIpwoWuREKsTOSrNayxLCJiBVkA['title'])
     if GvXYIpwoWuREKsTOSrNayxLCJiBVkP:GvXYIpwoWuREKsTOSrNayxLCJiBVkP+='\n'
     GvXYIpwoWuREKsTOSrNayxLCJiBVkP+=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.xmlText(GvXYIpwoWuREKsTOSrNayxLCJiBVkA['title'])+'\n'
     GvXYIpwoWuREKsTOSrNayxLCJiBVkP+=' [%s:%s ~ %s:%s]'%(GvXYIpwoWuREKsTOSrNayxLCJiBVkA['startTime'][8:10],GvXYIpwoWuREKsTOSrNayxLCJiBVkA['startTime'][10:12],GvXYIpwoWuREKsTOSrNayxLCJiBVkA['endTime'][8:10],GvXYIpwoWuREKsTOSrNayxLCJiBVkA['endTime'][10:12])+'\n'
    GvXYIpwoWuREKsTOSrNayxLCJiBVkn[GvXYIpwoWuREKsTOSrNayxLCJiBVkF]={'epg':GvXYIpwoWuREKsTOSrNayxLCJiBVkP,'title':GvXYIpwoWuREKsTOSrNayxLCJiBVkU}
  except GvXYIpwoWuREKsTOSrNayxLCJiBVqh as exception:
   GvXYIpwoWuREKsTOSrNayxLCJiBVen(exception)
  return GvXYIpwoWuREKsTOSrNayxLCJiBVkn
 def Get_EpgInfo_Spotv_spotvon(GvXYIpwoWuREKsTOSrNayxLCJiBVnz,GvXYIpwoWuREKsTOSrNayxLCJiBVkl,epgnm,now_day):
  GvXYIpwoWuREKsTOSrNayxLCJiBVkn =[]
  try:
   GvXYIpwoWuREKsTOSrNayxLCJiBVnc='https://www.spotvon.co.kr/data/onAir/%s/Daily/D%s.asp'%(epgnm,now_day)
   GvXYIpwoWuREKsTOSrNayxLCJiBVnd=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.callRequestCookies('Get',GvXYIpwoWuREKsTOSrNayxLCJiBVnc,payload=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,params=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,headers=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,cookies=GvXYIpwoWuREKsTOSrNayxLCJiBVqM)
   GvXYIpwoWuREKsTOSrNayxLCJiBVfn=json.loads(GvXYIpwoWuREKsTOSrNayxLCJiBVnd.text)
   for GvXYIpwoWuREKsTOSrNayxLCJiBVfg in GvXYIpwoWuREKsTOSrNayxLCJiBVfn:
    GvXYIpwoWuREKsTOSrNayxLCJiBVft={'title':GvXYIpwoWuREKsTOSrNayxLCJiBVfg['title'],'startTime':GvXYIpwoWuREKsTOSrNayxLCJiBVfg['sch_date'].replace('-','')+GvXYIpwoWuREKsTOSrNayxLCJiBVqd(GvXYIpwoWuREKsTOSrNayxLCJiBVfg['sch_hour']).zfill(2)+GvXYIpwoWuREKsTOSrNayxLCJiBVfg['sch_min']+'00'}
    GvXYIpwoWuREKsTOSrNayxLCJiBVkn.append(GvXYIpwoWuREKsTOSrNayxLCJiBVft)
   for i in GvXYIpwoWuREKsTOSrNayxLCJiBVek(GvXYIpwoWuREKsTOSrNayxLCJiBVef(GvXYIpwoWuREKsTOSrNayxLCJiBVkn)):
    if i>0:GvXYIpwoWuREKsTOSrNayxLCJiBVkn[i-1]['endTime']=GvXYIpwoWuREKsTOSrNayxLCJiBVkn[i]['startTime']
    if i==GvXYIpwoWuREKsTOSrNayxLCJiBVef(GvXYIpwoWuREKsTOSrNayxLCJiBVkn)-1: GvXYIpwoWuREKsTOSrNayxLCJiBVkn[i]['endTime']=now_day+'240000'
  except GvXYIpwoWuREKsTOSrNayxLCJiBVqh as exception:
   GvXYIpwoWuREKsTOSrNayxLCJiBVen(exception)
   return[]
  return GvXYIpwoWuREKsTOSrNayxLCJiBVkn
 def Get_EpgInfo_Spotv_spotvnet(GvXYIpwoWuREKsTOSrNayxLCJiBVnz,GvXYIpwoWuREKsTOSrNayxLCJiBVkl,epgnm,now_day):
  GvXYIpwoWuREKsTOSrNayxLCJiBVkn =[]
  try:
   GvXYIpwoWuREKsTOSrNayxLCJiBVnc='https://www.spotv.net/data/json/schedule/%s/Daily/D%s.json'%(epgnm,now_day)
   GvXYIpwoWuREKsTOSrNayxLCJiBVnd=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.callRequestCookies('Get',GvXYIpwoWuREKsTOSrNayxLCJiBVnc,payload=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,params=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,headers=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,cookies=GvXYIpwoWuREKsTOSrNayxLCJiBVqM)
   GvXYIpwoWuREKsTOSrNayxLCJiBVfn=json.loads(GvXYIpwoWuREKsTOSrNayxLCJiBVnd.text)
   for GvXYIpwoWuREKsTOSrNayxLCJiBVfg in GvXYIpwoWuREKsTOSrNayxLCJiBVfn:
    GvXYIpwoWuREKsTOSrNayxLCJiBVft={'title':GvXYIpwoWuREKsTOSrNayxLCJiBVfg['title'],'startTime':GvXYIpwoWuREKsTOSrNayxLCJiBVfg['sch_date'].replace('-','')+GvXYIpwoWuREKsTOSrNayxLCJiBVqd(GvXYIpwoWuREKsTOSrNayxLCJiBVfg['sch_hour']).zfill(2)+GvXYIpwoWuREKsTOSrNayxLCJiBVfg['sch_min']+'00'}
    GvXYIpwoWuREKsTOSrNayxLCJiBVkn.append(GvXYIpwoWuREKsTOSrNayxLCJiBVft)
   for i in GvXYIpwoWuREKsTOSrNayxLCJiBVek(GvXYIpwoWuREKsTOSrNayxLCJiBVef(GvXYIpwoWuREKsTOSrNayxLCJiBVkn)):
    if i>0:GvXYIpwoWuREKsTOSrNayxLCJiBVkn[i-1]['endTime']=GvXYIpwoWuREKsTOSrNayxLCJiBVkn[i]['startTime']
    if i==GvXYIpwoWuREKsTOSrNayxLCJiBVef(GvXYIpwoWuREKsTOSrNayxLCJiBVkn)-1: GvXYIpwoWuREKsTOSrNayxLCJiBVkn[i]['endTime']=now_day+'240000'
  except GvXYIpwoWuREKsTOSrNayxLCJiBVqh as exception:
   GvXYIpwoWuREKsTOSrNayxLCJiBVen(exception)
   return[]
  return GvXYIpwoWuREKsTOSrNayxLCJiBVkn
 def GetEventLiveList(GvXYIpwoWuREKsTOSrNayxLCJiBVnz):
  GvXYIpwoWuREKsTOSrNayxLCJiBVfd=[]
  GvXYIpwoWuREKsTOSrNayxLCJiBVkj =0
  try:
   GvXYIpwoWuREKsTOSrNayxLCJiBVkM=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.Get_Now_Datetime()
   GvXYIpwoWuREKsTOSrNayxLCJiBVkc=GvXYIpwoWuREKsTOSrNayxLCJiBVkM.strftime('%Y-%m-%d')
  except GvXYIpwoWuREKsTOSrNayxLCJiBVqh as exception:
   GvXYIpwoWuREKsTOSrNayxLCJiBVen(exception)
   return GvXYIpwoWuREKsTOSrNayxLCJiBVfd,GvXYIpwoWuREKsTOSrNayxLCJiBVkj
  GvXYIpwoWuREKsTOSrNayxLCJiBVnc=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.API_DOMAIN+'/api/v3/player/lives/'+GvXYIpwoWuREKsTOSrNayxLCJiBVkc 
  GvXYIpwoWuREKsTOSrNayxLCJiBVnU=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.makeDefaultCookies()
  GvXYIpwoWuREKsTOSrNayxLCJiBVnd=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.callRequestCookies('Get',GvXYIpwoWuREKsTOSrNayxLCJiBVnc,payload=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,params=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,headers=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,cookies=GvXYIpwoWuREKsTOSrNayxLCJiBVnU)
  GvXYIpwoWuREKsTOSrNayxLCJiBVkj=GvXYIpwoWuREKsTOSrNayxLCJiBVnd.status_code 
  if GvXYIpwoWuREKsTOSrNayxLCJiBVkj!=200:return GvXYIpwoWuREKsTOSrNayxLCJiBVfd,GvXYIpwoWuREKsTOSrNayxLCJiBVkj
  GvXYIpwoWuREKsTOSrNayxLCJiBVfe=json.loads(GvXYIpwoWuREKsTOSrNayxLCJiBVnd.text)
  for GvXYIpwoWuREKsTOSrNayxLCJiBVkd in GvXYIpwoWuREKsTOSrNayxLCJiBVfe:
   for GvXYIpwoWuREKsTOSrNayxLCJiBVfg in GvXYIpwoWuREKsTOSrNayxLCJiBVkd['liveNowList']:
    if GvXYIpwoWuREKsTOSrNayxLCJiBVfg['gameDesc']['title']==GvXYIpwoWuREKsTOSrNayxLCJiBVqM or GvXYIpwoWuREKsTOSrNayxLCJiBVfg['gameDesc']['title']=='':
     GvXYIpwoWuREKsTOSrNayxLCJiBVkH='%s ( %s : %s )'%(GvXYIpwoWuREKsTOSrNayxLCJiBVfg['leagueName'],GvXYIpwoWuREKsTOSrNayxLCJiBVfg['homeNameShort'],GvXYIpwoWuREKsTOSrNayxLCJiBVfg['awayNameShort'])
    else:
     GvXYIpwoWuREKsTOSrNayxLCJiBVkH=GvXYIpwoWuREKsTOSrNayxLCJiBVfg['gameDesc']['title']
    GvXYIpwoWuREKsTOSrNayxLCJiBVft={'liveId':GvXYIpwoWuREKsTOSrNayxLCJiBVfg['liveId'],'title':GvXYIpwoWuREKsTOSrNayxLCJiBVkH,'logo':GvXYIpwoWuREKsTOSrNayxLCJiBVfg['gameDesc']['leagueLogo'],'free':GvXYIpwoWuREKsTOSrNayxLCJiBVfg['isFree'],'startTime':GvXYIpwoWuREKsTOSrNayxLCJiBVfg['startTime']}
    GvXYIpwoWuREKsTOSrNayxLCJiBVfd.append(GvXYIpwoWuREKsTOSrNayxLCJiBVft)
  return GvXYIpwoWuREKsTOSrNayxLCJiBVfd,GvXYIpwoWuREKsTOSrNayxLCJiBVkj
 def GetEventLive_videoId(GvXYIpwoWuREKsTOSrNayxLCJiBVnz,liveId):
  GvXYIpwoWuREKsTOSrNayxLCJiBVkg=''
  try:
   GvXYIpwoWuREKsTOSrNayxLCJiBVnc=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.API_DOMAIN+'/api/v3/live/'+liveId
   GvXYIpwoWuREKsTOSrNayxLCJiBVnd=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.callRequestCookies('Get',GvXYIpwoWuREKsTOSrNayxLCJiBVnc,payload=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,params=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,headers=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,cookies=GvXYIpwoWuREKsTOSrNayxLCJiBVqM)
   GvXYIpwoWuREKsTOSrNayxLCJiBVfe=json.loads(GvXYIpwoWuREKsTOSrNayxLCJiBVnd.text)
   GvXYIpwoWuREKsTOSrNayxLCJiBVkt=GvXYIpwoWuREKsTOSrNayxLCJiBVfe['videoId']
   GvXYIpwoWuREKsTOSrNayxLCJiBVkg=GvXYIpwoWuREKsTOSrNayxLCJiBVkt.replace('ref:','')
  except GvXYIpwoWuREKsTOSrNayxLCJiBVqh as exception:
   GvXYIpwoWuREKsTOSrNayxLCJiBVen(exception)
  return GvXYIpwoWuREKsTOSrNayxLCJiBVkg
 def CheckMainEnd(GvXYIpwoWuREKsTOSrNayxLCJiBVnz):
  GvXYIpwoWuREKsTOSrNayxLCJiBVkh=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.SPOTV_PMCODE+GvXYIpwoWuREKsTOSrNayxLCJiBVqd(GvXYIpwoWuREKsTOSrNayxLCJiBVnz.ST['cookies']['spotv_sessionid'])
  GvXYIpwoWuREKsTOSrNayxLCJiBVkh=base64.standard_b64encode(GvXYIpwoWuREKsTOSrNayxLCJiBVkh.encode()).decode('utf-8')
  if GvXYIpwoWuREKsTOSrNayxLCJiBVkh=='OTg3MTgzMzM0Ng==' or GvXYIpwoWuREKsTOSrNayxLCJiBVkh=='OTg3MTgzMzExNw==':return GvXYIpwoWuREKsTOSrNayxLCJiBVqg
  return GvXYIpwoWuREKsTOSrNayxLCJiBVqc
 def CheckSubEnd(GvXYIpwoWuREKsTOSrNayxLCJiBVnz):
  GvXYIpwoWuREKsTOSrNayxLCJiBVnD=GvXYIpwoWuREKsTOSrNayxLCJiBVqc
  try:
   if GvXYIpwoWuREKsTOSrNayxLCJiBVnz.CheckMainEnd():return GvXYIpwoWuREKsTOSrNayxLCJiBVqg 
   GvXYIpwoWuREKsTOSrNayxLCJiBVzn=base64.standard_b64decode(GvXYIpwoWuREKsTOSrNayxLCJiBVnz.ST['cookies']['spotv_subend']).decode('utf-8')[GvXYIpwoWuREKsTOSrNayxLCJiBVnz.SPOTV_PMSIZE:]
   if GvXYIpwoWuREKsTOSrNayxLCJiBVzn=='0':return GvXYIpwoWuREKsTOSrNayxLCJiBVnD
   GvXYIpwoWuREKsTOSrNayxLCJiBVzf =GvXYIpwoWuREKsTOSrNayxLCJiBVqt(GvXYIpwoWuREKsTOSrNayxLCJiBVnz.Get_Now_Datetime().strftime('%Y%m%d'))
   GvXYIpwoWuREKsTOSrNayxLCJiBVzk =GvXYIpwoWuREKsTOSrNayxLCJiBVqt(GvXYIpwoWuREKsTOSrNayxLCJiBVzn)/1000
   GvXYIpwoWuREKsTOSrNayxLCJiBVzq =GvXYIpwoWuREKsTOSrNayxLCJiBVqt(datetime.datetime.fromtimestamp(GvXYIpwoWuREKsTOSrNayxLCJiBVzk,datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul')).strftime('%Y%m%d'))
   if GvXYIpwoWuREKsTOSrNayxLCJiBVzf<=GvXYIpwoWuREKsTOSrNayxLCJiBVzq:GvXYIpwoWuREKsTOSrNayxLCJiBVnD=GvXYIpwoWuREKsTOSrNayxLCJiBVqg
  except GvXYIpwoWuREKsTOSrNayxLCJiBVqh as exception:
   GvXYIpwoWuREKsTOSrNayxLCJiBVen(exception)
   return GvXYIpwoWuREKsTOSrNayxLCJiBVnD
  return GvXYIpwoWuREKsTOSrNayxLCJiBVnD
 def GetBroadURL(GvXYIpwoWuREKsTOSrNayxLCJiBVnz,GvXYIpwoWuREKsTOSrNayxLCJiBVkg,mediatype,GvXYIpwoWuREKsTOSrNayxLCJiBVzU):
  GvXYIpwoWuREKsTOSrNayxLCJiBVze=''
  try:
   if mediatype=='live':
    GvXYIpwoWuREKsTOSrNayxLCJiBVnc=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.API_DOMAIN+'/api/v3/live/'+GvXYIpwoWuREKsTOSrNayxLCJiBVkg
   else:
    GvXYIpwoWuREKsTOSrNayxLCJiBVkg=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.GetReplay_UrlId(GvXYIpwoWuREKsTOSrNayxLCJiBVkg,GvXYIpwoWuREKsTOSrNayxLCJiBVzU)
    if GvXYIpwoWuREKsTOSrNayxLCJiBVkg=='':return GvXYIpwoWuREKsTOSrNayxLCJiBVze
    GvXYIpwoWuREKsTOSrNayxLCJiBVnc=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.PLAYER_DOMAIN+'/playback/v1/accounts/'+GvXYIpwoWuREKsTOSrNayxLCJiBVqd(GvXYIpwoWuREKsTOSrNayxLCJiBVnz.ST['cookies']['spotv_accountId'])+'/videos/'+GvXYIpwoWuREKsTOSrNayxLCJiBVkg
   GvXYIpwoWuREKsTOSrNayxLCJiBVnA=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.makeDefaultHeaders()
   GvXYIpwoWuREKsTOSrNayxLCJiBVnd=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.callRequestCookies('Get',GvXYIpwoWuREKsTOSrNayxLCJiBVnc,payload=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,params=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,headers=GvXYIpwoWuREKsTOSrNayxLCJiBVnA,cookies=GvXYIpwoWuREKsTOSrNayxLCJiBVqM)
   GvXYIpwoWuREKsTOSrNayxLCJiBVfn=json.loads(GvXYIpwoWuREKsTOSrNayxLCJiBVnd.text)
   GvXYIpwoWuREKsTOSrNayxLCJiBVen(GvXYIpwoWuREKsTOSrNayxLCJiBVnc)
   if mediatype=='live':
    GvXYIpwoWuREKsTOSrNayxLCJiBVze=GvXYIpwoWuREKsTOSrNayxLCJiBVfn['hlsUrl2']or GvXYIpwoWuREKsTOSrNayxLCJiBVfn['hlsUrl']
   else:
    GvXYIpwoWuREKsTOSrNayxLCJiBVen(GvXYIpwoWuREKsTOSrNayxLCJiBVfn)
    GvXYIpwoWuREKsTOSrNayxLCJiBVze=GvXYIpwoWuREKsTOSrNayxLCJiBVfn['sources'][0]['src']
   GvXYIpwoWuREKsTOSrNayxLCJiBVze=GvXYIpwoWuREKsTOSrNayxLCJiBVze.replace('http://','https://')
  except GvXYIpwoWuREKsTOSrNayxLCJiBVqh as exception:
   GvXYIpwoWuREKsTOSrNayxLCJiBVen(exception)
  return GvXYIpwoWuREKsTOSrNayxLCJiBVze
 def GetTitleGroupList(GvXYIpwoWuREKsTOSrNayxLCJiBVnz):
  GvXYIpwoWuREKsTOSrNayxLCJiBVfd=[]
  GvXYIpwoWuREKsTOSrNayxLCJiBVnc=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.API_DOMAIN+'/api/v3/home/web'
  GvXYIpwoWuREKsTOSrNayxLCJiBVnd=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.callRequestCookies('Get',GvXYIpwoWuREKsTOSrNayxLCJiBVnc,payload=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,params=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,headers=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,cookies=GvXYIpwoWuREKsTOSrNayxLCJiBVqM)
  GvXYIpwoWuREKsTOSrNayxLCJiBVfe=json.loads(GvXYIpwoWuREKsTOSrNayxLCJiBVnd.text)
  for GvXYIpwoWuREKsTOSrNayxLCJiBVfg in GvXYIpwoWuREKsTOSrNayxLCJiBVfe:
   if GvXYIpwoWuREKsTOSrNayxLCJiBVqd(GvXYIpwoWuREKsTOSrNayxLCJiBVfg['type'])=='3':
    GvXYIpwoWuREKsTOSrNayxLCJiBVzm=''
    for GvXYIpwoWuREKsTOSrNayxLCJiBVzP in GvXYIpwoWuREKsTOSrNayxLCJiBVfg['data']['list']:
     GvXYIpwoWuREKsTOSrNayxLCJiBVzQ='[%s] %s vs %s\n<%s>\n\n'%(GvXYIpwoWuREKsTOSrNayxLCJiBVzP['gameDesc']['roundName'],GvXYIpwoWuREKsTOSrNayxLCJiBVzP['gameDesc']['homeNameShort'],GvXYIpwoWuREKsTOSrNayxLCJiBVzP['gameDesc']['awayNameShort'],GvXYIpwoWuREKsTOSrNayxLCJiBVzP['gameDesc']['beginDate'])
     GvXYIpwoWuREKsTOSrNayxLCJiBVzm+=GvXYIpwoWuREKsTOSrNayxLCJiBVzQ
    GvXYIpwoWuREKsTOSrNayxLCJiBVft={'title':GvXYIpwoWuREKsTOSrNayxLCJiBVfg['title'],'logo':GvXYIpwoWuREKsTOSrNayxLCJiBVfg['logo'],'reagueId':GvXYIpwoWuREKsTOSrNayxLCJiBVqd(GvXYIpwoWuREKsTOSrNayxLCJiBVfg['destId']),'subGame':GvXYIpwoWuREKsTOSrNayxLCJiBVzm,}
    GvXYIpwoWuREKsTOSrNayxLCJiBVfd.append(GvXYIpwoWuREKsTOSrNayxLCJiBVft)
  return GvXYIpwoWuREKsTOSrNayxLCJiBVfd
 def GetPopularGroupList(GvXYIpwoWuREKsTOSrNayxLCJiBVnz):
  GvXYIpwoWuREKsTOSrNayxLCJiBVfd=[]
  GvXYIpwoWuREKsTOSrNayxLCJiBVnc=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.API_DOMAIN+'/api/v3/home/web'
  GvXYIpwoWuREKsTOSrNayxLCJiBVnd=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.callRequestCookies('Get',GvXYIpwoWuREKsTOSrNayxLCJiBVnc,payload=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,params=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,headers=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,cookies=GvXYIpwoWuREKsTOSrNayxLCJiBVqM)
  GvXYIpwoWuREKsTOSrNayxLCJiBVfe=json.loads(GvXYIpwoWuREKsTOSrNayxLCJiBVnd.text)
  for GvXYIpwoWuREKsTOSrNayxLCJiBVfg in GvXYIpwoWuREKsTOSrNayxLCJiBVfe:
   if GvXYIpwoWuREKsTOSrNayxLCJiBVqd(GvXYIpwoWuREKsTOSrNayxLCJiBVfg['type'])=='1' and GvXYIpwoWuREKsTOSrNayxLCJiBVqd(GvXYIpwoWuREKsTOSrNayxLCJiBVfg['destId'])=='4':
    for GvXYIpwoWuREKsTOSrNayxLCJiBVzP in GvXYIpwoWuREKsTOSrNayxLCJiBVfg['data']['list']:
     GvXYIpwoWuREKsTOSrNayxLCJiBVzb =GvXYIpwoWuREKsTOSrNayxLCJiBVzP['title']
     GvXYIpwoWuREKsTOSrNayxLCJiBVzD =GvXYIpwoWuREKsTOSrNayxLCJiBVzP['id']
     GvXYIpwoWuREKsTOSrNayxLCJiBVzl =GvXYIpwoWuREKsTOSrNayxLCJiBVzP['vtype']
     GvXYIpwoWuREKsTOSrNayxLCJiBVzF =GvXYIpwoWuREKsTOSrNayxLCJiBVzP['imgUrl']
     GvXYIpwoWuREKsTOSrNayxLCJiBVzU =GvXYIpwoWuREKsTOSrNayxLCJiBVzP['vtypeId']
     GvXYIpwoWuREKsTOSrNayxLCJiBVft={'vodTitle':GvXYIpwoWuREKsTOSrNayxLCJiBVzb,'vodId':GvXYIpwoWuREKsTOSrNayxLCJiBVzD,'vodType':GvXYIpwoWuREKsTOSrNayxLCJiBVzl,'thumbnail':GvXYIpwoWuREKsTOSrNayxLCJiBVzF,'vtypeId':GvXYIpwoWuREKsTOSrNayxLCJiBVqd(GvXYIpwoWuREKsTOSrNayxLCJiBVzU),'duration':GvXYIpwoWuREKsTOSrNayxLCJiBVqt(GvXYIpwoWuREKsTOSrNayxLCJiBVzP['duration']/1000),}
     GvXYIpwoWuREKsTOSrNayxLCJiBVfd.append(GvXYIpwoWuREKsTOSrNayxLCJiBVft)
  return GvXYIpwoWuREKsTOSrNayxLCJiBVfd
 def Get_NowVod_GroupList(GvXYIpwoWuREKsTOSrNayxLCJiBVnz,page_int):
  GvXYIpwoWuREKsTOSrNayxLCJiBVfd=[]
  GvXYIpwoWuREKsTOSrNayxLCJiBVzA=GvXYIpwoWuREKsTOSrNayxLCJiBVqc
  GvXYIpwoWuREKsTOSrNayxLCJiBVnc=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.API_DOMAIN+'/api/v3/theme/14/list'
  GvXYIpwoWuREKsTOSrNayxLCJiBVzj={'pageItem':'10','pageNo':GvXYIpwoWuREKsTOSrNayxLCJiBVqd(page_int)}
  GvXYIpwoWuREKsTOSrNayxLCJiBVnd=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.callRequestCookies('Get',GvXYIpwoWuREKsTOSrNayxLCJiBVnc,payload=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,params=GvXYIpwoWuREKsTOSrNayxLCJiBVzj,headers=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,cookies=GvXYIpwoWuREKsTOSrNayxLCJiBVqM)
  GvXYIpwoWuREKsTOSrNayxLCJiBVfe=json.loads(GvXYIpwoWuREKsTOSrNayxLCJiBVnd.text)
  for GvXYIpwoWuREKsTOSrNayxLCJiBVfg in GvXYIpwoWuREKsTOSrNayxLCJiBVfe['list']:
   GvXYIpwoWuREKsTOSrNayxLCJiBVzb =GvXYIpwoWuREKsTOSrNayxLCJiBVfg['title']
   GvXYIpwoWuREKsTOSrNayxLCJiBVzD =GvXYIpwoWuREKsTOSrNayxLCJiBVfg['id']
   GvXYIpwoWuREKsTOSrNayxLCJiBVzl =GvXYIpwoWuREKsTOSrNayxLCJiBVfg['vtype']
   GvXYIpwoWuREKsTOSrNayxLCJiBVzF =GvXYIpwoWuREKsTOSrNayxLCJiBVfg['imgUrl']
   GvXYIpwoWuREKsTOSrNayxLCJiBVzU =GvXYIpwoWuREKsTOSrNayxLCJiBVfg['vtypeId']
   GvXYIpwoWuREKsTOSrNayxLCJiBVft={'vodTitle':GvXYIpwoWuREKsTOSrNayxLCJiBVzb,'vodId':GvXYIpwoWuREKsTOSrNayxLCJiBVzD,'vodType':GvXYIpwoWuREKsTOSrNayxLCJiBVzl,'thumbnail':GvXYIpwoWuREKsTOSrNayxLCJiBVzF,'vtypeId':GvXYIpwoWuREKsTOSrNayxLCJiBVqd(GvXYIpwoWuREKsTOSrNayxLCJiBVzU),'duration':GvXYIpwoWuREKsTOSrNayxLCJiBVqt(GvXYIpwoWuREKsTOSrNayxLCJiBVfg['duration']/1000),}
   GvXYIpwoWuREKsTOSrNayxLCJiBVfd.append(GvXYIpwoWuREKsTOSrNayxLCJiBVft)
   if GvXYIpwoWuREKsTOSrNayxLCJiBVfe['count']>page_int*GvXYIpwoWuREKsTOSrNayxLCJiBVnz.GAMELIST_LIMIT:GvXYIpwoWuREKsTOSrNayxLCJiBVzA=GvXYIpwoWuREKsTOSrNayxLCJiBVqg
  return GvXYIpwoWuREKsTOSrNayxLCJiBVfd,GvXYIpwoWuREKsTOSrNayxLCJiBVzA
 def GetSeasonList(GvXYIpwoWuREKsTOSrNayxLCJiBVnz,leagueId):
  GvXYIpwoWuREKsTOSrNayxLCJiBVfd=[]
  GvXYIpwoWuREKsTOSrNayxLCJiBVzM=GvXYIpwoWuREKsTOSrNayxLCJiBVzc=''
  try:
   GvXYIpwoWuREKsTOSrNayxLCJiBVnc=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.API_DOMAIN+'/api/v3/game/league/'+leagueId
   GvXYIpwoWuREKsTOSrNayxLCJiBVnd=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.callRequestCookies('Get',GvXYIpwoWuREKsTOSrNayxLCJiBVnc,payload=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,params=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,headers=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,cookies=GvXYIpwoWuREKsTOSrNayxLCJiBVqM)
   GvXYIpwoWuREKsTOSrNayxLCJiBVfe=json.loads(GvXYIpwoWuREKsTOSrNayxLCJiBVnd.text)
   GvXYIpwoWuREKsTOSrNayxLCJiBVzM=GvXYIpwoWuREKsTOSrNayxLCJiBVfe['name']
   GvXYIpwoWuREKsTOSrNayxLCJiBVzc=GvXYIpwoWuREKsTOSrNayxLCJiBVqd(GvXYIpwoWuREKsTOSrNayxLCJiBVfe['gameTypeId'])
  except GvXYIpwoWuREKsTOSrNayxLCJiBVqh as exception:
   GvXYIpwoWuREKsTOSrNayxLCJiBVen(exception)
   return GvXYIpwoWuREKsTOSrNayxLCJiBVfd
  if GvXYIpwoWuREKsTOSrNayxLCJiBVzc in['2','5','6','8']:
   try:
    GvXYIpwoWuREKsTOSrNayxLCJiBVnc=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.API_DOMAIN+'/api/v3/year/'+leagueId
    GvXYIpwoWuREKsTOSrNayxLCJiBVnd=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.callRequestCookies('Get',GvXYIpwoWuREKsTOSrNayxLCJiBVnc,payload=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,params=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,headers=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,cookies=GvXYIpwoWuREKsTOSrNayxLCJiBVqM)
    GvXYIpwoWuREKsTOSrNayxLCJiBVfe=json.loads(GvXYIpwoWuREKsTOSrNayxLCJiBVnd.text)
    for GvXYIpwoWuREKsTOSrNayxLCJiBVfg in GvXYIpwoWuREKsTOSrNayxLCJiBVfe:
     GvXYIpwoWuREKsTOSrNayxLCJiBVft={'reagueName':GvXYIpwoWuREKsTOSrNayxLCJiBVzM,'gameTypeId':GvXYIpwoWuREKsTOSrNayxLCJiBVzc,'seasonName':GvXYIpwoWuREKsTOSrNayxLCJiBVqd(GvXYIpwoWuREKsTOSrNayxLCJiBVfg),'seasonId':GvXYIpwoWuREKsTOSrNayxLCJiBVqd(GvXYIpwoWuREKsTOSrNayxLCJiBVfg)}
     GvXYIpwoWuREKsTOSrNayxLCJiBVfd.append(GvXYIpwoWuREKsTOSrNayxLCJiBVft)
   except GvXYIpwoWuREKsTOSrNayxLCJiBVqh as exception:
    GvXYIpwoWuREKsTOSrNayxLCJiBVen(exception)
    return[]
  else:
   try:
    GvXYIpwoWuREKsTOSrNayxLCJiBVnc=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.API_DOMAIN+'/api/v3/season/'+leagueId
    GvXYIpwoWuREKsTOSrNayxLCJiBVnd=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.callRequestCookies('Get',GvXYIpwoWuREKsTOSrNayxLCJiBVnc,payload=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,params=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,headers=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,cookies=GvXYIpwoWuREKsTOSrNayxLCJiBVqM)
    GvXYIpwoWuREKsTOSrNayxLCJiBVfe=json.loads(GvXYIpwoWuREKsTOSrNayxLCJiBVnd.text)
    for GvXYIpwoWuREKsTOSrNayxLCJiBVfg in GvXYIpwoWuREKsTOSrNayxLCJiBVfe:
     GvXYIpwoWuREKsTOSrNayxLCJiBVft={'reagueName':GvXYIpwoWuREKsTOSrNayxLCJiBVzM,'gameTypeId':GvXYIpwoWuREKsTOSrNayxLCJiBVzc,'seasonName':GvXYIpwoWuREKsTOSrNayxLCJiBVfg['name'],'seasonId':GvXYIpwoWuREKsTOSrNayxLCJiBVqd(GvXYIpwoWuREKsTOSrNayxLCJiBVfg['id'])}
     GvXYIpwoWuREKsTOSrNayxLCJiBVfd.append(GvXYIpwoWuREKsTOSrNayxLCJiBVft)
   except GvXYIpwoWuREKsTOSrNayxLCJiBVqh as exception:
    GvXYIpwoWuREKsTOSrNayxLCJiBVen(exception)
    return[]
  return GvXYIpwoWuREKsTOSrNayxLCJiBVfd
 def GetGameList(GvXYIpwoWuREKsTOSrNayxLCJiBVnz,GvXYIpwoWuREKsTOSrNayxLCJiBVzc,leagueId,seasonId,page_int,hidescore=GvXYIpwoWuREKsTOSrNayxLCJiBVqg):
  GvXYIpwoWuREKsTOSrNayxLCJiBVfd=[]
  GvXYIpwoWuREKsTOSrNayxLCJiBVzA=GvXYIpwoWuREKsTOSrNayxLCJiBVqc
  try:
   GvXYIpwoWuREKsTOSrNayxLCJiBVnc=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.API_DOMAIN+'/api/v3/vod/league/detail'
   GvXYIpwoWuREKsTOSrNayxLCJiBVzj={'gameType':GvXYIpwoWuREKsTOSrNayxLCJiBVzc,'leagueId':leagueId,'seasonId':seasonId if GvXYIpwoWuREKsTOSrNayxLCJiBVzc not in['2','5','6','8']else '','teamId':'','roundId':'','year':'' if GvXYIpwoWuREKsTOSrNayxLCJiBVzc not in['2','5','6','8']else seasonId,'pageNo':GvXYIpwoWuREKsTOSrNayxLCJiBVqd(page_int)}
   GvXYIpwoWuREKsTOSrNayxLCJiBVnd=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.callRequestCookies('Get',GvXYIpwoWuREKsTOSrNayxLCJiBVnc,payload=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,params=GvXYIpwoWuREKsTOSrNayxLCJiBVzj,headers=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,cookies=GvXYIpwoWuREKsTOSrNayxLCJiBVqM)
   GvXYIpwoWuREKsTOSrNayxLCJiBVfe=json.loads(GvXYIpwoWuREKsTOSrNayxLCJiBVnd.text)
   GvXYIpwoWuREKsTOSrNayxLCJiBVkd=GvXYIpwoWuREKsTOSrNayxLCJiBVfe['list']
   for GvXYIpwoWuREKsTOSrNayxLCJiBVzd in GvXYIpwoWuREKsTOSrNayxLCJiBVkd:
    for GvXYIpwoWuREKsTOSrNayxLCJiBVfg in GvXYIpwoWuREKsTOSrNayxLCJiBVzd['list']:
     if GvXYIpwoWuREKsTOSrNayxLCJiBVfg['gameDesc']['title']==GvXYIpwoWuREKsTOSrNayxLCJiBVqM or GvXYIpwoWuREKsTOSrNayxLCJiBVfg['gameDesc']['title']=='':
      GvXYIpwoWuREKsTOSrNayxLCJiBVkH ='%s vs %s'%(GvXYIpwoWuREKsTOSrNayxLCJiBVfg['gameDesc']['homeNameShort'],GvXYIpwoWuREKsTOSrNayxLCJiBVfg['gameDesc']['awayNameShort'])
     else:
      GvXYIpwoWuREKsTOSrNayxLCJiBVkH =GvXYIpwoWuREKsTOSrNayxLCJiBVfg['gameDesc']['title']
     GvXYIpwoWuREKsTOSrNayxLCJiBVzH =GvXYIpwoWuREKsTOSrNayxLCJiBVfg['gameDesc']['beginDate']
     GvXYIpwoWuREKsTOSrNayxLCJiBVzg =GvXYIpwoWuREKsTOSrNayxLCJiBVfg['gameDesc']['id']
     GvXYIpwoWuREKsTOSrNayxLCJiBVzt =GvXYIpwoWuREKsTOSrNayxLCJiBVfg['gameDesc']['leagueNameFull']
     GvXYIpwoWuREKsTOSrNayxLCJiBVzh =GvXYIpwoWuREKsTOSrNayxLCJiBVfg['gameDesc']['seasonName']
     GvXYIpwoWuREKsTOSrNayxLCJiBVqn =GvXYIpwoWuREKsTOSrNayxLCJiBVfg['gameDesc']['roundName']
     GvXYIpwoWuREKsTOSrNayxLCJiBVqf =GvXYIpwoWuREKsTOSrNayxLCJiBVfg['gameDesc']['homeName']
     GvXYIpwoWuREKsTOSrNayxLCJiBVqk =GvXYIpwoWuREKsTOSrNayxLCJiBVfg['gameDesc']['awayName']
     GvXYIpwoWuREKsTOSrNayxLCJiBVqz =GvXYIpwoWuREKsTOSrNayxLCJiBVfg['gameDesc']['homeScore']
     GvXYIpwoWuREKsTOSrNayxLCJiBVqe =GvXYIpwoWuREKsTOSrNayxLCJiBVfg['gameDesc']['awayScore']
     if hidescore==GvXYIpwoWuREKsTOSrNayxLCJiBVqg:
      GvXYIpwoWuREKsTOSrNayxLCJiBVqm ='%s\n - %s (%s)\n - %s\n\nhome : %s\n\naway : %s'%(GvXYIpwoWuREKsTOSrNayxLCJiBVzt,GvXYIpwoWuREKsTOSrNayxLCJiBVzh,GvXYIpwoWuREKsTOSrNayxLCJiBVqn,GvXYIpwoWuREKsTOSrNayxLCJiBVzH,GvXYIpwoWuREKsTOSrNayxLCJiBVqf,GvXYIpwoWuREKsTOSrNayxLCJiBVqk)
     else:
      GvXYIpwoWuREKsTOSrNayxLCJiBVqm ='%s\n - %s (%s)\n - %s\n\nhome : %s (Score %s)\n\naway : %s (Score %s)'%(GvXYIpwoWuREKsTOSrNayxLCJiBVzt,GvXYIpwoWuREKsTOSrNayxLCJiBVzh,GvXYIpwoWuREKsTOSrNayxLCJiBVqn,GvXYIpwoWuREKsTOSrNayxLCJiBVzH,GvXYIpwoWuREKsTOSrNayxLCJiBVqf,GvXYIpwoWuREKsTOSrNayxLCJiBVqz,GvXYIpwoWuREKsTOSrNayxLCJiBVqk,GvXYIpwoWuREKsTOSrNayxLCJiBVqe)
     GvXYIpwoWuREKsTOSrNayxLCJiBVqP=GvXYIpwoWuREKsTOSrNayxLCJiBVqm
     GvXYIpwoWuREKsTOSrNayxLCJiBVqQ =GvXYIpwoWuREKsTOSrNayxLCJiBVfg['replayVod']['count']
     GvXYIpwoWuREKsTOSrNayxLCJiBVqb=GvXYIpwoWuREKsTOSrNayxLCJiBVfg['highlightVod']['count']
     GvXYIpwoWuREKsTOSrNayxLCJiBVqD =GvXYIpwoWuREKsTOSrNayxLCJiBVfg['vods']['count']
     GvXYIpwoWuREKsTOSrNayxLCJiBVzF='' 
     GvXYIpwoWuREKsTOSrNayxLCJiBVql=GvXYIpwoWuREKsTOSrNayxLCJiBVqQ+GvXYIpwoWuREKsTOSrNayxLCJiBVqb+GvXYIpwoWuREKsTOSrNayxLCJiBVqD
     if GvXYIpwoWuREKsTOSrNayxLCJiBVql==0:
      if GvXYIpwoWuREKsTOSrNayxLCJiBVzc=='2':
       GvXYIpwoWuREKsTOSrNayxLCJiBVkH='----- %s -----'%(GvXYIpwoWuREKsTOSrNayxLCJiBVzh)
       GvXYIpwoWuREKsTOSrNayxLCJiBVzH=''
      else:
       GvXYIpwoWuREKsTOSrNayxLCJiBVkH+=' - 관련영상 없음'
       GvXYIpwoWuREKsTOSrNayxLCJiBVqP+='\n\n ** 관련영상 없음 **'
     else:
      if GvXYIpwoWuREKsTOSrNayxLCJiBVqQ!=0:
       GvXYIpwoWuREKsTOSrNayxLCJiBVzF =GvXYIpwoWuREKsTOSrNayxLCJiBVfg['replayVod']['list'][0]['imgUrl']
      elif GvXYIpwoWuREKsTOSrNayxLCJiBVqb!=0:
       GvXYIpwoWuREKsTOSrNayxLCJiBVzF =GvXYIpwoWuREKsTOSrNayxLCJiBVfg['highlightVod']['list'][0]['imgUrl']
      else:
       GvXYIpwoWuREKsTOSrNayxLCJiBVzF =GvXYIpwoWuREKsTOSrNayxLCJiBVfg['vods']['list'][0]['imgUrl']
     GvXYIpwoWuREKsTOSrNayxLCJiBVft={'gameTitle':GvXYIpwoWuREKsTOSrNayxLCJiBVkH,'gameId':GvXYIpwoWuREKsTOSrNayxLCJiBVzg,'beginDate':GvXYIpwoWuREKsTOSrNayxLCJiBVzH[:11],'thumbnail':GvXYIpwoWuREKsTOSrNayxLCJiBVzF,'info_plot':GvXYIpwoWuREKsTOSrNayxLCJiBVqP,'leaguenm':GvXYIpwoWuREKsTOSrNayxLCJiBVzt,'seasonnm':GvXYIpwoWuREKsTOSrNayxLCJiBVzh,'roundnm':GvXYIpwoWuREKsTOSrNayxLCJiBVqn,'totVodCnt':GvXYIpwoWuREKsTOSrNayxLCJiBVql}
     GvXYIpwoWuREKsTOSrNayxLCJiBVfd.append(GvXYIpwoWuREKsTOSrNayxLCJiBVft)
  except GvXYIpwoWuREKsTOSrNayxLCJiBVqh as exception:
   GvXYIpwoWuREKsTOSrNayxLCJiBVen(exception)
  if GvXYIpwoWuREKsTOSrNayxLCJiBVfe['count']>page_int*GvXYIpwoWuREKsTOSrNayxLCJiBVnz.GAMELIST_LIMIT:GvXYIpwoWuREKsTOSrNayxLCJiBVzA=GvXYIpwoWuREKsTOSrNayxLCJiBVqg
  return GvXYIpwoWuREKsTOSrNayxLCJiBVfd,GvXYIpwoWuREKsTOSrNayxLCJiBVzA
 def GetGameVodList(GvXYIpwoWuREKsTOSrNayxLCJiBVnz,GvXYIpwoWuREKsTOSrNayxLCJiBVzg,vodCount=1000):
  GvXYIpwoWuREKsTOSrNayxLCJiBVfd=[]
  GvXYIpwoWuREKsTOSrNayxLCJiBVqF=''
  try:
   GvXYIpwoWuREKsTOSrNayxLCJiBVnc=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.API_DOMAIN+'/api/v3/vod/game'
   GvXYIpwoWuREKsTOSrNayxLCJiBVzj={'gameId':GvXYIpwoWuREKsTOSrNayxLCJiBVzg,'pageItem':GvXYIpwoWuREKsTOSrNayxLCJiBVqd(vodCount)}
   GvXYIpwoWuREKsTOSrNayxLCJiBVnd=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.callRequestCookies('Get',GvXYIpwoWuREKsTOSrNayxLCJiBVnc,payload=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,params=GvXYIpwoWuREKsTOSrNayxLCJiBVzj,headers=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,cookies=GvXYIpwoWuREKsTOSrNayxLCJiBVqM)
   GvXYIpwoWuREKsTOSrNayxLCJiBVfe=json.loads(GvXYIpwoWuREKsTOSrNayxLCJiBVnd.text)
   GvXYIpwoWuREKsTOSrNayxLCJiBVzd=GvXYIpwoWuREKsTOSrNayxLCJiBVfe['list']
   for GvXYIpwoWuREKsTOSrNayxLCJiBVfg in GvXYIpwoWuREKsTOSrNayxLCJiBVzd:
    GvXYIpwoWuREKsTOSrNayxLCJiBVzb =GvXYIpwoWuREKsTOSrNayxLCJiBVfg['title']
    GvXYIpwoWuREKsTOSrNayxLCJiBVzD =GvXYIpwoWuREKsTOSrNayxLCJiBVfg['id']
    GvXYIpwoWuREKsTOSrNayxLCJiBVzl =GvXYIpwoWuREKsTOSrNayxLCJiBVfg['vtype']
    GvXYIpwoWuREKsTOSrNayxLCJiBVzF =GvXYIpwoWuREKsTOSrNayxLCJiBVfg['imgUrl']
    GvXYIpwoWuREKsTOSrNayxLCJiBVzU =GvXYIpwoWuREKsTOSrNayxLCJiBVfg['vtypeId']
    GvXYIpwoWuREKsTOSrNayxLCJiBVqU =GvXYIpwoWuREKsTOSrNayxLCJiBVfg['isFree']
    GvXYIpwoWuREKsTOSrNayxLCJiBVft={'vodTitle':GvXYIpwoWuREKsTOSrNayxLCJiBVzb,'vodId':GvXYIpwoWuREKsTOSrNayxLCJiBVzD,'vodType':GvXYIpwoWuREKsTOSrNayxLCJiBVzl,'thumbnail':GvXYIpwoWuREKsTOSrNayxLCJiBVzF,'vtypeId':GvXYIpwoWuREKsTOSrNayxLCJiBVqd(GvXYIpwoWuREKsTOSrNayxLCJiBVzU),'duration':GvXYIpwoWuREKsTOSrNayxLCJiBVqt(GvXYIpwoWuREKsTOSrNayxLCJiBVfg['duration']/1000),'isFree':GvXYIpwoWuREKsTOSrNayxLCJiBVqU}
    GvXYIpwoWuREKsTOSrNayxLCJiBVfd.append(GvXYIpwoWuREKsTOSrNayxLCJiBVft)
  except GvXYIpwoWuREKsTOSrNayxLCJiBVqh as exception:
   GvXYIpwoWuREKsTOSrNayxLCJiBVen(exception)
  return GvXYIpwoWuREKsTOSrNayxLCJiBVfd
 def GetReplay_UrlId(GvXYIpwoWuREKsTOSrNayxLCJiBVnz,GvXYIpwoWuREKsTOSrNayxLCJiBVqF,GvXYIpwoWuREKsTOSrNayxLCJiBVzU):
  GvXYIpwoWuREKsTOSrNayxLCJiBVqA=''
  try:
   GvXYIpwoWuREKsTOSrNayxLCJiBVnc=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.API_DOMAIN+'/api/v3/vod/'+GvXYIpwoWuREKsTOSrNayxLCJiBVqF
   GvXYIpwoWuREKsTOSrNayxLCJiBVnd=GvXYIpwoWuREKsTOSrNayxLCJiBVnz.callRequestCookies('Get',GvXYIpwoWuREKsTOSrNayxLCJiBVnc,payload=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,params=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,headers=GvXYIpwoWuREKsTOSrNayxLCJiBVqM,cookies=GvXYIpwoWuREKsTOSrNayxLCJiBVqM)
   GvXYIpwoWuREKsTOSrNayxLCJiBVfe=json.loads(GvXYIpwoWuREKsTOSrNayxLCJiBVnd.text)
   GvXYIpwoWuREKsTOSrNayxLCJiBVqA=GvXYIpwoWuREKsTOSrNayxLCJiBVfe['videoId']
  except GvXYIpwoWuREKsTOSrNayxLCJiBVqh as exception:
   GvXYIpwoWuREKsTOSrNayxLCJiBVen(exception)
  return GvXYIpwoWuREKsTOSrNayxLCJiBVqA
# Created by pyminifier (https://github.com/liftoff/pyminifier)
