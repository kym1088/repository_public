__author__="NightRain"
FJPHBYyOIqeGhvgUnRfzDNaSXlMmpc=object
FJPHBYyOIqeGhvgUnRfzDNaSXlMmpd=None
FJPHBYyOIqeGhvgUnRfzDNaSXlMmpt=False
FJPHBYyOIqeGhvgUnRfzDNaSXlMmpw=True
FJPHBYyOIqeGhvgUnRfzDNaSXlMmpA=getattr
FJPHBYyOIqeGhvgUnRfzDNaSXlMmps=type
FJPHBYyOIqeGhvgUnRfzDNaSXlMmpx=int
FJPHBYyOIqeGhvgUnRfzDNaSXlMmpV=list
FJPHBYyOIqeGhvgUnRfzDNaSXlMmpE=len
FJPHBYyOIqeGhvgUnRfzDNaSXlMmpo=str
FJPHBYyOIqeGhvgUnRfzDNaSXlMmpu=id
FJPHBYyOIqeGhvgUnRfzDNaSXlMmpk=open
FJPHBYyOIqeGhvgUnRfzDNaSXlMmpK=dict
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
FJPHBYyOIqeGhvgUnRfzDNaSXlMmLb=[{'title':'TV 채널 (유료사용자만 지원)','mode':'LIVE_GROUP','icon':'live.png'},{'title':'Live중계 (경기중에만 재생)','mode':'ELIVE_GROUP','icon':'live.png'},{'title':'-----------------','mode':'XXX'},{'title':'오늘의 추천 VOD','mode':'NOW_GROUP'},{'title':'인기영상 5','mode':'POP_GROUP'},{'title':'-----------------','mode':'XXX'},{'title':'VOD (리그, 경기별)','mode':'VOD_GROUP'},{'title':'Watched (시청목록)','mode':'WATCH','icon':'history.png'},]
FJPHBYyOIqeGhvgUnRfzDNaSXlMmLT={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
FJPHBYyOIqeGhvgUnRfzDNaSXlMmLC=xbmcvfs.translatePath(os.path.join(__profile__,'spotv_cookies.json'))
from spotvCore import*
class FJPHBYyOIqeGhvgUnRfzDNaSXlMmLj(FJPHBYyOIqeGhvgUnRfzDNaSXlMmpc):
 def __init__(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp,FJPHBYyOIqeGhvgUnRfzDNaSXlMmLW,FJPHBYyOIqeGhvgUnRfzDNaSXlMmLQ,FJPHBYyOIqeGhvgUnRfzDNaSXlMmLc):
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp._addon_url =FJPHBYyOIqeGhvgUnRfzDNaSXlMmLW
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp._addon_handle=FJPHBYyOIqeGhvgUnRfzDNaSXlMmLQ
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.main_params =FJPHBYyOIqeGhvgUnRfzDNaSXlMmLc
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.SpotvObj =NJERvVGTwDhmoUrfFSyBadAWptCcIP() 
 def addon_noti(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp,sting):
  try:
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLt=xbmcgui.Dialog()
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLt.notification(__addonname__,sting)
  except:
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmpd
 def addon_log(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp,string):
  try:
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLw=string.encode('utf-8','ignore')
  except:
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLw='addonException: addon_log'
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmLA=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,FJPHBYyOIqeGhvgUnRfzDNaSXlMmLw),level=FJPHBYyOIqeGhvgUnRfzDNaSXlMmLA)
 def get_keyboard_input(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp,FJPHBYyOIqeGhvgUnRfzDNaSXlMmLu):
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmLs=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpd
  kb=xbmc.Keyboard()
  kb.setHeading(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLu)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLs=kb.getText()
  return FJPHBYyOIqeGhvgUnRfzDNaSXlMmLs
 def get_settings_account(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp):
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmLx =__addon__.getSetting('id')
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmLV =__addon__.getSetting('pw')
  return(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLx,FJPHBYyOIqeGhvgUnRfzDNaSXlMmLV)
 def get_settings_hidescoreyn(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp):
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmLE =__addon__.getSetting('hidescore')
  if FJPHBYyOIqeGhvgUnRfzDNaSXlMmLE=='false':
   return FJPHBYyOIqeGhvgUnRfzDNaSXlMmpt
  else:
   return FJPHBYyOIqeGhvgUnRfzDNaSXlMmpw
 def add_dir(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp,label,sublabel='',img='',infoLabels=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpd,isFolder=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpw,params='',isLink=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpt,ContextMenu=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpd):
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmLo='%s?%s'%(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp._addon_url,urllib.parse.urlencode(params))
  if sublabel:FJPHBYyOIqeGhvgUnRfzDNaSXlMmLu='%s < %s >'%(label,sublabel)
  else: FJPHBYyOIqeGhvgUnRfzDNaSXlMmLu=label
  if not img:img='DefaultFolder.png'
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmLk=xbmcgui.ListItem(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLu)
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmLk.setArt({'thumb':img,'icon':img,'poster':img})
  if FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.SpotvObj.KodiVersion>=20:
   if infoLabels:FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.Set_InfoTag(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLk.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:FJPHBYyOIqeGhvgUnRfzDNaSXlMmLk.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLk.setProperty('IsPlayable','true')
  if ContextMenu:FJPHBYyOIqeGhvgUnRfzDNaSXlMmLk.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp._addon_handle,FJPHBYyOIqeGhvgUnRfzDNaSXlMmLo,FJPHBYyOIqeGhvgUnRfzDNaSXlMmLk,isFolder)
 def Set_InfoTag(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp,video_InfoTag:xbmc.InfoTagVideo,FJPHBYyOIqeGhvgUnRfzDNaSXlMmjc):
  for FJPHBYyOIqeGhvgUnRfzDNaSXlMmLK,value in FJPHBYyOIqeGhvgUnRfzDNaSXlMmjc.items():
   if FJPHBYyOIqeGhvgUnRfzDNaSXlMmLT[FJPHBYyOIqeGhvgUnRfzDNaSXlMmLK]['type']=='string':
    FJPHBYyOIqeGhvgUnRfzDNaSXlMmpA(video_InfoTag,FJPHBYyOIqeGhvgUnRfzDNaSXlMmLT[FJPHBYyOIqeGhvgUnRfzDNaSXlMmLK]['func'])(value)
   elif FJPHBYyOIqeGhvgUnRfzDNaSXlMmLT[FJPHBYyOIqeGhvgUnRfzDNaSXlMmLK]['type']=='int':
    if FJPHBYyOIqeGhvgUnRfzDNaSXlMmps(value)==FJPHBYyOIqeGhvgUnRfzDNaSXlMmpx:
     FJPHBYyOIqeGhvgUnRfzDNaSXlMmLi=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpx(value)
    else:
     FJPHBYyOIqeGhvgUnRfzDNaSXlMmLi=0
    FJPHBYyOIqeGhvgUnRfzDNaSXlMmpA(video_InfoTag,FJPHBYyOIqeGhvgUnRfzDNaSXlMmLT[FJPHBYyOIqeGhvgUnRfzDNaSXlMmLK]['func'])(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLi)
   elif FJPHBYyOIqeGhvgUnRfzDNaSXlMmLT[FJPHBYyOIqeGhvgUnRfzDNaSXlMmLK]['type']=='actor':
    if value!=[]:
     FJPHBYyOIqeGhvgUnRfzDNaSXlMmpA(video_InfoTag,FJPHBYyOIqeGhvgUnRfzDNaSXlMmLT[FJPHBYyOIqeGhvgUnRfzDNaSXlMmLK]['func'])([xbmc.Actor(name)for name in value])
   elif FJPHBYyOIqeGhvgUnRfzDNaSXlMmLT[FJPHBYyOIqeGhvgUnRfzDNaSXlMmLK]['type']=='list':
    if FJPHBYyOIqeGhvgUnRfzDNaSXlMmps(value)==FJPHBYyOIqeGhvgUnRfzDNaSXlMmpV:
     FJPHBYyOIqeGhvgUnRfzDNaSXlMmpA(video_InfoTag,FJPHBYyOIqeGhvgUnRfzDNaSXlMmLT[FJPHBYyOIqeGhvgUnRfzDNaSXlMmLK]['func'])(value)
    else:
     FJPHBYyOIqeGhvgUnRfzDNaSXlMmpA(video_InfoTag,FJPHBYyOIqeGhvgUnRfzDNaSXlMmLT[FJPHBYyOIqeGhvgUnRfzDNaSXlMmLK]['func'])([value])
 def get_selQuality(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp,etype):
  try:
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLr='selected_quality'
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjL=[1080,720,540]
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjb=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpx(__addon__.getSetting(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLr))
   return FJPHBYyOIqeGhvgUnRfzDNaSXlMmjL[FJPHBYyOIqeGhvgUnRfzDNaSXlMmjb]
  except:
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmpd
  return 1080 
 def dp_Main_List(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp):
  for FJPHBYyOIqeGhvgUnRfzDNaSXlMmjT in FJPHBYyOIqeGhvgUnRfzDNaSXlMmLb:
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLu=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjT.get('title')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjC=''
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjp={'mode':FJPHBYyOIqeGhvgUnRfzDNaSXlMmjT.get('mode'),'page':'1'}
   if FJPHBYyOIqeGhvgUnRfzDNaSXlMmjT.get('mode')=='XXX':
    FJPHBYyOIqeGhvgUnRfzDNaSXlMmjW=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpt
    FJPHBYyOIqeGhvgUnRfzDNaSXlMmjQ =FJPHBYyOIqeGhvgUnRfzDNaSXlMmpw
   else:
    FJPHBYyOIqeGhvgUnRfzDNaSXlMmjW=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpw
    FJPHBYyOIqeGhvgUnRfzDNaSXlMmjQ =FJPHBYyOIqeGhvgUnRfzDNaSXlMmpt
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjc={'title':FJPHBYyOIqeGhvgUnRfzDNaSXlMmLu,'plot':FJPHBYyOIqeGhvgUnRfzDNaSXlMmLu}
   if FJPHBYyOIqeGhvgUnRfzDNaSXlMmjT.get('mode')=='XXX':FJPHBYyOIqeGhvgUnRfzDNaSXlMmjc=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpd
   if 'icon' in FJPHBYyOIqeGhvgUnRfzDNaSXlMmjT:FJPHBYyOIqeGhvgUnRfzDNaSXlMmjC=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',FJPHBYyOIqeGhvgUnRfzDNaSXlMmjT.get('icon')) 
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.add_dir(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLu,sublabel='',img=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjC,infoLabels=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjc,isFolder=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjW,params=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjp,isLink=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjQ)
  if FJPHBYyOIqeGhvgUnRfzDNaSXlMmpE(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLb)>0:xbmcplugin.endOfDirectory(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp._addon_handle,cacheToDisc=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpt)
 def dp_MainLeague_List(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp,args):
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.addon_log('dp_MainLeague_List')
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmjt=FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.SpotvObj.GetTitleGroupList()
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.addon_log('dp_MainLeague_List cnt : '+FJPHBYyOIqeGhvgUnRfzDNaSXlMmpo(FJPHBYyOIqeGhvgUnRfzDNaSXlMmpE(FJPHBYyOIqeGhvgUnRfzDNaSXlMmjt)))
  for FJPHBYyOIqeGhvgUnRfzDNaSXlMmjw in FJPHBYyOIqeGhvgUnRfzDNaSXlMmjt:
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLu =FJPHBYyOIqeGhvgUnRfzDNaSXlMmjw.get('title')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjA =FJPHBYyOIqeGhvgUnRfzDNaSXlMmjw.get('logo')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjs =FJPHBYyOIqeGhvgUnRfzDNaSXlMmjw.get('reagueId')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjx =FJPHBYyOIqeGhvgUnRfzDNaSXlMmjw.get('subGame')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjV={'mediatype':'episode','plot':'%s\n\n%s'%(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLu,FJPHBYyOIqeGhvgUnRfzDNaSXlMmjx)}
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjp={'mode':'LEAGUE_GROUP','reagueId':FJPHBYyOIqeGhvgUnRfzDNaSXlMmjs}
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.add_dir(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLu,sublabel=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpd,img=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjA,infoLabels=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjV,isFolder=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpw,params=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjp)
  if FJPHBYyOIqeGhvgUnRfzDNaSXlMmpE(FJPHBYyOIqeGhvgUnRfzDNaSXlMmjt)>0:xbmcplugin.endOfDirectory(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp._addon_handle,cacheToDisc=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpt)
 def dp_NowVod_GroupList(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp,args):
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmjE=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpx(args.get('page'))
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.addon_log('dp_NowVod_GroupList page : '+FJPHBYyOIqeGhvgUnRfzDNaSXlMmpo(FJPHBYyOIqeGhvgUnRfzDNaSXlMmjE))
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmjt,FJPHBYyOIqeGhvgUnRfzDNaSXlMmjo=FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.SpotvObj.Get_NowVod_GroupList(FJPHBYyOIqeGhvgUnRfzDNaSXlMmjE)
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.addon_log('dp_NowVod_GroupList cnt : '+FJPHBYyOIqeGhvgUnRfzDNaSXlMmpo(FJPHBYyOIqeGhvgUnRfzDNaSXlMmpE(FJPHBYyOIqeGhvgUnRfzDNaSXlMmjt)))
  for FJPHBYyOIqeGhvgUnRfzDNaSXlMmjw in FJPHBYyOIqeGhvgUnRfzDNaSXlMmjt:
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmju =FJPHBYyOIqeGhvgUnRfzDNaSXlMmjw.get('vodTitle')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjk =FJPHBYyOIqeGhvgUnRfzDNaSXlMmjw.get('vodId')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjK =FJPHBYyOIqeGhvgUnRfzDNaSXlMmjw.get('vodType')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjA=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjw.get('thumbnail')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmji =FJPHBYyOIqeGhvgUnRfzDNaSXlMmjw.get('vtypeId')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjr =FJPHBYyOIqeGhvgUnRfzDNaSXlMmjw.get('duration')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjV={'mediatype':'episode','duration':FJPHBYyOIqeGhvgUnRfzDNaSXlMmjr,'plot':FJPHBYyOIqeGhvgUnRfzDNaSXlMmju}
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjp={'mode':'NOW_VOD','mediacode':FJPHBYyOIqeGhvgUnRfzDNaSXlMmjk,'mediatype':'vod','vtypeId':FJPHBYyOIqeGhvgUnRfzDNaSXlMmji}
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.add_dir(FJPHBYyOIqeGhvgUnRfzDNaSXlMmju,sublabel=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjK,img=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjA,infoLabels=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjV,isFolder=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpt,params=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjp)
  if FJPHBYyOIqeGhvgUnRfzDNaSXlMmjo:
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjp['mode'] ='NOW_GROUP' 
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjp['page'] =FJPHBYyOIqeGhvgUnRfzDNaSXlMmpo(FJPHBYyOIqeGhvgUnRfzDNaSXlMmjE+1)
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLu='[B]%s >>[/B]'%'다음 페이지'
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmbL=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpo(FJPHBYyOIqeGhvgUnRfzDNaSXlMmjE+1)
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjC=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.add_dir(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLu,sublabel=FJPHBYyOIqeGhvgUnRfzDNaSXlMmbL,img=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjC,infoLabels=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpd,isFolder=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpw,params=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjp)
  xbmcplugin.setContent(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp._addon_handle,cacheToDisc=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpt)
 def dp_PopVod_GroupList(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp,args):
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.addon_log('dp_PopVod_GroupList ')
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmjt=FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.SpotvObj.GetPopularGroupList()
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.addon_log('dp_PopVod_GroupList cnt : '+FJPHBYyOIqeGhvgUnRfzDNaSXlMmpo(FJPHBYyOIqeGhvgUnRfzDNaSXlMmpE(FJPHBYyOIqeGhvgUnRfzDNaSXlMmjt)))
  for FJPHBYyOIqeGhvgUnRfzDNaSXlMmjw in FJPHBYyOIqeGhvgUnRfzDNaSXlMmjt:
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmju =FJPHBYyOIqeGhvgUnRfzDNaSXlMmjw.get('vodTitle')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjk =FJPHBYyOIqeGhvgUnRfzDNaSXlMmjw.get('vodId')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjK =FJPHBYyOIqeGhvgUnRfzDNaSXlMmjw.get('vodType')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjA=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjw.get('thumbnail')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmji =FJPHBYyOIqeGhvgUnRfzDNaSXlMmjw.get('vtypeId')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjr =FJPHBYyOIqeGhvgUnRfzDNaSXlMmjw.get('duration')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjV={'mediatype':'episode','duration':FJPHBYyOIqeGhvgUnRfzDNaSXlMmjr,'plot':FJPHBYyOIqeGhvgUnRfzDNaSXlMmju}
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjp={'mode':'POP_VOD','mediacode':FJPHBYyOIqeGhvgUnRfzDNaSXlMmjk,'mediatype':'vod','vtypeId':FJPHBYyOIqeGhvgUnRfzDNaSXlMmji}
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.add_dir(FJPHBYyOIqeGhvgUnRfzDNaSXlMmju,sublabel=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjK,img=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjA,infoLabels=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjV,isFolder=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpt,params=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjp)
  xbmcplugin.setContent(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp._addon_handle,cacheToDisc=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpt)
 def dp_Season_List(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp,args):
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmjs=args.get('reagueId')
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.addon_log('Season_List - reagueId : '+FJPHBYyOIqeGhvgUnRfzDNaSXlMmjs)
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmjt=FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.SpotvObj.GetSeasonList(FJPHBYyOIqeGhvgUnRfzDNaSXlMmjs)
  for FJPHBYyOIqeGhvgUnRfzDNaSXlMmjw in FJPHBYyOIqeGhvgUnRfzDNaSXlMmjt:
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmbT =FJPHBYyOIqeGhvgUnRfzDNaSXlMmjw.get('reagueName')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmbC =FJPHBYyOIqeGhvgUnRfzDNaSXlMmjw.get('gameTypeId')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmbp =FJPHBYyOIqeGhvgUnRfzDNaSXlMmjw.get('seasonName')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmbW =FJPHBYyOIqeGhvgUnRfzDNaSXlMmjw.get('seasonId')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjV={'mediatype':'episode','plot':'%s - %s'%(FJPHBYyOIqeGhvgUnRfzDNaSXlMmbT,FJPHBYyOIqeGhvgUnRfzDNaSXlMmbp)}
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjp={'mode':'SEASON_GROUP','reagueId':FJPHBYyOIqeGhvgUnRfzDNaSXlMmjs,'seasonId':FJPHBYyOIqeGhvgUnRfzDNaSXlMmbW,'gameTypeId':FJPHBYyOIqeGhvgUnRfzDNaSXlMmbC,'page':'1'}
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.add_dir(FJPHBYyOIqeGhvgUnRfzDNaSXlMmbT,sublabel=FJPHBYyOIqeGhvgUnRfzDNaSXlMmbp,img='',infoLabels=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjV,isFolder=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpw,params=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjp)
  if FJPHBYyOIqeGhvgUnRfzDNaSXlMmpE(FJPHBYyOIqeGhvgUnRfzDNaSXlMmjt)>0:xbmcplugin.endOfDirectory(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp._addon_handle,cacheToDisc=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpt)
 def dp_Game_List(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp,args):
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmbC=args.get('gameTypeId')
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmjs =args.get('reagueId')
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmbW =args.get('seasonId')
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmjE =FJPHBYyOIqeGhvgUnRfzDNaSXlMmpx(args.get('page'))
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.addon_log('Game_List - gameTypeId : '+FJPHBYyOIqeGhvgUnRfzDNaSXlMmbC)
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.addon_log('Game_List - reagueId   : '+FJPHBYyOIqeGhvgUnRfzDNaSXlMmjs)
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.addon_log('Game_List - seasonId   : '+FJPHBYyOIqeGhvgUnRfzDNaSXlMmbW)
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmjt,FJPHBYyOIqeGhvgUnRfzDNaSXlMmjo=FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.SpotvObj.GetGameList(FJPHBYyOIqeGhvgUnRfzDNaSXlMmbC,FJPHBYyOIqeGhvgUnRfzDNaSXlMmjs,FJPHBYyOIqeGhvgUnRfzDNaSXlMmbW,FJPHBYyOIqeGhvgUnRfzDNaSXlMmjE,hidescore=FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.get_settings_hidescoreyn())
  for FJPHBYyOIqeGhvgUnRfzDNaSXlMmjw in FJPHBYyOIqeGhvgUnRfzDNaSXlMmjt:
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmbQ =FJPHBYyOIqeGhvgUnRfzDNaSXlMmjw.get('gameTitle')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmbc =FJPHBYyOIqeGhvgUnRfzDNaSXlMmjw.get('beginDate')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjA =FJPHBYyOIqeGhvgUnRfzDNaSXlMmjw.get('thumbnail')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmbd =FJPHBYyOIqeGhvgUnRfzDNaSXlMmjw.get('gameId')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmbt =FJPHBYyOIqeGhvgUnRfzDNaSXlMmjw.get('totVodCnt')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmbw =FJPHBYyOIqeGhvgUnRfzDNaSXlMmjw.get('leaguenm')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmbA =FJPHBYyOIqeGhvgUnRfzDNaSXlMmjw.get('seasonnm')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmbs =FJPHBYyOIqeGhvgUnRfzDNaSXlMmjw.get('roundnm')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmbx =FJPHBYyOIqeGhvgUnRfzDNaSXlMmjw.get('info_plot')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmbV ='%s < %s >'%(FJPHBYyOIqeGhvgUnRfzDNaSXlMmbQ,FJPHBYyOIqeGhvgUnRfzDNaSXlMmbc)
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjV={'mediatype':'video','plot':FJPHBYyOIqeGhvgUnRfzDNaSXlMmbx}
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjp={'mode':'GAME_VOD_GROUP' if FJPHBYyOIqeGhvgUnRfzDNaSXlMmbt!=0 else 'XXX','saveTitle':FJPHBYyOIqeGhvgUnRfzDNaSXlMmbV,'saveImg':FJPHBYyOIqeGhvgUnRfzDNaSXlMmjA,'saveInfo':FJPHBYyOIqeGhvgUnRfzDNaSXlMmjV['plot'],'gameid':FJPHBYyOIqeGhvgUnRfzDNaSXlMmbd,'totVodCnt':FJPHBYyOIqeGhvgUnRfzDNaSXlMmbt,}
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.add_dir(FJPHBYyOIqeGhvgUnRfzDNaSXlMmbQ,sublabel=FJPHBYyOIqeGhvgUnRfzDNaSXlMmbc,img=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjA,infoLabels=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjV,isFolder=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpw,params=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjp)
  if FJPHBYyOIqeGhvgUnRfzDNaSXlMmjo:
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjp['mode'] ='SEASON_GROUP' 
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjp['reagueId'] =FJPHBYyOIqeGhvgUnRfzDNaSXlMmjs
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjp['seasonId'] =FJPHBYyOIqeGhvgUnRfzDNaSXlMmbW
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjp['gameTypeId']=FJPHBYyOIqeGhvgUnRfzDNaSXlMmbC
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjp['page'] =FJPHBYyOIqeGhvgUnRfzDNaSXlMmpo(FJPHBYyOIqeGhvgUnRfzDNaSXlMmjE+1)
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLu='[B]%s >>[/B]'%'다음 페이지'
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmbL=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpo(FJPHBYyOIqeGhvgUnRfzDNaSXlMmjE+1)
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjC=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.add_dir(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLu,sublabel=FJPHBYyOIqeGhvgUnRfzDNaSXlMmbL,img=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjC,infoLabels=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpd,isFolder=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpw,params=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjp)
  if FJPHBYyOIqeGhvgUnRfzDNaSXlMmpE(FJPHBYyOIqeGhvgUnRfzDNaSXlMmjt)>0:xbmcplugin.endOfDirectory(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp._addon_handle,cacheToDisc=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpt)
 def dp_GameVod_List(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp,args):
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmbE =args.get('gameid')
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmbV=args.get('saveTitle')
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmbo =args.get('saveImg')
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmbu =args.get('saveInfo')
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmjt=FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.SpotvObj.GetGameVodList(FJPHBYyOIqeGhvgUnRfzDNaSXlMmbE)
  for FJPHBYyOIqeGhvgUnRfzDNaSXlMmjw in FJPHBYyOIqeGhvgUnRfzDNaSXlMmjt:
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmju =FJPHBYyOIqeGhvgUnRfzDNaSXlMmjw.get('vodTitle')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjk =FJPHBYyOIqeGhvgUnRfzDNaSXlMmjw.get('vodId')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjK =FJPHBYyOIqeGhvgUnRfzDNaSXlMmjw.get('vodType')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjA=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjw.get('thumbnail')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmji =FJPHBYyOIqeGhvgUnRfzDNaSXlMmjw.get('vtypeId')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjr =FJPHBYyOIqeGhvgUnRfzDNaSXlMmjw.get('duration')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjV={'mediatype':'episode','duration':FJPHBYyOIqeGhvgUnRfzDNaSXlMmjr,'plot':'%s \n\n %s'%(FJPHBYyOIqeGhvgUnRfzDNaSXlMmju,FJPHBYyOIqeGhvgUnRfzDNaSXlMmbu)}
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjp={'mode':'GAME_VOD','saveTitle':FJPHBYyOIqeGhvgUnRfzDNaSXlMmbV,'saveImg':FJPHBYyOIqeGhvgUnRfzDNaSXlMmbo,'saveId':FJPHBYyOIqeGhvgUnRfzDNaSXlMmbE,'saveInfo':FJPHBYyOIqeGhvgUnRfzDNaSXlMmbu,'mediacode':FJPHBYyOIqeGhvgUnRfzDNaSXlMmjk,'mediatype':'vod','vtypeId':FJPHBYyOIqeGhvgUnRfzDNaSXlMmji}
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.add_dir(FJPHBYyOIqeGhvgUnRfzDNaSXlMmju,sublabel=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjK,img=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjA,infoLabels=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjV,isFolder=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpt,params=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjp)
  xbmcplugin.setContent(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp._addon_handle,cacheToDisc=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpt)
 def login_main(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp):
  (FJPHBYyOIqeGhvgUnRfzDNaSXlMmbk,FJPHBYyOIqeGhvgUnRfzDNaSXlMmbK)=FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.get_settings_account()
  if not(FJPHBYyOIqeGhvgUnRfzDNaSXlMmbk and FJPHBYyOIqeGhvgUnRfzDNaSXlMmbK):
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLt=xbmcgui.Dialog()
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmbi=FJPHBYyOIqeGhvgUnRfzDNaSXlMmLt.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if FJPHBYyOIqeGhvgUnRfzDNaSXlMmbi==FJPHBYyOIqeGhvgUnRfzDNaSXlMmpw:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.cookiefile_check():return
  if xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINWAIT')=='TRUE':
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmbr=0
   while FJPHBYyOIqeGhvgUnRfzDNaSXlMmpw:
    FJPHBYyOIqeGhvgUnRfzDNaSXlMmbr+=1
    time.sleep(0.05)
    if FJPHBYyOIqeGhvgUnRfzDNaSXlMmbr>600:return
  else:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','TRUE')
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmTL=FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.SpotvObj.GetCredential_new(FJPHBYyOIqeGhvgUnRfzDNaSXlMmbk,FJPHBYyOIqeGhvgUnRfzDNaSXlMmbK)
  if FJPHBYyOIqeGhvgUnRfzDNaSXlMmTL:FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.cookiefile_save()
  xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
  if FJPHBYyOIqeGhvgUnRfzDNaSXlMmTL==FJPHBYyOIqeGhvgUnRfzDNaSXlMmpt:
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_LiveChannel_List(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp,args):
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmTj=FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.SpotvObj.GetLiveChannelList()
  for FJPHBYyOIqeGhvgUnRfzDNaSXlMmTb in FJPHBYyOIqeGhvgUnRfzDNaSXlMmTj:
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmpu =FJPHBYyOIqeGhvgUnRfzDNaSXlMmTb.get('id')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLu =FJPHBYyOIqeGhvgUnRfzDNaSXlMmTb.get('name')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjd =FJPHBYyOIqeGhvgUnRfzDNaSXlMmTb.get('programName')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjA =FJPHBYyOIqeGhvgUnRfzDNaSXlMmTb.get('logo')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmTC=FJPHBYyOIqeGhvgUnRfzDNaSXlMmTb.get('channelepg')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmTp =FJPHBYyOIqeGhvgUnRfzDNaSXlMmTb.get('free')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjV={'plot':'%s\n\n%s'%(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLu,FJPHBYyOIqeGhvgUnRfzDNaSXlMmTC),'mediatype':'episode',}
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjp={'mode':'LIVE','mediacode':FJPHBYyOIqeGhvgUnRfzDNaSXlMmpu,'free':FJPHBYyOIqeGhvgUnRfzDNaSXlMmTp,'mediatype':'live'}
   if FJPHBYyOIqeGhvgUnRfzDNaSXlMmTp:FJPHBYyOIqeGhvgUnRfzDNaSXlMmLu+=' [free]'
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.add_dir(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLu,sublabel=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjd,img=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjA,infoLabels=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjV,isFolder=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpt,params=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjp)
  xbmcplugin.setContent(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp._addon_handle,'episodes')
  if FJPHBYyOIqeGhvgUnRfzDNaSXlMmpE(FJPHBYyOIqeGhvgUnRfzDNaSXlMmTj)>0:xbmcplugin.endOfDirectory(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp._addon_handle,cacheToDisc=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpt)
 def dp_EventLiveChannel_List(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp,args):
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmTj,FJPHBYyOIqeGhvgUnRfzDNaSXlMmTW=FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.SpotvObj.GetEventLiveList()
  if FJPHBYyOIqeGhvgUnRfzDNaSXlMmTW!=401 and FJPHBYyOIqeGhvgUnRfzDNaSXlMmpE(FJPHBYyOIqeGhvgUnRfzDNaSXlMmTj)==0:
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.addon_noti(__language__(30907).encode('utf8'))
  for FJPHBYyOIqeGhvgUnRfzDNaSXlMmTb in FJPHBYyOIqeGhvgUnRfzDNaSXlMmTj:
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLu =FJPHBYyOIqeGhvgUnRfzDNaSXlMmTb.get('title')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjd =FJPHBYyOIqeGhvgUnRfzDNaSXlMmTb.get('startTime')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjA =FJPHBYyOIqeGhvgUnRfzDNaSXlMmTb.get('logo')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmTp =FJPHBYyOIqeGhvgUnRfzDNaSXlMmTb.get('free')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjV={'mediatype':'episode','plot':'%s\n\n%s'%(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLu,FJPHBYyOIqeGhvgUnRfzDNaSXlMmjd)}
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjp={'mode':'ELIVE','mediacode':FJPHBYyOIqeGhvgUnRfzDNaSXlMmTb.get('liveId'),'free':FJPHBYyOIqeGhvgUnRfzDNaSXlMmTp,'mediatype':'live'}
   if FJPHBYyOIqeGhvgUnRfzDNaSXlMmTp:FJPHBYyOIqeGhvgUnRfzDNaSXlMmLu+=' [free]'
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.add_dir(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLu,sublabel=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjd,img=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjA,infoLabels=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjV,isFolder=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpt,params=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjp)
  xbmcplugin.setContent(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp._addon_handle,'episodes')
  if FJPHBYyOIqeGhvgUnRfzDNaSXlMmpE(FJPHBYyOIqeGhvgUnRfzDNaSXlMmTj)>0:xbmcplugin.endOfDirectory(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp._addon_handle,cacheToDisc=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpt)
  return FJPHBYyOIqeGhvgUnRfzDNaSXlMmTW
 def make_stream_header(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp,FJPHBYyOIqeGhvgUnRfzDNaSXlMmTt,cookies):
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmTQ=''
  if cookies not in[{},FJPHBYyOIqeGhvgUnRfzDNaSXlMmpd,'']:
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmTc=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpE(cookies)
   for FJPHBYyOIqeGhvgUnRfzDNaSXlMmLK,FJPHBYyOIqeGhvgUnRfzDNaSXlMmTd in cookies.items():
    FJPHBYyOIqeGhvgUnRfzDNaSXlMmTQ+='{}={}'.format(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLK,FJPHBYyOIqeGhvgUnRfzDNaSXlMmTd)
    FJPHBYyOIqeGhvgUnRfzDNaSXlMmTc+=-1
    if FJPHBYyOIqeGhvgUnRfzDNaSXlMmTc>0:FJPHBYyOIqeGhvgUnRfzDNaSXlMmTQ+='; '
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmTt['cookie']=FJPHBYyOIqeGhvgUnRfzDNaSXlMmTQ
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmTw=''
  i=0
  for FJPHBYyOIqeGhvgUnRfzDNaSXlMmLK,FJPHBYyOIqeGhvgUnRfzDNaSXlMmTd in FJPHBYyOIqeGhvgUnRfzDNaSXlMmTt.items():
   i=i+1
   if i>1:FJPHBYyOIqeGhvgUnRfzDNaSXlMmTw+='&'
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmTw+='{}={}'.format(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLK,urllib.parse.quote(FJPHBYyOIqeGhvgUnRfzDNaSXlMmTd))
  return FJPHBYyOIqeGhvgUnRfzDNaSXlMmTw
 def play_VIDEO(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp,args):
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmTA =args.get('mode')
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmTs =args.get('mediacode')
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmTx =args.get('mediatype')
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmji =args.get('vtypeId')
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmTV =args.get('hlsUrl')
  if FJPHBYyOIqeGhvgUnRfzDNaSXlMmTA=='LIVE':
   if args.get('free')=='False':
    if FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.SpotvObj.CheckSubEnd()==FJPHBYyOIqeGhvgUnRfzDNaSXlMmpt:
     FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.addon_noti(__language__(30908).encode('utf8'))
     return
  elif FJPHBYyOIqeGhvgUnRfzDNaSXlMmTA=='ELIVE':
   if args.get('free')=='False':
    if FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.SpotvObj.CheckSubEnd()==FJPHBYyOIqeGhvgUnRfzDNaSXlMmpt:
     FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.addon_noti(__language__(30908).encode('utf8'))
     return
  if FJPHBYyOIqeGhvgUnRfzDNaSXlMmTs=='' or FJPHBYyOIqeGhvgUnRfzDNaSXlMmTs==FJPHBYyOIqeGhvgUnRfzDNaSXlMmpd:
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.addon_noti(__language__(30907).encode('utf8'))
   return
  if FJPHBYyOIqeGhvgUnRfzDNaSXlMmTA=='LIVE':
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmTE,FJPHBYyOIqeGhvgUnRfzDNaSXlMmTo=FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.SpotvObj.GetHlsUrl(FJPHBYyOIqeGhvgUnRfzDNaSXlMmTs)
  else:
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.addon_log('mediacode : '+FJPHBYyOIqeGhvgUnRfzDNaSXlMmTs)
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.addon_log('mediatype : '+FJPHBYyOIqeGhvgUnRfzDNaSXlMmTx)
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.addon_log('vtypeId   : '+FJPHBYyOIqeGhvgUnRfzDNaSXlMmpo(FJPHBYyOIqeGhvgUnRfzDNaSXlMmji))
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmTE,FJPHBYyOIqeGhvgUnRfzDNaSXlMmTo=FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.SpotvObj.GetBroadURL(FJPHBYyOIqeGhvgUnRfzDNaSXlMmTs,FJPHBYyOIqeGhvgUnRfzDNaSXlMmTx,FJPHBYyOIqeGhvgUnRfzDNaSXlMmji)
  if FJPHBYyOIqeGhvgUnRfzDNaSXlMmTo=='':
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.addon_noti(__language__(30908).encode('utf8'))
   return
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmTu=FJPHBYyOIqeGhvgUnRfzDNaSXlMmTo
  try:
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.addon_log('mainMode  = '+FJPHBYyOIqeGhvgUnRfzDNaSXlMmTA)
  except:
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmpd
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.addon_log(FJPHBYyOIqeGhvgUnRfzDNaSXlMmTu)
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmTk=xbmcgui.ListItem(path=FJPHBYyOIqeGhvgUnRfzDNaSXlMmTu)
  if FJPHBYyOIqeGhvgUnRfzDNaSXlMmTA in['LIVE','ELIVE']:
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmTK={}
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmTK['content-type']='application/octet-stream' 
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmTK['user-agent'] =FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.SpotvObj.USER_AGENT
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmTi ='https://www.spotvnow.co.kr/drm/widevine/{}/{}'.format(FJPHBYyOIqeGhvgUnRfzDNaSXlMmTE,FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.SpotvObj.ST['cookies']['spotv_sessionid'])
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmTr=FJPHBYyOIqeGhvgUnRfzDNaSXlMmTi+'|'+urllib.parse.urlencode(FJPHBYyOIqeGhvgUnRfzDNaSXlMmTK)+'|R{SSM}|'
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmCL=FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.make_stream_header(FJPHBYyOIqeGhvgUnRfzDNaSXlMmTK,FJPHBYyOIqeGhvgUnRfzDNaSXlMmpd)
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.addon_log(FJPHBYyOIqeGhvgUnRfzDNaSXlMmTi)
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmTk.setProperty('inputstream','inputstream.adaptive')
   if FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.SpotvObj.KodiVersion<=20:
    FJPHBYyOIqeGhvgUnRfzDNaSXlMmTk.setProperty('inputstream.adaptive.manifest_type','hls')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmTk.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmTk.setProperty('inputstream.adaptive.license_key',FJPHBYyOIqeGhvgUnRfzDNaSXlMmTr)
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmTk.setProperty('inputstream.adaptive.stream_headers',FJPHBYyOIqeGhvgUnRfzDNaSXlMmCL)
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmTk.setProperty('inputstream.adaptive.manifest_headers',FJPHBYyOIqeGhvgUnRfzDNaSXlMmCL)
  xbmcplugin.setResolvedUrl(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp._addon_handle,FJPHBYyOIqeGhvgUnRfzDNaSXlMmpw,FJPHBYyOIqeGhvgUnRfzDNaSXlMmTk)
  try:
   if FJPHBYyOIqeGhvgUnRfzDNaSXlMmTx=='vod' and FJPHBYyOIqeGhvgUnRfzDNaSXlMmTA not in['POP_VOD','NOW_VOD']:
    FJPHBYyOIqeGhvgUnRfzDNaSXlMmjp={'code':args.get('saveId'),'img':args.get('saveImg'),'title':args.get('saveTitle'),'info':args.get('saveInfo')}
    FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.Save_Watched_List(FJPHBYyOIqeGhvgUnRfzDNaSXlMmTx,FJPHBYyOIqeGhvgUnRfzDNaSXlMmjp)
  except:
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmpd
 def logout(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp):
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmLt=xbmcgui.Dialog()
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmbi=FJPHBYyOIqeGhvgUnRfzDNaSXlMmLt.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if FJPHBYyOIqeGhvgUnRfzDNaSXlMmbi==FJPHBYyOIqeGhvgUnRfzDNaSXlMmpt:sys.exit()
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.SpotvObj.Init_ST_Total()
  if os.path.isfile(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLC):os.remove(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLC)
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp):
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmCj =FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.SpotvObj.Get_Now_Datetime()
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmCb=FJPHBYyOIqeGhvgUnRfzDNaSXlMmCj+datetime.timedelta(days=0)
  (FJPHBYyOIqeGhvgUnRfzDNaSXlMmbk,FJPHBYyOIqeGhvgUnRfzDNaSXlMmbK)=FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.get_settings_account()
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.SpotvObj.Save_session_acount(FJPHBYyOIqeGhvgUnRfzDNaSXlMmbk,FJPHBYyOIqeGhvgUnRfzDNaSXlMmbK)
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.SpotvObj.ST['account']['token_limit']=FJPHBYyOIqeGhvgUnRfzDNaSXlMmCb.strftime('%Y%m%d')
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.SpotvObj.JsonFile_Save(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLC,FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.SpotvObj.ST)
 def cookiefile_check(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp):
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.SpotvObj.ST=FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.SpotvObj.JsonFile_Load(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLC)
  if 'account' not in FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.SpotvObj.ST:
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.SpotvObj.Init_ST_Total()
   return FJPHBYyOIqeGhvgUnRfzDNaSXlMmpt
  (FJPHBYyOIqeGhvgUnRfzDNaSXlMmCT,FJPHBYyOIqeGhvgUnRfzDNaSXlMmCp)=FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.get_settings_account()
  (FJPHBYyOIqeGhvgUnRfzDNaSXlMmCW,FJPHBYyOIqeGhvgUnRfzDNaSXlMmCQ)=FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.SpotvObj.Load_session_acount()
  if FJPHBYyOIqeGhvgUnRfzDNaSXlMmCT!=FJPHBYyOIqeGhvgUnRfzDNaSXlMmCW or FJPHBYyOIqeGhvgUnRfzDNaSXlMmCp!=FJPHBYyOIqeGhvgUnRfzDNaSXlMmCQ:
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.SpotvObj.Init_ST_Total()
   return FJPHBYyOIqeGhvgUnRfzDNaSXlMmpt
  if FJPHBYyOIqeGhvgUnRfzDNaSXlMmpx(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))>FJPHBYyOIqeGhvgUnRfzDNaSXlMmpx(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.SpotvObj.ST['account']['token_limit']):
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.SpotvObj.Init_ST_Total()
   return FJPHBYyOIqeGhvgUnRfzDNaSXlMmpt
  return FJPHBYyOIqeGhvgUnRfzDNaSXlMmpw
 def dp_History_Remove(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp,args):
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmCc=args.get('delType')
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmCd =args.get('sKey')
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmCt =args.get('vType')
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmLt=xbmcgui.Dialog()
  if FJPHBYyOIqeGhvgUnRfzDNaSXlMmCc=='WATCH_ALL':
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmbi=FJPHBYyOIqeGhvgUnRfzDNaSXlMmLt.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif FJPHBYyOIqeGhvgUnRfzDNaSXlMmCc=='WATCH_ONE':
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmbi=FJPHBYyOIqeGhvgUnRfzDNaSXlMmLt.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  if FJPHBYyOIqeGhvgUnRfzDNaSXlMmbi==FJPHBYyOIqeGhvgUnRfzDNaSXlMmpt:sys.exit()
  if FJPHBYyOIqeGhvgUnRfzDNaSXlMmCc=='WATCH_ALL':
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmCw=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%FJPHBYyOIqeGhvgUnRfzDNaSXlMmCt))
   if os.path.isfile(FJPHBYyOIqeGhvgUnRfzDNaSXlMmCw):os.remove(FJPHBYyOIqeGhvgUnRfzDNaSXlMmCw)
  elif FJPHBYyOIqeGhvgUnRfzDNaSXlMmCc=='WATCH_ONE':
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmCw=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%FJPHBYyOIqeGhvgUnRfzDNaSXlMmCt))
   try:
    FJPHBYyOIqeGhvgUnRfzDNaSXlMmCA=FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.Load_List_File(FJPHBYyOIqeGhvgUnRfzDNaSXlMmCt) 
    fp=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpk(FJPHBYyOIqeGhvgUnRfzDNaSXlMmCw,'w',-1,'utf-8')
    for FJPHBYyOIqeGhvgUnRfzDNaSXlMmCs in FJPHBYyOIqeGhvgUnRfzDNaSXlMmCA:
     FJPHBYyOIqeGhvgUnRfzDNaSXlMmCx=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpK(urllib.parse.parse_qsl(FJPHBYyOIqeGhvgUnRfzDNaSXlMmCs))
     FJPHBYyOIqeGhvgUnRfzDNaSXlMmCV=FJPHBYyOIqeGhvgUnRfzDNaSXlMmCx.get('code').strip()
     if FJPHBYyOIqeGhvgUnRfzDNaSXlMmCd!=FJPHBYyOIqeGhvgUnRfzDNaSXlMmCV:
      fp.write(FJPHBYyOIqeGhvgUnRfzDNaSXlMmCs)
    fp.close()
   except:
    FJPHBYyOIqeGhvgUnRfzDNaSXlMmpd
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp,FJPHBYyOIqeGhvgUnRfzDNaSXlMmTx):
  try:
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmCE=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%FJPHBYyOIqeGhvgUnRfzDNaSXlMmTx))
   fp=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpk(FJPHBYyOIqeGhvgUnRfzDNaSXlMmCE,'r',-1,'utf-8')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmCo=fp.readlines()
   fp.close()
  except:
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmCo=[]
  return FJPHBYyOIqeGhvgUnRfzDNaSXlMmCo
 def Save_Watched_List(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp,stype,FJPHBYyOIqeGhvgUnRfzDNaSXlMmLc):
  try:
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmCE=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmCA=FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.Load_List_File(stype) 
   fp=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpk(FJPHBYyOIqeGhvgUnRfzDNaSXlMmCE,'w',-1,'utf-8')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmCu=urllib.parse.urlencode(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLc)
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmCu=FJPHBYyOIqeGhvgUnRfzDNaSXlMmCu+'\n'
   fp.write(FJPHBYyOIqeGhvgUnRfzDNaSXlMmCu)
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmCk=0
   for FJPHBYyOIqeGhvgUnRfzDNaSXlMmCs in FJPHBYyOIqeGhvgUnRfzDNaSXlMmCA:
    FJPHBYyOIqeGhvgUnRfzDNaSXlMmCx=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpK(urllib.parse.parse_qsl(FJPHBYyOIqeGhvgUnRfzDNaSXlMmCs))
    FJPHBYyOIqeGhvgUnRfzDNaSXlMmCK=FJPHBYyOIqeGhvgUnRfzDNaSXlMmLc.get('code')
    FJPHBYyOIqeGhvgUnRfzDNaSXlMmCi=FJPHBYyOIqeGhvgUnRfzDNaSXlMmCx.get('code')
    if FJPHBYyOIqeGhvgUnRfzDNaSXlMmCK!=FJPHBYyOIqeGhvgUnRfzDNaSXlMmCi:
     fp.write(FJPHBYyOIqeGhvgUnRfzDNaSXlMmCs)
     FJPHBYyOIqeGhvgUnRfzDNaSXlMmCk+=1
     if FJPHBYyOIqeGhvgUnRfzDNaSXlMmCk>=50:break
   fp.close()
  except:
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmpd
 def dp_Watch_List(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp,args):
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmTx ='vod'
  if FJPHBYyOIqeGhvgUnRfzDNaSXlMmTx=='vod':
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmCr=FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.Load_List_File(FJPHBYyOIqeGhvgUnRfzDNaSXlMmTx)
   for FJPHBYyOIqeGhvgUnRfzDNaSXlMmpL in FJPHBYyOIqeGhvgUnRfzDNaSXlMmCr:
    FJPHBYyOIqeGhvgUnRfzDNaSXlMmpj=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpK(urllib.parse.parse_qsl(FJPHBYyOIqeGhvgUnRfzDNaSXlMmpL))
    FJPHBYyOIqeGhvgUnRfzDNaSXlMmLu =FJPHBYyOIqeGhvgUnRfzDNaSXlMmpj.get('title')
    FJPHBYyOIqeGhvgUnRfzDNaSXlMmjA=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpj.get('img')
    FJPHBYyOIqeGhvgUnRfzDNaSXlMmTs=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpj.get('code')
    FJPHBYyOIqeGhvgUnRfzDNaSXlMmpb =FJPHBYyOIqeGhvgUnRfzDNaSXlMmpj.get('info')
    FJPHBYyOIqeGhvgUnRfzDNaSXlMmjV={}
    FJPHBYyOIqeGhvgUnRfzDNaSXlMmjV['plot'] =FJPHBYyOIqeGhvgUnRfzDNaSXlMmpb
    FJPHBYyOIqeGhvgUnRfzDNaSXlMmjV['mediatype']='tvshow'
    FJPHBYyOIqeGhvgUnRfzDNaSXlMmjp={'mode':'GAME_VOD_GROUP','gameid':FJPHBYyOIqeGhvgUnRfzDNaSXlMmTs,'saveTitle':FJPHBYyOIqeGhvgUnRfzDNaSXlMmLu,'saveImg':FJPHBYyOIqeGhvgUnRfzDNaSXlMmjA,'saveInfo':FJPHBYyOIqeGhvgUnRfzDNaSXlMmpb,'mediatype':FJPHBYyOIqeGhvgUnRfzDNaSXlMmTx}
    FJPHBYyOIqeGhvgUnRfzDNaSXlMmpT={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':FJPHBYyOIqeGhvgUnRfzDNaSXlMmTs,'vType':FJPHBYyOIqeGhvgUnRfzDNaSXlMmTx,}
    FJPHBYyOIqeGhvgUnRfzDNaSXlMmpC=urllib.parse.urlencode(FJPHBYyOIqeGhvgUnRfzDNaSXlMmpT)
    FJPHBYyOIqeGhvgUnRfzDNaSXlMmpW=[('선택된 시청이력 ( %s ) 삭제'%(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLu),'RunPlugin(plugin://plugin.video.spotvm/?%s)'%(FJPHBYyOIqeGhvgUnRfzDNaSXlMmpC))]
    FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.add_dir(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLu,sublabel='',img=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjA,infoLabels=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjV,isFolder=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpw,params=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjp,ContextMenu=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpW)
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjV={'plot':'시청목록을 삭제합니다.'}
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLu='*** 시청목록 삭제 ***'
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjp={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':FJPHBYyOIqeGhvgUnRfzDNaSXlMmTx,}
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmjC=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.add_dir(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLu,sublabel='',img=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjC,infoLabels=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjV,isFolder=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpt,params=FJPHBYyOIqeGhvgUnRfzDNaSXlMmjp,isLink=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpw)
   xbmcplugin.endOfDirectory(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp._addon_handle,cacheToDisc=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpt)
 def spotv_main(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp):
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.SpotvObj.KodiVersion=FJPHBYyOIqeGhvgUnRfzDNaSXlMmpx(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmpQ=FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.main_params.get('mode',FJPHBYyOIqeGhvgUnRfzDNaSXlMmpd)
  if FJPHBYyOIqeGhvgUnRfzDNaSXlMmpQ=='LOGOUT':
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.logout()
   return
  FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.login_main()
  if FJPHBYyOIqeGhvgUnRfzDNaSXlMmpQ is FJPHBYyOIqeGhvgUnRfzDNaSXlMmpd:
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.dp_Main_List()
  elif FJPHBYyOIqeGhvgUnRfzDNaSXlMmpQ=='LIVE_GROUP':
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.dp_LiveChannel_List(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.main_params)
  elif FJPHBYyOIqeGhvgUnRfzDNaSXlMmpQ=='ELIVE_GROUP':
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmTW=FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.dp_EventLiveChannel_List(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.main_params)
   if FJPHBYyOIqeGhvgUnRfzDNaSXlMmTW==401:
    if os.path.isfile(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLC):os.remove(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLC)
    FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.login_main()
    FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.dp_EventLiveChannel_List(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.main_params)
  elif FJPHBYyOIqeGhvgUnRfzDNaSXlMmpQ in['LIVE','GAME_VOD','POP_VOD','NOW_VOD','ELIVE']:
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.play_VIDEO(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.main_params)
  elif FJPHBYyOIqeGhvgUnRfzDNaSXlMmpQ=='VOD_GROUP':
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.dp_MainLeague_List(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.main_params)
  elif FJPHBYyOIqeGhvgUnRfzDNaSXlMmpQ=='NOW_GROUP':
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.dp_NowVod_GroupList(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.main_params)
  elif FJPHBYyOIqeGhvgUnRfzDNaSXlMmpQ=='POP_GROUP':
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.dp_PopVod_GroupList(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.main_params)
  elif FJPHBYyOIqeGhvgUnRfzDNaSXlMmpQ=='LEAGUE_GROUP':
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.dp_Season_List(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.main_params)
  elif FJPHBYyOIqeGhvgUnRfzDNaSXlMmpQ=='SEASON_GROUP':
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.dp_Game_List(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.main_params)
  elif FJPHBYyOIqeGhvgUnRfzDNaSXlMmpQ=='GAME_VOD_GROUP':
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.dp_GameVod_List(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.main_params)
  elif FJPHBYyOIqeGhvgUnRfzDNaSXlMmpQ=='WATCH':
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.dp_Watch_List(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.main_params)
  elif FJPHBYyOIqeGhvgUnRfzDNaSXlMmpQ=='MYVIEW_REMOVE':
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.dp_History_Remove(FJPHBYyOIqeGhvgUnRfzDNaSXlMmLp.main_params)
  else:
   FJPHBYyOIqeGhvgUnRfzDNaSXlMmpd
# Created by pyminifier (https://github.com/liftoff/pyminifier)
