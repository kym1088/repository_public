__author__="NightRain"
NJERvVGTwDhmoUrfFSyBadAWptCcje=object
NJERvVGTwDhmoUrfFSyBadAWptCcjs=None
NJERvVGTwDhmoUrfFSyBadAWptCcjK=False
NJERvVGTwDhmoUrfFSyBadAWptCcjx=str
NJERvVGTwDhmoUrfFSyBadAWptCcjY=open
NJERvVGTwDhmoUrfFSyBadAWptCcjn=True
NJERvVGTwDhmoUrfFSyBadAWptCcjQ=int
NJERvVGTwDhmoUrfFSyBadAWptCcOI=Exception
NJERvVGTwDhmoUrfFSyBadAWptCcOP=print
NJERvVGTwDhmoUrfFSyBadAWptCcOX=len
NJERvVGTwDhmoUrfFSyBadAWptCcOM=range
import urllib
import re
import json
import sys
import time
import requests
import datetime
import base64
import random
NJERvVGTwDhmoUrfFSyBadAWptCcIX={'stream50':1080,'stream40':720,'stream30':540}
class NJERvVGTwDhmoUrfFSyBadAWptCcIP(NJERvVGTwDhmoUrfFSyBadAWptCcje):
 def __init__(NJERvVGTwDhmoUrfFSyBadAWptCcIM):
  NJERvVGTwDhmoUrfFSyBadAWptCcIM.SPOTV_PMCODE ='987'
  NJERvVGTwDhmoUrfFSyBadAWptCcIM.SPOTV_PMSIZE =3
  NJERvVGTwDhmoUrfFSyBadAWptCcIM.GAMELIST_LIMIT =10
  NJERvVGTwDhmoUrfFSyBadAWptCcIM.API_DOMAIN ='https://www.spotvnow.co.kr'
  NJERvVGTwDhmoUrfFSyBadAWptCcIM.BC_DOMAIN ='https://players.brightcove.net'
  NJERvVGTwDhmoUrfFSyBadAWptCcIM.PLAYER_DOMAIN ='https://edge.api.brightcove.com'
  NJERvVGTwDhmoUrfFSyBadAWptCcIM.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36'
  NJERvVGTwDhmoUrfFSyBadAWptCcIM.DEFAULT_HEADER ={'user-agent':NJERvVGTwDhmoUrfFSyBadAWptCcIM.USER_AGENT}
  NJERvVGTwDhmoUrfFSyBadAWptCcIM.COOKIE_FILE_NAME=''
  NJERvVGTwDhmoUrfFSyBadAWptCcIM.KodiVersion =20
  NJERvVGTwDhmoUrfFSyBadAWptCcIM.SP_CONTEXTJSON_FILE1 =''
  NJERvVGTwDhmoUrfFSyBadAWptCcIM.SP_CONTEXTJSON_FILE2 =''
  NJERvVGTwDhmoUrfFSyBadAWptCcIM.ST ={}
  NJERvVGTwDhmoUrfFSyBadAWptCcIM.Init_ST_Total()
 def Init_ST_Total(NJERvVGTwDhmoUrfFSyBadAWptCcIM):
  NJERvVGTwDhmoUrfFSyBadAWptCcIM.ST={'account':{},'cookies':{},}
 def addon_log(NJERvVGTwDhmoUrfFSyBadAWptCcIM,string):
  import xbmcaddon,xbmc
  __version__=xbmcaddon.Addon().getAddonInfo('version')
  __addonid__=xbmcaddon.Addon().getAddonInfo('id')
  try:
   NJERvVGTwDhmoUrfFSyBadAWptCcIj=string.encode('utf-8','ignore')
  except:
   NJERvVGTwDhmoUrfFSyBadAWptCcIj='addonException: addon_log'
  NJERvVGTwDhmoUrfFSyBadAWptCcIO=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,NJERvVGTwDhmoUrfFSyBadAWptCcIj),level=NJERvVGTwDhmoUrfFSyBadAWptCcIO)
 def callRequestCookies(NJERvVGTwDhmoUrfFSyBadAWptCcIM,jobtype,NJERvVGTwDhmoUrfFSyBadAWptCcIs,payload=NJERvVGTwDhmoUrfFSyBadAWptCcjs,json=NJERvVGTwDhmoUrfFSyBadAWptCcjs,params=NJERvVGTwDhmoUrfFSyBadAWptCcjs,headers=NJERvVGTwDhmoUrfFSyBadAWptCcjs,cookies=NJERvVGTwDhmoUrfFSyBadAWptCcjs,redirects=NJERvVGTwDhmoUrfFSyBadAWptCcjK):
  NJERvVGTwDhmoUrfFSyBadAWptCcIi=NJERvVGTwDhmoUrfFSyBadAWptCcIM.DEFAULT_HEADER
  if headers:NJERvVGTwDhmoUrfFSyBadAWptCcIi.update(headers)
  if jobtype=='Get':
   NJERvVGTwDhmoUrfFSyBadAWptCcIq=requests.get(NJERvVGTwDhmoUrfFSyBadAWptCcIs,params=params,headers=NJERvVGTwDhmoUrfFSyBadAWptCcIi,cookies=cookies,allow_redirects=redirects)
  else:
   NJERvVGTwDhmoUrfFSyBadAWptCcIq=requests.post(NJERvVGTwDhmoUrfFSyBadAWptCcIs,data=payload,json=json,params=params,headers=NJERvVGTwDhmoUrfFSyBadAWptCcIi,cookies=cookies,allow_redirects=redirects)
  try:
   NJERvVGTwDhmoUrfFSyBadAWptCcIM.addon_log(NJERvVGTwDhmoUrfFSyBadAWptCcjx(NJERvVGTwDhmoUrfFSyBadAWptCcIq.status_code)+' : '+NJERvVGTwDhmoUrfFSyBadAWptCcIq.url)
  except:
   NJERvVGTwDhmoUrfFSyBadAWptCcjs
  return NJERvVGTwDhmoUrfFSyBadAWptCcIq
 def JsonFile_Save(NJERvVGTwDhmoUrfFSyBadAWptCcIM,filename,NJERvVGTwDhmoUrfFSyBadAWptCcIu):
  if filename=='':return NJERvVGTwDhmoUrfFSyBadAWptCcjK
  try:
   fp=NJERvVGTwDhmoUrfFSyBadAWptCcjY(filename,'w',-1,'utf-8')
   json.dump(NJERvVGTwDhmoUrfFSyBadAWptCcIu,fp,indent=4,ensure_ascii=NJERvVGTwDhmoUrfFSyBadAWptCcjK)
   fp.close()
  except:
   return NJERvVGTwDhmoUrfFSyBadAWptCcjK
  return NJERvVGTwDhmoUrfFSyBadAWptCcjn
 def JsonFile_Load(NJERvVGTwDhmoUrfFSyBadAWptCcIM,filename):
  if filename=='':return{}
  try:
   fp=NJERvVGTwDhmoUrfFSyBadAWptCcjY(filename,'r',-1,'utf-8')
   NJERvVGTwDhmoUrfFSyBadAWptCcIL=json.load(fp)
   fp.close()
  except:
   return{}
  return NJERvVGTwDhmoUrfFSyBadAWptCcIL
 def Save_session_acount(NJERvVGTwDhmoUrfFSyBadAWptCcIM,NJERvVGTwDhmoUrfFSyBadAWptCcIz,NJERvVGTwDhmoUrfFSyBadAWptCcIk):
  NJERvVGTwDhmoUrfFSyBadAWptCcIM.ST['account']['stid'] =base64.standard_b64encode(NJERvVGTwDhmoUrfFSyBadAWptCcIz.encode()).decode('utf-8')
  NJERvVGTwDhmoUrfFSyBadAWptCcIM.ST['account']['stpw'] =base64.standard_b64encode(NJERvVGTwDhmoUrfFSyBadAWptCcIk.encode()).decode('utf-8')
 def Load_session_acount(NJERvVGTwDhmoUrfFSyBadAWptCcIM):
  try:
   NJERvVGTwDhmoUrfFSyBadAWptCcIz =base64.standard_b64decode(NJERvVGTwDhmoUrfFSyBadAWptCcIM.ST['account']['stid']).decode('utf-8')
   NJERvVGTwDhmoUrfFSyBadAWptCcIk =base64.standard_b64decode(NJERvVGTwDhmoUrfFSyBadAWptCcIM.ST['account']['stpw']).decode('utf-8')
  except:
   return '',''
  return NJERvVGTwDhmoUrfFSyBadAWptCcIz,NJERvVGTwDhmoUrfFSyBadAWptCcIk
 def makeDefaultCookies(NJERvVGTwDhmoUrfFSyBadAWptCcIM):
  NJERvVGTwDhmoUrfFSyBadAWptCcIl={'id_token':NJERvVGTwDhmoUrfFSyBadAWptCcIM.ST['cookies']['id_token'],'ory_hydra_consent_csrf_3853969264':NJERvVGTwDhmoUrfFSyBadAWptCcIM.ST['cookies']['ory_hydra_consent_csrf_3853969264'],'ory_hydra_session':NJERvVGTwDhmoUrfFSyBadAWptCcIM.ST['cookies']['ory_hydra_session'],}
  return NJERvVGTwDhmoUrfFSyBadAWptCcIl
 def makeDefaultHeaders(NJERvVGTwDhmoUrfFSyBadAWptCcIM):
  NJERvVGTwDhmoUrfFSyBadAWptCcIH={'accept':'application/json;pk={}'.format(NJERvVGTwDhmoUrfFSyBadAWptCcIM.ST['cookies']['spotv_policyKey'])}
  return NJERvVGTwDhmoUrfFSyBadAWptCcIH
 def xmlText(NJERvVGTwDhmoUrfFSyBadAWptCcIM,in_text):
  NJERvVGTwDhmoUrfFSyBadAWptCcIg=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;')
  return NJERvVGTwDhmoUrfFSyBadAWptCcIg
 def GetNoCache(NJERvVGTwDhmoUrfFSyBadAWptCcIM,timetype=1):
  if timetype==1:
   return NJERvVGTwDhmoUrfFSyBadAWptCcjQ(time.time())
  else:
   return NJERvVGTwDhmoUrfFSyBadAWptCcjQ(time.time()*1000)
 def GetCredential_new(NJERvVGTwDhmoUrfFSyBadAWptCcIM,user_id,user_pw):
  NJERvVGTwDhmoUrfFSyBadAWptCcIe=requests.session()
  try:
   NJERvVGTwDhmoUrfFSyBadAWptCcIs='https://nid.spotvnow.co.kr/api/v3/oauth2/authorize/spotvnow?return_url=https%3A%2F%2Fwww.spotvnow.co.kr%2Fcheck&err_return_url=https%3A%2F%2Fwww.spotvnow.co.kr%2Fabout&logout_url=https%3A%2F%2Fwww.spotvnow.co.kr%2Fintro'
   NJERvVGTwDhmoUrfFSyBadAWptCcIH={'User-Agent':NJERvVGTwDhmoUrfFSyBadAWptCcIM.USER_AGENT,}
   while(NJERvVGTwDhmoUrfFSyBadAWptCcIs not in['',NJERvVGTwDhmoUrfFSyBadAWptCcjs]):
    NJERvVGTwDhmoUrfFSyBadAWptCcIK=NJERvVGTwDhmoUrfFSyBadAWptCcIe.get(NJERvVGTwDhmoUrfFSyBadAWptCcIs,params=NJERvVGTwDhmoUrfFSyBadAWptCcjs,headers=NJERvVGTwDhmoUrfFSyBadAWptCcIH,cookies=NJERvVGTwDhmoUrfFSyBadAWptCcIM.ST['cookies'],allow_redirects=NJERvVGTwDhmoUrfFSyBadAWptCcjK)
    NJERvVGTwDhmoUrfFSyBadAWptCcIs =NJERvVGTwDhmoUrfFSyBadAWptCcIK.headers.get('location')
    for NJERvVGTwDhmoUrfFSyBadAWptCcIx in NJERvVGTwDhmoUrfFSyBadAWptCcIK.cookies:
     if NJERvVGTwDhmoUrfFSyBadAWptCcIx.value not in['',NJERvVGTwDhmoUrfFSyBadAWptCcjs]:
      NJERvVGTwDhmoUrfFSyBadAWptCcIM.ST['cookies'][NJERvVGTwDhmoUrfFSyBadAWptCcIx.name]=NJERvVGTwDhmoUrfFSyBadAWptCcIx.value
    if NJERvVGTwDhmoUrfFSyBadAWptCcIK.status_code==200:break
   if NJERvVGTwDhmoUrfFSyBadAWptCcIM.ST['cookies']['login_challenge']=='':
    NJERvVGTwDhmoUrfFSyBadAWptCcIM.Init_ST_Total()
    return NJERvVGTwDhmoUrfFSyBadAWptCcjK
  except NJERvVGTwDhmoUrfFSyBadAWptCcOI as exception:
   NJERvVGTwDhmoUrfFSyBadAWptCcOP(exception)
   NJERvVGTwDhmoUrfFSyBadAWptCcIM.Init_ST_Total()
   return NJERvVGTwDhmoUrfFSyBadAWptCcjK
  try:
   NJERvVGTwDhmoUrfFSyBadAWptCcIY=base64.standard_b64encode(user_id.encode('UTF-8')).decode('utf-8')
   NJERvVGTwDhmoUrfFSyBadAWptCcIn=base64.standard_b64encode(user_pw.encode('UTF-8')).decode('utf-8')
   NJERvVGTwDhmoUrfFSyBadAWptCcIs='https://nid.spotvnow.co.kr/api/v3/user-auth/login'
   NJERvVGTwDhmoUrfFSyBadAWptCcIH={'User-Agent':NJERvVGTwDhmoUrfFSyBadAWptCcIM.USER_AGENT,}
   NJERvVGTwDhmoUrfFSyBadAWptCcIQ={'username':NJERvVGTwDhmoUrfFSyBadAWptCcIY,'password':NJERvVGTwDhmoUrfFSyBadAWptCcIn,'remember':NJERvVGTwDhmoUrfFSyBadAWptCcjn,'err_return_url':'https://www.spotvnow.co.kr/intro',}
   NJERvVGTwDhmoUrfFSyBadAWptCcIK=NJERvVGTwDhmoUrfFSyBadAWptCcIe.post(NJERvVGTwDhmoUrfFSyBadAWptCcIs,data=NJERvVGTwDhmoUrfFSyBadAWptCcIQ,params=NJERvVGTwDhmoUrfFSyBadAWptCcjs,headers=NJERvVGTwDhmoUrfFSyBadAWptCcIH,cookies=NJERvVGTwDhmoUrfFSyBadAWptCcIM.ST['cookies'],allow_redirects=NJERvVGTwDhmoUrfFSyBadAWptCcjK)
   for NJERvVGTwDhmoUrfFSyBadAWptCcIx in NJERvVGTwDhmoUrfFSyBadAWptCcIK.cookies:
    if NJERvVGTwDhmoUrfFSyBadAWptCcIx.value not in['',NJERvVGTwDhmoUrfFSyBadAWptCcjs]:
     NJERvVGTwDhmoUrfFSyBadAWptCcIM.ST['cookies'][NJERvVGTwDhmoUrfFSyBadAWptCcIx.name]=NJERvVGTwDhmoUrfFSyBadAWptCcIx.value
   NJERvVGTwDhmoUrfFSyBadAWptCcIs=NJERvVGTwDhmoUrfFSyBadAWptCcIK.headers.get('location')
   while(NJERvVGTwDhmoUrfFSyBadAWptCcIs not in['',NJERvVGTwDhmoUrfFSyBadAWptCcjs]):
    NJERvVGTwDhmoUrfFSyBadAWptCcIH={'user-agent':NJERvVGTwDhmoUrfFSyBadAWptCcIM.USER_AGENT,}
    NJERvVGTwDhmoUrfFSyBadAWptCcIK=NJERvVGTwDhmoUrfFSyBadAWptCcIe.get(NJERvVGTwDhmoUrfFSyBadAWptCcIs,params=NJERvVGTwDhmoUrfFSyBadAWptCcjs,headers=NJERvVGTwDhmoUrfFSyBadAWptCcIH,cookies=NJERvVGTwDhmoUrfFSyBadAWptCcIM.ST['cookies'],allow_redirects=NJERvVGTwDhmoUrfFSyBadAWptCcjK)
    NJERvVGTwDhmoUrfFSyBadAWptCcIs =NJERvVGTwDhmoUrfFSyBadAWptCcIK.headers.get('location')
    for NJERvVGTwDhmoUrfFSyBadAWptCcIx in NJERvVGTwDhmoUrfFSyBadAWptCcIK.cookies:
     if NJERvVGTwDhmoUrfFSyBadAWptCcIx.value not in['',NJERvVGTwDhmoUrfFSyBadAWptCcjs]:
      NJERvVGTwDhmoUrfFSyBadAWptCcIM.ST['cookies'][NJERvVGTwDhmoUrfFSyBadAWptCcIx.name]=NJERvVGTwDhmoUrfFSyBadAWptCcIx.value
    if NJERvVGTwDhmoUrfFSyBadAWptCcIK.status_code==200:break
   if NJERvVGTwDhmoUrfFSyBadAWptCcIM.ST['cookies']['id_token']=='':
    NJERvVGTwDhmoUrfFSyBadAWptCcIM.Init_ST_Total()
    return NJERvVGTwDhmoUrfFSyBadAWptCcjK
  except NJERvVGTwDhmoUrfFSyBadAWptCcOI as exception:
   NJERvVGTwDhmoUrfFSyBadAWptCcOP(exception)
   NJERvVGTwDhmoUrfFSyBadAWptCcIM.Init_ST_Total()
   return NJERvVGTwDhmoUrfFSyBadAWptCcjK
  try:
   NJERvVGTwDhmoUrfFSyBadAWptCcIs=NJERvVGTwDhmoUrfFSyBadAWptCcIM.API_DOMAIN+'/api/v3/session' 
   NJERvVGTwDhmoUrfFSyBadAWptCcIl=NJERvVGTwDhmoUrfFSyBadAWptCcIM.makeDefaultCookies()
   NJERvVGTwDhmoUrfFSyBadAWptCcIK=NJERvVGTwDhmoUrfFSyBadAWptCcIM.callRequestCookies('Get',NJERvVGTwDhmoUrfFSyBadAWptCcIs,params=NJERvVGTwDhmoUrfFSyBadAWptCcjs,headers=NJERvVGTwDhmoUrfFSyBadAWptCcjs,cookies=NJERvVGTwDhmoUrfFSyBadAWptCcIl)
   NJERvVGTwDhmoUrfFSyBadAWptCcPI=json.loads(NJERvVGTwDhmoUrfFSyBadAWptCcIK.text)
   NJERvVGTwDhmoUrfFSyBadAWptCcIM.ST['cookies']['spotv_sessionid']=NJERvVGTwDhmoUrfFSyBadAWptCcPI.get('userId')
   NJERvVGTwDhmoUrfFSyBadAWptCcPX=NJERvVGTwDhmoUrfFSyBadAWptCcIM.SPOTV_PMCODE+NJERvVGTwDhmoUrfFSyBadAWptCcjx(NJERvVGTwDhmoUrfFSyBadAWptCcPI['subEndTime'])
   NJERvVGTwDhmoUrfFSyBadAWptCcIM.ST['cookies']['spotv_subend'] =base64.standard_b64encode(NJERvVGTwDhmoUrfFSyBadAWptCcPX.encode()).decode('utf-8')
  except NJERvVGTwDhmoUrfFSyBadAWptCcOI as exception:
   NJERvVGTwDhmoUrfFSyBadAWptCcOP(exception)
   NJERvVGTwDhmoUrfFSyBadAWptCcIM.Init_ST_Total()
   return NJERvVGTwDhmoUrfFSyBadAWptCcjK
  try:
   if NJERvVGTwDhmoUrfFSyBadAWptCcPI['subEndTime']in[0,'0',NJERvVGTwDhmoUrfFSyBadAWptCcjs]:
    NJERvVGTwDhmoUrfFSyBadAWptCcIs=NJERvVGTwDhmoUrfFSyBadAWptCcIM.API_DOMAIN+'/api/v3/user/sub/scope' 
    NJERvVGTwDhmoUrfFSyBadAWptCcIl=NJERvVGTwDhmoUrfFSyBadAWptCcIM.makeDefaultCookies()
    NJERvVGTwDhmoUrfFSyBadAWptCcIK=NJERvVGTwDhmoUrfFSyBadAWptCcIM.callRequestCookies('Get',NJERvVGTwDhmoUrfFSyBadAWptCcIs,params=NJERvVGTwDhmoUrfFSyBadAWptCcjs,headers=NJERvVGTwDhmoUrfFSyBadAWptCcjs,cookies=NJERvVGTwDhmoUrfFSyBadAWptCcIl)
    NJERvVGTwDhmoUrfFSyBadAWptCcPI=json.loads(NJERvVGTwDhmoUrfFSyBadAWptCcIK.text)
    if NJERvVGTwDhmoUrfFSyBadAWptCcPI.get('endDate')==NJERvVGTwDhmoUrfFSyBadAWptCcjs:
     NJERvVGTwDhmoUrfFSyBadAWptCcPX=NJERvVGTwDhmoUrfFSyBadAWptCcIM.SPOTV_PMCODE+'0'
     NJERvVGTwDhmoUrfFSyBadAWptCcIM.ST['cookies']['spotv_subend'] =base64.standard_b64encode(NJERvVGTwDhmoUrfFSyBadAWptCcPX.encode()).decode('utf-8')
    else:
     NJERvVGTwDhmoUrfFSyBadAWptCcPM=datetime.datetime.strptime(NJERvVGTwDhmoUrfFSyBadAWptCcPI.get('endDate'),'%Y-%m-%d %H:%M:%S')
     NJERvVGTwDhmoUrfFSyBadAWptCcPX=NJERvVGTwDhmoUrfFSyBadAWptCcjQ(time.mktime(NJERvVGTwDhmoUrfFSyBadAWptCcPM.timetuple()))
     NJERvVGTwDhmoUrfFSyBadAWptCcPX=NJERvVGTwDhmoUrfFSyBadAWptCcIM.SPOTV_PMCODE+NJERvVGTwDhmoUrfFSyBadAWptCcjx(NJERvVGTwDhmoUrfFSyBadAWptCcPX)+'000'
     NJERvVGTwDhmoUrfFSyBadAWptCcIM.ST['cookies']['spotv_subend'] =base64.standard_b64encode(NJERvVGTwDhmoUrfFSyBadAWptCcPX.encode()).decode('utf-8')
  except NJERvVGTwDhmoUrfFSyBadAWptCcOI as exception:
   NJERvVGTwDhmoUrfFSyBadAWptCcOP(exception)
   NJERvVGTwDhmoUrfFSyBadAWptCcIM.Init_ST_Total()
   return NJERvVGTwDhmoUrfFSyBadAWptCcjK
  if NJERvVGTwDhmoUrfFSyBadAWptCcIM.GetPolicyKey()==NJERvVGTwDhmoUrfFSyBadAWptCcjK:
   NJERvVGTwDhmoUrfFSyBadAWptCcIM.Init_ST_Total()
   return NJERvVGTwDhmoUrfFSyBadAWptCcjK
  '''
  https://players.brightcove.net/5764318566001/2SXVGLGl4_default/index.min.js
    options: {accountId: "5764318566001", policyKey: "BCpkADawqM072_NUcqm8RBVoMGIaio2x979NvYhN4Zrs685jLKKYmCx_ssySm_0HFSnwPKQIbaekH1PnWGFk-nQCtuky-DlMgN4KNvNlPYjsojAi1fU9ozEXVSpULPylDb8STvOgPf-F941V-RbByAkzD8CgApyhBS8TNN-yDc17gnFUj82OEBP8DEo" }  
  '''  
  return NJERvVGTwDhmoUrfFSyBadAWptCcjn
 def GetCredential(NJERvVGTwDhmoUrfFSyBadAWptCcIM,user_id,user_pw):
  try:
   NJERvVGTwDhmoUrfFSyBadAWptCcIY=base64.standard_b64encode(user_id.encode('UTF-8')).decode('utf-8')
   NJERvVGTwDhmoUrfFSyBadAWptCcIn=base64.standard_b64encode(user_pw.encode('UTF-8')).decode('utf-8')
   NJERvVGTwDhmoUrfFSyBadAWptCcPj=NJERvVGTwDhmoUrfFSyBadAWptCcIM.API_DOMAIN+'/api/v2/login'
   NJERvVGTwDhmoUrfFSyBadAWptCcIQ={'username':NJERvVGTwDhmoUrfFSyBadAWptCcIY,'password':NJERvVGTwDhmoUrfFSyBadAWptCcIn}
   NJERvVGTwDhmoUrfFSyBadAWptCcIQ=json.dumps(NJERvVGTwDhmoUrfFSyBadAWptCcIQ)
   NJERvVGTwDhmoUrfFSyBadAWptCcIK=NJERvVGTwDhmoUrfFSyBadAWptCcIM.callRequestCookies('Post',NJERvVGTwDhmoUrfFSyBadAWptCcPj,payload=NJERvVGTwDhmoUrfFSyBadAWptCcIQ,params=NJERvVGTwDhmoUrfFSyBadAWptCcjs,headers=NJERvVGTwDhmoUrfFSyBadAWptCcjs,cookies=NJERvVGTwDhmoUrfFSyBadAWptCcjs)
   NJERvVGTwDhmoUrfFSyBadAWptCcPO=json.loads(NJERvVGTwDhmoUrfFSyBadAWptCcIK.text)
   for NJERvVGTwDhmoUrfFSyBadAWptCcIx in NJERvVGTwDhmoUrfFSyBadAWptCcIK.cookies:
    if NJERvVGTwDhmoUrfFSyBadAWptCcIx.name=='SESSION':
     NJERvVGTwDhmoUrfFSyBadAWptCcIM.ST['cookies']['spotv_session']=NJERvVGTwDhmoUrfFSyBadAWptCcIx.value
     break
   if NJERvVGTwDhmoUrfFSyBadAWptCcIM.ST['cookies']['spotv_session']=='':
    NJERvVGTwDhmoUrfFSyBadAWptCcIM.Init_ST_Total()
    return NJERvVGTwDhmoUrfFSyBadAWptCcjK
   NJERvVGTwDhmoUrfFSyBadAWptCcIM.ST['cookies']['spotv_sessionid']=NJERvVGTwDhmoUrfFSyBadAWptCcjx(NJERvVGTwDhmoUrfFSyBadAWptCcPO['userId'])
   NJERvVGTwDhmoUrfFSyBadAWptCcPX=NJERvVGTwDhmoUrfFSyBadAWptCcIM.SPOTV_PMCODE+NJERvVGTwDhmoUrfFSyBadAWptCcjx(NJERvVGTwDhmoUrfFSyBadAWptCcPO['subEndTime'])
   NJERvVGTwDhmoUrfFSyBadAWptCcIM.ST['cookies']['spotv_subend'] =base64.standard_b64encode(NJERvVGTwDhmoUrfFSyBadAWptCcPX.encode()).decode('utf-8')
   if NJERvVGTwDhmoUrfFSyBadAWptCcIM.GetPolicyKey()==NJERvVGTwDhmoUrfFSyBadAWptCcjK:
    NJERvVGTwDhmoUrfFSyBadAWptCcIM.Init_ST_Total()
    return NJERvVGTwDhmoUrfFSyBadAWptCcjK
  except NJERvVGTwDhmoUrfFSyBadAWptCcOI as exception:
   NJERvVGTwDhmoUrfFSyBadAWptCcOP(exception)
   NJERvVGTwDhmoUrfFSyBadAWptCcIM.Init_ST_Total()
   return NJERvVGTwDhmoUrfFSyBadAWptCcjK
  return NJERvVGTwDhmoUrfFSyBadAWptCcjn
 def GetPolicyKey(NJERvVGTwDhmoUrfFSyBadAWptCcIM):
  try:
   NJERvVGTwDhmoUrfFSyBadAWptCcIs=NJERvVGTwDhmoUrfFSyBadAWptCcIM.GetMainJspath()
   if NJERvVGTwDhmoUrfFSyBadAWptCcIs=='':return NJERvVGTwDhmoUrfFSyBadAWptCcjK
   NJERvVGTwDhmoUrfFSyBadAWptCcIK=NJERvVGTwDhmoUrfFSyBadAWptCcIM.callRequestCookies('Get',NJERvVGTwDhmoUrfFSyBadAWptCcIs,payload=NJERvVGTwDhmoUrfFSyBadAWptCcjs,params=NJERvVGTwDhmoUrfFSyBadAWptCcjs,headers=NJERvVGTwDhmoUrfFSyBadAWptCcjs,cookies=NJERvVGTwDhmoUrfFSyBadAWptCcjs)
   NJERvVGTwDhmoUrfFSyBadAWptCcPi=NJERvVGTwDhmoUrfFSyBadAWptCcIK.text
   NJERvVGTwDhmoUrfFSyBadAWptCcPq =re.findall('accountId:\s*\"\d{13}\",\s*policyKey:\s*\".[^(){}]{100,300}\"',NJERvVGTwDhmoUrfFSyBadAWptCcPi)[0]
   NJERvVGTwDhmoUrfFSyBadAWptCcPq =NJERvVGTwDhmoUrfFSyBadAWptCcPq.replace('accountId','"accountId"')
   NJERvVGTwDhmoUrfFSyBadAWptCcPq =NJERvVGTwDhmoUrfFSyBadAWptCcPq.replace('policyKey','"policyKey"')
   NJERvVGTwDhmoUrfFSyBadAWptCcPq ='{'+NJERvVGTwDhmoUrfFSyBadAWptCcPq+'}'
   NJERvVGTwDhmoUrfFSyBadAWptCcPu=json.loads(NJERvVGTwDhmoUrfFSyBadAWptCcPq)
   NJERvVGTwDhmoUrfFSyBadAWptCcIM.ST['cookies']['spotv_accountId']=NJERvVGTwDhmoUrfFSyBadAWptCcPu['accountId']
   NJERvVGTwDhmoUrfFSyBadAWptCcIM.ST['cookies']['spotv_policyKey']=NJERvVGTwDhmoUrfFSyBadAWptCcPu['policyKey']
   NJERvVGTwDhmoUrfFSyBadAWptCcOP(NJERvVGTwDhmoUrfFSyBadAWptCcIM.ST['cookies'])
  except NJERvVGTwDhmoUrfFSyBadAWptCcOI as exception:
   NJERvVGTwDhmoUrfFSyBadAWptCcOP(exception)
   return NJERvVGTwDhmoUrfFSyBadAWptCcjK
  return NJERvVGTwDhmoUrfFSyBadAWptCcjn
 def GetBcPlayerUrl(NJERvVGTwDhmoUrfFSyBadAWptCcIM):
  NJERvVGTwDhmoUrfFSyBadAWptCcPb=''
  try:
   NJERvVGTwDhmoUrfFSyBadAWptCcIs=NJERvVGTwDhmoUrfFSyBadAWptCcIM.GetMainJspath()
   if NJERvVGTwDhmoUrfFSyBadAWptCcIs=='':return NJERvVGTwDhmoUrfFSyBadAWptCcPb
   NJERvVGTwDhmoUrfFSyBadAWptCcOP(NJERvVGTwDhmoUrfFSyBadAWptCcIs)
   NJERvVGTwDhmoUrfFSyBadAWptCcIK=NJERvVGTwDhmoUrfFSyBadAWptCcIM.callRequestCookies('Get',NJERvVGTwDhmoUrfFSyBadAWptCcIs,payload=NJERvVGTwDhmoUrfFSyBadAWptCcjs,params=NJERvVGTwDhmoUrfFSyBadAWptCcjs,headers=NJERvVGTwDhmoUrfFSyBadAWptCcjs,cookies=NJERvVGTwDhmoUrfFSyBadAWptCcjs)
   NJERvVGTwDhmoUrfFSyBadAWptCcPi=NJERvVGTwDhmoUrfFSyBadAWptCcIK.text
   NJERvVGTwDhmoUrfFSyBadAWptCcPL =r'default:{(.*?)}'
   NJERvVGTwDhmoUrfFSyBadAWptCcPz =re.compile(NJERvVGTwDhmoUrfFSyBadAWptCcPL).findall(NJERvVGTwDhmoUrfFSyBadAWptCcPi)[0]
   NJERvVGTwDhmoUrfFSyBadAWptCcPk=r'bc:"(.*?)"'
   NJERvVGTwDhmoUrfFSyBadAWptCcPl=re.compile(NJERvVGTwDhmoUrfFSyBadAWptCcPk).findall(NJERvVGTwDhmoUrfFSyBadAWptCcPz)[0]
   NJERvVGTwDhmoUrfFSyBadAWptCcPH=r'":"(.*?)"'
   NJERvVGTwDhmoUrfFSyBadAWptCcPg=re.compile(NJERvVGTwDhmoUrfFSyBadAWptCcPH).findall(NJERvVGTwDhmoUrfFSyBadAWptCcPz)[0]
   NJERvVGTwDhmoUrfFSyBadAWptCcPb="%s/%s/%s_default/index.min.js"%(NJERvVGTwDhmoUrfFSyBadAWptCcIM.BC_DOMAIN,NJERvVGTwDhmoUrfFSyBadAWptCcPl,NJERvVGTwDhmoUrfFSyBadAWptCcPg)
  except NJERvVGTwDhmoUrfFSyBadAWptCcOI as exception:
   NJERvVGTwDhmoUrfFSyBadAWptCcOP(exception)
  return NJERvVGTwDhmoUrfFSyBadAWptCcPb
 def GetMainJspath(NJERvVGTwDhmoUrfFSyBadAWptCcIM):
  NJERvVGTwDhmoUrfFSyBadAWptCcPe=''
  try:
   NJERvVGTwDhmoUrfFSyBadAWptCcIs=NJERvVGTwDhmoUrfFSyBadAWptCcIM.API_DOMAIN
   NJERvVGTwDhmoUrfFSyBadAWptCcIK=NJERvVGTwDhmoUrfFSyBadAWptCcIM.callRequestCookies('Get',NJERvVGTwDhmoUrfFSyBadAWptCcIs,payload=NJERvVGTwDhmoUrfFSyBadAWptCcjs,params=NJERvVGTwDhmoUrfFSyBadAWptCcjs,headers=NJERvVGTwDhmoUrfFSyBadAWptCcjs,cookies=NJERvVGTwDhmoUrfFSyBadAWptCcjs)
   NJERvVGTwDhmoUrfFSyBadAWptCcPi=NJERvVGTwDhmoUrfFSyBadAWptCcIK.text
   NJERvVGTwDhmoUrfFSyBadAWptCcPq =re.findall('https://cdn.spotvnow.co.kr/dist/js/.{20}\.js',NJERvVGTwDhmoUrfFSyBadAWptCcPi)[0]
   NJERvVGTwDhmoUrfFSyBadAWptCcPe=NJERvVGTwDhmoUrfFSyBadAWptCcPq
  except NJERvVGTwDhmoUrfFSyBadAWptCcOI as exception:
   NJERvVGTwDhmoUrfFSyBadAWptCcOP(exception)
  return NJERvVGTwDhmoUrfFSyBadAWptCcPe
 def Get_Now_Datetime(NJERvVGTwDhmoUrfFSyBadAWptCcIM):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetLiveChannelList(NJERvVGTwDhmoUrfFSyBadAWptCcIM):
  NJERvVGTwDhmoUrfFSyBadAWptCcPK=[]
  NJERvVGTwDhmoUrfFSyBadAWptCcPx ={}
  try:
   NJERvVGTwDhmoUrfFSyBadAWptCcIs=NJERvVGTwDhmoUrfFSyBadAWptCcIM.API_DOMAIN+'/api/v3/channel'
   NJERvVGTwDhmoUrfFSyBadAWptCcIK=NJERvVGTwDhmoUrfFSyBadAWptCcIM.callRequestCookies('Get',NJERvVGTwDhmoUrfFSyBadAWptCcIs,payload=NJERvVGTwDhmoUrfFSyBadAWptCcjs,params=NJERvVGTwDhmoUrfFSyBadAWptCcjs,headers=NJERvVGTwDhmoUrfFSyBadAWptCcjs,cookies=NJERvVGTwDhmoUrfFSyBadAWptCcjs)
   NJERvVGTwDhmoUrfFSyBadAWptCcPO=json.loads(NJERvVGTwDhmoUrfFSyBadAWptCcIK.text)
   NJERvVGTwDhmoUrfFSyBadAWptCcPx=NJERvVGTwDhmoUrfFSyBadAWptCcIM.GetEPGList()
   for NJERvVGTwDhmoUrfFSyBadAWptCcPY in NJERvVGTwDhmoUrfFSyBadAWptCcPO:
    NJERvVGTwDhmoUrfFSyBadAWptCcPn={'id':NJERvVGTwDhmoUrfFSyBadAWptCcPY['id'],'name':NJERvVGTwDhmoUrfFSyBadAWptCcPY['name'],'logo':NJERvVGTwDhmoUrfFSyBadAWptCcPY['logo'],'free':NJERvVGTwDhmoUrfFSyBadAWptCcPY['free'],'programName':NJERvVGTwDhmoUrfFSyBadAWptCcPY['programName'],'channelepg':NJERvVGTwDhmoUrfFSyBadAWptCcPx.get(NJERvVGTwDhmoUrfFSyBadAWptCcPY['id']),}
    NJERvVGTwDhmoUrfFSyBadAWptCcPK.append(NJERvVGTwDhmoUrfFSyBadAWptCcPn)
  except NJERvVGTwDhmoUrfFSyBadAWptCcOI as exception:
   NJERvVGTwDhmoUrfFSyBadAWptCcOP(exception)
  return NJERvVGTwDhmoUrfFSyBadAWptCcPK
 def GetHlsUrl(NJERvVGTwDhmoUrfFSyBadAWptCcIM,mediacode):
  NJERvVGTwDhmoUrfFSyBadAWptCcPQ=''
  try:
   NJERvVGTwDhmoUrfFSyBadAWptCcIs='{}/api/v3/channel/di/con/sec/web/{}'.format(NJERvVGTwDhmoUrfFSyBadAWptCcIM.API_DOMAIN,mediacode)
   NJERvVGTwDhmoUrfFSyBadAWptCcIK=NJERvVGTwDhmoUrfFSyBadAWptCcIM.callRequestCookies('Get',NJERvVGTwDhmoUrfFSyBadAWptCcIs,payload=NJERvVGTwDhmoUrfFSyBadAWptCcjs,params=NJERvVGTwDhmoUrfFSyBadAWptCcjs,headers=NJERvVGTwDhmoUrfFSyBadAWptCcjs,cookies=NJERvVGTwDhmoUrfFSyBadAWptCcjs)
   NJERvVGTwDhmoUrfFSyBadAWptCcPI=json.loads(NJERvVGTwDhmoUrfFSyBadAWptCcIK.text)
   NJERvVGTwDhmoUrfFSyBadAWptCcPQ=NJERvVGTwDhmoUrfFSyBadAWptCcPI['hlsDrmUrl']
   NJERvVGTwDhmoUrfFSyBadAWptCcXI =NJERvVGTwDhmoUrfFSyBadAWptCcPI['cid']
  except NJERvVGTwDhmoUrfFSyBadAWptCcOI as exception:
   NJERvVGTwDhmoUrfFSyBadAWptCcOP(exception)
  return NJERvVGTwDhmoUrfFSyBadAWptCcXI,NJERvVGTwDhmoUrfFSyBadAWptCcPQ
 def GetEPGList(NJERvVGTwDhmoUrfFSyBadAWptCcIM):
  NJERvVGTwDhmoUrfFSyBadAWptCcXP={}
  NJERvVGTwDhmoUrfFSyBadAWptCcXM=NJERvVGTwDhmoUrfFSyBadAWptCcIM.Get_Now_Datetime()
  NJERvVGTwDhmoUrfFSyBadAWptCcXj=NJERvVGTwDhmoUrfFSyBadAWptCcXM.strftime('%Y%m%d%H%M')
  NJERvVGTwDhmoUrfFSyBadAWptCcXO='%s-%s-%s'%(NJERvVGTwDhmoUrfFSyBadAWptCcXj[0:4],NJERvVGTwDhmoUrfFSyBadAWptCcXj[4:6],NJERvVGTwDhmoUrfFSyBadAWptCcXj[6:8])
  NJERvVGTwDhmoUrfFSyBadAWptCcXi=(NJERvVGTwDhmoUrfFSyBadAWptCcXM+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M')
  try:
   NJERvVGTwDhmoUrfFSyBadAWptCcIs=NJERvVGTwDhmoUrfFSyBadAWptCcIM.API_DOMAIN+'/api/v3/program/'+NJERvVGTwDhmoUrfFSyBadAWptCcXO
   NJERvVGTwDhmoUrfFSyBadAWptCcIK=NJERvVGTwDhmoUrfFSyBadAWptCcIM.callRequestCookies('Get',NJERvVGTwDhmoUrfFSyBadAWptCcIs,payload=NJERvVGTwDhmoUrfFSyBadAWptCcjs,params=NJERvVGTwDhmoUrfFSyBadAWptCcjs,headers=NJERvVGTwDhmoUrfFSyBadAWptCcjs,cookies=NJERvVGTwDhmoUrfFSyBadAWptCcjs)
   NJERvVGTwDhmoUrfFSyBadAWptCcPO=json.loads(NJERvVGTwDhmoUrfFSyBadAWptCcIK.text)
   NJERvVGTwDhmoUrfFSyBadAWptCcXq=-1 
   NJERvVGTwDhmoUrfFSyBadAWptCcXu =''
   for NJERvVGTwDhmoUrfFSyBadAWptCcPY in NJERvVGTwDhmoUrfFSyBadAWptCcPO:
    NJERvVGTwDhmoUrfFSyBadAWptCcXb=NJERvVGTwDhmoUrfFSyBadAWptCcPY['channelId']
    NJERvVGTwDhmoUrfFSyBadAWptCcXL =NJERvVGTwDhmoUrfFSyBadAWptCcPY['startTime'].replace('-','').replace(' ','').replace(':','')
    NJERvVGTwDhmoUrfFSyBadAWptCcXz =NJERvVGTwDhmoUrfFSyBadAWptCcPY['endTime'].replace('-','').replace(' ','').replace(':','')
    if NJERvVGTwDhmoUrfFSyBadAWptCcjQ(NJERvVGTwDhmoUrfFSyBadAWptCcXj)>NJERvVGTwDhmoUrfFSyBadAWptCcjQ(NJERvVGTwDhmoUrfFSyBadAWptCcXz) :continue
    if NJERvVGTwDhmoUrfFSyBadAWptCcjQ(NJERvVGTwDhmoUrfFSyBadAWptCcXi)<NJERvVGTwDhmoUrfFSyBadAWptCcjQ(NJERvVGTwDhmoUrfFSyBadAWptCcXL):continue
    if NJERvVGTwDhmoUrfFSyBadAWptCcXq!=NJERvVGTwDhmoUrfFSyBadAWptCcXb:
     if NJERvVGTwDhmoUrfFSyBadAWptCcXu!='':NJERvVGTwDhmoUrfFSyBadAWptCcXP[NJERvVGTwDhmoUrfFSyBadAWptCcXq]=NJERvVGTwDhmoUrfFSyBadAWptCcXu
     NJERvVGTwDhmoUrfFSyBadAWptCcXq=NJERvVGTwDhmoUrfFSyBadAWptCcXb
     NJERvVGTwDhmoUrfFSyBadAWptCcXu =''
    if NJERvVGTwDhmoUrfFSyBadAWptCcXu:NJERvVGTwDhmoUrfFSyBadAWptCcXu+='\n'
    NJERvVGTwDhmoUrfFSyBadAWptCcXu+=NJERvVGTwDhmoUrfFSyBadAWptCcPY['title']+'\n'
    NJERvVGTwDhmoUrfFSyBadAWptCcXu+=' [%s ~ %s]'%(NJERvVGTwDhmoUrfFSyBadAWptCcPY['startTime'][-5:],NJERvVGTwDhmoUrfFSyBadAWptCcPY['endTime'][-5:])+'\n'
   if NJERvVGTwDhmoUrfFSyBadAWptCcXu:NJERvVGTwDhmoUrfFSyBadAWptCcXP[NJERvVGTwDhmoUrfFSyBadAWptCcXq]=NJERvVGTwDhmoUrfFSyBadAWptCcXu
  except NJERvVGTwDhmoUrfFSyBadAWptCcOI as exception:
   NJERvVGTwDhmoUrfFSyBadAWptCcOP(exception)
  return NJERvVGTwDhmoUrfFSyBadAWptCcXP
 def GetEPGList_new(NJERvVGTwDhmoUrfFSyBadAWptCcIM):
  NJERvVGTwDhmoUrfFSyBadAWptCcXP={}
  NJERvVGTwDhmoUrfFSyBadAWptCcXM=NJERvVGTwDhmoUrfFSyBadAWptCcIM.Get_Now_Datetime()
  NJERvVGTwDhmoUrfFSyBadAWptCcXj=NJERvVGTwDhmoUrfFSyBadAWptCcXM.strftime('%Y%m%d%H%M00')
  NJERvVGTwDhmoUrfFSyBadAWptCcXO='%s%s%s'%(NJERvVGTwDhmoUrfFSyBadAWptCcXj[0:4],NJERvVGTwDhmoUrfFSyBadAWptCcXj[4:6],NJERvVGTwDhmoUrfFSyBadAWptCcXj[6:8])
  NJERvVGTwDhmoUrfFSyBadAWptCcXi=(NJERvVGTwDhmoUrfFSyBadAWptCcXM+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M00')
  try:
   for NJERvVGTwDhmoUrfFSyBadAWptCcPY in LIVETV_LIST:
    NJERvVGTwDhmoUrfFSyBadAWptCcXk =NJERvVGTwDhmoUrfFSyBadAWptCcPY['videoId']
    if NJERvVGTwDhmoUrfFSyBadAWptCcPY['epgtype']=='spotvon':
     NJERvVGTwDhmoUrfFSyBadAWptCcXu=NJERvVGTwDhmoUrfFSyBadAWptCcIM.Get_EpgInfo_Spotv_spotvon(NJERvVGTwDhmoUrfFSyBadAWptCcXk,NJERvVGTwDhmoUrfFSyBadAWptCcPY['epgnm'],NJERvVGTwDhmoUrfFSyBadAWptCcXO)
     NJERvVGTwDhmoUrfFSyBadAWptCcXP[NJERvVGTwDhmoUrfFSyBadAWptCcXk]=NJERvVGTwDhmoUrfFSyBadAWptCcXu
    if NJERvVGTwDhmoUrfFSyBadAWptCcPY['epgtype']=='spotvnet':
     NJERvVGTwDhmoUrfFSyBadAWptCcXu=NJERvVGTwDhmoUrfFSyBadAWptCcIM.Get_EpgInfo_Spotv_spotvnet(NJERvVGTwDhmoUrfFSyBadAWptCcXk,NJERvVGTwDhmoUrfFSyBadAWptCcPY['epgnm'],NJERvVGTwDhmoUrfFSyBadAWptCcXO)
     NJERvVGTwDhmoUrfFSyBadAWptCcXP[NJERvVGTwDhmoUrfFSyBadAWptCcXk]=NJERvVGTwDhmoUrfFSyBadAWptCcXu
   for NJERvVGTwDhmoUrfFSyBadAWptCcXl in NJERvVGTwDhmoUrfFSyBadAWptCcXP.keys():
    if NJERvVGTwDhmoUrfFSyBadAWptCcOX(NJERvVGTwDhmoUrfFSyBadAWptCcXP.get(NJERvVGTwDhmoUrfFSyBadAWptCcXl))==0:continue
    NJERvVGTwDhmoUrfFSyBadAWptCcXu =''
    NJERvVGTwDhmoUrfFSyBadAWptCcXH=''
    for NJERvVGTwDhmoUrfFSyBadAWptCcXg in NJERvVGTwDhmoUrfFSyBadAWptCcXP.get(NJERvVGTwDhmoUrfFSyBadAWptCcXl):
     NJERvVGTwDhmoUrfFSyBadAWptCcXL =NJERvVGTwDhmoUrfFSyBadAWptCcXg['startTime']
     NJERvVGTwDhmoUrfFSyBadAWptCcXz =NJERvVGTwDhmoUrfFSyBadAWptCcXg['endTime']
     if NJERvVGTwDhmoUrfFSyBadAWptCcjQ(NJERvVGTwDhmoUrfFSyBadAWptCcXj)>NJERvVGTwDhmoUrfFSyBadAWptCcjQ(NJERvVGTwDhmoUrfFSyBadAWptCcXz) :continue
     if NJERvVGTwDhmoUrfFSyBadAWptCcjQ(NJERvVGTwDhmoUrfFSyBadAWptCcXi)<NJERvVGTwDhmoUrfFSyBadAWptCcjQ(NJERvVGTwDhmoUrfFSyBadAWptCcXL):continue
     if NJERvVGTwDhmoUrfFSyBadAWptCcjQ(NJERvVGTwDhmoUrfFSyBadAWptCcXj)>=NJERvVGTwDhmoUrfFSyBadAWptCcjQ(NJERvVGTwDhmoUrfFSyBadAWptCcXL)and NJERvVGTwDhmoUrfFSyBadAWptCcjQ(NJERvVGTwDhmoUrfFSyBadAWptCcXj)<NJERvVGTwDhmoUrfFSyBadAWptCcjQ(NJERvVGTwDhmoUrfFSyBadAWptCcXz):NJERvVGTwDhmoUrfFSyBadAWptCcXH=NJERvVGTwDhmoUrfFSyBadAWptCcIM.xmlText(NJERvVGTwDhmoUrfFSyBadAWptCcXg['title'])
     if NJERvVGTwDhmoUrfFSyBadAWptCcXu:NJERvVGTwDhmoUrfFSyBadAWptCcXu+='\n'
     NJERvVGTwDhmoUrfFSyBadAWptCcXu+=NJERvVGTwDhmoUrfFSyBadAWptCcIM.xmlText(NJERvVGTwDhmoUrfFSyBadAWptCcXg['title'])+'\n'
     NJERvVGTwDhmoUrfFSyBadAWptCcXu+=' [%s:%s ~ %s:%s]'%(NJERvVGTwDhmoUrfFSyBadAWptCcXg['startTime'][8:10],NJERvVGTwDhmoUrfFSyBadAWptCcXg['startTime'][10:12],NJERvVGTwDhmoUrfFSyBadAWptCcXg['endTime'][8:10],NJERvVGTwDhmoUrfFSyBadAWptCcXg['endTime'][10:12])+'\n'
    NJERvVGTwDhmoUrfFSyBadAWptCcXP[NJERvVGTwDhmoUrfFSyBadAWptCcXl]={'epg':NJERvVGTwDhmoUrfFSyBadAWptCcXu,'title':NJERvVGTwDhmoUrfFSyBadAWptCcXH}
  except NJERvVGTwDhmoUrfFSyBadAWptCcOI as exception:
   NJERvVGTwDhmoUrfFSyBadAWptCcOP(exception)
  return NJERvVGTwDhmoUrfFSyBadAWptCcXP
 def Get_EpgInfo_Spotv_spotvon(NJERvVGTwDhmoUrfFSyBadAWptCcIM,NJERvVGTwDhmoUrfFSyBadAWptCcXk,epgnm,now_day):
  NJERvVGTwDhmoUrfFSyBadAWptCcXP =[]
  try:
   NJERvVGTwDhmoUrfFSyBadAWptCcIs='https://www.spotvon.co.kr/data/onAir/%s/Daily/D%s.asp'%(epgnm,now_day)
   NJERvVGTwDhmoUrfFSyBadAWptCcIK=NJERvVGTwDhmoUrfFSyBadAWptCcIM.callRequestCookies('Get',NJERvVGTwDhmoUrfFSyBadAWptCcIs,payload=NJERvVGTwDhmoUrfFSyBadAWptCcjs,params=NJERvVGTwDhmoUrfFSyBadAWptCcjs,headers=NJERvVGTwDhmoUrfFSyBadAWptCcjs,cookies=NJERvVGTwDhmoUrfFSyBadAWptCcjs)
   NJERvVGTwDhmoUrfFSyBadAWptCcPI=json.loads(NJERvVGTwDhmoUrfFSyBadAWptCcIK.text)
   for NJERvVGTwDhmoUrfFSyBadAWptCcPY in NJERvVGTwDhmoUrfFSyBadAWptCcPI:
    NJERvVGTwDhmoUrfFSyBadAWptCcPn={'title':NJERvVGTwDhmoUrfFSyBadAWptCcPY['title'],'startTime':NJERvVGTwDhmoUrfFSyBadAWptCcPY['sch_date'].replace('-','')+NJERvVGTwDhmoUrfFSyBadAWptCcjx(NJERvVGTwDhmoUrfFSyBadAWptCcPY['sch_hour']).zfill(2)+NJERvVGTwDhmoUrfFSyBadAWptCcPY['sch_min']+'00'}
    NJERvVGTwDhmoUrfFSyBadAWptCcXP.append(NJERvVGTwDhmoUrfFSyBadAWptCcPn)
   for i in NJERvVGTwDhmoUrfFSyBadAWptCcOM(NJERvVGTwDhmoUrfFSyBadAWptCcOX(NJERvVGTwDhmoUrfFSyBadAWptCcXP)):
    if i>0:NJERvVGTwDhmoUrfFSyBadAWptCcXP[i-1]['endTime']=NJERvVGTwDhmoUrfFSyBadAWptCcXP[i]['startTime']
    if i==NJERvVGTwDhmoUrfFSyBadAWptCcOX(NJERvVGTwDhmoUrfFSyBadAWptCcXP)-1: NJERvVGTwDhmoUrfFSyBadAWptCcXP[i]['endTime']=now_day+'240000'
  except NJERvVGTwDhmoUrfFSyBadAWptCcOI as exception:
   NJERvVGTwDhmoUrfFSyBadAWptCcOP(exception)
   return[]
  return NJERvVGTwDhmoUrfFSyBadAWptCcXP
 def Get_EpgInfo_Spotv_spotvnet(NJERvVGTwDhmoUrfFSyBadAWptCcIM,NJERvVGTwDhmoUrfFSyBadAWptCcXk,epgnm,now_day):
  NJERvVGTwDhmoUrfFSyBadAWptCcXP =[]
  try:
   NJERvVGTwDhmoUrfFSyBadAWptCcIs='https://www.spotv.net/data/json/schedule/%s/Daily/D%s.json'%(epgnm,now_day)
   NJERvVGTwDhmoUrfFSyBadAWptCcIK=NJERvVGTwDhmoUrfFSyBadAWptCcIM.callRequestCookies('Get',NJERvVGTwDhmoUrfFSyBadAWptCcIs,payload=NJERvVGTwDhmoUrfFSyBadAWptCcjs,params=NJERvVGTwDhmoUrfFSyBadAWptCcjs,headers=NJERvVGTwDhmoUrfFSyBadAWptCcjs,cookies=NJERvVGTwDhmoUrfFSyBadAWptCcjs)
   NJERvVGTwDhmoUrfFSyBadAWptCcPI=json.loads(NJERvVGTwDhmoUrfFSyBadAWptCcIK.text)
   for NJERvVGTwDhmoUrfFSyBadAWptCcPY in NJERvVGTwDhmoUrfFSyBadAWptCcPI:
    NJERvVGTwDhmoUrfFSyBadAWptCcPn={'title':NJERvVGTwDhmoUrfFSyBadAWptCcPY['title'],'startTime':NJERvVGTwDhmoUrfFSyBadAWptCcPY['sch_date'].replace('-','')+NJERvVGTwDhmoUrfFSyBadAWptCcjx(NJERvVGTwDhmoUrfFSyBadAWptCcPY['sch_hour']).zfill(2)+NJERvVGTwDhmoUrfFSyBadAWptCcPY['sch_min']+'00'}
    NJERvVGTwDhmoUrfFSyBadAWptCcXP.append(NJERvVGTwDhmoUrfFSyBadAWptCcPn)
   for i in NJERvVGTwDhmoUrfFSyBadAWptCcOM(NJERvVGTwDhmoUrfFSyBadAWptCcOX(NJERvVGTwDhmoUrfFSyBadAWptCcXP)):
    if i>0:NJERvVGTwDhmoUrfFSyBadAWptCcXP[i-1]['endTime']=NJERvVGTwDhmoUrfFSyBadAWptCcXP[i]['startTime']
    if i==NJERvVGTwDhmoUrfFSyBadAWptCcOX(NJERvVGTwDhmoUrfFSyBadAWptCcXP)-1: NJERvVGTwDhmoUrfFSyBadAWptCcXP[i]['endTime']=now_day+'240000'
  except NJERvVGTwDhmoUrfFSyBadAWptCcOI as exception:
   NJERvVGTwDhmoUrfFSyBadAWptCcOP(exception)
   return[]
  return NJERvVGTwDhmoUrfFSyBadAWptCcXP
 def GetEventLiveList(NJERvVGTwDhmoUrfFSyBadAWptCcIM):
  NJERvVGTwDhmoUrfFSyBadAWptCcPK=[]
  NJERvVGTwDhmoUrfFSyBadAWptCcXe =0
  try:
   NJERvVGTwDhmoUrfFSyBadAWptCcXs=NJERvVGTwDhmoUrfFSyBadAWptCcIM.Get_Now_Datetime()
   NJERvVGTwDhmoUrfFSyBadAWptCcXK=NJERvVGTwDhmoUrfFSyBadAWptCcXs.strftime('%Y-%m-%d')
  except NJERvVGTwDhmoUrfFSyBadAWptCcOI as exception:
   NJERvVGTwDhmoUrfFSyBadAWptCcOP(exception)
   return NJERvVGTwDhmoUrfFSyBadAWptCcPK,NJERvVGTwDhmoUrfFSyBadAWptCcXe
  NJERvVGTwDhmoUrfFSyBadAWptCcIs=NJERvVGTwDhmoUrfFSyBadAWptCcIM.API_DOMAIN+'/api/v3/player/lives/'+NJERvVGTwDhmoUrfFSyBadAWptCcXK 
  NJERvVGTwDhmoUrfFSyBadAWptCcIl=NJERvVGTwDhmoUrfFSyBadAWptCcIM.makeDefaultCookies()
  NJERvVGTwDhmoUrfFSyBadAWptCcIK=NJERvVGTwDhmoUrfFSyBadAWptCcIM.callRequestCookies('Get',NJERvVGTwDhmoUrfFSyBadAWptCcIs,payload=NJERvVGTwDhmoUrfFSyBadAWptCcjs,params=NJERvVGTwDhmoUrfFSyBadAWptCcjs,headers=NJERvVGTwDhmoUrfFSyBadAWptCcjs,cookies=NJERvVGTwDhmoUrfFSyBadAWptCcIl)
  NJERvVGTwDhmoUrfFSyBadAWptCcXe=NJERvVGTwDhmoUrfFSyBadAWptCcIK.status_code 
  if NJERvVGTwDhmoUrfFSyBadAWptCcXe!=200:return NJERvVGTwDhmoUrfFSyBadAWptCcPK,NJERvVGTwDhmoUrfFSyBadAWptCcXe
  NJERvVGTwDhmoUrfFSyBadAWptCcPO=json.loads(NJERvVGTwDhmoUrfFSyBadAWptCcIK.text)
  for NJERvVGTwDhmoUrfFSyBadAWptCcXx in NJERvVGTwDhmoUrfFSyBadAWptCcPO:
   for NJERvVGTwDhmoUrfFSyBadAWptCcPY in NJERvVGTwDhmoUrfFSyBadAWptCcXx['liveNowList']:
    if NJERvVGTwDhmoUrfFSyBadAWptCcPY['gameDesc']['title']==NJERvVGTwDhmoUrfFSyBadAWptCcjs or NJERvVGTwDhmoUrfFSyBadAWptCcPY['gameDesc']['title']=='':
     NJERvVGTwDhmoUrfFSyBadAWptCcXY='%s ( %s : %s )'%(NJERvVGTwDhmoUrfFSyBadAWptCcPY['leagueName'],NJERvVGTwDhmoUrfFSyBadAWptCcPY['homeNameShort'],NJERvVGTwDhmoUrfFSyBadAWptCcPY['awayNameShort'])
    else:
     NJERvVGTwDhmoUrfFSyBadAWptCcXY=NJERvVGTwDhmoUrfFSyBadAWptCcPY['gameDesc']['title']
    NJERvVGTwDhmoUrfFSyBadAWptCcPn={'liveId':NJERvVGTwDhmoUrfFSyBadAWptCcPY['liveId'],'title':NJERvVGTwDhmoUrfFSyBadAWptCcXY,'logo':NJERvVGTwDhmoUrfFSyBadAWptCcPY['gameDesc']['leagueLogo'],'free':NJERvVGTwDhmoUrfFSyBadAWptCcPY['isFree'],'startTime':NJERvVGTwDhmoUrfFSyBadAWptCcPY['startTime']}
    NJERvVGTwDhmoUrfFSyBadAWptCcPK.append(NJERvVGTwDhmoUrfFSyBadAWptCcPn)
  return NJERvVGTwDhmoUrfFSyBadAWptCcPK,NJERvVGTwDhmoUrfFSyBadAWptCcXe
 def GetEventLive_videoId(NJERvVGTwDhmoUrfFSyBadAWptCcIM,liveId):
  NJERvVGTwDhmoUrfFSyBadAWptCcXn=''
  try:
   NJERvVGTwDhmoUrfFSyBadAWptCcIs=NJERvVGTwDhmoUrfFSyBadAWptCcIM.API_DOMAIN+'/api/v3/live/'+liveId
   NJERvVGTwDhmoUrfFSyBadAWptCcIK=NJERvVGTwDhmoUrfFSyBadAWptCcIM.callRequestCookies('Get',NJERvVGTwDhmoUrfFSyBadAWptCcIs,payload=NJERvVGTwDhmoUrfFSyBadAWptCcjs,params=NJERvVGTwDhmoUrfFSyBadAWptCcjs,headers=NJERvVGTwDhmoUrfFSyBadAWptCcjs,cookies=NJERvVGTwDhmoUrfFSyBadAWptCcjs)
   NJERvVGTwDhmoUrfFSyBadAWptCcPO=json.loads(NJERvVGTwDhmoUrfFSyBadAWptCcIK.text)
   NJERvVGTwDhmoUrfFSyBadAWptCcXQ=NJERvVGTwDhmoUrfFSyBadAWptCcPO['videoId']
   NJERvVGTwDhmoUrfFSyBadAWptCcXn=NJERvVGTwDhmoUrfFSyBadAWptCcXQ.replace('ref:','')
  except NJERvVGTwDhmoUrfFSyBadAWptCcOI as exception:
   NJERvVGTwDhmoUrfFSyBadAWptCcOP(exception)
  return NJERvVGTwDhmoUrfFSyBadAWptCcXn
 def CheckMainEnd(NJERvVGTwDhmoUrfFSyBadAWptCcIM):
  NJERvVGTwDhmoUrfFSyBadAWptCcMI=NJERvVGTwDhmoUrfFSyBadAWptCcIM.SPOTV_PMCODE+NJERvVGTwDhmoUrfFSyBadAWptCcjx(NJERvVGTwDhmoUrfFSyBadAWptCcIM.ST['cookies']['spotv_sessionid'])
  NJERvVGTwDhmoUrfFSyBadAWptCcMI=base64.standard_b64encode(NJERvVGTwDhmoUrfFSyBadAWptCcMI.encode()).decode('utf-8')
  if NJERvVGTwDhmoUrfFSyBadAWptCcMI=='OTg3MTgzMzM0Ng==' or NJERvVGTwDhmoUrfFSyBadAWptCcMI=='OTg3MTgzMzExNw==':return NJERvVGTwDhmoUrfFSyBadAWptCcjn
  return NJERvVGTwDhmoUrfFSyBadAWptCcjK
 def CheckSubEnd(NJERvVGTwDhmoUrfFSyBadAWptCcIM):
  NJERvVGTwDhmoUrfFSyBadAWptCcIL=NJERvVGTwDhmoUrfFSyBadAWptCcjK
  try:
   if NJERvVGTwDhmoUrfFSyBadAWptCcIM.CheckMainEnd():return NJERvVGTwDhmoUrfFSyBadAWptCcjn 
   NJERvVGTwDhmoUrfFSyBadAWptCcMP=base64.standard_b64decode(NJERvVGTwDhmoUrfFSyBadAWptCcIM.ST['cookies']['spotv_subend']).decode('utf-8')[NJERvVGTwDhmoUrfFSyBadAWptCcIM.SPOTV_PMSIZE:]
   if NJERvVGTwDhmoUrfFSyBadAWptCcMP=='0':return NJERvVGTwDhmoUrfFSyBadAWptCcIL
   NJERvVGTwDhmoUrfFSyBadAWptCcMX =NJERvVGTwDhmoUrfFSyBadAWptCcjQ(NJERvVGTwDhmoUrfFSyBadAWptCcIM.Get_Now_Datetime().strftime('%Y%m%d'))
   NJERvVGTwDhmoUrfFSyBadAWptCcMj =NJERvVGTwDhmoUrfFSyBadAWptCcjQ(NJERvVGTwDhmoUrfFSyBadAWptCcMP)/1000
   NJERvVGTwDhmoUrfFSyBadAWptCcMO =NJERvVGTwDhmoUrfFSyBadAWptCcjQ(datetime.datetime.fromtimestamp(NJERvVGTwDhmoUrfFSyBadAWptCcMj,datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul')).strftime('%Y%m%d'))
   if NJERvVGTwDhmoUrfFSyBadAWptCcMX<=NJERvVGTwDhmoUrfFSyBadAWptCcMO:NJERvVGTwDhmoUrfFSyBadAWptCcIL=NJERvVGTwDhmoUrfFSyBadAWptCcjn
  except NJERvVGTwDhmoUrfFSyBadAWptCcOI as exception:
   NJERvVGTwDhmoUrfFSyBadAWptCcOP(exception)
   return NJERvVGTwDhmoUrfFSyBadAWptCcIL
  return NJERvVGTwDhmoUrfFSyBadAWptCcIL
 def GetBroadURL(NJERvVGTwDhmoUrfFSyBadAWptCcIM,NJERvVGTwDhmoUrfFSyBadAWptCcXn,mediatype,NJERvVGTwDhmoUrfFSyBadAWptCcMH):
  NJERvVGTwDhmoUrfFSyBadAWptCcMi=''
  try:
   if mediatype=='live':
    NJERvVGTwDhmoUrfFSyBadAWptCcIs='{}/api/v3/live/di/con/sec/web/{}'.format(NJERvVGTwDhmoUrfFSyBadAWptCcIM.API_DOMAIN,NJERvVGTwDhmoUrfFSyBadAWptCcXn)
   else:
    NJERvVGTwDhmoUrfFSyBadAWptCcXn=NJERvVGTwDhmoUrfFSyBadAWptCcIM.GetReplay_UrlId(NJERvVGTwDhmoUrfFSyBadAWptCcXn,NJERvVGTwDhmoUrfFSyBadAWptCcMH)
    if NJERvVGTwDhmoUrfFSyBadAWptCcXn=='':return NJERvVGTwDhmoUrfFSyBadAWptCcMi
    NJERvVGTwDhmoUrfFSyBadAWptCcIs=NJERvVGTwDhmoUrfFSyBadAWptCcIM.PLAYER_DOMAIN+'/playback/v1/accounts/'+NJERvVGTwDhmoUrfFSyBadAWptCcjx(NJERvVGTwDhmoUrfFSyBadAWptCcIM.ST['cookies']['spotv_accountId'])+'/videos/'+NJERvVGTwDhmoUrfFSyBadAWptCcXn
   NJERvVGTwDhmoUrfFSyBadAWptCcIH=NJERvVGTwDhmoUrfFSyBadAWptCcIM.makeDefaultHeaders()
   NJERvVGTwDhmoUrfFSyBadAWptCcIK=NJERvVGTwDhmoUrfFSyBadAWptCcIM.callRequestCookies('Get',NJERvVGTwDhmoUrfFSyBadAWptCcIs,payload=NJERvVGTwDhmoUrfFSyBadAWptCcjs,params=NJERvVGTwDhmoUrfFSyBadAWptCcjs,headers=NJERvVGTwDhmoUrfFSyBadAWptCcIH,cookies=NJERvVGTwDhmoUrfFSyBadAWptCcjs)
   NJERvVGTwDhmoUrfFSyBadAWptCcPI=json.loads(NJERvVGTwDhmoUrfFSyBadAWptCcIK.text)
   NJERvVGTwDhmoUrfFSyBadAWptCcOP(NJERvVGTwDhmoUrfFSyBadAWptCcIs)
   if mediatype=='live':
    NJERvVGTwDhmoUrfFSyBadAWptCcMi=NJERvVGTwDhmoUrfFSyBadAWptCcPI['hlsDrmUrl']
    NJERvVGTwDhmoUrfFSyBadAWptCcXI =NJERvVGTwDhmoUrfFSyBadAWptCcPI['cid']
   else:
    NJERvVGTwDhmoUrfFSyBadAWptCcOP(NJERvVGTwDhmoUrfFSyBadAWptCcPI)
    NJERvVGTwDhmoUrfFSyBadAWptCcMi=NJERvVGTwDhmoUrfFSyBadAWptCcPI['sources'][0]['src']
    NJERvVGTwDhmoUrfFSyBadAWptCcXI =''
   NJERvVGTwDhmoUrfFSyBadAWptCcMi=NJERvVGTwDhmoUrfFSyBadAWptCcMi.replace('http://','https://')
  except NJERvVGTwDhmoUrfFSyBadAWptCcOI as exception:
   NJERvVGTwDhmoUrfFSyBadAWptCcOP(exception)
  return NJERvVGTwDhmoUrfFSyBadAWptCcXI,NJERvVGTwDhmoUrfFSyBadAWptCcMi
 def GetTitleGroupList(NJERvVGTwDhmoUrfFSyBadAWptCcIM):
  NJERvVGTwDhmoUrfFSyBadAWptCcPK=[]
  NJERvVGTwDhmoUrfFSyBadAWptCcIs=NJERvVGTwDhmoUrfFSyBadAWptCcIM.API_DOMAIN+'/api/v3/home/web'
  NJERvVGTwDhmoUrfFSyBadAWptCcIK=NJERvVGTwDhmoUrfFSyBadAWptCcIM.callRequestCookies('Get',NJERvVGTwDhmoUrfFSyBadAWptCcIs,payload=NJERvVGTwDhmoUrfFSyBadAWptCcjs,params=NJERvVGTwDhmoUrfFSyBadAWptCcjs,headers=NJERvVGTwDhmoUrfFSyBadAWptCcjs,cookies=NJERvVGTwDhmoUrfFSyBadAWptCcjs)
  NJERvVGTwDhmoUrfFSyBadAWptCcPO=json.loads(NJERvVGTwDhmoUrfFSyBadAWptCcIK.text)
  for NJERvVGTwDhmoUrfFSyBadAWptCcPY in NJERvVGTwDhmoUrfFSyBadAWptCcPO:
   if NJERvVGTwDhmoUrfFSyBadAWptCcjx(NJERvVGTwDhmoUrfFSyBadAWptCcPY['type'])=='3':
    NJERvVGTwDhmoUrfFSyBadAWptCcMq=''
    for NJERvVGTwDhmoUrfFSyBadAWptCcMu in NJERvVGTwDhmoUrfFSyBadAWptCcPY['data']['list']:
     NJERvVGTwDhmoUrfFSyBadAWptCcMb='[%s] %s vs %s\n<%s>\n\n'%(NJERvVGTwDhmoUrfFSyBadAWptCcMu['gameDesc']['roundName'],NJERvVGTwDhmoUrfFSyBadAWptCcMu['gameDesc']['homeNameShort'],NJERvVGTwDhmoUrfFSyBadAWptCcMu['gameDesc']['awayNameShort'],NJERvVGTwDhmoUrfFSyBadAWptCcMu['gameDesc']['beginDate'])
     NJERvVGTwDhmoUrfFSyBadAWptCcMq+=NJERvVGTwDhmoUrfFSyBadAWptCcMb
    NJERvVGTwDhmoUrfFSyBadAWptCcPn={'title':NJERvVGTwDhmoUrfFSyBadAWptCcPY['title'],'logo':NJERvVGTwDhmoUrfFSyBadAWptCcPY['logo'],'reagueId':NJERvVGTwDhmoUrfFSyBadAWptCcjx(NJERvVGTwDhmoUrfFSyBadAWptCcPY['destId']),'subGame':NJERvVGTwDhmoUrfFSyBadAWptCcMq,}
    NJERvVGTwDhmoUrfFSyBadAWptCcPK.append(NJERvVGTwDhmoUrfFSyBadAWptCcPn)
  return NJERvVGTwDhmoUrfFSyBadAWptCcPK
 def GetPopularGroupList(NJERvVGTwDhmoUrfFSyBadAWptCcIM):
  NJERvVGTwDhmoUrfFSyBadAWptCcPK=[]
  NJERvVGTwDhmoUrfFSyBadAWptCcIs=NJERvVGTwDhmoUrfFSyBadAWptCcIM.API_DOMAIN+'/api/v3/home/web'
  NJERvVGTwDhmoUrfFSyBadAWptCcIK=NJERvVGTwDhmoUrfFSyBadAWptCcIM.callRequestCookies('Get',NJERvVGTwDhmoUrfFSyBadAWptCcIs,payload=NJERvVGTwDhmoUrfFSyBadAWptCcjs,params=NJERvVGTwDhmoUrfFSyBadAWptCcjs,headers=NJERvVGTwDhmoUrfFSyBadAWptCcjs,cookies=NJERvVGTwDhmoUrfFSyBadAWptCcjs)
  NJERvVGTwDhmoUrfFSyBadAWptCcPO=json.loads(NJERvVGTwDhmoUrfFSyBadAWptCcIK.text)
  for NJERvVGTwDhmoUrfFSyBadAWptCcPY in NJERvVGTwDhmoUrfFSyBadAWptCcPO:
   if NJERvVGTwDhmoUrfFSyBadAWptCcjx(NJERvVGTwDhmoUrfFSyBadAWptCcPY['type'])=='1' and NJERvVGTwDhmoUrfFSyBadAWptCcjx(NJERvVGTwDhmoUrfFSyBadAWptCcPY['destId'])=='4':
    for NJERvVGTwDhmoUrfFSyBadAWptCcMu in NJERvVGTwDhmoUrfFSyBadAWptCcPY['data']['list']:
     NJERvVGTwDhmoUrfFSyBadAWptCcML =NJERvVGTwDhmoUrfFSyBadAWptCcMu['title']
     NJERvVGTwDhmoUrfFSyBadAWptCcMz =NJERvVGTwDhmoUrfFSyBadAWptCcMu['id']
     NJERvVGTwDhmoUrfFSyBadAWptCcMk =NJERvVGTwDhmoUrfFSyBadAWptCcMu['vtype']
     NJERvVGTwDhmoUrfFSyBadAWptCcMl =NJERvVGTwDhmoUrfFSyBadAWptCcMu['imgUrl']
     NJERvVGTwDhmoUrfFSyBadAWptCcMH =NJERvVGTwDhmoUrfFSyBadAWptCcMu['vtypeId']
     NJERvVGTwDhmoUrfFSyBadAWptCcPn={'vodTitle':NJERvVGTwDhmoUrfFSyBadAWptCcML,'vodId':NJERvVGTwDhmoUrfFSyBadAWptCcMz,'vodType':NJERvVGTwDhmoUrfFSyBadAWptCcMk,'thumbnail':NJERvVGTwDhmoUrfFSyBadAWptCcMl,'vtypeId':NJERvVGTwDhmoUrfFSyBadAWptCcjx(NJERvVGTwDhmoUrfFSyBadAWptCcMH),'duration':NJERvVGTwDhmoUrfFSyBadAWptCcjQ(NJERvVGTwDhmoUrfFSyBadAWptCcMu['duration']/1000),}
     NJERvVGTwDhmoUrfFSyBadAWptCcPK.append(NJERvVGTwDhmoUrfFSyBadAWptCcPn)
  return NJERvVGTwDhmoUrfFSyBadAWptCcPK
 def Get_NowVod_GroupList(NJERvVGTwDhmoUrfFSyBadAWptCcIM,page_int):
  NJERvVGTwDhmoUrfFSyBadAWptCcPK=[]
  NJERvVGTwDhmoUrfFSyBadAWptCcMg=NJERvVGTwDhmoUrfFSyBadAWptCcjK
  NJERvVGTwDhmoUrfFSyBadAWptCcIs=NJERvVGTwDhmoUrfFSyBadAWptCcIM.API_DOMAIN+'/api/v3/theme/14/list'
  NJERvVGTwDhmoUrfFSyBadAWptCcMe={'pageItem':'10','pageNo':NJERvVGTwDhmoUrfFSyBadAWptCcjx(page_int)}
  NJERvVGTwDhmoUrfFSyBadAWptCcIK=NJERvVGTwDhmoUrfFSyBadAWptCcIM.callRequestCookies('Get',NJERvVGTwDhmoUrfFSyBadAWptCcIs,payload=NJERvVGTwDhmoUrfFSyBadAWptCcjs,params=NJERvVGTwDhmoUrfFSyBadAWptCcMe,headers=NJERvVGTwDhmoUrfFSyBadAWptCcjs,cookies=NJERvVGTwDhmoUrfFSyBadAWptCcjs)
  NJERvVGTwDhmoUrfFSyBadAWptCcPO=json.loads(NJERvVGTwDhmoUrfFSyBadAWptCcIK.text)
  for NJERvVGTwDhmoUrfFSyBadAWptCcPY in NJERvVGTwDhmoUrfFSyBadAWptCcPO['list']:
   NJERvVGTwDhmoUrfFSyBadAWptCcML =NJERvVGTwDhmoUrfFSyBadAWptCcPY['title']
   NJERvVGTwDhmoUrfFSyBadAWptCcMz =NJERvVGTwDhmoUrfFSyBadAWptCcPY['id']
   NJERvVGTwDhmoUrfFSyBadAWptCcMk =NJERvVGTwDhmoUrfFSyBadAWptCcPY['vtype']
   NJERvVGTwDhmoUrfFSyBadAWptCcMl =NJERvVGTwDhmoUrfFSyBadAWptCcPY['imgUrl']
   NJERvVGTwDhmoUrfFSyBadAWptCcMH =NJERvVGTwDhmoUrfFSyBadAWptCcPY['vtypeId']
   NJERvVGTwDhmoUrfFSyBadAWptCcPn={'vodTitle':NJERvVGTwDhmoUrfFSyBadAWptCcML,'vodId':NJERvVGTwDhmoUrfFSyBadAWptCcMz,'vodType':NJERvVGTwDhmoUrfFSyBadAWptCcMk,'thumbnail':NJERvVGTwDhmoUrfFSyBadAWptCcMl,'vtypeId':NJERvVGTwDhmoUrfFSyBadAWptCcjx(NJERvVGTwDhmoUrfFSyBadAWptCcMH),'duration':NJERvVGTwDhmoUrfFSyBadAWptCcjQ(NJERvVGTwDhmoUrfFSyBadAWptCcPY['duration']/1000),}
   NJERvVGTwDhmoUrfFSyBadAWptCcPK.append(NJERvVGTwDhmoUrfFSyBadAWptCcPn)
   if NJERvVGTwDhmoUrfFSyBadAWptCcPO['count']>page_int*NJERvVGTwDhmoUrfFSyBadAWptCcIM.GAMELIST_LIMIT:NJERvVGTwDhmoUrfFSyBadAWptCcMg=NJERvVGTwDhmoUrfFSyBadAWptCcjn
  return NJERvVGTwDhmoUrfFSyBadAWptCcPK,NJERvVGTwDhmoUrfFSyBadAWptCcMg
 def GetSeasonList(NJERvVGTwDhmoUrfFSyBadAWptCcIM,leagueId):
  NJERvVGTwDhmoUrfFSyBadAWptCcPK=[]
  NJERvVGTwDhmoUrfFSyBadAWptCcMs=NJERvVGTwDhmoUrfFSyBadAWptCcMK=''
  try:
   NJERvVGTwDhmoUrfFSyBadAWptCcIs=NJERvVGTwDhmoUrfFSyBadAWptCcIM.API_DOMAIN+'/api/v3/game/league/'+leagueId
   NJERvVGTwDhmoUrfFSyBadAWptCcIK=NJERvVGTwDhmoUrfFSyBadAWptCcIM.callRequestCookies('Get',NJERvVGTwDhmoUrfFSyBadAWptCcIs,payload=NJERvVGTwDhmoUrfFSyBadAWptCcjs,params=NJERvVGTwDhmoUrfFSyBadAWptCcjs,headers=NJERvVGTwDhmoUrfFSyBadAWptCcjs,cookies=NJERvVGTwDhmoUrfFSyBadAWptCcjs)
   NJERvVGTwDhmoUrfFSyBadAWptCcPO=json.loads(NJERvVGTwDhmoUrfFSyBadAWptCcIK.text)
   NJERvVGTwDhmoUrfFSyBadAWptCcMs=NJERvVGTwDhmoUrfFSyBadAWptCcPO['name']
   NJERvVGTwDhmoUrfFSyBadAWptCcMK=NJERvVGTwDhmoUrfFSyBadAWptCcjx(NJERvVGTwDhmoUrfFSyBadAWptCcPO['gameTypeId'])
  except NJERvVGTwDhmoUrfFSyBadAWptCcOI as exception:
   NJERvVGTwDhmoUrfFSyBadAWptCcOP(exception)
   return NJERvVGTwDhmoUrfFSyBadAWptCcPK
  if NJERvVGTwDhmoUrfFSyBadAWptCcMK in['2','5','6','8']:
   try:
    NJERvVGTwDhmoUrfFSyBadAWptCcIs=NJERvVGTwDhmoUrfFSyBadAWptCcIM.API_DOMAIN+'/api/v3/year/'+leagueId
    NJERvVGTwDhmoUrfFSyBadAWptCcIK=NJERvVGTwDhmoUrfFSyBadAWptCcIM.callRequestCookies('Get',NJERvVGTwDhmoUrfFSyBadAWptCcIs,payload=NJERvVGTwDhmoUrfFSyBadAWptCcjs,params=NJERvVGTwDhmoUrfFSyBadAWptCcjs,headers=NJERvVGTwDhmoUrfFSyBadAWptCcjs,cookies=NJERvVGTwDhmoUrfFSyBadAWptCcjs)
    NJERvVGTwDhmoUrfFSyBadAWptCcPO=json.loads(NJERvVGTwDhmoUrfFSyBadAWptCcIK.text)
    for NJERvVGTwDhmoUrfFSyBadAWptCcPY in NJERvVGTwDhmoUrfFSyBadAWptCcPO:
     NJERvVGTwDhmoUrfFSyBadAWptCcPn={'reagueName':NJERvVGTwDhmoUrfFSyBadAWptCcMs,'gameTypeId':NJERvVGTwDhmoUrfFSyBadAWptCcMK,'seasonName':NJERvVGTwDhmoUrfFSyBadAWptCcjx(NJERvVGTwDhmoUrfFSyBadAWptCcPY),'seasonId':NJERvVGTwDhmoUrfFSyBadAWptCcjx(NJERvVGTwDhmoUrfFSyBadAWptCcPY)}
     NJERvVGTwDhmoUrfFSyBadAWptCcPK.append(NJERvVGTwDhmoUrfFSyBadAWptCcPn)
   except NJERvVGTwDhmoUrfFSyBadAWptCcOI as exception:
    NJERvVGTwDhmoUrfFSyBadAWptCcOP(exception)
    return[]
  else:
   try:
    NJERvVGTwDhmoUrfFSyBadAWptCcIs=NJERvVGTwDhmoUrfFSyBadAWptCcIM.API_DOMAIN+'/api/v3/season/'+leagueId
    NJERvVGTwDhmoUrfFSyBadAWptCcIK=NJERvVGTwDhmoUrfFSyBadAWptCcIM.callRequestCookies('Get',NJERvVGTwDhmoUrfFSyBadAWptCcIs,payload=NJERvVGTwDhmoUrfFSyBadAWptCcjs,params=NJERvVGTwDhmoUrfFSyBadAWptCcjs,headers=NJERvVGTwDhmoUrfFSyBadAWptCcjs,cookies=NJERvVGTwDhmoUrfFSyBadAWptCcjs)
    NJERvVGTwDhmoUrfFSyBadAWptCcPO=json.loads(NJERvVGTwDhmoUrfFSyBadAWptCcIK.text)
    for NJERvVGTwDhmoUrfFSyBadAWptCcPY in NJERvVGTwDhmoUrfFSyBadAWptCcPO:
     NJERvVGTwDhmoUrfFSyBadAWptCcPn={'reagueName':NJERvVGTwDhmoUrfFSyBadAWptCcMs,'gameTypeId':NJERvVGTwDhmoUrfFSyBadAWptCcMK,'seasonName':NJERvVGTwDhmoUrfFSyBadAWptCcPY['name'],'seasonId':NJERvVGTwDhmoUrfFSyBadAWptCcjx(NJERvVGTwDhmoUrfFSyBadAWptCcPY['id'])}
     NJERvVGTwDhmoUrfFSyBadAWptCcPK.append(NJERvVGTwDhmoUrfFSyBadAWptCcPn)
   except NJERvVGTwDhmoUrfFSyBadAWptCcOI as exception:
    NJERvVGTwDhmoUrfFSyBadAWptCcOP(exception)
    return[]
  return NJERvVGTwDhmoUrfFSyBadAWptCcPK
 def GetGameList(NJERvVGTwDhmoUrfFSyBadAWptCcIM,NJERvVGTwDhmoUrfFSyBadAWptCcMK,leagueId,seasonId,page_int,hidescore=NJERvVGTwDhmoUrfFSyBadAWptCcjn):
  NJERvVGTwDhmoUrfFSyBadAWptCcPK=[]
  NJERvVGTwDhmoUrfFSyBadAWptCcMg=NJERvVGTwDhmoUrfFSyBadAWptCcjK
  try:
   NJERvVGTwDhmoUrfFSyBadAWptCcIs=NJERvVGTwDhmoUrfFSyBadAWptCcIM.API_DOMAIN+'/api/v3/vod/league/detail'
   NJERvVGTwDhmoUrfFSyBadAWptCcMe={'gameType':NJERvVGTwDhmoUrfFSyBadAWptCcMK,'leagueId':leagueId,'seasonId':seasonId if NJERvVGTwDhmoUrfFSyBadAWptCcMK not in['2','5','6','8']else '','teamId':'','roundId':'','year':'' if NJERvVGTwDhmoUrfFSyBadAWptCcMK not in['2','5','6','8']else seasonId,'pageNo':NJERvVGTwDhmoUrfFSyBadAWptCcjx(page_int)}
   NJERvVGTwDhmoUrfFSyBadAWptCcIK=NJERvVGTwDhmoUrfFSyBadAWptCcIM.callRequestCookies('Get',NJERvVGTwDhmoUrfFSyBadAWptCcIs,payload=NJERvVGTwDhmoUrfFSyBadAWptCcjs,params=NJERvVGTwDhmoUrfFSyBadAWptCcMe,headers=NJERvVGTwDhmoUrfFSyBadAWptCcjs,cookies=NJERvVGTwDhmoUrfFSyBadAWptCcjs)
   NJERvVGTwDhmoUrfFSyBadAWptCcPO=json.loads(NJERvVGTwDhmoUrfFSyBadAWptCcIK.text)
   NJERvVGTwDhmoUrfFSyBadAWptCcXx=NJERvVGTwDhmoUrfFSyBadAWptCcPO['list']
   for NJERvVGTwDhmoUrfFSyBadAWptCcMx in NJERvVGTwDhmoUrfFSyBadAWptCcXx:
    for NJERvVGTwDhmoUrfFSyBadAWptCcPY in NJERvVGTwDhmoUrfFSyBadAWptCcMx['list']:
     if NJERvVGTwDhmoUrfFSyBadAWptCcPY['gameDesc']['title']==NJERvVGTwDhmoUrfFSyBadAWptCcjs or NJERvVGTwDhmoUrfFSyBadAWptCcPY['gameDesc']['title']=='':
      NJERvVGTwDhmoUrfFSyBadAWptCcXY ='%s vs %s'%(NJERvVGTwDhmoUrfFSyBadAWptCcPY['gameDesc']['homeNameShort'],NJERvVGTwDhmoUrfFSyBadAWptCcPY['gameDesc']['awayNameShort'])
     else:
      NJERvVGTwDhmoUrfFSyBadAWptCcXY =NJERvVGTwDhmoUrfFSyBadAWptCcPY['gameDesc']['title']
     NJERvVGTwDhmoUrfFSyBadAWptCcMY =NJERvVGTwDhmoUrfFSyBadAWptCcPY['gameDesc']['beginDate']
     NJERvVGTwDhmoUrfFSyBadAWptCcMn =NJERvVGTwDhmoUrfFSyBadAWptCcPY['gameDesc']['id']
     NJERvVGTwDhmoUrfFSyBadAWptCcMQ =NJERvVGTwDhmoUrfFSyBadAWptCcPY['gameDesc']['leagueNameFull']
     NJERvVGTwDhmoUrfFSyBadAWptCcjI =NJERvVGTwDhmoUrfFSyBadAWptCcPY['gameDesc']['seasonName']
     NJERvVGTwDhmoUrfFSyBadAWptCcjP =NJERvVGTwDhmoUrfFSyBadAWptCcPY['gameDesc']['roundName']
     NJERvVGTwDhmoUrfFSyBadAWptCcjX =NJERvVGTwDhmoUrfFSyBadAWptCcPY['gameDesc']['homeName']
     NJERvVGTwDhmoUrfFSyBadAWptCcjM =NJERvVGTwDhmoUrfFSyBadAWptCcPY['gameDesc']['awayName']
     NJERvVGTwDhmoUrfFSyBadAWptCcjO =NJERvVGTwDhmoUrfFSyBadAWptCcPY['gameDesc']['homeScore']
     NJERvVGTwDhmoUrfFSyBadAWptCcji =NJERvVGTwDhmoUrfFSyBadAWptCcPY['gameDesc']['awayScore']
     if hidescore==NJERvVGTwDhmoUrfFSyBadAWptCcjn:
      NJERvVGTwDhmoUrfFSyBadAWptCcjq ='%s\n - %s (%s)\n - %s\n\nhome : %s\n\naway : %s'%(NJERvVGTwDhmoUrfFSyBadAWptCcMQ,NJERvVGTwDhmoUrfFSyBadAWptCcjI,NJERvVGTwDhmoUrfFSyBadAWptCcjP,NJERvVGTwDhmoUrfFSyBadAWptCcMY,NJERvVGTwDhmoUrfFSyBadAWptCcjX,NJERvVGTwDhmoUrfFSyBadAWptCcjM)
     else:
      NJERvVGTwDhmoUrfFSyBadAWptCcjq ='%s\n - %s (%s)\n - %s\n\nhome : %s (Score %s)\n\naway : %s (Score %s)'%(NJERvVGTwDhmoUrfFSyBadAWptCcMQ,NJERvVGTwDhmoUrfFSyBadAWptCcjI,NJERvVGTwDhmoUrfFSyBadAWptCcjP,NJERvVGTwDhmoUrfFSyBadAWptCcMY,NJERvVGTwDhmoUrfFSyBadAWptCcjX,NJERvVGTwDhmoUrfFSyBadAWptCcjO,NJERvVGTwDhmoUrfFSyBadAWptCcjM,NJERvVGTwDhmoUrfFSyBadAWptCcji)
     NJERvVGTwDhmoUrfFSyBadAWptCcju=NJERvVGTwDhmoUrfFSyBadAWptCcjq
     NJERvVGTwDhmoUrfFSyBadAWptCcjb =NJERvVGTwDhmoUrfFSyBadAWptCcPY['replayVod']['count']
     NJERvVGTwDhmoUrfFSyBadAWptCcjL=NJERvVGTwDhmoUrfFSyBadAWptCcPY['highlightVod']['count']
     NJERvVGTwDhmoUrfFSyBadAWptCcjz =NJERvVGTwDhmoUrfFSyBadAWptCcPY['vods']['count']
     NJERvVGTwDhmoUrfFSyBadAWptCcMl='' 
     NJERvVGTwDhmoUrfFSyBadAWptCcjk=NJERvVGTwDhmoUrfFSyBadAWptCcjb+NJERvVGTwDhmoUrfFSyBadAWptCcjL+NJERvVGTwDhmoUrfFSyBadAWptCcjz
     if NJERvVGTwDhmoUrfFSyBadAWptCcjk==0:
      if NJERvVGTwDhmoUrfFSyBadAWptCcMK=='2':
       NJERvVGTwDhmoUrfFSyBadAWptCcXY='----- %s -----'%(NJERvVGTwDhmoUrfFSyBadAWptCcjI)
       NJERvVGTwDhmoUrfFSyBadAWptCcMY=''
      else:
       NJERvVGTwDhmoUrfFSyBadAWptCcXY+=' - 관련영상 없음'
       NJERvVGTwDhmoUrfFSyBadAWptCcju+='\n\n ** 관련영상 없음 **'
     else:
      if NJERvVGTwDhmoUrfFSyBadAWptCcjb!=0:
       NJERvVGTwDhmoUrfFSyBadAWptCcMl =NJERvVGTwDhmoUrfFSyBadAWptCcPY['replayVod']['list'][0]['imgUrl']
      elif NJERvVGTwDhmoUrfFSyBadAWptCcjL!=0:
       NJERvVGTwDhmoUrfFSyBadAWptCcMl =NJERvVGTwDhmoUrfFSyBadAWptCcPY['highlightVod']['list'][0]['imgUrl']
      else:
       NJERvVGTwDhmoUrfFSyBadAWptCcMl =NJERvVGTwDhmoUrfFSyBadAWptCcPY['vods']['list'][0]['imgUrl']
     NJERvVGTwDhmoUrfFSyBadAWptCcPn={'gameTitle':NJERvVGTwDhmoUrfFSyBadAWptCcXY,'gameId':NJERvVGTwDhmoUrfFSyBadAWptCcMn,'beginDate':NJERvVGTwDhmoUrfFSyBadAWptCcMY[:11],'thumbnail':NJERvVGTwDhmoUrfFSyBadAWptCcMl,'info_plot':NJERvVGTwDhmoUrfFSyBadAWptCcju,'leaguenm':NJERvVGTwDhmoUrfFSyBadAWptCcMQ,'seasonnm':NJERvVGTwDhmoUrfFSyBadAWptCcjI,'roundnm':NJERvVGTwDhmoUrfFSyBadAWptCcjP,'totVodCnt':NJERvVGTwDhmoUrfFSyBadAWptCcjk}
     NJERvVGTwDhmoUrfFSyBadAWptCcPK.append(NJERvVGTwDhmoUrfFSyBadAWptCcPn)
  except NJERvVGTwDhmoUrfFSyBadAWptCcOI as exception:
   NJERvVGTwDhmoUrfFSyBadAWptCcOP(exception)
  if NJERvVGTwDhmoUrfFSyBadAWptCcPO['count']>page_int*NJERvVGTwDhmoUrfFSyBadAWptCcIM.GAMELIST_LIMIT:NJERvVGTwDhmoUrfFSyBadAWptCcMg=NJERvVGTwDhmoUrfFSyBadAWptCcjn
  return NJERvVGTwDhmoUrfFSyBadAWptCcPK,NJERvVGTwDhmoUrfFSyBadAWptCcMg
 def GetGameVodList(NJERvVGTwDhmoUrfFSyBadAWptCcIM,NJERvVGTwDhmoUrfFSyBadAWptCcMn,vodCount=1000):
  NJERvVGTwDhmoUrfFSyBadAWptCcPK=[]
  NJERvVGTwDhmoUrfFSyBadAWptCcjl=''
  try:
   NJERvVGTwDhmoUrfFSyBadAWptCcIs=NJERvVGTwDhmoUrfFSyBadAWptCcIM.API_DOMAIN+'/api/v3/vod/game'
   NJERvVGTwDhmoUrfFSyBadAWptCcMe={'gameId':NJERvVGTwDhmoUrfFSyBadAWptCcMn,'pageItem':NJERvVGTwDhmoUrfFSyBadAWptCcjx(vodCount)}
   NJERvVGTwDhmoUrfFSyBadAWptCcIK=NJERvVGTwDhmoUrfFSyBadAWptCcIM.callRequestCookies('Get',NJERvVGTwDhmoUrfFSyBadAWptCcIs,payload=NJERvVGTwDhmoUrfFSyBadAWptCcjs,params=NJERvVGTwDhmoUrfFSyBadAWptCcMe,headers=NJERvVGTwDhmoUrfFSyBadAWptCcjs,cookies=NJERvVGTwDhmoUrfFSyBadAWptCcjs)
   NJERvVGTwDhmoUrfFSyBadAWptCcPO=json.loads(NJERvVGTwDhmoUrfFSyBadAWptCcIK.text)
   NJERvVGTwDhmoUrfFSyBadAWptCcMx=NJERvVGTwDhmoUrfFSyBadAWptCcPO['list']
   for NJERvVGTwDhmoUrfFSyBadAWptCcPY in NJERvVGTwDhmoUrfFSyBadAWptCcMx:
    NJERvVGTwDhmoUrfFSyBadAWptCcML =NJERvVGTwDhmoUrfFSyBadAWptCcPY['title']
    NJERvVGTwDhmoUrfFSyBadAWptCcMz =NJERvVGTwDhmoUrfFSyBadAWptCcPY['id']
    NJERvVGTwDhmoUrfFSyBadAWptCcMk =NJERvVGTwDhmoUrfFSyBadAWptCcPY['vtype']
    NJERvVGTwDhmoUrfFSyBadAWptCcMl =NJERvVGTwDhmoUrfFSyBadAWptCcPY['imgUrl']
    NJERvVGTwDhmoUrfFSyBadAWptCcMH =NJERvVGTwDhmoUrfFSyBadAWptCcPY['vtypeId']
    NJERvVGTwDhmoUrfFSyBadAWptCcjH =NJERvVGTwDhmoUrfFSyBadAWptCcPY['isFree']
    NJERvVGTwDhmoUrfFSyBadAWptCcPn={'vodTitle':NJERvVGTwDhmoUrfFSyBadAWptCcML,'vodId':NJERvVGTwDhmoUrfFSyBadAWptCcMz,'vodType':NJERvVGTwDhmoUrfFSyBadAWptCcMk,'thumbnail':NJERvVGTwDhmoUrfFSyBadAWptCcMl,'vtypeId':NJERvVGTwDhmoUrfFSyBadAWptCcjx(NJERvVGTwDhmoUrfFSyBadAWptCcMH),'duration':NJERvVGTwDhmoUrfFSyBadAWptCcjQ(NJERvVGTwDhmoUrfFSyBadAWptCcPY['duration']/1000),'isFree':NJERvVGTwDhmoUrfFSyBadAWptCcjH}
    NJERvVGTwDhmoUrfFSyBadAWptCcPK.append(NJERvVGTwDhmoUrfFSyBadAWptCcPn)
  except NJERvVGTwDhmoUrfFSyBadAWptCcOI as exception:
   NJERvVGTwDhmoUrfFSyBadAWptCcOP(exception)
  return NJERvVGTwDhmoUrfFSyBadAWptCcPK
 def GetReplay_UrlId(NJERvVGTwDhmoUrfFSyBadAWptCcIM,NJERvVGTwDhmoUrfFSyBadAWptCcjl,NJERvVGTwDhmoUrfFSyBadAWptCcMH):
  NJERvVGTwDhmoUrfFSyBadAWptCcjg=''
  try:
   NJERvVGTwDhmoUrfFSyBadAWptCcIs=NJERvVGTwDhmoUrfFSyBadAWptCcIM.API_DOMAIN+'/api/v3/vod/'+NJERvVGTwDhmoUrfFSyBadAWptCcjl
   NJERvVGTwDhmoUrfFSyBadAWptCcIK=NJERvVGTwDhmoUrfFSyBadAWptCcIM.callRequestCookies('Get',NJERvVGTwDhmoUrfFSyBadAWptCcIs,payload=NJERvVGTwDhmoUrfFSyBadAWptCcjs,params=NJERvVGTwDhmoUrfFSyBadAWptCcjs,headers=NJERvVGTwDhmoUrfFSyBadAWptCcjs,cookies=NJERvVGTwDhmoUrfFSyBadAWptCcjs)
   NJERvVGTwDhmoUrfFSyBadAWptCcPO=json.loads(NJERvVGTwDhmoUrfFSyBadAWptCcIK.text)
   NJERvVGTwDhmoUrfFSyBadAWptCcjg=NJERvVGTwDhmoUrfFSyBadAWptCcPO['videoId']
  except NJERvVGTwDhmoUrfFSyBadAWptCcOI as exception:
   NJERvVGTwDhmoUrfFSyBadAWptCcOP(exception)
  return NJERvVGTwDhmoUrfFSyBadAWptCcjg
# Created by pyminifier (https://github.com/liftoff/pyminifier)
