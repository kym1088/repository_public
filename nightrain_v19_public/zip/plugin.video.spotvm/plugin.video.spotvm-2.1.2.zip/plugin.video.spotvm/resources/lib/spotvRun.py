__author__="NightRain"
gscTqVJQKLiCNvwpudWmXYlnAkjhGB=object
gscTqVJQKLiCNvwpudWmXYlnAkjhGS=None
gscTqVJQKLiCNvwpudWmXYlnAkjhGP=True
gscTqVJQKLiCNvwpudWmXYlnAkjhGf=int
gscTqVJQKLiCNvwpudWmXYlnAkjhGr=False
gscTqVJQKLiCNvwpudWmXYlnAkjhGH=len
gscTqVJQKLiCNvwpudWmXYlnAkjhGz=str
gscTqVJQKLiCNvwpudWmXYlnAkjhGU=open
gscTqVJQKLiCNvwpudWmXYlnAkjhGo=Exception
gscTqVJQKLiCNvwpudWmXYlnAkjhGI=print
gscTqVJQKLiCNvwpudWmXYlnAkjhGy=dict
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
gscTqVJQKLiCNvwpudWmXYlnAkjhtM=[{'title':'TV 채널 (유료사용자만 지원)','mode':'LIVE_GROUP'},{'title':'Live중계 (독점,현지)','mode':'ELIVE_GROUP'},{'title':'-----------------','mode':'XXX'},{'title':'인기영상5','mode':'POP_GROUP'},{'title':'VOD 영상','mode':'VOD_GROUP'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH'}]
gscTqVJQKLiCNvwpudWmXYlnAkjhtB=xbmcvfs.translatePath(os.path.join(__profile__,'spotv_cookies.json'))
from spotvCore import*
class gscTqVJQKLiCNvwpudWmXYlnAkjhte(gscTqVJQKLiCNvwpudWmXYlnAkjhGB):
 def __init__(gscTqVJQKLiCNvwpudWmXYlnAkjhtG,gscTqVJQKLiCNvwpudWmXYlnAkjhtS,gscTqVJQKLiCNvwpudWmXYlnAkjhtP,gscTqVJQKLiCNvwpudWmXYlnAkjhtf):
  gscTqVJQKLiCNvwpudWmXYlnAkjhtG._addon_url =gscTqVJQKLiCNvwpudWmXYlnAkjhtS
  gscTqVJQKLiCNvwpudWmXYlnAkjhtG._addon_handle=gscTqVJQKLiCNvwpudWmXYlnAkjhtP
  gscTqVJQKLiCNvwpudWmXYlnAkjhtG.main_params =gscTqVJQKLiCNvwpudWmXYlnAkjhtf
  gscTqVJQKLiCNvwpudWmXYlnAkjhtG.SpotvObj =fXigIEAuNdoFyUOWzTPQrJKmSDpbRC() 
 def addon_noti(gscTqVJQKLiCNvwpudWmXYlnAkjhtG,sting):
  try:
   gscTqVJQKLiCNvwpudWmXYlnAkjhtH=xbmcgui.Dialog()
   gscTqVJQKLiCNvwpudWmXYlnAkjhtH.notification(__addonname__,sting)
  except:
   gscTqVJQKLiCNvwpudWmXYlnAkjhGS
 def addon_log(gscTqVJQKLiCNvwpudWmXYlnAkjhtG,string):
  try:
   gscTqVJQKLiCNvwpudWmXYlnAkjhtz=string.encode('utf-8','ignore')
  except:
   gscTqVJQKLiCNvwpudWmXYlnAkjhtz='addonException: addon_log'
  gscTqVJQKLiCNvwpudWmXYlnAkjhtU=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,gscTqVJQKLiCNvwpudWmXYlnAkjhtz),level=gscTqVJQKLiCNvwpudWmXYlnAkjhtU)
 def get_keyboard_input(gscTqVJQKLiCNvwpudWmXYlnAkjhtG,gscTqVJQKLiCNvwpudWmXYlnAkjhtx):
  gscTqVJQKLiCNvwpudWmXYlnAkjhto=gscTqVJQKLiCNvwpudWmXYlnAkjhGS
  kb=xbmc.Keyboard()
  kb.setHeading(gscTqVJQKLiCNvwpudWmXYlnAkjhtx)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   gscTqVJQKLiCNvwpudWmXYlnAkjhto=kb.getText()
  return gscTqVJQKLiCNvwpudWmXYlnAkjhto
 def get_settings_login_info(gscTqVJQKLiCNvwpudWmXYlnAkjhtG):
  gscTqVJQKLiCNvwpudWmXYlnAkjhtI =__addon__.getSetting('id')
  gscTqVJQKLiCNvwpudWmXYlnAkjhty =__addon__.getSetting('pw')
  return(gscTqVJQKLiCNvwpudWmXYlnAkjhtI,gscTqVJQKLiCNvwpudWmXYlnAkjhty)
 def set_winCredential(gscTqVJQKLiCNvwpudWmXYlnAkjhtG,credential):
  gscTqVJQKLiCNvwpudWmXYlnAkjhtE=xbmcgui.Window(10000)
  gscTqVJQKLiCNvwpudWmXYlnAkjhtE.setProperty('SPOTV_M_SESSIONID',credential.get('spotv_sessionid'))
  gscTqVJQKLiCNvwpudWmXYlnAkjhtE.setProperty('SPOTV_M_SESSION',credential.get('spotv_session'))
  gscTqVJQKLiCNvwpudWmXYlnAkjhtE.setProperty('SPOTV_M_ACCOUNTID',credential.get('spotv_accountId'))
  gscTqVJQKLiCNvwpudWmXYlnAkjhtE.setProperty('SPOTV_M_POLICYKEY',credential.get('spotv_policyKey'))
  gscTqVJQKLiCNvwpudWmXYlnAkjhtE.setProperty('SPOTV_M_SUBEND',credential.get('spotv_subend'))
  gscTqVJQKLiCNvwpudWmXYlnAkjhtE.setProperty('SPOTV_M_LOGINTIME',gscTqVJQKLiCNvwpudWmXYlnAkjhtG.SpotvObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(gscTqVJQKLiCNvwpudWmXYlnAkjhtG):
  gscTqVJQKLiCNvwpudWmXYlnAkjhtE=xbmcgui.Window(10000)
  gscTqVJQKLiCNvwpudWmXYlnAkjhta={'spotv_sessionid':gscTqVJQKLiCNvwpudWmXYlnAkjhtE.getProperty('SPOTV_M_SESSIONID'),'spotv_session':gscTqVJQKLiCNvwpudWmXYlnAkjhtE.getProperty('SPOTV_M_SESSION'),'spotv_accountId':gscTqVJQKLiCNvwpudWmXYlnAkjhtE.getProperty('SPOTV_M_ACCOUNTID'),'spotv_policyKey':gscTqVJQKLiCNvwpudWmXYlnAkjhtE.getProperty('SPOTV_M_POLICYKEY'),'spotv_subend':gscTqVJQKLiCNvwpudWmXYlnAkjhtE.getProperty('SPOTV_M_SUBEND')}
  return gscTqVJQKLiCNvwpudWmXYlnAkjhta
 def add_dir(gscTqVJQKLiCNvwpudWmXYlnAkjhtG,label,sublabel='',img='',infoLabels=gscTqVJQKLiCNvwpudWmXYlnAkjhGS,isFolder=gscTqVJQKLiCNvwpudWmXYlnAkjhGP,params=''):
  gscTqVJQKLiCNvwpudWmXYlnAkjhtF='%s?%s'%(gscTqVJQKLiCNvwpudWmXYlnAkjhtG._addon_url,urllib.parse.urlencode(params))
  if sublabel:gscTqVJQKLiCNvwpudWmXYlnAkjhtx='%s < %s >'%(label,sublabel)
  else: gscTqVJQKLiCNvwpudWmXYlnAkjhtx=label
  if not img:img='DefaultFolder.png'
  gscTqVJQKLiCNvwpudWmXYlnAkjhtD=xbmcgui.ListItem(gscTqVJQKLiCNvwpudWmXYlnAkjhtx)
  gscTqVJQKLiCNvwpudWmXYlnAkjhtD.setArt({'thumb':img,'icon':img,'poster':img})
  if infoLabels:gscTqVJQKLiCNvwpudWmXYlnAkjhtD.setInfo(type="Video",infoLabels=infoLabels)
  if not isFolder:gscTqVJQKLiCNvwpudWmXYlnAkjhtD.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(gscTqVJQKLiCNvwpudWmXYlnAkjhtG._addon_handle,gscTqVJQKLiCNvwpudWmXYlnAkjhtF,gscTqVJQKLiCNvwpudWmXYlnAkjhtD,isFolder)
 def get_selQuality(gscTqVJQKLiCNvwpudWmXYlnAkjhtG,etype):
  try:
   gscTqVJQKLiCNvwpudWmXYlnAkjhtR='selected_quality'
   gscTqVJQKLiCNvwpudWmXYlnAkjhtO=[1080,720,540]
   gscTqVJQKLiCNvwpudWmXYlnAkjhtb=gscTqVJQKLiCNvwpudWmXYlnAkjhGf(__addon__.getSetting(gscTqVJQKLiCNvwpudWmXYlnAkjhtR))
   return gscTqVJQKLiCNvwpudWmXYlnAkjhtO[gscTqVJQKLiCNvwpudWmXYlnAkjhtb]
  except:
   gscTqVJQKLiCNvwpudWmXYlnAkjhGS
  return 1080 
 def dp_Main_List(gscTqVJQKLiCNvwpudWmXYlnAkjhtG):
  for gscTqVJQKLiCNvwpudWmXYlnAkjhet in gscTqVJQKLiCNvwpudWmXYlnAkjhtM:
   gscTqVJQKLiCNvwpudWmXYlnAkjhtx=gscTqVJQKLiCNvwpudWmXYlnAkjhet.get('title')
   gscTqVJQKLiCNvwpudWmXYlnAkjheM={'mode':gscTqVJQKLiCNvwpudWmXYlnAkjhet.get('mode')}
   if gscTqVJQKLiCNvwpudWmXYlnAkjhet.get('mode')=='XXX':
    gscTqVJQKLiCNvwpudWmXYlnAkjheB=gscTqVJQKLiCNvwpudWmXYlnAkjhGr
   else:
    gscTqVJQKLiCNvwpudWmXYlnAkjheB=gscTqVJQKLiCNvwpudWmXYlnAkjhGP
   gscTqVJQKLiCNvwpudWmXYlnAkjhtG.add_dir(gscTqVJQKLiCNvwpudWmXYlnAkjhtx,sublabel='',img='',infoLabels=gscTqVJQKLiCNvwpudWmXYlnAkjhGS,isFolder=gscTqVJQKLiCNvwpudWmXYlnAkjheB,params=gscTqVJQKLiCNvwpudWmXYlnAkjheM)
  if gscTqVJQKLiCNvwpudWmXYlnAkjhGH(gscTqVJQKLiCNvwpudWmXYlnAkjhtM)>0:xbmcplugin.endOfDirectory(gscTqVJQKLiCNvwpudWmXYlnAkjhtG._addon_handle)
 def dp_MainLeague_List(gscTqVJQKLiCNvwpudWmXYlnAkjhtG,args):
  gscTqVJQKLiCNvwpudWmXYlnAkjhtG.SpotvObj.SaveCredential(gscTqVJQKLiCNvwpudWmXYlnAkjhtG.get_winCredential())
  gscTqVJQKLiCNvwpudWmXYlnAkjheS=gscTqVJQKLiCNvwpudWmXYlnAkjhtG.SpotvObj.GetTitleGroupList()
  for gscTqVJQKLiCNvwpudWmXYlnAkjheP in gscTqVJQKLiCNvwpudWmXYlnAkjheS:
   gscTqVJQKLiCNvwpudWmXYlnAkjhtx =gscTqVJQKLiCNvwpudWmXYlnAkjheP.get('title')
   gscTqVJQKLiCNvwpudWmXYlnAkjhef =gscTqVJQKLiCNvwpudWmXYlnAkjheP.get('logo')
   gscTqVJQKLiCNvwpudWmXYlnAkjher =gscTqVJQKLiCNvwpudWmXYlnAkjheP.get('reagueId')
   gscTqVJQKLiCNvwpudWmXYlnAkjheH =gscTqVJQKLiCNvwpudWmXYlnAkjheP.get('subGame')
   gscTqVJQKLiCNvwpudWmXYlnAkjhez={'mediatype':'episode','plot':'%s\n\n%s'%(gscTqVJQKLiCNvwpudWmXYlnAkjhtx,gscTqVJQKLiCNvwpudWmXYlnAkjheH)}
   gscTqVJQKLiCNvwpudWmXYlnAkjheM={'mode':'LEAGUE_GROUP','reagueId':gscTqVJQKLiCNvwpudWmXYlnAkjher}
   gscTqVJQKLiCNvwpudWmXYlnAkjhtG.add_dir(gscTqVJQKLiCNvwpudWmXYlnAkjhtx,sublabel=gscTqVJQKLiCNvwpudWmXYlnAkjhGS,img=gscTqVJQKLiCNvwpudWmXYlnAkjhef,infoLabels=gscTqVJQKLiCNvwpudWmXYlnAkjhez,isFolder=gscTqVJQKLiCNvwpudWmXYlnAkjhGP,params=gscTqVJQKLiCNvwpudWmXYlnAkjheM)
  if gscTqVJQKLiCNvwpudWmXYlnAkjhGH(gscTqVJQKLiCNvwpudWmXYlnAkjheS)>0:xbmcplugin.endOfDirectory(gscTqVJQKLiCNvwpudWmXYlnAkjhtG._addon_handle,cacheToDisc=gscTqVJQKLiCNvwpudWmXYlnAkjhGr)
 def dp_PopVod_GroupList(gscTqVJQKLiCNvwpudWmXYlnAkjhtG,args):
  gscTqVJQKLiCNvwpudWmXYlnAkjhtG.SpotvObj.SaveCredential(gscTqVJQKLiCNvwpudWmXYlnAkjhtG.get_winCredential())
  gscTqVJQKLiCNvwpudWmXYlnAkjheS=gscTqVJQKLiCNvwpudWmXYlnAkjhtG.SpotvObj.GetPopularGroupList()
  for gscTqVJQKLiCNvwpudWmXYlnAkjheP in gscTqVJQKLiCNvwpudWmXYlnAkjheS:
   gscTqVJQKLiCNvwpudWmXYlnAkjheU =gscTqVJQKLiCNvwpudWmXYlnAkjheP.get('vodTitle')
   gscTqVJQKLiCNvwpudWmXYlnAkjheo =gscTqVJQKLiCNvwpudWmXYlnAkjheP.get('vodId')
   gscTqVJQKLiCNvwpudWmXYlnAkjheI =gscTqVJQKLiCNvwpudWmXYlnAkjheP.get('vodType')
   gscTqVJQKLiCNvwpudWmXYlnAkjhef=gscTqVJQKLiCNvwpudWmXYlnAkjheP.get('thumbnail')
   gscTqVJQKLiCNvwpudWmXYlnAkjhey =gscTqVJQKLiCNvwpudWmXYlnAkjheP.get('vtypeId')
   gscTqVJQKLiCNvwpudWmXYlnAkjheE =gscTqVJQKLiCNvwpudWmXYlnAkjheP.get('duration')
   gscTqVJQKLiCNvwpudWmXYlnAkjhez={'mediatype':'video','duration':gscTqVJQKLiCNvwpudWmXYlnAkjheE,'plot':gscTqVJQKLiCNvwpudWmXYlnAkjheU}
   gscTqVJQKLiCNvwpudWmXYlnAkjheM={'mode':'POP_VOD','mediacode':gscTqVJQKLiCNvwpudWmXYlnAkjheo,'mediatype':'vod','vtypeId':gscTqVJQKLiCNvwpudWmXYlnAkjhey}
   gscTqVJQKLiCNvwpudWmXYlnAkjhtG.add_dir(gscTqVJQKLiCNvwpudWmXYlnAkjheU,sublabel=gscTqVJQKLiCNvwpudWmXYlnAkjheI,img=gscTqVJQKLiCNvwpudWmXYlnAkjhef,infoLabels=gscTqVJQKLiCNvwpudWmXYlnAkjhez,isFolder=gscTqVJQKLiCNvwpudWmXYlnAkjhGr,params=gscTqVJQKLiCNvwpudWmXYlnAkjheM)
  if gscTqVJQKLiCNvwpudWmXYlnAkjhGH(gscTqVJQKLiCNvwpudWmXYlnAkjheS)>0:xbmcplugin.endOfDirectory(gscTqVJQKLiCNvwpudWmXYlnAkjhtG._addon_handle,cacheToDisc=gscTqVJQKLiCNvwpudWmXYlnAkjhGr)
 def dp_Season_List(gscTqVJQKLiCNvwpudWmXYlnAkjhtG,args):
  gscTqVJQKLiCNvwpudWmXYlnAkjhtG.SpotvObj.SaveCredential(gscTqVJQKLiCNvwpudWmXYlnAkjhtG.get_winCredential())
  gscTqVJQKLiCNvwpudWmXYlnAkjher=args.get('reagueId')
  gscTqVJQKLiCNvwpudWmXYlnAkjheS=gscTqVJQKLiCNvwpudWmXYlnAkjhtG.SpotvObj.GetSeasonList(gscTqVJQKLiCNvwpudWmXYlnAkjher)
  for gscTqVJQKLiCNvwpudWmXYlnAkjheP in gscTqVJQKLiCNvwpudWmXYlnAkjheS:
   gscTqVJQKLiCNvwpudWmXYlnAkjhea =gscTqVJQKLiCNvwpudWmXYlnAkjheP.get('reagueName')
   gscTqVJQKLiCNvwpudWmXYlnAkjheF =gscTqVJQKLiCNvwpudWmXYlnAkjheP.get('gameTypeId')
   gscTqVJQKLiCNvwpudWmXYlnAkjhex =gscTqVJQKLiCNvwpudWmXYlnAkjheP.get('seasonName')
   gscTqVJQKLiCNvwpudWmXYlnAkjheD =gscTqVJQKLiCNvwpudWmXYlnAkjheP.get('seasonId')
   gscTqVJQKLiCNvwpudWmXYlnAkjhez={'mediatype':'episode','plot':'%s - %s'%(gscTqVJQKLiCNvwpudWmXYlnAkjhea,gscTqVJQKLiCNvwpudWmXYlnAkjhex)}
   gscTqVJQKLiCNvwpudWmXYlnAkjheM={'mode':'SEASON_GROUP','reagueId':gscTqVJQKLiCNvwpudWmXYlnAkjher,'seasonId':gscTqVJQKLiCNvwpudWmXYlnAkjheD,'gameTypeId':gscTqVJQKLiCNvwpudWmXYlnAkjheF,'page':'1'}
   gscTqVJQKLiCNvwpudWmXYlnAkjhtG.add_dir(gscTqVJQKLiCNvwpudWmXYlnAkjhea,sublabel=gscTqVJQKLiCNvwpudWmXYlnAkjhex,img='',infoLabels=gscTqVJQKLiCNvwpudWmXYlnAkjhez,isFolder=gscTqVJQKLiCNvwpudWmXYlnAkjhGP,params=gscTqVJQKLiCNvwpudWmXYlnAkjheM)
  if gscTqVJQKLiCNvwpudWmXYlnAkjhGH(gscTqVJQKLiCNvwpudWmXYlnAkjheS)>0:xbmcplugin.endOfDirectory(gscTqVJQKLiCNvwpudWmXYlnAkjhtG._addon_handle,cacheToDisc=gscTqVJQKLiCNvwpudWmXYlnAkjhGP)
 def dp_Game_List(gscTqVJQKLiCNvwpudWmXYlnAkjhtG,args):
  gscTqVJQKLiCNvwpudWmXYlnAkjhtG.SpotvObj.SaveCredential(gscTqVJQKLiCNvwpudWmXYlnAkjhtG.get_winCredential())
  gscTqVJQKLiCNvwpudWmXYlnAkjheF=args.get('gameTypeId')
  gscTqVJQKLiCNvwpudWmXYlnAkjher =args.get('reagueId')
  gscTqVJQKLiCNvwpudWmXYlnAkjheD =args.get('seasonId')
  gscTqVJQKLiCNvwpudWmXYlnAkjheR =gscTqVJQKLiCNvwpudWmXYlnAkjhGf(args.get('page'))
  gscTqVJQKLiCNvwpudWmXYlnAkjheS,gscTqVJQKLiCNvwpudWmXYlnAkjheO=gscTqVJQKLiCNvwpudWmXYlnAkjhtG.SpotvObj.GetGameList(gscTqVJQKLiCNvwpudWmXYlnAkjheF,gscTqVJQKLiCNvwpudWmXYlnAkjher,gscTqVJQKLiCNvwpudWmXYlnAkjheD,gscTqVJQKLiCNvwpudWmXYlnAkjheR)
  for gscTqVJQKLiCNvwpudWmXYlnAkjheP in gscTqVJQKLiCNvwpudWmXYlnAkjheS:
   gscTqVJQKLiCNvwpudWmXYlnAkjheb =gscTqVJQKLiCNvwpudWmXYlnAkjheP.get('gameTitle')
   gscTqVJQKLiCNvwpudWmXYlnAkjhMt =gscTqVJQKLiCNvwpudWmXYlnAkjheP.get('beginDate')
   gscTqVJQKLiCNvwpudWmXYlnAkjhef =gscTqVJQKLiCNvwpudWmXYlnAkjheP.get('thumbnail')
   gscTqVJQKLiCNvwpudWmXYlnAkjhMe =gscTqVJQKLiCNvwpudWmXYlnAkjheP.get('gameId')
   gscTqVJQKLiCNvwpudWmXYlnAkjhMB =gscTqVJQKLiCNvwpudWmXYlnAkjheP.get('totVodCnt')
   gscTqVJQKLiCNvwpudWmXYlnAkjhMG =gscTqVJQKLiCNvwpudWmXYlnAkjheP.get('leaguenm')
   gscTqVJQKLiCNvwpudWmXYlnAkjhMS =gscTqVJQKLiCNvwpudWmXYlnAkjheP.get('seasonnm')
   gscTqVJQKLiCNvwpudWmXYlnAkjhMP =gscTqVJQKLiCNvwpudWmXYlnAkjheP.get('roundnm')
   gscTqVJQKLiCNvwpudWmXYlnAkjhMf =gscTqVJQKLiCNvwpudWmXYlnAkjheP.get('info_plot')
   gscTqVJQKLiCNvwpudWmXYlnAkjhMr ='%s < %s >'%(gscTqVJQKLiCNvwpudWmXYlnAkjheb,gscTqVJQKLiCNvwpudWmXYlnAkjhMt)
   gscTqVJQKLiCNvwpudWmXYlnAkjhez={'mediatype':'video','plot':gscTqVJQKLiCNvwpudWmXYlnAkjhMf}
   gscTqVJQKLiCNvwpudWmXYlnAkjheM={'mode':'GAME_VOD_GROUP' if gscTqVJQKLiCNvwpudWmXYlnAkjhMB!=0 else 'XXX','saveTitle':gscTqVJQKLiCNvwpudWmXYlnAkjhMr,'saveImg':gscTqVJQKLiCNvwpudWmXYlnAkjhef,'saveInfo':gscTqVJQKLiCNvwpudWmXYlnAkjhez['plot'],'gameid':gscTqVJQKLiCNvwpudWmXYlnAkjhMe}
   gscTqVJQKLiCNvwpudWmXYlnAkjhtG.add_dir(gscTqVJQKLiCNvwpudWmXYlnAkjheb,sublabel=gscTqVJQKLiCNvwpudWmXYlnAkjhMt,img=gscTqVJQKLiCNvwpudWmXYlnAkjhef,infoLabels=gscTqVJQKLiCNvwpudWmXYlnAkjhez,isFolder=gscTqVJQKLiCNvwpudWmXYlnAkjhGP,params=gscTqVJQKLiCNvwpudWmXYlnAkjheM)
  if gscTqVJQKLiCNvwpudWmXYlnAkjheO:
   gscTqVJQKLiCNvwpudWmXYlnAkjheM['mode'] ='SEASON_GROUP' 
   gscTqVJQKLiCNvwpudWmXYlnAkjheM['reagueId'] =gscTqVJQKLiCNvwpudWmXYlnAkjher
   gscTqVJQKLiCNvwpudWmXYlnAkjheM['seasonId'] =gscTqVJQKLiCNvwpudWmXYlnAkjheD
   gscTqVJQKLiCNvwpudWmXYlnAkjheM['gameTypeId']=gscTqVJQKLiCNvwpudWmXYlnAkjheF
   gscTqVJQKLiCNvwpudWmXYlnAkjheM['page'] =gscTqVJQKLiCNvwpudWmXYlnAkjhGz(gscTqVJQKLiCNvwpudWmXYlnAkjheR+1)
   gscTqVJQKLiCNvwpudWmXYlnAkjhtx='[B]%s >>[/B]'%'다음 페이지'
   gscTqVJQKLiCNvwpudWmXYlnAkjhMH=gscTqVJQKLiCNvwpudWmXYlnAkjhGz(gscTqVJQKLiCNvwpudWmXYlnAkjheR+1)
   gscTqVJQKLiCNvwpudWmXYlnAkjhtG.add_dir(gscTqVJQKLiCNvwpudWmXYlnAkjhtx,sublabel=gscTqVJQKLiCNvwpudWmXYlnAkjhMH,img='',infoLabels=gscTqVJQKLiCNvwpudWmXYlnAkjhGS,isFolder=gscTqVJQKLiCNvwpudWmXYlnAkjhGP,params=gscTqVJQKLiCNvwpudWmXYlnAkjheM)
  if gscTqVJQKLiCNvwpudWmXYlnAkjhGH(gscTqVJQKLiCNvwpudWmXYlnAkjheS)>0:xbmcplugin.endOfDirectory(gscTqVJQKLiCNvwpudWmXYlnAkjhtG._addon_handle,cacheToDisc=gscTqVJQKLiCNvwpudWmXYlnAkjhGr)
 def dp_GameVod_List(gscTqVJQKLiCNvwpudWmXYlnAkjhtG,args):
  gscTqVJQKLiCNvwpudWmXYlnAkjhtG.SpotvObj.SaveCredential(gscTqVJQKLiCNvwpudWmXYlnAkjhtG.get_winCredential())
  gscTqVJQKLiCNvwpudWmXYlnAkjhMz =args.get('gameid')
  gscTqVJQKLiCNvwpudWmXYlnAkjhMr=args.get('saveTitle')
  gscTqVJQKLiCNvwpudWmXYlnAkjhMU =args.get('saveImg')
  gscTqVJQKLiCNvwpudWmXYlnAkjhMo =args.get('saveInfo')
  gscTqVJQKLiCNvwpudWmXYlnAkjheS=gscTqVJQKLiCNvwpudWmXYlnAkjhtG.SpotvObj.GetGameVodList(gscTqVJQKLiCNvwpudWmXYlnAkjhMz)
  for gscTqVJQKLiCNvwpudWmXYlnAkjheP in gscTqVJQKLiCNvwpudWmXYlnAkjheS:
   gscTqVJQKLiCNvwpudWmXYlnAkjheU =gscTqVJQKLiCNvwpudWmXYlnAkjheP.get('vodTitle')
   gscTqVJQKLiCNvwpudWmXYlnAkjheo =gscTqVJQKLiCNvwpudWmXYlnAkjheP.get('vodId')
   gscTqVJQKLiCNvwpudWmXYlnAkjheI =gscTqVJQKLiCNvwpudWmXYlnAkjheP.get('vodType')
   gscTqVJQKLiCNvwpudWmXYlnAkjhef=gscTqVJQKLiCNvwpudWmXYlnAkjheP.get('thumbnail')
   gscTqVJQKLiCNvwpudWmXYlnAkjhey =gscTqVJQKLiCNvwpudWmXYlnAkjheP.get('vtypeId')
   gscTqVJQKLiCNvwpudWmXYlnAkjheE =gscTqVJQKLiCNvwpudWmXYlnAkjheP.get('duration')
   gscTqVJQKLiCNvwpudWmXYlnAkjhez={'mediatype':'video','duration':gscTqVJQKLiCNvwpudWmXYlnAkjheE,'plot':'%s \n\n %s'%(gscTqVJQKLiCNvwpudWmXYlnAkjheU,gscTqVJQKLiCNvwpudWmXYlnAkjhMo)}
   gscTqVJQKLiCNvwpudWmXYlnAkjheM={'mode':'GAME_VOD','saveTitle':gscTqVJQKLiCNvwpudWmXYlnAkjhMr,'saveImg':gscTqVJQKLiCNvwpudWmXYlnAkjhMU,'saveId':gscTqVJQKLiCNvwpudWmXYlnAkjhMz,'saveInfo':gscTqVJQKLiCNvwpudWmXYlnAkjhMo,'mediacode':gscTqVJQKLiCNvwpudWmXYlnAkjheo,'mediatype':'vod','vtypeId':gscTqVJQKLiCNvwpudWmXYlnAkjhey}
   gscTqVJQKLiCNvwpudWmXYlnAkjhtG.add_dir(gscTqVJQKLiCNvwpudWmXYlnAkjheU,sublabel=gscTqVJQKLiCNvwpudWmXYlnAkjheI,img=gscTqVJQKLiCNvwpudWmXYlnAkjhef,infoLabels=gscTqVJQKLiCNvwpudWmXYlnAkjhez,isFolder=gscTqVJQKLiCNvwpudWmXYlnAkjhGr,params=gscTqVJQKLiCNvwpudWmXYlnAkjheM)
  if gscTqVJQKLiCNvwpudWmXYlnAkjhGH(gscTqVJQKLiCNvwpudWmXYlnAkjheS)>0:xbmcplugin.endOfDirectory(gscTqVJQKLiCNvwpudWmXYlnAkjhtG._addon_handle,cacheToDisc=gscTqVJQKLiCNvwpudWmXYlnAkjhGr)
 def login_main(gscTqVJQKLiCNvwpudWmXYlnAkjhtG):
  (gscTqVJQKLiCNvwpudWmXYlnAkjhMI,gscTqVJQKLiCNvwpudWmXYlnAkjhMy)=gscTqVJQKLiCNvwpudWmXYlnAkjhtG.get_settings_login_info()
  if not(gscTqVJQKLiCNvwpudWmXYlnAkjhMI and gscTqVJQKLiCNvwpudWmXYlnAkjhMy):
   gscTqVJQKLiCNvwpudWmXYlnAkjhtH=xbmcgui.Dialog()
   gscTqVJQKLiCNvwpudWmXYlnAkjhME=gscTqVJQKLiCNvwpudWmXYlnAkjhtH.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if gscTqVJQKLiCNvwpudWmXYlnAkjhME==gscTqVJQKLiCNvwpudWmXYlnAkjhGP:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if gscTqVJQKLiCNvwpudWmXYlnAkjhtG.cookiefile_check():return
  gscTqVJQKLiCNvwpudWmXYlnAkjhMa =gscTqVJQKLiCNvwpudWmXYlnAkjhGf(gscTqVJQKLiCNvwpudWmXYlnAkjhtG.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))
  gscTqVJQKLiCNvwpudWmXYlnAkjhMF=xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINTIME')
  if gscTqVJQKLiCNvwpudWmXYlnAkjhMF==gscTqVJQKLiCNvwpudWmXYlnAkjhGS or gscTqVJQKLiCNvwpudWmXYlnAkjhMF=='':
   gscTqVJQKLiCNvwpudWmXYlnAkjhMF=gscTqVJQKLiCNvwpudWmXYlnAkjhGf('19000101')
  else:
   gscTqVJQKLiCNvwpudWmXYlnAkjhMF=gscTqVJQKLiCNvwpudWmXYlnAkjhGf(re.sub('-','',gscTqVJQKLiCNvwpudWmXYlnAkjhMF))
  if xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINWAIT')=='TRUE':
   gscTqVJQKLiCNvwpudWmXYlnAkjhMx=0
   while gscTqVJQKLiCNvwpudWmXYlnAkjhGP:
    gscTqVJQKLiCNvwpudWmXYlnAkjhMx+=1
    time.sleep(0.05)
    if gscTqVJQKLiCNvwpudWmXYlnAkjhMF>=gscTqVJQKLiCNvwpudWmXYlnAkjhMa:return
    if gscTqVJQKLiCNvwpudWmXYlnAkjhMx>600:return
  else:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','TRUE')
  if gscTqVJQKLiCNvwpudWmXYlnAkjhMF>=gscTqVJQKLiCNvwpudWmXYlnAkjhMa:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
   return
  if not gscTqVJQKLiCNvwpudWmXYlnAkjhtG.SpotvObj.GetCredential(gscTqVJQKLiCNvwpudWmXYlnAkjhMI,gscTqVJQKLiCNvwpudWmXYlnAkjhMy):
   gscTqVJQKLiCNvwpudWmXYlnAkjhtG.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
   sys.exit()
  gscTqVJQKLiCNvwpudWmXYlnAkjhtG.set_winCredential(gscTqVJQKLiCNvwpudWmXYlnAkjhtG.SpotvObj.LoadCredential())
  gscTqVJQKLiCNvwpudWmXYlnAkjhtG.cookiefile_save()
  xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
 def dp_LiveChannel_List(gscTqVJQKLiCNvwpudWmXYlnAkjhtG,args):
  gscTqVJQKLiCNvwpudWmXYlnAkjhtG.SpotvObj.SaveCredential(gscTqVJQKLiCNvwpudWmXYlnAkjhtG.get_winCredential())
  gscTqVJQKLiCNvwpudWmXYlnAkjhMD=gscTqVJQKLiCNvwpudWmXYlnAkjhtG.SpotvObj.GetLiveChannelList()
  for gscTqVJQKLiCNvwpudWmXYlnAkjhMR in gscTqVJQKLiCNvwpudWmXYlnAkjhMD:
   gscTqVJQKLiCNvwpudWmXYlnAkjhtx =gscTqVJQKLiCNvwpudWmXYlnAkjhMR.get('name')
   gscTqVJQKLiCNvwpudWmXYlnAkjhef =gscTqVJQKLiCNvwpudWmXYlnAkjhMR.get('logo')
   gscTqVJQKLiCNvwpudWmXYlnAkjhMO =gscTqVJQKLiCNvwpudWmXYlnAkjhMR.get('free')
   gscTqVJQKLiCNvwpudWmXYlnAkjhez={'plot':'%s'%(gscTqVJQKLiCNvwpudWmXYlnAkjhtx),'mediatype':'video'}
   gscTqVJQKLiCNvwpudWmXYlnAkjheM={'mode':'LIVE','mediaid':gscTqVJQKLiCNvwpudWmXYlnAkjhMR.get('id'),'mediacode':gscTqVJQKLiCNvwpudWmXYlnAkjhMR.get('videoId'),'free':gscTqVJQKLiCNvwpudWmXYlnAkjhMO,'mediatype':'live'}
   if gscTqVJQKLiCNvwpudWmXYlnAkjhMO:gscTqVJQKLiCNvwpudWmXYlnAkjhtx+=' [free]'
   gscTqVJQKLiCNvwpudWmXYlnAkjhtG.add_dir(gscTqVJQKLiCNvwpudWmXYlnAkjhtx,sublabel='',img=gscTqVJQKLiCNvwpudWmXYlnAkjhef,infoLabels=gscTqVJQKLiCNvwpudWmXYlnAkjhez,isFolder=gscTqVJQKLiCNvwpudWmXYlnAkjhGr,params=gscTqVJQKLiCNvwpudWmXYlnAkjheM)
  if gscTqVJQKLiCNvwpudWmXYlnAkjhGH(gscTqVJQKLiCNvwpudWmXYlnAkjhMD)>0:xbmcplugin.endOfDirectory(gscTqVJQKLiCNvwpudWmXYlnAkjhtG._addon_handle,cacheToDisc=gscTqVJQKLiCNvwpudWmXYlnAkjhGr)
 def dp_EventLiveChannel_List(gscTqVJQKLiCNvwpudWmXYlnAkjhtG,args):
  gscTqVJQKLiCNvwpudWmXYlnAkjhtG.SpotvObj.SaveCredential(gscTqVJQKLiCNvwpudWmXYlnAkjhtG.get_winCredential())
  gscTqVJQKLiCNvwpudWmXYlnAkjhMD,gscTqVJQKLiCNvwpudWmXYlnAkjhMb=gscTqVJQKLiCNvwpudWmXYlnAkjhtG.SpotvObj.GetEventLiveList()
  if gscTqVJQKLiCNvwpudWmXYlnAkjhMb!=401 and gscTqVJQKLiCNvwpudWmXYlnAkjhGH(gscTqVJQKLiCNvwpudWmXYlnAkjhMD)==0:
   gscTqVJQKLiCNvwpudWmXYlnAkjhtG.addon_noti(__language__(30907).encode('utf8'))
  for gscTqVJQKLiCNvwpudWmXYlnAkjhMR in gscTqVJQKLiCNvwpudWmXYlnAkjhMD:
   gscTqVJQKLiCNvwpudWmXYlnAkjhtx =gscTqVJQKLiCNvwpudWmXYlnAkjhMR.get('title')
   gscTqVJQKLiCNvwpudWmXYlnAkjheG =gscTqVJQKLiCNvwpudWmXYlnAkjhMR.get('startTime')
   gscTqVJQKLiCNvwpudWmXYlnAkjhef =gscTqVJQKLiCNvwpudWmXYlnAkjhMR.get('logo')
   gscTqVJQKLiCNvwpudWmXYlnAkjhMO =gscTqVJQKLiCNvwpudWmXYlnAkjhMR.get('free')
   gscTqVJQKLiCNvwpudWmXYlnAkjhez={'mediatype':'video','plot':'%s\n\n%s'%(gscTqVJQKLiCNvwpudWmXYlnAkjhtx,gscTqVJQKLiCNvwpudWmXYlnAkjheG)}
   gscTqVJQKLiCNvwpudWmXYlnAkjheM={'mode':'ELIVE','mediaid':gscTqVJQKLiCNvwpudWmXYlnAkjhMR.get('liveId'),'mediacode':'','free':gscTqVJQKLiCNvwpudWmXYlnAkjhMO,'mediatype':'live'}
   if gscTqVJQKLiCNvwpudWmXYlnAkjhMO:gscTqVJQKLiCNvwpudWmXYlnAkjhtx+=' [free]'
   gscTqVJQKLiCNvwpudWmXYlnAkjhtG.add_dir(gscTqVJQKLiCNvwpudWmXYlnAkjhtx,sublabel=gscTqVJQKLiCNvwpudWmXYlnAkjheG,img=gscTqVJQKLiCNvwpudWmXYlnAkjhef,infoLabels=gscTqVJQKLiCNvwpudWmXYlnAkjhez,isFolder=gscTqVJQKLiCNvwpudWmXYlnAkjhGr,params=gscTqVJQKLiCNvwpudWmXYlnAkjheM)
  if gscTqVJQKLiCNvwpudWmXYlnAkjhGH(gscTqVJQKLiCNvwpudWmXYlnAkjhMD)>0:xbmcplugin.endOfDirectory(gscTqVJQKLiCNvwpudWmXYlnAkjhtG._addon_handle,cacheToDisc=gscTqVJQKLiCNvwpudWmXYlnAkjhGP)
  return gscTqVJQKLiCNvwpudWmXYlnAkjhMb
 def play_VIDEO(gscTqVJQKLiCNvwpudWmXYlnAkjhtG,args):
  gscTqVJQKLiCNvwpudWmXYlnAkjhtG.SpotvObj.SaveCredential(gscTqVJQKLiCNvwpudWmXYlnAkjhtG.get_winCredential())
  gscTqVJQKLiCNvwpudWmXYlnAkjhBt =args.get('mode')
  gscTqVJQKLiCNvwpudWmXYlnAkjhBe =args.get('mediacode')
  gscTqVJQKLiCNvwpudWmXYlnAkjhBM =args.get('mediatype')
  gscTqVJQKLiCNvwpudWmXYlnAkjhey =args.get('vtypeId')
  if gscTqVJQKLiCNvwpudWmXYlnAkjhBt=='LIVE':
   if args.get('free')=='False':
    if gscTqVJQKLiCNvwpudWmXYlnAkjhtG.SpotvObj.CheckSubEnd()==gscTqVJQKLiCNvwpudWmXYlnAkjhGr:
     gscTqVJQKLiCNvwpudWmXYlnAkjhtG.addon_noti(__language__(30908).encode('utf8'))
     return
  elif gscTqVJQKLiCNvwpudWmXYlnAkjhBt=='ELIVE':
   if args.get('free')=='False':
    if gscTqVJQKLiCNvwpudWmXYlnAkjhtG.SpotvObj.CheckSubEnd()==gscTqVJQKLiCNvwpudWmXYlnAkjhGr:
     gscTqVJQKLiCNvwpudWmXYlnAkjhtG.addon_noti(__language__(30908).encode('utf8'))
     return
   gscTqVJQKLiCNvwpudWmXYlnAkjhBe=gscTqVJQKLiCNvwpudWmXYlnAkjhtG.SpotvObj.GetEventLive_videoId(args.get('mediaid'))
  if gscTqVJQKLiCNvwpudWmXYlnAkjhBe=='' or gscTqVJQKLiCNvwpudWmXYlnAkjhBe==gscTqVJQKLiCNvwpudWmXYlnAkjhGS:
   gscTqVJQKLiCNvwpudWmXYlnAkjhtG.addon_noti(__language__(30907).encode('utf8'))
   return
  if gscTqVJQKLiCNvwpudWmXYlnAkjhBt=='LIVE':
   gscTqVJQKLiCNvwpudWmXYlnAkjhBG=gscTqVJQKLiCNvwpudWmXYlnAkjhtG.SpotvObj.Get_Streamurl_Make(args.get('mediaid'))
  else:
   gscTqVJQKLiCNvwpudWmXYlnAkjhBG=gscTqVJQKLiCNvwpudWmXYlnAkjhtG.SpotvObj.GetBroadURL(gscTqVJQKLiCNvwpudWmXYlnAkjhBe,gscTqVJQKLiCNvwpudWmXYlnAkjhBM,gscTqVJQKLiCNvwpudWmXYlnAkjhey)
  if gscTqVJQKLiCNvwpudWmXYlnAkjhBG=='':
   gscTqVJQKLiCNvwpudWmXYlnAkjhtG.addon_noti(__language__(30908).encode('utf8'))
   return
  gscTqVJQKLiCNvwpudWmXYlnAkjhBS=gscTqVJQKLiCNvwpudWmXYlnAkjhBG
  gscTqVJQKLiCNvwpudWmXYlnAkjhtG.addon_log(gscTqVJQKLiCNvwpudWmXYlnAkjhBS)
  gscTqVJQKLiCNvwpudWmXYlnAkjhBP=xbmcgui.ListItem(path=gscTqVJQKLiCNvwpudWmXYlnAkjhBS)
  xbmcplugin.setResolvedUrl(gscTqVJQKLiCNvwpudWmXYlnAkjhtG._addon_handle,gscTqVJQKLiCNvwpudWmXYlnAkjhGP,gscTqVJQKLiCNvwpudWmXYlnAkjhBP)
  try:
   if gscTqVJQKLiCNvwpudWmXYlnAkjhBM=='vod' and gscTqVJQKLiCNvwpudWmXYlnAkjhBt!='POP_VOD':
    gscTqVJQKLiCNvwpudWmXYlnAkjheM={'code':args.get('saveId'),'img':args.get('saveImg'),'title':args.get('saveTitle'),'info':args.get('saveInfo')}
    gscTqVJQKLiCNvwpudWmXYlnAkjhtG.Save_Watched_List(gscTqVJQKLiCNvwpudWmXYlnAkjhBM,gscTqVJQKLiCNvwpudWmXYlnAkjheM)
  except:
   gscTqVJQKLiCNvwpudWmXYlnAkjhGS
 def logout(gscTqVJQKLiCNvwpudWmXYlnAkjhtG):
  gscTqVJQKLiCNvwpudWmXYlnAkjhtH=xbmcgui.Dialog()
  gscTqVJQKLiCNvwpudWmXYlnAkjhME=gscTqVJQKLiCNvwpudWmXYlnAkjhtH.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if gscTqVJQKLiCNvwpudWmXYlnAkjhME==gscTqVJQKLiCNvwpudWmXYlnAkjhGr:sys.exit()
  gscTqVJQKLiCNvwpudWmXYlnAkjhtG.wininfo_clear()
  if os.path.isfile(gscTqVJQKLiCNvwpudWmXYlnAkjhtB):os.remove(gscTqVJQKLiCNvwpudWmXYlnAkjhtB)
  gscTqVJQKLiCNvwpudWmXYlnAkjhtG.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(gscTqVJQKLiCNvwpudWmXYlnAkjhtG):
  gscTqVJQKLiCNvwpudWmXYlnAkjhtE=xbmcgui.Window(10000)
  gscTqVJQKLiCNvwpudWmXYlnAkjhtE.setProperty('SPOTV_M_SESSIONID','')
  gscTqVJQKLiCNvwpudWmXYlnAkjhtE.setProperty('SPOTV_M_SESSION','')
  gscTqVJQKLiCNvwpudWmXYlnAkjhtE.setProperty('SPOTV_M_ACCOUNTID','')
  gscTqVJQKLiCNvwpudWmXYlnAkjhtE.setProperty('SPOTV_M_POLICYKEY','')
  gscTqVJQKLiCNvwpudWmXYlnAkjhtE.setProperty('SPOTV_M_SUBEND','')
  gscTqVJQKLiCNvwpudWmXYlnAkjhtE.setProperty('SPOTV_M_LOGINTIME','')
 def cookiefile_save(gscTqVJQKLiCNvwpudWmXYlnAkjhtG):
  gscTqVJQKLiCNvwpudWmXYlnAkjhBf =gscTqVJQKLiCNvwpudWmXYlnAkjhtG.SpotvObj.Get_Now_Datetime()
  gscTqVJQKLiCNvwpudWmXYlnAkjhBr=gscTqVJQKLiCNvwpudWmXYlnAkjhBf+datetime.timedelta(days=gscTqVJQKLiCNvwpudWmXYlnAkjhGf(__addon__.getSetting('cache_ttl')))
  gscTqVJQKLiCNvwpudWmXYlnAkjhtE=xbmcgui.Window(10000)
  gscTqVJQKLiCNvwpudWmXYlnAkjhBH={'spotv_sessionid':gscTqVJQKLiCNvwpudWmXYlnAkjhtE.getProperty('SPOTV_M_SESSIONID'),'spotv_session':gscTqVJQKLiCNvwpudWmXYlnAkjhtE.getProperty('SPOTV_M_SESSION'),'spotv_accountId':gscTqVJQKLiCNvwpudWmXYlnAkjhtE.getProperty('SPOTV_M_ACCOUNTID'),'spotv_policyKey':base64.standard_b64encode(gscTqVJQKLiCNvwpudWmXYlnAkjhtE.getProperty('SPOTV_M_POLICYKEY').encode()).decode('utf-8'),'spotv_subend':base64.standard_b64encode((gscTqVJQKLiCNvwpudWmXYlnAkjhtG.SpotvObj.SPOTV_PMCODE+gscTqVJQKLiCNvwpudWmXYlnAkjhtE.getProperty('SPOTV_M_SUBEND')).encode()).decode('utf-8'),'spotv_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'spotv_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'spotv_limitdate':gscTqVJQKLiCNvwpudWmXYlnAkjhBr.strftime('%Y-%m-%d')}
  try: 
   fp=gscTqVJQKLiCNvwpudWmXYlnAkjhGU(gscTqVJQKLiCNvwpudWmXYlnAkjhtB,'w',-1,'utf-8')
   json.dump(gscTqVJQKLiCNvwpudWmXYlnAkjhBH,fp)
   fp.close()
  except gscTqVJQKLiCNvwpudWmXYlnAkjhGo as exception:
   gscTqVJQKLiCNvwpudWmXYlnAkjhGI(exception)
 def cookiefile_check(gscTqVJQKLiCNvwpudWmXYlnAkjhtG):
  gscTqVJQKLiCNvwpudWmXYlnAkjhBH={}
  try: 
   fp=gscTqVJQKLiCNvwpudWmXYlnAkjhGU(gscTqVJQKLiCNvwpudWmXYlnAkjhtB,'r',-1,'utf-8')
   gscTqVJQKLiCNvwpudWmXYlnAkjhBH= json.load(fp)
   fp.close()
  except gscTqVJQKLiCNvwpudWmXYlnAkjhGo as exception:
   gscTqVJQKLiCNvwpudWmXYlnAkjhtG.wininfo_clear()
   return gscTqVJQKLiCNvwpudWmXYlnAkjhGr
  gscTqVJQKLiCNvwpudWmXYlnAkjhMI =__addon__.getSetting('id')
  gscTqVJQKLiCNvwpudWmXYlnAkjhMy =__addon__.getSetting('pw')
  gscTqVJQKLiCNvwpudWmXYlnAkjhBH['spotv_id'] =base64.standard_b64decode(gscTqVJQKLiCNvwpudWmXYlnAkjhBH['spotv_id']).decode('utf-8')
  gscTqVJQKLiCNvwpudWmXYlnAkjhBH['spotv_pw'] =base64.standard_b64decode(gscTqVJQKLiCNvwpudWmXYlnAkjhBH['spotv_pw']).decode('utf-8')
  gscTqVJQKLiCNvwpudWmXYlnAkjhBH['spotv_policyKey']=base64.standard_b64decode(gscTqVJQKLiCNvwpudWmXYlnAkjhBH['spotv_policyKey']).decode('utf-8')
  gscTqVJQKLiCNvwpudWmXYlnAkjhBH['spotv_subend']=base64.standard_b64decode(gscTqVJQKLiCNvwpudWmXYlnAkjhBH['spotv_subend']).decode('utf-8')[gscTqVJQKLiCNvwpudWmXYlnAkjhtG.SpotvObj.SPOTV_PMSIZE:]
  if gscTqVJQKLiCNvwpudWmXYlnAkjhMI!=gscTqVJQKLiCNvwpudWmXYlnAkjhBH['spotv_id']or gscTqVJQKLiCNvwpudWmXYlnAkjhMy!=gscTqVJQKLiCNvwpudWmXYlnAkjhBH['spotv_pw']:
   gscTqVJQKLiCNvwpudWmXYlnAkjhtG.wininfo_clear()
   return gscTqVJQKLiCNvwpudWmXYlnAkjhGr
  gscTqVJQKLiCNvwpudWmXYlnAkjhMa =gscTqVJQKLiCNvwpudWmXYlnAkjhGf(gscTqVJQKLiCNvwpudWmXYlnAkjhtG.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))
  gscTqVJQKLiCNvwpudWmXYlnAkjhBz=gscTqVJQKLiCNvwpudWmXYlnAkjhBH['spotv_limitdate']
  gscTqVJQKLiCNvwpudWmXYlnAkjhMF =gscTqVJQKLiCNvwpudWmXYlnAkjhGf(re.sub('-','',gscTqVJQKLiCNvwpudWmXYlnAkjhBz))
  if gscTqVJQKLiCNvwpudWmXYlnAkjhMF<gscTqVJQKLiCNvwpudWmXYlnAkjhMa:
   gscTqVJQKLiCNvwpudWmXYlnAkjhtG.wininfo_clear()
   return gscTqVJQKLiCNvwpudWmXYlnAkjhGr
  gscTqVJQKLiCNvwpudWmXYlnAkjhtE=xbmcgui.Window(10000)
  gscTqVJQKLiCNvwpudWmXYlnAkjhtE.setProperty('SPOTV_M_SESSIONID',gscTqVJQKLiCNvwpudWmXYlnAkjhBH['spotv_sessionid'])
  gscTqVJQKLiCNvwpudWmXYlnAkjhtE.setProperty('SPOTV_M_SESSION',gscTqVJQKLiCNvwpudWmXYlnAkjhBH['spotv_session'])
  gscTqVJQKLiCNvwpudWmXYlnAkjhtE.setProperty('SPOTV_M_ACCOUNTID',gscTqVJQKLiCNvwpudWmXYlnAkjhBH['spotv_accountId'])
  gscTqVJQKLiCNvwpudWmXYlnAkjhtE.setProperty('SPOTV_M_POLICYKEY',gscTqVJQKLiCNvwpudWmXYlnAkjhBH['spotv_policyKey'])
  gscTqVJQKLiCNvwpudWmXYlnAkjhtE.setProperty('SPOTV_M_SUBEND',gscTqVJQKLiCNvwpudWmXYlnAkjhBH['spotv_subend'])
  gscTqVJQKLiCNvwpudWmXYlnAkjhtE.setProperty('SPOTV_M_LOGINTIME',gscTqVJQKLiCNvwpudWmXYlnAkjhBz)
  return gscTqVJQKLiCNvwpudWmXYlnAkjhGP
 def dp_WatchList_Delete(gscTqVJQKLiCNvwpudWmXYlnAkjhtG,args):
  gscTqVJQKLiCNvwpudWmXYlnAkjhBM=args.get('mediatype')
  gscTqVJQKLiCNvwpudWmXYlnAkjhtH=xbmcgui.Dialog()
  gscTqVJQKLiCNvwpudWmXYlnAkjhME=gscTqVJQKLiCNvwpudWmXYlnAkjhtH.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if gscTqVJQKLiCNvwpudWmXYlnAkjhME==gscTqVJQKLiCNvwpudWmXYlnAkjhGr:sys.exit()
  gscTqVJQKLiCNvwpudWmXYlnAkjhtG.Delete_Watched_List(gscTqVJQKLiCNvwpudWmXYlnAkjhBM)
  xbmc.executebuiltin("Container.Refresh")
 def Delete_Watched_List(gscTqVJQKLiCNvwpudWmXYlnAkjhtG,gscTqVJQKLiCNvwpudWmXYlnAkjhBM):
  try:
   gscTqVJQKLiCNvwpudWmXYlnAkjhBU=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%gscTqVJQKLiCNvwpudWmXYlnAkjhBM))
   fp=gscTqVJQKLiCNvwpudWmXYlnAkjhGU(gscTqVJQKLiCNvwpudWmXYlnAkjhBU,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   gscTqVJQKLiCNvwpudWmXYlnAkjhGS
 def Load_Watched_List(gscTqVJQKLiCNvwpudWmXYlnAkjhtG,gscTqVJQKLiCNvwpudWmXYlnAkjhBM):
  try:
   gscTqVJQKLiCNvwpudWmXYlnAkjhBU=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%gscTqVJQKLiCNvwpudWmXYlnAkjhBM))
   fp=gscTqVJQKLiCNvwpudWmXYlnAkjhGU(gscTqVJQKLiCNvwpudWmXYlnAkjhBU,'r',-1,'utf-8')
   gscTqVJQKLiCNvwpudWmXYlnAkjhBo=fp.readlines()
   fp.close()
  except:
   gscTqVJQKLiCNvwpudWmXYlnAkjhBo=[]
  return gscTqVJQKLiCNvwpudWmXYlnAkjhBo
 def Save_Watched_List(gscTqVJQKLiCNvwpudWmXYlnAkjhtG,stype,gscTqVJQKLiCNvwpudWmXYlnAkjhtf):
  try:
   gscTqVJQKLiCNvwpudWmXYlnAkjhBU=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   gscTqVJQKLiCNvwpudWmXYlnAkjhBI=gscTqVJQKLiCNvwpudWmXYlnAkjhtG.Load_Watched_List(stype) 
   fp=gscTqVJQKLiCNvwpudWmXYlnAkjhGU(gscTqVJQKLiCNvwpudWmXYlnAkjhBU,'w',-1,'utf-8')
   gscTqVJQKLiCNvwpudWmXYlnAkjhBy=urllib.parse.urlencode(gscTqVJQKLiCNvwpudWmXYlnAkjhtf)
   gscTqVJQKLiCNvwpudWmXYlnAkjhBy=gscTqVJQKLiCNvwpudWmXYlnAkjhBy+'\n'
   fp.write(gscTqVJQKLiCNvwpudWmXYlnAkjhBy)
   gscTqVJQKLiCNvwpudWmXYlnAkjhBE=0
   for gscTqVJQKLiCNvwpudWmXYlnAkjhBa in gscTqVJQKLiCNvwpudWmXYlnAkjhBI:
    gscTqVJQKLiCNvwpudWmXYlnAkjhBF=gscTqVJQKLiCNvwpudWmXYlnAkjhGy(urllib.parse.parse_qsl(gscTqVJQKLiCNvwpudWmXYlnAkjhBa))
    gscTqVJQKLiCNvwpudWmXYlnAkjhBx=gscTqVJQKLiCNvwpudWmXYlnAkjhtf.get('code')
    gscTqVJQKLiCNvwpudWmXYlnAkjhBD=gscTqVJQKLiCNvwpudWmXYlnAkjhBF.get('code')
    if gscTqVJQKLiCNvwpudWmXYlnAkjhBx!=gscTqVJQKLiCNvwpudWmXYlnAkjhBD:
     fp.write(gscTqVJQKLiCNvwpudWmXYlnAkjhBa)
     gscTqVJQKLiCNvwpudWmXYlnAkjhBE+=1
     if gscTqVJQKLiCNvwpudWmXYlnAkjhBE>=50:break
   fp.close()
  except:
   gscTqVJQKLiCNvwpudWmXYlnAkjhGS
 def dp_Watch_List(gscTqVJQKLiCNvwpudWmXYlnAkjhtG,args):
  gscTqVJQKLiCNvwpudWmXYlnAkjhBM ='vod'
  if gscTqVJQKLiCNvwpudWmXYlnAkjhBM=='vod':
   gscTqVJQKLiCNvwpudWmXYlnAkjhBR=gscTqVJQKLiCNvwpudWmXYlnAkjhtG.Load_Watched_List(gscTqVJQKLiCNvwpudWmXYlnAkjhBM)
   for gscTqVJQKLiCNvwpudWmXYlnAkjhBO in gscTqVJQKLiCNvwpudWmXYlnAkjhBR:
    gscTqVJQKLiCNvwpudWmXYlnAkjhBb=gscTqVJQKLiCNvwpudWmXYlnAkjhGy(urllib.parse.parse_qsl(gscTqVJQKLiCNvwpudWmXYlnAkjhBO))
    gscTqVJQKLiCNvwpudWmXYlnAkjhtx =gscTqVJQKLiCNvwpudWmXYlnAkjhBb.get('title')
    gscTqVJQKLiCNvwpudWmXYlnAkjhef=gscTqVJQKLiCNvwpudWmXYlnAkjhBb.get('img')
    gscTqVJQKLiCNvwpudWmXYlnAkjhBe=gscTqVJQKLiCNvwpudWmXYlnAkjhBb.get('code')
    gscTqVJQKLiCNvwpudWmXYlnAkjhGt =gscTqVJQKLiCNvwpudWmXYlnAkjhBb.get('info')
    gscTqVJQKLiCNvwpudWmXYlnAkjhez={}
    gscTqVJQKLiCNvwpudWmXYlnAkjhez['plot']=gscTqVJQKLiCNvwpudWmXYlnAkjhGt
    gscTqVJQKLiCNvwpudWmXYlnAkjheM={'mode':'GAME_VOD_GROUP','gameid':gscTqVJQKLiCNvwpudWmXYlnAkjhBe,'saveTitle':gscTqVJQKLiCNvwpudWmXYlnAkjhtx,'saveImg':gscTqVJQKLiCNvwpudWmXYlnAkjhef,'saveInfo':gscTqVJQKLiCNvwpudWmXYlnAkjhGt,'mediatype':gscTqVJQKLiCNvwpudWmXYlnAkjhBM}
    gscTqVJQKLiCNvwpudWmXYlnAkjhtG.add_dir(gscTqVJQKLiCNvwpudWmXYlnAkjhtx,sublabel='',img=gscTqVJQKLiCNvwpudWmXYlnAkjhef,infoLabels=gscTqVJQKLiCNvwpudWmXYlnAkjhez,isFolder=gscTqVJQKLiCNvwpudWmXYlnAkjhGP,params=gscTqVJQKLiCNvwpudWmXYlnAkjheM)
   gscTqVJQKLiCNvwpudWmXYlnAkjhez={'plot':'시청목록을 삭제합니다.'}
   gscTqVJQKLiCNvwpudWmXYlnAkjhtx='*** 시청목록 삭제 ***'
   gscTqVJQKLiCNvwpudWmXYlnAkjheM={'mode':'MYVIEW_REMOVE','mediatype':gscTqVJQKLiCNvwpudWmXYlnAkjhBM}
   gscTqVJQKLiCNvwpudWmXYlnAkjhtG.add_dir(gscTqVJQKLiCNvwpudWmXYlnAkjhtx,sublabel='',img='',infoLabels=gscTqVJQKLiCNvwpudWmXYlnAkjhez,isFolder=gscTqVJQKLiCNvwpudWmXYlnAkjhGr,params=gscTqVJQKLiCNvwpudWmXYlnAkjheM)
   xbmcplugin.endOfDirectory(gscTqVJQKLiCNvwpudWmXYlnAkjhtG._addon_handle,cacheToDisc=gscTqVJQKLiCNvwpudWmXYlnAkjhGr)
 def spotv_main(gscTqVJQKLiCNvwpudWmXYlnAkjhtG):
  gscTqVJQKLiCNvwpudWmXYlnAkjhGM=gscTqVJQKLiCNvwpudWmXYlnAkjhtG.main_params.get('mode',gscTqVJQKLiCNvwpudWmXYlnAkjhGS)
  if gscTqVJQKLiCNvwpudWmXYlnAkjhGM=='LOGOUT':
   gscTqVJQKLiCNvwpudWmXYlnAkjhtG.logout()
   return
  gscTqVJQKLiCNvwpudWmXYlnAkjhtG.login_main()
  if gscTqVJQKLiCNvwpudWmXYlnAkjhGM is gscTqVJQKLiCNvwpudWmXYlnAkjhGS:
   gscTqVJQKLiCNvwpudWmXYlnAkjhtG.dp_Main_List()
  elif gscTqVJQKLiCNvwpudWmXYlnAkjhGM=='LIVE_GROUP':
   gscTqVJQKLiCNvwpudWmXYlnAkjhtG.dp_LiveChannel_List(gscTqVJQKLiCNvwpudWmXYlnAkjhtG.main_params)
  elif gscTqVJQKLiCNvwpudWmXYlnAkjhGM=='ELIVE_GROUP':
   gscTqVJQKLiCNvwpudWmXYlnAkjhMb=gscTqVJQKLiCNvwpudWmXYlnAkjhtG.dp_EventLiveChannel_List(gscTqVJQKLiCNvwpudWmXYlnAkjhtG.main_params)
   if gscTqVJQKLiCNvwpudWmXYlnAkjhMb==401:
    if os.path.isfile(gscTqVJQKLiCNvwpudWmXYlnAkjhtB):os.remove(gscTqVJQKLiCNvwpudWmXYlnAkjhtB)
    gscTqVJQKLiCNvwpudWmXYlnAkjhtG.login_main()
    gscTqVJQKLiCNvwpudWmXYlnAkjhtG.dp_EventLiveChannel_List(gscTqVJQKLiCNvwpudWmXYlnAkjhtG.main_params)
  elif gscTqVJQKLiCNvwpudWmXYlnAkjhGM in['LIVE','GAME_VOD','POP_VOD','ELIVE']:
   gscTqVJQKLiCNvwpudWmXYlnAkjhtG.play_VIDEO(gscTqVJQKLiCNvwpudWmXYlnAkjhtG.main_params)
  elif gscTqVJQKLiCNvwpudWmXYlnAkjhGM=='VOD_GROUP':
   gscTqVJQKLiCNvwpudWmXYlnAkjhtG.dp_MainLeague_List(gscTqVJQKLiCNvwpudWmXYlnAkjhtG.main_params)
  elif gscTqVJQKLiCNvwpudWmXYlnAkjhGM=='POP_GROUP':
   gscTqVJQKLiCNvwpudWmXYlnAkjhtG.dp_PopVod_GroupList(gscTqVJQKLiCNvwpudWmXYlnAkjhtG.main_params)
  elif gscTqVJQKLiCNvwpudWmXYlnAkjhGM=='LEAGUE_GROUP':
   gscTqVJQKLiCNvwpudWmXYlnAkjhtG.dp_Season_List(gscTqVJQKLiCNvwpudWmXYlnAkjhtG.main_params)
  elif gscTqVJQKLiCNvwpudWmXYlnAkjhGM=='SEASON_GROUP':
   gscTqVJQKLiCNvwpudWmXYlnAkjhtG.dp_Game_List(gscTqVJQKLiCNvwpudWmXYlnAkjhtG.main_params)
  elif gscTqVJQKLiCNvwpudWmXYlnAkjhGM=='GAME_VOD_GROUP':
   gscTqVJQKLiCNvwpudWmXYlnAkjhtG.dp_GameVod_List(gscTqVJQKLiCNvwpudWmXYlnAkjhtG.main_params)
  elif gscTqVJQKLiCNvwpudWmXYlnAkjhGM=='WATCH':
   gscTqVJQKLiCNvwpudWmXYlnAkjhtG.dp_Watch_List(gscTqVJQKLiCNvwpudWmXYlnAkjhtG.main_params)
  elif gscTqVJQKLiCNvwpudWmXYlnAkjhGM=='MYVIEW_REMOVE':
   gscTqVJQKLiCNvwpudWmXYlnAkjhtG.dp_WatchList_Delete(gscTqVJQKLiCNvwpudWmXYlnAkjhtG.main_params)
  else:
   gscTqVJQKLiCNvwpudWmXYlnAkjhGS
# Created by pyminifier (https://github.com/liftoff/pyminifier)
