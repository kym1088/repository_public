__author__="NightRain"
fXigIEAuNdoFyUOWzTPQrJKmSDpbYM=False
fXigIEAuNdoFyUOWzTPQrJKmSDpbYe=object
fXigIEAuNdoFyUOWzTPQrJKmSDpbYw=None
fXigIEAuNdoFyUOWzTPQrJKmSDpbYH=print
fXigIEAuNdoFyUOWzTPQrJKmSDpbYl=str
fXigIEAuNdoFyUOWzTPQrJKmSDpbYk=True
fXigIEAuNdoFyUOWzTPQrJKmSDpbYq=Exception
fXigIEAuNdoFyUOWzTPQrJKmSDpbYa=id
fXigIEAuNdoFyUOWzTPQrJKmSDpbYh=int
import urllib
import http.cookiejar 
import re
import json
import sys
import time
import requests
import datetime
import base64
fXigIEAuNdoFyUOWzTPQrJKmSDpbRL={'stream50':1080,'stream40':720,'stream30':540}
fXigIEAuNdoFyUOWzTPQrJKmSDpbRc=[{'id':'1','name':'NOW','videoId':'ch_spotvnow1','free':fXigIEAuNdoFyUOWzTPQrJKmSDpbYM,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/ccdb36ce757afc1ca15fc38357d498e4.png'},{'id':'2','name':'NOW2','videoId':'ch_spotvnow2','free':fXigIEAuNdoFyUOWzTPQrJKmSDpbYM,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/8b6bdf6213a715eeba719b2cb9b2c747.png'},{'id':'3','name':'NBA TV','videoId':'ch_nbatv','free':fXigIEAuNdoFyUOWzTPQrJKmSDpbYM,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/5036e56d5c6594ea606f7159f59779fe.png'},{'id':'9','name':'SPOTV','videoId':'ch_spotv','free':fXigIEAuNdoFyUOWzTPQrJKmSDpbYM,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/56688c2e527c6e1b8d68e338057a7dfc.png'},{'id':'10','name':'SPOTV2','videoId':'ch_spotv2','free':fXigIEAuNdoFyUOWzTPQrJKmSDpbYM,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20201209/ca6e7a213c84e629985e609ddcda6b17.png'},{'id':'11','name':'SPOTV Golf & Health','videoId':'ch_spotvplus','free':fXigIEAuNdoFyUOWzTPQrJKmSDpbYM,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/7aa87953f1211313c3e110cace2628ff.png'},]
fXigIEAuNdoFyUOWzTPQrJKmSDpbRY={'1':{'lv':'abf18bbf3b3f4a0db4a41dd2af7f75c6','rv':'__nn__=5981484117001&hdnea=st=1609407000~exp=1609410600~acl=/abf18bbf3b3f4a0db4a41dd2af7f75c6/ap-northeast-1/5764318566001/*~hmac=e28a244d1b6b77d4e0101010816d4cd6ca89d9d31fe6a5290039d2395d81bc03'},'2':{'lv':'3054522000fc4d60aabe23d6e5911275','rv':'__nn__=5981484117001&hdnea=st=1609408800~exp=1609412400~acl=/3054522000fc4d60aabe23d6e5911275/ap-northeast-1/5764318566001/*~hmac=323b2deea8e3455fa77405f37b19231c6f0b48a5690b7218df875171ac2d6be6'},'3':{'lv':'31f99a0a6067413ea1b390c41a5c12be','rv':'__nn__=5981484117001&hdnea=st=1609408800~exp=1609412400~acl=/31f99a0a6067413ea1b390c41a5c12be/ap-northeast-1/5764318566001/*~hmac=b7ac24bc4772e3ad2669000919058bba64a6f001c69c8846341c326b089c306c'},'9':{'lv':'1f2651c2fea34be9850bfdedf8d9cfdb','rv':'__nn__=5981484117001&hdnea=st=1609408800~exp=1609412400~acl=/1f2651c2fea34be9850bfdedf8d9cfdb/ap-northeast-1/5764318566001/*~hmac=e1f6c44d1be5459cfc40af1e1b204ac9b513bb7405e070da2bff8f115f298133'},'10':{'lv':'7bf3fb8685854892b01e1fc897e7e9b0','rv':'__nn__=5981484117001&hdnea=st=1609408800~exp=1609412400~acl=/7bf3fb8685854892b01e1fc897e7e9b0/ap-northeast-1/5764318566001/*~hmac=e9bb30991cfab98b1976aacabafcd51b63769ede40148f7cc289ffed15398e81'},'11':{'lv':'242b2b6c0c654f47a07f4e2420f9c184','rv':'__nn__=5981484117001&hdnea=st=1609408800~exp=1609412400~acl=/242b2b6c0c654f47a07f4e2420f9c184/ap-northeast-1/5764318566001/*~hmac=5e4ce0553e709eb60d880bf37bc2e99661767b0a38ecee037fb4d7dce757b922'},}
class fXigIEAuNdoFyUOWzTPQrJKmSDpbRC(fXigIEAuNdoFyUOWzTPQrJKmSDpbYe):
 def __init__(fXigIEAuNdoFyUOWzTPQrJKmSDpbRv):
  fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.SPOTV_SESSIONID=''
  fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.SPOTV_SESSION =''
  fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.SPOTV_ACCOUNTID=''
  fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.SPOTV_POLICYKEY=''
  fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.SPOTV_SUBEND =''
  fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.SPOTV_PMCODE ='987'
  fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.SPOTV_PMSIZE =3
  fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.GAMELIST_LIMIT =10
  fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.API_DOMAIN ='https://www.spotvnow.co.kr'
  fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.BC_DOMAIN ='https://players.brightcove.net'
  fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.PLAYER_DOMAIN ='https://edge.api.brightcove.com'
  fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.STREAM_DOMAIN ='https://gtm-spotv.brightcovecdn.com'
  fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.STREAM_M3U8 ='ap-northeast-1/5764318566001/playlist_dvr'
  fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36'
  fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.DEFAULT_HEADER ={'user-agent':fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.USER_AGENT}
 def callRequestCookies(fXigIEAuNdoFyUOWzTPQrJKmSDpbRv,jobtype,fXigIEAuNdoFyUOWzTPQrJKmSDpbCB,payload=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,params=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,headers=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,cookies=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,redirects=fXigIEAuNdoFyUOWzTPQrJKmSDpbYM):
  fXigIEAuNdoFyUOWzTPQrJKmSDpbRs=fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.DEFAULT_HEADER
  if headers:fXigIEAuNdoFyUOWzTPQrJKmSDpbRs.update(headers)
  if jobtype=='Get':
   fXigIEAuNdoFyUOWzTPQrJKmSDpbRB=requests.get(fXigIEAuNdoFyUOWzTPQrJKmSDpbCB,params=params,headers=fXigIEAuNdoFyUOWzTPQrJKmSDpbRs,cookies=cookies,allow_redirects=redirects)
  else:
   fXigIEAuNdoFyUOWzTPQrJKmSDpbRB=requests.post(fXigIEAuNdoFyUOWzTPQrJKmSDpbCB,data=payload,params=params,headers=fXigIEAuNdoFyUOWzTPQrJKmSDpbRs,cookies=cookies,allow_redirects=redirects)
  return fXigIEAuNdoFyUOWzTPQrJKmSDpbRB
 def makeDefaultCookies(fXigIEAuNdoFyUOWzTPQrJKmSDpbRv):
  fXigIEAuNdoFyUOWzTPQrJKmSDpbRM={'SESSION':fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.SPOTV_SESSION}
  return fXigIEAuNdoFyUOWzTPQrJKmSDpbRM
 def GetCredential(fXigIEAuNdoFyUOWzTPQrJKmSDpbRv,user_id,user_pw):
  fXigIEAuNdoFyUOWzTPQrJKmSDpbRe=fXigIEAuNdoFyUOWzTPQrJKmSDpbYM
  fXigIEAuNdoFyUOWzTPQrJKmSDpbRw=fXigIEAuNdoFyUOWzTPQrJKmSDpbRn=fXigIEAuNdoFyUOWzTPQrJKmSDpbRG=fXigIEAuNdoFyUOWzTPQrJKmSDpbRt=fXigIEAuNdoFyUOWzTPQrJKmSDpbRj=''
  try:
   fXigIEAuNdoFyUOWzTPQrJKmSDpbRH=base64.standard_b64encode(user_id.encode("UTF-8")).decode('utf-8')
   fXigIEAuNdoFyUOWzTPQrJKmSDpbRl=base64.standard_b64encode(user_pw.encode("UTF-8")).decode('utf-8')
   fXigIEAuNdoFyUOWzTPQrJKmSDpbRk=fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.API_DOMAIN+'/api/v2/login'
   fXigIEAuNdoFyUOWzTPQrJKmSDpbRq={'username':fXigIEAuNdoFyUOWzTPQrJKmSDpbRH,'password':fXigIEAuNdoFyUOWzTPQrJKmSDpbRl}
   fXigIEAuNdoFyUOWzTPQrJKmSDpbRq=json.dumps(fXigIEAuNdoFyUOWzTPQrJKmSDpbRq)
   fXigIEAuNdoFyUOWzTPQrJKmSDpbRa=fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.callRequestCookies('Post',fXigIEAuNdoFyUOWzTPQrJKmSDpbRk,payload=fXigIEAuNdoFyUOWzTPQrJKmSDpbRq,params=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,headers=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,cookies=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw)
   fXigIEAuNdoFyUOWzTPQrJKmSDpbYH(fXigIEAuNdoFyUOWzTPQrJKmSDpbRa.status_code)
   for fXigIEAuNdoFyUOWzTPQrJKmSDpbRh in fXigIEAuNdoFyUOWzTPQrJKmSDpbRa.cookies:
    if fXigIEAuNdoFyUOWzTPQrJKmSDpbRh.name=='SESSION':
     fXigIEAuNdoFyUOWzTPQrJKmSDpbRn=fXigIEAuNdoFyUOWzTPQrJKmSDpbRh.value
     break
   if fXigIEAuNdoFyUOWzTPQrJKmSDpbRn=='':return fXigIEAuNdoFyUOWzTPQrJKmSDpbRe
   fXigIEAuNdoFyUOWzTPQrJKmSDpbRV=json.loads(fXigIEAuNdoFyUOWzTPQrJKmSDpbRa.text)
   if not('userId' in fXigIEAuNdoFyUOWzTPQrJKmSDpbRV):return fXigIEAuNdoFyUOWzTPQrJKmSDpbRe
   fXigIEAuNdoFyUOWzTPQrJKmSDpbRw=fXigIEAuNdoFyUOWzTPQrJKmSDpbYl(fXigIEAuNdoFyUOWzTPQrJKmSDpbRV['userId'])
   fXigIEAuNdoFyUOWzTPQrJKmSDpbRj =fXigIEAuNdoFyUOWzTPQrJKmSDpbYl(fXigIEAuNdoFyUOWzTPQrJKmSDpbRV['subEndTime'])
   fXigIEAuNdoFyUOWzTPQrJKmSDpbRG,fXigIEAuNdoFyUOWzTPQrJKmSDpbRt=fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.GetPolicyKey()
   if fXigIEAuNdoFyUOWzTPQrJKmSDpbRt=='':return fXigIEAuNdoFyUOWzTPQrJKmSDpbRe
   fXigIEAuNdoFyUOWzTPQrJKmSDpbRe=fXigIEAuNdoFyUOWzTPQrJKmSDpbYk
  except fXigIEAuNdoFyUOWzTPQrJKmSDpbYq as exception:
   fXigIEAuNdoFyUOWzTPQrJKmSDpbRw=fXigIEAuNdoFyUOWzTPQrJKmSDpbRn='' 
   fXigIEAuNdoFyUOWzTPQrJKmSDpbYH(exception)
  fXigIEAuNdoFyUOWzTPQrJKmSDpbRx={'spotv_sessionid':fXigIEAuNdoFyUOWzTPQrJKmSDpbRw,'spotv_session':fXigIEAuNdoFyUOWzTPQrJKmSDpbRn,'spotv_accountId':fXigIEAuNdoFyUOWzTPQrJKmSDpbRG,'spotv_policyKey':fXigIEAuNdoFyUOWzTPQrJKmSDpbRt,'spotv_subend':fXigIEAuNdoFyUOWzTPQrJKmSDpbRj}
  fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.SaveCredential(fXigIEAuNdoFyUOWzTPQrJKmSDpbRx)
  return fXigIEAuNdoFyUOWzTPQrJKmSDpbRe
 def SaveCredential(fXigIEAuNdoFyUOWzTPQrJKmSDpbRv,fXigIEAuNdoFyUOWzTPQrJKmSDpbRx):
  fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.SPOTV_SESSIONID=fXigIEAuNdoFyUOWzTPQrJKmSDpbRx.get('spotv_sessionid')
  fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.SPOTV_SESSION =fXigIEAuNdoFyUOWzTPQrJKmSDpbRx.get('spotv_session')
  fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.SPOTV_ACCOUNTID=fXigIEAuNdoFyUOWzTPQrJKmSDpbRx.get('spotv_accountId')
  fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.SPOTV_POLICYKEY=fXigIEAuNdoFyUOWzTPQrJKmSDpbRx.get('spotv_policyKey')
  fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.SPOTV_SUBEND =fXigIEAuNdoFyUOWzTPQrJKmSDpbRx.get('spotv_subend')
 def LoadCredential(fXigIEAuNdoFyUOWzTPQrJKmSDpbRv):
  fXigIEAuNdoFyUOWzTPQrJKmSDpbRx={'spotv_sessionid':fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.SPOTV_SESSIONID,'spotv_session':fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.SPOTV_SESSION,'spotv_accountId':fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.SPOTV_ACCOUNTID,'spotv_policyKey':fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.SPOTV_POLICYKEY,'spotv_subend':fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.SPOTV_SUBEND}
  return fXigIEAuNdoFyUOWzTPQrJKmSDpbRx
 def Get_Now_Datetime(fXigIEAuNdoFyUOWzTPQrJKmSDpbRv):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_Streamurl_Make(fXigIEAuNdoFyUOWzTPQrJKmSDpbRv,fXigIEAuNdoFyUOWzTPQrJKmSDpbYa):
  fXigIEAuNdoFyUOWzTPQrJKmSDpbCL='%s/%s/%s.m3u8?%s'%(fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.STREAM_DOMAIN,fXigIEAuNdoFyUOWzTPQrJKmSDpbRY.get(fXigIEAuNdoFyUOWzTPQrJKmSDpbYa).get('lv'),fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.STREAM_M3U8,fXigIEAuNdoFyUOWzTPQrJKmSDpbRY.get(fXigIEAuNdoFyUOWzTPQrJKmSDpbYa).get('rv'))
  return fXigIEAuNdoFyUOWzTPQrJKmSDpbCL
 def GetLiveChannelList(fXigIEAuNdoFyUOWzTPQrJKmSDpbRv):
  fXigIEAuNdoFyUOWzTPQrJKmSDpbCc=[]
  fXigIEAuNdoFyUOWzTPQrJKmSDpbCY ={}
  try:
   for fXigIEAuNdoFyUOWzTPQrJKmSDpbCv in fXigIEAuNdoFyUOWzTPQrJKmSDpbRc:
    fXigIEAuNdoFyUOWzTPQrJKmSDpbCs={'id':fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['id'],'name':fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['name'],'logo':fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['logo'],'videoId':fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['videoId'],'free':fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['free']}
    fXigIEAuNdoFyUOWzTPQrJKmSDpbCc.append(fXigIEAuNdoFyUOWzTPQrJKmSDpbCs)
  except fXigIEAuNdoFyUOWzTPQrJKmSDpbYq as exception:
   fXigIEAuNdoFyUOWzTPQrJKmSDpbYH(exception)
  return fXigIEAuNdoFyUOWzTPQrJKmSDpbCc
 def CheckLiveChannel(fXigIEAuNdoFyUOWzTPQrJKmSDpbRv,channelid):
  try:
   fXigIEAuNdoFyUOWzTPQrJKmSDpbCB=fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.API_DOMAIN+'/api/v2/channel'
   fXigIEAuNdoFyUOWzTPQrJKmSDpbRa=fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.callRequestCookies('Get',fXigIEAuNdoFyUOWzTPQrJKmSDpbCB,payload=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,params=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,headers=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,cookies=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw)
   fXigIEAuNdoFyUOWzTPQrJKmSDpbRV=json.loads(fXigIEAuNdoFyUOWzTPQrJKmSDpbRa.text)
   for fXigIEAuNdoFyUOWzTPQrJKmSDpbCv in fXigIEAuNdoFyUOWzTPQrJKmSDpbRV:
    if fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['videoId'].replace('ref:','')==channelid:
     return fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['free']
  except fXigIEAuNdoFyUOWzTPQrJKmSDpbYq as exception:
   fXigIEAuNdoFyUOWzTPQrJKmSDpbYH(exception)
  return fXigIEAuNdoFyUOWzTPQrJKmSDpbYM
 def GetEPGList(fXigIEAuNdoFyUOWzTPQrJKmSDpbRv):
  fXigIEAuNdoFyUOWzTPQrJKmSDpbCM={}
  fXigIEAuNdoFyUOWzTPQrJKmSDpbCe=fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.Get_Now_Datetime()
  fXigIEAuNdoFyUOWzTPQrJKmSDpbCw=fXigIEAuNdoFyUOWzTPQrJKmSDpbCe.strftime('%Y%m%d%H%M')
  fXigIEAuNdoFyUOWzTPQrJKmSDpbCH='%s-%s-%s'%(fXigIEAuNdoFyUOWzTPQrJKmSDpbCw[0:4],fXigIEAuNdoFyUOWzTPQrJKmSDpbCw[4:6],fXigIEAuNdoFyUOWzTPQrJKmSDpbCw[6:8])
  fXigIEAuNdoFyUOWzTPQrJKmSDpbCl=(fXigIEAuNdoFyUOWzTPQrJKmSDpbCe+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M')
  try:
   fXigIEAuNdoFyUOWzTPQrJKmSDpbCB=fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.API_DOMAIN+'/api/v2/program/'+fXigIEAuNdoFyUOWzTPQrJKmSDpbCH
   fXigIEAuNdoFyUOWzTPQrJKmSDpbRa=fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.callRequestCookies('Get',fXigIEAuNdoFyUOWzTPQrJKmSDpbCB,payload=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,params=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,headers=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,cookies=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw)
   fXigIEAuNdoFyUOWzTPQrJKmSDpbRV=json.loads(fXigIEAuNdoFyUOWzTPQrJKmSDpbRa.text)
   fXigIEAuNdoFyUOWzTPQrJKmSDpbCk=-1 
   fXigIEAuNdoFyUOWzTPQrJKmSDpbCq =''
   for fXigIEAuNdoFyUOWzTPQrJKmSDpbCv in fXigIEAuNdoFyUOWzTPQrJKmSDpbRV:
    fXigIEAuNdoFyUOWzTPQrJKmSDpbCa=fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['channelId']
    fXigIEAuNdoFyUOWzTPQrJKmSDpbCh =fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['startTime'].replace('-','').replace(' ','').replace(':','')
    fXigIEAuNdoFyUOWzTPQrJKmSDpbCn =fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['endTime'].replace('-','').replace(' ','').replace(':','')
    if fXigIEAuNdoFyUOWzTPQrJKmSDpbYh(fXigIEAuNdoFyUOWzTPQrJKmSDpbCw)>fXigIEAuNdoFyUOWzTPQrJKmSDpbYh(fXigIEAuNdoFyUOWzTPQrJKmSDpbCn) :continue
    if fXigIEAuNdoFyUOWzTPQrJKmSDpbYh(fXigIEAuNdoFyUOWzTPQrJKmSDpbCl)<fXigIEAuNdoFyUOWzTPQrJKmSDpbYh(fXigIEAuNdoFyUOWzTPQrJKmSDpbCh):continue
    if fXigIEAuNdoFyUOWzTPQrJKmSDpbCk!=fXigIEAuNdoFyUOWzTPQrJKmSDpbCa:
     if fXigIEAuNdoFyUOWzTPQrJKmSDpbCq!='':fXigIEAuNdoFyUOWzTPQrJKmSDpbCM[fXigIEAuNdoFyUOWzTPQrJKmSDpbCk]=fXigIEAuNdoFyUOWzTPQrJKmSDpbCq
     fXigIEAuNdoFyUOWzTPQrJKmSDpbCk=fXigIEAuNdoFyUOWzTPQrJKmSDpbCa
     fXigIEAuNdoFyUOWzTPQrJKmSDpbCq =''
    if fXigIEAuNdoFyUOWzTPQrJKmSDpbCq:fXigIEAuNdoFyUOWzTPQrJKmSDpbCq+='\n'
    fXigIEAuNdoFyUOWzTPQrJKmSDpbCq+=fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['title']+'\n'
    fXigIEAuNdoFyUOWzTPQrJKmSDpbCq+=' [%s ~ %s]'%(fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['startTime'][-5:],fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['endTime'][-5:])+'\n'
   if fXigIEAuNdoFyUOWzTPQrJKmSDpbCq:fXigIEAuNdoFyUOWzTPQrJKmSDpbCM[fXigIEAuNdoFyUOWzTPQrJKmSDpbCk]=fXigIEAuNdoFyUOWzTPQrJKmSDpbCq
  except fXigIEAuNdoFyUOWzTPQrJKmSDpbYq as exception:
   fXigIEAuNdoFyUOWzTPQrJKmSDpbYH(exception)
  return fXigIEAuNdoFyUOWzTPQrJKmSDpbCM
 def GetEventLiveList(fXigIEAuNdoFyUOWzTPQrJKmSDpbRv):
  fXigIEAuNdoFyUOWzTPQrJKmSDpbCc=[]
  fXigIEAuNdoFyUOWzTPQrJKmSDpbCV =0
  try:
   fXigIEAuNdoFyUOWzTPQrJKmSDpbCj=fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.Get_Now_Datetime()
   fXigIEAuNdoFyUOWzTPQrJKmSDpbCG=fXigIEAuNdoFyUOWzTPQrJKmSDpbCj.strftime('%Y-%m-%d')
  except fXigIEAuNdoFyUOWzTPQrJKmSDpbYq as exception:
   fXigIEAuNdoFyUOWzTPQrJKmSDpbYH(exception)
   return fXigIEAuNdoFyUOWzTPQrJKmSDpbCc,fXigIEAuNdoFyUOWzTPQrJKmSDpbCV
  try:
   fXigIEAuNdoFyUOWzTPQrJKmSDpbCB=fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.API_DOMAIN+'/api/v2/player/lives/'+fXigIEAuNdoFyUOWzTPQrJKmSDpbCG 
   fXigIEAuNdoFyUOWzTPQrJKmSDpbRM=fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.makeDefaultCookies()
   fXigIEAuNdoFyUOWzTPQrJKmSDpbRa=fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.callRequestCookies('Get',fXigIEAuNdoFyUOWzTPQrJKmSDpbCB,payload=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,params=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,headers=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,cookies=fXigIEAuNdoFyUOWzTPQrJKmSDpbRM)
   fXigIEAuNdoFyUOWzTPQrJKmSDpbCV=fXigIEAuNdoFyUOWzTPQrJKmSDpbRa.status_code 
   fXigIEAuNdoFyUOWzTPQrJKmSDpbRV=json.loads(fXigIEAuNdoFyUOWzTPQrJKmSDpbRa.text)
   for fXigIEAuNdoFyUOWzTPQrJKmSDpbCt in fXigIEAuNdoFyUOWzTPQrJKmSDpbRV:
    for fXigIEAuNdoFyUOWzTPQrJKmSDpbCv in fXigIEAuNdoFyUOWzTPQrJKmSDpbCt['liveNowList']:
     if fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['gameDesc']['title']==fXigIEAuNdoFyUOWzTPQrJKmSDpbYw or fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['gameDesc']['title']=='':
      fXigIEAuNdoFyUOWzTPQrJKmSDpbCx='%s ( %s : %s )'%(fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['leagueName'],fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['homeNameShort'],fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['awayNameShort'])
     else:
      fXigIEAuNdoFyUOWzTPQrJKmSDpbCx=fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['gameDesc']['title']
     fXigIEAuNdoFyUOWzTPQrJKmSDpbCs={'liveId':fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['liveId'],'title':fXigIEAuNdoFyUOWzTPQrJKmSDpbCx,'logo':fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['gameDesc']['leagueLogo'],'free':fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['isFree'],'startTime':fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['startTime']}
     fXigIEAuNdoFyUOWzTPQrJKmSDpbCc.append(fXigIEAuNdoFyUOWzTPQrJKmSDpbCs)
  except fXigIEAuNdoFyUOWzTPQrJKmSDpbYq as exception:
   fXigIEAuNdoFyUOWzTPQrJKmSDpbYH(exception)
  return fXigIEAuNdoFyUOWzTPQrJKmSDpbCc,fXigIEAuNdoFyUOWzTPQrJKmSDpbCV
 def GetEventLive_videoId(fXigIEAuNdoFyUOWzTPQrJKmSDpbRv,liveId):
  fXigIEAuNdoFyUOWzTPQrJKmSDpbLR=''
  try:
   fXigIEAuNdoFyUOWzTPQrJKmSDpbCB=fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.API_DOMAIN+'/api/v2/live/'+liveId
   fXigIEAuNdoFyUOWzTPQrJKmSDpbRa=fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.callRequestCookies('Get',fXigIEAuNdoFyUOWzTPQrJKmSDpbCB,payload=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,params=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,headers=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,cookies=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw)
   fXigIEAuNdoFyUOWzTPQrJKmSDpbRV=json.loads(fXigIEAuNdoFyUOWzTPQrJKmSDpbRa.text)
   fXigIEAuNdoFyUOWzTPQrJKmSDpbLC=fXigIEAuNdoFyUOWzTPQrJKmSDpbRV['videoId']
   fXigIEAuNdoFyUOWzTPQrJKmSDpbLR=fXigIEAuNdoFyUOWzTPQrJKmSDpbLC.replace('ref:','')
  except fXigIEAuNdoFyUOWzTPQrJKmSDpbYq as exception:
   fXigIEAuNdoFyUOWzTPQrJKmSDpbYH(exception)
  return fXigIEAuNdoFyUOWzTPQrJKmSDpbLR
 def CheckMainEnd(fXigIEAuNdoFyUOWzTPQrJKmSDpbRv):
  fXigIEAuNdoFyUOWzTPQrJKmSDpbLc=base64.standard_b64encode((fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.SPOTV_PMCODE+fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.SPOTV_SESSIONID).encode()).decode('utf-8')
  if fXigIEAuNdoFyUOWzTPQrJKmSDpbLc=='OTg3MTgzMzM0Ng==' or fXigIEAuNdoFyUOWzTPQrJKmSDpbLc=='OTg3MTgzMzExNw==':return fXigIEAuNdoFyUOWzTPQrJKmSDpbYk
  return fXigIEAuNdoFyUOWzTPQrJKmSDpbYM
 def CheckSubEnd(fXigIEAuNdoFyUOWzTPQrJKmSDpbRv):
  fXigIEAuNdoFyUOWzTPQrJKmSDpbLY=fXigIEAuNdoFyUOWzTPQrJKmSDpbYM
  try:
   if fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.CheckMainEnd():return fXigIEAuNdoFyUOWzTPQrJKmSDpbYk 
   if fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.SPOTV_SUBEND=='0':return fXigIEAuNdoFyUOWzTPQrJKmSDpbLY
   fXigIEAuNdoFyUOWzTPQrJKmSDpbLv =fXigIEAuNdoFyUOWzTPQrJKmSDpbYh(fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.Get_Now_Datetime().strftime('%Y%m%d'))
   fXigIEAuNdoFyUOWzTPQrJKmSDpbLs =fXigIEAuNdoFyUOWzTPQrJKmSDpbYh(fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.SPOTV_SUBEND)/1000
   fXigIEAuNdoFyUOWzTPQrJKmSDpbLB =fXigIEAuNdoFyUOWzTPQrJKmSDpbYh(datetime.datetime.fromtimestamp(fXigIEAuNdoFyUOWzTPQrJKmSDpbLs,datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul')).strftime('%Y%m%d'))
   if fXigIEAuNdoFyUOWzTPQrJKmSDpbLv<=fXigIEAuNdoFyUOWzTPQrJKmSDpbLB:fXigIEAuNdoFyUOWzTPQrJKmSDpbLY=fXigIEAuNdoFyUOWzTPQrJKmSDpbYk
  except fXigIEAuNdoFyUOWzTPQrJKmSDpbYq as exception:
   fXigIEAuNdoFyUOWzTPQrJKmSDpbYH(exception)
   return fXigIEAuNdoFyUOWzTPQrJKmSDpbLY
  return fXigIEAuNdoFyUOWzTPQrJKmSDpbLY
 def GetMainJspath(fXigIEAuNdoFyUOWzTPQrJKmSDpbRv):
  fXigIEAuNdoFyUOWzTPQrJKmSDpbLM=''
  try:
   fXigIEAuNdoFyUOWzTPQrJKmSDpbCB=fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.API_DOMAIN
   fXigIEAuNdoFyUOWzTPQrJKmSDpbRa=fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.callRequestCookies('Get',fXigIEAuNdoFyUOWzTPQrJKmSDpbCB,payload=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,params=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,headers=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,cookies=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw)
   fXigIEAuNdoFyUOWzTPQrJKmSDpbLe=fXigIEAuNdoFyUOWzTPQrJKmSDpbRa.text
   fXigIEAuNdoFyUOWzTPQrJKmSDpbLw =re.findall('https://cdn.spotvnow.co.kr/dist/js/.{20}\.js',fXigIEAuNdoFyUOWzTPQrJKmSDpbLe)[0]
   fXigIEAuNdoFyUOWzTPQrJKmSDpbLM=fXigIEAuNdoFyUOWzTPQrJKmSDpbLw
  except fXigIEAuNdoFyUOWzTPQrJKmSDpbYq as exception:
   fXigIEAuNdoFyUOWzTPQrJKmSDpbYH(exception)
  return fXigIEAuNdoFyUOWzTPQrJKmSDpbLM
 def GetBcPlayerUrl(fXigIEAuNdoFyUOWzTPQrJKmSDpbRv):
  fXigIEAuNdoFyUOWzTPQrJKmSDpbLH=''
  try:
   fXigIEAuNdoFyUOWzTPQrJKmSDpbCB=fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.GetMainJspath()
   if fXigIEAuNdoFyUOWzTPQrJKmSDpbCB=='':return fXigIEAuNdoFyUOWzTPQrJKmSDpbLH
   fXigIEAuNdoFyUOWzTPQrJKmSDpbRa=fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.callRequestCookies('Get',fXigIEAuNdoFyUOWzTPQrJKmSDpbCB,payload=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,params=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,headers=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,cookies=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw)
   fXigIEAuNdoFyUOWzTPQrJKmSDpbLe=fXigIEAuNdoFyUOWzTPQrJKmSDpbRa.text
   fXigIEAuNdoFyUOWzTPQrJKmSDpbLl =re.findall('bc:\s*\"\d{13}\",\s*player:\s*\".{9}\"',fXigIEAuNdoFyUOWzTPQrJKmSDpbLe)[0]
   fXigIEAuNdoFyUOWzTPQrJKmSDpbLl =fXigIEAuNdoFyUOWzTPQrJKmSDpbLl.replace('bc','"bc"')
   fXigIEAuNdoFyUOWzTPQrJKmSDpbLl =fXigIEAuNdoFyUOWzTPQrJKmSDpbLl.replace('player','"player"')
   fXigIEAuNdoFyUOWzTPQrJKmSDpbLl ='{'+fXigIEAuNdoFyUOWzTPQrJKmSDpbLl+'}'
   fXigIEAuNdoFyUOWzTPQrJKmSDpbLl =json.loads(fXigIEAuNdoFyUOWzTPQrJKmSDpbLl)
   bc =fXigIEAuNdoFyUOWzTPQrJKmSDpbLl['bc']
   fXigIEAuNdoFyUOWzTPQrJKmSDpbLk =fXigIEAuNdoFyUOWzTPQrJKmSDpbLl['player']
   fXigIEAuNdoFyUOWzTPQrJKmSDpbLH="%s/%s/%s_default/index.min.js"%(fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.BC_DOMAIN,bc,fXigIEAuNdoFyUOWzTPQrJKmSDpbLk)
  except fXigIEAuNdoFyUOWzTPQrJKmSDpbYq as exception:
   fXigIEAuNdoFyUOWzTPQrJKmSDpbYH(exception)
  return fXigIEAuNdoFyUOWzTPQrJKmSDpbLH
 def GetPolicyKey(fXigIEAuNdoFyUOWzTPQrJKmSDpbRv):
  fXigIEAuNdoFyUOWzTPQrJKmSDpbLq=policykey=''
  try:
   fXigIEAuNdoFyUOWzTPQrJKmSDpbCB=fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.GetBcPlayerUrl()
   if fXigIEAuNdoFyUOWzTPQrJKmSDpbCB=='':return fXigIEAuNdoFyUOWzTPQrJKmSDpbLq,fXigIEAuNdoFyUOWzTPQrJKmSDpbLh
   fXigIEAuNdoFyUOWzTPQrJKmSDpbRa=fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.callRequestCookies('Get',fXigIEAuNdoFyUOWzTPQrJKmSDpbCB,payload=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,params=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,headers=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,cookies=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw)
   fXigIEAuNdoFyUOWzTPQrJKmSDpbLe=fXigIEAuNdoFyUOWzTPQrJKmSDpbRa.text
   fXigIEAuNdoFyUOWzTPQrJKmSDpbLw =re.findall('accountId:\s*\"\d{13}\",\s*policyKey:\s*\".[^(){}]{100,300}\"',fXigIEAuNdoFyUOWzTPQrJKmSDpbLe)[0]
   fXigIEAuNdoFyUOWzTPQrJKmSDpbLw =fXigIEAuNdoFyUOWzTPQrJKmSDpbLw.replace('accountId','"accountId"')
   fXigIEAuNdoFyUOWzTPQrJKmSDpbLw =fXigIEAuNdoFyUOWzTPQrJKmSDpbLw.replace('policyKey','"policyKey"')
   fXigIEAuNdoFyUOWzTPQrJKmSDpbLw ='{'+fXigIEAuNdoFyUOWzTPQrJKmSDpbLw+'}'
   fXigIEAuNdoFyUOWzTPQrJKmSDpbLa=json.loads(fXigIEAuNdoFyUOWzTPQrJKmSDpbLw)
   fXigIEAuNdoFyUOWzTPQrJKmSDpbLq =fXigIEAuNdoFyUOWzTPQrJKmSDpbLa['accountId']
   fXigIEAuNdoFyUOWzTPQrJKmSDpbLh =fXigIEAuNdoFyUOWzTPQrJKmSDpbLa['policyKey']
  except fXigIEAuNdoFyUOWzTPQrJKmSDpbYq as exception:
   fXigIEAuNdoFyUOWzTPQrJKmSDpbYH(exception)
  return fXigIEAuNdoFyUOWzTPQrJKmSDpbLq,fXigIEAuNdoFyUOWzTPQrJKmSDpbLh
 def GetBroadURL(fXigIEAuNdoFyUOWzTPQrJKmSDpbRv,fXigIEAuNdoFyUOWzTPQrJKmSDpbLR,mediatype,fXigIEAuNdoFyUOWzTPQrJKmSDpbcs):
  fXigIEAuNdoFyUOWzTPQrJKmSDpbLn=''
  try:
   if mediatype=='live':
    fXigIEAuNdoFyUOWzTPQrJKmSDpbLR='ref%3A'+fXigIEAuNdoFyUOWzTPQrJKmSDpbLR
   else:
    fXigIEAuNdoFyUOWzTPQrJKmSDpbLR=fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.GetReplay_UrlId(fXigIEAuNdoFyUOWzTPQrJKmSDpbLR,fXigIEAuNdoFyUOWzTPQrJKmSDpbcs)
    if fXigIEAuNdoFyUOWzTPQrJKmSDpbLR=='':return fXigIEAuNdoFyUOWzTPQrJKmSDpbLn
   fXigIEAuNdoFyUOWzTPQrJKmSDpbCB=fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.PLAYER_DOMAIN+'/playback/v1/accounts/'+fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.SPOTV_ACCOUNTID+'/videos/'+fXigIEAuNdoFyUOWzTPQrJKmSDpbLR
   fXigIEAuNdoFyUOWzTPQrJKmSDpbLV={'accept':'application/json;pk='+fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.SPOTV_POLICYKEY}
   fXigIEAuNdoFyUOWzTPQrJKmSDpbRa=fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.callRequestCookies('Get',fXigIEAuNdoFyUOWzTPQrJKmSDpbCB,payload=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,params=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,headers=fXigIEAuNdoFyUOWzTPQrJKmSDpbLV,cookies=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw)
   fXigIEAuNdoFyUOWzTPQrJKmSDpbLj=json.loads(fXigIEAuNdoFyUOWzTPQrJKmSDpbRa.text)
   fXigIEAuNdoFyUOWzTPQrJKmSDpbLn=fXigIEAuNdoFyUOWzTPQrJKmSDpbLj['sources'][0]['src']
   if mediatype=='live':
    fXigIEAuNdoFyUOWzTPQrJKmSDpbLn=fXigIEAuNdoFyUOWzTPQrJKmSDpbLn.replace('playlist.m3u8','playlist_dvr.m3u8')
   fXigIEAuNdoFyUOWzTPQrJKmSDpbLn=fXigIEAuNdoFyUOWzTPQrJKmSDpbLn.replace('http://','https://')
  except fXigIEAuNdoFyUOWzTPQrJKmSDpbYq as exception:
   fXigIEAuNdoFyUOWzTPQrJKmSDpbYH(exception)
  return fXigIEAuNdoFyUOWzTPQrJKmSDpbLn
 def GetTitleGroupList(fXigIEAuNdoFyUOWzTPQrJKmSDpbRv):
  fXigIEAuNdoFyUOWzTPQrJKmSDpbCc=[]
  fXigIEAuNdoFyUOWzTPQrJKmSDpbLG=fXigIEAuNdoFyUOWzTPQrJKmSDpbYM
  try:
   fXigIEAuNdoFyUOWzTPQrJKmSDpbCB=fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.API_DOMAIN+'/api/v2/home/web'
   fXigIEAuNdoFyUOWzTPQrJKmSDpbRa=fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.callRequestCookies('Get',fXigIEAuNdoFyUOWzTPQrJKmSDpbCB,payload=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,params=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,headers=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,cookies=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw)
   fXigIEAuNdoFyUOWzTPQrJKmSDpbRV=json.loads(fXigIEAuNdoFyUOWzTPQrJKmSDpbRa.text)
   for fXigIEAuNdoFyUOWzTPQrJKmSDpbCv in fXigIEAuNdoFyUOWzTPQrJKmSDpbRV:
    if fXigIEAuNdoFyUOWzTPQrJKmSDpbYl(fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['type'])=='3':
     fXigIEAuNdoFyUOWzTPQrJKmSDpbLt=''
     for fXigIEAuNdoFyUOWzTPQrJKmSDpbLx in fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['data']['list']:
      fXigIEAuNdoFyUOWzTPQrJKmSDpbcR='[%s] %s vs %s\n<%s>\n\n'%(fXigIEAuNdoFyUOWzTPQrJKmSDpbLx['gameDesc']['roundName'],fXigIEAuNdoFyUOWzTPQrJKmSDpbLx['gameDesc']['homeNameShort'],fXigIEAuNdoFyUOWzTPQrJKmSDpbLx['gameDesc']['awayNameShort'],fXigIEAuNdoFyUOWzTPQrJKmSDpbLx['gameDesc']['beginDate'])
      fXigIEAuNdoFyUOWzTPQrJKmSDpbLt+=fXigIEAuNdoFyUOWzTPQrJKmSDpbcR
     fXigIEAuNdoFyUOWzTPQrJKmSDpbCs={'title':fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['title'],'logo':fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['logo'],'reagueId':fXigIEAuNdoFyUOWzTPQrJKmSDpbYl(fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['destId']),'subGame':fXigIEAuNdoFyUOWzTPQrJKmSDpbLt}
     fXigIEAuNdoFyUOWzTPQrJKmSDpbCc.append(fXigIEAuNdoFyUOWzTPQrJKmSDpbCs)
     if fXigIEAuNdoFyUOWzTPQrJKmSDpbYl(fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['destId'])=='13':fXigIEAuNdoFyUOWzTPQrJKmSDpbLG=fXigIEAuNdoFyUOWzTPQrJKmSDpbYk
   if fXigIEAuNdoFyUOWzTPQrJKmSDpbLG==fXigIEAuNdoFyUOWzTPQrJKmSDpbYM:
    fXigIEAuNdoFyUOWzTPQrJKmSDpbCs={'title':'UFC','logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200928/a643c7cf1c285fb0b4469c07d4c09c28.png','reagueId':'13','subGame':''}
    fXigIEAuNdoFyUOWzTPQrJKmSDpbCc.append(fXigIEAuNdoFyUOWzTPQrJKmSDpbCs)
  except fXigIEAuNdoFyUOWzTPQrJKmSDpbYq as exception:
   fXigIEAuNdoFyUOWzTPQrJKmSDpbYH(exception)
  return fXigIEAuNdoFyUOWzTPQrJKmSDpbCc
 def GetPopularGroupList(fXigIEAuNdoFyUOWzTPQrJKmSDpbRv):
  fXigIEAuNdoFyUOWzTPQrJKmSDpbCc=[]
  try:
   fXigIEAuNdoFyUOWzTPQrJKmSDpbCB=fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.API_DOMAIN+'/api/v2/home/web'
   fXigIEAuNdoFyUOWzTPQrJKmSDpbRa=fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.callRequestCookies('Get',fXigIEAuNdoFyUOWzTPQrJKmSDpbCB,payload=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,params=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,headers=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,cookies=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw)
   fXigIEAuNdoFyUOWzTPQrJKmSDpbRV=json.loads(fXigIEAuNdoFyUOWzTPQrJKmSDpbRa.text)
   for fXigIEAuNdoFyUOWzTPQrJKmSDpbCv in fXigIEAuNdoFyUOWzTPQrJKmSDpbRV:
    if fXigIEAuNdoFyUOWzTPQrJKmSDpbYl(fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['type'])=='1' and fXigIEAuNdoFyUOWzTPQrJKmSDpbYl(fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['destId'])=='4':
     for fXigIEAuNdoFyUOWzTPQrJKmSDpbLx in fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['data']['list']:
      fXigIEAuNdoFyUOWzTPQrJKmSDpbcC =fXigIEAuNdoFyUOWzTPQrJKmSDpbLx['title']
      fXigIEAuNdoFyUOWzTPQrJKmSDpbcL =fXigIEAuNdoFyUOWzTPQrJKmSDpbLx['id']
      fXigIEAuNdoFyUOWzTPQrJKmSDpbcY =fXigIEAuNdoFyUOWzTPQrJKmSDpbLx['vtype']
      fXigIEAuNdoFyUOWzTPQrJKmSDpbcv =fXigIEAuNdoFyUOWzTPQrJKmSDpbLx['imgUrl']
      fXigIEAuNdoFyUOWzTPQrJKmSDpbcs =fXigIEAuNdoFyUOWzTPQrJKmSDpbLx['vtypeId']
      fXigIEAuNdoFyUOWzTPQrJKmSDpbCs={'vodTitle':fXigIEAuNdoFyUOWzTPQrJKmSDpbcC,'vodId':fXigIEAuNdoFyUOWzTPQrJKmSDpbcL,'vodType':fXigIEAuNdoFyUOWzTPQrJKmSDpbcY,'thumbnail':fXigIEAuNdoFyUOWzTPQrJKmSDpbcv,'vtypeId':fXigIEAuNdoFyUOWzTPQrJKmSDpbYl(fXigIEAuNdoFyUOWzTPQrJKmSDpbcs),'duration':fXigIEAuNdoFyUOWzTPQrJKmSDpbYh(fXigIEAuNdoFyUOWzTPQrJKmSDpbLx['duration']/1000)}
      fXigIEAuNdoFyUOWzTPQrJKmSDpbCc.append(fXigIEAuNdoFyUOWzTPQrJKmSDpbCs)
  except fXigIEAuNdoFyUOWzTPQrJKmSDpbYq as exception:
   fXigIEAuNdoFyUOWzTPQrJKmSDpbYH(exception)
  return fXigIEAuNdoFyUOWzTPQrJKmSDpbCc
 def GetSeasonList(fXigIEAuNdoFyUOWzTPQrJKmSDpbRv,leagueId):
  fXigIEAuNdoFyUOWzTPQrJKmSDpbCc=[]
  fXigIEAuNdoFyUOWzTPQrJKmSDpbcB=fXigIEAuNdoFyUOWzTPQrJKmSDpbcM=''
  try:
   fXigIEAuNdoFyUOWzTPQrJKmSDpbCB=fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.API_DOMAIN+'/api/v2/game/league/'+leagueId
   fXigIEAuNdoFyUOWzTPQrJKmSDpbRa=fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.callRequestCookies('Get',fXigIEAuNdoFyUOWzTPQrJKmSDpbCB,payload=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,params=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,headers=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,cookies=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw)
   fXigIEAuNdoFyUOWzTPQrJKmSDpbRV=json.loads(fXigIEAuNdoFyUOWzTPQrJKmSDpbRa.text)
   fXigIEAuNdoFyUOWzTPQrJKmSDpbcB=fXigIEAuNdoFyUOWzTPQrJKmSDpbRV['name']
   fXigIEAuNdoFyUOWzTPQrJKmSDpbcM=fXigIEAuNdoFyUOWzTPQrJKmSDpbYl(fXigIEAuNdoFyUOWzTPQrJKmSDpbRV['gameTypeId'])
  except fXigIEAuNdoFyUOWzTPQrJKmSDpbYq as exception:
   fXigIEAuNdoFyUOWzTPQrJKmSDpbYH(exception)
   return fXigIEAuNdoFyUOWzTPQrJKmSDpbCc
  if fXigIEAuNdoFyUOWzTPQrJKmSDpbcM=='2':
   try:
    fXigIEAuNdoFyUOWzTPQrJKmSDpbCB=fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.API_DOMAIN+'/api/v2/year/'+leagueId
    fXigIEAuNdoFyUOWzTPQrJKmSDpbRa=fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.callRequestCookies('Get',fXigIEAuNdoFyUOWzTPQrJKmSDpbCB,payload=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,params=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,headers=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,cookies=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw)
    fXigIEAuNdoFyUOWzTPQrJKmSDpbRV=json.loads(fXigIEAuNdoFyUOWzTPQrJKmSDpbRa.text)
    for fXigIEAuNdoFyUOWzTPQrJKmSDpbCv in fXigIEAuNdoFyUOWzTPQrJKmSDpbRV:
     fXigIEAuNdoFyUOWzTPQrJKmSDpbCs={'reagueName':fXigIEAuNdoFyUOWzTPQrJKmSDpbcB,'gameTypeId':fXigIEAuNdoFyUOWzTPQrJKmSDpbcM,'seasonName':fXigIEAuNdoFyUOWzTPQrJKmSDpbYl(fXigIEAuNdoFyUOWzTPQrJKmSDpbCv),'seasonId':fXigIEAuNdoFyUOWzTPQrJKmSDpbYl(fXigIEAuNdoFyUOWzTPQrJKmSDpbCv)}
     fXigIEAuNdoFyUOWzTPQrJKmSDpbCc.append(fXigIEAuNdoFyUOWzTPQrJKmSDpbCs)
   except fXigIEAuNdoFyUOWzTPQrJKmSDpbYq as exception:
    fXigIEAuNdoFyUOWzTPQrJKmSDpbYH(exception)
    return[]
  else:
   try:
    fXigIEAuNdoFyUOWzTPQrJKmSDpbCB=fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.API_DOMAIN+'/api/v2/season/'+leagueId
    fXigIEAuNdoFyUOWzTPQrJKmSDpbRa=fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.callRequestCookies('Get',fXigIEAuNdoFyUOWzTPQrJKmSDpbCB,payload=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,params=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,headers=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,cookies=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw)
    fXigIEAuNdoFyUOWzTPQrJKmSDpbRV=json.loads(fXigIEAuNdoFyUOWzTPQrJKmSDpbRa.text)
    for fXigIEAuNdoFyUOWzTPQrJKmSDpbCv in fXigIEAuNdoFyUOWzTPQrJKmSDpbRV:
     fXigIEAuNdoFyUOWzTPQrJKmSDpbCs={'reagueName':fXigIEAuNdoFyUOWzTPQrJKmSDpbcB,'gameTypeId':fXigIEAuNdoFyUOWzTPQrJKmSDpbcM,'seasonName':fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['name'],'seasonId':fXigIEAuNdoFyUOWzTPQrJKmSDpbYl(fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['id'])}
     fXigIEAuNdoFyUOWzTPQrJKmSDpbCc.append(fXigIEAuNdoFyUOWzTPQrJKmSDpbCs)
   except fXigIEAuNdoFyUOWzTPQrJKmSDpbYq as exception:
    fXigIEAuNdoFyUOWzTPQrJKmSDpbYH(exception)
    return[]
  return fXigIEAuNdoFyUOWzTPQrJKmSDpbCc
 def GetGameList(fXigIEAuNdoFyUOWzTPQrJKmSDpbRv,fXigIEAuNdoFyUOWzTPQrJKmSDpbcM,leagueId,seasonId,page_int):
  fXigIEAuNdoFyUOWzTPQrJKmSDpbCc=[]
  fXigIEAuNdoFyUOWzTPQrJKmSDpbce=fXigIEAuNdoFyUOWzTPQrJKmSDpbYM
  try:
   fXigIEAuNdoFyUOWzTPQrJKmSDpbCB=fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.API_DOMAIN+'/api/v2/vod/league/detail'
   fXigIEAuNdoFyUOWzTPQrJKmSDpbcw={'gameType':fXigIEAuNdoFyUOWzTPQrJKmSDpbcM,'leagueId':leagueId,'seasonId':seasonId if fXigIEAuNdoFyUOWzTPQrJKmSDpbcM!='2' else '','teamId':'','roundId':'','year':'' if fXigIEAuNdoFyUOWzTPQrJKmSDpbcM!='2' else seasonId,'pageNo':fXigIEAuNdoFyUOWzTPQrJKmSDpbYl(page_int)}
   fXigIEAuNdoFyUOWzTPQrJKmSDpbRa=fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.callRequestCookies('Get',fXigIEAuNdoFyUOWzTPQrJKmSDpbCB,payload=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,params=fXigIEAuNdoFyUOWzTPQrJKmSDpbcw,headers=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,cookies=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw)
   fXigIEAuNdoFyUOWzTPQrJKmSDpbRV=json.loads(fXigIEAuNdoFyUOWzTPQrJKmSDpbRa.text)
   fXigIEAuNdoFyUOWzTPQrJKmSDpbCt=fXigIEAuNdoFyUOWzTPQrJKmSDpbRV['list']
   for fXigIEAuNdoFyUOWzTPQrJKmSDpbcH in fXigIEAuNdoFyUOWzTPQrJKmSDpbCt:
    for fXigIEAuNdoFyUOWzTPQrJKmSDpbCv in fXigIEAuNdoFyUOWzTPQrJKmSDpbcH['list']:
     if fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['gameDesc']['title']==fXigIEAuNdoFyUOWzTPQrJKmSDpbYw or fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['gameDesc']['title']=='':
      fXigIEAuNdoFyUOWzTPQrJKmSDpbCx ='%s vs %s'%(fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['gameDesc']['homeNameShort'],fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['gameDesc']['awayNameShort'])
     else:
      fXigIEAuNdoFyUOWzTPQrJKmSDpbCx =fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['gameDesc']['title']
     fXigIEAuNdoFyUOWzTPQrJKmSDpbcl =fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['gameDesc']['beginDate']
     fXigIEAuNdoFyUOWzTPQrJKmSDpbck =fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['gameDesc']['id']
     fXigIEAuNdoFyUOWzTPQrJKmSDpbcq =fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['gameDesc']['leagueNameFull']
     fXigIEAuNdoFyUOWzTPQrJKmSDpbca =fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['gameDesc']['seasonName']
     fXigIEAuNdoFyUOWzTPQrJKmSDpbch =fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['gameDesc']['roundName']
     fXigIEAuNdoFyUOWzTPQrJKmSDpbcn =fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['gameDesc']['homeName']
     fXigIEAuNdoFyUOWzTPQrJKmSDpbcV =fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['gameDesc']['awayName']
     fXigIEAuNdoFyUOWzTPQrJKmSDpbcj =fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['gameDesc']['homeScore']
     fXigIEAuNdoFyUOWzTPQrJKmSDpbcG =fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['gameDesc']['awayScore']
     fXigIEAuNdoFyUOWzTPQrJKmSDpbct ='%s\n - %s (%s)\n - %s\n\nhome : %s (Score %s)\n\naway : %s (Score %s)'%(fXigIEAuNdoFyUOWzTPQrJKmSDpbcq,fXigIEAuNdoFyUOWzTPQrJKmSDpbca,fXigIEAuNdoFyUOWzTPQrJKmSDpbch,fXigIEAuNdoFyUOWzTPQrJKmSDpbcl,fXigIEAuNdoFyUOWzTPQrJKmSDpbcn,fXigIEAuNdoFyUOWzTPQrJKmSDpbcj,fXigIEAuNdoFyUOWzTPQrJKmSDpbcV,fXigIEAuNdoFyUOWzTPQrJKmSDpbcG)
     fXigIEAuNdoFyUOWzTPQrJKmSDpbcx=fXigIEAuNdoFyUOWzTPQrJKmSDpbct
     fXigIEAuNdoFyUOWzTPQrJKmSDpbYR =fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['replayVod']['count']
     fXigIEAuNdoFyUOWzTPQrJKmSDpbYC=fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['highlightVod']['count']
     fXigIEAuNdoFyUOWzTPQrJKmSDpbYL =fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['vods']['count']
     fXigIEAuNdoFyUOWzTPQrJKmSDpbcv='' 
     fXigIEAuNdoFyUOWzTPQrJKmSDpbYc=fXigIEAuNdoFyUOWzTPQrJKmSDpbYR+fXigIEAuNdoFyUOWzTPQrJKmSDpbYC+fXigIEAuNdoFyUOWzTPQrJKmSDpbYL
     if fXigIEAuNdoFyUOWzTPQrJKmSDpbYc==0:
      if fXigIEAuNdoFyUOWzTPQrJKmSDpbcM=='2':
       fXigIEAuNdoFyUOWzTPQrJKmSDpbCx='----- %s -----'%(fXigIEAuNdoFyUOWzTPQrJKmSDpbca)
       fXigIEAuNdoFyUOWzTPQrJKmSDpbcl=''
      else:
       fXigIEAuNdoFyUOWzTPQrJKmSDpbCx+=' - 관련영상 없음'
       fXigIEAuNdoFyUOWzTPQrJKmSDpbcx+='\n\n ** 관련영상 없음 **'
     else:
      if fXigIEAuNdoFyUOWzTPQrJKmSDpbYR!=0:
       fXigIEAuNdoFyUOWzTPQrJKmSDpbcv =fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['replayVod']['list'][0]['imgUrl']
      elif fXigIEAuNdoFyUOWzTPQrJKmSDpbYC!=0:
       fXigIEAuNdoFyUOWzTPQrJKmSDpbcv =fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['highlightVod']['list'][0]['imgUrl']
      else:
       fXigIEAuNdoFyUOWzTPQrJKmSDpbcv =fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['vods']['list'][0]['imgUrl']
     fXigIEAuNdoFyUOWzTPQrJKmSDpbCs={'gameTitle':fXigIEAuNdoFyUOWzTPQrJKmSDpbCx,'gameId':fXigIEAuNdoFyUOWzTPQrJKmSDpbck,'beginDate':fXigIEAuNdoFyUOWzTPQrJKmSDpbcl[:11],'thumbnail':fXigIEAuNdoFyUOWzTPQrJKmSDpbcv,'info_plot':fXigIEAuNdoFyUOWzTPQrJKmSDpbcx,'leaguenm':fXigIEAuNdoFyUOWzTPQrJKmSDpbcq,'seasonnm':fXigIEAuNdoFyUOWzTPQrJKmSDpbca,'roundnm':fXigIEAuNdoFyUOWzTPQrJKmSDpbch,'totVodCnt':fXigIEAuNdoFyUOWzTPQrJKmSDpbYc}
     fXigIEAuNdoFyUOWzTPQrJKmSDpbCc.append(fXigIEAuNdoFyUOWzTPQrJKmSDpbCs)
   if fXigIEAuNdoFyUOWzTPQrJKmSDpbcM=='2':
    if fXigIEAuNdoFyUOWzTPQrJKmSDpbRV['count']>page_int*fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.GAMELIST_LIMIT:fXigIEAuNdoFyUOWzTPQrJKmSDpbce=fXigIEAuNdoFyUOWzTPQrJKmSDpbYk
   else:
    if fXigIEAuNdoFyUOWzTPQrJKmSDpbRV['list'][0]['count']>page_int*fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.GAMELIST_LIMIT:fXigIEAuNdoFyUOWzTPQrJKmSDpbce=fXigIEAuNdoFyUOWzTPQrJKmSDpbYk
  except fXigIEAuNdoFyUOWzTPQrJKmSDpbYq as exception:
   fXigIEAuNdoFyUOWzTPQrJKmSDpbYH(exception)
  return fXigIEAuNdoFyUOWzTPQrJKmSDpbCc,fXigIEAuNdoFyUOWzTPQrJKmSDpbce
 def GetGameVodList(fXigIEAuNdoFyUOWzTPQrJKmSDpbRv,fXigIEAuNdoFyUOWzTPQrJKmSDpbck):
  fXigIEAuNdoFyUOWzTPQrJKmSDpbCc=[]
  fXigIEAuNdoFyUOWzTPQrJKmSDpbYv=''
  try:
   fXigIEAuNdoFyUOWzTPQrJKmSDpbCB=fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.API_DOMAIN+'/api/v2/vod/game'
   fXigIEAuNdoFyUOWzTPQrJKmSDpbcw={'gameId':fXigIEAuNdoFyUOWzTPQrJKmSDpbck,'pageItem':'1000'}
   fXigIEAuNdoFyUOWzTPQrJKmSDpbRa=fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.callRequestCookies('Get',fXigIEAuNdoFyUOWzTPQrJKmSDpbCB,payload=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,params=fXigIEAuNdoFyUOWzTPQrJKmSDpbcw,headers=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,cookies=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw)
   fXigIEAuNdoFyUOWzTPQrJKmSDpbRV=json.loads(fXigIEAuNdoFyUOWzTPQrJKmSDpbRa.text)
   fXigIEAuNdoFyUOWzTPQrJKmSDpbcH=fXigIEAuNdoFyUOWzTPQrJKmSDpbRV['list']
   for fXigIEAuNdoFyUOWzTPQrJKmSDpbCv in fXigIEAuNdoFyUOWzTPQrJKmSDpbcH:
    fXigIEAuNdoFyUOWzTPQrJKmSDpbcC =fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['title']
    fXigIEAuNdoFyUOWzTPQrJKmSDpbcL =fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['id']
    fXigIEAuNdoFyUOWzTPQrJKmSDpbcY =fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['vtype']
    fXigIEAuNdoFyUOWzTPQrJKmSDpbcv =fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['imgUrl']
    fXigIEAuNdoFyUOWzTPQrJKmSDpbcs =fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['vtypeId']
    fXigIEAuNdoFyUOWzTPQrJKmSDpbCs={'vodTitle':fXigIEAuNdoFyUOWzTPQrJKmSDpbcC,'vodId':fXigIEAuNdoFyUOWzTPQrJKmSDpbcL,'vodType':fXigIEAuNdoFyUOWzTPQrJKmSDpbcY,'thumbnail':fXigIEAuNdoFyUOWzTPQrJKmSDpbcv,'vtypeId':fXigIEAuNdoFyUOWzTPQrJKmSDpbYl(fXigIEAuNdoFyUOWzTPQrJKmSDpbcs),'duration':fXigIEAuNdoFyUOWzTPQrJKmSDpbYh(fXigIEAuNdoFyUOWzTPQrJKmSDpbCv['duration']/1000)}
    fXigIEAuNdoFyUOWzTPQrJKmSDpbCc.append(fXigIEAuNdoFyUOWzTPQrJKmSDpbCs)
  except fXigIEAuNdoFyUOWzTPQrJKmSDpbYq as exception:
   fXigIEAuNdoFyUOWzTPQrJKmSDpbYH(exception)
  return fXigIEAuNdoFyUOWzTPQrJKmSDpbCc
 def GetReplay_UrlId(fXigIEAuNdoFyUOWzTPQrJKmSDpbRv,fXigIEAuNdoFyUOWzTPQrJKmSDpbYv,fXigIEAuNdoFyUOWzTPQrJKmSDpbcs):
  fXigIEAuNdoFyUOWzTPQrJKmSDpbYs=fXigIEAuNdoFyUOWzTPQrJKmSDpbLR=''
  fXigIEAuNdoFyUOWzTPQrJKmSDpbYB=''
  try:
   fXigIEAuNdoFyUOWzTPQrJKmSDpbCB=fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.API_DOMAIN+'/api/v2/vod/'+fXigIEAuNdoFyUOWzTPQrJKmSDpbYv
   fXigIEAuNdoFyUOWzTPQrJKmSDpbRa=fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.callRequestCookies('Get',fXigIEAuNdoFyUOWzTPQrJKmSDpbCB,payload=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,params=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,headers=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw,cookies=fXigIEAuNdoFyUOWzTPQrJKmSDpbYw)
   fXigIEAuNdoFyUOWzTPQrJKmSDpbRV=json.loads(fXigIEAuNdoFyUOWzTPQrJKmSDpbRa.text)
   fXigIEAuNdoFyUOWzTPQrJKmSDpbYs =fXigIEAuNdoFyUOWzTPQrJKmSDpbRV['clipId']
   fXigIEAuNdoFyUOWzTPQrJKmSDpbLR=fXigIEAuNdoFyUOWzTPQrJKmSDpbRV['videoId']
   fXigIEAuNdoFyUOWzTPQrJKmSDpbYB=fXigIEAuNdoFyUOWzTPQrJKmSDpbYs
   if fXigIEAuNdoFyUOWzTPQrJKmSDpbRv.CheckSubEnd()or fXigIEAuNdoFyUOWzTPQrJKmSDpbcs!='1':fXigIEAuNdoFyUOWzTPQrJKmSDpbYB=fXigIEAuNdoFyUOWzTPQrJKmSDpbLR 
  except fXigIEAuNdoFyUOWzTPQrJKmSDpbYq as exception:
   fXigIEAuNdoFyUOWzTPQrJKmSDpbYH(exception)
  return fXigIEAuNdoFyUOWzTPQrJKmSDpbYB
# Created by pyminifier (https://github.com/liftoff/pyminifier)
