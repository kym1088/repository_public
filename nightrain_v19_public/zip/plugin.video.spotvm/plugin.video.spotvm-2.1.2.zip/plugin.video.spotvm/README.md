# spotvM-v19
 스포티비 나우 애드온 for Kodi19

###
# 저장소를 통해서만 업데이트 됩니다.
* [Korea OTT Package for Kodi 18 (public)-18.0.0.zip](https://github.com/kym1088/repository_public/raw/master/repository.nightrain_v18_public.zip)
* [Korea OTT Package for Kodi 19 (public)-19.0.0.zip](https://github.com/kym1088/repository_public/raw/master/repository.nightrain_v19_public.zip)
###


# 공통

## Version 2.1.2 (2021.01.03)
- 라이브tv 서비스 삭제

## Version 2.1.1 (2020.12.25)
- 썸네일, info

## Version 2.1.0 (2020.11.01)
- channel check

## Version 2.0.7 (2020.10.20)
- kodi update 대응

## Version 2.0.6 (2020.10.08)
- alpha_2 오류 수정

## Version 2.0.5 (2020.10.07)
- TV채널 조회순서 조정

## Version 2.0.4 (2020.10.05)
- live 중계 추가

## Version 2.0.3 (2020.09.26)
- 유료사용자 지원

## Version 2.0.2 (2020.09.20)
- VOD 목록

## Version 2.0.1 (2020.09.16)
- 재접속 오류수정

## Version 2.0.0 (2020.09.15)
- kodi 19 라이브채널 재생
