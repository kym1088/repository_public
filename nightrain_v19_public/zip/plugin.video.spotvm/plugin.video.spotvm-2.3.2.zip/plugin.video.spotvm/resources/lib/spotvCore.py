__author__="NightRain"
zfXIYoCinWBMLtOpbuksSjNhFmTHVl=object
zfXIYoCinWBMLtOpbuksSjNhFmTHVA=print
zfXIYoCinWBMLtOpbuksSjNhFmTHVc=None
zfXIYoCinWBMLtOpbuksSjNhFmTHVy=False
zfXIYoCinWBMLtOpbuksSjNhFmTHVa=str
zfXIYoCinWBMLtOpbuksSjNhFmTHVP=open
zfXIYoCinWBMLtOpbuksSjNhFmTHVq=True
zfXIYoCinWBMLtOpbuksSjNhFmTHVQ=int
zfXIYoCinWBMLtOpbuksSjNhFmTHVg=Exception
zfXIYoCinWBMLtOpbuksSjNhFmTHVU=len
zfXIYoCinWBMLtOpbuksSjNhFmTHVv=range
import urllib
import re
import json
import sys
import time
import requests
import datetime
import base64
import random
zfXIYoCinWBMLtOpbuksSjNhFmTHEx={'stream50':1080,'stream40':720,'stream30':540}
class zfXIYoCinWBMLtOpbuksSjNhFmTHEr(zfXIYoCinWBMLtOpbuksSjNhFmTHVl):
 def __init__(zfXIYoCinWBMLtOpbuksSjNhFmTHER):
  zfXIYoCinWBMLtOpbuksSjNhFmTHER.SPOTV_PMCODE ='987'
  zfXIYoCinWBMLtOpbuksSjNhFmTHER.SPOTV_PMSIZE =3
  zfXIYoCinWBMLtOpbuksSjNhFmTHER.GAMELIST_LIMIT =10
  zfXIYoCinWBMLtOpbuksSjNhFmTHER.API_DOMAIN ='https://www.spotvnow.co.kr'
  zfXIYoCinWBMLtOpbuksSjNhFmTHER.BC_DOMAIN ='https://players.brightcove.net'
  zfXIYoCinWBMLtOpbuksSjNhFmTHER.PLAYER_DOMAIN ='https://edge.api.brightcove.com'
  zfXIYoCinWBMLtOpbuksSjNhFmTHER.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36'
  zfXIYoCinWBMLtOpbuksSjNhFmTHER.DEFAULT_HEADER ={'user-agent':zfXIYoCinWBMLtOpbuksSjNhFmTHER.USER_AGENT}
  zfXIYoCinWBMLtOpbuksSjNhFmTHER.COOKIE_FILE_NAME=''
  zfXIYoCinWBMLtOpbuksSjNhFmTHER.KodiVersion =20
  zfXIYoCinWBMLtOpbuksSjNhFmTHER.SP_CONTEXTJSON_FILE1 =''
  zfXIYoCinWBMLtOpbuksSjNhFmTHER.SP_CONTEXTJSON_FILE2 =''
  zfXIYoCinWBMLtOpbuksSjNhFmTHER.ST ={}
  zfXIYoCinWBMLtOpbuksSjNhFmTHER.Init_ST_Total()
 def Init_ST_Total(zfXIYoCinWBMLtOpbuksSjNhFmTHER):
  zfXIYoCinWBMLtOpbuksSjNhFmTHER.ST={'account':{},'cookies':{},}
 def addon_log(zfXIYoCinWBMLtOpbuksSjNhFmTHER,string):
  try:
   import xbmcaddon,xbmc
   __version__=xbmcaddon.Addon().getAddonInfo('version')
   __addonid__=xbmcaddon.Addon().getAddonInfo('id')
   zfXIYoCinWBMLtOpbuksSjNhFmTHEV=string.encode('utf-8','ignore')
   zfXIYoCinWBMLtOpbuksSjNhFmTHEw=xbmc.LOGINFO
   xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,zfXIYoCinWBMLtOpbuksSjNhFmTHEV),level=zfXIYoCinWBMLtOpbuksSjNhFmTHEw)
  except:
   zfXIYoCinWBMLtOpbuksSjNhFmTHVA(string)
 def callRequestCookies(zfXIYoCinWBMLtOpbuksSjNhFmTHER,jobtype,zfXIYoCinWBMLtOpbuksSjNhFmTHEU,payload=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,json=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,params=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,headers=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,cookies=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,redirects=zfXIYoCinWBMLtOpbuksSjNhFmTHVy):
  zfXIYoCinWBMLtOpbuksSjNhFmTHEe=zfXIYoCinWBMLtOpbuksSjNhFmTHER.DEFAULT_HEADER
  if headers:zfXIYoCinWBMLtOpbuksSjNhFmTHEe.update(headers)
  if jobtype=='Get':
   zfXIYoCinWBMLtOpbuksSjNhFmTHEG=requests.get(zfXIYoCinWBMLtOpbuksSjNhFmTHEU,params=params,headers=zfXIYoCinWBMLtOpbuksSjNhFmTHEe,cookies=cookies,allow_redirects=redirects)
  else:
   zfXIYoCinWBMLtOpbuksSjNhFmTHEG=requests.post(zfXIYoCinWBMLtOpbuksSjNhFmTHEU,data=payload,json=json,params=params,headers=zfXIYoCinWBMLtOpbuksSjNhFmTHEe,cookies=cookies,allow_redirects=redirects)
  try:
   zfXIYoCinWBMLtOpbuksSjNhFmTHER.addon_log(zfXIYoCinWBMLtOpbuksSjNhFmTHVa(zfXIYoCinWBMLtOpbuksSjNhFmTHEG.status_code)+' : '+zfXIYoCinWBMLtOpbuksSjNhFmTHEG.url)
  except:
   zfXIYoCinWBMLtOpbuksSjNhFmTHVc
  return zfXIYoCinWBMLtOpbuksSjNhFmTHEG
 def JsonFile_Save(zfXIYoCinWBMLtOpbuksSjNhFmTHER,filename,zfXIYoCinWBMLtOpbuksSjNhFmTHEl):
  if filename=='':return zfXIYoCinWBMLtOpbuksSjNhFmTHVy
  try:
   fp=zfXIYoCinWBMLtOpbuksSjNhFmTHVP(filename,'w',-1,'utf-8')
   json.dump(zfXIYoCinWBMLtOpbuksSjNhFmTHEl,fp,indent=4,ensure_ascii=zfXIYoCinWBMLtOpbuksSjNhFmTHVy)
   fp.close()
  except:
   return zfXIYoCinWBMLtOpbuksSjNhFmTHVy
  return zfXIYoCinWBMLtOpbuksSjNhFmTHVq
 def JsonFile_Load(zfXIYoCinWBMLtOpbuksSjNhFmTHER,filename):
  if filename=='':return{}
  try:
   fp=zfXIYoCinWBMLtOpbuksSjNhFmTHVP(filename,'r',-1,'utf-8')
   zfXIYoCinWBMLtOpbuksSjNhFmTHEc=json.load(fp)
   fp.close()
  except:
   return{}
  return zfXIYoCinWBMLtOpbuksSjNhFmTHEc
 def Save_session_acount(zfXIYoCinWBMLtOpbuksSjNhFmTHER,zfXIYoCinWBMLtOpbuksSjNhFmTHEy,zfXIYoCinWBMLtOpbuksSjNhFmTHEa):
  zfXIYoCinWBMLtOpbuksSjNhFmTHER.ST['account']['stid'] =base64.standard_b64encode(zfXIYoCinWBMLtOpbuksSjNhFmTHEy.encode()).decode('utf-8')
  zfXIYoCinWBMLtOpbuksSjNhFmTHER.ST['account']['stpw'] =base64.standard_b64encode(zfXIYoCinWBMLtOpbuksSjNhFmTHEa.encode()).decode('utf-8')
 def Load_session_acount(zfXIYoCinWBMLtOpbuksSjNhFmTHER):
  try:
   zfXIYoCinWBMLtOpbuksSjNhFmTHEy =base64.standard_b64decode(zfXIYoCinWBMLtOpbuksSjNhFmTHER.ST['account']['stid']).decode('utf-8')
   zfXIYoCinWBMLtOpbuksSjNhFmTHEa =base64.standard_b64decode(zfXIYoCinWBMLtOpbuksSjNhFmTHER.ST['account']['stpw']).decode('utf-8')
  except:
   return '',''
  return zfXIYoCinWBMLtOpbuksSjNhFmTHEy,zfXIYoCinWBMLtOpbuksSjNhFmTHEa
 def makeDefaultCookies(zfXIYoCinWBMLtOpbuksSjNhFmTHER):
  zfXIYoCinWBMLtOpbuksSjNhFmTHEP={'id_token':zfXIYoCinWBMLtOpbuksSjNhFmTHER.ST['cookies']['id_token'],}
  return zfXIYoCinWBMLtOpbuksSjNhFmTHEP
 def makeDefaultHeaders(zfXIYoCinWBMLtOpbuksSjNhFmTHER):
  zfXIYoCinWBMLtOpbuksSjNhFmTHEq={'accept':'application/json;pk={}'.format(zfXIYoCinWBMLtOpbuksSjNhFmTHER.ST['cookies']['spotv_policyKey'])}
  return zfXIYoCinWBMLtOpbuksSjNhFmTHEq
 def xmlText(zfXIYoCinWBMLtOpbuksSjNhFmTHER,in_text):
  zfXIYoCinWBMLtOpbuksSjNhFmTHEQ=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;')
  return zfXIYoCinWBMLtOpbuksSjNhFmTHEQ
 def GetNoCache(zfXIYoCinWBMLtOpbuksSjNhFmTHER,timetype=1):
  if timetype==1:
   return zfXIYoCinWBMLtOpbuksSjNhFmTHVQ(time.time())
  else:
   return zfXIYoCinWBMLtOpbuksSjNhFmTHVQ(time.time()*1000)
 def GetCredential_new(zfXIYoCinWBMLtOpbuksSjNhFmTHER,user_id,user_pw):
  zfXIYoCinWBMLtOpbuksSjNhFmTHEg=requests.session()
  try:
   zfXIYoCinWBMLtOpbuksSjNhFmTHEU='https://nid.spotvnow.co.kr/api/v3/oauth2/authorize/spotvnow?return_url=https%3A%2F%2Fwww.spotvnow.co.kr%2F&err_return_url=https%3A%2F%2Fwww.spotvnow.co.kr%2Fabout&logout_url=https%3A%2F%2Fwww.spotvnow.co.kr%2Fintro'
   zfXIYoCinWBMLtOpbuksSjNhFmTHEq={'Referer':'https://www.spotvnow.co.kr/login','User-Agent':zfXIYoCinWBMLtOpbuksSjNhFmTHER.USER_AGENT,}
   while(zfXIYoCinWBMLtOpbuksSjNhFmTHEU not in['',zfXIYoCinWBMLtOpbuksSjNhFmTHVc]):
    zfXIYoCinWBMLtOpbuksSjNhFmTHEv=zfXIYoCinWBMLtOpbuksSjNhFmTHEg.get(zfXIYoCinWBMLtOpbuksSjNhFmTHEU,params=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,headers=zfXIYoCinWBMLtOpbuksSjNhFmTHEq,cookies=zfXIYoCinWBMLtOpbuksSjNhFmTHER.ST['cookies'],allow_redirects=zfXIYoCinWBMLtOpbuksSjNhFmTHVy)
    zfXIYoCinWBMLtOpbuksSjNhFmTHEU =zfXIYoCinWBMLtOpbuksSjNhFmTHEv.headers.get('location')
    for zfXIYoCinWBMLtOpbuksSjNhFmTHEJ in zfXIYoCinWBMLtOpbuksSjNhFmTHEv.cookies:
     if zfXIYoCinWBMLtOpbuksSjNhFmTHEJ.value not in['',zfXIYoCinWBMLtOpbuksSjNhFmTHVc]:
      zfXIYoCinWBMLtOpbuksSjNhFmTHER.ST['cookies'][zfXIYoCinWBMLtOpbuksSjNhFmTHEJ.name]=zfXIYoCinWBMLtOpbuksSjNhFmTHEJ.value
    if zfXIYoCinWBMLtOpbuksSjNhFmTHEv.status_code==200:break
   if zfXIYoCinWBMLtOpbuksSjNhFmTHER.ST['cookies']['login_challenge']=='':
    zfXIYoCinWBMLtOpbuksSjNhFmTHER.Init_ST_Total()
    return zfXIYoCinWBMLtOpbuksSjNhFmTHVy
  except zfXIYoCinWBMLtOpbuksSjNhFmTHVg as exception:
   zfXIYoCinWBMLtOpbuksSjNhFmTHVA(exception)
   zfXIYoCinWBMLtOpbuksSjNhFmTHER.Init_ST_Total()
   return zfXIYoCinWBMLtOpbuksSjNhFmTHVy
  zfXIYoCinWBMLtOpbuksSjNhFmTHER.addon_log('login : step 1') 
  try:
   zfXIYoCinWBMLtOpbuksSjNhFmTHED=base64.standard_b64encode(user_id.encode('UTF-8')).decode('utf-8')
   zfXIYoCinWBMLtOpbuksSjNhFmTHEd=base64.standard_b64encode(user_pw.encode('UTF-8')).decode('utf-8')
   zfXIYoCinWBMLtOpbuksSjNhFmTHEU='https://nid.spotvnow.co.kr/api/v3/user-auth/login'
   zfXIYoCinWBMLtOpbuksSjNhFmTHEq={'User-Agent':zfXIYoCinWBMLtOpbuksSjNhFmTHER.USER_AGENT,'Referer':'https://www.spotvnow.co.kr/',}
   zfXIYoCinWBMLtOpbuksSjNhFmTHEK={'username':zfXIYoCinWBMLtOpbuksSjNhFmTHED,'password':zfXIYoCinWBMLtOpbuksSjNhFmTHEd,'remember':zfXIYoCinWBMLtOpbuksSjNhFmTHVy,'err_return_url':'https://www.spotvnow.co.kr/intro',}
   zfXIYoCinWBMLtOpbuksSjNhFmTHEv=zfXIYoCinWBMLtOpbuksSjNhFmTHEg.post(zfXIYoCinWBMLtOpbuksSjNhFmTHEU,data=zfXIYoCinWBMLtOpbuksSjNhFmTHEK,params=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,headers=zfXIYoCinWBMLtOpbuksSjNhFmTHEq,cookies=zfXIYoCinWBMLtOpbuksSjNhFmTHER.ST['cookies'],allow_redirects=zfXIYoCinWBMLtOpbuksSjNhFmTHVy)
   for zfXIYoCinWBMLtOpbuksSjNhFmTHEJ in zfXIYoCinWBMLtOpbuksSjNhFmTHEv.cookies:
    if zfXIYoCinWBMLtOpbuksSjNhFmTHEJ.value not in['',zfXIYoCinWBMLtOpbuksSjNhFmTHVc]:
     zfXIYoCinWBMLtOpbuksSjNhFmTHER.ST['cookies'][zfXIYoCinWBMLtOpbuksSjNhFmTHEJ.name]=zfXIYoCinWBMLtOpbuksSjNhFmTHEJ.value
   zfXIYoCinWBMLtOpbuksSjNhFmTHEU=zfXIYoCinWBMLtOpbuksSjNhFmTHEv.headers.get('location')
   while(zfXIYoCinWBMLtOpbuksSjNhFmTHEU not in['',zfXIYoCinWBMLtOpbuksSjNhFmTHVc]):
    zfXIYoCinWBMLtOpbuksSjNhFmTHEv=zfXIYoCinWBMLtOpbuksSjNhFmTHEg.get(zfXIYoCinWBMLtOpbuksSjNhFmTHEU,params=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,headers=zfXIYoCinWBMLtOpbuksSjNhFmTHEq,cookies=zfXIYoCinWBMLtOpbuksSjNhFmTHER.ST['cookies'],allow_redirects=zfXIYoCinWBMLtOpbuksSjNhFmTHVy)
    zfXIYoCinWBMLtOpbuksSjNhFmTHEU =zfXIYoCinWBMLtOpbuksSjNhFmTHEv.headers.get('location')
    for zfXIYoCinWBMLtOpbuksSjNhFmTHEJ in zfXIYoCinWBMLtOpbuksSjNhFmTHEv.cookies:
     if zfXIYoCinWBMLtOpbuksSjNhFmTHEJ.value not in['',zfXIYoCinWBMLtOpbuksSjNhFmTHVc]:
      zfXIYoCinWBMLtOpbuksSjNhFmTHER.ST['cookies'][zfXIYoCinWBMLtOpbuksSjNhFmTHEJ.name]=zfXIYoCinWBMLtOpbuksSjNhFmTHEJ.value
    if zfXIYoCinWBMLtOpbuksSjNhFmTHEv.status_code==200:break
   if zfXIYoCinWBMLtOpbuksSjNhFmTHER.ST['cookies']['id_token']=='':
    zfXIYoCinWBMLtOpbuksSjNhFmTHER.Init_ST_Total()
    return zfXIYoCinWBMLtOpbuksSjNhFmTHVy
  except zfXIYoCinWBMLtOpbuksSjNhFmTHVg as exception:
   zfXIYoCinWBMLtOpbuksSjNhFmTHVA(exception)
   zfXIYoCinWBMLtOpbuksSjNhFmTHER.Init_ST_Total()
   return zfXIYoCinWBMLtOpbuksSjNhFmTHVy
  zfXIYoCinWBMLtOpbuksSjNhFmTHER.addon_log('login : step 2')
  try:
   zfXIYoCinWBMLtOpbuksSjNhFmTHEU=zfXIYoCinWBMLtOpbuksSjNhFmTHER.API_DOMAIN+'/api/v3/session' 
   zfXIYoCinWBMLtOpbuksSjNhFmTHEP=zfXIYoCinWBMLtOpbuksSjNhFmTHER.makeDefaultCookies()
   zfXIYoCinWBMLtOpbuksSjNhFmTHEv=zfXIYoCinWBMLtOpbuksSjNhFmTHER.callRequestCookies('Get',zfXIYoCinWBMLtOpbuksSjNhFmTHEU,params=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,headers=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,cookies=zfXIYoCinWBMLtOpbuksSjNhFmTHEP)
   zfXIYoCinWBMLtOpbuksSjNhFmTHrE=json.loads(zfXIYoCinWBMLtOpbuksSjNhFmTHEv.text)
   zfXIYoCinWBMLtOpbuksSjNhFmTHER.ST['cookies']['spotv_sessionid']=zfXIYoCinWBMLtOpbuksSjNhFmTHrE.get('userId') 
   zfXIYoCinWBMLtOpbuksSjNhFmTHrx=zfXIYoCinWBMLtOpbuksSjNhFmTHER.SPOTV_PMCODE+zfXIYoCinWBMLtOpbuksSjNhFmTHVa(zfXIYoCinWBMLtOpbuksSjNhFmTHrE['subEndTime'])
   zfXIYoCinWBMLtOpbuksSjNhFmTHER.ST['cookies']['spotv_subend'] =base64.standard_b64encode(zfXIYoCinWBMLtOpbuksSjNhFmTHrx.encode()).decode('utf-8')
  except zfXIYoCinWBMLtOpbuksSjNhFmTHVg as exception:
   zfXIYoCinWBMLtOpbuksSjNhFmTHVA(exception)
   zfXIYoCinWBMLtOpbuksSjNhFmTHER.Init_ST_Total()
   return zfXIYoCinWBMLtOpbuksSjNhFmTHVy
  zfXIYoCinWBMLtOpbuksSjNhFmTHER.addon_log('login : step 3')
  try:
   if zfXIYoCinWBMLtOpbuksSjNhFmTHrE['subEndTime']in[0,'0',zfXIYoCinWBMLtOpbuksSjNhFmTHVc]:
    zfXIYoCinWBMLtOpbuksSjNhFmTHEU=zfXIYoCinWBMLtOpbuksSjNhFmTHER.API_DOMAIN+'/api/v3/user/sub/scope' 
    zfXIYoCinWBMLtOpbuksSjNhFmTHEP=zfXIYoCinWBMLtOpbuksSjNhFmTHER.makeDefaultCookies()
    zfXIYoCinWBMLtOpbuksSjNhFmTHEv=zfXIYoCinWBMLtOpbuksSjNhFmTHER.callRequestCookies('Get',zfXIYoCinWBMLtOpbuksSjNhFmTHEU,params=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,headers=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,cookies=zfXIYoCinWBMLtOpbuksSjNhFmTHEP)
    zfXIYoCinWBMLtOpbuksSjNhFmTHrE=json.loads(zfXIYoCinWBMLtOpbuksSjNhFmTHEv.text)
    if zfXIYoCinWBMLtOpbuksSjNhFmTHrE.get('endDate')==zfXIYoCinWBMLtOpbuksSjNhFmTHVc:
     zfXIYoCinWBMLtOpbuksSjNhFmTHrx=zfXIYoCinWBMLtOpbuksSjNhFmTHER.SPOTV_PMCODE+'0'
     zfXIYoCinWBMLtOpbuksSjNhFmTHER.ST['cookies']['spotv_subend'] =base64.standard_b64encode(zfXIYoCinWBMLtOpbuksSjNhFmTHrx.encode()).decode('utf-8')
    else:
     zfXIYoCinWBMLtOpbuksSjNhFmTHrR=datetime.datetime.strptime(zfXIYoCinWBMLtOpbuksSjNhFmTHrE.get('endDate'),'%Y-%m-%d %H:%M:%S')
     zfXIYoCinWBMLtOpbuksSjNhFmTHrx=zfXIYoCinWBMLtOpbuksSjNhFmTHVQ(time.mktime(zfXIYoCinWBMLtOpbuksSjNhFmTHrR.timetuple()))
     zfXIYoCinWBMLtOpbuksSjNhFmTHrx=zfXIYoCinWBMLtOpbuksSjNhFmTHER.SPOTV_PMCODE+zfXIYoCinWBMLtOpbuksSjNhFmTHVa(zfXIYoCinWBMLtOpbuksSjNhFmTHrx)+'000'
     zfXIYoCinWBMLtOpbuksSjNhFmTHER.ST['cookies']['spotv_subend'] =base64.standard_b64encode(zfXIYoCinWBMLtOpbuksSjNhFmTHrx.encode()).decode('utf-8')
  except zfXIYoCinWBMLtOpbuksSjNhFmTHVg as exception:
   zfXIYoCinWBMLtOpbuksSjNhFmTHVA(exception)
   zfXIYoCinWBMLtOpbuksSjNhFmTHER.Init_ST_Total()
   return zfXIYoCinWBMLtOpbuksSjNhFmTHVy
  zfXIYoCinWBMLtOpbuksSjNhFmTHER.addon_log('login : step 4')
  if zfXIYoCinWBMLtOpbuksSjNhFmTHER.GetPolicyKey()==zfXIYoCinWBMLtOpbuksSjNhFmTHVy:
   zfXIYoCinWBMLtOpbuksSjNhFmTHER.Init_ST_Total()
   return zfXIYoCinWBMLtOpbuksSjNhFmTHVy
  '''
  https://cdn.spotvnow.co.kr/dist/js/6ca348bfe80d471db7ef.js
    bc: {accountId: "5764318566001", policyKey: "BCpkADawqM0U3mi_PT566m5lvtapzMq3Uy7ICGGjGB6v4Ske7ZX_ynzj8ePedQJhH36nym_5mbvSYeyyHOOdUsZovyg2XlhV6rRspyYPw_USVNLaR0fB_AAL2HSQlfuetIPiEzbUs1tpNF9NtQxt3BAPvXdOAsvy1ltLPWMVzJHiw9slpLRgI2NUufc" }  
  '''  
  zfXIYoCinWBMLtOpbuksSjNhFmTHER.addon_log('login : step 5')
  return zfXIYoCinWBMLtOpbuksSjNhFmTHVq
 def GetPolicyKey(zfXIYoCinWBMLtOpbuksSjNhFmTHER):
  try:
   zfXIYoCinWBMLtOpbuksSjNhFmTHEU=zfXIYoCinWBMLtOpbuksSjNhFmTHER.GetMainJspath()
   if zfXIYoCinWBMLtOpbuksSjNhFmTHEU=='':return zfXIYoCinWBMLtOpbuksSjNhFmTHVy
   zfXIYoCinWBMLtOpbuksSjNhFmTHEv=zfXIYoCinWBMLtOpbuksSjNhFmTHER.callRequestCookies('Get',zfXIYoCinWBMLtOpbuksSjNhFmTHEU,payload=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,params=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,headers=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,cookies=zfXIYoCinWBMLtOpbuksSjNhFmTHVc)
   zfXIYoCinWBMLtOpbuksSjNhFmTHrV=zfXIYoCinWBMLtOpbuksSjNhFmTHEv.text
   zfXIYoCinWBMLtOpbuksSjNhFmTHrw =re.findall('accountId:\s*\"\d{13}\",\s*policyKey:\s*\".[^(){}]{100,300}\"',zfXIYoCinWBMLtOpbuksSjNhFmTHrV)[0]
   zfXIYoCinWBMLtOpbuksSjNhFmTHrw =zfXIYoCinWBMLtOpbuksSjNhFmTHrw.replace('accountId','"accountId"')
   zfXIYoCinWBMLtOpbuksSjNhFmTHrw =zfXIYoCinWBMLtOpbuksSjNhFmTHrw.replace('policyKey','"policyKey"')
   zfXIYoCinWBMLtOpbuksSjNhFmTHrw ='{'+zfXIYoCinWBMLtOpbuksSjNhFmTHrw+'}'
   zfXIYoCinWBMLtOpbuksSjNhFmTHre=json.loads(zfXIYoCinWBMLtOpbuksSjNhFmTHrw)
   zfXIYoCinWBMLtOpbuksSjNhFmTHER.ST['cookies']['spotv_accountId']=zfXIYoCinWBMLtOpbuksSjNhFmTHre['accountId']
   zfXIYoCinWBMLtOpbuksSjNhFmTHER.ST['cookies']['spotv_policyKey']=zfXIYoCinWBMLtOpbuksSjNhFmTHre['policyKey']
  except zfXIYoCinWBMLtOpbuksSjNhFmTHVg as exception:
   zfXIYoCinWBMLtOpbuksSjNhFmTHVA(exception)
   return zfXIYoCinWBMLtOpbuksSjNhFmTHVy
  return zfXIYoCinWBMLtOpbuksSjNhFmTHVq
 def GetMainJspath(zfXIYoCinWBMLtOpbuksSjNhFmTHER):
  zfXIYoCinWBMLtOpbuksSjNhFmTHrG=''
  try:
   zfXIYoCinWBMLtOpbuksSjNhFmTHEU=zfXIYoCinWBMLtOpbuksSjNhFmTHER.API_DOMAIN
   zfXIYoCinWBMLtOpbuksSjNhFmTHEv=zfXIYoCinWBMLtOpbuksSjNhFmTHER.callRequestCookies('Get',zfXIYoCinWBMLtOpbuksSjNhFmTHEU,payload=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,params=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,headers=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,cookies=zfXIYoCinWBMLtOpbuksSjNhFmTHVc)
   zfXIYoCinWBMLtOpbuksSjNhFmTHrV=zfXIYoCinWBMLtOpbuksSjNhFmTHEv.text
   zfXIYoCinWBMLtOpbuksSjNhFmTHrw =re.findall('https://cdn.spotvnow.co.kr/dist/js/.{20}\.js',zfXIYoCinWBMLtOpbuksSjNhFmTHrV)[0]
   zfXIYoCinWBMLtOpbuksSjNhFmTHrG=zfXIYoCinWBMLtOpbuksSjNhFmTHrw
  except zfXIYoCinWBMLtOpbuksSjNhFmTHVg as exception:
   zfXIYoCinWBMLtOpbuksSjNhFmTHVA(exception)
  return zfXIYoCinWBMLtOpbuksSjNhFmTHrG
 def Get_Now_Datetime(zfXIYoCinWBMLtOpbuksSjNhFmTHER):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetLiveChannelList(zfXIYoCinWBMLtOpbuksSjNhFmTHER):
  zfXIYoCinWBMLtOpbuksSjNhFmTHrA=[]
  zfXIYoCinWBMLtOpbuksSjNhFmTHrc ={}
  try:
   zfXIYoCinWBMLtOpbuksSjNhFmTHEU=zfXIYoCinWBMLtOpbuksSjNhFmTHER.API_DOMAIN+'/api/v3/channel'
   zfXIYoCinWBMLtOpbuksSjNhFmTHEv=zfXIYoCinWBMLtOpbuksSjNhFmTHER.callRequestCookies('Get',zfXIYoCinWBMLtOpbuksSjNhFmTHEU,payload=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,params=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,headers=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,cookies=zfXIYoCinWBMLtOpbuksSjNhFmTHVc)
   zfXIYoCinWBMLtOpbuksSjNhFmTHry=json.loads(zfXIYoCinWBMLtOpbuksSjNhFmTHEv.text)
   zfXIYoCinWBMLtOpbuksSjNhFmTHrc=zfXIYoCinWBMLtOpbuksSjNhFmTHER.GetEPGList()
   for zfXIYoCinWBMLtOpbuksSjNhFmTHra in zfXIYoCinWBMLtOpbuksSjNhFmTHry:
    zfXIYoCinWBMLtOpbuksSjNhFmTHrP={'id':zfXIYoCinWBMLtOpbuksSjNhFmTHra['id'],'name':zfXIYoCinWBMLtOpbuksSjNhFmTHra['name'],'logo':zfXIYoCinWBMLtOpbuksSjNhFmTHra['logo'],'free':zfXIYoCinWBMLtOpbuksSjNhFmTHra['free'],'programName':zfXIYoCinWBMLtOpbuksSjNhFmTHra['programName'],'channelepg':zfXIYoCinWBMLtOpbuksSjNhFmTHrc.get(zfXIYoCinWBMLtOpbuksSjNhFmTHra['id']),}
    zfXIYoCinWBMLtOpbuksSjNhFmTHrA.append(zfXIYoCinWBMLtOpbuksSjNhFmTHrP)
  except zfXIYoCinWBMLtOpbuksSjNhFmTHVg as exception:
   zfXIYoCinWBMLtOpbuksSjNhFmTHVA(exception)
  return zfXIYoCinWBMLtOpbuksSjNhFmTHrA
 def GetHlsUrl(zfXIYoCinWBMLtOpbuksSjNhFmTHER,mediacode):
  zfXIYoCinWBMLtOpbuksSjNhFmTHrq=''
  try:
   zfXIYoCinWBMLtOpbuksSjNhFmTHEU='{}/api/v3/channel/di/con/sec/web/{}'.format(zfXIYoCinWBMLtOpbuksSjNhFmTHER.API_DOMAIN,mediacode)
   zfXIYoCinWBMLtOpbuksSjNhFmTHEv=zfXIYoCinWBMLtOpbuksSjNhFmTHER.callRequestCookies('Get',zfXIYoCinWBMLtOpbuksSjNhFmTHEU,payload=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,params=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,headers=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,cookies=zfXIYoCinWBMLtOpbuksSjNhFmTHVc)
   zfXIYoCinWBMLtOpbuksSjNhFmTHrE=json.loads(zfXIYoCinWBMLtOpbuksSjNhFmTHEv.text)
   zfXIYoCinWBMLtOpbuksSjNhFmTHrq=zfXIYoCinWBMLtOpbuksSjNhFmTHrE['hlsDrmUrl']
   zfXIYoCinWBMLtOpbuksSjNhFmTHrQ =zfXIYoCinWBMLtOpbuksSjNhFmTHrE['cid']
  except zfXIYoCinWBMLtOpbuksSjNhFmTHVg as exception:
   zfXIYoCinWBMLtOpbuksSjNhFmTHVA(exception)
  return zfXIYoCinWBMLtOpbuksSjNhFmTHrQ,zfXIYoCinWBMLtOpbuksSjNhFmTHrq
 def GetEPGList(zfXIYoCinWBMLtOpbuksSjNhFmTHER):
  zfXIYoCinWBMLtOpbuksSjNhFmTHrg={}
  zfXIYoCinWBMLtOpbuksSjNhFmTHrU=zfXIYoCinWBMLtOpbuksSjNhFmTHER.Get_Now_Datetime()
  zfXIYoCinWBMLtOpbuksSjNhFmTHrv=zfXIYoCinWBMLtOpbuksSjNhFmTHrU.strftime('%Y%m%d%H%M')
  zfXIYoCinWBMLtOpbuksSjNhFmTHrJ='%s-%s-%s'%(zfXIYoCinWBMLtOpbuksSjNhFmTHrv[0:4],zfXIYoCinWBMLtOpbuksSjNhFmTHrv[4:6],zfXIYoCinWBMLtOpbuksSjNhFmTHrv[6:8])
  zfXIYoCinWBMLtOpbuksSjNhFmTHrD=(zfXIYoCinWBMLtOpbuksSjNhFmTHrU+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M')
  try:
   zfXIYoCinWBMLtOpbuksSjNhFmTHEU=zfXIYoCinWBMLtOpbuksSjNhFmTHER.API_DOMAIN+'/api/v3/program/'+zfXIYoCinWBMLtOpbuksSjNhFmTHrJ
   zfXIYoCinWBMLtOpbuksSjNhFmTHEv=zfXIYoCinWBMLtOpbuksSjNhFmTHER.callRequestCookies('Get',zfXIYoCinWBMLtOpbuksSjNhFmTHEU,payload=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,params=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,headers=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,cookies=zfXIYoCinWBMLtOpbuksSjNhFmTHVc)
   zfXIYoCinWBMLtOpbuksSjNhFmTHry=json.loads(zfXIYoCinWBMLtOpbuksSjNhFmTHEv.text)
   zfXIYoCinWBMLtOpbuksSjNhFmTHrd=-1 
   zfXIYoCinWBMLtOpbuksSjNhFmTHrK =''
   for zfXIYoCinWBMLtOpbuksSjNhFmTHra in zfXIYoCinWBMLtOpbuksSjNhFmTHry:
    zfXIYoCinWBMLtOpbuksSjNhFmTHxE=zfXIYoCinWBMLtOpbuksSjNhFmTHra['channelId']
    zfXIYoCinWBMLtOpbuksSjNhFmTHxr =zfXIYoCinWBMLtOpbuksSjNhFmTHra['startTime'].replace('-','').replace(' ','').replace(':','')
    zfXIYoCinWBMLtOpbuksSjNhFmTHxR =zfXIYoCinWBMLtOpbuksSjNhFmTHra['endTime'].replace('-','').replace(' ','').replace(':','')
    if zfXIYoCinWBMLtOpbuksSjNhFmTHVQ(zfXIYoCinWBMLtOpbuksSjNhFmTHrv)>zfXIYoCinWBMLtOpbuksSjNhFmTHVQ(zfXIYoCinWBMLtOpbuksSjNhFmTHxR) :continue
    if zfXIYoCinWBMLtOpbuksSjNhFmTHVQ(zfXIYoCinWBMLtOpbuksSjNhFmTHrD)<zfXIYoCinWBMLtOpbuksSjNhFmTHVQ(zfXIYoCinWBMLtOpbuksSjNhFmTHxr):continue
    if zfXIYoCinWBMLtOpbuksSjNhFmTHrd!=zfXIYoCinWBMLtOpbuksSjNhFmTHxE:
     if zfXIYoCinWBMLtOpbuksSjNhFmTHrK!='':zfXIYoCinWBMLtOpbuksSjNhFmTHrg[zfXIYoCinWBMLtOpbuksSjNhFmTHrd]=zfXIYoCinWBMLtOpbuksSjNhFmTHrK
     zfXIYoCinWBMLtOpbuksSjNhFmTHrd=zfXIYoCinWBMLtOpbuksSjNhFmTHxE
     zfXIYoCinWBMLtOpbuksSjNhFmTHrK =''
    if zfXIYoCinWBMLtOpbuksSjNhFmTHrK:zfXIYoCinWBMLtOpbuksSjNhFmTHrK+='\n'
    zfXIYoCinWBMLtOpbuksSjNhFmTHrK+=zfXIYoCinWBMLtOpbuksSjNhFmTHra['title']+'\n'
    zfXIYoCinWBMLtOpbuksSjNhFmTHrK+=' [%s ~ %s]'%(zfXIYoCinWBMLtOpbuksSjNhFmTHra['startTime'][-5:],zfXIYoCinWBMLtOpbuksSjNhFmTHra['endTime'][-5:])+'\n'
   if zfXIYoCinWBMLtOpbuksSjNhFmTHrK:zfXIYoCinWBMLtOpbuksSjNhFmTHrg[zfXIYoCinWBMLtOpbuksSjNhFmTHrd]=zfXIYoCinWBMLtOpbuksSjNhFmTHrK
  except zfXIYoCinWBMLtOpbuksSjNhFmTHVg as exception:
   zfXIYoCinWBMLtOpbuksSjNhFmTHVA(exception)
  return zfXIYoCinWBMLtOpbuksSjNhFmTHrg
 def GetEPGList_new(zfXIYoCinWBMLtOpbuksSjNhFmTHER):
  zfXIYoCinWBMLtOpbuksSjNhFmTHrg={}
  zfXIYoCinWBMLtOpbuksSjNhFmTHrU=zfXIYoCinWBMLtOpbuksSjNhFmTHER.Get_Now_Datetime()
  zfXIYoCinWBMLtOpbuksSjNhFmTHrv=zfXIYoCinWBMLtOpbuksSjNhFmTHrU.strftime('%Y%m%d%H%M00')
  zfXIYoCinWBMLtOpbuksSjNhFmTHrJ='%s%s%s'%(zfXIYoCinWBMLtOpbuksSjNhFmTHrv[0:4],zfXIYoCinWBMLtOpbuksSjNhFmTHrv[4:6],zfXIYoCinWBMLtOpbuksSjNhFmTHrv[6:8])
  zfXIYoCinWBMLtOpbuksSjNhFmTHrD=(zfXIYoCinWBMLtOpbuksSjNhFmTHrU+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M00')
  try:
   for zfXIYoCinWBMLtOpbuksSjNhFmTHra in LIVETV_LIST:
    zfXIYoCinWBMLtOpbuksSjNhFmTHxV =zfXIYoCinWBMLtOpbuksSjNhFmTHra['videoId']
    if zfXIYoCinWBMLtOpbuksSjNhFmTHra['epgtype']=='spotvon':
     zfXIYoCinWBMLtOpbuksSjNhFmTHrK=zfXIYoCinWBMLtOpbuksSjNhFmTHER.Get_EpgInfo_Spotv_spotvon(zfXIYoCinWBMLtOpbuksSjNhFmTHxV,zfXIYoCinWBMLtOpbuksSjNhFmTHra['epgnm'],zfXIYoCinWBMLtOpbuksSjNhFmTHrJ)
     zfXIYoCinWBMLtOpbuksSjNhFmTHrg[zfXIYoCinWBMLtOpbuksSjNhFmTHxV]=zfXIYoCinWBMLtOpbuksSjNhFmTHrK
    if zfXIYoCinWBMLtOpbuksSjNhFmTHra['epgtype']=='spotvnet':
     zfXIYoCinWBMLtOpbuksSjNhFmTHrK=zfXIYoCinWBMLtOpbuksSjNhFmTHER.Get_EpgInfo_Spotv_spotvnet(zfXIYoCinWBMLtOpbuksSjNhFmTHxV,zfXIYoCinWBMLtOpbuksSjNhFmTHra['epgnm'],zfXIYoCinWBMLtOpbuksSjNhFmTHrJ)
     zfXIYoCinWBMLtOpbuksSjNhFmTHrg[zfXIYoCinWBMLtOpbuksSjNhFmTHxV]=zfXIYoCinWBMLtOpbuksSjNhFmTHrK
   for zfXIYoCinWBMLtOpbuksSjNhFmTHxw in zfXIYoCinWBMLtOpbuksSjNhFmTHrg.keys():
    if zfXIYoCinWBMLtOpbuksSjNhFmTHVU(zfXIYoCinWBMLtOpbuksSjNhFmTHrg.get(zfXIYoCinWBMLtOpbuksSjNhFmTHxw))==0:continue
    zfXIYoCinWBMLtOpbuksSjNhFmTHrK =''
    zfXIYoCinWBMLtOpbuksSjNhFmTHxe=''
    for zfXIYoCinWBMLtOpbuksSjNhFmTHxG in zfXIYoCinWBMLtOpbuksSjNhFmTHrg.get(zfXIYoCinWBMLtOpbuksSjNhFmTHxw):
     zfXIYoCinWBMLtOpbuksSjNhFmTHxr =zfXIYoCinWBMLtOpbuksSjNhFmTHxG['startTime']
     zfXIYoCinWBMLtOpbuksSjNhFmTHxR =zfXIYoCinWBMLtOpbuksSjNhFmTHxG['endTime']
     if zfXIYoCinWBMLtOpbuksSjNhFmTHVQ(zfXIYoCinWBMLtOpbuksSjNhFmTHrv)>zfXIYoCinWBMLtOpbuksSjNhFmTHVQ(zfXIYoCinWBMLtOpbuksSjNhFmTHxR) :continue
     if zfXIYoCinWBMLtOpbuksSjNhFmTHVQ(zfXIYoCinWBMLtOpbuksSjNhFmTHrD)<zfXIYoCinWBMLtOpbuksSjNhFmTHVQ(zfXIYoCinWBMLtOpbuksSjNhFmTHxr):continue
     if zfXIYoCinWBMLtOpbuksSjNhFmTHVQ(zfXIYoCinWBMLtOpbuksSjNhFmTHrv)>=zfXIYoCinWBMLtOpbuksSjNhFmTHVQ(zfXIYoCinWBMLtOpbuksSjNhFmTHxr)and zfXIYoCinWBMLtOpbuksSjNhFmTHVQ(zfXIYoCinWBMLtOpbuksSjNhFmTHrv)<zfXIYoCinWBMLtOpbuksSjNhFmTHVQ(zfXIYoCinWBMLtOpbuksSjNhFmTHxR):zfXIYoCinWBMLtOpbuksSjNhFmTHxe=zfXIYoCinWBMLtOpbuksSjNhFmTHER.xmlText(zfXIYoCinWBMLtOpbuksSjNhFmTHxG['title'])
     if zfXIYoCinWBMLtOpbuksSjNhFmTHrK:zfXIYoCinWBMLtOpbuksSjNhFmTHrK+='\n'
     zfXIYoCinWBMLtOpbuksSjNhFmTHrK+=zfXIYoCinWBMLtOpbuksSjNhFmTHER.xmlText(zfXIYoCinWBMLtOpbuksSjNhFmTHxG['title'])+'\n'
     zfXIYoCinWBMLtOpbuksSjNhFmTHrK+=' [%s:%s ~ %s:%s]'%(zfXIYoCinWBMLtOpbuksSjNhFmTHxG['startTime'][8:10],zfXIYoCinWBMLtOpbuksSjNhFmTHxG['startTime'][10:12],zfXIYoCinWBMLtOpbuksSjNhFmTHxG['endTime'][8:10],zfXIYoCinWBMLtOpbuksSjNhFmTHxG['endTime'][10:12])+'\n'
    zfXIYoCinWBMLtOpbuksSjNhFmTHrg[zfXIYoCinWBMLtOpbuksSjNhFmTHxw]={'epg':zfXIYoCinWBMLtOpbuksSjNhFmTHrK,'title':zfXIYoCinWBMLtOpbuksSjNhFmTHxe}
  except zfXIYoCinWBMLtOpbuksSjNhFmTHVg as exception:
   zfXIYoCinWBMLtOpbuksSjNhFmTHVA(exception)
  return zfXIYoCinWBMLtOpbuksSjNhFmTHrg
 def Get_EpgInfo_Spotv_spotvon(zfXIYoCinWBMLtOpbuksSjNhFmTHER,zfXIYoCinWBMLtOpbuksSjNhFmTHxV,epgnm,now_day):
  zfXIYoCinWBMLtOpbuksSjNhFmTHrg =[]
  try:
   zfXIYoCinWBMLtOpbuksSjNhFmTHEU='https://www.spotvon.co.kr/data/onAir/%s/Daily/D%s.asp'%(epgnm,now_day)
   zfXIYoCinWBMLtOpbuksSjNhFmTHEv=zfXIYoCinWBMLtOpbuksSjNhFmTHER.callRequestCookies('Get',zfXIYoCinWBMLtOpbuksSjNhFmTHEU,payload=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,params=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,headers=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,cookies=zfXIYoCinWBMLtOpbuksSjNhFmTHVc)
   zfXIYoCinWBMLtOpbuksSjNhFmTHrE=json.loads(zfXIYoCinWBMLtOpbuksSjNhFmTHEv.text)
   for zfXIYoCinWBMLtOpbuksSjNhFmTHra in zfXIYoCinWBMLtOpbuksSjNhFmTHrE:
    zfXIYoCinWBMLtOpbuksSjNhFmTHrP={'title':zfXIYoCinWBMLtOpbuksSjNhFmTHra['title'],'startTime':zfXIYoCinWBMLtOpbuksSjNhFmTHra['sch_date'].replace('-','')+zfXIYoCinWBMLtOpbuksSjNhFmTHVa(zfXIYoCinWBMLtOpbuksSjNhFmTHra['sch_hour']).zfill(2)+zfXIYoCinWBMLtOpbuksSjNhFmTHra['sch_min']+'00'}
    zfXIYoCinWBMLtOpbuksSjNhFmTHrg.append(zfXIYoCinWBMLtOpbuksSjNhFmTHrP)
   for i in zfXIYoCinWBMLtOpbuksSjNhFmTHVv(zfXIYoCinWBMLtOpbuksSjNhFmTHVU(zfXIYoCinWBMLtOpbuksSjNhFmTHrg)):
    if i>0:zfXIYoCinWBMLtOpbuksSjNhFmTHrg[i-1]['endTime']=zfXIYoCinWBMLtOpbuksSjNhFmTHrg[i]['startTime']
    if i==zfXIYoCinWBMLtOpbuksSjNhFmTHVU(zfXIYoCinWBMLtOpbuksSjNhFmTHrg)-1: zfXIYoCinWBMLtOpbuksSjNhFmTHrg[i]['endTime']=now_day+'240000'
  except zfXIYoCinWBMLtOpbuksSjNhFmTHVg as exception:
   zfXIYoCinWBMLtOpbuksSjNhFmTHVA(exception)
   return[]
  return zfXIYoCinWBMLtOpbuksSjNhFmTHrg
 def Get_EpgInfo_Spotv_spotvnet(zfXIYoCinWBMLtOpbuksSjNhFmTHER,zfXIYoCinWBMLtOpbuksSjNhFmTHxV,epgnm,now_day):
  zfXIYoCinWBMLtOpbuksSjNhFmTHrg =[]
  try:
   zfXIYoCinWBMLtOpbuksSjNhFmTHEU='https://www.spotv.net/data/json/schedule/%s/Daily/D%s.json'%(epgnm,now_day)
   zfXIYoCinWBMLtOpbuksSjNhFmTHEv=zfXIYoCinWBMLtOpbuksSjNhFmTHER.callRequestCookies('Get',zfXIYoCinWBMLtOpbuksSjNhFmTHEU,payload=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,params=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,headers=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,cookies=zfXIYoCinWBMLtOpbuksSjNhFmTHVc)
   zfXIYoCinWBMLtOpbuksSjNhFmTHrE=json.loads(zfXIYoCinWBMLtOpbuksSjNhFmTHEv.text)
   for zfXIYoCinWBMLtOpbuksSjNhFmTHra in zfXIYoCinWBMLtOpbuksSjNhFmTHrE:
    zfXIYoCinWBMLtOpbuksSjNhFmTHrP={'title':zfXIYoCinWBMLtOpbuksSjNhFmTHra['title'],'startTime':zfXIYoCinWBMLtOpbuksSjNhFmTHra['sch_date'].replace('-','')+zfXIYoCinWBMLtOpbuksSjNhFmTHVa(zfXIYoCinWBMLtOpbuksSjNhFmTHra['sch_hour']).zfill(2)+zfXIYoCinWBMLtOpbuksSjNhFmTHra['sch_min']+'00'}
    zfXIYoCinWBMLtOpbuksSjNhFmTHrg.append(zfXIYoCinWBMLtOpbuksSjNhFmTHrP)
   for i in zfXIYoCinWBMLtOpbuksSjNhFmTHVv(zfXIYoCinWBMLtOpbuksSjNhFmTHVU(zfXIYoCinWBMLtOpbuksSjNhFmTHrg)):
    if i>0:zfXIYoCinWBMLtOpbuksSjNhFmTHrg[i-1]['endTime']=zfXIYoCinWBMLtOpbuksSjNhFmTHrg[i]['startTime']
    if i==zfXIYoCinWBMLtOpbuksSjNhFmTHVU(zfXIYoCinWBMLtOpbuksSjNhFmTHrg)-1: zfXIYoCinWBMLtOpbuksSjNhFmTHrg[i]['endTime']=now_day+'240000'
  except zfXIYoCinWBMLtOpbuksSjNhFmTHVg as exception:
   zfXIYoCinWBMLtOpbuksSjNhFmTHVA(exception)
   return[]
  return zfXIYoCinWBMLtOpbuksSjNhFmTHrg
 def GetEventLiveList(zfXIYoCinWBMLtOpbuksSjNhFmTHER):
  zfXIYoCinWBMLtOpbuksSjNhFmTHrA=[]
  zfXIYoCinWBMLtOpbuksSjNhFmTHxl =0
  try:
   zfXIYoCinWBMLtOpbuksSjNhFmTHxA=zfXIYoCinWBMLtOpbuksSjNhFmTHER.Get_Now_Datetime()
   zfXIYoCinWBMLtOpbuksSjNhFmTHxc=zfXIYoCinWBMLtOpbuksSjNhFmTHxA.strftime('%Y-%m-%d')
  except zfXIYoCinWBMLtOpbuksSjNhFmTHVg as exception:
   zfXIYoCinWBMLtOpbuksSjNhFmTHVA(exception)
   return zfXIYoCinWBMLtOpbuksSjNhFmTHrA,zfXIYoCinWBMLtOpbuksSjNhFmTHxl
  zfXIYoCinWBMLtOpbuksSjNhFmTHEU=zfXIYoCinWBMLtOpbuksSjNhFmTHER.API_DOMAIN+'/api/v3/player/lives/'+zfXIYoCinWBMLtOpbuksSjNhFmTHxc 
  zfXIYoCinWBMLtOpbuksSjNhFmTHEP=zfXIYoCinWBMLtOpbuksSjNhFmTHER.makeDefaultCookies()
  zfXIYoCinWBMLtOpbuksSjNhFmTHEv=zfXIYoCinWBMLtOpbuksSjNhFmTHER.callRequestCookies('Get',zfXIYoCinWBMLtOpbuksSjNhFmTHEU,payload=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,params=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,headers=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,cookies=zfXIYoCinWBMLtOpbuksSjNhFmTHEP)
  zfXIYoCinWBMLtOpbuksSjNhFmTHxl=zfXIYoCinWBMLtOpbuksSjNhFmTHEv.status_code 
  if zfXIYoCinWBMLtOpbuksSjNhFmTHxl!=200:return zfXIYoCinWBMLtOpbuksSjNhFmTHrA,zfXIYoCinWBMLtOpbuksSjNhFmTHxl
  zfXIYoCinWBMLtOpbuksSjNhFmTHry=json.loads(zfXIYoCinWBMLtOpbuksSjNhFmTHEv.text)
  for zfXIYoCinWBMLtOpbuksSjNhFmTHxy in zfXIYoCinWBMLtOpbuksSjNhFmTHry:
   for zfXIYoCinWBMLtOpbuksSjNhFmTHra in zfXIYoCinWBMLtOpbuksSjNhFmTHxy['liveNowList']:
    if zfXIYoCinWBMLtOpbuksSjNhFmTHra['gameDesc']['title']==zfXIYoCinWBMLtOpbuksSjNhFmTHVc or zfXIYoCinWBMLtOpbuksSjNhFmTHra['gameDesc']['title']=='':
     zfXIYoCinWBMLtOpbuksSjNhFmTHxa='%s ( %s : %s )'%(zfXIYoCinWBMLtOpbuksSjNhFmTHra['leagueName'],zfXIYoCinWBMLtOpbuksSjNhFmTHra['homeNameShort'],zfXIYoCinWBMLtOpbuksSjNhFmTHra['awayNameShort'])
    else:
     zfXIYoCinWBMLtOpbuksSjNhFmTHxa=zfXIYoCinWBMLtOpbuksSjNhFmTHra['gameDesc']['title']
    zfXIYoCinWBMLtOpbuksSjNhFmTHrP={'liveId':zfXIYoCinWBMLtOpbuksSjNhFmTHra['liveId'],'title':zfXIYoCinWBMLtOpbuksSjNhFmTHxa,'logo':zfXIYoCinWBMLtOpbuksSjNhFmTHra['gameDesc']['leagueLogo'],'free':zfXIYoCinWBMLtOpbuksSjNhFmTHra['isFree'],'startTime':zfXIYoCinWBMLtOpbuksSjNhFmTHra['startTime']}
    zfXIYoCinWBMLtOpbuksSjNhFmTHrA.append(zfXIYoCinWBMLtOpbuksSjNhFmTHrP)
  return zfXIYoCinWBMLtOpbuksSjNhFmTHrA,zfXIYoCinWBMLtOpbuksSjNhFmTHxl
 def GetEventLive_videoId(zfXIYoCinWBMLtOpbuksSjNhFmTHER,liveId):
  zfXIYoCinWBMLtOpbuksSjNhFmTHxP=''
  try:
   zfXIYoCinWBMLtOpbuksSjNhFmTHEU=zfXIYoCinWBMLtOpbuksSjNhFmTHER.API_DOMAIN+'/api/v3/live/'+liveId
   zfXIYoCinWBMLtOpbuksSjNhFmTHEv=zfXIYoCinWBMLtOpbuksSjNhFmTHER.callRequestCookies('Get',zfXIYoCinWBMLtOpbuksSjNhFmTHEU,payload=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,params=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,headers=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,cookies=zfXIYoCinWBMLtOpbuksSjNhFmTHVc)
   zfXIYoCinWBMLtOpbuksSjNhFmTHry=json.loads(zfXIYoCinWBMLtOpbuksSjNhFmTHEv.text)
   zfXIYoCinWBMLtOpbuksSjNhFmTHxq=zfXIYoCinWBMLtOpbuksSjNhFmTHry['videoId']
   zfXIYoCinWBMLtOpbuksSjNhFmTHxP=zfXIYoCinWBMLtOpbuksSjNhFmTHxq.replace('ref:','')
  except zfXIYoCinWBMLtOpbuksSjNhFmTHVg as exception:
   zfXIYoCinWBMLtOpbuksSjNhFmTHVA(exception)
  return zfXIYoCinWBMLtOpbuksSjNhFmTHxP
 def CheckMainEnd(zfXIYoCinWBMLtOpbuksSjNhFmTHER):
  zfXIYoCinWBMLtOpbuksSjNhFmTHxQ=zfXIYoCinWBMLtOpbuksSjNhFmTHER.SPOTV_PMCODE+zfXIYoCinWBMLtOpbuksSjNhFmTHVa(zfXIYoCinWBMLtOpbuksSjNhFmTHER.ST['cookies']['spotv_sessionid'])
  zfXIYoCinWBMLtOpbuksSjNhFmTHxQ=base64.standard_b64encode(zfXIYoCinWBMLtOpbuksSjNhFmTHxQ.encode()).decode('utf-8')
  if zfXIYoCinWBMLtOpbuksSjNhFmTHxQ=='OTg3MTgzMzM0Ng==' or zfXIYoCinWBMLtOpbuksSjNhFmTHxQ=='OTg3MTgzMzExNw==':return zfXIYoCinWBMLtOpbuksSjNhFmTHVq
  return zfXIYoCinWBMLtOpbuksSjNhFmTHVy
 def CheckSubEnd(zfXIYoCinWBMLtOpbuksSjNhFmTHER):
  zfXIYoCinWBMLtOpbuksSjNhFmTHEc=zfXIYoCinWBMLtOpbuksSjNhFmTHVy
  try:
   if zfXIYoCinWBMLtOpbuksSjNhFmTHER.CheckMainEnd():return zfXIYoCinWBMLtOpbuksSjNhFmTHVq 
   zfXIYoCinWBMLtOpbuksSjNhFmTHxg=base64.standard_b64decode(zfXIYoCinWBMLtOpbuksSjNhFmTHER.ST['cookies']['spotv_subend']).decode('utf-8')[zfXIYoCinWBMLtOpbuksSjNhFmTHER.SPOTV_PMSIZE:]
   if zfXIYoCinWBMLtOpbuksSjNhFmTHxg=='0':return zfXIYoCinWBMLtOpbuksSjNhFmTHEc
   zfXIYoCinWBMLtOpbuksSjNhFmTHxU =zfXIYoCinWBMLtOpbuksSjNhFmTHVQ(zfXIYoCinWBMLtOpbuksSjNhFmTHER.Get_Now_Datetime().strftime('%Y%m%d'))
   zfXIYoCinWBMLtOpbuksSjNhFmTHxv =zfXIYoCinWBMLtOpbuksSjNhFmTHVQ(zfXIYoCinWBMLtOpbuksSjNhFmTHxg)/1000
   zfXIYoCinWBMLtOpbuksSjNhFmTHxJ =zfXIYoCinWBMLtOpbuksSjNhFmTHVQ(datetime.datetime.fromtimestamp(zfXIYoCinWBMLtOpbuksSjNhFmTHxv,datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul')).strftime('%Y%m%d'))
   if zfXIYoCinWBMLtOpbuksSjNhFmTHxU<=zfXIYoCinWBMLtOpbuksSjNhFmTHxJ:zfXIYoCinWBMLtOpbuksSjNhFmTHEc=zfXIYoCinWBMLtOpbuksSjNhFmTHVq
  except zfXIYoCinWBMLtOpbuksSjNhFmTHVg as exception:
   zfXIYoCinWBMLtOpbuksSjNhFmTHVA(exception)
   return zfXIYoCinWBMLtOpbuksSjNhFmTHEc
  return zfXIYoCinWBMLtOpbuksSjNhFmTHEc
 def GetBroadURL(zfXIYoCinWBMLtOpbuksSjNhFmTHER,zfXIYoCinWBMLtOpbuksSjNhFmTHxP,mediatype,zfXIYoCinWBMLtOpbuksSjNhFmTHRe):
  zfXIYoCinWBMLtOpbuksSjNhFmTHxD=''
  try:
   if mediatype=='live':
    zfXIYoCinWBMLtOpbuksSjNhFmTHEU='{}/api/v3/live/di/con/sec/web/{}'.format(zfXIYoCinWBMLtOpbuksSjNhFmTHER.API_DOMAIN,zfXIYoCinWBMLtOpbuksSjNhFmTHxP)
   else:
    zfXIYoCinWBMLtOpbuksSjNhFmTHxP=zfXIYoCinWBMLtOpbuksSjNhFmTHER.GetReplay_UrlId(zfXIYoCinWBMLtOpbuksSjNhFmTHxP,zfXIYoCinWBMLtOpbuksSjNhFmTHRe)
    if zfXIYoCinWBMLtOpbuksSjNhFmTHxP=='':return zfXIYoCinWBMLtOpbuksSjNhFmTHxD
    zfXIYoCinWBMLtOpbuksSjNhFmTHEU=zfXIYoCinWBMLtOpbuksSjNhFmTHER.PLAYER_DOMAIN+'/playback/v1/accounts/'+zfXIYoCinWBMLtOpbuksSjNhFmTHVa(zfXIYoCinWBMLtOpbuksSjNhFmTHER.ST['cookies']['spotv_accountId'])+'/videos/'+zfXIYoCinWBMLtOpbuksSjNhFmTHxP
   zfXIYoCinWBMLtOpbuksSjNhFmTHEq=zfXIYoCinWBMLtOpbuksSjNhFmTHER.makeDefaultHeaders()
   zfXIYoCinWBMLtOpbuksSjNhFmTHEv=zfXIYoCinWBMLtOpbuksSjNhFmTHER.callRequestCookies('Get',zfXIYoCinWBMLtOpbuksSjNhFmTHEU,payload=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,params=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,headers=zfXIYoCinWBMLtOpbuksSjNhFmTHEq,cookies=zfXIYoCinWBMLtOpbuksSjNhFmTHVc)
   zfXIYoCinWBMLtOpbuksSjNhFmTHrE=json.loads(zfXIYoCinWBMLtOpbuksSjNhFmTHEv.text)
   zfXIYoCinWBMLtOpbuksSjNhFmTHVA(zfXIYoCinWBMLtOpbuksSjNhFmTHEU)
   if mediatype=='live':
    zfXIYoCinWBMLtOpbuksSjNhFmTHxD=zfXIYoCinWBMLtOpbuksSjNhFmTHrE['hlsDrmUrl']
    zfXIYoCinWBMLtOpbuksSjNhFmTHrQ =zfXIYoCinWBMLtOpbuksSjNhFmTHrE['cid']
   else:
    zfXIYoCinWBMLtOpbuksSjNhFmTHxD=zfXIYoCinWBMLtOpbuksSjNhFmTHrE['sources'][0]['src']
    zfXIYoCinWBMLtOpbuksSjNhFmTHrQ =''
   zfXIYoCinWBMLtOpbuksSjNhFmTHxD=zfXIYoCinWBMLtOpbuksSjNhFmTHxD.replace('http://','https://')
  except zfXIYoCinWBMLtOpbuksSjNhFmTHVg as exception:
   zfXIYoCinWBMLtOpbuksSjNhFmTHVA(exception)
  return zfXIYoCinWBMLtOpbuksSjNhFmTHrQ,zfXIYoCinWBMLtOpbuksSjNhFmTHxD
 def GetTitleGroupList(zfXIYoCinWBMLtOpbuksSjNhFmTHER):
  zfXIYoCinWBMLtOpbuksSjNhFmTHrA=[]
  zfXIYoCinWBMLtOpbuksSjNhFmTHEU=zfXIYoCinWBMLtOpbuksSjNhFmTHER.API_DOMAIN+'/api/v3/home/web'
  zfXIYoCinWBMLtOpbuksSjNhFmTHEv=zfXIYoCinWBMLtOpbuksSjNhFmTHER.callRequestCookies('Get',zfXIYoCinWBMLtOpbuksSjNhFmTHEU,payload=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,params=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,headers=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,cookies=zfXIYoCinWBMLtOpbuksSjNhFmTHVc)
  zfXIYoCinWBMLtOpbuksSjNhFmTHry=json.loads(zfXIYoCinWBMLtOpbuksSjNhFmTHEv.text)
  for zfXIYoCinWBMLtOpbuksSjNhFmTHra in zfXIYoCinWBMLtOpbuksSjNhFmTHry:
   if zfXIYoCinWBMLtOpbuksSjNhFmTHVa(zfXIYoCinWBMLtOpbuksSjNhFmTHra['type'])=='3':
    zfXIYoCinWBMLtOpbuksSjNhFmTHxd=''
    for zfXIYoCinWBMLtOpbuksSjNhFmTHxK in zfXIYoCinWBMLtOpbuksSjNhFmTHra['data']['list']:
     zfXIYoCinWBMLtOpbuksSjNhFmTHRE='[%s] %s vs %s\n<%s>\n\n'%(zfXIYoCinWBMLtOpbuksSjNhFmTHxK['gameDesc']['roundName'],zfXIYoCinWBMLtOpbuksSjNhFmTHxK['gameDesc']['homeNameShort'],zfXIYoCinWBMLtOpbuksSjNhFmTHxK['gameDesc']['awayNameShort'],zfXIYoCinWBMLtOpbuksSjNhFmTHxK['gameDesc']['beginDate'])
     zfXIYoCinWBMLtOpbuksSjNhFmTHxd+=zfXIYoCinWBMLtOpbuksSjNhFmTHRE
    zfXIYoCinWBMLtOpbuksSjNhFmTHrP={'title':zfXIYoCinWBMLtOpbuksSjNhFmTHra['title'],'logo':zfXIYoCinWBMLtOpbuksSjNhFmTHra['logo'],'reagueId':zfXIYoCinWBMLtOpbuksSjNhFmTHVa(zfXIYoCinWBMLtOpbuksSjNhFmTHra['destId']),'subGame':zfXIYoCinWBMLtOpbuksSjNhFmTHxd,}
    zfXIYoCinWBMLtOpbuksSjNhFmTHrA.append(zfXIYoCinWBMLtOpbuksSjNhFmTHrP)
  return zfXIYoCinWBMLtOpbuksSjNhFmTHrA
 def GetPopularGroupList(zfXIYoCinWBMLtOpbuksSjNhFmTHER):
  zfXIYoCinWBMLtOpbuksSjNhFmTHrA=[]
  zfXIYoCinWBMLtOpbuksSjNhFmTHEU=zfXIYoCinWBMLtOpbuksSjNhFmTHER.API_DOMAIN+'/api/v3/home/web'
  zfXIYoCinWBMLtOpbuksSjNhFmTHEv=zfXIYoCinWBMLtOpbuksSjNhFmTHER.callRequestCookies('Get',zfXIYoCinWBMLtOpbuksSjNhFmTHEU,payload=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,params=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,headers=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,cookies=zfXIYoCinWBMLtOpbuksSjNhFmTHVc)
  zfXIYoCinWBMLtOpbuksSjNhFmTHry=json.loads(zfXIYoCinWBMLtOpbuksSjNhFmTHEv.text)
  for zfXIYoCinWBMLtOpbuksSjNhFmTHra in zfXIYoCinWBMLtOpbuksSjNhFmTHry:
   if zfXIYoCinWBMLtOpbuksSjNhFmTHVa(zfXIYoCinWBMLtOpbuksSjNhFmTHra['type'])=='1' and zfXIYoCinWBMLtOpbuksSjNhFmTHVa(zfXIYoCinWBMLtOpbuksSjNhFmTHra['destId'])=='4':
    for zfXIYoCinWBMLtOpbuksSjNhFmTHxK in zfXIYoCinWBMLtOpbuksSjNhFmTHra['data']['list']:
     zfXIYoCinWBMLtOpbuksSjNhFmTHRr =zfXIYoCinWBMLtOpbuksSjNhFmTHxK['title']
     zfXIYoCinWBMLtOpbuksSjNhFmTHRx =zfXIYoCinWBMLtOpbuksSjNhFmTHxK['id']
     zfXIYoCinWBMLtOpbuksSjNhFmTHRV =zfXIYoCinWBMLtOpbuksSjNhFmTHxK['vtype']
     zfXIYoCinWBMLtOpbuksSjNhFmTHRw =zfXIYoCinWBMLtOpbuksSjNhFmTHxK['imgUrl']
     zfXIYoCinWBMLtOpbuksSjNhFmTHRe =zfXIYoCinWBMLtOpbuksSjNhFmTHxK['vtypeId']
     zfXIYoCinWBMLtOpbuksSjNhFmTHrP={'vodTitle':zfXIYoCinWBMLtOpbuksSjNhFmTHRr,'vodId':zfXIYoCinWBMLtOpbuksSjNhFmTHRx,'vodType':zfXIYoCinWBMLtOpbuksSjNhFmTHRV,'thumbnail':zfXIYoCinWBMLtOpbuksSjNhFmTHRw,'vtypeId':zfXIYoCinWBMLtOpbuksSjNhFmTHVa(zfXIYoCinWBMLtOpbuksSjNhFmTHRe),'duration':zfXIYoCinWBMLtOpbuksSjNhFmTHVQ(zfXIYoCinWBMLtOpbuksSjNhFmTHxK['duration']/1000),}
     zfXIYoCinWBMLtOpbuksSjNhFmTHrA.append(zfXIYoCinWBMLtOpbuksSjNhFmTHrP)
  return zfXIYoCinWBMLtOpbuksSjNhFmTHrA
 def Get_NowVod_GroupList(zfXIYoCinWBMLtOpbuksSjNhFmTHER,page_int):
  zfXIYoCinWBMLtOpbuksSjNhFmTHrA=[]
  zfXIYoCinWBMLtOpbuksSjNhFmTHRG=zfXIYoCinWBMLtOpbuksSjNhFmTHVy
  zfXIYoCinWBMLtOpbuksSjNhFmTHEU=zfXIYoCinWBMLtOpbuksSjNhFmTHER.API_DOMAIN+'/api/v3/theme/14/list'
  zfXIYoCinWBMLtOpbuksSjNhFmTHRl={'pageItem':'10','pageNo':zfXIYoCinWBMLtOpbuksSjNhFmTHVa(page_int)}
  zfXIYoCinWBMLtOpbuksSjNhFmTHEv=zfXIYoCinWBMLtOpbuksSjNhFmTHER.callRequestCookies('Get',zfXIYoCinWBMLtOpbuksSjNhFmTHEU,payload=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,params=zfXIYoCinWBMLtOpbuksSjNhFmTHRl,headers=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,cookies=zfXIYoCinWBMLtOpbuksSjNhFmTHVc)
  zfXIYoCinWBMLtOpbuksSjNhFmTHry=json.loads(zfXIYoCinWBMLtOpbuksSjNhFmTHEv.text)
  for zfXIYoCinWBMLtOpbuksSjNhFmTHra in zfXIYoCinWBMLtOpbuksSjNhFmTHry['list']:
   zfXIYoCinWBMLtOpbuksSjNhFmTHRr =zfXIYoCinWBMLtOpbuksSjNhFmTHra['title']
   zfXIYoCinWBMLtOpbuksSjNhFmTHRx =zfXIYoCinWBMLtOpbuksSjNhFmTHra['id']
   zfXIYoCinWBMLtOpbuksSjNhFmTHRV =zfXIYoCinWBMLtOpbuksSjNhFmTHra['vtype']
   zfXIYoCinWBMLtOpbuksSjNhFmTHRw =zfXIYoCinWBMLtOpbuksSjNhFmTHra['imgUrl']
   zfXIYoCinWBMLtOpbuksSjNhFmTHRe =zfXIYoCinWBMLtOpbuksSjNhFmTHra['vtypeId']
   zfXIYoCinWBMLtOpbuksSjNhFmTHrP={'vodTitle':zfXIYoCinWBMLtOpbuksSjNhFmTHRr,'vodId':zfXIYoCinWBMLtOpbuksSjNhFmTHRx,'vodType':zfXIYoCinWBMLtOpbuksSjNhFmTHRV,'thumbnail':zfXIYoCinWBMLtOpbuksSjNhFmTHRw,'vtypeId':zfXIYoCinWBMLtOpbuksSjNhFmTHVa(zfXIYoCinWBMLtOpbuksSjNhFmTHRe),'duration':zfXIYoCinWBMLtOpbuksSjNhFmTHVQ(zfXIYoCinWBMLtOpbuksSjNhFmTHra['duration']/1000),}
   zfXIYoCinWBMLtOpbuksSjNhFmTHrA.append(zfXIYoCinWBMLtOpbuksSjNhFmTHrP)
   if zfXIYoCinWBMLtOpbuksSjNhFmTHry['count']>page_int*zfXIYoCinWBMLtOpbuksSjNhFmTHER.GAMELIST_LIMIT:zfXIYoCinWBMLtOpbuksSjNhFmTHRG=zfXIYoCinWBMLtOpbuksSjNhFmTHVq
  return zfXIYoCinWBMLtOpbuksSjNhFmTHrA,zfXIYoCinWBMLtOpbuksSjNhFmTHRG
 def GetSeasonList(zfXIYoCinWBMLtOpbuksSjNhFmTHER,leagueId):
  zfXIYoCinWBMLtOpbuksSjNhFmTHrA=[]
  zfXIYoCinWBMLtOpbuksSjNhFmTHRA=zfXIYoCinWBMLtOpbuksSjNhFmTHRc=''
  try:
   zfXIYoCinWBMLtOpbuksSjNhFmTHEU=zfXIYoCinWBMLtOpbuksSjNhFmTHER.API_DOMAIN+'/api/v3/game/league/'+leagueId
   zfXIYoCinWBMLtOpbuksSjNhFmTHEv=zfXIYoCinWBMLtOpbuksSjNhFmTHER.callRequestCookies('Get',zfXIYoCinWBMLtOpbuksSjNhFmTHEU,payload=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,params=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,headers=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,cookies=zfXIYoCinWBMLtOpbuksSjNhFmTHVc)
   zfXIYoCinWBMLtOpbuksSjNhFmTHry=json.loads(zfXIYoCinWBMLtOpbuksSjNhFmTHEv.text)
   zfXIYoCinWBMLtOpbuksSjNhFmTHRA=zfXIYoCinWBMLtOpbuksSjNhFmTHry['name']
   zfXIYoCinWBMLtOpbuksSjNhFmTHRc=zfXIYoCinWBMLtOpbuksSjNhFmTHVa(zfXIYoCinWBMLtOpbuksSjNhFmTHry['gameTypeId'])
  except zfXIYoCinWBMLtOpbuksSjNhFmTHVg as exception:
   zfXIYoCinWBMLtOpbuksSjNhFmTHVA(exception)
   return zfXIYoCinWBMLtOpbuksSjNhFmTHrA
  if zfXIYoCinWBMLtOpbuksSjNhFmTHRc in['2','5','6','8']:
   try:
    zfXIYoCinWBMLtOpbuksSjNhFmTHEU=zfXIYoCinWBMLtOpbuksSjNhFmTHER.API_DOMAIN+'/api/v3/year/'+leagueId
    zfXIYoCinWBMLtOpbuksSjNhFmTHEv=zfXIYoCinWBMLtOpbuksSjNhFmTHER.callRequestCookies('Get',zfXIYoCinWBMLtOpbuksSjNhFmTHEU,payload=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,params=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,headers=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,cookies=zfXIYoCinWBMLtOpbuksSjNhFmTHVc)
    zfXIYoCinWBMLtOpbuksSjNhFmTHry=json.loads(zfXIYoCinWBMLtOpbuksSjNhFmTHEv.text)
    for zfXIYoCinWBMLtOpbuksSjNhFmTHra in zfXIYoCinWBMLtOpbuksSjNhFmTHry:
     zfXIYoCinWBMLtOpbuksSjNhFmTHrP={'reagueName':zfXIYoCinWBMLtOpbuksSjNhFmTHRA,'gameTypeId':zfXIYoCinWBMLtOpbuksSjNhFmTHRc,'seasonName':zfXIYoCinWBMLtOpbuksSjNhFmTHVa(zfXIYoCinWBMLtOpbuksSjNhFmTHra),'seasonId':zfXIYoCinWBMLtOpbuksSjNhFmTHVa(zfXIYoCinWBMLtOpbuksSjNhFmTHra)}
     zfXIYoCinWBMLtOpbuksSjNhFmTHrA.append(zfXIYoCinWBMLtOpbuksSjNhFmTHrP)
   except zfXIYoCinWBMLtOpbuksSjNhFmTHVg as exception:
    zfXIYoCinWBMLtOpbuksSjNhFmTHVA(exception)
    return[]
  else:
   try:
    zfXIYoCinWBMLtOpbuksSjNhFmTHEU=zfXIYoCinWBMLtOpbuksSjNhFmTHER.API_DOMAIN+'/api/v3/season/'+leagueId
    zfXIYoCinWBMLtOpbuksSjNhFmTHEv=zfXIYoCinWBMLtOpbuksSjNhFmTHER.callRequestCookies('Get',zfXIYoCinWBMLtOpbuksSjNhFmTHEU,payload=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,params=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,headers=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,cookies=zfXIYoCinWBMLtOpbuksSjNhFmTHVc)
    zfXIYoCinWBMLtOpbuksSjNhFmTHry=json.loads(zfXIYoCinWBMLtOpbuksSjNhFmTHEv.text)
    for zfXIYoCinWBMLtOpbuksSjNhFmTHra in zfXIYoCinWBMLtOpbuksSjNhFmTHry:
     zfXIYoCinWBMLtOpbuksSjNhFmTHrP={'reagueName':zfXIYoCinWBMLtOpbuksSjNhFmTHRA,'gameTypeId':zfXIYoCinWBMLtOpbuksSjNhFmTHRc,'seasonName':zfXIYoCinWBMLtOpbuksSjNhFmTHra['name'],'seasonId':zfXIYoCinWBMLtOpbuksSjNhFmTHVa(zfXIYoCinWBMLtOpbuksSjNhFmTHra['id'])}
     zfXIYoCinWBMLtOpbuksSjNhFmTHrA.append(zfXIYoCinWBMLtOpbuksSjNhFmTHrP)
   except zfXIYoCinWBMLtOpbuksSjNhFmTHVg as exception:
    zfXIYoCinWBMLtOpbuksSjNhFmTHVA(exception)
    return[]
  return zfXIYoCinWBMLtOpbuksSjNhFmTHrA
 def GetGameList(zfXIYoCinWBMLtOpbuksSjNhFmTHER,zfXIYoCinWBMLtOpbuksSjNhFmTHRc,leagueId,seasonId,page_int,hidescore=zfXIYoCinWBMLtOpbuksSjNhFmTHVq):
  zfXIYoCinWBMLtOpbuksSjNhFmTHrA=[]
  zfXIYoCinWBMLtOpbuksSjNhFmTHRG=zfXIYoCinWBMLtOpbuksSjNhFmTHVy
  try:
   zfXIYoCinWBMLtOpbuksSjNhFmTHEU=zfXIYoCinWBMLtOpbuksSjNhFmTHER.API_DOMAIN+'/api/v3/vod/league/detail'
   zfXIYoCinWBMLtOpbuksSjNhFmTHRl={'gameType':zfXIYoCinWBMLtOpbuksSjNhFmTHRc,'leagueId':leagueId,'seasonId':seasonId if zfXIYoCinWBMLtOpbuksSjNhFmTHRc not in['2','5','6','8']else '','teamId':'','roundId':'','year':'' if zfXIYoCinWBMLtOpbuksSjNhFmTHRc not in['2','5','6','8']else seasonId,'pageNo':zfXIYoCinWBMLtOpbuksSjNhFmTHVa(page_int)}
   zfXIYoCinWBMLtOpbuksSjNhFmTHEv=zfXIYoCinWBMLtOpbuksSjNhFmTHER.callRequestCookies('Get',zfXIYoCinWBMLtOpbuksSjNhFmTHEU,payload=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,params=zfXIYoCinWBMLtOpbuksSjNhFmTHRl,headers=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,cookies=zfXIYoCinWBMLtOpbuksSjNhFmTHVc)
   zfXIYoCinWBMLtOpbuksSjNhFmTHry=json.loads(zfXIYoCinWBMLtOpbuksSjNhFmTHEv.text)
   zfXIYoCinWBMLtOpbuksSjNhFmTHxy=zfXIYoCinWBMLtOpbuksSjNhFmTHry['list']
   for zfXIYoCinWBMLtOpbuksSjNhFmTHRy in zfXIYoCinWBMLtOpbuksSjNhFmTHxy:
    for zfXIYoCinWBMLtOpbuksSjNhFmTHra in zfXIYoCinWBMLtOpbuksSjNhFmTHRy['list']:
     if zfXIYoCinWBMLtOpbuksSjNhFmTHra['gameDesc']['title']==zfXIYoCinWBMLtOpbuksSjNhFmTHVc or zfXIYoCinWBMLtOpbuksSjNhFmTHra['gameDesc']['title']=='':
      zfXIYoCinWBMLtOpbuksSjNhFmTHxa ='%s vs %s'%(zfXIYoCinWBMLtOpbuksSjNhFmTHra['gameDesc']['homeNameShort'],zfXIYoCinWBMLtOpbuksSjNhFmTHra['gameDesc']['awayNameShort'])
     else:
      zfXIYoCinWBMLtOpbuksSjNhFmTHxa =zfXIYoCinWBMLtOpbuksSjNhFmTHra['gameDesc']['title']
     zfXIYoCinWBMLtOpbuksSjNhFmTHRa =zfXIYoCinWBMLtOpbuksSjNhFmTHra['gameDesc']['beginDate']
     zfXIYoCinWBMLtOpbuksSjNhFmTHRP =zfXIYoCinWBMLtOpbuksSjNhFmTHra['gameDesc']['id']
     zfXIYoCinWBMLtOpbuksSjNhFmTHRq =zfXIYoCinWBMLtOpbuksSjNhFmTHra['gameDesc']['leagueNameFull']
     zfXIYoCinWBMLtOpbuksSjNhFmTHRQ =zfXIYoCinWBMLtOpbuksSjNhFmTHra['gameDesc']['seasonName']
     zfXIYoCinWBMLtOpbuksSjNhFmTHRg =zfXIYoCinWBMLtOpbuksSjNhFmTHra['gameDesc']['roundName']
     zfXIYoCinWBMLtOpbuksSjNhFmTHRU =zfXIYoCinWBMLtOpbuksSjNhFmTHra['gameDesc']['homeName']
     zfXIYoCinWBMLtOpbuksSjNhFmTHRv =zfXIYoCinWBMLtOpbuksSjNhFmTHra['gameDesc']['awayName']
     zfXIYoCinWBMLtOpbuksSjNhFmTHRJ =zfXIYoCinWBMLtOpbuksSjNhFmTHra['gameDesc']['homeScore']
     zfXIYoCinWBMLtOpbuksSjNhFmTHRD =zfXIYoCinWBMLtOpbuksSjNhFmTHra['gameDesc']['awayScore']
     if hidescore==zfXIYoCinWBMLtOpbuksSjNhFmTHVq:
      zfXIYoCinWBMLtOpbuksSjNhFmTHRd ='%s\n - %s (%s)\n - %s\n\nhome : %s\n\naway : %s'%(zfXIYoCinWBMLtOpbuksSjNhFmTHRq,zfXIYoCinWBMLtOpbuksSjNhFmTHRQ,zfXIYoCinWBMLtOpbuksSjNhFmTHRg,zfXIYoCinWBMLtOpbuksSjNhFmTHRa,zfXIYoCinWBMLtOpbuksSjNhFmTHRU,zfXIYoCinWBMLtOpbuksSjNhFmTHRv)
     else:
      zfXIYoCinWBMLtOpbuksSjNhFmTHRd ='%s\n - %s (%s)\n - %s\n\nhome : %s (Score %s)\n\naway : %s (Score %s)'%(zfXIYoCinWBMLtOpbuksSjNhFmTHRq,zfXIYoCinWBMLtOpbuksSjNhFmTHRQ,zfXIYoCinWBMLtOpbuksSjNhFmTHRg,zfXIYoCinWBMLtOpbuksSjNhFmTHRa,zfXIYoCinWBMLtOpbuksSjNhFmTHRU,zfXIYoCinWBMLtOpbuksSjNhFmTHRJ,zfXIYoCinWBMLtOpbuksSjNhFmTHRv,zfXIYoCinWBMLtOpbuksSjNhFmTHRD)
     zfXIYoCinWBMLtOpbuksSjNhFmTHRK=zfXIYoCinWBMLtOpbuksSjNhFmTHRd
     zfXIYoCinWBMLtOpbuksSjNhFmTHVE =zfXIYoCinWBMLtOpbuksSjNhFmTHra['replayVod']['count']
     zfXIYoCinWBMLtOpbuksSjNhFmTHVr=zfXIYoCinWBMLtOpbuksSjNhFmTHra['highlightVod']['count']
     zfXIYoCinWBMLtOpbuksSjNhFmTHVx =zfXIYoCinWBMLtOpbuksSjNhFmTHra['vods']['count']
     zfXIYoCinWBMLtOpbuksSjNhFmTHRw='' 
     zfXIYoCinWBMLtOpbuksSjNhFmTHVR=zfXIYoCinWBMLtOpbuksSjNhFmTHVE+zfXIYoCinWBMLtOpbuksSjNhFmTHVr+zfXIYoCinWBMLtOpbuksSjNhFmTHVx
     if zfXIYoCinWBMLtOpbuksSjNhFmTHVR==0:
      if zfXIYoCinWBMLtOpbuksSjNhFmTHRc=='2':
       zfXIYoCinWBMLtOpbuksSjNhFmTHxa='----- %s -----'%(zfXIYoCinWBMLtOpbuksSjNhFmTHRQ)
       zfXIYoCinWBMLtOpbuksSjNhFmTHRa=''
      else:
       zfXIYoCinWBMLtOpbuksSjNhFmTHxa+=' - 관련영상 없음'
       zfXIYoCinWBMLtOpbuksSjNhFmTHRK+='\n\n ** 관련영상 없음 **'
     else:
      if zfXIYoCinWBMLtOpbuksSjNhFmTHVE!=0:
       zfXIYoCinWBMLtOpbuksSjNhFmTHRw =zfXIYoCinWBMLtOpbuksSjNhFmTHra['replayVod']['list'][0]['imgUrl']
      elif zfXIYoCinWBMLtOpbuksSjNhFmTHVr!=0:
       zfXIYoCinWBMLtOpbuksSjNhFmTHRw =zfXIYoCinWBMLtOpbuksSjNhFmTHra['highlightVod']['list'][0]['imgUrl']
      else:
       zfXIYoCinWBMLtOpbuksSjNhFmTHRw =zfXIYoCinWBMLtOpbuksSjNhFmTHra['vods']['list'][0]['imgUrl']
     zfXIYoCinWBMLtOpbuksSjNhFmTHrP={'gameTitle':zfXIYoCinWBMLtOpbuksSjNhFmTHxa,'gameId':zfXIYoCinWBMLtOpbuksSjNhFmTHRP,'beginDate':zfXIYoCinWBMLtOpbuksSjNhFmTHRa[:11],'thumbnail':zfXIYoCinWBMLtOpbuksSjNhFmTHRw,'info_plot':zfXIYoCinWBMLtOpbuksSjNhFmTHRK,'leaguenm':zfXIYoCinWBMLtOpbuksSjNhFmTHRq,'seasonnm':zfXIYoCinWBMLtOpbuksSjNhFmTHRQ,'roundnm':zfXIYoCinWBMLtOpbuksSjNhFmTHRg,'totVodCnt':zfXIYoCinWBMLtOpbuksSjNhFmTHVR}
     zfXIYoCinWBMLtOpbuksSjNhFmTHrA.append(zfXIYoCinWBMLtOpbuksSjNhFmTHrP)
  except zfXIYoCinWBMLtOpbuksSjNhFmTHVg as exception:
   zfXIYoCinWBMLtOpbuksSjNhFmTHVA(exception)
  if zfXIYoCinWBMLtOpbuksSjNhFmTHry['count']>page_int*zfXIYoCinWBMLtOpbuksSjNhFmTHER.GAMELIST_LIMIT:zfXIYoCinWBMLtOpbuksSjNhFmTHRG=zfXIYoCinWBMLtOpbuksSjNhFmTHVq
  return zfXIYoCinWBMLtOpbuksSjNhFmTHrA,zfXIYoCinWBMLtOpbuksSjNhFmTHRG
 def GetGameVodList(zfXIYoCinWBMLtOpbuksSjNhFmTHER,zfXIYoCinWBMLtOpbuksSjNhFmTHRP,vodCount=1000):
  zfXIYoCinWBMLtOpbuksSjNhFmTHrA=[]
  zfXIYoCinWBMLtOpbuksSjNhFmTHVw=''
  try:
   zfXIYoCinWBMLtOpbuksSjNhFmTHEU=zfXIYoCinWBMLtOpbuksSjNhFmTHER.API_DOMAIN+'/api/v3/vod/game'
   zfXIYoCinWBMLtOpbuksSjNhFmTHRl={'gameId':zfXIYoCinWBMLtOpbuksSjNhFmTHRP,'pageItem':zfXIYoCinWBMLtOpbuksSjNhFmTHVa(vodCount)}
   zfXIYoCinWBMLtOpbuksSjNhFmTHEv=zfXIYoCinWBMLtOpbuksSjNhFmTHER.callRequestCookies('Get',zfXIYoCinWBMLtOpbuksSjNhFmTHEU,payload=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,params=zfXIYoCinWBMLtOpbuksSjNhFmTHRl,headers=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,cookies=zfXIYoCinWBMLtOpbuksSjNhFmTHVc)
   zfXIYoCinWBMLtOpbuksSjNhFmTHry=json.loads(zfXIYoCinWBMLtOpbuksSjNhFmTHEv.text)
   zfXIYoCinWBMLtOpbuksSjNhFmTHRy=zfXIYoCinWBMLtOpbuksSjNhFmTHry['list']
   for zfXIYoCinWBMLtOpbuksSjNhFmTHra in zfXIYoCinWBMLtOpbuksSjNhFmTHRy:
    zfXIYoCinWBMLtOpbuksSjNhFmTHRr =zfXIYoCinWBMLtOpbuksSjNhFmTHra['title']
    zfXIYoCinWBMLtOpbuksSjNhFmTHRx =zfXIYoCinWBMLtOpbuksSjNhFmTHra['id']
    zfXIYoCinWBMLtOpbuksSjNhFmTHRV =zfXIYoCinWBMLtOpbuksSjNhFmTHra['vtype']
    zfXIYoCinWBMLtOpbuksSjNhFmTHRw =zfXIYoCinWBMLtOpbuksSjNhFmTHra['imgUrl']
    zfXIYoCinWBMLtOpbuksSjNhFmTHRe =zfXIYoCinWBMLtOpbuksSjNhFmTHra['vtypeId']
    zfXIYoCinWBMLtOpbuksSjNhFmTHVe =zfXIYoCinWBMLtOpbuksSjNhFmTHra['isFree']
    zfXIYoCinWBMLtOpbuksSjNhFmTHrP={'vodTitle':zfXIYoCinWBMLtOpbuksSjNhFmTHRr,'vodId':zfXIYoCinWBMLtOpbuksSjNhFmTHRx,'vodType':zfXIYoCinWBMLtOpbuksSjNhFmTHRV,'thumbnail':zfXIYoCinWBMLtOpbuksSjNhFmTHRw,'vtypeId':zfXIYoCinWBMLtOpbuksSjNhFmTHVa(zfXIYoCinWBMLtOpbuksSjNhFmTHRe),'duration':zfXIYoCinWBMLtOpbuksSjNhFmTHVQ(zfXIYoCinWBMLtOpbuksSjNhFmTHra['duration']/1000),'isFree':zfXIYoCinWBMLtOpbuksSjNhFmTHVe}
    zfXIYoCinWBMLtOpbuksSjNhFmTHrA.append(zfXIYoCinWBMLtOpbuksSjNhFmTHrP)
  except zfXIYoCinWBMLtOpbuksSjNhFmTHVg as exception:
   zfXIYoCinWBMLtOpbuksSjNhFmTHVA(exception)
  return zfXIYoCinWBMLtOpbuksSjNhFmTHrA
 def GetReplay_UrlId(zfXIYoCinWBMLtOpbuksSjNhFmTHER,zfXIYoCinWBMLtOpbuksSjNhFmTHVw,zfXIYoCinWBMLtOpbuksSjNhFmTHRe):
  zfXIYoCinWBMLtOpbuksSjNhFmTHVG=''
  try:
   zfXIYoCinWBMLtOpbuksSjNhFmTHEU=zfXIYoCinWBMLtOpbuksSjNhFmTHER.API_DOMAIN+'/api/v3/vod/'+zfXIYoCinWBMLtOpbuksSjNhFmTHVw
   zfXIYoCinWBMLtOpbuksSjNhFmTHEv=zfXIYoCinWBMLtOpbuksSjNhFmTHER.callRequestCookies('Get',zfXIYoCinWBMLtOpbuksSjNhFmTHEU,payload=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,params=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,headers=zfXIYoCinWBMLtOpbuksSjNhFmTHVc,cookies=zfXIYoCinWBMLtOpbuksSjNhFmTHVc)
   zfXIYoCinWBMLtOpbuksSjNhFmTHry=json.loads(zfXIYoCinWBMLtOpbuksSjNhFmTHEv.text)
   zfXIYoCinWBMLtOpbuksSjNhFmTHVG=zfXIYoCinWBMLtOpbuksSjNhFmTHry['videoId']
  except zfXIYoCinWBMLtOpbuksSjNhFmTHVg as exception:
   zfXIYoCinWBMLtOpbuksSjNhFmTHVA(exception)
  return zfXIYoCinWBMLtOpbuksSjNhFmTHVG
# Created by pyminifier (https://github.com/liftoff/pyminifier)
