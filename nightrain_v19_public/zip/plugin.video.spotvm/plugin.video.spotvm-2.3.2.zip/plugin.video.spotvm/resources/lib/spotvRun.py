__author__="NightRain"
lzMAVcQxdyaIHjrCYGeUbTiqSDOpFs=object
lzMAVcQxdyaIHjrCYGeUbTiqSDOpFv=None
lzMAVcQxdyaIHjrCYGeUbTiqSDOpFR=False
lzMAVcQxdyaIHjrCYGeUbTiqSDOpFX=True
lzMAVcQxdyaIHjrCYGeUbTiqSDOpFm=getattr
lzMAVcQxdyaIHjrCYGeUbTiqSDOpFB=type
lzMAVcQxdyaIHjrCYGeUbTiqSDOpFk=int
lzMAVcQxdyaIHjrCYGeUbTiqSDOpFN=list
lzMAVcQxdyaIHjrCYGeUbTiqSDOpFt=len
lzMAVcQxdyaIHjrCYGeUbTiqSDOpFo=str
lzMAVcQxdyaIHjrCYGeUbTiqSDOpFK=id
lzMAVcQxdyaIHjrCYGeUbTiqSDOpFu=open
lzMAVcQxdyaIHjrCYGeUbTiqSDOpFL=dict
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
lzMAVcQxdyaIHjrCYGeUbTiqSDOpnf=[{'title':'TV 채널 (유료사용자만 지원)','mode':'LIVE_GROUP','icon':'live.png'},{'title':'Live중계 (경기중에만 재생)','mode':'ELIVE_GROUP','icon':'live.png'},{'title':'-----------------','mode':'XXX'},{'title':'오늘의 추천 VOD','mode':'NOW_GROUP'},{'title':'인기영상 5','mode':'POP_GROUP'},{'title':'-----------------','mode':'XXX'},{'title':'VOD (리그, 경기별)','mode':'VOD_GROUP'},{'title':'Watched (시청목록)','mode':'WATCH','icon':'history.png'},]
lzMAVcQxdyaIHjrCYGeUbTiqSDOpnJ={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
lzMAVcQxdyaIHjrCYGeUbTiqSDOpnP=xbmcvfs.translatePath(os.path.join(__profile__,'spotv_cookies.json'))
from spotvCore import*
class lzMAVcQxdyaIHjrCYGeUbTiqSDOpnh(lzMAVcQxdyaIHjrCYGeUbTiqSDOpFs):
 def __init__(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF,lzMAVcQxdyaIHjrCYGeUbTiqSDOpnw,lzMAVcQxdyaIHjrCYGeUbTiqSDOpnE,lzMAVcQxdyaIHjrCYGeUbTiqSDOpns):
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF._addon_url =lzMAVcQxdyaIHjrCYGeUbTiqSDOpnw
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF._addon_handle=lzMAVcQxdyaIHjrCYGeUbTiqSDOpnE
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.main_params =lzMAVcQxdyaIHjrCYGeUbTiqSDOpns
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.SpotvObj =zfXIYoCinWBMLtOpbuksSjNhFmTHEr() 
 def addon_noti(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF,sting):
  try:
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnR=xbmcgui.Dialog()
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnR.notification(__addonname__,sting)
  except:
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpFv
 def addon_log(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF,string):
  try:
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnX=string.encode('utf-8','ignore')
  except:
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnX='addonException: addon_log'
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpnm=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,lzMAVcQxdyaIHjrCYGeUbTiqSDOpnX),level=lzMAVcQxdyaIHjrCYGeUbTiqSDOpnm)
 def get_keyboard_input(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF,lzMAVcQxdyaIHjrCYGeUbTiqSDOpnK):
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpnB=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFv
  kb=xbmc.Keyboard()
  kb.setHeading(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnK)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnB=kb.getText()
  return lzMAVcQxdyaIHjrCYGeUbTiqSDOpnB
 def get_settings_account(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF):
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpnk =__addon__.getSetting('id')
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpnN =__addon__.getSetting('pw')
  return(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnk,lzMAVcQxdyaIHjrCYGeUbTiqSDOpnN)
 def get_settings_hidescoreyn(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF):
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpnt =__addon__.getSetting('hidescore')
  if lzMAVcQxdyaIHjrCYGeUbTiqSDOpnt=='false':
   return lzMAVcQxdyaIHjrCYGeUbTiqSDOpFR
  else:
   return lzMAVcQxdyaIHjrCYGeUbTiqSDOpFX
 def add_dir(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF,label,sublabel='',img='',infoLabels=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFv,isFolder=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFX,params='',isLink=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFR,ContextMenu=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFv):
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpno='%s?%s'%(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF._addon_url,urllib.parse.urlencode(params))
  if sublabel:lzMAVcQxdyaIHjrCYGeUbTiqSDOpnK='%s < %s >'%(label,sublabel)
  else: lzMAVcQxdyaIHjrCYGeUbTiqSDOpnK=label
  if not img:img='DefaultFolder.png'
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpnu=xbmcgui.ListItem(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnK)
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpnu.setArt({'thumb':img,'icon':img,'poster':img})
  if lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.SpotvObj.KodiVersion>=20:
   if infoLabels:lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.Set_InfoTag(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnu.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:lzMAVcQxdyaIHjrCYGeUbTiqSDOpnu.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnu.setProperty('IsPlayable','true')
  if ContextMenu:lzMAVcQxdyaIHjrCYGeUbTiqSDOpnu.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF._addon_handle,lzMAVcQxdyaIHjrCYGeUbTiqSDOpno,lzMAVcQxdyaIHjrCYGeUbTiqSDOpnu,isFolder)
 def Set_InfoTag(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF,video_InfoTag:xbmc.InfoTagVideo,lzMAVcQxdyaIHjrCYGeUbTiqSDOphs):
  for lzMAVcQxdyaIHjrCYGeUbTiqSDOpnL,value in lzMAVcQxdyaIHjrCYGeUbTiqSDOphs.items():
   if lzMAVcQxdyaIHjrCYGeUbTiqSDOpnJ[lzMAVcQxdyaIHjrCYGeUbTiqSDOpnL]['type']=='string':
    lzMAVcQxdyaIHjrCYGeUbTiqSDOpFm(video_InfoTag,lzMAVcQxdyaIHjrCYGeUbTiqSDOpnJ[lzMAVcQxdyaIHjrCYGeUbTiqSDOpnL]['func'])(value)
   elif lzMAVcQxdyaIHjrCYGeUbTiqSDOpnJ[lzMAVcQxdyaIHjrCYGeUbTiqSDOpnL]['type']=='int':
    if lzMAVcQxdyaIHjrCYGeUbTiqSDOpFB(value)==lzMAVcQxdyaIHjrCYGeUbTiqSDOpFk:
     lzMAVcQxdyaIHjrCYGeUbTiqSDOpng=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFk(value)
    else:
     lzMAVcQxdyaIHjrCYGeUbTiqSDOpng=0
    lzMAVcQxdyaIHjrCYGeUbTiqSDOpFm(video_InfoTag,lzMAVcQxdyaIHjrCYGeUbTiqSDOpnJ[lzMAVcQxdyaIHjrCYGeUbTiqSDOpnL]['func'])(lzMAVcQxdyaIHjrCYGeUbTiqSDOpng)
   elif lzMAVcQxdyaIHjrCYGeUbTiqSDOpnJ[lzMAVcQxdyaIHjrCYGeUbTiqSDOpnL]['type']=='actor':
    if value!=[]:
     lzMAVcQxdyaIHjrCYGeUbTiqSDOpFm(video_InfoTag,lzMAVcQxdyaIHjrCYGeUbTiqSDOpnJ[lzMAVcQxdyaIHjrCYGeUbTiqSDOpnL]['func'])([xbmc.Actor(name)for name in value])
   elif lzMAVcQxdyaIHjrCYGeUbTiqSDOpnJ[lzMAVcQxdyaIHjrCYGeUbTiqSDOpnL]['type']=='list':
    if lzMAVcQxdyaIHjrCYGeUbTiqSDOpFB(value)==lzMAVcQxdyaIHjrCYGeUbTiqSDOpFN:
     lzMAVcQxdyaIHjrCYGeUbTiqSDOpFm(video_InfoTag,lzMAVcQxdyaIHjrCYGeUbTiqSDOpnJ[lzMAVcQxdyaIHjrCYGeUbTiqSDOpnL]['func'])(value)
    else:
     lzMAVcQxdyaIHjrCYGeUbTiqSDOpFm(video_InfoTag,lzMAVcQxdyaIHjrCYGeUbTiqSDOpnJ[lzMAVcQxdyaIHjrCYGeUbTiqSDOpnL]['func'])([value])
 def get_selQuality(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF,etype):
  try:
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnW='selected_quality'
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphn=[1080,720,540]
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphf=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFk(__addon__.getSetting(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnW))
   return lzMAVcQxdyaIHjrCYGeUbTiqSDOphn[lzMAVcQxdyaIHjrCYGeUbTiqSDOphf]
  except:
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpFv
  return 1080 
 def dp_Main_List(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF):
  for lzMAVcQxdyaIHjrCYGeUbTiqSDOphJ in lzMAVcQxdyaIHjrCYGeUbTiqSDOpnf:
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnK=lzMAVcQxdyaIHjrCYGeUbTiqSDOphJ.get('title')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphP=''
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphF={'mode':lzMAVcQxdyaIHjrCYGeUbTiqSDOphJ.get('mode'),'page':'1'}
   if lzMAVcQxdyaIHjrCYGeUbTiqSDOphJ.get('mode')=='XXX':
    lzMAVcQxdyaIHjrCYGeUbTiqSDOphw=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFR
    lzMAVcQxdyaIHjrCYGeUbTiqSDOphE =lzMAVcQxdyaIHjrCYGeUbTiqSDOpFX
   else:
    lzMAVcQxdyaIHjrCYGeUbTiqSDOphw=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFX
    lzMAVcQxdyaIHjrCYGeUbTiqSDOphE =lzMAVcQxdyaIHjrCYGeUbTiqSDOpFR
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphs={'title':lzMAVcQxdyaIHjrCYGeUbTiqSDOpnK,'plot':lzMAVcQxdyaIHjrCYGeUbTiqSDOpnK}
   if lzMAVcQxdyaIHjrCYGeUbTiqSDOphJ.get('mode')=='XXX':lzMAVcQxdyaIHjrCYGeUbTiqSDOphs=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFv
   if 'icon' in lzMAVcQxdyaIHjrCYGeUbTiqSDOphJ:lzMAVcQxdyaIHjrCYGeUbTiqSDOphP=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',lzMAVcQxdyaIHjrCYGeUbTiqSDOphJ.get('icon')) 
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.add_dir(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnK,sublabel='',img=lzMAVcQxdyaIHjrCYGeUbTiqSDOphP,infoLabels=lzMAVcQxdyaIHjrCYGeUbTiqSDOphs,isFolder=lzMAVcQxdyaIHjrCYGeUbTiqSDOphw,params=lzMAVcQxdyaIHjrCYGeUbTiqSDOphF,isLink=lzMAVcQxdyaIHjrCYGeUbTiqSDOphE)
  if lzMAVcQxdyaIHjrCYGeUbTiqSDOpFt(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnf)>0:xbmcplugin.endOfDirectory(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF._addon_handle,cacheToDisc=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFR)
 def dp_MainLeague_List(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF,args):
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.addon_log('dp_MainLeague_List')
  lzMAVcQxdyaIHjrCYGeUbTiqSDOphR=lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.SpotvObj.GetTitleGroupList()
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.addon_log('dp_MainLeague_List cnt : '+lzMAVcQxdyaIHjrCYGeUbTiqSDOpFo(lzMAVcQxdyaIHjrCYGeUbTiqSDOpFt(lzMAVcQxdyaIHjrCYGeUbTiqSDOphR)))
  for lzMAVcQxdyaIHjrCYGeUbTiqSDOphX in lzMAVcQxdyaIHjrCYGeUbTiqSDOphR:
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnK =lzMAVcQxdyaIHjrCYGeUbTiqSDOphX.get('title')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphm =lzMAVcQxdyaIHjrCYGeUbTiqSDOphX.get('logo')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphB =lzMAVcQxdyaIHjrCYGeUbTiqSDOphX.get('reagueId')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphk =lzMAVcQxdyaIHjrCYGeUbTiqSDOphX.get('subGame')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphN={'mediatype':'episode','plot':'%s\n\n%s'%(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnK,lzMAVcQxdyaIHjrCYGeUbTiqSDOphk)}
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphF={'mode':'LEAGUE_GROUP','reagueId':lzMAVcQxdyaIHjrCYGeUbTiqSDOphB}
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.add_dir(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnK,sublabel=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFv,img=lzMAVcQxdyaIHjrCYGeUbTiqSDOphm,infoLabels=lzMAVcQxdyaIHjrCYGeUbTiqSDOphN,isFolder=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFX,params=lzMAVcQxdyaIHjrCYGeUbTiqSDOphF)
  if lzMAVcQxdyaIHjrCYGeUbTiqSDOpFt(lzMAVcQxdyaIHjrCYGeUbTiqSDOphR)>0:xbmcplugin.endOfDirectory(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF._addon_handle,cacheToDisc=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFR)
 def dp_NowVod_GroupList(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF,args):
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpht=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFk(args.get('page'))
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.addon_log('dp_NowVod_GroupList page : '+lzMAVcQxdyaIHjrCYGeUbTiqSDOpFo(lzMAVcQxdyaIHjrCYGeUbTiqSDOpht))
  lzMAVcQxdyaIHjrCYGeUbTiqSDOphR,lzMAVcQxdyaIHjrCYGeUbTiqSDOpho=lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.SpotvObj.Get_NowVod_GroupList(lzMAVcQxdyaIHjrCYGeUbTiqSDOpht)
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.addon_log('dp_NowVod_GroupList cnt : '+lzMAVcQxdyaIHjrCYGeUbTiqSDOpFo(lzMAVcQxdyaIHjrCYGeUbTiqSDOpFt(lzMAVcQxdyaIHjrCYGeUbTiqSDOphR)))
  for lzMAVcQxdyaIHjrCYGeUbTiqSDOphX in lzMAVcQxdyaIHjrCYGeUbTiqSDOphR:
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphK =lzMAVcQxdyaIHjrCYGeUbTiqSDOphX.get('vodTitle')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphu =lzMAVcQxdyaIHjrCYGeUbTiqSDOphX.get('vodId')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphL =lzMAVcQxdyaIHjrCYGeUbTiqSDOphX.get('vodType')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphm=lzMAVcQxdyaIHjrCYGeUbTiqSDOphX.get('thumbnail')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphg =lzMAVcQxdyaIHjrCYGeUbTiqSDOphX.get('vtypeId')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphW =lzMAVcQxdyaIHjrCYGeUbTiqSDOphX.get('duration')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphN={'mediatype':'episode','duration':lzMAVcQxdyaIHjrCYGeUbTiqSDOphW,'plot':lzMAVcQxdyaIHjrCYGeUbTiqSDOphK}
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphF={'mode':'NOW_VOD','mediacode':lzMAVcQxdyaIHjrCYGeUbTiqSDOphu,'mediatype':'vod','vtypeId':lzMAVcQxdyaIHjrCYGeUbTiqSDOphg}
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.add_dir(lzMAVcQxdyaIHjrCYGeUbTiqSDOphK,sublabel=lzMAVcQxdyaIHjrCYGeUbTiqSDOphL,img=lzMAVcQxdyaIHjrCYGeUbTiqSDOphm,infoLabels=lzMAVcQxdyaIHjrCYGeUbTiqSDOphN,isFolder=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFR,params=lzMAVcQxdyaIHjrCYGeUbTiqSDOphF)
  if lzMAVcQxdyaIHjrCYGeUbTiqSDOpho:
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphF['mode'] ='NOW_GROUP' 
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphF['page'] =lzMAVcQxdyaIHjrCYGeUbTiqSDOpFo(lzMAVcQxdyaIHjrCYGeUbTiqSDOpht+1)
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnK='[B]%s >>[/B]'%'다음 페이지'
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpfn=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFo(lzMAVcQxdyaIHjrCYGeUbTiqSDOpht+1)
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphP=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.add_dir(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnK,sublabel=lzMAVcQxdyaIHjrCYGeUbTiqSDOpfn,img=lzMAVcQxdyaIHjrCYGeUbTiqSDOphP,infoLabels=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFv,isFolder=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFX,params=lzMAVcQxdyaIHjrCYGeUbTiqSDOphF)
  xbmcplugin.setContent(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF._addon_handle,cacheToDisc=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFR)
 def dp_PopVod_GroupList(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF,args):
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.addon_log('dp_PopVod_GroupList ')
  lzMAVcQxdyaIHjrCYGeUbTiqSDOphR=lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.SpotvObj.GetPopularGroupList()
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.addon_log('dp_PopVod_GroupList cnt : '+lzMAVcQxdyaIHjrCYGeUbTiqSDOpFo(lzMAVcQxdyaIHjrCYGeUbTiqSDOpFt(lzMAVcQxdyaIHjrCYGeUbTiqSDOphR)))
  for lzMAVcQxdyaIHjrCYGeUbTiqSDOphX in lzMAVcQxdyaIHjrCYGeUbTiqSDOphR:
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphK =lzMAVcQxdyaIHjrCYGeUbTiqSDOphX.get('vodTitle')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphu =lzMAVcQxdyaIHjrCYGeUbTiqSDOphX.get('vodId')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphL =lzMAVcQxdyaIHjrCYGeUbTiqSDOphX.get('vodType')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphm=lzMAVcQxdyaIHjrCYGeUbTiqSDOphX.get('thumbnail')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphg =lzMAVcQxdyaIHjrCYGeUbTiqSDOphX.get('vtypeId')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphW =lzMAVcQxdyaIHjrCYGeUbTiqSDOphX.get('duration')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphN={'mediatype':'episode','duration':lzMAVcQxdyaIHjrCYGeUbTiqSDOphW,'plot':lzMAVcQxdyaIHjrCYGeUbTiqSDOphK}
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphF={'mode':'POP_VOD','mediacode':lzMAVcQxdyaIHjrCYGeUbTiqSDOphu,'mediatype':'vod','vtypeId':lzMAVcQxdyaIHjrCYGeUbTiqSDOphg}
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.add_dir(lzMAVcQxdyaIHjrCYGeUbTiqSDOphK,sublabel=lzMAVcQxdyaIHjrCYGeUbTiqSDOphL,img=lzMAVcQxdyaIHjrCYGeUbTiqSDOphm,infoLabels=lzMAVcQxdyaIHjrCYGeUbTiqSDOphN,isFolder=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFR,params=lzMAVcQxdyaIHjrCYGeUbTiqSDOphF)
  xbmcplugin.setContent(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF._addon_handle,cacheToDisc=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFR)
 def dp_Season_List(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF,args):
  lzMAVcQxdyaIHjrCYGeUbTiqSDOphB=args.get('reagueId')
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.addon_log('Season_List - reagueId : '+lzMAVcQxdyaIHjrCYGeUbTiqSDOphB)
  lzMAVcQxdyaIHjrCYGeUbTiqSDOphR=lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.SpotvObj.GetSeasonList(lzMAVcQxdyaIHjrCYGeUbTiqSDOphB)
  for lzMAVcQxdyaIHjrCYGeUbTiqSDOphX in lzMAVcQxdyaIHjrCYGeUbTiqSDOphR:
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpfJ =lzMAVcQxdyaIHjrCYGeUbTiqSDOphX.get('reagueName')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpfP =lzMAVcQxdyaIHjrCYGeUbTiqSDOphX.get('gameTypeId')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpfF =lzMAVcQxdyaIHjrCYGeUbTiqSDOphX.get('seasonName')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpfw =lzMAVcQxdyaIHjrCYGeUbTiqSDOphX.get('seasonId')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphN={'mediatype':'episode','plot':'%s - %s'%(lzMAVcQxdyaIHjrCYGeUbTiqSDOpfJ,lzMAVcQxdyaIHjrCYGeUbTiqSDOpfF)}
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphF={'mode':'SEASON_GROUP','reagueId':lzMAVcQxdyaIHjrCYGeUbTiqSDOphB,'seasonId':lzMAVcQxdyaIHjrCYGeUbTiqSDOpfw,'gameTypeId':lzMAVcQxdyaIHjrCYGeUbTiqSDOpfP,'page':'1'}
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.add_dir(lzMAVcQxdyaIHjrCYGeUbTiqSDOpfJ,sublabel=lzMAVcQxdyaIHjrCYGeUbTiqSDOpfF,img='',infoLabels=lzMAVcQxdyaIHjrCYGeUbTiqSDOphN,isFolder=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFX,params=lzMAVcQxdyaIHjrCYGeUbTiqSDOphF)
  if lzMAVcQxdyaIHjrCYGeUbTiqSDOpFt(lzMAVcQxdyaIHjrCYGeUbTiqSDOphR)>0:xbmcplugin.endOfDirectory(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF._addon_handle,cacheToDisc=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFR)
 def dp_Game_List(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF,args):
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpfP=args.get('gameTypeId')
  lzMAVcQxdyaIHjrCYGeUbTiqSDOphB =args.get('reagueId')
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpfw =args.get('seasonId')
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpht =lzMAVcQxdyaIHjrCYGeUbTiqSDOpFk(args.get('page'))
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.addon_log('Game_List - gameTypeId : '+lzMAVcQxdyaIHjrCYGeUbTiqSDOpfP)
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.addon_log('Game_List - reagueId   : '+lzMAVcQxdyaIHjrCYGeUbTiqSDOphB)
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.addon_log('Game_List - seasonId   : '+lzMAVcQxdyaIHjrCYGeUbTiqSDOpfw)
  lzMAVcQxdyaIHjrCYGeUbTiqSDOphR,lzMAVcQxdyaIHjrCYGeUbTiqSDOpho=lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.SpotvObj.GetGameList(lzMAVcQxdyaIHjrCYGeUbTiqSDOpfP,lzMAVcQxdyaIHjrCYGeUbTiqSDOphB,lzMAVcQxdyaIHjrCYGeUbTiqSDOpfw,lzMAVcQxdyaIHjrCYGeUbTiqSDOpht,hidescore=lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.get_settings_hidescoreyn())
  for lzMAVcQxdyaIHjrCYGeUbTiqSDOphX in lzMAVcQxdyaIHjrCYGeUbTiqSDOphR:
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpfE =lzMAVcQxdyaIHjrCYGeUbTiqSDOphX.get('gameTitle')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpfs =lzMAVcQxdyaIHjrCYGeUbTiqSDOphX.get('beginDate')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphm =lzMAVcQxdyaIHjrCYGeUbTiqSDOphX.get('thumbnail')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpfv =lzMAVcQxdyaIHjrCYGeUbTiqSDOphX.get('gameId')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpfR =lzMAVcQxdyaIHjrCYGeUbTiqSDOphX.get('totVodCnt')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpfX =lzMAVcQxdyaIHjrCYGeUbTiqSDOphX.get('leaguenm')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpfm =lzMAVcQxdyaIHjrCYGeUbTiqSDOphX.get('seasonnm')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpfB =lzMAVcQxdyaIHjrCYGeUbTiqSDOphX.get('roundnm')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpfk =lzMAVcQxdyaIHjrCYGeUbTiqSDOphX.get('info_plot')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpfN ='%s < %s >'%(lzMAVcQxdyaIHjrCYGeUbTiqSDOpfE,lzMAVcQxdyaIHjrCYGeUbTiqSDOpfs)
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphN={'mediatype':'video','plot':lzMAVcQxdyaIHjrCYGeUbTiqSDOpfk}
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphF={'mode':'GAME_VOD_GROUP' if lzMAVcQxdyaIHjrCYGeUbTiqSDOpfR!=0 else 'XXX','saveTitle':lzMAVcQxdyaIHjrCYGeUbTiqSDOpfN,'saveImg':lzMAVcQxdyaIHjrCYGeUbTiqSDOphm,'saveInfo':lzMAVcQxdyaIHjrCYGeUbTiqSDOphN['plot'],'gameid':lzMAVcQxdyaIHjrCYGeUbTiqSDOpfv,'totVodCnt':lzMAVcQxdyaIHjrCYGeUbTiqSDOpfR,}
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.add_dir(lzMAVcQxdyaIHjrCYGeUbTiqSDOpfE,sublabel=lzMAVcQxdyaIHjrCYGeUbTiqSDOpfs,img=lzMAVcQxdyaIHjrCYGeUbTiqSDOphm,infoLabels=lzMAVcQxdyaIHjrCYGeUbTiqSDOphN,isFolder=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFX,params=lzMAVcQxdyaIHjrCYGeUbTiqSDOphF)
  if lzMAVcQxdyaIHjrCYGeUbTiqSDOpho:
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphF['mode'] ='SEASON_GROUP' 
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphF['reagueId'] =lzMAVcQxdyaIHjrCYGeUbTiqSDOphB
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphF['seasonId'] =lzMAVcQxdyaIHjrCYGeUbTiqSDOpfw
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphF['gameTypeId']=lzMAVcQxdyaIHjrCYGeUbTiqSDOpfP
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphF['page'] =lzMAVcQxdyaIHjrCYGeUbTiqSDOpFo(lzMAVcQxdyaIHjrCYGeUbTiqSDOpht+1)
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnK='[B]%s >>[/B]'%'다음 페이지'
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpfn=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFo(lzMAVcQxdyaIHjrCYGeUbTiqSDOpht+1)
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphP=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.add_dir(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnK,sublabel=lzMAVcQxdyaIHjrCYGeUbTiqSDOpfn,img=lzMAVcQxdyaIHjrCYGeUbTiqSDOphP,infoLabels=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFv,isFolder=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFX,params=lzMAVcQxdyaIHjrCYGeUbTiqSDOphF)
  if lzMAVcQxdyaIHjrCYGeUbTiqSDOpFt(lzMAVcQxdyaIHjrCYGeUbTiqSDOphR)>0:xbmcplugin.endOfDirectory(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF._addon_handle,cacheToDisc=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFR)
 def dp_GameVod_List(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF,args):
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpft =args.get('gameid')
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpfN=args.get('saveTitle')
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpfo =args.get('saveImg')
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpfK =args.get('saveInfo')
  lzMAVcQxdyaIHjrCYGeUbTiqSDOphR=lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.SpotvObj.GetGameVodList(lzMAVcQxdyaIHjrCYGeUbTiqSDOpft)
  for lzMAVcQxdyaIHjrCYGeUbTiqSDOphX in lzMAVcQxdyaIHjrCYGeUbTiqSDOphR:
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphK =lzMAVcQxdyaIHjrCYGeUbTiqSDOphX.get('vodTitle')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphu =lzMAVcQxdyaIHjrCYGeUbTiqSDOphX.get('vodId')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphL =lzMAVcQxdyaIHjrCYGeUbTiqSDOphX.get('vodType')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphm=lzMAVcQxdyaIHjrCYGeUbTiqSDOphX.get('thumbnail')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphg =lzMAVcQxdyaIHjrCYGeUbTiqSDOphX.get('vtypeId')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphW =lzMAVcQxdyaIHjrCYGeUbTiqSDOphX.get('duration')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphN={'mediatype':'episode','duration':lzMAVcQxdyaIHjrCYGeUbTiqSDOphW,'plot':'%s \n\n %s'%(lzMAVcQxdyaIHjrCYGeUbTiqSDOphK,lzMAVcQxdyaIHjrCYGeUbTiqSDOpfK)}
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphF={'mode':'GAME_VOD','saveTitle':lzMAVcQxdyaIHjrCYGeUbTiqSDOpfN,'saveImg':lzMAVcQxdyaIHjrCYGeUbTiqSDOpfo,'saveId':lzMAVcQxdyaIHjrCYGeUbTiqSDOpft,'saveInfo':lzMAVcQxdyaIHjrCYGeUbTiqSDOpfK,'mediacode':lzMAVcQxdyaIHjrCYGeUbTiqSDOphu,'mediatype':'vod','vtypeId':lzMAVcQxdyaIHjrCYGeUbTiqSDOphg}
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.add_dir(lzMAVcQxdyaIHjrCYGeUbTiqSDOphK,sublabel=lzMAVcQxdyaIHjrCYGeUbTiqSDOphL,img=lzMAVcQxdyaIHjrCYGeUbTiqSDOphm,infoLabels=lzMAVcQxdyaIHjrCYGeUbTiqSDOphN,isFolder=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFR,params=lzMAVcQxdyaIHjrCYGeUbTiqSDOphF)
  xbmcplugin.setContent(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF._addon_handle,cacheToDisc=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFR)
 def login_main(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF):
  (lzMAVcQxdyaIHjrCYGeUbTiqSDOpfu,lzMAVcQxdyaIHjrCYGeUbTiqSDOpfL)=lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.get_settings_account()
  if not(lzMAVcQxdyaIHjrCYGeUbTiqSDOpfu and lzMAVcQxdyaIHjrCYGeUbTiqSDOpfL):
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnR=xbmcgui.Dialog()
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpfg=lzMAVcQxdyaIHjrCYGeUbTiqSDOpnR.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if lzMAVcQxdyaIHjrCYGeUbTiqSDOpfg==lzMAVcQxdyaIHjrCYGeUbTiqSDOpFX:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.cookiefile_check():return
  if xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINWAIT')=='TRUE':
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpfW=0
   while lzMAVcQxdyaIHjrCYGeUbTiqSDOpFX:
    lzMAVcQxdyaIHjrCYGeUbTiqSDOpfW+=1
    time.sleep(0.05)
    if lzMAVcQxdyaIHjrCYGeUbTiqSDOpfW>600:return
  else:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','TRUE')
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpJn=lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.SpotvObj.GetCredential_new(lzMAVcQxdyaIHjrCYGeUbTiqSDOpfu,lzMAVcQxdyaIHjrCYGeUbTiqSDOpfL)
  if lzMAVcQxdyaIHjrCYGeUbTiqSDOpJn:lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.cookiefile_save()
  xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
  if lzMAVcQxdyaIHjrCYGeUbTiqSDOpJn==lzMAVcQxdyaIHjrCYGeUbTiqSDOpFR:
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_LiveChannel_List(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF,args):
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpJh=lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.SpotvObj.GetLiveChannelList()
  for lzMAVcQxdyaIHjrCYGeUbTiqSDOpJf in lzMAVcQxdyaIHjrCYGeUbTiqSDOpJh:
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpFK =lzMAVcQxdyaIHjrCYGeUbTiqSDOpJf.get('id')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnK =lzMAVcQxdyaIHjrCYGeUbTiqSDOpJf.get('name')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphv =lzMAVcQxdyaIHjrCYGeUbTiqSDOpJf.get('programName')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphm =lzMAVcQxdyaIHjrCYGeUbTiqSDOpJf.get('logo')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpJP=lzMAVcQxdyaIHjrCYGeUbTiqSDOpJf.get('channelepg')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpJF =lzMAVcQxdyaIHjrCYGeUbTiqSDOpJf.get('free')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphN={'plot':'%s\n\n%s'%(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnK,lzMAVcQxdyaIHjrCYGeUbTiqSDOpJP),'mediatype':'episode',}
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphF={'mode':'LIVE','mediacode':lzMAVcQxdyaIHjrCYGeUbTiqSDOpFK,'free':lzMAVcQxdyaIHjrCYGeUbTiqSDOpJF,'mediatype':'live'}
   if lzMAVcQxdyaIHjrCYGeUbTiqSDOpJF:lzMAVcQxdyaIHjrCYGeUbTiqSDOpnK+=' [free]'
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.add_dir(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnK,sublabel=lzMAVcQxdyaIHjrCYGeUbTiqSDOphv,img=lzMAVcQxdyaIHjrCYGeUbTiqSDOphm,infoLabels=lzMAVcQxdyaIHjrCYGeUbTiqSDOphN,isFolder=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFR,params=lzMAVcQxdyaIHjrCYGeUbTiqSDOphF)
  xbmcplugin.setContent(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF._addon_handle,'episodes')
  if lzMAVcQxdyaIHjrCYGeUbTiqSDOpFt(lzMAVcQxdyaIHjrCYGeUbTiqSDOpJh)>0:xbmcplugin.endOfDirectory(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF._addon_handle,cacheToDisc=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFR)
 def dp_EventLiveChannel_List(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF,args):
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpJh,lzMAVcQxdyaIHjrCYGeUbTiqSDOpJw=lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.SpotvObj.GetEventLiveList()
  if lzMAVcQxdyaIHjrCYGeUbTiqSDOpJw!=401 and lzMAVcQxdyaIHjrCYGeUbTiqSDOpFt(lzMAVcQxdyaIHjrCYGeUbTiqSDOpJh)==0:
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.addon_noti(__language__(30907).encode('utf8'))
  for lzMAVcQxdyaIHjrCYGeUbTiqSDOpJf in lzMAVcQxdyaIHjrCYGeUbTiqSDOpJh:
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnK =lzMAVcQxdyaIHjrCYGeUbTiqSDOpJf.get('title')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphv =lzMAVcQxdyaIHjrCYGeUbTiqSDOpJf.get('startTime')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphm =lzMAVcQxdyaIHjrCYGeUbTiqSDOpJf.get('logo')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpJF =lzMAVcQxdyaIHjrCYGeUbTiqSDOpJf.get('free')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphN={'mediatype':'episode','plot':'%s\n\n%s'%(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnK,lzMAVcQxdyaIHjrCYGeUbTiqSDOphv)}
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphF={'mode':'ELIVE','mediacode':lzMAVcQxdyaIHjrCYGeUbTiqSDOpJf.get('liveId'),'free':lzMAVcQxdyaIHjrCYGeUbTiqSDOpJF,'mediatype':'live'}
   if lzMAVcQxdyaIHjrCYGeUbTiqSDOpJF:lzMAVcQxdyaIHjrCYGeUbTiqSDOpnK+=' [free]'
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.add_dir(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnK,sublabel=lzMAVcQxdyaIHjrCYGeUbTiqSDOphv,img=lzMAVcQxdyaIHjrCYGeUbTiqSDOphm,infoLabels=lzMAVcQxdyaIHjrCYGeUbTiqSDOphN,isFolder=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFR,params=lzMAVcQxdyaIHjrCYGeUbTiqSDOphF)
  xbmcplugin.setContent(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF._addon_handle,'episodes')
  if lzMAVcQxdyaIHjrCYGeUbTiqSDOpFt(lzMAVcQxdyaIHjrCYGeUbTiqSDOpJh)>0:xbmcplugin.endOfDirectory(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF._addon_handle,cacheToDisc=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFR)
  return lzMAVcQxdyaIHjrCYGeUbTiqSDOpJw
 def make_stream_header(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF,lzMAVcQxdyaIHjrCYGeUbTiqSDOpJR,cookies):
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpJE=''
  if cookies not in[{},lzMAVcQxdyaIHjrCYGeUbTiqSDOpFv,'']:
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpJs=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFt(cookies)
   for lzMAVcQxdyaIHjrCYGeUbTiqSDOpnL,lzMAVcQxdyaIHjrCYGeUbTiqSDOpJv in cookies.items():
    lzMAVcQxdyaIHjrCYGeUbTiqSDOpJE+='{}={}'.format(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnL,lzMAVcQxdyaIHjrCYGeUbTiqSDOpJv)
    lzMAVcQxdyaIHjrCYGeUbTiqSDOpJs+=-1
    if lzMAVcQxdyaIHjrCYGeUbTiqSDOpJs>0:lzMAVcQxdyaIHjrCYGeUbTiqSDOpJE+='; '
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpJR['cookie']=lzMAVcQxdyaIHjrCYGeUbTiqSDOpJE
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpJX=''
  i=0
  for lzMAVcQxdyaIHjrCYGeUbTiqSDOpnL,lzMAVcQxdyaIHjrCYGeUbTiqSDOpJv in lzMAVcQxdyaIHjrCYGeUbTiqSDOpJR.items():
   i=i+1
   if i>1:lzMAVcQxdyaIHjrCYGeUbTiqSDOpJX+='&'
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpJX+='{}={}'.format(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnL,urllib.parse.quote(lzMAVcQxdyaIHjrCYGeUbTiqSDOpJv))
  return lzMAVcQxdyaIHjrCYGeUbTiqSDOpJX
 def play_VIDEO(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF,args):
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpJm =args.get('mode')
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpJB =args.get('mediacode')
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpJk =args.get('mediatype')
  lzMAVcQxdyaIHjrCYGeUbTiqSDOphg =args.get('vtypeId')
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpJN =args.get('hlsUrl')
  if lzMAVcQxdyaIHjrCYGeUbTiqSDOpJm=='LIVE':
   if args.get('free')=='False':
    if lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.SpotvObj.CheckSubEnd()==lzMAVcQxdyaIHjrCYGeUbTiqSDOpFR:
     lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.addon_noti(__language__(30908).encode('utf8'))
     return
  elif lzMAVcQxdyaIHjrCYGeUbTiqSDOpJm=='ELIVE':
   if args.get('free')=='False':
    if lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.SpotvObj.CheckSubEnd()==lzMAVcQxdyaIHjrCYGeUbTiqSDOpFR:
     lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.addon_noti(__language__(30908).encode('utf8'))
     return
  if lzMAVcQxdyaIHjrCYGeUbTiqSDOpJB=='' or lzMAVcQxdyaIHjrCYGeUbTiqSDOpJB==lzMAVcQxdyaIHjrCYGeUbTiqSDOpFv:
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.addon_noti(__language__(30907).encode('utf8'))
   return
  if lzMAVcQxdyaIHjrCYGeUbTiqSDOpJm=='LIVE':
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpJt,lzMAVcQxdyaIHjrCYGeUbTiqSDOpJo=lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.SpotvObj.GetHlsUrl(lzMAVcQxdyaIHjrCYGeUbTiqSDOpJB)
  else:
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.addon_log('mediacode : '+lzMAVcQxdyaIHjrCYGeUbTiqSDOpJB)
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.addon_log('mediatype : '+lzMAVcQxdyaIHjrCYGeUbTiqSDOpJk)
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.addon_log('vtypeId   : '+lzMAVcQxdyaIHjrCYGeUbTiqSDOpFo(lzMAVcQxdyaIHjrCYGeUbTiqSDOphg))
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpJt,lzMAVcQxdyaIHjrCYGeUbTiqSDOpJo=lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.SpotvObj.GetBroadURL(lzMAVcQxdyaIHjrCYGeUbTiqSDOpJB,lzMAVcQxdyaIHjrCYGeUbTiqSDOpJk,lzMAVcQxdyaIHjrCYGeUbTiqSDOphg)
  if lzMAVcQxdyaIHjrCYGeUbTiqSDOpJo=='':
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.addon_noti(__language__(30908).encode('utf8'))
   return
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpJK=lzMAVcQxdyaIHjrCYGeUbTiqSDOpJo
  try:
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.addon_log('mainMode  = '+lzMAVcQxdyaIHjrCYGeUbTiqSDOpJm)
  except:
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpFv
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.addon_log(lzMAVcQxdyaIHjrCYGeUbTiqSDOpJK)
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpJu=xbmcgui.ListItem(path=lzMAVcQxdyaIHjrCYGeUbTiqSDOpJK)
  if lzMAVcQxdyaIHjrCYGeUbTiqSDOpJm in['LIVE','ELIVE']:
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpJL={}
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpJL['content-type']='application/octet-stream' 
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpJL['user-agent'] =lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.SpotvObj.USER_AGENT
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpJg ='https://www.spotvnow.co.kr/drm/widevine/{}/{}'.format(lzMAVcQxdyaIHjrCYGeUbTiqSDOpJt,lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.SpotvObj.ST['cookies']['spotv_sessionid'])
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpJW=lzMAVcQxdyaIHjrCYGeUbTiqSDOpJg+'|'+urllib.parse.urlencode(lzMAVcQxdyaIHjrCYGeUbTiqSDOpJL)+'|R{SSM}|'
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpPn=lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.make_stream_header(lzMAVcQxdyaIHjrCYGeUbTiqSDOpJL,lzMAVcQxdyaIHjrCYGeUbTiqSDOpFv)
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.addon_log(lzMAVcQxdyaIHjrCYGeUbTiqSDOpJg)
   inputstreamhelper.Helper('hls').check_inputstream()
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpJu.setProperty('inputstream','inputstream.adaptive')
   if lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.SpotvObj.KodiVersion<=20:
    lzMAVcQxdyaIHjrCYGeUbTiqSDOpJu.setProperty('inputstream.adaptive.manifest_type','hls')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpJu.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpJu.setProperty('inputstream.adaptive.license_key',lzMAVcQxdyaIHjrCYGeUbTiqSDOpJW)
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpJu.setProperty('inputstream.adaptive.stream_headers',lzMAVcQxdyaIHjrCYGeUbTiqSDOpPn)
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpJu.setProperty('inputstream.adaptive.manifest_headers',lzMAVcQxdyaIHjrCYGeUbTiqSDOpPn)
  xbmcplugin.setResolvedUrl(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF._addon_handle,lzMAVcQxdyaIHjrCYGeUbTiqSDOpFX,lzMAVcQxdyaIHjrCYGeUbTiqSDOpJu)
  try:
   if lzMAVcQxdyaIHjrCYGeUbTiqSDOpJk=='vod' and lzMAVcQxdyaIHjrCYGeUbTiqSDOpJm not in['POP_VOD','NOW_VOD']:
    lzMAVcQxdyaIHjrCYGeUbTiqSDOphF={'code':args.get('saveId'),'img':args.get('saveImg'),'title':args.get('saveTitle'),'info':args.get('saveInfo')}
    lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.Save_Watched_List(lzMAVcQxdyaIHjrCYGeUbTiqSDOpJk,lzMAVcQxdyaIHjrCYGeUbTiqSDOphF)
  except:
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpFv
 def logout(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF):
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpnR=xbmcgui.Dialog()
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpfg=lzMAVcQxdyaIHjrCYGeUbTiqSDOpnR.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if lzMAVcQxdyaIHjrCYGeUbTiqSDOpfg==lzMAVcQxdyaIHjrCYGeUbTiqSDOpFR:sys.exit()
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.SpotvObj.Init_ST_Total()
  if os.path.isfile(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnP):os.remove(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnP)
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF):
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpPh =lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.SpotvObj.Get_Now_Datetime()
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpPf=lzMAVcQxdyaIHjrCYGeUbTiqSDOpPh+datetime.timedelta(days=0)
  (lzMAVcQxdyaIHjrCYGeUbTiqSDOpfu,lzMAVcQxdyaIHjrCYGeUbTiqSDOpfL)=lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.get_settings_account()
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.SpotvObj.Save_session_acount(lzMAVcQxdyaIHjrCYGeUbTiqSDOpfu,lzMAVcQxdyaIHjrCYGeUbTiqSDOpfL)
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.SpotvObj.ST['account']['token_limit']=lzMAVcQxdyaIHjrCYGeUbTiqSDOpPf.strftime('%Y%m%d')
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.SpotvObj.JsonFile_Save(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnP,lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.SpotvObj.ST)
 def cookiefile_check(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF):
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.SpotvObj.ST=lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.SpotvObj.JsonFile_Load(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnP)
  if 'account' not in lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.SpotvObj.ST:
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.SpotvObj.Init_ST_Total()
   return lzMAVcQxdyaIHjrCYGeUbTiqSDOpFR
  (lzMAVcQxdyaIHjrCYGeUbTiqSDOpPJ,lzMAVcQxdyaIHjrCYGeUbTiqSDOpPF)=lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.get_settings_account()
  (lzMAVcQxdyaIHjrCYGeUbTiqSDOpPw,lzMAVcQxdyaIHjrCYGeUbTiqSDOpPE)=lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.SpotvObj.Load_session_acount()
  if lzMAVcQxdyaIHjrCYGeUbTiqSDOpPJ!=lzMAVcQxdyaIHjrCYGeUbTiqSDOpPw or lzMAVcQxdyaIHjrCYGeUbTiqSDOpPF!=lzMAVcQxdyaIHjrCYGeUbTiqSDOpPE:
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.SpotvObj.Init_ST_Total()
   return lzMAVcQxdyaIHjrCYGeUbTiqSDOpFR
  if lzMAVcQxdyaIHjrCYGeUbTiqSDOpFk(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))>lzMAVcQxdyaIHjrCYGeUbTiqSDOpFk(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.SpotvObj.ST['account']['token_limit']):
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.SpotvObj.Init_ST_Total()
   return lzMAVcQxdyaIHjrCYGeUbTiqSDOpFR
  return lzMAVcQxdyaIHjrCYGeUbTiqSDOpFX
 def dp_History_Remove(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF,args):
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpPs=args.get('delType')
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpPv =args.get('sKey')
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpPR =args.get('vType')
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpnR=xbmcgui.Dialog()
  if lzMAVcQxdyaIHjrCYGeUbTiqSDOpPs=='WATCH_ALL':
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpfg=lzMAVcQxdyaIHjrCYGeUbTiqSDOpnR.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif lzMAVcQxdyaIHjrCYGeUbTiqSDOpPs=='WATCH_ONE':
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpfg=lzMAVcQxdyaIHjrCYGeUbTiqSDOpnR.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  if lzMAVcQxdyaIHjrCYGeUbTiqSDOpfg==lzMAVcQxdyaIHjrCYGeUbTiqSDOpFR:sys.exit()
  if lzMAVcQxdyaIHjrCYGeUbTiqSDOpPs=='WATCH_ALL':
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpPX=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%lzMAVcQxdyaIHjrCYGeUbTiqSDOpPR))
   if os.path.isfile(lzMAVcQxdyaIHjrCYGeUbTiqSDOpPX):os.remove(lzMAVcQxdyaIHjrCYGeUbTiqSDOpPX)
  elif lzMAVcQxdyaIHjrCYGeUbTiqSDOpPs=='WATCH_ONE':
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpPX=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%lzMAVcQxdyaIHjrCYGeUbTiqSDOpPR))
   try:
    lzMAVcQxdyaIHjrCYGeUbTiqSDOpPm=lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.Load_List_File(lzMAVcQxdyaIHjrCYGeUbTiqSDOpPR) 
    fp=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFu(lzMAVcQxdyaIHjrCYGeUbTiqSDOpPX,'w',-1,'utf-8')
    for lzMAVcQxdyaIHjrCYGeUbTiqSDOpPB in lzMAVcQxdyaIHjrCYGeUbTiqSDOpPm:
     lzMAVcQxdyaIHjrCYGeUbTiqSDOpPk=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFL(urllib.parse.parse_qsl(lzMAVcQxdyaIHjrCYGeUbTiqSDOpPB))
     lzMAVcQxdyaIHjrCYGeUbTiqSDOpPN=lzMAVcQxdyaIHjrCYGeUbTiqSDOpPk.get('code').strip()
     if lzMAVcQxdyaIHjrCYGeUbTiqSDOpPv!=lzMAVcQxdyaIHjrCYGeUbTiqSDOpPN:
      fp.write(lzMAVcQxdyaIHjrCYGeUbTiqSDOpPB)
    fp.close()
   except:
    lzMAVcQxdyaIHjrCYGeUbTiqSDOpFv
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF,lzMAVcQxdyaIHjrCYGeUbTiqSDOpJk):
  try:
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpPt=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%lzMAVcQxdyaIHjrCYGeUbTiqSDOpJk))
   fp=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFu(lzMAVcQxdyaIHjrCYGeUbTiqSDOpPt,'r',-1,'utf-8')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpPo=fp.readlines()
   fp.close()
  except:
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpPo=[]
  return lzMAVcQxdyaIHjrCYGeUbTiqSDOpPo
 def Save_Watched_List(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF,stype,lzMAVcQxdyaIHjrCYGeUbTiqSDOpns):
  try:
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpPt=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpPm=lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.Load_List_File(stype) 
   fp=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFu(lzMAVcQxdyaIHjrCYGeUbTiqSDOpPt,'w',-1,'utf-8')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpPK=urllib.parse.urlencode(lzMAVcQxdyaIHjrCYGeUbTiqSDOpns)
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpPK=lzMAVcQxdyaIHjrCYGeUbTiqSDOpPK+'\n'
   fp.write(lzMAVcQxdyaIHjrCYGeUbTiqSDOpPK)
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpPu=0
   for lzMAVcQxdyaIHjrCYGeUbTiqSDOpPB in lzMAVcQxdyaIHjrCYGeUbTiqSDOpPm:
    lzMAVcQxdyaIHjrCYGeUbTiqSDOpPk=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFL(urllib.parse.parse_qsl(lzMAVcQxdyaIHjrCYGeUbTiqSDOpPB))
    lzMAVcQxdyaIHjrCYGeUbTiqSDOpPL=lzMAVcQxdyaIHjrCYGeUbTiqSDOpns.get('code')
    lzMAVcQxdyaIHjrCYGeUbTiqSDOpPg=lzMAVcQxdyaIHjrCYGeUbTiqSDOpPk.get('code')
    if lzMAVcQxdyaIHjrCYGeUbTiqSDOpPL!=lzMAVcQxdyaIHjrCYGeUbTiqSDOpPg:
     fp.write(lzMAVcQxdyaIHjrCYGeUbTiqSDOpPB)
     lzMAVcQxdyaIHjrCYGeUbTiqSDOpPu+=1
     if lzMAVcQxdyaIHjrCYGeUbTiqSDOpPu>=50:break
   fp.close()
  except:
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpFv
 def dp_Watch_List(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF,args):
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpJk ='vod'
  if lzMAVcQxdyaIHjrCYGeUbTiqSDOpJk=='vod':
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpPW=lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.Load_List_File(lzMAVcQxdyaIHjrCYGeUbTiqSDOpJk)
   for lzMAVcQxdyaIHjrCYGeUbTiqSDOpFn in lzMAVcQxdyaIHjrCYGeUbTiqSDOpPW:
    lzMAVcQxdyaIHjrCYGeUbTiqSDOpFh=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFL(urllib.parse.parse_qsl(lzMAVcQxdyaIHjrCYGeUbTiqSDOpFn))
    lzMAVcQxdyaIHjrCYGeUbTiqSDOpnK =lzMAVcQxdyaIHjrCYGeUbTiqSDOpFh.get('title')
    lzMAVcQxdyaIHjrCYGeUbTiqSDOphm=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFh.get('img')
    lzMAVcQxdyaIHjrCYGeUbTiqSDOpJB=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFh.get('code')
    lzMAVcQxdyaIHjrCYGeUbTiqSDOpFf =lzMAVcQxdyaIHjrCYGeUbTiqSDOpFh.get('info')
    lzMAVcQxdyaIHjrCYGeUbTiqSDOphN={}
    lzMAVcQxdyaIHjrCYGeUbTiqSDOphN['plot'] =lzMAVcQxdyaIHjrCYGeUbTiqSDOpFf
    lzMAVcQxdyaIHjrCYGeUbTiqSDOphN['mediatype']='tvshow'
    lzMAVcQxdyaIHjrCYGeUbTiqSDOphF={'mode':'GAME_VOD_GROUP','gameid':lzMAVcQxdyaIHjrCYGeUbTiqSDOpJB,'saveTitle':lzMAVcQxdyaIHjrCYGeUbTiqSDOpnK,'saveImg':lzMAVcQxdyaIHjrCYGeUbTiqSDOphm,'saveInfo':lzMAVcQxdyaIHjrCYGeUbTiqSDOpFf,'mediatype':lzMAVcQxdyaIHjrCYGeUbTiqSDOpJk}
    lzMAVcQxdyaIHjrCYGeUbTiqSDOpFJ={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':lzMAVcQxdyaIHjrCYGeUbTiqSDOpJB,'vType':lzMAVcQxdyaIHjrCYGeUbTiqSDOpJk,}
    lzMAVcQxdyaIHjrCYGeUbTiqSDOpFP=urllib.parse.urlencode(lzMAVcQxdyaIHjrCYGeUbTiqSDOpFJ)
    lzMAVcQxdyaIHjrCYGeUbTiqSDOpFw=[('선택된 시청이력 ( %s ) 삭제'%(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnK),'RunPlugin(plugin://plugin.video.spotvm/?%s)'%(lzMAVcQxdyaIHjrCYGeUbTiqSDOpFP))]
    lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.add_dir(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnK,sublabel='',img=lzMAVcQxdyaIHjrCYGeUbTiqSDOphm,infoLabels=lzMAVcQxdyaIHjrCYGeUbTiqSDOphN,isFolder=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFX,params=lzMAVcQxdyaIHjrCYGeUbTiqSDOphF,ContextMenu=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFw)
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphN={'plot':'시청목록을 삭제합니다.'}
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnK='*** 시청목록 삭제 ***'
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphF={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':lzMAVcQxdyaIHjrCYGeUbTiqSDOpJk,}
   lzMAVcQxdyaIHjrCYGeUbTiqSDOphP=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.add_dir(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnK,sublabel='',img=lzMAVcQxdyaIHjrCYGeUbTiqSDOphP,infoLabels=lzMAVcQxdyaIHjrCYGeUbTiqSDOphN,isFolder=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFR,params=lzMAVcQxdyaIHjrCYGeUbTiqSDOphF,isLink=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFX)
   xbmcplugin.endOfDirectory(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF._addon_handle,cacheToDisc=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFR)
 def spotv_main(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF):
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.SpotvObj.KodiVersion=lzMAVcQxdyaIHjrCYGeUbTiqSDOpFk(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpFE=lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.main_params.get('mode',lzMAVcQxdyaIHjrCYGeUbTiqSDOpFv)
  if lzMAVcQxdyaIHjrCYGeUbTiqSDOpFE=='LOGOUT':
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.logout()
   return
  lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.login_main()
  if lzMAVcQxdyaIHjrCYGeUbTiqSDOpFE is lzMAVcQxdyaIHjrCYGeUbTiqSDOpFv:
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.dp_Main_List()
  elif lzMAVcQxdyaIHjrCYGeUbTiqSDOpFE=='LIVE_GROUP':
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.dp_LiveChannel_List(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.main_params)
  elif lzMAVcQxdyaIHjrCYGeUbTiqSDOpFE=='ELIVE_GROUP':
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpJw=lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.dp_EventLiveChannel_List(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.main_params)
   if lzMAVcQxdyaIHjrCYGeUbTiqSDOpJw==401:
    if os.path.isfile(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnP):os.remove(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnP)
    lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.login_main()
    lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.dp_EventLiveChannel_List(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.main_params)
  elif lzMAVcQxdyaIHjrCYGeUbTiqSDOpFE in['LIVE','GAME_VOD','POP_VOD','NOW_VOD','ELIVE']:
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.play_VIDEO(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.main_params)
  elif lzMAVcQxdyaIHjrCYGeUbTiqSDOpFE=='VOD_GROUP':
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.dp_MainLeague_List(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.main_params)
  elif lzMAVcQxdyaIHjrCYGeUbTiqSDOpFE=='NOW_GROUP':
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.dp_NowVod_GroupList(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.main_params)
  elif lzMAVcQxdyaIHjrCYGeUbTiqSDOpFE=='POP_GROUP':
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.dp_PopVod_GroupList(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.main_params)
  elif lzMAVcQxdyaIHjrCYGeUbTiqSDOpFE=='LEAGUE_GROUP':
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.dp_Season_List(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.main_params)
  elif lzMAVcQxdyaIHjrCYGeUbTiqSDOpFE=='SEASON_GROUP':
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.dp_Game_List(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.main_params)
  elif lzMAVcQxdyaIHjrCYGeUbTiqSDOpFE=='GAME_VOD_GROUP':
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.dp_GameVod_List(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.main_params)
  elif lzMAVcQxdyaIHjrCYGeUbTiqSDOpFE=='WATCH':
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.dp_Watch_List(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.main_params)
  elif lzMAVcQxdyaIHjrCYGeUbTiqSDOpFE=='MYVIEW_REMOVE':
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.dp_History_Remove(lzMAVcQxdyaIHjrCYGeUbTiqSDOpnF.main_params)
  else:
   lzMAVcQxdyaIHjrCYGeUbTiqSDOpFv
# Created by pyminifier (https://github.com/liftoff/pyminifier)
