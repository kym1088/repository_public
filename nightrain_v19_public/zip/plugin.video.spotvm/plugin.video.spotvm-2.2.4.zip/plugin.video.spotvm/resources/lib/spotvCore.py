__author__="NightRain"
zvxnsgpDVHOUhGYfdqIkJbTmBLXFty=object
zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw=None
zvxnsgpDVHOUhGYfdqIkJbTmBLXFte=False
zvxnsgpDVHOUhGYfdqIkJbTmBLXFtu=open
zvxnsgpDVHOUhGYfdqIkJbTmBLXFtA=True
zvxnsgpDVHOUhGYfdqIkJbTmBLXFtP=str
zvxnsgpDVHOUhGYfdqIkJbTmBLXFtN=Exception
zvxnsgpDVHOUhGYfdqIkJbTmBLXFtK=print
zvxnsgpDVHOUhGYfdqIkJbTmBLXFtC=int
zvxnsgpDVHOUhGYfdqIkJbTmBLXFtj=len
zvxnsgpDVHOUhGYfdqIkJbTmBLXFtW=range
import urllib
import re
import json
import sys
import time
import requests
import datetime
import base64
zvxnsgpDVHOUhGYfdqIkJbTmBLXFQr={'stream50':1080,'stream40':720,'stream30':540}
class zvxnsgpDVHOUhGYfdqIkJbTmBLXFQE(zvxnsgpDVHOUhGYfdqIkJbTmBLXFty):
 def __init__(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi):
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.SPOTV_PMCODE ='987'
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.SPOTV_PMSIZE =3
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.GAMELIST_LIMIT =10
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.API_DOMAIN ='https://www.spotvnow.co.kr'
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.BC_DOMAIN ='https://players.brightcove.net'
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.PLAYER_DOMAIN ='https://edge.api.brightcove.com'
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.STREAM_DOMAIN ='https://gtm-spotv.brightcovecdn.com'
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.STREAM_M3U8 ='ap-northeast-1/5764318566001/playlist_dvr'
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36'
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.DEFAULT_HEADER ={'user-agent':zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.USER_AGENT}
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.COOKIE_FILE_NAME=''
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.ST ={}
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.Init_ST_Total()
 def Init_ST_Total(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi):
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.ST={'account':{},'cookies':{'spotv_sessionid':'','spotv_session':'','spotv_accountId':'','spotv_policyKey':'','spotv_subend':'',},}
 def callRequestCookies(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi,jobtype,zvxnsgpDVHOUhGYfdqIkJbTmBLXFQW,payload=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,params=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,headers=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,cookies=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,redirects=zvxnsgpDVHOUhGYfdqIkJbTmBLXFte):
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFQt=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.DEFAULT_HEADER
  if headers:zvxnsgpDVHOUhGYfdqIkJbTmBLXFQt.update(headers)
  if jobtype=='Get':
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQo=requests.get(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQW,params=params,headers=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQt,cookies=cookies,allow_redirects=redirects)
  else:
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQo=requests.post(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQW,data=payload,params=params,headers=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQt,cookies=cookies,allow_redirects=redirects)
  return zvxnsgpDVHOUhGYfdqIkJbTmBLXFQo
 def JsonFile_Save(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi,filename,zvxnsgpDVHOUhGYfdqIkJbTmBLXFQl):
  if filename=='':return zvxnsgpDVHOUhGYfdqIkJbTmBLXFte
  try:
   fp=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtu(filename,'w',-1,'utf-8')
   json.dump(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQl,fp,indent=4,ensure_ascii=zvxnsgpDVHOUhGYfdqIkJbTmBLXFte)
   fp.close()
  except:
   return zvxnsgpDVHOUhGYfdqIkJbTmBLXFte
  return zvxnsgpDVHOUhGYfdqIkJbTmBLXFtA
 def JsonFile_Load(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi,filename):
  if filename=='':return{}
  try:
   fp=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtu(filename,'r',-1,'utf-8')
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQM=json.load(fp)
   fp.close()
  except:
   return{}
  return zvxnsgpDVHOUhGYfdqIkJbTmBLXFQM
 def Save_session_acount(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi,zvxnsgpDVHOUhGYfdqIkJbTmBLXFQa,zvxnsgpDVHOUhGYfdqIkJbTmBLXFQc):
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.ST['account']['stid'] =base64.standard_b64encode(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQa.encode()).decode('utf-8')
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.ST['account']['stpw'] =base64.standard_b64encode(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQc.encode()).decode('utf-8')
 def Load_session_acount(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi):
  try:
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQa =base64.standard_b64decode(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.ST['account']['stid']).decode('utf-8')
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQc =base64.standard_b64decode(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.ST['account']['stpw']).decode('utf-8')
  except:
   return '',''
  return zvxnsgpDVHOUhGYfdqIkJbTmBLXFQa,zvxnsgpDVHOUhGYfdqIkJbTmBLXFQc
 def makeDefaultCookies(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi):
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFQS={'SESSION':zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.ST['cookies']['spotv_session']}
  return zvxnsgpDVHOUhGYfdqIkJbTmBLXFQS
 def makeDefaultHeaders(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi):
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFQy={'accept':'application/json;pk={}'.format(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.ST['cookies']['spotv_policyKey'])}
  return zvxnsgpDVHOUhGYfdqIkJbTmBLXFQy
 def xmlText(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi,in_text):
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFQw=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;')
  return zvxnsgpDVHOUhGYfdqIkJbTmBLXFQw
 def GetCredential(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi,user_id,user_pw):
  try:
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQe=base64.standard_b64encode(user_id.encode('UTF-8')).decode('utf-8')
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQu=base64.standard_b64encode(user_pw.encode('UTF-8')).decode('utf-8')
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQA=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.API_DOMAIN+'/api/v2/login'
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQP={'username':zvxnsgpDVHOUhGYfdqIkJbTmBLXFQe,'password':zvxnsgpDVHOUhGYfdqIkJbTmBLXFQu}
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQP=json.dumps(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQP)
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQN=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.callRequestCookies('Post',zvxnsgpDVHOUhGYfdqIkJbTmBLXFQA,payload=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQP,params=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,headers=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,cookies=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw)
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQK=json.loads(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQN.text)
   for zvxnsgpDVHOUhGYfdqIkJbTmBLXFQC in zvxnsgpDVHOUhGYfdqIkJbTmBLXFQN.cookies:
    if zvxnsgpDVHOUhGYfdqIkJbTmBLXFQC.name=='SESSION':
     zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.ST['cookies']['spotv_session']=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQC.value
     break
   if zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.ST['cookies']['spotv_session']=='':
    zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.Init_ST_Total()
    return zvxnsgpDVHOUhGYfdqIkJbTmBLXFte
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.ST['cookies']['spotv_sessionid']=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtP(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQK['userId'])
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQj=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.SPOTV_PMCODE+zvxnsgpDVHOUhGYfdqIkJbTmBLXFtP(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQK['subEndTime'])
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.ST['cookies']['spotv_subend'] =base64.standard_b64encode(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQj.encode()).decode('utf-8')
   if zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.GetPolicyKey()==zvxnsgpDVHOUhGYfdqIkJbTmBLXFte:
    zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.Init_ST_Total()
    return zvxnsgpDVHOUhGYfdqIkJbTmBLXFte
  except zvxnsgpDVHOUhGYfdqIkJbTmBLXFtN as exception:
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFtK(exception)
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.Init_ST_Total()
   return zvxnsgpDVHOUhGYfdqIkJbTmBLXFte
  return zvxnsgpDVHOUhGYfdqIkJbTmBLXFtA
 def GetPolicyKey(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi):
  try:
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQW=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.GetBcPlayerUrl()
   if zvxnsgpDVHOUhGYfdqIkJbTmBLXFQW=='':return zvxnsgpDVHOUhGYfdqIkJbTmBLXFte
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQN=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.callRequestCookies('Get',zvxnsgpDVHOUhGYfdqIkJbTmBLXFQW,payload=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,params=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,headers=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,cookies=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw)
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFEQ=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQN.text
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFEr =re.findall('accountId:\s*\"\d{13}\",\s*policyKey:\s*\".[^(){}]{100,300}\"',zvxnsgpDVHOUhGYfdqIkJbTmBLXFEQ)[0]
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFEr =zvxnsgpDVHOUhGYfdqIkJbTmBLXFEr.replace('accountId','"accountId"')
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFEr =zvxnsgpDVHOUhGYfdqIkJbTmBLXFEr.replace('policyKey','"policyKey"')
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFEr ='{'+zvxnsgpDVHOUhGYfdqIkJbTmBLXFEr+'}'
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFEi=json.loads(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEr)
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.ST['cookies']['spotv_accountId']=zvxnsgpDVHOUhGYfdqIkJbTmBLXFEi['accountId']
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.ST['cookies']['spotv_policyKey']=zvxnsgpDVHOUhGYfdqIkJbTmBLXFEi['policyKey']
  except zvxnsgpDVHOUhGYfdqIkJbTmBLXFtN as exception:
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFtK(exception)
   return zvxnsgpDVHOUhGYfdqIkJbTmBLXFte
  return zvxnsgpDVHOUhGYfdqIkJbTmBLXFtA
 def GetBcPlayerUrl(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi):
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFEt=''
  try:
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQW=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.GetMainJspath()
   if zvxnsgpDVHOUhGYfdqIkJbTmBLXFQW=='':return zvxnsgpDVHOUhGYfdqIkJbTmBLXFEt
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQN=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.callRequestCookies('Get',zvxnsgpDVHOUhGYfdqIkJbTmBLXFQW,payload=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,params=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,headers=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,cookies=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw)
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFEQ=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQN.text
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFEo =r'default:{(.*?)}'
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFEl =re.compile(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEo).findall(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEQ)[0]
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFER=r'bc:"(.*?)"'
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFEM=re.compile(zvxnsgpDVHOUhGYfdqIkJbTmBLXFER).findall(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEl)[0]
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFEa=r'":"(.*?)"'
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFEc=re.compile(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEa).findall(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEl)[0]
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFEt="%s/%s/%s_default/index.min.js"%(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.BC_DOMAIN,zvxnsgpDVHOUhGYfdqIkJbTmBLXFEM,zvxnsgpDVHOUhGYfdqIkJbTmBLXFEc)
  except zvxnsgpDVHOUhGYfdqIkJbTmBLXFtN as exception:
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFtK(exception)
  return zvxnsgpDVHOUhGYfdqIkJbTmBLXFEt
 def GetMainJspath(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi):
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFES=''
  try:
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQW=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.API_DOMAIN
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQN=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.callRequestCookies('Get',zvxnsgpDVHOUhGYfdqIkJbTmBLXFQW,payload=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,params=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,headers=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,cookies=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw)
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFEQ=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQN.text
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFEr =re.findall('https://cdn.spotvnow.co.kr/dist/js/.{20}\.js',zvxnsgpDVHOUhGYfdqIkJbTmBLXFEQ)[0]
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFES=zvxnsgpDVHOUhGYfdqIkJbTmBLXFEr
  except zvxnsgpDVHOUhGYfdqIkJbTmBLXFtN as exception:
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFtK(exception)
  return zvxnsgpDVHOUhGYfdqIkJbTmBLXFES
 def Get_Now_Datetime(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetLiveChannelList(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi):
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFEw=[]
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFEe ={}
  try:
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQW=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.API_DOMAIN+'/api/v2/channel'
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQN=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.callRequestCookies('Get',zvxnsgpDVHOUhGYfdqIkJbTmBLXFQW,payload=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,params=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,headers=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,cookies=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw)
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQK=json.loads(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQN.text)
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFEe=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.GetEPGList()
   for zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu in zvxnsgpDVHOUhGYfdqIkJbTmBLXFQK:
    zvxnsgpDVHOUhGYfdqIkJbTmBLXFEA={'id':zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['id'],'name':zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['name'],'logo':zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['logo'],'free':zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['free'],'programName':zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['programName'],'channelepg':zvxnsgpDVHOUhGYfdqIkJbTmBLXFEe.get(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['id']),}
    zvxnsgpDVHOUhGYfdqIkJbTmBLXFEw.append(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEA)
  except zvxnsgpDVHOUhGYfdqIkJbTmBLXFtN as exception:
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFtK(exception)
  return zvxnsgpDVHOUhGYfdqIkJbTmBLXFEw
 def GetHlsUrl(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi,mediacode):
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFEP=''
  try:
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQW=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.API_DOMAIN+'/api/v2/channel/'+mediacode
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQN=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.callRequestCookies('Get',zvxnsgpDVHOUhGYfdqIkJbTmBLXFQW,payload=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,params=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,headers=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,cookies=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw)
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQK=json.loads(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQN.text)
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFEP=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQK['hlsUrl']
  except zvxnsgpDVHOUhGYfdqIkJbTmBLXFtN as exception:
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFtK(exception)
  return zvxnsgpDVHOUhGYfdqIkJbTmBLXFEP
 def GetEPGList(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi):
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFEN={}
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFEK=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.Get_Now_Datetime()
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFEC=zvxnsgpDVHOUhGYfdqIkJbTmBLXFEK.strftime('%Y%m%d%H%M')
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFEj='%s-%s-%s'%(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEC[0:4],zvxnsgpDVHOUhGYfdqIkJbTmBLXFEC[4:6],zvxnsgpDVHOUhGYfdqIkJbTmBLXFEC[6:8])
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFEW=(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEK+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M')
  try:
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQW=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.API_DOMAIN+'/api/v2/program/'+zvxnsgpDVHOUhGYfdqIkJbTmBLXFEj
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQN=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.callRequestCookies('Get',zvxnsgpDVHOUhGYfdqIkJbTmBLXFQW,payload=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,params=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,headers=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,cookies=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw)
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQK=json.loads(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQN.text)
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFrQ=-1 
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFrE =''
   for zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu in zvxnsgpDVHOUhGYfdqIkJbTmBLXFQK:
    zvxnsgpDVHOUhGYfdqIkJbTmBLXFri=zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['channelId']
    zvxnsgpDVHOUhGYfdqIkJbTmBLXFrt =zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['startTime'].replace('-','').replace(' ','').replace(':','')
    zvxnsgpDVHOUhGYfdqIkJbTmBLXFro =zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['endTime'].replace('-','').replace(' ','').replace(':','')
    if zvxnsgpDVHOUhGYfdqIkJbTmBLXFtC(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEC)>zvxnsgpDVHOUhGYfdqIkJbTmBLXFtC(zvxnsgpDVHOUhGYfdqIkJbTmBLXFro) :continue
    if zvxnsgpDVHOUhGYfdqIkJbTmBLXFtC(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEW)<zvxnsgpDVHOUhGYfdqIkJbTmBLXFtC(zvxnsgpDVHOUhGYfdqIkJbTmBLXFrt):continue
    if zvxnsgpDVHOUhGYfdqIkJbTmBLXFrQ!=zvxnsgpDVHOUhGYfdqIkJbTmBLXFri:
     if zvxnsgpDVHOUhGYfdqIkJbTmBLXFrE!='':zvxnsgpDVHOUhGYfdqIkJbTmBLXFEN[zvxnsgpDVHOUhGYfdqIkJbTmBLXFrQ]=zvxnsgpDVHOUhGYfdqIkJbTmBLXFrE
     zvxnsgpDVHOUhGYfdqIkJbTmBLXFrQ=zvxnsgpDVHOUhGYfdqIkJbTmBLXFri
     zvxnsgpDVHOUhGYfdqIkJbTmBLXFrE =''
    if zvxnsgpDVHOUhGYfdqIkJbTmBLXFrE:zvxnsgpDVHOUhGYfdqIkJbTmBLXFrE+='\n'
    zvxnsgpDVHOUhGYfdqIkJbTmBLXFrE+=zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['title']+'\n'
    zvxnsgpDVHOUhGYfdqIkJbTmBLXFrE+=' [%s ~ %s]'%(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['startTime'][-5:],zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['endTime'][-5:])+'\n'
   if zvxnsgpDVHOUhGYfdqIkJbTmBLXFrE:zvxnsgpDVHOUhGYfdqIkJbTmBLXFEN[zvxnsgpDVHOUhGYfdqIkJbTmBLXFrQ]=zvxnsgpDVHOUhGYfdqIkJbTmBLXFrE
  except zvxnsgpDVHOUhGYfdqIkJbTmBLXFtN as exception:
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFtK(exception)
  return zvxnsgpDVHOUhGYfdqIkJbTmBLXFEN
 def GetEPGList_new(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi):
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFEN={}
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFEK=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.Get_Now_Datetime()
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFEC=zvxnsgpDVHOUhGYfdqIkJbTmBLXFEK.strftime('%Y%m%d%H%M00')
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFEj='%s%s%s'%(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEC[0:4],zvxnsgpDVHOUhGYfdqIkJbTmBLXFEC[4:6],zvxnsgpDVHOUhGYfdqIkJbTmBLXFEC[6:8])
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFEW=(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEK+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M00')
  try:
   for zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu in LIVETV_LIST:
    zvxnsgpDVHOUhGYfdqIkJbTmBLXFrl =zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['videoId']
    if zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['epgtype']=='spotvon':
     zvxnsgpDVHOUhGYfdqIkJbTmBLXFrE=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.Get_EpgInfo_Spotv_spotvon(zvxnsgpDVHOUhGYfdqIkJbTmBLXFrl,zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['epgnm'],zvxnsgpDVHOUhGYfdqIkJbTmBLXFEj)
     zvxnsgpDVHOUhGYfdqIkJbTmBLXFEN[zvxnsgpDVHOUhGYfdqIkJbTmBLXFrl]=zvxnsgpDVHOUhGYfdqIkJbTmBLXFrE
    if zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['epgtype']=='spotvnet':
     zvxnsgpDVHOUhGYfdqIkJbTmBLXFrE=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.Get_EpgInfo_Spotv_spotvnet(zvxnsgpDVHOUhGYfdqIkJbTmBLXFrl,zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['epgnm'],zvxnsgpDVHOUhGYfdqIkJbTmBLXFEj)
     zvxnsgpDVHOUhGYfdqIkJbTmBLXFEN[zvxnsgpDVHOUhGYfdqIkJbTmBLXFrl]=zvxnsgpDVHOUhGYfdqIkJbTmBLXFrE
   for zvxnsgpDVHOUhGYfdqIkJbTmBLXFrR in zvxnsgpDVHOUhGYfdqIkJbTmBLXFEN.keys():
    if zvxnsgpDVHOUhGYfdqIkJbTmBLXFtj(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEN.get(zvxnsgpDVHOUhGYfdqIkJbTmBLXFrR))==0:continue
    zvxnsgpDVHOUhGYfdqIkJbTmBLXFrE =''
    zvxnsgpDVHOUhGYfdqIkJbTmBLXFrM=''
    for zvxnsgpDVHOUhGYfdqIkJbTmBLXFra in zvxnsgpDVHOUhGYfdqIkJbTmBLXFEN.get(zvxnsgpDVHOUhGYfdqIkJbTmBLXFrR):
     zvxnsgpDVHOUhGYfdqIkJbTmBLXFrt =zvxnsgpDVHOUhGYfdqIkJbTmBLXFra['startTime']
     zvxnsgpDVHOUhGYfdqIkJbTmBLXFro =zvxnsgpDVHOUhGYfdqIkJbTmBLXFra['endTime']
     if zvxnsgpDVHOUhGYfdqIkJbTmBLXFtC(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEC)>zvxnsgpDVHOUhGYfdqIkJbTmBLXFtC(zvxnsgpDVHOUhGYfdqIkJbTmBLXFro) :continue
     if zvxnsgpDVHOUhGYfdqIkJbTmBLXFtC(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEW)<zvxnsgpDVHOUhGYfdqIkJbTmBLXFtC(zvxnsgpDVHOUhGYfdqIkJbTmBLXFrt):continue
     if zvxnsgpDVHOUhGYfdqIkJbTmBLXFtC(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEC)>=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtC(zvxnsgpDVHOUhGYfdqIkJbTmBLXFrt)and zvxnsgpDVHOUhGYfdqIkJbTmBLXFtC(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEC)<zvxnsgpDVHOUhGYfdqIkJbTmBLXFtC(zvxnsgpDVHOUhGYfdqIkJbTmBLXFro):zvxnsgpDVHOUhGYfdqIkJbTmBLXFrM=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.xmlText(zvxnsgpDVHOUhGYfdqIkJbTmBLXFra['title'])
     if zvxnsgpDVHOUhGYfdqIkJbTmBLXFrE:zvxnsgpDVHOUhGYfdqIkJbTmBLXFrE+='\n'
     zvxnsgpDVHOUhGYfdqIkJbTmBLXFrE+=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.xmlText(zvxnsgpDVHOUhGYfdqIkJbTmBLXFra['title'])+'\n'
     zvxnsgpDVHOUhGYfdqIkJbTmBLXFrE+=' [%s:%s ~ %s:%s]'%(zvxnsgpDVHOUhGYfdqIkJbTmBLXFra['startTime'][8:10],zvxnsgpDVHOUhGYfdqIkJbTmBLXFra['startTime'][10:12],zvxnsgpDVHOUhGYfdqIkJbTmBLXFra['endTime'][8:10],zvxnsgpDVHOUhGYfdqIkJbTmBLXFra['endTime'][10:12])+'\n'
    zvxnsgpDVHOUhGYfdqIkJbTmBLXFEN[zvxnsgpDVHOUhGYfdqIkJbTmBLXFrR]={'epg':zvxnsgpDVHOUhGYfdqIkJbTmBLXFrE,'title':zvxnsgpDVHOUhGYfdqIkJbTmBLXFrM}
  except zvxnsgpDVHOUhGYfdqIkJbTmBLXFtN as exception:
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFtK(exception)
  return zvxnsgpDVHOUhGYfdqIkJbTmBLXFEN
 def Get_EpgInfo_Spotv_spotvon(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi,zvxnsgpDVHOUhGYfdqIkJbTmBLXFrl,epgnm,now_day):
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFEN =[]
  try:
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQW='https://www.spotvon.co.kr/data/onAir/%s/Daily/D%s.asp'%(epgnm,now_day)
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQN=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.callRequestCookies('Get',zvxnsgpDVHOUhGYfdqIkJbTmBLXFQW,payload=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,params=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,headers=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,cookies=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw)
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFrc=json.loads(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQN.text)
   for zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu in zvxnsgpDVHOUhGYfdqIkJbTmBLXFrc:
    zvxnsgpDVHOUhGYfdqIkJbTmBLXFEA={'title':zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['title'],'startTime':zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['sch_date'].replace('-','')+zvxnsgpDVHOUhGYfdqIkJbTmBLXFtP(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['sch_hour']).zfill(2)+zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['sch_min']+'00'}
    zvxnsgpDVHOUhGYfdqIkJbTmBLXFEN.append(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEA)
   for i in zvxnsgpDVHOUhGYfdqIkJbTmBLXFtW(zvxnsgpDVHOUhGYfdqIkJbTmBLXFtj(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEN)):
    if i>0:zvxnsgpDVHOUhGYfdqIkJbTmBLXFEN[i-1]['endTime']=zvxnsgpDVHOUhGYfdqIkJbTmBLXFEN[i]['startTime']
    if i==zvxnsgpDVHOUhGYfdqIkJbTmBLXFtj(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEN)-1: zvxnsgpDVHOUhGYfdqIkJbTmBLXFEN[i]['endTime']=now_day+'240000'
  except zvxnsgpDVHOUhGYfdqIkJbTmBLXFtN as exception:
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFtK(exception)
   return[]
  return zvxnsgpDVHOUhGYfdqIkJbTmBLXFEN
 def Get_EpgInfo_Spotv_spotvnet(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi,zvxnsgpDVHOUhGYfdqIkJbTmBLXFrl,epgnm,now_day):
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFEN =[]
  try:
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQW='https://www.spotv.net/data/json/schedule/%s/Daily/D%s.json'%(epgnm,now_day)
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQN=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.callRequestCookies('Get',zvxnsgpDVHOUhGYfdqIkJbTmBLXFQW,payload=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,params=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,headers=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,cookies=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw)
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFrc=json.loads(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQN.text)
   for zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu in zvxnsgpDVHOUhGYfdqIkJbTmBLXFrc:
    zvxnsgpDVHOUhGYfdqIkJbTmBLXFEA={'title':zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['title'],'startTime':zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['sch_date'].replace('-','')+zvxnsgpDVHOUhGYfdqIkJbTmBLXFtP(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['sch_hour']).zfill(2)+zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['sch_min']+'00'}
    zvxnsgpDVHOUhGYfdqIkJbTmBLXFEN.append(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEA)
   for i in zvxnsgpDVHOUhGYfdqIkJbTmBLXFtW(zvxnsgpDVHOUhGYfdqIkJbTmBLXFtj(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEN)):
    if i>0:zvxnsgpDVHOUhGYfdqIkJbTmBLXFEN[i-1]['endTime']=zvxnsgpDVHOUhGYfdqIkJbTmBLXFEN[i]['startTime']
    if i==zvxnsgpDVHOUhGYfdqIkJbTmBLXFtj(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEN)-1: zvxnsgpDVHOUhGYfdqIkJbTmBLXFEN[i]['endTime']=now_day+'240000'
  except zvxnsgpDVHOUhGYfdqIkJbTmBLXFtN as exception:
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFtK(exception)
   return[]
  return zvxnsgpDVHOUhGYfdqIkJbTmBLXFEN
 def GetEventLiveList(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi):
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFEw=[]
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFrS =0
  try:
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFry=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.Get_Now_Datetime()
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFrw=zvxnsgpDVHOUhGYfdqIkJbTmBLXFry.strftime('%Y-%m-%d')
  except zvxnsgpDVHOUhGYfdqIkJbTmBLXFtN as exception:
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFtK(exception)
   return zvxnsgpDVHOUhGYfdqIkJbTmBLXFEw,zvxnsgpDVHOUhGYfdqIkJbTmBLXFrS
  try:
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQW=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.API_DOMAIN+'/api/v2/player/lives/'+zvxnsgpDVHOUhGYfdqIkJbTmBLXFrw 
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQS=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.makeDefaultCookies()
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQN=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.callRequestCookies('Get',zvxnsgpDVHOUhGYfdqIkJbTmBLXFQW,payload=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,params=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,headers=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,cookies=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQS)
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFrS=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQN.status_code 
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQK=json.loads(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQN.text)
   for zvxnsgpDVHOUhGYfdqIkJbTmBLXFre in zvxnsgpDVHOUhGYfdqIkJbTmBLXFQK:
    for zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu in zvxnsgpDVHOUhGYfdqIkJbTmBLXFre['liveNowList']:
     if zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['gameDesc']['title']==zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw or zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['gameDesc']['title']=='':
      zvxnsgpDVHOUhGYfdqIkJbTmBLXFru='%s ( %s : %s )'%(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['leagueName'],zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['homeNameShort'],zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['awayNameShort'])
     else:
      zvxnsgpDVHOUhGYfdqIkJbTmBLXFru=zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['gameDesc']['title']
     zvxnsgpDVHOUhGYfdqIkJbTmBLXFEA={'liveId':zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['liveId'],'title':zvxnsgpDVHOUhGYfdqIkJbTmBLXFru,'logo':zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['gameDesc']['leagueLogo'],'free':zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['isFree'],'startTime':zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['startTime']}
     zvxnsgpDVHOUhGYfdqIkJbTmBLXFEw.append(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEA)
  except zvxnsgpDVHOUhGYfdqIkJbTmBLXFtN as exception:
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFtK(exception)
  return zvxnsgpDVHOUhGYfdqIkJbTmBLXFEw,zvxnsgpDVHOUhGYfdqIkJbTmBLXFrS
 def GetEventLive_videoId(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi,liveId):
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFrA=''
  try:
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQW=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.API_DOMAIN+'/api/v2/live/'+liveId
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQN=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.callRequestCookies('Get',zvxnsgpDVHOUhGYfdqIkJbTmBLXFQW,payload=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,params=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,headers=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,cookies=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw)
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQK=json.loads(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQN.text)
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFrP=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQK['videoId']
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFrA=zvxnsgpDVHOUhGYfdqIkJbTmBLXFrP.replace('ref:','')
  except zvxnsgpDVHOUhGYfdqIkJbTmBLXFtN as exception:
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFtK(exception)
  return zvxnsgpDVHOUhGYfdqIkJbTmBLXFrA
 def CheckMainEnd(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi):
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFrN=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.SPOTV_PMCODE+zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.ST['cookies']['spotv_sessionid']
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFrN=base64.standard_b64encode(zvxnsgpDVHOUhGYfdqIkJbTmBLXFrN.encode()).decode('utf-8')
  if zvxnsgpDVHOUhGYfdqIkJbTmBLXFrN=='OTg3MTgzMzM0Ng==' or zvxnsgpDVHOUhGYfdqIkJbTmBLXFrN=='OTg3MTgzMzExNw==':return zvxnsgpDVHOUhGYfdqIkJbTmBLXFtA
  return zvxnsgpDVHOUhGYfdqIkJbTmBLXFte
 def CheckSubEnd(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi):
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFQM=zvxnsgpDVHOUhGYfdqIkJbTmBLXFte
  try:
   if zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.CheckMainEnd():return zvxnsgpDVHOUhGYfdqIkJbTmBLXFtA 
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFrK=base64.standard_b64decode(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.ST['cookies']['spotv_subend']).decode('utf-8')[zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.SPOTV_PMSIZE:]
   if zvxnsgpDVHOUhGYfdqIkJbTmBLXFrK=='0':return zvxnsgpDVHOUhGYfdqIkJbTmBLXFQM
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFrC =zvxnsgpDVHOUhGYfdqIkJbTmBLXFtC(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.Get_Now_Datetime().strftime('%Y%m%d'))
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFrj =zvxnsgpDVHOUhGYfdqIkJbTmBLXFtC(zvxnsgpDVHOUhGYfdqIkJbTmBLXFrK)/1000
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFrW =zvxnsgpDVHOUhGYfdqIkJbTmBLXFtC(datetime.datetime.fromtimestamp(zvxnsgpDVHOUhGYfdqIkJbTmBLXFrj,datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul')).strftime('%Y%m%d'))
   if zvxnsgpDVHOUhGYfdqIkJbTmBLXFrC<=zvxnsgpDVHOUhGYfdqIkJbTmBLXFrW:zvxnsgpDVHOUhGYfdqIkJbTmBLXFQM=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtA
  except zvxnsgpDVHOUhGYfdqIkJbTmBLXFtN as exception:
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFtK(exception)
   return zvxnsgpDVHOUhGYfdqIkJbTmBLXFQM
  return zvxnsgpDVHOUhGYfdqIkJbTmBLXFQM
 def GetBroadURL(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi,zvxnsgpDVHOUhGYfdqIkJbTmBLXFrA,mediatype,zvxnsgpDVHOUhGYfdqIkJbTmBLXFic):
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFiQ=''
  try:
   if mediatype=='live':
    zvxnsgpDVHOUhGYfdqIkJbTmBLXFQW=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.API_DOMAIN+'/api/v2/live/'+zvxnsgpDVHOUhGYfdqIkJbTmBLXFrA
   else:
    zvxnsgpDVHOUhGYfdqIkJbTmBLXFrA=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.GetReplay_UrlId(zvxnsgpDVHOUhGYfdqIkJbTmBLXFrA,zvxnsgpDVHOUhGYfdqIkJbTmBLXFic)
    if zvxnsgpDVHOUhGYfdqIkJbTmBLXFrA=='':return zvxnsgpDVHOUhGYfdqIkJbTmBLXFiQ
    zvxnsgpDVHOUhGYfdqIkJbTmBLXFQW=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.PLAYER_DOMAIN+'/playback/v1/accounts/'+zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.ST['cookies']['spotv_accountId']+'/videos/'+zvxnsgpDVHOUhGYfdqIkJbTmBLXFrA
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQy=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.makeDefaultHeaders()
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQN=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.callRequestCookies('Get',zvxnsgpDVHOUhGYfdqIkJbTmBLXFQW,payload=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,params=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,headers=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQy,cookies=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw)
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFrc=json.loads(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQN.text)
   if mediatype=='live':
    zvxnsgpDVHOUhGYfdqIkJbTmBLXFiQ=zvxnsgpDVHOUhGYfdqIkJbTmBLXFrc['hlsUrl2']or zvxnsgpDVHOUhGYfdqIkJbTmBLXFrc['hlsUrl']
   else:
    zvxnsgpDVHOUhGYfdqIkJbTmBLXFiQ=zvxnsgpDVHOUhGYfdqIkJbTmBLXFrc['sources'][0]['src']
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFiQ=zvxnsgpDVHOUhGYfdqIkJbTmBLXFiQ.replace('http://','https://')
  except zvxnsgpDVHOUhGYfdqIkJbTmBLXFtN as exception:
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFtK(exception)
  return zvxnsgpDVHOUhGYfdqIkJbTmBLXFiQ
 def GetTitleGroupList(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi):
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFEw=[]
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFiE=zvxnsgpDVHOUhGYfdqIkJbTmBLXFte
  try:
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQW=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.API_DOMAIN+'/api/v2/home/web'
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQN=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.callRequestCookies('Get',zvxnsgpDVHOUhGYfdqIkJbTmBLXFQW,payload=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,params=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,headers=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,cookies=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw)
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQK=json.loads(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQN.text)
   for zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu in zvxnsgpDVHOUhGYfdqIkJbTmBLXFQK:
    if zvxnsgpDVHOUhGYfdqIkJbTmBLXFtP(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['type'])=='3':
     zvxnsgpDVHOUhGYfdqIkJbTmBLXFir=''
     for zvxnsgpDVHOUhGYfdqIkJbTmBLXFit in zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['data']['list']:
      zvxnsgpDVHOUhGYfdqIkJbTmBLXFio='[%s] %s vs %s\n<%s>\n\n'%(zvxnsgpDVHOUhGYfdqIkJbTmBLXFit['gameDesc']['roundName'],zvxnsgpDVHOUhGYfdqIkJbTmBLXFit['gameDesc']['homeNameShort'],zvxnsgpDVHOUhGYfdqIkJbTmBLXFit['gameDesc']['awayNameShort'],zvxnsgpDVHOUhGYfdqIkJbTmBLXFit['gameDesc']['beginDate'])
      zvxnsgpDVHOUhGYfdqIkJbTmBLXFir+=zvxnsgpDVHOUhGYfdqIkJbTmBLXFio
     zvxnsgpDVHOUhGYfdqIkJbTmBLXFEA={'title':zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['title'],'logo':zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['logo'],'reagueId':zvxnsgpDVHOUhGYfdqIkJbTmBLXFtP(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['destId']),'subGame':zvxnsgpDVHOUhGYfdqIkJbTmBLXFir}
     zvxnsgpDVHOUhGYfdqIkJbTmBLXFEw.append(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEA)
  except zvxnsgpDVHOUhGYfdqIkJbTmBLXFtN as exception:
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFtK(exception)
  return zvxnsgpDVHOUhGYfdqIkJbTmBLXFEw
 def GetPopularGroupList(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi):
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFEw=[]
  try:
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQW=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.API_DOMAIN+'/api/v2/home/web'
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQN=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.callRequestCookies('Get',zvxnsgpDVHOUhGYfdqIkJbTmBLXFQW,payload=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,params=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,headers=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,cookies=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw)
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQK=json.loads(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQN.text)
   for zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu in zvxnsgpDVHOUhGYfdqIkJbTmBLXFQK:
    if zvxnsgpDVHOUhGYfdqIkJbTmBLXFtP(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['type'])=='1' and zvxnsgpDVHOUhGYfdqIkJbTmBLXFtP(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['destId'])=='4':
     for zvxnsgpDVHOUhGYfdqIkJbTmBLXFit in zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['data']['list']:
      zvxnsgpDVHOUhGYfdqIkJbTmBLXFil =zvxnsgpDVHOUhGYfdqIkJbTmBLXFit['title']
      zvxnsgpDVHOUhGYfdqIkJbTmBLXFiR =zvxnsgpDVHOUhGYfdqIkJbTmBLXFit['id']
      zvxnsgpDVHOUhGYfdqIkJbTmBLXFiM =zvxnsgpDVHOUhGYfdqIkJbTmBLXFit['vtype']
      zvxnsgpDVHOUhGYfdqIkJbTmBLXFia =zvxnsgpDVHOUhGYfdqIkJbTmBLXFit['imgUrl']
      zvxnsgpDVHOUhGYfdqIkJbTmBLXFic =zvxnsgpDVHOUhGYfdqIkJbTmBLXFit['vtypeId']
      zvxnsgpDVHOUhGYfdqIkJbTmBLXFEA={'vodTitle':zvxnsgpDVHOUhGYfdqIkJbTmBLXFil,'vodId':zvxnsgpDVHOUhGYfdqIkJbTmBLXFiR,'vodType':zvxnsgpDVHOUhGYfdqIkJbTmBLXFiM,'thumbnail':zvxnsgpDVHOUhGYfdqIkJbTmBLXFia,'vtypeId':zvxnsgpDVHOUhGYfdqIkJbTmBLXFtP(zvxnsgpDVHOUhGYfdqIkJbTmBLXFic),'duration':zvxnsgpDVHOUhGYfdqIkJbTmBLXFtC(zvxnsgpDVHOUhGYfdqIkJbTmBLXFit['duration']/1000)}
      zvxnsgpDVHOUhGYfdqIkJbTmBLXFEw.append(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEA)
  except zvxnsgpDVHOUhGYfdqIkJbTmBLXFtN as exception:
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFtK(exception)
  return zvxnsgpDVHOUhGYfdqIkJbTmBLXFEw
 def Get_NowVod_GroupList(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi,page_int):
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFEw=[]
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFiS=zvxnsgpDVHOUhGYfdqIkJbTmBLXFte
  try:
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQW=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.API_DOMAIN+'/api/v2/theme/14/list'
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFiy={'pageItem':'10','pageNo':zvxnsgpDVHOUhGYfdqIkJbTmBLXFtP(page_int)}
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQN=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.callRequestCookies('Get',zvxnsgpDVHOUhGYfdqIkJbTmBLXFQW,payload=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,params=zvxnsgpDVHOUhGYfdqIkJbTmBLXFiy,headers=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,cookies=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw)
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQK=json.loads(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQN.text)
   for zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu in zvxnsgpDVHOUhGYfdqIkJbTmBLXFQK['list']:
    zvxnsgpDVHOUhGYfdqIkJbTmBLXFil =zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['title']
    zvxnsgpDVHOUhGYfdqIkJbTmBLXFiR =zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['id']
    zvxnsgpDVHOUhGYfdqIkJbTmBLXFiM =zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['vtype']
    zvxnsgpDVHOUhGYfdqIkJbTmBLXFia =zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['imgUrl']
    zvxnsgpDVHOUhGYfdqIkJbTmBLXFic =zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['vtypeId']
    zvxnsgpDVHOUhGYfdqIkJbTmBLXFEA={'vodTitle':zvxnsgpDVHOUhGYfdqIkJbTmBLXFil,'vodId':zvxnsgpDVHOUhGYfdqIkJbTmBLXFiR,'vodType':zvxnsgpDVHOUhGYfdqIkJbTmBLXFiM,'thumbnail':zvxnsgpDVHOUhGYfdqIkJbTmBLXFia,'vtypeId':zvxnsgpDVHOUhGYfdqIkJbTmBLXFtP(zvxnsgpDVHOUhGYfdqIkJbTmBLXFic),'duration':zvxnsgpDVHOUhGYfdqIkJbTmBLXFtC(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['duration']/1000),}
    zvxnsgpDVHOUhGYfdqIkJbTmBLXFEw.append(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEA)
    if zvxnsgpDVHOUhGYfdqIkJbTmBLXFQK['count']>page_int*zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.GAMELIST_LIMIT:zvxnsgpDVHOUhGYfdqIkJbTmBLXFiS=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtA
  except zvxnsgpDVHOUhGYfdqIkJbTmBLXFtN as exception:
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFtK(exception)
  return zvxnsgpDVHOUhGYfdqIkJbTmBLXFEw,zvxnsgpDVHOUhGYfdqIkJbTmBLXFiS
 def GetSeasonList(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi,leagueId):
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFEw=[]
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFiw=zvxnsgpDVHOUhGYfdqIkJbTmBLXFie=''
  try:
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQW=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.API_DOMAIN+'/api/v2/game/league/'+leagueId
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQN=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.callRequestCookies('Get',zvxnsgpDVHOUhGYfdqIkJbTmBLXFQW,payload=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,params=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,headers=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,cookies=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw)
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQK=json.loads(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQN.text)
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFiw=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQK['name']
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFie=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtP(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQK['gameTypeId'])
  except zvxnsgpDVHOUhGYfdqIkJbTmBLXFtN as exception:
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFtK(exception)
   return zvxnsgpDVHOUhGYfdqIkJbTmBLXFEw
  if zvxnsgpDVHOUhGYfdqIkJbTmBLXFie in['2','5','6','8']:
   try:
    zvxnsgpDVHOUhGYfdqIkJbTmBLXFQW=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.API_DOMAIN+'/api/v2/year/'+leagueId
    zvxnsgpDVHOUhGYfdqIkJbTmBLXFQN=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.callRequestCookies('Get',zvxnsgpDVHOUhGYfdqIkJbTmBLXFQW,payload=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,params=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,headers=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,cookies=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw)
    zvxnsgpDVHOUhGYfdqIkJbTmBLXFQK=json.loads(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQN.text)
    for zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu in zvxnsgpDVHOUhGYfdqIkJbTmBLXFQK:
     zvxnsgpDVHOUhGYfdqIkJbTmBLXFEA={'reagueName':zvxnsgpDVHOUhGYfdqIkJbTmBLXFiw,'gameTypeId':zvxnsgpDVHOUhGYfdqIkJbTmBLXFie,'seasonName':zvxnsgpDVHOUhGYfdqIkJbTmBLXFtP(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu),'seasonId':zvxnsgpDVHOUhGYfdqIkJbTmBLXFtP(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu)}
     zvxnsgpDVHOUhGYfdqIkJbTmBLXFEw.append(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEA)
   except zvxnsgpDVHOUhGYfdqIkJbTmBLXFtN as exception:
    zvxnsgpDVHOUhGYfdqIkJbTmBLXFtK(exception)
    return[]
  else:
   try:
    zvxnsgpDVHOUhGYfdqIkJbTmBLXFQW=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.API_DOMAIN+'/api/v2/season/'+leagueId
    zvxnsgpDVHOUhGYfdqIkJbTmBLXFQN=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.callRequestCookies('Get',zvxnsgpDVHOUhGYfdqIkJbTmBLXFQW,payload=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,params=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,headers=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,cookies=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw)
    zvxnsgpDVHOUhGYfdqIkJbTmBLXFQK=json.loads(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQN.text)
    for zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu in zvxnsgpDVHOUhGYfdqIkJbTmBLXFQK:
     zvxnsgpDVHOUhGYfdqIkJbTmBLXFEA={'reagueName':zvxnsgpDVHOUhGYfdqIkJbTmBLXFiw,'gameTypeId':zvxnsgpDVHOUhGYfdqIkJbTmBLXFie,'seasonName':zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['name'],'seasonId':zvxnsgpDVHOUhGYfdqIkJbTmBLXFtP(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['id'])}
     zvxnsgpDVHOUhGYfdqIkJbTmBLXFEw.append(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEA)
   except zvxnsgpDVHOUhGYfdqIkJbTmBLXFtN as exception:
    zvxnsgpDVHOUhGYfdqIkJbTmBLXFtK(exception)
    return[]
  return zvxnsgpDVHOUhGYfdqIkJbTmBLXFEw
 def GetGameList(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi,zvxnsgpDVHOUhGYfdqIkJbTmBLXFie,leagueId,seasonId,page_int,hidescore=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtA):
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFEw=[]
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFiS=zvxnsgpDVHOUhGYfdqIkJbTmBLXFte
  try:
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQW=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.API_DOMAIN+'/api/v2/vod/league/detail'
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFiy={'gameType':zvxnsgpDVHOUhGYfdqIkJbTmBLXFie,'leagueId':leagueId,'seasonId':seasonId if zvxnsgpDVHOUhGYfdqIkJbTmBLXFie not in['2','5','6','8']else '','teamId':'','roundId':'','year':'' if zvxnsgpDVHOUhGYfdqIkJbTmBLXFie not in['2','5','6','8']else seasonId,'pageNo':zvxnsgpDVHOUhGYfdqIkJbTmBLXFtP(page_int)}
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQN=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.callRequestCookies('Get',zvxnsgpDVHOUhGYfdqIkJbTmBLXFQW,payload=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,params=zvxnsgpDVHOUhGYfdqIkJbTmBLXFiy,headers=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,cookies=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw)
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQK=json.loads(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQN.text)
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFre=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQK['list']
   for zvxnsgpDVHOUhGYfdqIkJbTmBLXFiu in zvxnsgpDVHOUhGYfdqIkJbTmBLXFre:
    for zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu in zvxnsgpDVHOUhGYfdqIkJbTmBLXFiu['list']:
     if zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['gameDesc']['title']==zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw or zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['gameDesc']['title']=='':
      zvxnsgpDVHOUhGYfdqIkJbTmBLXFru ='%s vs %s'%(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['gameDesc']['homeNameShort'],zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['gameDesc']['awayNameShort'])
     else:
      zvxnsgpDVHOUhGYfdqIkJbTmBLXFru =zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['gameDesc']['title']
     zvxnsgpDVHOUhGYfdqIkJbTmBLXFiA =zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['gameDesc']['beginDate']
     zvxnsgpDVHOUhGYfdqIkJbTmBLXFiP =zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['gameDesc']['id']
     zvxnsgpDVHOUhGYfdqIkJbTmBLXFiN =zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['gameDesc']['leagueNameFull']
     zvxnsgpDVHOUhGYfdqIkJbTmBLXFiK =zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['gameDesc']['seasonName']
     zvxnsgpDVHOUhGYfdqIkJbTmBLXFiC =zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['gameDesc']['roundName']
     zvxnsgpDVHOUhGYfdqIkJbTmBLXFij =zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['gameDesc']['homeName']
     zvxnsgpDVHOUhGYfdqIkJbTmBLXFiW =zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['gameDesc']['awayName']
     zvxnsgpDVHOUhGYfdqIkJbTmBLXFtQ =zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['gameDesc']['homeScore']
     zvxnsgpDVHOUhGYfdqIkJbTmBLXFtE =zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['gameDesc']['awayScore']
     if hidescore==zvxnsgpDVHOUhGYfdqIkJbTmBLXFtA:
      zvxnsgpDVHOUhGYfdqIkJbTmBLXFtr ='%s\n - %s (%s)\n - %s\n\nhome : %s\n\naway : %s'%(zvxnsgpDVHOUhGYfdqIkJbTmBLXFiN,zvxnsgpDVHOUhGYfdqIkJbTmBLXFiK,zvxnsgpDVHOUhGYfdqIkJbTmBLXFiC,zvxnsgpDVHOUhGYfdqIkJbTmBLXFiA,zvxnsgpDVHOUhGYfdqIkJbTmBLXFij,zvxnsgpDVHOUhGYfdqIkJbTmBLXFiW)
     else:
      zvxnsgpDVHOUhGYfdqIkJbTmBLXFtr ='%s\n - %s (%s)\n - %s\n\nhome : %s (Score %s)\n\naway : %s (Score %s)'%(zvxnsgpDVHOUhGYfdqIkJbTmBLXFiN,zvxnsgpDVHOUhGYfdqIkJbTmBLXFiK,zvxnsgpDVHOUhGYfdqIkJbTmBLXFiC,zvxnsgpDVHOUhGYfdqIkJbTmBLXFiA,zvxnsgpDVHOUhGYfdqIkJbTmBLXFij,zvxnsgpDVHOUhGYfdqIkJbTmBLXFtQ,zvxnsgpDVHOUhGYfdqIkJbTmBLXFiW,zvxnsgpDVHOUhGYfdqIkJbTmBLXFtE)
     zvxnsgpDVHOUhGYfdqIkJbTmBLXFti=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtr
     zvxnsgpDVHOUhGYfdqIkJbTmBLXFto =zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['replayVod']['count']
     zvxnsgpDVHOUhGYfdqIkJbTmBLXFtl=zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['highlightVod']['count']
     zvxnsgpDVHOUhGYfdqIkJbTmBLXFtR =zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['vods']['count']
     zvxnsgpDVHOUhGYfdqIkJbTmBLXFia='' 
     zvxnsgpDVHOUhGYfdqIkJbTmBLXFtM=zvxnsgpDVHOUhGYfdqIkJbTmBLXFto+zvxnsgpDVHOUhGYfdqIkJbTmBLXFtl+zvxnsgpDVHOUhGYfdqIkJbTmBLXFtR
     if zvxnsgpDVHOUhGYfdqIkJbTmBLXFtM==0:
      if zvxnsgpDVHOUhGYfdqIkJbTmBLXFie=='2':
       zvxnsgpDVHOUhGYfdqIkJbTmBLXFru='----- %s -----'%(zvxnsgpDVHOUhGYfdqIkJbTmBLXFiK)
       zvxnsgpDVHOUhGYfdqIkJbTmBLXFiA=''
      else:
       zvxnsgpDVHOUhGYfdqIkJbTmBLXFru+=' - 관련영상 없음'
       zvxnsgpDVHOUhGYfdqIkJbTmBLXFti+='\n\n ** 관련영상 없음 **'
     else:
      if zvxnsgpDVHOUhGYfdqIkJbTmBLXFto!=0:
       zvxnsgpDVHOUhGYfdqIkJbTmBLXFia =zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['replayVod']['list'][0]['imgUrl']
      elif zvxnsgpDVHOUhGYfdqIkJbTmBLXFtl!=0:
       zvxnsgpDVHOUhGYfdqIkJbTmBLXFia =zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['highlightVod']['list'][0]['imgUrl']
      else:
       zvxnsgpDVHOUhGYfdqIkJbTmBLXFia =zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['vods']['list'][0]['imgUrl']
     zvxnsgpDVHOUhGYfdqIkJbTmBLXFEA={'gameTitle':zvxnsgpDVHOUhGYfdqIkJbTmBLXFru,'gameId':zvxnsgpDVHOUhGYfdqIkJbTmBLXFiP,'beginDate':zvxnsgpDVHOUhGYfdqIkJbTmBLXFiA[:11],'thumbnail':zvxnsgpDVHOUhGYfdqIkJbTmBLXFia,'info_plot':zvxnsgpDVHOUhGYfdqIkJbTmBLXFti,'leaguenm':zvxnsgpDVHOUhGYfdqIkJbTmBLXFiN,'seasonnm':zvxnsgpDVHOUhGYfdqIkJbTmBLXFiK,'roundnm':zvxnsgpDVHOUhGYfdqIkJbTmBLXFiC,'totVodCnt':zvxnsgpDVHOUhGYfdqIkJbTmBLXFtM}
     zvxnsgpDVHOUhGYfdqIkJbTmBLXFEw.append(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEA)
  except zvxnsgpDVHOUhGYfdqIkJbTmBLXFtN as exception:
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFtK(exception)
  if zvxnsgpDVHOUhGYfdqIkJbTmBLXFQK['count']>page_int*zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.GAMELIST_LIMIT:zvxnsgpDVHOUhGYfdqIkJbTmBLXFiS=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtA
  return zvxnsgpDVHOUhGYfdqIkJbTmBLXFEw,zvxnsgpDVHOUhGYfdqIkJbTmBLXFiS
 def GetGameVodList(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi,zvxnsgpDVHOUhGYfdqIkJbTmBLXFiP,vodCount=1000):
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFEw=[]
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFta=''
  try:
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQW=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.API_DOMAIN+'/api/v2/vod/game'
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFiy={'gameId':zvxnsgpDVHOUhGYfdqIkJbTmBLXFiP,'pageItem':zvxnsgpDVHOUhGYfdqIkJbTmBLXFtP(vodCount)}
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQN=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.callRequestCookies('Get',zvxnsgpDVHOUhGYfdqIkJbTmBLXFQW,payload=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,params=zvxnsgpDVHOUhGYfdqIkJbTmBLXFiy,headers=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,cookies=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw)
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQK=json.loads(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQN.text)
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFiu=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQK['list']
   for zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu in zvxnsgpDVHOUhGYfdqIkJbTmBLXFiu:
    zvxnsgpDVHOUhGYfdqIkJbTmBLXFil =zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['title']
    zvxnsgpDVHOUhGYfdqIkJbTmBLXFiR =zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['id']
    zvxnsgpDVHOUhGYfdqIkJbTmBLXFiM =zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['vtype']
    zvxnsgpDVHOUhGYfdqIkJbTmBLXFia =zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['imgUrl']
    zvxnsgpDVHOUhGYfdqIkJbTmBLXFic =zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['vtypeId']
    zvxnsgpDVHOUhGYfdqIkJbTmBLXFtc =zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['isFree']
    zvxnsgpDVHOUhGYfdqIkJbTmBLXFEA={'vodTitle':zvxnsgpDVHOUhGYfdqIkJbTmBLXFil,'vodId':zvxnsgpDVHOUhGYfdqIkJbTmBLXFiR,'vodType':zvxnsgpDVHOUhGYfdqIkJbTmBLXFiM,'thumbnail':zvxnsgpDVHOUhGYfdqIkJbTmBLXFia,'vtypeId':zvxnsgpDVHOUhGYfdqIkJbTmBLXFtP(zvxnsgpDVHOUhGYfdqIkJbTmBLXFic),'duration':zvxnsgpDVHOUhGYfdqIkJbTmBLXFtC(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEu['duration']/1000),'isFree':zvxnsgpDVHOUhGYfdqIkJbTmBLXFtc}
    zvxnsgpDVHOUhGYfdqIkJbTmBLXFEw.append(zvxnsgpDVHOUhGYfdqIkJbTmBLXFEA)
  except zvxnsgpDVHOUhGYfdqIkJbTmBLXFtN as exception:
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFtK(exception)
  return zvxnsgpDVHOUhGYfdqIkJbTmBLXFEw
 def GetReplay_UrlId(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi,zvxnsgpDVHOUhGYfdqIkJbTmBLXFta,zvxnsgpDVHOUhGYfdqIkJbTmBLXFic):
  zvxnsgpDVHOUhGYfdqIkJbTmBLXFtS=''
  try:
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQW=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.API_DOMAIN+'/api/v2/vod/'+zvxnsgpDVHOUhGYfdqIkJbTmBLXFta
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQN=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQi.callRequestCookies('Get',zvxnsgpDVHOUhGYfdqIkJbTmBLXFQW,payload=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,params=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,headers=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw,cookies=zvxnsgpDVHOUhGYfdqIkJbTmBLXFtw)
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFQK=json.loads(zvxnsgpDVHOUhGYfdqIkJbTmBLXFQN.text)
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFtS=zvxnsgpDVHOUhGYfdqIkJbTmBLXFQK['videoId']
  except zvxnsgpDVHOUhGYfdqIkJbTmBLXFtN as exception:
   zvxnsgpDVHOUhGYfdqIkJbTmBLXFtK(exception)
  return zvxnsgpDVHOUhGYfdqIkJbTmBLXFtS
# Created by pyminifier (https://github.com/liftoff/pyminifier)
