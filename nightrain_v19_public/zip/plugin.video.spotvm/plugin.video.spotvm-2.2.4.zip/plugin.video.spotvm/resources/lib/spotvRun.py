__author__="NightRain"
ubpljnYfWcMIiEXsGveBhACDVFtKmy=object
ubpljnYfWcMIiEXsGveBhACDVFtKmS=None
ubpljnYfWcMIiEXsGveBhACDVFtKmT=False
ubpljnYfWcMIiEXsGveBhACDVFtKmd=True
ubpljnYfWcMIiEXsGveBhACDVFtKmN=int
ubpljnYfWcMIiEXsGveBhACDVFtKmo=len
ubpljnYfWcMIiEXsGveBhACDVFtKmQ=str
ubpljnYfWcMIiEXsGveBhACDVFtKLw=id
ubpljnYfWcMIiEXsGveBhACDVFtKLq=open
ubpljnYfWcMIiEXsGveBhACDVFtKLz=dict
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
ubpljnYfWcMIiEXsGveBhACDVFtKwz=[{'title':'TV 채널 (유료사용자만 지원)','mode':'LIVE_GROUP','icon':'live.png'},{'title':'Live중계 (경기중에만 재생)','mode':'ELIVE_GROUP','icon':'live.png'},{'title':'-----------------','mode':'XXX'},{'title':'오늘의 추천 VOD','mode':'NOW_GROUP'},{'title':'인기영상 5','mode':'POP_GROUP'},{'title':'-----------------','mode':'XXX'},{'title':'VOD (리그, 경기별)','mode':'VOD_GROUP'},{'title':'Watched (시청목록)','mode':'WATCH','icon':'history.png'},]
ubpljnYfWcMIiEXsGveBhACDVFtKwU=xbmcvfs.translatePath(os.path.join(__profile__,'spotv_cookies.json'))
from spotvCore import*
class ubpljnYfWcMIiEXsGveBhACDVFtKwq(ubpljnYfWcMIiEXsGveBhACDVFtKmy):
 def __init__(ubpljnYfWcMIiEXsGveBhACDVFtKwm,ubpljnYfWcMIiEXsGveBhACDVFtKwL,ubpljnYfWcMIiEXsGveBhACDVFtKwJ,ubpljnYfWcMIiEXsGveBhACDVFtKwO):
  ubpljnYfWcMIiEXsGveBhACDVFtKwm._addon_url =ubpljnYfWcMIiEXsGveBhACDVFtKwL
  ubpljnYfWcMIiEXsGveBhACDVFtKwm._addon_handle=ubpljnYfWcMIiEXsGveBhACDVFtKwJ
  ubpljnYfWcMIiEXsGveBhACDVFtKwm.main_params =ubpljnYfWcMIiEXsGveBhACDVFtKwO
  ubpljnYfWcMIiEXsGveBhACDVFtKwm.SpotvObj =zvxnsgpDVHOUhGYfdqIkJbTmBLXFQE() 
 def addon_noti(ubpljnYfWcMIiEXsGveBhACDVFtKwm,sting):
  try:
   ubpljnYfWcMIiEXsGveBhACDVFtKwa=xbmcgui.Dialog()
   ubpljnYfWcMIiEXsGveBhACDVFtKwa.notification(__addonname__,sting)
  except:
   ubpljnYfWcMIiEXsGveBhACDVFtKmS
 def addon_log(ubpljnYfWcMIiEXsGveBhACDVFtKwm,string):
  try:
   ubpljnYfWcMIiEXsGveBhACDVFtKwH=string.encode('utf-8','ignore')
  except:
   ubpljnYfWcMIiEXsGveBhACDVFtKwH='addonException: addon_log'
  ubpljnYfWcMIiEXsGveBhACDVFtKwr=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,ubpljnYfWcMIiEXsGveBhACDVFtKwH),level=ubpljnYfWcMIiEXsGveBhACDVFtKwr)
 def get_keyboard_input(ubpljnYfWcMIiEXsGveBhACDVFtKwm,ubpljnYfWcMIiEXsGveBhACDVFtKwS):
  ubpljnYfWcMIiEXsGveBhACDVFtKwR=ubpljnYfWcMIiEXsGveBhACDVFtKmS
  kb=xbmc.Keyboard()
  kb.setHeading(ubpljnYfWcMIiEXsGveBhACDVFtKwS)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   ubpljnYfWcMIiEXsGveBhACDVFtKwR=kb.getText()
  return ubpljnYfWcMIiEXsGveBhACDVFtKwR
 def get_settings_account(ubpljnYfWcMIiEXsGveBhACDVFtKwm):
  ubpljnYfWcMIiEXsGveBhACDVFtKwx =__addon__.getSetting('id')
  ubpljnYfWcMIiEXsGveBhACDVFtKwk =__addon__.getSetting('pw')
  return(ubpljnYfWcMIiEXsGveBhACDVFtKwx,ubpljnYfWcMIiEXsGveBhACDVFtKwk)
 def get_settings_hidescoreyn(ubpljnYfWcMIiEXsGveBhACDVFtKwm):
  ubpljnYfWcMIiEXsGveBhACDVFtKwg =__addon__.getSetting('hidescore')
  if ubpljnYfWcMIiEXsGveBhACDVFtKwg=='false':
   return ubpljnYfWcMIiEXsGveBhACDVFtKmT
  else:
   return ubpljnYfWcMIiEXsGveBhACDVFtKmd
 def add_dir(ubpljnYfWcMIiEXsGveBhACDVFtKwm,label,sublabel='',img='',infoLabels=ubpljnYfWcMIiEXsGveBhACDVFtKmS,isFolder=ubpljnYfWcMIiEXsGveBhACDVFtKmd,params='',isLink=ubpljnYfWcMIiEXsGveBhACDVFtKmT,ContextMenu=ubpljnYfWcMIiEXsGveBhACDVFtKmS):
  ubpljnYfWcMIiEXsGveBhACDVFtKwy='%s?%s'%(ubpljnYfWcMIiEXsGveBhACDVFtKwm._addon_url,urllib.parse.urlencode(params))
  if sublabel:ubpljnYfWcMIiEXsGveBhACDVFtKwS='%s < %s >'%(label,sublabel)
  else: ubpljnYfWcMIiEXsGveBhACDVFtKwS=label
  if not img:img='DefaultFolder.png'
  ubpljnYfWcMIiEXsGveBhACDVFtKwT=xbmcgui.ListItem(ubpljnYfWcMIiEXsGveBhACDVFtKwS)
  ubpljnYfWcMIiEXsGveBhACDVFtKwT.setArt({'thumb':img,'icon':img,'poster':img})
  if infoLabels:ubpljnYfWcMIiEXsGveBhACDVFtKwT.setInfo(type="Video",infoLabels=infoLabels)
  if not isFolder and not isLink:
   ubpljnYfWcMIiEXsGveBhACDVFtKwT.setProperty('IsPlayable','true')
  if ContextMenu:ubpljnYfWcMIiEXsGveBhACDVFtKwT.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(ubpljnYfWcMIiEXsGveBhACDVFtKwm._addon_handle,ubpljnYfWcMIiEXsGveBhACDVFtKwy,ubpljnYfWcMIiEXsGveBhACDVFtKwT,isFolder)
 def get_selQuality(ubpljnYfWcMIiEXsGveBhACDVFtKwm,etype):
  try:
   ubpljnYfWcMIiEXsGveBhACDVFtKwd='selected_quality'
   ubpljnYfWcMIiEXsGveBhACDVFtKwN=[1080,720,540]
   ubpljnYfWcMIiEXsGveBhACDVFtKwo=ubpljnYfWcMIiEXsGveBhACDVFtKmN(__addon__.getSetting(ubpljnYfWcMIiEXsGveBhACDVFtKwd))
   return ubpljnYfWcMIiEXsGveBhACDVFtKwN[ubpljnYfWcMIiEXsGveBhACDVFtKwo]
  except:
   ubpljnYfWcMIiEXsGveBhACDVFtKmS
  return 1080 
 def dp_Main_List(ubpljnYfWcMIiEXsGveBhACDVFtKwm):
  for ubpljnYfWcMIiEXsGveBhACDVFtKwQ in ubpljnYfWcMIiEXsGveBhACDVFtKwz:
   ubpljnYfWcMIiEXsGveBhACDVFtKwS=ubpljnYfWcMIiEXsGveBhACDVFtKwQ.get('title')
   ubpljnYfWcMIiEXsGveBhACDVFtKqw=''
   ubpljnYfWcMIiEXsGveBhACDVFtKqz={'mode':ubpljnYfWcMIiEXsGveBhACDVFtKwQ.get('mode'),'page':'1'}
   if ubpljnYfWcMIiEXsGveBhACDVFtKwQ.get('mode')=='XXX':
    ubpljnYfWcMIiEXsGveBhACDVFtKqU=ubpljnYfWcMIiEXsGveBhACDVFtKmT
    ubpljnYfWcMIiEXsGveBhACDVFtKqm =ubpljnYfWcMIiEXsGveBhACDVFtKmd
   else:
    ubpljnYfWcMIiEXsGveBhACDVFtKqU=ubpljnYfWcMIiEXsGveBhACDVFtKmd
    ubpljnYfWcMIiEXsGveBhACDVFtKqm =ubpljnYfWcMIiEXsGveBhACDVFtKmT
   if 'icon' in ubpljnYfWcMIiEXsGveBhACDVFtKwQ:ubpljnYfWcMIiEXsGveBhACDVFtKqw=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',ubpljnYfWcMIiEXsGveBhACDVFtKwQ.get('icon')) 
   ubpljnYfWcMIiEXsGveBhACDVFtKwm.add_dir(ubpljnYfWcMIiEXsGveBhACDVFtKwS,sublabel='',img=ubpljnYfWcMIiEXsGveBhACDVFtKqw,infoLabels=ubpljnYfWcMIiEXsGveBhACDVFtKmS,isFolder=ubpljnYfWcMIiEXsGveBhACDVFtKqU,params=ubpljnYfWcMIiEXsGveBhACDVFtKqz,isLink=ubpljnYfWcMIiEXsGveBhACDVFtKqm)
  if ubpljnYfWcMIiEXsGveBhACDVFtKmo(ubpljnYfWcMIiEXsGveBhACDVFtKwz)>0:xbmcplugin.endOfDirectory(ubpljnYfWcMIiEXsGveBhACDVFtKwm._addon_handle)
 def dp_MainLeague_List(ubpljnYfWcMIiEXsGveBhACDVFtKwm,args):
  ubpljnYfWcMIiEXsGveBhACDVFtKqJ=ubpljnYfWcMIiEXsGveBhACDVFtKwm.SpotvObj.GetTitleGroupList()
  for ubpljnYfWcMIiEXsGveBhACDVFtKqO in ubpljnYfWcMIiEXsGveBhACDVFtKqJ:
   ubpljnYfWcMIiEXsGveBhACDVFtKwS =ubpljnYfWcMIiEXsGveBhACDVFtKqO.get('title')
   ubpljnYfWcMIiEXsGveBhACDVFtKqP =ubpljnYfWcMIiEXsGveBhACDVFtKqO.get('logo')
   ubpljnYfWcMIiEXsGveBhACDVFtKqa =ubpljnYfWcMIiEXsGveBhACDVFtKqO.get('reagueId')
   ubpljnYfWcMIiEXsGveBhACDVFtKqH =ubpljnYfWcMIiEXsGveBhACDVFtKqO.get('subGame')
   ubpljnYfWcMIiEXsGveBhACDVFtKqr={'mediatype':'episode','plot':'%s\n\n%s'%(ubpljnYfWcMIiEXsGveBhACDVFtKwS,ubpljnYfWcMIiEXsGveBhACDVFtKqH)}
   ubpljnYfWcMIiEXsGveBhACDVFtKqz={'mode':'LEAGUE_GROUP','reagueId':ubpljnYfWcMIiEXsGveBhACDVFtKqa}
   ubpljnYfWcMIiEXsGveBhACDVFtKwm.add_dir(ubpljnYfWcMIiEXsGveBhACDVFtKwS,sublabel=ubpljnYfWcMIiEXsGveBhACDVFtKmS,img=ubpljnYfWcMIiEXsGveBhACDVFtKqP,infoLabels=ubpljnYfWcMIiEXsGveBhACDVFtKqr,isFolder=ubpljnYfWcMIiEXsGveBhACDVFtKmd,params=ubpljnYfWcMIiEXsGveBhACDVFtKqz)
  if ubpljnYfWcMIiEXsGveBhACDVFtKmo(ubpljnYfWcMIiEXsGveBhACDVFtKqJ)>0:xbmcplugin.endOfDirectory(ubpljnYfWcMIiEXsGveBhACDVFtKwm._addon_handle,cacheToDisc=ubpljnYfWcMIiEXsGveBhACDVFtKmT)
 def dp_NowVod_GroupList(ubpljnYfWcMIiEXsGveBhACDVFtKwm,args):
  ubpljnYfWcMIiEXsGveBhACDVFtKqR=ubpljnYfWcMIiEXsGveBhACDVFtKmN(args.get('page'))
  ubpljnYfWcMIiEXsGveBhACDVFtKqJ,ubpljnYfWcMIiEXsGveBhACDVFtKqx=ubpljnYfWcMIiEXsGveBhACDVFtKwm.SpotvObj.Get_NowVod_GroupList(ubpljnYfWcMIiEXsGveBhACDVFtKqR)
  for ubpljnYfWcMIiEXsGveBhACDVFtKqO in ubpljnYfWcMIiEXsGveBhACDVFtKqJ:
   ubpljnYfWcMIiEXsGveBhACDVFtKqk =ubpljnYfWcMIiEXsGveBhACDVFtKqO.get('vodTitle')
   ubpljnYfWcMIiEXsGveBhACDVFtKqg =ubpljnYfWcMIiEXsGveBhACDVFtKqO.get('vodId')
   ubpljnYfWcMIiEXsGveBhACDVFtKqy =ubpljnYfWcMIiEXsGveBhACDVFtKqO.get('vodType')
   ubpljnYfWcMIiEXsGveBhACDVFtKqP=ubpljnYfWcMIiEXsGveBhACDVFtKqO.get('thumbnail')
   ubpljnYfWcMIiEXsGveBhACDVFtKqS =ubpljnYfWcMIiEXsGveBhACDVFtKqO.get('vtypeId')
   ubpljnYfWcMIiEXsGveBhACDVFtKqT =ubpljnYfWcMIiEXsGveBhACDVFtKqO.get('duration')
   ubpljnYfWcMIiEXsGveBhACDVFtKqr={'mediatype':'episode','duration':ubpljnYfWcMIiEXsGveBhACDVFtKqT,'plot':ubpljnYfWcMIiEXsGveBhACDVFtKqk}
   ubpljnYfWcMIiEXsGveBhACDVFtKqz={'mode':'NOW_VOD','mediacode':ubpljnYfWcMIiEXsGveBhACDVFtKqg,'mediatype':'vod','vtypeId':ubpljnYfWcMIiEXsGveBhACDVFtKqS}
   ubpljnYfWcMIiEXsGveBhACDVFtKwm.add_dir(ubpljnYfWcMIiEXsGveBhACDVFtKqk,sublabel=ubpljnYfWcMIiEXsGveBhACDVFtKqy,img=ubpljnYfWcMIiEXsGveBhACDVFtKqP,infoLabels=ubpljnYfWcMIiEXsGveBhACDVFtKqr,isFolder=ubpljnYfWcMIiEXsGveBhACDVFtKmT,params=ubpljnYfWcMIiEXsGveBhACDVFtKqz)
  if ubpljnYfWcMIiEXsGveBhACDVFtKqx:
   ubpljnYfWcMIiEXsGveBhACDVFtKqz['mode'] ='NOW_GROUP' 
   ubpljnYfWcMIiEXsGveBhACDVFtKqz['page'] =ubpljnYfWcMIiEXsGveBhACDVFtKmQ(ubpljnYfWcMIiEXsGveBhACDVFtKqR+1)
   ubpljnYfWcMIiEXsGveBhACDVFtKwS='[B]%s >>[/B]'%'다음 페이지'
   ubpljnYfWcMIiEXsGveBhACDVFtKqd=ubpljnYfWcMIiEXsGveBhACDVFtKmQ(ubpljnYfWcMIiEXsGveBhACDVFtKqR+1)
   ubpljnYfWcMIiEXsGveBhACDVFtKqw=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   ubpljnYfWcMIiEXsGveBhACDVFtKwm.add_dir(ubpljnYfWcMIiEXsGveBhACDVFtKwS,sublabel=ubpljnYfWcMIiEXsGveBhACDVFtKqd,img=ubpljnYfWcMIiEXsGveBhACDVFtKqw,infoLabels=ubpljnYfWcMIiEXsGveBhACDVFtKmS,isFolder=ubpljnYfWcMIiEXsGveBhACDVFtKmd,params=ubpljnYfWcMIiEXsGveBhACDVFtKqz)
  xbmcplugin.setContent(ubpljnYfWcMIiEXsGveBhACDVFtKwm._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(ubpljnYfWcMIiEXsGveBhACDVFtKwm._addon_handle,cacheToDisc=ubpljnYfWcMIiEXsGveBhACDVFtKmT)
 def dp_PopVod_GroupList(ubpljnYfWcMIiEXsGveBhACDVFtKwm,args):
  ubpljnYfWcMIiEXsGveBhACDVFtKqJ=ubpljnYfWcMIiEXsGveBhACDVFtKwm.SpotvObj.GetPopularGroupList()
  for ubpljnYfWcMIiEXsGveBhACDVFtKqO in ubpljnYfWcMIiEXsGveBhACDVFtKqJ:
   ubpljnYfWcMIiEXsGveBhACDVFtKqk =ubpljnYfWcMIiEXsGveBhACDVFtKqO.get('vodTitle')
   ubpljnYfWcMIiEXsGveBhACDVFtKqg =ubpljnYfWcMIiEXsGveBhACDVFtKqO.get('vodId')
   ubpljnYfWcMIiEXsGveBhACDVFtKqy =ubpljnYfWcMIiEXsGveBhACDVFtKqO.get('vodType')
   ubpljnYfWcMIiEXsGveBhACDVFtKqP=ubpljnYfWcMIiEXsGveBhACDVFtKqO.get('thumbnail')
   ubpljnYfWcMIiEXsGveBhACDVFtKqS =ubpljnYfWcMIiEXsGveBhACDVFtKqO.get('vtypeId')
   ubpljnYfWcMIiEXsGveBhACDVFtKqT =ubpljnYfWcMIiEXsGveBhACDVFtKqO.get('duration')
   ubpljnYfWcMIiEXsGveBhACDVFtKqr={'mediatype':'episode','duration':ubpljnYfWcMIiEXsGveBhACDVFtKqT,'plot':ubpljnYfWcMIiEXsGveBhACDVFtKqk}
   ubpljnYfWcMIiEXsGveBhACDVFtKqz={'mode':'POP_VOD','mediacode':ubpljnYfWcMIiEXsGveBhACDVFtKqg,'mediatype':'vod','vtypeId':ubpljnYfWcMIiEXsGveBhACDVFtKqS}
   ubpljnYfWcMIiEXsGveBhACDVFtKwm.add_dir(ubpljnYfWcMIiEXsGveBhACDVFtKqk,sublabel=ubpljnYfWcMIiEXsGveBhACDVFtKqy,img=ubpljnYfWcMIiEXsGveBhACDVFtKqP,infoLabels=ubpljnYfWcMIiEXsGveBhACDVFtKqr,isFolder=ubpljnYfWcMIiEXsGveBhACDVFtKmT,params=ubpljnYfWcMIiEXsGveBhACDVFtKqz)
  xbmcplugin.setContent(ubpljnYfWcMIiEXsGveBhACDVFtKwm._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(ubpljnYfWcMIiEXsGveBhACDVFtKwm._addon_handle,cacheToDisc=ubpljnYfWcMIiEXsGveBhACDVFtKmT)
 def dp_Season_List(ubpljnYfWcMIiEXsGveBhACDVFtKwm,args):
  ubpljnYfWcMIiEXsGveBhACDVFtKqa=args.get('reagueId')
  ubpljnYfWcMIiEXsGveBhACDVFtKwm.addon_log('Season_List - reagueId : '+ubpljnYfWcMIiEXsGveBhACDVFtKqa)
  ubpljnYfWcMIiEXsGveBhACDVFtKqJ=ubpljnYfWcMIiEXsGveBhACDVFtKwm.SpotvObj.GetSeasonList(ubpljnYfWcMIiEXsGveBhACDVFtKqa)
  for ubpljnYfWcMIiEXsGveBhACDVFtKqO in ubpljnYfWcMIiEXsGveBhACDVFtKqJ:
   ubpljnYfWcMIiEXsGveBhACDVFtKqo =ubpljnYfWcMIiEXsGveBhACDVFtKqO.get('reagueName')
   ubpljnYfWcMIiEXsGveBhACDVFtKqQ =ubpljnYfWcMIiEXsGveBhACDVFtKqO.get('gameTypeId')
   ubpljnYfWcMIiEXsGveBhACDVFtKzw =ubpljnYfWcMIiEXsGveBhACDVFtKqO.get('seasonName')
   ubpljnYfWcMIiEXsGveBhACDVFtKzq =ubpljnYfWcMIiEXsGveBhACDVFtKqO.get('seasonId')
   ubpljnYfWcMIiEXsGveBhACDVFtKqr={'mediatype':'episode','plot':'%s - %s'%(ubpljnYfWcMIiEXsGveBhACDVFtKqo,ubpljnYfWcMIiEXsGveBhACDVFtKzw)}
   ubpljnYfWcMIiEXsGveBhACDVFtKqz={'mode':'SEASON_GROUP','reagueId':ubpljnYfWcMIiEXsGveBhACDVFtKqa,'seasonId':ubpljnYfWcMIiEXsGveBhACDVFtKzq,'gameTypeId':ubpljnYfWcMIiEXsGveBhACDVFtKqQ,'page':'1'}
   ubpljnYfWcMIiEXsGveBhACDVFtKwm.add_dir(ubpljnYfWcMIiEXsGveBhACDVFtKqo,sublabel=ubpljnYfWcMIiEXsGveBhACDVFtKzw,img='',infoLabels=ubpljnYfWcMIiEXsGveBhACDVFtKqr,isFolder=ubpljnYfWcMIiEXsGveBhACDVFtKmd,params=ubpljnYfWcMIiEXsGveBhACDVFtKqz)
  if ubpljnYfWcMIiEXsGveBhACDVFtKmo(ubpljnYfWcMIiEXsGveBhACDVFtKqJ)>0:xbmcplugin.endOfDirectory(ubpljnYfWcMIiEXsGveBhACDVFtKwm._addon_handle,cacheToDisc=ubpljnYfWcMIiEXsGveBhACDVFtKmd)
 def dp_Game_List(ubpljnYfWcMIiEXsGveBhACDVFtKwm,args):
  ubpljnYfWcMIiEXsGveBhACDVFtKqQ=args.get('gameTypeId')
  ubpljnYfWcMIiEXsGveBhACDVFtKqa =args.get('reagueId')
  ubpljnYfWcMIiEXsGveBhACDVFtKzq =args.get('seasonId')
  ubpljnYfWcMIiEXsGveBhACDVFtKqR =ubpljnYfWcMIiEXsGveBhACDVFtKmN(args.get('page'))
  ubpljnYfWcMIiEXsGveBhACDVFtKwm.addon_log('Game_List - gameTypeId : '+ubpljnYfWcMIiEXsGveBhACDVFtKqQ)
  ubpljnYfWcMIiEXsGveBhACDVFtKwm.addon_log('Game_List - reagueId   : '+ubpljnYfWcMIiEXsGveBhACDVFtKqa)
  ubpljnYfWcMIiEXsGveBhACDVFtKwm.addon_log('Game_List - seasonId   : '+ubpljnYfWcMIiEXsGveBhACDVFtKzq)
  ubpljnYfWcMIiEXsGveBhACDVFtKqJ,ubpljnYfWcMIiEXsGveBhACDVFtKqx=ubpljnYfWcMIiEXsGveBhACDVFtKwm.SpotvObj.GetGameList(ubpljnYfWcMIiEXsGveBhACDVFtKqQ,ubpljnYfWcMIiEXsGveBhACDVFtKqa,ubpljnYfWcMIiEXsGveBhACDVFtKzq,ubpljnYfWcMIiEXsGveBhACDVFtKqR,hidescore=ubpljnYfWcMIiEXsGveBhACDVFtKwm.get_settings_hidescoreyn())
  for ubpljnYfWcMIiEXsGveBhACDVFtKqO in ubpljnYfWcMIiEXsGveBhACDVFtKqJ:
   ubpljnYfWcMIiEXsGveBhACDVFtKzU =ubpljnYfWcMIiEXsGveBhACDVFtKqO.get('gameTitle')
   ubpljnYfWcMIiEXsGveBhACDVFtKzm =ubpljnYfWcMIiEXsGveBhACDVFtKqO.get('beginDate')
   ubpljnYfWcMIiEXsGveBhACDVFtKqP =ubpljnYfWcMIiEXsGveBhACDVFtKqO.get('thumbnail')
   ubpljnYfWcMIiEXsGveBhACDVFtKzL =ubpljnYfWcMIiEXsGveBhACDVFtKqO.get('gameId')
   ubpljnYfWcMIiEXsGveBhACDVFtKzJ =ubpljnYfWcMIiEXsGveBhACDVFtKqO.get('totVodCnt')
   ubpljnYfWcMIiEXsGveBhACDVFtKzO =ubpljnYfWcMIiEXsGveBhACDVFtKqO.get('leaguenm')
   ubpljnYfWcMIiEXsGveBhACDVFtKzP =ubpljnYfWcMIiEXsGveBhACDVFtKqO.get('seasonnm')
   ubpljnYfWcMIiEXsGveBhACDVFtKza =ubpljnYfWcMIiEXsGveBhACDVFtKqO.get('roundnm')
   ubpljnYfWcMIiEXsGveBhACDVFtKzH =ubpljnYfWcMIiEXsGveBhACDVFtKqO.get('info_plot')
   ubpljnYfWcMIiEXsGveBhACDVFtKzr ='%s < %s >'%(ubpljnYfWcMIiEXsGveBhACDVFtKzU,ubpljnYfWcMIiEXsGveBhACDVFtKzm)
   ubpljnYfWcMIiEXsGveBhACDVFtKqr={'mediatype':'video','plot':ubpljnYfWcMIiEXsGveBhACDVFtKzH}
   ubpljnYfWcMIiEXsGveBhACDVFtKqz={'mode':'GAME_VOD_GROUP' if ubpljnYfWcMIiEXsGveBhACDVFtKzJ!=0 else 'XXX','saveTitle':ubpljnYfWcMIiEXsGveBhACDVFtKzr,'saveImg':ubpljnYfWcMIiEXsGveBhACDVFtKqP,'saveInfo':ubpljnYfWcMIiEXsGveBhACDVFtKqr['plot'],'gameid':ubpljnYfWcMIiEXsGveBhACDVFtKzL,'totVodCnt':ubpljnYfWcMIiEXsGveBhACDVFtKzJ,}
   ubpljnYfWcMIiEXsGveBhACDVFtKwm.add_dir(ubpljnYfWcMIiEXsGveBhACDVFtKzU,sublabel=ubpljnYfWcMIiEXsGveBhACDVFtKzm,img=ubpljnYfWcMIiEXsGveBhACDVFtKqP,infoLabels=ubpljnYfWcMIiEXsGveBhACDVFtKqr,isFolder=ubpljnYfWcMIiEXsGveBhACDVFtKmd,params=ubpljnYfWcMIiEXsGveBhACDVFtKqz)
  if ubpljnYfWcMIiEXsGveBhACDVFtKqx:
   ubpljnYfWcMIiEXsGveBhACDVFtKqz['mode'] ='SEASON_GROUP' 
   ubpljnYfWcMIiEXsGveBhACDVFtKqz['reagueId'] =ubpljnYfWcMIiEXsGveBhACDVFtKqa
   ubpljnYfWcMIiEXsGveBhACDVFtKqz['seasonId'] =ubpljnYfWcMIiEXsGveBhACDVFtKzq
   ubpljnYfWcMIiEXsGveBhACDVFtKqz['gameTypeId']=ubpljnYfWcMIiEXsGveBhACDVFtKqQ
   ubpljnYfWcMIiEXsGveBhACDVFtKqz['page'] =ubpljnYfWcMIiEXsGveBhACDVFtKmQ(ubpljnYfWcMIiEXsGveBhACDVFtKqR+1)
   ubpljnYfWcMIiEXsGveBhACDVFtKwS='[B]%s >>[/B]'%'다음 페이지'
   ubpljnYfWcMIiEXsGveBhACDVFtKqd=ubpljnYfWcMIiEXsGveBhACDVFtKmQ(ubpljnYfWcMIiEXsGveBhACDVFtKqR+1)
   ubpljnYfWcMIiEXsGveBhACDVFtKqw=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   ubpljnYfWcMIiEXsGveBhACDVFtKwm.add_dir(ubpljnYfWcMIiEXsGveBhACDVFtKwS,sublabel=ubpljnYfWcMIiEXsGveBhACDVFtKqd,img=ubpljnYfWcMIiEXsGveBhACDVFtKqw,infoLabels=ubpljnYfWcMIiEXsGveBhACDVFtKmS,isFolder=ubpljnYfWcMIiEXsGveBhACDVFtKmd,params=ubpljnYfWcMIiEXsGveBhACDVFtKqz)
  if ubpljnYfWcMIiEXsGveBhACDVFtKmo(ubpljnYfWcMIiEXsGveBhACDVFtKqJ)>0:xbmcplugin.endOfDirectory(ubpljnYfWcMIiEXsGveBhACDVFtKwm._addon_handle,cacheToDisc=ubpljnYfWcMIiEXsGveBhACDVFtKmT)
 def dp_GameVod_List(ubpljnYfWcMIiEXsGveBhACDVFtKwm,args):
  ubpljnYfWcMIiEXsGveBhACDVFtKzR =args.get('gameid')
  ubpljnYfWcMIiEXsGveBhACDVFtKzr=args.get('saveTitle')
  ubpljnYfWcMIiEXsGveBhACDVFtKzx =args.get('saveImg')
  ubpljnYfWcMIiEXsGveBhACDVFtKzk =args.get('saveInfo')
  ubpljnYfWcMIiEXsGveBhACDVFtKqJ=ubpljnYfWcMIiEXsGveBhACDVFtKwm.SpotvObj.GetGameVodList(ubpljnYfWcMIiEXsGveBhACDVFtKzR)
  for ubpljnYfWcMIiEXsGveBhACDVFtKqO in ubpljnYfWcMIiEXsGveBhACDVFtKqJ:
   ubpljnYfWcMIiEXsGveBhACDVFtKqk =ubpljnYfWcMIiEXsGveBhACDVFtKqO.get('vodTitle')
   ubpljnYfWcMIiEXsGveBhACDVFtKqg =ubpljnYfWcMIiEXsGveBhACDVFtKqO.get('vodId')
   ubpljnYfWcMIiEXsGveBhACDVFtKqy =ubpljnYfWcMIiEXsGveBhACDVFtKqO.get('vodType')
   ubpljnYfWcMIiEXsGveBhACDVFtKqP=ubpljnYfWcMIiEXsGveBhACDVFtKqO.get('thumbnail')
   ubpljnYfWcMIiEXsGveBhACDVFtKqS =ubpljnYfWcMIiEXsGveBhACDVFtKqO.get('vtypeId')
   ubpljnYfWcMIiEXsGveBhACDVFtKqT =ubpljnYfWcMIiEXsGveBhACDVFtKqO.get('duration')
   ubpljnYfWcMIiEXsGveBhACDVFtKqr={'mediatype':'episode','duration':ubpljnYfWcMIiEXsGveBhACDVFtKqT,'plot':'%s \n\n %s'%(ubpljnYfWcMIiEXsGveBhACDVFtKqk,ubpljnYfWcMIiEXsGveBhACDVFtKzk)}
   ubpljnYfWcMIiEXsGveBhACDVFtKqz={'mode':'GAME_VOD','saveTitle':ubpljnYfWcMIiEXsGveBhACDVFtKzr,'saveImg':ubpljnYfWcMIiEXsGveBhACDVFtKzx,'saveId':ubpljnYfWcMIiEXsGveBhACDVFtKzR,'saveInfo':ubpljnYfWcMIiEXsGveBhACDVFtKzk,'mediacode':ubpljnYfWcMIiEXsGveBhACDVFtKqg,'mediatype':'vod','vtypeId':ubpljnYfWcMIiEXsGveBhACDVFtKqS}
   ubpljnYfWcMIiEXsGveBhACDVFtKwm.add_dir(ubpljnYfWcMIiEXsGveBhACDVFtKqk,sublabel=ubpljnYfWcMIiEXsGveBhACDVFtKqy,img=ubpljnYfWcMIiEXsGveBhACDVFtKqP,infoLabels=ubpljnYfWcMIiEXsGveBhACDVFtKqr,isFolder=ubpljnYfWcMIiEXsGveBhACDVFtKmT,params=ubpljnYfWcMIiEXsGveBhACDVFtKqz)
  xbmcplugin.setContent(ubpljnYfWcMIiEXsGveBhACDVFtKwm._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(ubpljnYfWcMIiEXsGveBhACDVFtKwm._addon_handle,cacheToDisc=ubpljnYfWcMIiEXsGveBhACDVFtKmT)
 def login_main(ubpljnYfWcMIiEXsGveBhACDVFtKwm):
  (ubpljnYfWcMIiEXsGveBhACDVFtKzg,ubpljnYfWcMIiEXsGveBhACDVFtKzy)=ubpljnYfWcMIiEXsGveBhACDVFtKwm.get_settings_account()
  if not(ubpljnYfWcMIiEXsGveBhACDVFtKzg and ubpljnYfWcMIiEXsGveBhACDVFtKzy):
   ubpljnYfWcMIiEXsGveBhACDVFtKwa=xbmcgui.Dialog()
   ubpljnYfWcMIiEXsGveBhACDVFtKzS=ubpljnYfWcMIiEXsGveBhACDVFtKwa.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if ubpljnYfWcMIiEXsGveBhACDVFtKzS==ubpljnYfWcMIiEXsGveBhACDVFtKmd:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if ubpljnYfWcMIiEXsGveBhACDVFtKwm.cookiefile_check():return
  if xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINWAIT')=='TRUE':
   ubpljnYfWcMIiEXsGveBhACDVFtKzT=0
   while ubpljnYfWcMIiEXsGveBhACDVFtKmd:
    ubpljnYfWcMIiEXsGveBhACDVFtKzT+=1
    time.sleep(0.05)
    if ubpljnYfWcMIiEXsGveBhACDVFtKzT>600:return
  else:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','TRUE')
  ubpljnYfWcMIiEXsGveBhACDVFtKzd=ubpljnYfWcMIiEXsGveBhACDVFtKwm.SpotvObj.GetCredential(ubpljnYfWcMIiEXsGveBhACDVFtKzg,ubpljnYfWcMIiEXsGveBhACDVFtKzy)
  if ubpljnYfWcMIiEXsGveBhACDVFtKzd:ubpljnYfWcMIiEXsGveBhACDVFtKwm.cookiefile_save()
  xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
  if ubpljnYfWcMIiEXsGveBhACDVFtKzd==ubpljnYfWcMIiEXsGveBhACDVFtKmT:
   ubpljnYfWcMIiEXsGveBhACDVFtKwm.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_LiveChannel_List(ubpljnYfWcMIiEXsGveBhACDVFtKwm,args):
  ubpljnYfWcMIiEXsGveBhACDVFtKzN=ubpljnYfWcMIiEXsGveBhACDVFtKwm.SpotvObj.GetLiveChannelList()
  for ubpljnYfWcMIiEXsGveBhACDVFtKzo in ubpljnYfWcMIiEXsGveBhACDVFtKzN:
   ubpljnYfWcMIiEXsGveBhACDVFtKLw =ubpljnYfWcMIiEXsGveBhACDVFtKzo.get('id')
   ubpljnYfWcMIiEXsGveBhACDVFtKwS =ubpljnYfWcMIiEXsGveBhACDVFtKzo.get('name')
   ubpljnYfWcMIiEXsGveBhACDVFtKqL =ubpljnYfWcMIiEXsGveBhACDVFtKzo.get('programName')
   ubpljnYfWcMIiEXsGveBhACDVFtKqP =ubpljnYfWcMIiEXsGveBhACDVFtKzo.get('logo')
   ubpljnYfWcMIiEXsGveBhACDVFtKzQ=ubpljnYfWcMIiEXsGveBhACDVFtKzo.get('channelepg')
   ubpljnYfWcMIiEXsGveBhACDVFtKUw =ubpljnYfWcMIiEXsGveBhACDVFtKzo.get('free')
   ubpljnYfWcMIiEXsGveBhACDVFtKqr={'plot':'%s\n\n%s'%(ubpljnYfWcMIiEXsGveBhACDVFtKwS,ubpljnYfWcMIiEXsGveBhACDVFtKzQ),'mediatype':'episode',}
   ubpljnYfWcMIiEXsGveBhACDVFtKqz={'mode':'LIVE','mediacode':ubpljnYfWcMIiEXsGveBhACDVFtKLw,'free':ubpljnYfWcMIiEXsGveBhACDVFtKUw,'mediatype':'live'}
   if ubpljnYfWcMIiEXsGveBhACDVFtKUw:ubpljnYfWcMIiEXsGveBhACDVFtKwS+=' [free]'
   ubpljnYfWcMIiEXsGveBhACDVFtKwm.add_dir(ubpljnYfWcMIiEXsGveBhACDVFtKwS,sublabel=ubpljnYfWcMIiEXsGveBhACDVFtKqL,img=ubpljnYfWcMIiEXsGveBhACDVFtKqP,infoLabels=ubpljnYfWcMIiEXsGveBhACDVFtKqr,isFolder=ubpljnYfWcMIiEXsGveBhACDVFtKmT,params=ubpljnYfWcMIiEXsGveBhACDVFtKqz)
  xbmcplugin.setContent(ubpljnYfWcMIiEXsGveBhACDVFtKwm._addon_handle,'episodes')
  if ubpljnYfWcMIiEXsGveBhACDVFtKmo(ubpljnYfWcMIiEXsGveBhACDVFtKzN)>0:xbmcplugin.endOfDirectory(ubpljnYfWcMIiEXsGveBhACDVFtKwm._addon_handle,cacheToDisc=ubpljnYfWcMIiEXsGveBhACDVFtKmT)
 def dp_EventLiveChannel_List(ubpljnYfWcMIiEXsGveBhACDVFtKwm,args):
  ubpljnYfWcMIiEXsGveBhACDVFtKzN,ubpljnYfWcMIiEXsGveBhACDVFtKUq=ubpljnYfWcMIiEXsGveBhACDVFtKwm.SpotvObj.GetEventLiveList()
  if ubpljnYfWcMIiEXsGveBhACDVFtKUq!=401 and ubpljnYfWcMIiEXsGveBhACDVFtKmo(ubpljnYfWcMIiEXsGveBhACDVFtKzN)==0:
   ubpljnYfWcMIiEXsGveBhACDVFtKwm.addon_noti(__language__(30907).encode('utf8'))
  for ubpljnYfWcMIiEXsGveBhACDVFtKzo in ubpljnYfWcMIiEXsGveBhACDVFtKzN:
   ubpljnYfWcMIiEXsGveBhACDVFtKwS =ubpljnYfWcMIiEXsGveBhACDVFtKzo.get('title')
   ubpljnYfWcMIiEXsGveBhACDVFtKqL =ubpljnYfWcMIiEXsGveBhACDVFtKzo.get('startTime')
   ubpljnYfWcMIiEXsGveBhACDVFtKqP =ubpljnYfWcMIiEXsGveBhACDVFtKzo.get('logo')
   ubpljnYfWcMIiEXsGveBhACDVFtKUw =ubpljnYfWcMIiEXsGveBhACDVFtKzo.get('free')
   ubpljnYfWcMIiEXsGveBhACDVFtKqr={'mediatype':'episode','plot':'%s\n\n%s'%(ubpljnYfWcMIiEXsGveBhACDVFtKwS,ubpljnYfWcMIiEXsGveBhACDVFtKqL)}
   ubpljnYfWcMIiEXsGveBhACDVFtKqz={'mode':'ELIVE','mediacode':ubpljnYfWcMIiEXsGveBhACDVFtKzo.get('liveId'),'free':ubpljnYfWcMIiEXsGveBhACDVFtKUw,'mediatype':'live'}
   if ubpljnYfWcMIiEXsGveBhACDVFtKUw:ubpljnYfWcMIiEXsGveBhACDVFtKwS+=' [free]'
   ubpljnYfWcMIiEXsGveBhACDVFtKwm.add_dir(ubpljnYfWcMIiEXsGveBhACDVFtKwS,sublabel=ubpljnYfWcMIiEXsGveBhACDVFtKqL,img=ubpljnYfWcMIiEXsGveBhACDVFtKqP,infoLabels=ubpljnYfWcMIiEXsGveBhACDVFtKqr,isFolder=ubpljnYfWcMIiEXsGveBhACDVFtKmT,params=ubpljnYfWcMIiEXsGveBhACDVFtKqz)
  xbmcplugin.setContent(ubpljnYfWcMIiEXsGveBhACDVFtKwm._addon_handle,'episodes')
  if ubpljnYfWcMIiEXsGveBhACDVFtKmo(ubpljnYfWcMIiEXsGveBhACDVFtKzN)>0:xbmcplugin.endOfDirectory(ubpljnYfWcMIiEXsGveBhACDVFtKwm._addon_handle,cacheToDisc=ubpljnYfWcMIiEXsGveBhACDVFtKmd)
  return ubpljnYfWcMIiEXsGveBhACDVFtKUq
 def play_VIDEO(ubpljnYfWcMIiEXsGveBhACDVFtKwm,args):
  ubpljnYfWcMIiEXsGveBhACDVFtKUz =args.get('mode')
  ubpljnYfWcMIiEXsGveBhACDVFtKUm =args.get('mediacode')
  ubpljnYfWcMIiEXsGveBhACDVFtKUL =args.get('mediatype')
  ubpljnYfWcMIiEXsGveBhACDVFtKqS =args.get('vtypeId')
  ubpljnYfWcMIiEXsGveBhACDVFtKUJ =args.get('hlsUrl')
  if ubpljnYfWcMIiEXsGveBhACDVFtKUz=='LIVE':
   if args.get('free')=='False':
    if ubpljnYfWcMIiEXsGveBhACDVFtKwm.SpotvObj.CheckSubEnd()==ubpljnYfWcMIiEXsGveBhACDVFtKmT:
     ubpljnYfWcMIiEXsGveBhACDVFtKwm.addon_noti(__language__(30908).encode('utf8'))
     return
  elif ubpljnYfWcMIiEXsGveBhACDVFtKUz=='ELIVE':
   if args.get('free')=='False':
    if ubpljnYfWcMIiEXsGveBhACDVFtKwm.SpotvObj.CheckSubEnd()==ubpljnYfWcMIiEXsGveBhACDVFtKmT:
     ubpljnYfWcMIiEXsGveBhACDVFtKwm.addon_noti(__language__(30908).encode('utf8'))
     return
  if ubpljnYfWcMIiEXsGveBhACDVFtKUm=='' or ubpljnYfWcMIiEXsGveBhACDVFtKUm==ubpljnYfWcMIiEXsGveBhACDVFtKmS:
   ubpljnYfWcMIiEXsGveBhACDVFtKwm.addon_noti(__language__(30907).encode('utf8'))
   return
  if ubpljnYfWcMIiEXsGveBhACDVFtKUz=='LIVE':
   ubpljnYfWcMIiEXsGveBhACDVFtKUO=ubpljnYfWcMIiEXsGveBhACDVFtKwm.SpotvObj.GetHlsUrl(ubpljnYfWcMIiEXsGveBhACDVFtKUm)
  else:
   ubpljnYfWcMIiEXsGveBhACDVFtKwm.addon_log('mediacode : '+ubpljnYfWcMIiEXsGveBhACDVFtKUm)
   ubpljnYfWcMIiEXsGveBhACDVFtKwm.addon_log('mediatype : '+ubpljnYfWcMIiEXsGveBhACDVFtKUL)
   ubpljnYfWcMIiEXsGveBhACDVFtKwm.addon_log('vtypeId   : '+ubpljnYfWcMIiEXsGveBhACDVFtKmQ(ubpljnYfWcMIiEXsGveBhACDVFtKqS))
   ubpljnYfWcMIiEXsGveBhACDVFtKUO=ubpljnYfWcMIiEXsGveBhACDVFtKwm.SpotvObj.GetBroadURL(ubpljnYfWcMIiEXsGveBhACDVFtKUm,ubpljnYfWcMIiEXsGveBhACDVFtKUL,ubpljnYfWcMIiEXsGveBhACDVFtKqS)
  if ubpljnYfWcMIiEXsGveBhACDVFtKUO=='':
   ubpljnYfWcMIiEXsGveBhACDVFtKwm.addon_noti(__language__(30908).encode('utf8'))
   return
  ubpljnYfWcMIiEXsGveBhACDVFtKUP=ubpljnYfWcMIiEXsGveBhACDVFtKUO
  try:
   ubpljnYfWcMIiEXsGveBhACDVFtKwm.addon_log('mainMode  = '+ubpljnYfWcMIiEXsGveBhACDVFtKUz)
  except:
   ubpljnYfWcMIiEXsGveBhACDVFtKmS
  ubpljnYfWcMIiEXsGveBhACDVFtKwm.addon_log(ubpljnYfWcMIiEXsGveBhACDVFtKUP)
  ubpljnYfWcMIiEXsGveBhACDVFtKUa=xbmcgui.ListItem(path=ubpljnYfWcMIiEXsGveBhACDVFtKUP)
  xbmcplugin.setResolvedUrl(ubpljnYfWcMIiEXsGveBhACDVFtKwm._addon_handle,ubpljnYfWcMIiEXsGveBhACDVFtKmd,ubpljnYfWcMIiEXsGveBhACDVFtKUa)
  try:
   if ubpljnYfWcMIiEXsGveBhACDVFtKUL=='vod' and ubpljnYfWcMIiEXsGveBhACDVFtKUz not in['POP_VOD','NOW_VOD']:
    ubpljnYfWcMIiEXsGveBhACDVFtKqz={'code':args.get('saveId'),'img':args.get('saveImg'),'title':args.get('saveTitle'),'info':args.get('saveInfo')}
    ubpljnYfWcMIiEXsGveBhACDVFtKwm.Save_Watched_List(ubpljnYfWcMIiEXsGveBhACDVFtKUL,ubpljnYfWcMIiEXsGveBhACDVFtKqz)
  except:
   ubpljnYfWcMIiEXsGveBhACDVFtKmS
 def logout(ubpljnYfWcMIiEXsGveBhACDVFtKwm):
  ubpljnYfWcMIiEXsGveBhACDVFtKwa=xbmcgui.Dialog()
  ubpljnYfWcMIiEXsGveBhACDVFtKzS=ubpljnYfWcMIiEXsGveBhACDVFtKwa.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if ubpljnYfWcMIiEXsGveBhACDVFtKzS==ubpljnYfWcMIiEXsGveBhACDVFtKmT:sys.exit()
  ubpljnYfWcMIiEXsGveBhACDVFtKwm.SpotvObj.Init_ST_Total()
  if os.path.isfile(ubpljnYfWcMIiEXsGveBhACDVFtKwU):os.remove(ubpljnYfWcMIiEXsGveBhACDVFtKwU)
  ubpljnYfWcMIiEXsGveBhACDVFtKwm.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(ubpljnYfWcMIiEXsGveBhACDVFtKwm):
  ubpljnYfWcMIiEXsGveBhACDVFtKUH =ubpljnYfWcMIiEXsGveBhACDVFtKwm.SpotvObj.Get_Now_Datetime()
  ubpljnYfWcMIiEXsGveBhACDVFtKUr=ubpljnYfWcMIiEXsGveBhACDVFtKUH+datetime.timedelta(days=ubpljnYfWcMIiEXsGveBhACDVFtKmN(__addon__.getSetting('cache_ttl')))
  (ubpljnYfWcMIiEXsGveBhACDVFtKzg,ubpljnYfWcMIiEXsGveBhACDVFtKzy)=ubpljnYfWcMIiEXsGveBhACDVFtKwm.get_settings_account()
  ubpljnYfWcMIiEXsGveBhACDVFtKwm.SpotvObj.Save_session_acount(ubpljnYfWcMIiEXsGveBhACDVFtKzg,ubpljnYfWcMIiEXsGveBhACDVFtKzy)
  ubpljnYfWcMIiEXsGveBhACDVFtKwm.SpotvObj.ST['account']['token_limit']=ubpljnYfWcMIiEXsGveBhACDVFtKUr.strftime('%Y%m%d')
  ubpljnYfWcMIiEXsGveBhACDVFtKwm.SpotvObj.JsonFile_Save(ubpljnYfWcMIiEXsGveBhACDVFtKwU,ubpljnYfWcMIiEXsGveBhACDVFtKwm.SpotvObj.ST)
 def cookiefile_check(ubpljnYfWcMIiEXsGveBhACDVFtKwm):
  ubpljnYfWcMIiEXsGveBhACDVFtKwm.SpotvObj.ST=ubpljnYfWcMIiEXsGveBhACDVFtKwm.SpotvObj.JsonFile_Load(ubpljnYfWcMIiEXsGveBhACDVFtKwU)
  if 'account' not in ubpljnYfWcMIiEXsGveBhACDVFtKwm.SpotvObj.ST:
   ubpljnYfWcMIiEXsGveBhACDVFtKwm.SpotvObj.Init_ST_Total()
   return ubpljnYfWcMIiEXsGveBhACDVFtKmT
  (ubpljnYfWcMIiEXsGveBhACDVFtKUR,ubpljnYfWcMIiEXsGveBhACDVFtKUx)=ubpljnYfWcMIiEXsGveBhACDVFtKwm.get_settings_account()
  (ubpljnYfWcMIiEXsGveBhACDVFtKUk,ubpljnYfWcMIiEXsGveBhACDVFtKUg)=ubpljnYfWcMIiEXsGveBhACDVFtKwm.SpotvObj.Load_session_acount()
  if ubpljnYfWcMIiEXsGveBhACDVFtKUR!=ubpljnYfWcMIiEXsGveBhACDVFtKUk or ubpljnYfWcMIiEXsGveBhACDVFtKUx!=ubpljnYfWcMIiEXsGveBhACDVFtKUg:
   ubpljnYfWcMIiEXsGveBhACDVFtKwm.SpotvObj.Init_ST_Total()
   return ubpljnYfWcMIiEXsGveBhACDVFtKmT
  if ubpljnYfWcMIiEXsGveBhACDVFtKmN(ubpljnYfWcMIiEXsGveBhACDVFtKwm.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))>ubpljnYfWcMIiEXsGveBhACDVFtKmN(ubpljnYfWcMIiEXsGveBhACDVFtKwm.SpotvObj.ST['account']['token_limit']):
   ubpljnYfWcMIiEXsGveBhACDVFtKwm.SpotvObj.Init_ST_Total()
   return ubpljnYfWcMIiEXsGveBhACDVFtKmT
  return ubpljnYfWcMIiEXsGveBhACDVFtKmd
 def dp_History_Remove(ubpljnYfWcMIiEXsGveBhACDVFtKwm,args):
  ubpljnYfWcMIiEXsGveBhACDVFtKUy=args.get('delType')
  ubpljnYfWcMIiEXsGveBhACDVFtKUS =args.get('sKey')
  ubpljnYfWcMIiEXsGveBhACDVFtKUT =args.get('vType')
  ubpljnYfWcMIiEXsGveBhACDVFtKwa=xbmcgui.Dialog()
  if ubpljnYfWcMIiEXsGveBhACDVFtKUy=='WATCH_ALL':
   ubpljnYfWcMIiEXsGveBhACDVFtKzS=ubpljnYfWcMIiEXsGveBhACDVFtKwa.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif ubpljnYfWcMIiEXsGveBhACDVFtKUy=='WATCH_ONE':
   ubpljnYfWcMIiEXsGveBhACDVFtKzS=ubpljnYfWcMIiEXsGveBhACDVFtKwa.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  if ubpljnYfWcMIiEXsGveBhACDVFtKzS==ubpljnYfWcMIiEXsGveBhACDVFtKmT:sys.exit()
  if ubpljnYfWcMIiEXsGveBhACDVFtKUy=='WATCH_ALL':
   ubpljnYfWcMIiEXsGveBhACDVFtKUd=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%ubpljnYfWcMIiEXsGveBhACDVFtKUT))
   if os.path.isfile(ubpljnYfWcMIiEXsGveBhACDVFtKUd):os.remove(ubpljnYfWcMIiEXsGveBhACDVFtKUd)
  elif ubpljnYfWcMIiEXsGveBhACDVFtKUy=='WATCH_ONE':
   ubpljnYfWcMIiEXsGveBhACDVFtKUd=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%ubpljnYfWcMIiEXsGveBhACDVFtKUT))
   try:
    ubpljnYfWcMIiEXsGveBhACDVFtKUN=ubpljnYfWcMIiEXsGveBhACDVFtKwm.Load_List_File(ubpljnYfWcMIiEXsGveBhACDVFtKUT) 
    fp=ubpljnYfWcMIiEXsGveBhACDVFtKLq(ubpljnYfWcMIiEXsGveBhACDVFtKUd,'w',-1,'utf-8')
    for ubpljnYfWcMIiEXsGveBhACDVFtKUo in ubpljnYfWcMIiEXsGveBhACDVFtKUN:
     ubpljnYfWcMIiEXsGveBhACDVFtKUQ=ubpljnYfWcMIiEXsGveBhACDVFtKLz(urllib.parse.parse_qsl(ubpljnYfWcMIiEXsGveBhACDVFtKUo))
     ubpljnYfWcMIiEXsGveBhACDVFtKmw=ubpljnYfWcMIiEXsGveBhACDVFtKUQ.get('code').strip()
     if ubpljnYfWcMIiEXsGveBhACDVFtKUS!=ubpljnYfWcMIiEXsGveBhACDVFtKmw:
      fp.write(ubpljnYfWcMIiEXsGveBhACDVFtKUo)
    fp.close()
   except:
    ubpljnYfWcMIiEXsGveBhACDVFtKmS
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(ubpljnYfWcMIiEXsGveBhACDVFtKwm,ubpljnYfWcMIiEXsGveBhACDVFtKUL):
  try:
   ubpljnYfWcMIiEXsGveBhACDVFtKmq=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%ubpljnYfWcMIiEXsGveBhACDVFtKUL))
   fp=ubpljnYfWcMIiEXsGveBhACDVFtKLq(ubpljnYfWcMIiEXsGveBhACDVFtKmq,'r',-1,'utf-8')
   ubpljnYfWcMIiEXsGveBhACDVFtKmz=fp.readlines()
   fp.close()
  except:
   ubpljnYfWcMIiEXsGveBhACDVFtKmz=[]
  return ubpljnYfWcMIiEXsGveBhACDVFtKmz
 def Save_Watched_List(ubpljnYfWcMIiEXsGveBhACDVFtKwm,stype,ubpljnYfWcMIiEXsGveBhACDVFtKwO):
  try:
   ubpljnYfWcMIiEXsGveBhACDVFtKmq=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   ubpljnYfWcMIiEXsGveBhACDVFtKUN=ubpljnYfWcMIiEXsGveBhACDVFtKwm.Load_List_File(stype) 
   fp=ubpljnYfWcMIiEXsGveBhACDVFtKLq(ubpljnYfWcMIiEXsGveBhACDVFtKmq,'w',-1,'utf-8')
   ubpljnYfWcMIiEXsGveBhACDVFtKmU=urllib.parse.urlencode(ubpljnYfWcMIiEXsGveBhACDVFtKwO)
   ubpljnYfWcMIiEXsGveBhACDVFtKmU=ubpljnYfWcMIiEXsGveBhACDVFtKmU+'\n'
   fp.write(ubpljnYfWcMIiEXsGveBhACDVFtKmU)
   ubpljnYfWcMIiEXsGveBhACDVFtKmL=0
   for ubpljnYfWcMIiEXsGveBhACDVFtKUo in ubpljnYfWcMIiEXsGveBhACDVFtKUN:
    ubpljnYfWcMIiEXsGveBhACDVFtKUQ=ubpljnYfWcMIiEXsGveBhACDVFtKLz(urllib.parse.parse_qsl(ubpljnYfWcMIiEXsGveBhACDVFtKUo))
    ubpljnYfWcMIiEXsGveBhACDVFtKmJ=ubpljnYfWcMIiEXsGveBhACDVFtKwO.get('code')
    ubpljnYfWcMIiEXsGveBhACDVFtKmO=ubpljnYfWcMIiEXsGveBhACDVFtKUQ.get('code')
    if ubpljnYfWcMIiEXsGveBhACDVFtKmJ!=ubpljnYfWcMIiEXsGveBhACDVFtKmO:
     fp.write(ubpljnYfWcMIiEXsGveBhACDVFtKUo)
     ubpljnYfWcMIiEXsGveBhACDVFtKmL+=1
     if ubpljnYfWcMIiEXsGveBhACDVFtKmL>=50:break
   fp.close()
  except:
   ubpljnYfWcMIiEXsGveBhACDVFtKmS
 def dp_Watch_List(ubpljnYfWcMIiEXsGveBhACDVFtKwm,args):
  ubpljnYfWcMIiEXsGveBhACDVFtKUL ='vod'
  if ubpljnYfWcMIiEXsGveBhACDVFtKUL=='vod':
   ubpljnYfWcMIiEXsGveBhACDVFtKmP=ubpljnYfWcMIiEXsGveBhACDVFtKwm.Load_List_File(ubpljnYfWcMIiEXsGveBhACDVFtKUL)
   for ubpljnYfWcMIiEXsGveBhACDVFtKma in ubpljnYfWcMIiEXsGveBhACDVFtKmP:
    ubpljnYfWcMIiEXsGveBhACDVFtKmH=ubpljnYfWcMIiEXsGveBhACDVFtKLz(urllib.parse.parse_qsl(ubpljnYfWcMIiEXsGveBhACDVFtKma))
    ubpljnYfWcMIiEXsGveBhACDVFtKwS =ubpljnYfWcMIiEXsGveBhACDVFtKmH.get('title')
    ubpljnYfWcMIiEXsGveBhACDVFtKqP=ubpljnYfWcMIiEXsGveBhACDVFtKmH.get('img')
    ubpljnYfWcMIiEXsGveBhACDVFtKUm=ubpljnYfWcMIiEXsGveBhACDVFtKmH.get('code')
    ubpljnYfWcMIiEXsGveBhACDVFtKmr =ubpljnYfWcMIiEXsGveBhACDVFtKmH.get('info')
    ubpljnYfWcMIiEXsGveBhACDVFtKqr={}
    ubpljnYfWcMIiEXsGveBhACDVFtKqr['plot'] =ubpljnYfWcMIiEXsGveBhACDVFtKmr
    ubpljnYfWcMIiEXsGveBhACDVFtKqr['mediatype']='tvshow'
    ubpljnYfWcMIiEXsGveBhACDVFtKqz={'mode':'GAME_VOD_GROUP','gameid':ubpljnYfWcMIiEXsGveBhACDVFtKUm,'saveTitle':ubpljnYfWcMIiEXsGveBhACDVFtKwS,'saveImg':ubpljnYfWcMIiEXsGveBhACDVFtKqP,'saveInfo':ubpljnYfWcMIiEXsGveBhACDVFtKmr,'mediatype':ubpljnYfWcMIiEXsGveBhACDVFtKUL}
    ubpljnYfWcMIiEXsGveBhACDVFtKmR={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':ubpljnYfWcMIiEXsGveBhACDVFtKUm,'vType':ubpljnYfWcMIiEXsGveBhACDVFtKUL,}
    ubpljnYfWcMIiEXsGveBhACDVFtKmx=urllib.parse.urlencode(ubpljnYfWcMIiEXsGveBhACDVFtKmR)
    ubpljnYfWcMIiEXsGveBhACDVFtKmk=[('선택된 시청이력 ( %s ) 삭제'%(ubpljnYfWcMIiEXsGveBhACDVFtKwS),'RunPlugin(plugin://plugin.video.spotvm/?%s)'%(ubpljnYfWcMIiEXsGveBhACDVFtKmx))]
    ubpljnYfWcMIiEXsGveBhACDVFtKwm.add_dir(ubpljnYfWcMIiEXsGveBhACDVFtKwS,sublabel='',img=ubpljnYfWcMIiEXsGveBhACDVFtKqP,infoLabels=ubpljnYfWcMIiEXsGveBhACDVFtKqr,isFolder=ubpljnYfWcMIiEXsGveBhACDVFtKmd,params=ubpljnYfWcMIiEXsGveBhACDVFtKqz,ContextMenu=ubpljnYfWcMIiEXsGveBhACDVFtKmk)
   ubpljnYfWcMIiEXsGveBhACDVFtKqr={'plot':'시청목록을 삭제합니다.'}
   ubpljnYfWcMIiEXsGveBhACDVFtKwS='*** 시청목록 삭제 ***'
   ubpljnYfWcMIiEXsGveBhACDVFtKqz={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':ubpljnYfWcMIiEXsGveBhACDVFtKUL,}
   ubpljnYfWcMIiEXsGveBhACDVFtKqw=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   ubpljnYfWcMIiEXsGveBhACDVFtKwm.add_dir(ubpljnYfWcMIiEXsGveBhACDVFtKwS,sublabel='',img=ubpljnYfWcMIiEXsGveBhACDVFtKqw,infoLabels=ubpljnYfWcMIiEXsGveBhACDVFtKqr,isFolder=ubpljnYfWcMIiEXsGveBhACDVFtKmT,params=ubpljnYfWcMIiEXsGveBhACDVFtKqz,isLink=ubpljnYfWcMIiEXsGveBhACDVFtKmd)
   xbmcplugin.endOfDirectory(ubpljnYfWcMIiEXsGveBhACDVFtKwm._addon_handle,cacheToDisc=ubpljnYfWcMIiEXsGveBhACDVFtKmT)
 def spotv_main(ubpljnYfWcMIiEXsGveBhACDVFtKwm):
  ubpljnYfWcMIiEXsGveBhACDVFtKmg=ubpljnYfWcMIiEXsGveBhACDVFtKwm.main_params.get('mode',ubpljnYfWcMIiEXsGveBhACDVFtKmS)
  if ubpljnYfWcMIiEXsGveBhACDVFtKmg=='LOGOUT':
   ubpljnYfWcMIiEXsGveBhACDVFtKwm.logout()
   return
  ubpljnYfWcMIiEXsGveBhACDVFtKwm.login_main()
  if ubpljnYfWcMIiEXsGveBhACDVFtKmg is ubpljnYfWcMIiEXsGveBhACDVFtKmS:
   ubpljnYfWcMIiEXsGveBhACDVFtKwm.dp_Main_List()
  elif ubpljnYfWcMIiEXsGveBhACDVFtKmg=='LIVE_GROUP':
   ubpljnYfWcMIiEXsGveBhACDVFtKwm.dp_LiveChannel_List(ubpljnYfWcMIiEXsGveBhACDVFtKwm.main_params)
  elif ubpljnYfWcMIiEXsGveBhACDVFtKmg=='ELIVE_GROUP':
   ubpljnYfWcMIiEXsGveBhACDVFtKUq=ubpljnYfWcMIiEXsGveBhACDVFtKwm.dp_EventLiveChannel_List(ubpljnYfWcMIiEXsGveBhACDVFtKwm.main_params)
   if ubpljnYfWcMIiEXsGveBhACDVFtKUq==401:
    if os.path.isfile(ubpljnYfWcMIiEXsGveBhACDVFtKwU):os.remove(ubpljnYfWcMIiEXsGveBhACDVFtKwU)
    ubpljnYfWcMIiEXsGveBhACDVFtKwm.login_main()
    ubpljnYfWcMIiEXsGveBhACDVFtKwm.dp_EventLiveChannel_List(ubpljnYfWcMIiEXsGveBhACDVFtKwm.main_params)
  elif ubpljnYfWcMIiEXsGveBhACDVFtKmg in['LIVE','GAME_VOD','POP_VOD','NOW_VOD','ELIVE']:
   ubpljnYfWcMIiEXsGveBhACDVFtKwm.play_VIDEO(ubpljnYfWcMIiEXsGveBhACDVFtKwm.main_params)
  elif ubpljnYfWcMIiEXsGveBhACDVFtKmg=='VOD_GROUP':
   ubpljnYfWcMIiEXsGveBhACDVFtKwm.dp_MainLeague_List(ubpljnYfWcMIiEXsGveBhACDVFtKwm.main_params)
  elif ubpljnYfWcMIiEXsGveBhACDVFtKmg=='NOW_GROUP':
   ubpljnYfWcMIiEXsGveBhACDVFtKwm.dp_NowVod_GroupList(ubpljnYfWcMIiEXsGveBhACDVFtKwm.main_params)
  elif ubpljnYfWcMIiEXsGveBhACDVFtKmg=='POP_GROUP':
   ubpljnYfWcMIiEXsGveBhACDVFtKwm.dp_PopVod_GroupList(ubpljnYfWcMIiEXsGveBhACDVFtKwm.main_params)
  elif ubpljnYfWcMIiEXsGveBhACDVFtKmg=='LEAGUE_GROUP':
   ubpljnYfWcMIiEXsGveBhACDVFtKwm.dp_Season_List(ubpljnYfWcMIiEXsGveBhACDVFtKwm.main_params)
  elif ubpljnYfWcMIiEXsGveBhACDVFtKmg=='SEASON_GROUP':
   ubpljnYfWcMIiEXsGveBhACDVFtKwm.dp_Game_List(ubpljnYfWcMIiEXsGveBhACDVFtKwm.main_params)
  elif ubpljnYfWcMIiEXsGveBhACDVFtKmg=='GAME_VOD_GROUP':
   ubpljnYfWcMIiEXsGveBhACDVFtKwm.dp_GameVod_List(ubpljnYfWcMIiEXsGveBhACDVFtKwm.main_params)
  elif ubpljnYfWcMIiEXsGveBhACDVFtKmg=='WATCH':
   ubpljnYfWcMIiEXsGveBhACDVFtKwm.dp_Watch_List(ubpljnYfWcMIiEXsGveBhACDVFtKwm.main_params)
  elif ubpljnYfWcMIiEXsGveBhACDVFtKmg=='MYVIEW_REMOVE':
   ubpljnYfWcMIiEXsGveBhACDVFtKwm.dp_History_Remove(ubpljnYfWcMIiEXsGveBhACDVFtKwm.main_params)
  else:
   ubpljnYfWcMIiEXsGveBhACDVFtKmS
# Created by pyminifier (https://github.com/liftoff/pyminifier)
