__author__="NightRain"
gmLutJXqnKTWQYvwsaBkEbMDPoGzpf=object
gmLutJXqnKTWQYvwsaBkEbMDPoGzpC=None
gmLutJXqnKTWQYvwsaBkEbMDPoGzpe=False
gmLutJXqnKTWQYvwsaBkEbMDPoGzRA=True
gmLutJXqnKTWQYvwsaBkEbMDPoGzRd=getattr
gmLutJXqnKTWQYvwsaBkEbMDPoGzRN=type
gmLutJXqnKTWQYvwsaBkEbMDPoGzRV=int
gmLutJXqnKTWQYvwsaBkEbMDPoGzRp=list
gmLutJXqnKTWQYvwsaBkEbMDPoGzRH=len
gmLutJXqnKTWQYvwsaBkEbMDPoGzRj=str
gmLutJXqnKTWQYvwsaBkEbMDPoGzRl=id
gmLutJXqnKTWQYvwsaBkEbMDPoGzRI=open
gmLutJXqnKTWQYvwsaBkEbMDPoGzRx=dict
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
gmLutJXqnKTWQYvwsaBkEbMDPoGzAN=[{'title':'TV 채널 (유료사용자만 지원)','mode':'LIVE_GROUP','icon':'live.png'},{'title':'Live중계 (경기중에만 재생)','mode':'ELIVE_GROUP','icon':'live.png'},{'title':'-----------------','mode':'XXX'},{'title':'오늘의 추천 VOD','mode':'NOW_GROUP'},{'title':'인기영상 5','mode':'POP_GROUP'},{'title':'-----------------','mode':'XXX'},{'title':'VOD (리그, 경기별)','mode':'VOD_GROUP'},{'title':'Watched (시청목록)','mode':'WATCH','icon':'history.png'},]
gmLutJXqnKTWQYvwsaBkEbMDPoGzAV={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
gmLutJXqnKTWQYvwsaBkEbMDPoGzAp=xbmcvfs.translatePath(os.path.join(__profile__,'spotv_cookies.json'))
from spotvCore import*
class gmLutJXqnKTWQYvwsaBkEbMDPoGzAd(gmLutJXqnKTWQYvwsaBkEbMDPoGzpf):
 def __init__(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR,gmLutJXqnKTWQYvwsaBkEbMDPoGzAH,gmLutJXqnKTWQYvwsaBkEbMDPoGzAj,gmLutJXqnKTWQYvwsaBkEbMDPoGzAl):
  gmLutJXqnKTWQYvwsaBkEbMDPoGzAR._addon_url =gmLutJXqnKTWQYvwsaBkEbMDPoGzAH
  gmLutJXqnKTWQYvwsaBkEbMDPoGzAR._addon_handle=gmLutJXqnKTWQYvwsaBkEbMDPoGzAj
  gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.main_params =gmLutJXqnKTWQYvwsaBkEbMDPoGzAl
  gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.SpotvObj =SoYKDycdgmfjPhlMzkOewRBCbTHGJQ() 
 def addon_noti(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR,sting):
  try:
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAx=xbmcgui.Dialog()
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAx.notification(__addonname__,sting)
  except:
   gmLutJXqnKTWQYvwsaBkEbMDPoGzpC
 def addon_log(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR,string):
  try:
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAU=string.encode('utf-8','ignore')
  except:
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAU='addonException: addon_log'
  gmLutJXqnKTWQYvwsaBkEbMDPoGzAF=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,gmLutJXqnKTWQYvwsaBkEbMDPoGzAU),level=gmLutJXqnKTWQYvwsaBkEbMDPoGzAF)
 def get_keyboard_input(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR,gmLutJXqnKTWQYvwsaBkEbMDPoGzAy):
  gmLutJXqnKTWQYvwsaBkEbMDPoGzAS=gmLutJXqnKTWQYvwsaBkEbMDPoGzpC
  kb=xbmc.Keyboard()
  kb.setHeading(gmLutJXqnKTWQYvwsaBkEbMDPoGzAy)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAS=kb.getText()
  return gmLutJXqnKTWQYvwsaBkEbMDPoGzAS
 def get_settings_account(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR):
  gmLutJXqnKTWQYvwsaBkEbMDPoGzAr =__addon__.getSetting('id')
  gmLutJXqnKTWQYvwsaBkEbMDPoGzAO =__addon__.getSetting('pw')
  return(gmLutJXqnKTWQYvwsaBkEbMDPoGzAr,gmLutJXqnKTWQYvwsaBkEbMDPoGzAO)
 def get_settings_hidescoreyn(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR):
  gmLutJXqnKTWQYvwsaBkEbMDPoGzAc =__addon__.getSetting('hidescore')
  if gmLutJXqnKTWQYvwsaBkEbMDPoGzAc=='false':
   return gmLutJXqnKTWQYvwsaBkEbMDPoGzpe
  else:
   return gmLutJXqnKTWQYvwsaBkEbMDPoGzRA
 def add_dir(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR,label,sublabel='',img='',infoLabels=gmLutJXqnKTWQYvwsaBkEbMDPoGzpC,isFolder=gmLutJXqnKTWQYvwsaBkEbMDPoGzRA,params='',isLink=gmLutJXqnKTWQYvwsaBkEbMDPoGzpe,ContextMenu=gmLutJXqnKTWQYvwsaBkEbMDPoGzpC):
  gmLutJXqnKTWQYvwsaBkEbMDPoGzAh='%s?%s'%(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR._addon_url,urllib.parse.urlencode(params))
  if sublabel:gmLutJXqnKTWQYvwsaBkEbMDPoGzAy='%s < %s >'%(label,sublabel)
  else: gmLutJXqnKTWQYvwsaBkEbMDPoGzAy=label
  if not img:img='DefaultFolder.png'
  gmLutJXqnKTWQYvwsaBkEbMDPoGzAi=xbmcgui.ListItem(gmLutJXqnKTWQYvwsaBkEbMDPoGzAy)
  gmLutJXqnKTWQYvwsaBkEbMDPoGzAi.setArt({'thumb':img,'icon':img,'poster':img})
  if gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.SpotvObj.KodiVersion>=20:
   if infoLabels:gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.Set_InfoTag(gmLutJXqnKTWQYvwsaBkEbMDPoGzAi.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:gmLutJXqnKTWQYvwsaBkEbMDPoGzAi.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAi.setProperty('IsPlayable','true')
  if ContextMenu:gmLutJXqnKTWQYvwsaBkEbMDPoGzAi.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR._addon_handle,gmLutJXqnKTWQYvwsaBkEbMDPoGzAh,gmLutJXqnKTWQYvwsaBkEbMDPoGzAi,isFolder)
 def Set_InfoTag(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR,video_InfoTag:xbmc.InfoTagVideo,gmLutJXqnKTWQYvwsaBkEbMDPoGzdl):
  for gmLutJXqnKTWQYvwsaBkEbMDPoGzAf,value in gmLutJXqnKTWQYvwsaBkEbMDPoGzdl.items():
   if gmLutJXqnKTWQYvwsaBkEbMDPoGzAV[gmLutJXqnKTWQYvwsaBkEbMDPoGzAf]['type']=='string':
    gmLutJXqnKTWQYvwsaBkEbMDPoGzRd(video_InfoTag,gmLutJXqnKTWQYvwsaBkEbMDPoGzAV[gmLutJXqnKTWQYvwsaBkEbMDPoGzAf]['func'])(value)
   elif gmLutJXqnKTWQYvwsaBkEbMDPoGzAV[gmLutJXqnKTWQYvwsaBkEbMDPoGzAf]['type']=='int':
    if gmLutJXqnKTWQYvwsaBkEbMDPoGzRN(value)==gmLutJXqnKTWQYvwsaBkEbMDPoGzRV:
     gmLutJXqnKTWQYvwsaBkEbMDPoGzAC=gmLutJXqnKTWQYvwsaBkEbMDPoGzRV(value)
    else:
     gmLutJXqnKTWQYvwsaBkEbMDPoGzAC=0
    gmLutJXqnKTWQYvwsaBkEbMDPoGzRd(video_InfoTag,gmLutJXqnKTWQYvwsaBkEbMDPoGzAV[gmLutJXqnKTWQYvwsaBkEbMDPoGzAf]['func'])(gmLutJXqnKTWQYvwsaBkEbMDPoGzAC)
   elif gmLutJXqnKTWQYvwsaBkEbMDPoGzAV[gmLutJXqnKTWQYvwsaBkEbMDPoGzAf]['type']=='actor':
    if value!=[]:
     gmLutJXqnKTWQYvwsaBkEbMDPoGzRd(video_InfoTag,gmLutJXqnKTWQYvwsaBkEbMDPoGzAV[gmLutJXqnKTWQYvwsaBkEbMDPoGzAf]['func'])([xbmc.Actor(name)for name in value])
   elif gmLutJXqnKTWQYvwsaBkEbMDPoGzAV[gmLutJXqnKTWQYvwsaBkEbMDPoGzAf]['type']=='list':
    if gmLutJXqnKTWQYvwsaBkEbMDPoGzRN(value)==gmLutJXqnKTWQYvwsaBkEbMDPoGzRp:
     gmLutJXqnKTWQYvwsaBkEbMDPoGzRd(video_InfoTag,gmLutJXqnKTWQYvwsaBkEbMDPoGzAV[gmLutJXqnKTWQYvwsaBkEbMDPoGzAf]['func'])(value)
    else:
     gmLutJXqnKTWQYvwsaBkEbMDPoGzRd(video_InfoTag,gmLutJXqnKTWQYvwsaBkEbMDPoGzAV[gmLutJXqnKTWQYvwsaBkEbMDPoGzAf]['func'])([value])
 def get_selQuality(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR,etype):
  try:
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAe='selected_quality'
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdA=[1080,720,540]
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdN=gmLutJXqnKTWQYvwsaBkEbMDPoGzRV(__addon__.getSetting(gmLutJXqnKTWQYvwsaBkEbMDPoGzAe))
   return gmLutJXqnKTWQYvwsaBkEbMDPoGzdA[gmLutJXqnKTWQYvwsaBkEbMDPoGzdN]
  except:
   gmLutJXqnKTWQYvwsaBkEbMDPoGzpC
  return 1080 
 def dp_Main_List(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR):
  for gmLutJXqnKTWQYvwsaBkEbMDPoGzdV in gmLutJXqnKTWQYvwsaBkEbMDPoGzAN:
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAy=gmLutJXqnKTWQYvwsaBkEbMDPoGzdV.get('title')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdp=''
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdR={'mode':gmLutJXqnKTWQYvwsaBkEbMDPoGzdV.get('mode'),'page':'1'}
   if gmLutJXqnKTWQYvwsaBkEbMDPoGzdV.get('mode')=='XXX':
    gmLutJXqnKTWQYvwsaBkEbMDPoGzdH=gmLutJXqnKTWQYvwsaBkEbMDPoGzpe
    gmLutJXqnKTWQYvwsaBkEbMDPoGzdj =gmLutJXqnKTWQYvwsaBkEbMDPoGzRA
   else:
    gmLutJXqnKTWQYvwsaBkEbMDPoGzdH=gmLutJXqnKTWQYvwsaBkEbMDPoGzRA
    gmLutJXqnKTWQYvwsaBkEbMDPoGzdj =gmLutJXqnKTWQYvwsaBkEbMDPoGzpe
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdl={'title':gmLutJXqnKTWQYvwsaBkEbMDPoGzAy,'plot':gmLutJXqnKTWQYvwsaBkEbMDPoGzAy}
   if gmLutJXqnKTWQYvwsaBkEbMDPoGzdV.get('mode')=='XXX':gmLutJXqnKTWQYvwsaBkEbMDPoGzdl=gmLutJXqnKTWQYvwsaBkEbMDPoGzpC
   if 'icon' in gmLutJXqnKTWQYvwsaBkEbMDPoGzdV:gmLutJXqnKTWQYvwsaBkEbMDPoGzdp=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',gmLutJXqnKTWQYvwsaBkEbMDPoGzdV.get('icon')) 
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.add_dir(gmLutJXqnKTWQYvwsaBkEbMDPoGzAy,sublabel='',img=gmLutJXqnKTWQYvwsaBkEbMDPoGzdp,infoLabels=gmLutJXqnKTWQYvwsaBkEbMDPoGzdl,isFolder=gmLutJXqnKTWQYvwsaBkEbMDPoGzdH,params=gmLutJXqnKTWQYvwsaBkEbMDPoGzdR,isLink=gmLutJXqnKTWQYvwsaBkEbMDPoGzdj)
  if gmLutJXqnKTWQYvwsaBkEbMDPoGzRH(gmLutJXqnKTWQYvwsaBkEbMDPoGzAN)>0:xbmcplugin.endOfDirectory(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR._addon_handle)
 def dp_MainLeague_List(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR,args):
  gmLutJXqnKTWQYvwsaBkEbMDPoGzdx=gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.SpotvObj.GetTitleGroupList()
  for gmLutJXqnKTWQYvwsaBkEbMDPoGzdU in gmLutJXqnKTWQYvwsaBkEbMDPoGzdx:
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAy =gmLutJXqnKTWQYvwsaBkEbMDPoGzdU.get('title')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdF =gmLutJXqnKTWQYvwsaBkEbMDPoGzdU.get('logo')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdS =gmLutJXqnKTWQYvwsaBkEbMDPoGzdU.get('reagueId')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdr =gmLutJXqnKTWQYvwsaBkEbMDPoGzdU.get('subGame')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdO={'mediatype':'episode','plot':'%s\n\n%s'%(gmLutJXqnKTWQYvwsaBkEbMDPoGzAy,gmLutJXqnKTWQYvwsaBkEbMDPoGzdr)}
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdR={'mode':'LEAGUE_GROUP','reagueId':gmLutJXqnKTWQYvwsaBkEbMDPoGzdS}
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.add_dir(gmLutJXqnKTWQYvwsaBkEbMDPoGzAy,sublabel=gmLutJXqnKTWQYvwsaBkEbMDPoGzpC,img=gmLutJXqnKTWQYvwsaBkEbMDPoGzdF,infoLabels=gmLutJXqnKTWQYvwsaBkEbMDPoGzdO,isFolder=gmLutJXqnKTWQYvwsaBkEbMDPoGzRA,params=gmLutJXqnKTWQYvwsaBkEbMDPoGzdR)
  if gmLutJXqnKTWQYvwsaBkEbMDPoGzRH(gmLutJXqnKTWQYvwsaBkEbMDPoGzdx)>0:xbmcplugin.endOfDirectory(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR._addon_handle,cacheToDisc=gmLutJXqnKTWQYvwsaBkEbMDPoGzpe)
 def dp_NowVod_GroupList(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR,args):
  gmLutJXqnKTWQYvwsaBkEbMDPoGzdc=gmLutJXqnKTWQYvwsaBkEbMDPoGzRV(args.get('page'))
  gmLutJXqnKTWQYvwsaBkEbMDPoGzdx,gmLutJXqnKTWQYvwsaBkEbMDPoGzdh=gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.SpotvObj.Get_NowVod_GroupList(gmLutJXqnKTWQYvwsaBkEbMDPoGzdc)
  for gmLutJXqnKTWQYvwsaBkEbMDPoGzdU in gmLutJXqnKTWQYvwsaBkEbMDPoGzdx:
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdy =gmLutJXqnKTWQYvwsaBkEbMDPoGzdU.get('vodTitle')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdi =gmLutJXqnKTWQYvwsaBkEbMDPoGzdU.get('vodId')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdf =gmLutJXqnKTWQYvwsaBkEbMDPoGzdU.get('vodType')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdF=gmLutJXqnKTWQYvwsaBkEbMDPoGzdU.get('thumbnail')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdC =gmLutJXqnKTWQYvwsaBkEbMDPoGzdU.get('vtypeId')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzde =gmLutJXqnKTWQYvwsaBkEbMDPoGzdU.get('duration')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdO={'mediatype':'episode','duration':gmLutJXqnKTWQYvwsaBkEbMDPoGzde,'plot':gmLutJXqnKTWQYvwsaBkEbMDPoGzdy}
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdR={'mode':'NOW_VOD','mediacode':gmLutJXqnKTWQYvwsaBkEbMDPoGzdi,'mediatype':'vod','vtypeId':gmLutJXqnKTWQYvwsaBkEbMDPoGzdC}
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.add_dir(gmLutJXqnKTWQYvwsaBkEbMDPoGzdy,sublabel=gmLutJXqnKTWQYvwsaBkEbMDPoGzdf,img=gmLutJXqnKTWQYvwsaBkEbMDPoGzdF,infoLabels=gmLutJXqnKTWQYvwsaBkEbMDPoGzdO,isFolder=gmLutJXqnKTWQYvwsaBkEbMDPoGzpe,params=gmLutJXqnKTWQYvwsaBkEbMDPoGzdR)
  if gmLutJXqnKTWQYvwsaBkEbMDPoGzdh:
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdR['mode'] ='NOW_GROUP' 
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdR['page'] =gmLutJXqnKTWQYvwsaBkEbMDPoGzRj(gmLutJXqnKTWQYvwsaBkEbMDPoGzdc+1)
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAy='[B]%s >>[/B]'%'다음 페이지'
   gmLutJXqnKTWQYvwsaBkEbMDPoGzNA=gmLutJXqnKTWQYvwsaBkEbMDPoGzRj(gmLutJXqnKTWQYvwsaBkEbMDPoGzdc+1)
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdp=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.add_dir(gmLutJXqnKTWQYvwsaBkEbMDPoGzAy,sublabel=gmLutJXqnKTWQYvwsaBkEbMDPoGzNA,img=gmLutJXqnKTWQYvwsaBkEbMDPoGzdp,infoLabels=gmLutJXqnKTWQYvwsaBkEbMDPoGzpC,isFolder=gmLutJXqnKTWQYvwsaBkEbMDPoGzRA,params=gmLutJXqnKTWQYvwsaBkEbMDPoGzdR)
  xbmcplugin.setContent(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR._addon_handle,cacheToDisc=gmLutJXqnKTWQYvwsaBkEbMDPoGzpe)
 def dp_PopVod_GroupList(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR,args):
  gmLutJXqnKTWQYvwsaBkEbMDPoGzdx=gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.SpotvObj.GetPopularGroupList()
  for gmLutJXqnKTWQYvwsaBkEbMDPoGzdU in gmLutJXqnKTWQYvwsaBkEbMDPoGzdx:
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdy =gmLutJXqnKTWQYvwsaBkEbMDPoGzdU.get('vodTitle')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdi =gmLutJXqnKTWQYvwsaBkEbMDPoGzdU.get('vodId')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdf =gmLutJXqnKTWQYvwsaBkEbMDPoGzdU.get('vodType')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdF=gmLutJXqnKTWQYvwsaBkEbMDPoGzdU.get('thumbnail')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdC =gmLutJXqnKTWQYvwsaBkEbMDPoGzdU.get('vtypeId')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzde =gmLutJXqnKTWQYvwsaBkEbMDPoGzdU.get('duration')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdO={'mediatype':'episode','duration':gmLutJXqnKTWQYvwsaBkEbMDPoGzde,'plot':gmLutJXqnKTWQYvwsaBkEbMDPoGzdy}
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdR={'mode':'POP_VOD','mediacode':gmLutJXqnKTWQYvwsaBkEbMDPoGzdi,'mediatype':'vod','vtypeId':gmLutJXqnKTWQYvwsaBkEbMDPoGzdC}
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.add_dir(gmLutJXqnKTWQYvwsaBkEbMDPoGzdy,sublabel=gmLutJXqnKTWQYvwsaBkEbMDPoGzdf,img=gmLutJXqnKTWQYvwsaBkEbMDPoGzdF,infoLabels=gmLutJXqnKTWQYvwsaBkEbMDPoGzdO,isFolder=gmLutJXqnKTWQYvwsaBkEbMDPoGzpe,params=gmLutJXqnKTWQYvwsaBkEbMDPoGzdR)
  xbmcplugin.setContent(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR._addon_handle,cacheToDisc=gmLutJXqnKTWQYvwsaBkEbMDPoGzpe)
 def dp_Season_List(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR,args):
  gmLutJXqnKTWQYvwsaBkEbMDPoGzdS=args.get('reagueId')
  gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.addon_log('Season_List - reagueId : '+gmLutJXqnKTWQYvwsaBkEbMDPoGzdS)
  gmLutJXqnKTWQYvwsaBkEbMDPoGzdx=gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.SpotvObj.GetSeasonList(gmLutJXqnKTWQYvwsaBkEbMDPoGzdS)
  for gmLutJXqnKTWQYvwsaBkEbMDPoGzdU in gmLutJXqnKTWQYvwsaBkEbMDPoGzdx:
   gmLutJXqnKTWQYvwsaBkEbMDPoGzNV =gmLutJXqnKTWQYvwsaBkEbMDPoGzdU.get('reagueName')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzNp =gmLutJXqnKTWQYvwsaBkEbMDPoGzdU.get('gameTypeId')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzNR =gmLutJXqnKTWQYvwsaBkEbMDPoGzdU.get('seasonName')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzNH =gmLutJXqnKTWQYvwsaBkEbMDPoGzdU.get('seasonId')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdO={'mediatype':'episode','plot':'%s - %s'%(gmLutJXqnKTWQYvwsaBkEbMDPoGzNV,gmLutJXqnKTWQYvwsaBkEbMDPoGzNR)}
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdR={'mode':'SEASON_GROUP','reagueId':gmLutJXqnKTWQYvwsaBkEbMDPoGzdS,'seasonId':gmLutJXqnKTWQYvwsaBkEbMDPoGzNH,'gameTypeId':gmLutJXqnKTWQYvwsaBkEbMDPoGzNp,'page':'1'}
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.add_dir(gmLutJXqnKTWQYvwsaBkEbMDPoGzNV,sublabel=gmLutJXqnKTWQYvwsaBkEbMDPoGzNR,img='',infoLabels=gmLutJXqnKTWQYvwsaBkEbMDPoGzdO,isFolder=gmLutJXqnKTWQYvwsaBkEbMDPoGzRA,params=gmLutJXqnKTWQYvwsaBkEbMDPoGzdR)
  if gmLutJXqnKTWQYvwsaBkEbMDPoGzRH(gmLutJXqnKTWQYvwsaBkEbMDPoGzdx)>0:xbmcplugin.endOfDirectory(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR._addon_handle,cacheToDisc=gmLutJXqnKTWQYvwsaBkEbMDPoGzRA)
 def dp_Game_List(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR,args):
  gmLutJXqnKTWQYvwsaBkEbMDPoGzNp=args.get('gameTypeId')
  gmLutJXqnKTWQYvwsaBkEbMDPoGzdS =args.get('reagueId')
  gmLutJXqnKTWQYvwsaBkEbMDPoGzNH =args.get('seasonId')
  gmLutJXqnKTWQYvwsaBkEbMDPoGzdc =gmLutJXqnKTWQYvwsaBkEbMDPoGzRV(args.get('page'))
  gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.addon_log('Game_List - gameTypeId : '+gmLutJXqnKTWQYvwsaBkEbMDPoGzNp)
  gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.addon_log('Game_List - reagueId   : '+gmLutJXqnKTWQYvwsaBkEbMDPoGzdS)
  gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.addon_log('Game_List - seasonId   : '+gmLutJXqnKTWQYvwsaBkEbMDPoGzNH)
  gmLutJXqnKTWQYvwsaBkEbMDPoGzdx,gmLutJXqnKTWQYvwsaBkEbMDPoGzdh=gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.SpotvObj.GetGameList(gmLutJXqnKTWQYvwsaBkEbMDPoGzNp,gmLutJXqnKTWQYvwsaBkEbMDPoGzdS,gmLutJXqnKTWQYvwsaBkEbMDPoGzNH,gmLutJXqnKTWQYvwsaBkEbMDPoGzdc,hidescore=gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.get_settings_hidescoreyn())
  for gmLutJXqnKTWQYvwsaBkEbMDPoGzdU in gmLutJXqnKTWQYvwsaBkEbMDPoGzdx:
   gmLutJXqnKTWQYvwsaBkEbMDPoGzNj =gmLutJXqnKTWQYvwsaBkEbMDPoGzdU.get('gameTitle')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzNl =gmLutJXqnKTWQYvwsaBkEbMDPoGzdU.get('beginDate')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdF =gmLutJXqnKTWQYvwsaBkEbMDPoGzdU.get('thumbnail')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzNI =gmLutJXqnKTWQYvwsaBkEbMDPoGzdU.get('gameId')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzNx =gmLutJXqnKTWQYvwsaBkEbMDPoGzdU.get('totVodCnt')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzNU =gmLutJXqnKTWQYvwsaBkEbMDPoGzdU.get('leaguenm')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzNF =gmLutJXqnKTWQYvwsaBkEbMDPoGzdU.get('seasonnm')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzNS =gmLutJXqnKTWQYvwsaBkEbMDPoGzdU.get('roundnm')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzNr =gmLutJXqnKTWQYvwsaBkEbMDPoGzdU.get('info_plot')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzNO ='%s < %s >'%(gmLutJXqnKTWQYvwsaBkEbMDPoGzNj,gmLutJXqnKTWQYvwsaBkEbMDPoGzNl)
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdO={'mediatype':'video','plot':gmLutJXqnKTWQYvwsaBkEbMDPoGzNr}
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdR={'mode':'GAME_VOD_GROUP' if gmLutJXqnKTWQYvwsaBkEbMDPoGzNx!=0 else 'XXX','saveTitle':gmLutJXqnKTWQYvwsaBkEbMDPoGzNO,'saveImg':gmLutJXqnKTWQYvwsaBkEbMDPoGzdF,'saveInfo':gmLutJXqnKTWQYvwsaBkEbMDPoGzdO['plot'],'gameid':gmLutJXqnKTWQYvwsaBkEbMDPoGzNI,'totVodCnt':gmLutJXqnKTWQYvwsaBkEbMDPoGzNx,}
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.add_dir(gmLutJXqnKTWQYvwsaBkEbMDPoGzNj,sublabel=gmLutJXqnKTWQYvwsaBkEbMDPoGzNl,img=gmLutJXqnKTWQYvwsaBkEbMDPoGzdF,infoLabels=gmLutJXqnKTWQYvwsaBkEbMDPoGzdO,isFolder=gmLutJXqnKTWQYvwsaBkEbMDPoGzRA,params=gmLutJXqnKTWQYvwsaBkEbMDPoGzdR)
  if gmLutJXqnKTWQYvwsaBkEbMDPoGzdh:
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdR['mode'] ='SEASON_GROUP' 
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdR['reagueId'] =gmLutJXqnKTWQYvwsaBkEbMDPoGzdS
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdR['seasonId'] =gmLutJXqnKTWQYvwsaBkEbMDPoGzNH
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdR['gameTypeId']=gmLutJXqnKTWQYvwsaBkEbMDPoGzNp
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdR['page'] =gmLutJXqnKTWQYvwsaBkEbMDPoGzRj(gmLutJXqnKTWQYvwsaBkEbMDPoGzdc+1)
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAy='[B]%s >>[/B]'%'다음 페이지'
   gmLutJXqnKTWQYvwsaBkEbMDPoGzNA=gmLutJXqnKTWQYvwsaBkEbMDPoGzRj(gmLutJXqnKTWQYvwsaBkEbMDPoGzdc+1)
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdp=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.add_dir(gmLutJXqnKTWQYvwsaBkEbMDPoGzAy,sublabel=gmLutJXqnKTWQYvwsaBkEbMDPoGzNA,img=gmLutJXqnKTWQYvwsaBkEbMDPoGzdp,infoLabels=gmLutJXqnKTWQYvwsaBkEbMDPoGzpC,isFolder=gmLutJXqnKTWQYvwsaBkEbMDPoGzRA,params=gmLutJXqnKTWQYvwsaBkEbMDPoGzdR)
  if gmLutJXqnKTWQYvwsaBkEbMDPoGzRH(gmLutJXqnKTWQYvwsaBkEbMDPoGzdx)>0:xbmcplugin.endOfDirectory(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR._addon_handle,cacheToDisc=gmLutJXqnKTWQYvwsaBkEbMDPoGzpe)
 def dp_GameVod_List(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR,args):
  gmLutJXqnKTWQYvwsaBkEbMDPoGzNc =args.get('gameid')
  gmLutJXqnKTWQYvwsaBkEbMDPoGzNO=args.get('saveTitle')
  gmLutJXqnKTWQYvwsaBkEbMDPoGzNh =args.get('saveImg')
  gmLutJXqnKTWQYvwsaBkEbMDPoGzNy =args.get('saveInfo')
  gmLutJXqnKTWQYvwsaBkEbMDPoGzdx=gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.SpotvObj.GetGameVodList(gmLutJXqnKTWQYvwsaBkEbMDPoGzNc)
  for gmLutJXqnKTWQYvwsaBkEbMDPoGzdU in gmLutJXqnKTWQYvwsaBkEbMDPoGzdx:
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdy =gmLutJXqnKTWQYvwsaBkEbMDPoGzdU.get('vodTitle')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdi =gmLutJXqnKTWQYvwsaBkEbMDPoGzdU.get('vodId')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdf =gmLutJXqnKTWQYvwsaBkEbMDPoGzdU.get('vodType')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdF=gmLutJXqnKTWQYvwsaBkEbMDPoGzdU.get('thumbnail')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdC =gmLutJXqnKTWQYvwsaBkEbMDPoGzdU.get('vtypeId')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzde =gmLutJXqnKTWQYvwsaBkEbMDPoGzdU.get('duration')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdO={'mediatype':'episode','duration':gmLutJXqnKTWQYvwsaBkEbMDPoGzde,'plot':'%s \n\n %s'%(gmLutJXqnKTWQYvwsaBkEbMDPoGzdy,gmLutJXqnKTWQYvwsaBkEbMDPoGzNy)}
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdR={'mode':'GAME_VOD','saveTitle':gmLutJXqnKTWQYvwsaBkEbMDPoGzNO,'saveImg':gmLutJXqnKTWQYvwsaBkEbMDPoGzNh,'saveId':gmLutJXqnKTWQYvwsaBkEbMDPoGzNc,'saveInfo':gmLutJXqnKTWQYvwsaBkEbMDPoGzNy,'mediacode':gmLutJXqnKTWQYvwsaBkEbMDPoGzdi,'mediatype':'vod','vtypeId':gmLutJXqnKTWQYvwsaBkEbMDPoGzdC}
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.add_dir(gmLutJXqnKTWQYvwsaBkEbMDPoGzdy,sublabel=gmLutJXqnKTWQYvwsaBkEbMDPoGzdf,img=gmLutJXqnKTWQYvwsaBkEbMDPoGzdF,infoLabels=gmLutJXqnKTWQYvwsaBkEbMDPoGzdO,isFolder=gmLutJXqnKTWQYvwsaBkEbMDPoGzpe,params=gmLutJXqnKTWQYvwsaBkEbMDPoGzdR)
  xbmcplugin.setContent(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR._addon_handle,cacheToDisc=gmLutJXqnKTWQYvwsaBkEbMDPoGzpe)
 def login_main(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR):
  (gmLutJXqnKTWQYvwsaBkEbMDPoGzNi,gmLutJXqnKTWQYvwsaBkEbMDPoGzNf)=gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.get_settings_account()
  if not(gmLutJXqnKTWQYvwsaBkEbMDPoGzNi and gmLutJXqnKTWQYvwsaBkEbMDPoGzNf):
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAx=xbmcgui.Dialog()
   gmLutJXqnKTWQYvwsaBkEbMDPoGzNC=gmLutJXqnKTWQYvwsaBkEbMDPoGzAx.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if gmLutJXqnKTWQYvwsaBkEbMDPoGzNC==gmLutJXqnKTWQYvwsaBkEbMDPoGzRA:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.cookiefile_check():return
  if xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINWAIT')=='TRUE':
   gmLutJXqnKTWQYvwsaBkEbMDPoGzNe=0
   while gmLutJXqnKTWQYvwsaBkEbMDPoGzRA:
    gmLutJXqnKTWQYvwsaBkEbMDPoGzNe+=1
    time.sleep(0.05)
    if gmLutJXqnKTWQYvwsaBkEbMDPoGzNe>600:return
  else:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','TRUE')
  gmLutJXqnKTWQYvwsaBkEbMDPoGzVA=gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.SpotvObj.GetCredential_new(gmLutJXqnKTWQYvwsaBkEbMDPoGzNi,gmLutJXqnKTWQYvwsaBkEbMDPoGzNf)
  if gmLutJXqnKTWQYvwsaBkEbMDPoGzVA:gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.cookiefile_save()
  xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
  if gmLutJXqnKTWQYvwsaBkEbMDPoGzVA==gmLutJXqnKTWQYvwsaBkEbMDPoGzpe:
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_LiveChannel_List(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR,args):
  gmLutJXqnKTWQYvwsaBkEbMDPoGzVd=gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.SpotvObj.GetLiveChannelList()
  for gmLutJXqnKTWQYvwsaBkEbMDPoGzVN in gmLutJXqnKTWQYvwsaBkEbMDPoGzVd:
   gmLutJXqnKTWQYvwsaBkEbMDPoGzRl =gmLutJXqnKTWQYvwsaBkEbMDPoGzVN.get('id')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAy =gmLutJXqnKTWQYvwsaBkEbMDPoGzVN.get('name')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdI =gmLutJXqnKTWQYvwsaBkEbMDPoGzVN.get('programName')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdF =gmLutJXqnKTWQYvwsaBkEbMDPoGzVN.get('logo')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzVp=gmLutJXqnKTWQYvwsaBkEbMDPoGzVN.get('channelepg')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzVR =gmLutJXqnKTWQYvwsaBkEbMDPoGzVN.get('free')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdO={'plot':'%s\n\n%s'%(gmLutJXqnKTWQYvwsaBkEbMDPoGzAy,gmLutJXqnKTWQYvwsaBkEbMDPoGzVp),'mediatype':'episode',}
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdR={'mode':'LIVE','mediacode':gmLutJXqnKTWQYvwsaBkEbMDPoGzRl,'free':gmLutJXqnKTWQYvwsaBkEbMDPoGzVR,'mediatype':'live'}
   if gmLutJXqnKTWQYvwsaBkEbMDPoGzVR:gmLutJXqnKTWQYvwsaBkEbMDPoGzAy+=' [free]'
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.add_dir(gmLutJXqnKTWQYvwsaBkEbMDPoGzAy,sublabel=gmLutJXqnKTWQYvwsaBkEbMDPoGzdI,img=gmLutJXqnKTWQYvwsaBkEbMDPoGzdF,infoLabels=gmLutJXqnKTWQYvwsaBkEbMDPoGzdO,isFolder=gmLutJXqnKTWQYvwsaBkEbMDPoGzpe,params=gmLutJXqnKTWQYvwsaBkEbMDPoGzdR)
  xbmcplugin.setContent(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR._addon_handle,'episodes')
  if gmLutJXqnKTWQYvwsaBkEbMDPoGzRH(gmLutJXqnKTWQYvwsaBkEbMDPoGzVd)>0:xbmcplugin.endOfDirectory(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR._addon_handle,cacheToDisc=gmLutJXqnKTWQYvwsaBkEbMDPoGzpe)
 def dp_EventLiveChannel_List(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR,args):
  gmLutJXqnKTWQYvwsaBkEbMDPoGzVd,gmLutJXqnKTWQYvwsaBkEbMDPoGzVH=gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.SpotvObj.GetEventLiveList()
  if gmLutJXqnKTWQYvwsaBkEbMDPoGzVH!=401 and gmLutJXqnKTWQYvwsaBkEbMDPoGzRH(gmLutJXqnKTWQYvwsaBkEbMDPoGzVd)==0:
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.addon_noti(__language__(30907).encode('utf8'))
  for gmLutJXqnKTWQYvwsaBkEbMDPoGzVN in gmLutJXqnKTWQYvwsaBkEbMDPoGzVd:
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAy =gmLutJXqnKTWQYvwsaBkEbMDPoGzVN.get('title')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdI =gmLutJXqnKTWQYvwsaBkEbMDPoGzVN.get('startTime')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdF =gmLutJXqnKTWQYvwsaBkEbMDPoGzVN.get('logo')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzVR =gmLutJXqnKTWQYvwsaBkEbMDPoGzVN.get('free')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdO={'mediatype':'episode','plot':'%s\n\n%s'%(gmLutJXqnKTWQYvwsaBkEbMDPoGzAy,gmLutJXqnKTWQYvwsaBkEbMDPoGzdI)}
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdR={'mode':'ELIVE','mediacode':gmLutJXqnKTWQYvwsaBkEbMDPoGzVN.get('liveId'),'free':gmLutJXqnKTWQYvwsaBkEbMDPoGzVR,'mediatype':'live'}
   if gmLutJXqnKTWQYvwsaBkEbMDPoGzVR:gmLutJXqnKTWQYvwsaBkEbMDPoGzAy+=' [free]'
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.add_dir(gmLutJXqnKTWQYvwsaBkEbMDPoGzAy,sublabel=gmLutJXqnKTWQYvwsaBkEbMDPoGzdI,img=gmLutJXqnKTWQYvwsaBkEbMDPoGzdF,infoLabels=gmLutJXqnKTWQYvwsaBkEbMDPoGzdO,isFolder=gmLutJXqnKTWQYvwsaBkEbMDPoGzpe,params=gmLutJXqnKTWQYvwsaBkEbMDPoGzdR)
  xbmcplugin.setContent(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR._addon_handle,'episodes')
  if gmLutJXqnKTWQYvwsaBkEbMDPoGzRH(gmLutJXqnKTWQYvwsaBkEbMDPoGzVd)>0:xbmcplugin.endOfDirectory(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR._addon_handle,cacheToDisc=gmLutJXqnKTWQYvwsaBkEbMDPoGzRA)
  return gmLutJXqnKTWQYvwsaBkEbMDPoGzVH
 def play_VIDEO(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR,args):
  gmLutJXqnKTWQYvwsaBkEbMDPoGzVj =args.get('mode')
  gmLutJXqnKTWQYvwsaBkEbMDPoGzVl =args.get('mediacode')
  gmLutJXqnKTWQYvwsaBkEbMDPoGzVI =args.get('mediatype')
  gmLutJXqnKTWQYvwsaBkEbMDPoGzdC =args.get('vtypeId')
  gmLutJXqnKTWQYvwsaBkEbMDPoGzVx =args.get('hlsUrl')
  if gmLutJXqnKTWQYvwsaBkEbMDPoGzVj=='LIVE':
   if args.get('free')=='False':
    if gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.SpotvObj.CheckSubEnd()==gmLutJXqnKTWQYvwsaBkEbMDPoGzpe:
     gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.addon_noti(__language__(30908).encode('utf8'))
     return
  elif gmLutJXqnKTWQYvwsaBkEbMDPoGzVj=='ELIVE':
   if args.get('free')=='False':
    if gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.SpotvObj.CheckSubEnd()==gmLutJXqnKTWQYvwsaBkEbMDPoGzpe:
     gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.addon_noti(__language__(30908).encode('utf8'))
     return
  if gmLutJXqnKTWQYvwsaBkEbMDPoGzVl=='' or gmLutJXqnKTWQYvwsaBkEbMDPoGzVl==gmLutJXqnKTWQYvwsaBkEbMDPoGzpC:
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.addon_noti(__language__(30907).encode('utf8'))
   return
  if gmLutJXqnKTWQYvwsaBkEbMDPoGzVj=='LIVE':
   gmLutJXqnKTWQYvwsaBkEbMDPoGzVU=gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.SpotvObj.GetHlsUrl(gmLutJXqnKTWQYvwsaBkEbMDPoGzVl)
  else:
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.addon_log('mediacode : '+gmLutJXqnKTWQYvwsaBkEbMDPoGzVl)
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.addon_log('mediatype : '+gmLutJXqnKTWQYvwsaBkEbMDPoGzVI)
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.addon_log('vtypeId   : '+gmLutJXqnKTWQYvwsaBkEbMDPoGzRj(gmLutJXqnKTWQYvwsaBkEbMDPoGzdC))
   gmLutJXqnKTWQYvwsaBkEbMDPoGzVU=gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.SpotvObj.GetBroadURL(gmLutJXqnKTWQYvwsaBkEbMDPoGzVl,gmLutJXqnKTWQYvwsaBkEbMDPoGzVI,gmLutJXqnKTWQYvwsaBkEbMDPoGzdC)
  if gmLutJXqnKTWQYvwsaBkEbMDPoGzVU=='':
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.addon_noti(__language__(30908).encode('utf8'))
   return
  gmLutJXqnKTWQYvwsaBkEbMDPoGzVF=gmLutJXqnKTWQYvwsaBkEbMDPoGzVU
  try:
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.addon_log('mainMode  = '+gmLutJXqnKTWQYvwsaBkEbMDPoGzVj)
  except:
   gmLutJXqnKTWQYvwsaBkEbMDPoGzpC
  gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.addon_log(gmLutJXqnKTWQYvwsaBkEbMDPoGzVF)
  gmLutJXqnKTWQYvwsaBkEbMDPoGzVS=xbmcgui.ListItem(path=gmLutJXqnKTWQYvwsaBkEbMDPoGzVF)
  xbmcplugin.setResolvedUrl(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR._addon_handle,gmLutJXqnKTWQYvwsaBkEbMDPoGzRA,gmLutJXqnKTWQYvwsaBkEbMDPoGzVS)
  try:
   if gmLutJXqnKTWQYvwsaBkEbMDPoGzVI=='vod' and gmLutJXqnKTWQYvwsaBkEbMDPoGzVj not in['POP_VOD','NOW_VOD']:
    gmLutJXqnKTWQYvwsaBkEbMDPoGzdR={'code':args.get('saveId'),'img':args.get('saveImg'),'title':args.get('saveTitle'),'info':args.get('saveInfo')}
    gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.Save_Watched_List(gmLutJXqnKTWQYvwsaBkEbMDPoGzVI,gmLutJXqnKTWQYvwsaBkEbMDPoGzdR)
  except:
   gmLutJXqnKTWQYvwsaBkEbMDPoGzpC
 def logout(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR):
  gmLutJXqnKTWQYvwsaBkEbMDPoGzAx=xbmcgui.Dialog()
  gmLutJXqnKTWQYvwsaBkEbMDPoGzNC=gmLutJXqnKTWQYvwsaBkEbMDPoGzAx.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if gmLutJXqnKTWQYvwsaBkEbMDPoGzNC==gmLutJXqnKTWQYvwsaBkEbMDPoGzpe:sys.exit()
  gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.SpotvObj.Init_ST_Total()
  if os.path.isfile(gmLutJXqnKTWQYvwsaBkEbMDPoGzAp):os.remove(gmLutJXqnKTWQYvwsaBkEbMDPoGzAp)
  gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR):
  gmLutJXqnKTWQYvwsaBkEbMDPoGzVr =gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.SpotvObj.Get_Now_Datetime()
  gmLutJXqnKTWQYvwsaBkEbMDPoGzVO=gmLutJXqnKTWQYvwsaBkEbMDPoGzVr+datetime.timedelta(days=gmLutJXqnKTWQYvwsaBkEbMDPoGzRV(__addon__.getSetting('cache_ttl')))
  (gmLutJXqnKTWQYvwsaBkEbMDPoGzNi,gmLutJXqnKTWQYvwsaBkEbMDPoGzNf)=gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.get_settings_account()
  gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.SpotvObj.Save_session_acount(gmLutJXqnKTWQYvwsaBkEbMDPoGzNi,gmLutJXqnKTWQYvwsaBkEbMDPoGzNf)
  gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.SpotvObj.ST['account']['token_limit']=gmLutJXqnKTWQYvwsaBkEbMDPoGzVO.strftime('%Y%m%d')
  gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.SpotvObj.JsonFile_Save(gmLutJXqnKTWQYvwsaBkEbMDPoGzAp,gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.SpotvObj.ST)
 def cookiefile_check(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR):
  gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.SpotvObj.ST=gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.SpotvObj.JsonFile_Load(gmLutJXqnKTWQYvwsaBkEbMDPoGzAp)
  if 'account' not in gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.SpotvObj.ST:
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.SpotvObj.Init_ST_Total()
   return gmLutJXqnKTWQYvwsaBkEbMDPoGzpe
  (gmLutJXqnKTWQYvwsaBkEbMDPoGzVc,gmLutJXqnKTWQYvwsaBkEbMDPoGzVh)=gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.get_settings_account()
  (gmLutJXqnKTWQYvwsaBkEbMDPoGzVy,gmLutJXqnKTWQYvwsaBkEbMDPoGzVi)=gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.SpotvObj.Load_session_acount()
  if gmLutJXqnKTWQYvwsaBkEbMDPoGzVc!=gmLutJXqnKTWQYvwsaBkEbMDPoGzVy or gmLutJXqnKTWQYvwsaBkEbMDPoGzVh!=gmLutJXqnKTWQYvwsaBkEbMDPoGzVi:
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.SpotvObj.Init_ST_Total()
   return gmLutJXqnKTWQYvwsaBkEbMDPoGzpe
  if gmLutJXqnKTWQYvwsaBkEbMDPoGzRV(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))>gmLutJXqnKTWQYvwsaBkEbMDPoGzRV(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.SpotvObj.ST['account']['token_limit']):
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.SpotvObj.Init_ST_Total()
   return gmLutJXqnKTWQYvwsaBkEbMDPoGzpe
  return gmLutJXqnKTWQYvwsaBkEbMDPoGzRA
 def dp_History_Remove(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR,args):
  gmLutJXqnKTWQYvwsaBkEbMDPoGzVf=args.get('delType')
  gmLutJXqnKTWQYvwsaBkEbMDPoGzVC =args.get('sKey')
  gmLutJXqnKTWQYvwsaBkEbMDPoGzVe =args.get('vType')
  gmLutJXqnKTWQYvwsaBkEbMDPoGzAx=xbmcgui.Dialog()
  if gmLutJXqnKTWQYvwsaBkEbMDPoGzVf=='WATCH_ALL':
   gmLutJXqnKTWQYvwsaBkEbMDPoGzNC=gmLutJXqnKTWQYvwsaBkEbMDPoGzAx.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif gmLutJXqnKTWQYvwsaBkEbMDPoGzVf=='WATCH_ONE':
   gmLutJXqnKTWQYvwsaBkEbMDPoGzNC=gmLutJXqnKTWQYvwsaBkEbMDPoGzAx.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  if gmLutJXqnKTWQYvwsaBkEbMDPoGzNC==gmLutJXqnKTWQYvwsaBkEbMDPoGzpe:sys.exit()
  if gmLutJXqnKTWQYvwsaBkEbMDPoGzVf=='WATCH_ALL':
   gmLutJXqnKTWQYvwsaBkEbMDPoGzpA=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%gmLutJXqnKTWQYvwsaBkEbMDPoGzVe))
   if os.path.isfile(gmLutJXqnKTWQYvwsaBkEbMDPoGzpA):os.remove(gmLutJXqnKTWQYvwsaBkEbMDPoGzpA)
  elif gmLutJXqnKTWQYvwsaBkEbMDPoGzVf=='WATCH_ONE':
   gmLutJXqnKTWQYvwsaBkEbMDPoGzpA=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%gmLutJXqnKTWQYvwsaBkEbMDPoGzVe))
   try:
    gmLutJXqnKTWQYvwsaBkEbMDPoGzpd=gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.Load_List_File(gmLutJXqnKTWQYvwsaBkEbMDPoGzVe) 
    fp=gmLutJXqnKTWQYvwsaBkEbMDPoGzRI(gmLutJXqnKTWQYvwsaBkEbMDPoGzpA,'w',-1,'utf-8')
    for gmLutJXqnKTWQYvwsaBkEbMDPoGzpN in gmLutJXqnKTWQYvwsaBkEbMDPoGzpd:
     gmLutJXqnKTWQYvwsaBkEbMDPoGzpV=gmLutJXqnKTWQYvwsaBkEbMDPoGzRx(urllib.parse.parse_qsl(gmLutJXqnKTWQYvwsaBkEbMDPoGzpN))
     gmLutJXqnKTWQYvwsaBkEbMDPoGzpR=gmLutJXqnKTWQYvwsaBkEbMDPoGzpV.get('code').strip()
     if gmLutJXqnKTWQYvwsaBkEbMDPoGzVC!=gmLutJXqnKTWQYvwsaBkEbMDPoGzpR:
      fp.write(gmLutJXqnKTWQYvwsaBkEbMDPoGzpN)
    fp.close()
   except:
    gmLutJXqnKTWQYvwsaBkEbMDPoGzpC
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR,gmLutJXqnKTWQYvwsaBkEbMDPoGzVI):
  try:
   gmLutJXqnKTWQYvwsaBkEbMDPoGzpH=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%gmLutJXqnKTWQYvwsaBkEbMDPoGzVI))
   fp=gmLutJXqnKTWQYvwsaBkEbMDPoGzRI(gmLutJXqnKTWQYvwsaBkEbMDPoGzpH,'r',-1,'utf-8')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzpj=fp.readlines()
   fp.close()
  except:
   gmLutJXqnKTWQYvwsaBkEbMDPoGzpj=[]
  return gmLutJXqnKTWQYvwsaBkEbMDPoGzpj
 def Save_Watched_List(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR,stype,gmLutJXqnKTWQYvwsaBkEbMDPoGzAl):
  try:
   gmLutJXqnKTWQYvwsaBkEbMDPoGzpH=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   gmLutJXqnKTWQYvwsaBkEbMDPoGzpd=gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.Load_List_File(stype) 
   fp=gmLutJXqnKTWQYvwsaBkEbMDPoGzRI(gmLutJXqnKTWQYvwsaBkEbMDPoGzpH,'w',-1,'utf-8')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzpl=urllib.parse.urlencode(gmLutJXqnKTWQYvwsaBkEbMDPoGzAl)
   gmLutJXqnKTWQYvwsaBkEbMDPoGzpl=gmLutJXqnKTWQYvwsaBkEbMDPoGzpl+'\n'
   fp.write(gmLutJXqnKTWQYvwsaBkEbMDPoGzpl)
   gmLutJXqnKTWQYvwsaBkEbMDPoGzpI=0
   for gmLutJXqnKTWQYvwsaBkEbMDPoGzpN in gmLutJXqnKTWQYvwsaBkEbMDPoGzpd:
    gmLutJXqnKTWQYvwsaBkEbMDPoGzpV=gmLutJXqnKTWQYvwsaBkEbMDPoGzRx(urllib.parse.parse_qsl(gmLutJXqnKTWQYvwsaBkEbMDPoGzpN))
    gmLutJXqnKTWQYvwsaBkEbMDPoGzpx=gmLutJXqnKTWQYvwsaBkEbMDPoGzAl.get('code')
    gmLutJXqnKTWQYvwsaBkEbMDPoGzpU=gmLutJXqnKTWQYvwsaBkEbMDPoGzpV.get('code')
    if gmLutJXqnKTWQYvwsaBkEbMDPoGzpx!=gmLutJXqnKTWQYvwsaBkEbMDPoGzpU:
     fp.write(gmLutJXqnKTWQYvwsaBkEbMDPoGzpN)
     gmLutJXqnKTWQYvwsaBkEbMDPoGzpI+=1
     if gmLutJXqnKTWQYvwsaBkEbMDPoGzpI>=50:break
   fp.close()
  except:
   gmLutJXqnKTWQYvwsaBkEbMDPoGzpC
 def dp_Watch_List(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR,args):
  gmLutJXqnKTWQYvwsaBkEbMDPoGzVI ='vod'
  if gmLutJXqnKTWQYvwsaBkEbMDPoGzVI=='vod':
   gmLutJXqnKTWQYvwsaBkEbMDPoGzpF=gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.Load_List_File(gmLutJXqnKTWQYvwsaBkEbMDPoGzVI)
   for gmLutJXqnKTWQYvwsaBkEbMDPoGzpS in gmLutJXqnKTWQYvwsaBkEbMDPoGzpF:
    gmLutJXqnKTWQYvwsaBkEbMDPoGzpr=gmLutJXqnKTWQYvwsaBkEbMDPoGzRx(urllib.parse.parse_qsl(gmLutJXqnKTWQYvwsaBkEbMDPoGzpS))
    gmLutJXqnKTWQYvwsaBkEbMDPoGzAy =gmLutJXqnKTWQYvwsaBkEbMDPoGzpr.get('title')
    gmLutJXqnKTWQYvwsaBkEbMDPoGzdF=gmLutJXqnKTWQYvwsaBkEbMDPoGzpr.get('img')
    gmLutJXqnKTWQYvwsaBkEbMDPoGzVl=gmLutJXqnKTWQYvwsaBkEbMDPoGzpr.get('code')
    gmLutJXqnKTWQYvwsaBkEbMDPoGzpO =gmLutJXqnKTWQYvwsaBkEbMDPoGzpr.get('info')
    gmLutJXqnKTWQYvwsaBkEbMDPoGzdO={}
    gmLutJXqnKTWQYvwsaBkEbMDPoGzdO['plot'] =gmLutJXqnKTWQYvwsaBkEbMDPoGzpO
    gmLutJXqnKTWQYvwsaBkEbMDPoGzdO['mediatype']='tvshow'
    gmLutJXqnKTWQYvwsaBkEbMDPoGzdR={'mode':'GAME_VOD_GROUP','gameid':gmLutJXqnKTWQYvwsaBkEbMDPoGzVl,'saveTitle':gmLutJXqnKTWQYvwsaBkEbMDPoGzAy,'saveImg':gmLutJXqnKTWQYvwsaBkEbMDPoGzdF,'saveInfo':gmLutJXqnKTWQYvwsaBkEbMDPoGzpO,'mediatype':gmLutJXqnKTWQYvwsaBkEbMDPoGzVI}
    gmLutJXqnKTWQYvwsaBkEbMDPoGzpc={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':gmLutJXqnKTWQYvwsaBkEbMDPoGzVl,'vType':gmLutJXqnKTWQYvwsaBkEbMDPoGzVI,}
    gmLutJXqnKTWQYvwsaBkEbMDPoGzph=urllib.parse.urlencode(gmLutJXqnKTWQYvwsaBkEbMDPoGzpc)
    gmLutJXqnKTWQYvwsaBkEbMDPoGzpy=[('선택된 시청이력 ( %s ) 삭제'%(gmLutJXqnKTWQYvwsaBkEbMDPoGzAy),'RunPlugin(plugin://plugin.video.spotvm/?%s)'%(gmLutJXqnKTWQYvwsaBkEbMDPoGzph))]
    gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.add_dir(gmLutJXqnKTWQYvwsaBkEbMDPoGzAy,sublabel='',img=gmLutJXqnKTWQYvwsaBkEbMDPoGzdF,infoLabels=gmLutJXqnKTWQYvwsaBkEbMDPoGzdO,isFolder=gmLutJXqnKTWQYvwsaBkEbMDPoGzRA,params=gmLutJXqnKTWQYvwsaBkEbMDPoGzdR,ContextMenu=gmLutJXqnKTWQYvwsaBkEbMDPoGzpy)
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdO={'plot':'시청목록을 삭제합니다.'}
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAy='*** 시청목록 삭제 ***'
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdR={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':gmLutJXqnKTWQYvwsaBkEbMDPoGzVI,}
   gmLutJXqnKTWQYvwsaBkEbMDPoGzdp=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.add_dir(gmLutJXqnKTWQYvwsaBkEbMDPoGzAy,sublabel='',img=gmLutJXqnKTWQYvwsaBkEbMDPoGzdp,infoLabels=gmLutJXqnKTWQYvwsaBkEbMDPoGzdO,isFolder=gmLutJXqnKTWQYvwsaBkEbMDPoGzpe,params=gmLutJXqnKTWQYvwsaBkEbMDPoGzdR,isLink=gmLutJXqnKTWQYvwsaBkEbMDPoGzRA)
   xbmcplugin.endOfDirectory(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR._addon_handle,cacheToDisc=gmLutJXqnKTWQYvwsaBkEbMDPoGzpe)
 def spotv_main(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR):
  gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.SpotvObj.KodiVersion=gmLutJXqnKTWQYvwsaBkEbMDPoGzRV(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  gmLutJXqnKTWQYvwsaBkEbMDPoGzpi=gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.main_params.get('mode',gmLutJXqnKTWQYvwsaBkEbMDPoGzpC)
  if gmLutJXqnKTWQYvwsaBkEbMDPoGzpi=='LOGOUT':
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.logout()
   return
  gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.login_main()
  if gmLutJXqnKTWQYvwsaBkEbMDPoGzpi is gmLutJXqnKTWQYvwsaBkEbMDPoGzpC:
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.dp_Main_List()
  elif gmLutJXqnKTWQYvwsaBkEbMDPoGzpi=='LIVE_GROUP':
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.dp_LiveChannel_List(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.main_params)
  elif gmLutJXqnKTWQYvwsaBkEbMDPoGzpi=='ELIVE_GROUP':
   gmLutJXqnKTWQYvwsaBkEbMDPoGzVH=gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.dp_EventLiveChannel_List(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.main_params)
   if gmLutJXqnKTWQYvwsaBkEbMDPoGzVH==401:
    if os.path.isfile(gmLutJXqnKTWQYvwsaBkEbMDPoGzAp):os.remove(gmLutJXqnKTWQYvwsaBkEbMDPoGzAp)
    gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.login_main()
    gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.dp_EventLiveChannel_List(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.main_params)
  elif gmLutJXqnKTWQYvwsaBkEbMDPoGzpi in['LIVE','GAME_VOD','POP_VOD','NOW_VOD','ELIVE']:
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.play_VIDEO(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.main_params)
  elif gmLutJXqnKTWQYvwsaBkEbMDPoGzpi=='VOD_GROUP':
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.dp_MainLeague_List(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.main_params)
  elif gmLutJXqnKTWQYvwsaBkEbMDPoGzpi=='NOW_GROUP':
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.dp_NowVod_GroupList(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.main_params)
  elif gmLutJXqnKTWQYvwsaBkEbMDPoGzpi=='POP_GROUP':
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.dp_PopVod_GroupList(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.main_params)
  elif gmLutJXqnKTWQYvwsaBkEbMDPoGzpi=='LEAGUE_GROUP':
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.dp_Season_List(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.main_params)
  elif gmLutJXqnKTWQYvwsaBkEbMDPoGzpi=='SEASON_GROUP':
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.dp_Game_List(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.main_params)
  elif gmLutJXqnKTWQYvwsaBkEbMDPoGzpi=='GAME_VOD_GROUP':
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.dp_GameVod_List(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.main_params)
  elif gmLutJXqnKTWQYvwsaBkEbMDPoGzpi=='WATCH':
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.dp_Watch_List(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.main_params)
  elif gmLutJXqnKTWQYvwsaBkEbMDPoGzpi=='MYVIEW_REMOVE':
   gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.dp_History_Remove(gmLutJXqnKTWQYvwsaBkEbMDPoGzAR.main_params)
  else:
   gmLutJXqnKTWQYvwsaBkEbMDPoGzpC
# Created by pyminifier (https://github.com/liftoff/pyminifier)
