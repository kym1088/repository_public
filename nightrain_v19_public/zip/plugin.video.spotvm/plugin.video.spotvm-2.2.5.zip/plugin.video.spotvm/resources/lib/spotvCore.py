__author__="NightRain"
SoYKDycdgmfjPhlMzkOewRBCbTHGiX=object
SoYKDycdgmfjPhlMzkOewRBCbTHGiL=None
SoYKDycdgmfjPhlMzkOewRBCbTHGiW=False
SoYKDycdgmfjPhlMzkOewRBCbTHGiv=open
SoYKDycdgmfjPhlMzkOewRBCbTHGiU=True
SoYKDycdgmfjPhlMzkOewRBCbTHGiE=int
SoYKDycdgmfjPhlMzkOewRBCbTHGiu=Exception
SoYKDycdgmfjPhlMzkOewRBCbTHGir=print
SoYKDycdgmfjPhlMzkOewRBCbTHGiF=str
SoYKDycdgmfjPhlMzkOewRBCbTHGiN=len
SoYKDycdgmfjPhlMzkOewRBCbTHGix=range
import urllib
import re
import json
import sys
import time
import requests
import datetime
import base64
import random
SoYKDycdgmfjPhlMzkOewRBCbTHGJI={'stream50':1080,'stream40':720,'stream30':540}
class SoYKDycdgmfjPhlMzkOewRBCbTHGJQ(SoYKDycdgmfjPhlMzkOewRBCbTHGiX):
 def __init__(SoYKDycdgmfjPhlMzkOewRBCbTHGJn):
  SoYKDycdgmfjPhlMzkOewRBCbTHGJn.SPOTV_PMCODE ='987'
  SoYKDycdgmfjPhlMzkOewRBCbTHGJn.SPOTV_PMSIZE =3
  SoYKDycdgmfjPhlMzkOewRBCbTHGJn.GAMELIST_LIMIT =10
  SoYKDycdgmfjPhlMzkOewRBCbTHGJn.API_DOMAIN ='https://www.spotvnow.co.kr'
  SoYKDycdgmfjPhlMzkOewRBCbTHGJn.BC_DOMAIN ='https://players.brightcove.net'
  SoYKDycdgmfjPhlMzkOewRBCbTHGJn.PLAYER_DOMAIN ='https://edge.api.brightcove.com'
  SoYKDycdgmfjPhlMzkOewRBCbTHGJn.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36'
  SoYKDycdgmfjPhlMzkOewRBCbTHGJn.DEFAULT_HEADER ={'user-agent':SoYKDycdgmfjPhlMzkOewRBCbTHGJn.USER_AGENT}
  SoYKDycdgmfjPhlMzkOewRBCbTHGJn.COOKIE_FILE_NAME=''
  SoYKDycdgmfjPhlMzkOewRBCbTHGJn.KodiVersion =20
  SoYKDycdgmfjPhlMzkOewRBCbTHGJn.ST ={}
  SoYKDycdgmfjPhlMzkOewRBCbTHGJn.Init_ST_Total()
 def Init_ST_Total(SoYKDycdgmfjPhlMzkOewRBCbTHGJn):
  SoYKDycdgmfjPhlMzkOewRBCbTHGJn.ST={'account':{},'cookies':{},}
 def callRequestCookies(SoYKDycdgmfjPhlMzkOewRBCbTHGJn,jobtype,SoYKDycdgmfjPhlMzkOewRBCbTHGJv,payload=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,json=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,params=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,headers=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,cookies=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,redirects=SoYKDycdgmfjPhlMzkOewRBCbTHGiW):
  SoYKDycdgmfjPhlMzkOewRBCbTHGJi=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.DEFAULT_HEADER
  if headers:SoYKDycdgmfjPhlMzkOewRBCbTHGJi.update(headers)
  if jobtype=='Get':
   SoYKDycdgmfjPhlMzkOewRBCbTHGJA=requests.get(SoYKDycdgmfjPhlMzkOewRBCbTHGJv,params=params,headers=SoYKDycdgmfjPhlMzkOewRBCbTHGJi,cookies=cookies,allow_redirects=redirects)
  else:
   SoYKDycdgmfjPhlMzkOewRBCbTHGJA=requests.post(SoYKDycdgmfjPhlMzkOewRBCbTHGJv,data=payload,json=json,params=params,headers=SoYKDycdgmfjPhlMzkOewRBCbTHGJi,cookies=cookies,allow_redirects=redirects)
  return SoYKDycdgmfjPhlMzkOewRBCbTHGJA
 def JsonFile_Save(SoYKDycdgmfjPhlMzkOewRBCbTHGJn,filename,SoYKDycdgmfjPhlMzkOewRBCbTHGJV):
  if filename=='':return SoYKDycdgmfjPhlMzkOewRBCbTHGiW
  try:
   fp=SoYKDycdgmfjPhlMzkOewRBCbTHGiv(filename,'w',-1,'utf-8')
   json.dump(SoYKDycdgmfjPhlMzkOewRBCbTHGJV,fp,indent=4,ensure_ascii=SoYKDycdgmfjPhlMzkOewRBCbTHGiW)
   fp.close()
  except:
   return SoYKDycdgmfjPhlMzkOewRBCbTHGiW
  return SoYKDycdgmfjPhlMzkOewRBCbTHGiU
 def JsonFile_Load(SoYKDycdgmfjPhlMzkOewRBCbTHGJn,filename):
  if filename=='':return{}
  try:
   fp=SoYKDycdgmfjPhlMzkOewRBCbTHGiv(filename,'r',-1,'utf-8')
   SoYKDycdgmfjPhlMzkOewRBCbTHGJp=json.load(fp)
   fp.close()
  except:
   return{}
  return SoYKDycdgmfjPhlMzkOewRBCbTHGJp
 def Save_session_acount(SoYKDycdgmfjPhlMzkOewRBCbTHGJn,SoYKDycdgmfjPhlMzkOewRBCbTHGJs,SoYKDycdgmfjPhlMzkOewRBCbTHGJa):
  SoYKDycdgmfjPhlMzkOewRBCbTHGJn.ST['account']['stid'] =base64.standard_b64encode(SoYKDycdgmfjPhlMzkOewRBCbTHGJs.encode()).decode('utf-8')
  SoYKDycdgmfjPhlMzkOewRBCbTHGJn.ST['account']['stpw'] =base64.standard_b64encode(SoYKDycdgmfjPhlMzkOewRBCbTHGJa.encode()).decode('utf-8')
 def Load_session_acount(SoYKDycdgmfjPhlMzkOewRBCbTHGJn):
  try:
   SoYKDycdgmfjPhlMzkOewRBCbTHGJs =base64.standard_b64decode(SoYKDycdgmfjPhlMzkOewRBCbTHGJn.ST['account']['stid']).decode('utf-8')
   SoYKDycdgmfjPhlMzkOewRBCbTHGJa =base64.standard_b64decode(SoYKDycdgmfjPhlMzkOewRBCbTHGJn.ST['account']['stpw']).decode('utf-8')
  except:
   return '',''
  return SoYKDycdgmfjPhlMzkOewRBCbTHGJs,SoYKDycdgmfjPhlMzkOewRBCbTHGJa
 def makeDefaultCookies(SoYKDycdgmfjPhlMzkOewRBCbTHGJn):
  SoYKDycdgmfjPhlMzkOewRBCbTHGJq={'id_token':SoYKDycdgmfjPhlMzkOewRBCbTHGJn.ST['cookies']['id_token']}
  return SoYKDycdgmfjPhlMzkOewRBCbTHGJq
 def makeDefaultHeaders(SoYKDycdgmfjPhlMzkOewRBCbTHGJn):
  SoYKDycdgmfjPhlMzkOewRBCbTHGJX={'accept':'application/json;pk={}'.format(SoYKDycdgmfjPhlMzkOewRBCbTHGJn.ST['cookies']['spotv_policyKey'])}
  return SoYKDycdgmfjPhlMzkOewRBCbTHGJX
 def xmlText(SoYKDycdgmfjPhlMzkOewRBCbTHGJn,in_text):
  SoYKDycdgmfjPhlMzkOewRBCbTHGJL=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;')
  return SoYKDycdgmfjPhlMzkOewRBCbTHGJL
 def GetNoCache(SoYKDycdgmfjPhlMzkOewRBCbTHGJn,timetype=1):
  if timetype==1:
   return SoYKDycdgmfjPhlMzkOewRBCbTHGiE(time.time())
  else:
   return SoYKDycdgmfjPhlMzkOewRBCbTHGiE(time.time()*1000)
 def GetCredential_new(SoYKDycdgmfjPhlMzkOewRBCbTHGJn,user_id,user_pw):
  SoYKDycdgmfjPhlMzkOewRBCbTHGJW=requests.session()
  try:
   SoYKDycdgmfjPhlMzkOewRBCbTHGJv='https://nid.spotvnow.co.kr/api/v3/oauth2/authorize/spotvnow?return_url=https%3A%2F%2Fwww.spotvnow.co.kr%2Fcheck&err_return_url=https%3A%2F%2Fwww.spotvnow.co.kr%2Fabout&logout_url=https%3A%2F%2Fwww.spotvnow.co.kr%2Fintro'
   SoYKDycdgmfjPhlMzkOewRBCbTHGJX={'User-Agent':SoYKDycdgmfjPhlMzkOewRBCbTHGJn.USER_AGENT,}
   while(SoYKDycdgmfjPhlMzkOewRBCbTHGJv not in['',SoYKDycdgmfjPhlMzkOewRBCbTHGiL]):
    SoYKDycdgmfjPhlMzkOewRBCbTHGJU=SoYKDycdgmfjPhlMzkOewRBCbTHGJW.get(SoYKDycdgmfjPhlMzkOewRBCbTHGJv,params=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,headers=SoYKDycdgmfjPhlMzkOewRBCbTHGJX,cookies=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.ST['cookies'],allow_redirects=SoYKDycdgmfjPhlMzkOewRBCbTHGiW)
    SoYKDycdgmfjPhlMzkOewRBCbTHGJv =SoYKDycdgmfjPhlMzkOewRBCbTHGJU.headers.get('location')
    for SoYKDycdgmfjPhlMzkOewRBCbTHGJE in SoYKDycdgmfjPhlMzkOewRBCbTHGJU.cookies:
     if SoYKDycdgmfjPhlMzkOewRBCbTHGJE.value not in['',SoYKDycdgmfjPhlMzkOewRBCbTHGiL]:
      SoYKDycdgmfjPhlMzkOewRBCbTHGJn.ST['cookies'][SoYKDycdgmfjPhlMzkOewRBCbTHGJE.name]=SoYKDycdgmfjPhlMzkOewRBCbTHGJE.value
    if SoYKDycdgmfjPhlMzkOewRBCbTHGJU.status_code==200:break
   if SoYKDycdgmfjPhlMzkOewRBCbTHGJn.ST['cookies']['login_challenge']=='':
    SoYKDycdgmfjPhlMzkOewRBCbTHGJn.Init_ST_Total()
    return SoYKDycdgmfjPhlMzkOewRBCbTHGiW
  except SoYKDycdgmfjPhlMzkOewRBCbTHGiu as exception:
   SoYKDycdgmfjPhlMzkOewRBCbTHGir(exception)
   SoYKDycdgmfjPhlMzkOewRBCbTHGJn.Init_ST_Total()
   return SoYKDycdgmfjPhlMzkOewRBCbTHGiW
  try:
   SoYKDycdgmfjPhlMzkOewRBCbTHGJu=base64.standard_b64encode(user_id.encode('UTF-8')).decode('utf-8')
   SoYKDycdgmfjPhlMzkOewRBCbTHGJr=base64.standard_b64encode(user_pw.encode('UTF-8')).decode('utf-8')
   SoYKDycdgmfjPhlMzkOewRBCbTHGJv='https://nid.spotvnow.co.kr/api/v3/user-auth/login'
   SoYKDycdgmfjPhlMzkOewRBCbTHGJX={'User-Agent':SoYKDycdgmfjPhlMzkOewRBCbTHGJn.USER_AGENT,}
   SoYKDycdgmfjPhlMzkOewRBCbTHGJF={'username':SoYKDycdgmfjPhlMzkOewRBCbTHGJu,'password':SoYKDycdgmfjPhlMzkOewRBCbTHGJr,'remember':SoYKDycdgmfjPhlMzkOewRBCbTHGiU,'err_return_url':'https://www.spotvnow.co.kr/intro',}
   SoYKDycdgmfjPhlMzkOewRBCbTHGJU=SoYKDycdgmfjPhlMzkOewRBCbTHGJW.post(SoYKDycdgmfjPhlMzkOewRBCbTHGJv,data=SoYKDycdgmfjPhlMzkOewRBCbTHGJF,params=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,headers=SoYKDycdgmfjPhlMzkOewRBCbTHGJX,cookies=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.ST['cookies'],allow_redirects=SoYKDycdgmfjPhlMzkOewRBCbTHGiW)
   for SoYKDycdgmfjPhlMzkOewRBCbTHGJE in SoYKDycdgmfjPhlMzkOewRBCbTHGJU.cookies:
    if SoYKDycdgmfjPhlMzkOewRBCbTHGJE.value not in['',SoYKDycdgmfjPhlMzkOewRBCbTHGiL]:
     SoYKDycdgmfjPhlMzkOewRBCbTHGJn.ST['cookies'][SoYKDycdgmfjPhlMzkOewRBCbTHGJE.name]=SoYKDycdgmfjPhlMzkOewRBCbTHGJE.value
   SoYKDycdgmfjPhlMzkOewRBCbTHGJv=SoYKDycdgmfjPhlMzkOewRBCbTHGJU.headers.get('location')
   while(SoYKDycdgmfjPhlMzkOewRBCbTHGJv not in['',SoYKDycdgmfjPhlMzkOewRBCbTHGiL]):
    SoYKDycdgmfjPhlMzkOewRBCbTHGJX={'user-agent':SoYKDycdgmfjPhlMzkOewRBCbTHGJn.USER_AGENT,}
    SoYKDycdgmfjPhlMzkOewRBCbTHGJU=SoYKDycdgmfjPhlMzkOewRBCbTHGJW.get(SoYKDycdgmfjPhlMzkOewRBCbTHGJv,params=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,headers=SoYKDycdgmfjPhlMzkOewRBCbTHGJX,cookies=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.ST['cookies'],allow_redirects=SoYKDycdgmfjPhlMzkOewRBCbTHGiW)
    SoYKDycdgmfjPhlMzkOewRBCbTHGJv =SoYKDycdgmfjPhlMzkOewRBCbTHGJU.headers.get('location')
    for SoYKDycdgmfjPhlMzkOewRBCbTHGJE in SoYKDycdgmfjPhlMzkOewRBCbTHGJU.cookies:
     if SoYKDycdgmfjPhlMzkOewRBCbTHGJE.value not in['',SoYKDycdgmfjPhlMzkOewRBCbTHGiL]:
      SoYKDycdgmfjPhlMzkOewRBCbTHGJn.ST['cookies'][SoYKDycdgmfjPhlMzkOewRBCbTHGJE.name]=SoYKDycdgmfjPhlMzkOewRBCbTHGJE.value
    if SoYKDycdgmfjPhlMzkOewRBCbTHGJU.status_code==200:break
   if SoYKDycdgmfjPhlMzkOewRBCbTHGJn.ST['cookies']['id_token']=='':
    SoYKDycdgmfjPhlMzkOewRBCbTHGJn.Init_ST_Total()
    return SoYKDycdgmfjPhlMzkOewRBCbTHGiW
  except SoYKDycdgmfjPhlMzkOewRBCbTHGiu as exception:
   SoYKDycdgmfjPhlMzkOewRBCbTHGir(exception)
   SoYKDycdgmfjPhlMzkOewRBCbTHGJn.Init_ST_Total()
   return SoYKDycdgmfjPhlMzkOewRBCbTHGiW
  try:
   SoYKDycdgmfjPhlMzkOewRBCbTHGJv=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.API_DOMAIN+'/api/v3/session' 
   SoYKDycdgmfjPhlMzkOewRBCbTHGJq=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.makeDefaultCookies()
   SoYKDycdgmfjPhlMzkOewRBCbTHGJU=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.callRequestCookies('Get',SoYKDycdgmfjPhlMzkOewRBCbTHGJv,params=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,headers=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,cookies=SoYKDycdgmfjPhlMzkOewRBCbTHGJq)
   SoYKDycdgmfjPhlMzkOewRBCbTHGJN=json.loads(SoYKDycdgmfjPhlMzkOewRBCbTHGJU.text)
   SoYKDycdgmfjPhlMzkOewRBCbTHGJn.ST['cookies']['spotv_sessionid']=SoYKDycdgmfjPhlMzkOewRBCbTHGJN.get('userId')
   SoYKDycdgmfjPhlMzkOewRBCbTHGJx=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.SPOTV_PMCODE+SoYKDycdgmfjPhlMzkOewRBCbTHGiF(SoYKDycdgmfjPhlMzkOewRBCbTHGJN['subEndTime'])
   SoYKDycdgmfjPhlMzkOewRBCbTHGJn.ST['cookies']['spotv_subend'] =base64.standard_b64encode(SoYKDycdgmfjPhlMzkOewRBCbTHGJx.encode()).decode('utf-8')
  except SoYKDycdgmfjPhlMzkOewRBCbTHGiu as exception:
   SoYKDycdgmfjPhlMzkOewRBCbTHGir(exception)
   SoYKDycdgmfjPhlMzkOewRBCbTHGJn.Init_ST_Total()
   return SoYKDycdgmfjPhlMzkOewRBCbTHGiW
  if SoYKDycdgmfjPhlMzkOewRBCbTHGJn.GetPolicyKey()==SoYKDycdgmfjPhlMzkOewRBCbTHGiW:
   SoYKDycdgmfjPhlMzkOewRBCbTHGJn.Init_ST_Total()
   return SoYKDycdgmfjPhlMzkOewRBCbTHGiW
  '''
  https://players.brightcove.net/5764318566001/2SXVGLGl4_default/index.min.js
    options: {accountId: "5764318566001", policyKey: "BCpkADawqM072_NUcqm8RBVoMGIaio2x979NvYhN4Zrs685jLKKYmCx_ssySm_0HFSnwPKQIbaekH1PnWGFk-nQCtuky-DlMgN4KNvNlPYjsojAi1fU9ozEXVSpULPylDb8STvOgPf-F941V-RbByAkzD8CgApyhBS8TNN-yDc17gnFUj82OEBP8DEo" }  
  '''  
  return SoYKDycdgmfjPhlMzkOewRBCbTHGiU
 def GetCredential(SoYKDycdgmfjPhlMzkOewRBCbTHGJn,user_id,user_pw):
  try:
   SoYKDycdgmfjPhlMzkOewRBCbTHGJu=base64.standard_b64encode(user_id.encode('UTF-8')).decode('utf-8')
   SoYKDycdgmfjPhlMzkOewRBCbTHGJr=base64.standard_b64encode(user_pw.encode('UTF-8')).decode('utf-8')
   SoYKDycdgmfjPhlMzkOewRBCbTHGQJ=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.API_DOMAIN+'/api/v2/login'
   SoYKDycdgmfjPhlMzkOewRBCbTHGJF={'username':SoYKDycdgmfjPhlMzkOewRBCbTHGJu,'password':SoYKDycdgmfjPhlMzkOewRBCbTHGJr}
   SoYKDycdgmfjPhlMzkOewRBCbTHGJF=json.dumps(SoYKDycdgmfjPhlMzkOewRBCbTHGJF)
   SoYKDycdgmfjPhlMzkOewRBCbTHGJU=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.callRequestCookies('Post',SoYKDycdgmfjPhlMzkOewRBCbTHGQJ,payload=SoYKDycdgmfjPhlMzkOewRBCbTHGJF,params=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,headers=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,cookies=SoYKDycdgmfjPhlMzkOewRBCbTHGiL)
   SoYKDycdgmfjPhlMzkOewRBCbTHGQI=json.loads(SoYKDycdgmfjPhlMzkOewRBCbTHGJU.text)
   for SoYKDycdgmfjPhlMzkOewRBCbTHGJE in SoYKDycdgmfjPhlMzkOewRBCbTHGJU.cookies:
    if SoYKDycdgmfjPhlMzkOewRBCbTHGJE.name=='SESSION':
     SoYKDycdgmfjPhlMzkOewRBCbTHGJn.ST['cookies']['spotv_session']=SoYKDycdgmfjPhlMzkOewRBCbTHGJE.value
     break
   if SoYKDycdgmfjPhlMzkOewRBCbTHGJn.ST['cookies']['spotv_session']=='':
    SoYKDycdgmfjPhlMzkOewRBCbTHGJn.Init_ST_Total()
    return SoYKDycdgmfjPhlMzkOewRBCbTHGiW
   SoYKDycdgmfjPhlMzkOewRBCbTHGJn.ST['cookies']['spotv_sessionid']=SoYKDycdgmfjPhlMzkOewRBCbTHGiF(SoYKDycdgmfjPhlMzkOewRBCbTHGQI['userId'])
   SoYKDycdgmfjPhlMzkOewRBCbTHGJx=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.SPOTV_PMCODE+SoYKDycdgmfjPhlMzkOewRBCbTHGiF(SoYKDycdgmfjPhlMzkOewRBCbTHGQI['subEndTime'])
   SoYKDycdgmfjPhlMzkOewRBCbTHGJn.ST['cookies']['spotv_subend'] =base64.standard_b64encode(SoYKDycdgmfjPhlMzkOewRBCbTHGJx.encode()).decode('utf-8')
   if SoYKDycdgmfjPhlMzkOewRBCbTHGJn.GetPolicyKey()==SoYKDycdgmfjPhlMzkOewRBCbTHGiW:
    SoYKDycdgmfjPhlMzkOewRBCbTHGJn.Init_ST_Total()
    return SoYKDycdgmfjPhlMzkOewRBCbTHGiW
  except SoYKDycdgmfjPhlMzkOewRBCbTHGiu as exception:
   SoYKDycdgmfjPhlMzkOewRBCbTHGir(exception)
   SoYKDycdgmfjPhlMzkOewRBCbTHGJn.Init_ST_Total()
   return SoYKDycdgmfjPhlMzkOewRBCbTHGiW
  return SoYKDycdgmfjPhlMzkOewRBCbTHGiU
 def GetPolicyKey(SoYKDycdgmfjPhlMzkOewRBCbTHGJn):
  try:
   SoYKDycdgmfjPhlMzkOewRBCbTHGJv=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.GetBcPlayerUrl()
   if SoYKDycdgmfjPhlMzkOewRBCbTHGJv=='':return SoYKDycdgmfjPhlMzkOewRBCbTHGiW
   SoYKDycdgmfjPhlMzkOewRBCbTHGJU=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.callRequestCookies('Get',SoYKDycdgmfjPhlMzkOewRBCbTHGJv,payload=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,params=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,headers=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,cookies=SoYKDycdgmfjPhlMzkOewRBCbTHGiL)
   SoYKDycdgmfjPhlMzkOewRBCbTHGQn=SoYKDycdgmfjPhlMzkOewRBCbTHGJU.text
   SoYKDycdgmfjPhlMzkOewRBCbTHGQi =re.findall('accountId:\s*\"\d{13}\",\s*policyKey:\s*\".[^(){}]{100,300}\"',SoYKDycdgmfjPhlMzkOewRBCbTHGQn)[0]
   SoYKDycdgmfjPhlMzkOewRBCbTHGQi =SoYKDycdgmfjPhlMzkOewRBCbTHGQi.replace('accountId','"accountId"')
   SoYKDycdgmfjPhlMzkOewRBCbTHGQi =SoYKDycdgmfjPhlMzkOewRBCbTHGQi.replace('policyKey','"policyKey"')
   SoYKDycdgmfjPhlMzkOewRBCbTHGQi ='{'+SoYKDycdgmfjPhlMzkOewRBCbTHGQi+'}'
   SoYKDycdgmfjPhlMzkOewRBCbTHGQA=json.loads(SoYKDycdgmfjPhlMzkOewRBCbTHGQi)
   SoYKDycdgmfjPhlMzkOewRBCbTHGJn.ST['cookies']['spotv_accountId']=SoYKDycdgmfjPhlMzkOewRBCbTHGQA['accountId']
   SoYKDycdgmfjPhlMzkOewRBCbTHGJn.ST['cookies']['spotv_policyKey']=SoYKDycdgmfjPhlMzkOewRBCbTHGQA['policyKey']
  except SoYKDycdgmfjPhlMzkOewRBCbTHGiu as exception:
   SoYKDycdgmfjPhlMzkOewRBCbTHGir(exception)
   return SoYKDycdgmfjPhlMzkOewRBCbTHGiW
  return SoYKDycdgmfjPhlMzkOewRBCbTHGiU
 def GetBcPlayerUrl(SoYKDycdgmfjPhlMzkOewRBCbTHGJn):
  SoYKDycdgmfjPhlMzkOewRBCbTHGQV=''
  try:
   SoYKDycdgmfjPhlMzkOewRBCbTHGJv=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.GetMainJspath()
   if SoYKDycdgmfjPhlMzkOewRBCbTHGJv=='':return SoYKDycdgmfjPhlMzkOewRBCbTHGQV
   SoYKDycdgmfjPhlMzkOewRBCbTHGJU=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.callRequestCookies('Get',SoYKDycdgmfjPhlMzkOewRBCbTHGJv,payload=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,params=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,headers=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,cookies=SoYKDycdgmfjPhlMzkOewRBCbTHGiL)
   SoYKDycdgmfjPhlMzkOewRBCbTHGQn=SoYKDycdgmfjPhlMzkOewRBCbTHGJU.text
   SoYKDycdgmfjPhlMzkOewRBCbTHGQt =r'default:{(.*?)}'
   SoYKDycdgmfjPhlMzkOewRBCbTHGQp =re.compile(SoYKDycdgmfjPhlMzkOewRBCbTHGQt).findall(SoYKDycdgmfjPhlMzkOewRBCbTHGQn)[0]
   SoYKDycdgmfjPhlMzkOewRBCbTHGQs=r'bc:"(.*?)"'
   SoYKDycdgmfjPhlMzkOewRBCbTHGQa=re.compile(SoYKDycdgmfjPhlMzkOewRBCbTHGQs).findall(SoYKDycdgmfjPhlMzkOewRBCbTHGQp)[0]
   SoYKDycdgmfjPhlMzkOewRBCbTHGQq=r'":"(.*?)"'
   SoYKDycdgmfjPhlMzkOewRBCbTHGQX=re.compile(SoYKDycdgmfjPhlMzkOewRBCbTHGQq).findall(SoYKDycdgmfjPhlMzkOewRBCbTHGQp)[0]
   SoYKDycdgmfjPhlMzkOewRBCbTHGQV="%s/%s/%s_default/index.min.js"%(SoYKDycdgmfjPhlMzkOewRBCbTHGJn.BC_DOMAIN,SoYKDycdgmfjPhlMzkOewRBCbTHGQa,SoYKDycdgmfjPhlMzkOewRBCbTHGQX)
  except SoYKDycdgmfjPhlMzkOewRBCbTHGiu as exception:
   SoYKDycdgmfjPhlMzkOewRBCbTHGir(exception)
  return SoYKDycdgmfjPhlMzkOewRBCbTHGQV
 def GetMainJspath(SoYKDycdgmfjPhlMzkOewRBCbTHGJn):
  SoYKDycdgmfjPhlMzkOewRBCbTHGQL=''
  try:
   SoYKDycdgmfjPhlMzkOewRBCbTHGJv=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.API_DOMAIN
   SoYKDycdgmfjPhlMzkOewRBCbTHGJU=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.callRequestCookies('Get',SoYKDycdgmfjPhlMzkOewRBCbTHGJv,payload=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,params=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,headers=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,cookies=SoYKDycdgmfjPhlMzkOewRBCbTHGiL)
   SoYKDycdgmfjPhlMzkOewRBCbTHGQn=SoYKDycdgmfjPhlMzkOewRBCbTHGJU.text
   SoYKDycdgmfjPhlMzkOewRBCbTHGQi =re.findall('https://cdn.spotvnow.co.kr/dist/js/.{20}\.js',SoYKDycdgmfjPhlMzkOewRBCbTHGQn)[0]
   SoYKDycdgmfjPhlMzkOewRBCbTHGQL=SoYKDycdgmfjPhlMzkOewRBCbTHGQi
  except SoYKDycdgmfjPhlMzkOewRBCbTHGiu as exception:
   SoYKDycdgmfjPhlMzkOewRBCbTHGir(exception)
  return SoYKDycdgmfjPhlMzkOewRBCbTHGQL
 def Get_Now_Datetime(SoYKDycdgmfjPhlMzkOewRBCbTHGJn):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetLiveChannelList(SoYKDycdgmfjPhlMzkOewRBCbTHGJn):
  SoYKDycdgmfjPhlMzkOewRBCbTHGQv=[]
  SoYKDycdgmfjPhlMzkOewRBCbTHGQU ={}
  try:
   SoYKDycdgmfjPhlMzkOewRBCbTHGJv=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.API_DOMAIN+'/api/v3/channel'
   SoYKDycdgmfjPhlMzkOewRBCbTHGJU=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.callRequestCookies('Get',SoYKDycdgmfjPhlMzkOewRBCbTHGJv,payload=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,params=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,headers=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,cookies=SoYKDycdgmfjPhlMzkOewRBCbTHGiL)
   SoYKDycdgmfjPhlMzkOewRBCbTHGQI=json.loads(SoYKDycdgmfjPhlMzkOewRBCbTHGJU.text)
   SoYKDycdgmfjPhlMzkOewRBCbTHGQU=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.GetEPGList()
   for SoYKDycdgmfjPhlMzkOewRBCbTHGQE in SoYKDycdgmfjPhlMzkOewRBCbTHGQI:
    SoYKDycdgmfjPhlMzkOewRBCbTHGQu={'id':SoYKDycdgmfjPhlMzkOewRBCbTHGQE['id'],'name':SoYKDycdgmfjPhlMzkOewRBCbTHGQE['name'],'logo':SoYKDycdgmfjPhlMzkOewRBCbTHGQE['logo'],'free':SoYKDycdgmfjPhlMzkOewRBCbTHGQE['free'],'programName':SoYKDycdgmfjPhlMzkOewRBCbTHGQE['programName'],'channelepg':SoYKDycdgmfjPhlMzkOewRBCbTHGQU.get(SoYKDycdgmfjPhlMzkOewRBCbTHGQE['id']),}
    SoYKDycdgmfjPhlMzkOewRBCbTHGQv.append(SoYKDycdgmfjPhlMzkOewRBCbTHGQu)
  except SoYKDycdgmfjPhlMzkOewRBCbTHGiu as exception:
   SoYKDycdgmfjPhlMzkOewRBCbTHGir(exception)
  return SoYKDycdgmfjPhlMzkOewRBCbTHGQv
 def GetHlsUrl(SoYKDycdgmfjPhlMzkOewRBCbTHGJn,mediacode):
  SoYKDycdgmfjPhlMzkOewRBCbTHGQr=''
  try:
   SoYKDycdgmfjPhlMzkOewRBCbTHGJv=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.API_DOMAIN+'/api/v3/channel/'+mediacode
   SoYKDycdgmfjPhlMzkOewRBCbTHGJU=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.callRequestCookies('Get',SoYKDycdgmfjPhlMzkOewRBCbTHGJv,payload=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,params=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,headers=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,cookies=SoYKDycdgmfjPhlMzkOewRBCbTHGiL)
   SoYKDycdgmfjPhlMzkOewRBCbTHGQI=json.loads(SoYKDycdgmfjPhlMzkOewRBCbTHGJU.text)
   SoYKDycdgmfjPhlMzkOewRBCbTHGQr=SoYKDycdgmfjPhlMzkOewRBCbTHGQI['hlsUrl']
  except SoYKDycdgmfjPhlMzkOewRBCbTHGiu as exception:
   SoYKDycdgmfjPhlMzkOewRBCbTHGir(exception)
  return SoYKDycdgmfjPhlMzkOewRBCbTHGQr
 def GetEPGList(SoYKDycdgmfjPhlMzkOewRBCbTHGJn):
  SoYKDycdgmfjPhlMzkOewRBCbTHGQF={}
  SoYKDycdgmfjPhlMzkOewRBCbTHGQN=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.Get_Now_Datetime()
  SoYKDycdgmfjPhlMzkOewRBCbTHGQx=SoYKDycdgmfjPhlMzkOewRBCbTHGQN.strftime('%Y%m%d%H%M')
  SoYKDycdgmfjPhlMzkOewRBCbTHGIJ='%s-%s-%s'%(SoYKDycdgmfjPhlMzkOewRBCbTHGQx[0:4],SoYKDycdgmfjPhlMzkOewRBCbTHGQx[4:6],SoYKDycdgmfjPhlMzkOewRBCbTHGQx[6:8])
  SoYKDycdgmfjPhlMzkOewRBCbTHGIQ=(SoYKDycdgmfjPhlMzkOewRBCbTHGQN+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M')
  try:
   SoYKDycdgmfjPhlMzkOewRBCbTHGJv=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.API_DOMAIN+'/api/v3/program/'+SoYKDycdgmfjPhlMzkOewRBCbTHGIJ
   SoYKDycdgmfjPhlMzkOewRBCbTHGJU=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.callRequestCookies('Get',SoYKDycdgmfjPhlMzkOewRBCbTHGJv,payload=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,params=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,headers=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,cookies=SoYKDycdgmfjPhlMzkOewRBCbTHGiL)
   SoYKDycdgmfjPhlMzkOewRBCbTHGQI=json.loads(SoYKDycdgmfjPhlMzkOewRBCbTHGJU.text)
   SoYKDycdgmfjPhlMzkOewRBCbTHGIn=-1 
   SoYKDycdgmfjPhlMzkOewRBCbTHGIi =''
   for SoYKDycdgmfjPhlMzkOewRBCbTHGQE in SoYKDycdgmfjPhlMzkOewRBCbTHGQI:
    SoYKDycdgmfjPhlMzkOewRBCbTHGIA=SoYKDycdgmfjPhlMzkOewRBCbTHGQE['channelId']
    SoYKDycdgmfjPhlMzkOewRBCbTHGIV =SoYKDycdgmfjPhlMzkOewRBCbTHGQE['startTime'].replace('-','').replace(' ','').replace(':','')
    SoYKDycdgmfjPhlMzkOewRBCbTHGIt =SoYKDycdgmfjPhlMzkOewRBCbTHGQE['endTime'].replace('-','').replace(' ','').replace(':','')
    if SoYKDycdgmfjPhlMzkOewRBCbTHGiE(SoYKDycdgmfjPhlMzkOewRBCbTHGQx)>SoYKDycdgmfjPhlMzkOewRBCbTHGiE(SoYKDycdgmfjPhlMzkOewRBCbTHGIt) :continue
    if SoYKDycdgmfjPhlMzkOewRBCbTHGiE(SoYKDycdgmfjPhlMzkOewRBCbTHGIQ)<SoYKDycdgmfjPhlMzkOewRBCbTHGiE(SoYKDycdgmfjPhlMzkOewRBCbTHGIV):continue
    if SoYKDycdgmfjPhlMzkOewRBCbTHGIn!=SoYKDycdgmfjPhlMzkOewRBCbTHGIA:
     if SoYKDycdgmfjPhlMzkOewRBCbTHGIi!='':SoYKDycdgmfjPhlMzkOewRBCbTHGQF[SoYKDycdgmfjPhlMzkOewRBCbTHGIn]=SoYKDycdgmfjPhlMzkOewRBCbTHGIi
     SoYKDycdgmfjPhlMzkOewRBCbTHGIn=SoYKDycdgmfjPhlMzkOewRBCbTHGIA
     SoYKDycdgmfjPhlMzkOewRBCbTHGIi =''
    if SoYKDycdgmfjPhlMzkOewRBCbTHGIi:SoYKDycdgmfjPhlMzkOewRBCbTHGIi+='\n'
    SoYKDycdgmfjPhlMzkOewRBCbTHGIi+=SoYKDycdgmfjPhlMzkOewRBCbTHGQE['title']+'\n'
    SoYKDycdgmfjPhlMzkOewRBCbTHGIi+=' [%s ~ %s]'%(SoYKDycdgmfjPhlMzkOewRBCbTHGQE['startTime'][-5:],SoYKDycdgmfjPhlMzkOewRBCbTHGQE['endTime'][-5:])+'\n'
   if SoYKDycdgmfjPhlMzkOewRBCbTHGIi:SoYKDycdgmfjPhlMzkOewRBCbTHGQF[SoYKDycdgmfjPhlMzkOewRBCbTHGIn]=SoYKDycdgmfjPhlMzkOewRBCbTHGIi
  except SoYKDycdgmfjPhlMzkOewRBCbTHGiu as exception:
   SoYKDycdgmfjPhlMzkOewRBCbTHGir(exception)
  return SoYKDycdgmfjPhlMzkOewRBCbTHGQF
 def GetEPGList_new(SoYKDycdgmfjPhlMzkOewRBCbTHGJn):
  SoYKDycdgmfjPhlMzkOewRBCbTHGQF={}
  SoYKDycdgmfjPhlMzkOewRBCbTHGQN=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.Get_Now_Datetime()
  SoYKDycdgmfjPhlMzkOewRBCbTHGQx=SoYKDycdgmfjPhlMzkOewRBCbTHGQN.strftime('%Y%m%d%H%M00')
  SoYKDycdgmfjPhlMzkOewRBCbTHGIJ='%s%s%s'%(SoYKDycdgmfjPhlMzkOewRBCbTHGQx[0:4],SoYKDycdgmfjPhlMzkOewRBCbTHGQx[4:6],SoYKDycdgmfjPhlMzkOewRBCbTHGQx[6:8])
  SoYKDycdgmfjPhlMzkOewRBCbTHGIQ=(SoYKDycdgmfjPhlMzkOewRBCbTHGQN+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M00')
  try:
   for SoYKDycdgmfjPhlMzkOewRBCbTHGQE in LIVETV_LIST:
    SoYKDycdgmfjPhlMzkOewRBCbTHGIp =SoYKDycdgmfjPhlMzkOewRBCbTHGQE['videoId']
    if SoYKDycdgmfjPhlMzkOewRBCbTHGQE['epgtype']=='spotvon':
     SoYKDycdgmfjPhlMzkOewRBCbTHGIi=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.Get_EpgInfo_Spotv_spotvon(SoYKDycdgmfjPhlMzkOewRBCbTHGIp,SoYKDycdgmfjPhlMzkOewRBCbTHGQE['epgnm'],SoYKDycdgmfjPhlMzkOewRBCbTHGIJ)
     SoYKDycdgmfjPhlMzkOewRBCbTHGQF[SoYKDycdgmfjPhlMzkOewRBCbTHGIp]=SoYKDycdgmfjPhlMzkOewRBCbTHGIi
    if SoYKDycdgmfjPhlMzkOewRBCbTHGQE['epgtype']=='spotvnet':
     SoYKDycdgmfjPhlMzkOewRBCbTHGIi=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.Get_EpgInfo_Spotv_spotvnet(SoYKDycdgmfjPhlMzkOewRBCbTHGIp,SoYKDycdgmfjPhlMzkOewRBCbTHGQE['epgnm'],SoYKDycdgmfjPhlMzkOewRBCbTHGIJ)
     SoYKDycdgmfjPhlMzkOewRBCbTHGQF[SoYKDycdgmfjPhlMzkOewRBCbTHGIp]=SoYKDycdgmfjPhlMzkOewRBCbTHGIi
   for SoYKDycdgmfjPhlMzkOewRBCbTHGIs in SoYKDycdgmfjPhlMzkOewRBCbTHGQF.keys():
    if SoYKDycdgmfjPhlMzkOewRBCbTHGiN(SoYKDycdgmfjPhlMzkOewRBCbTHGQF.get(SoYKDycdgmfjPhlMzkOewRBCbTHGIs))==0:continue
    SoYKDycdgmfjPhlMzkOewRBCbTHGIi =''
    SoYKDycdgmfjPhlMzkOewRBCbTHGIa=''
    for SoYKDycdgmfjPhlMzkOewRBCbTHGIq in SoYKDycdgmfjPhlMzkOewRBCbTHGQF.get(SoYKDycdgmfjPhlMzkOewRBCbTHGIs):
     SoYKDycdgmfjPhlMzkOewRBCbTHGIV =SoYKDycdgmfjPhlMzkOewRBCbTHGIq['startTime']
     SoYKDycdgmfjPhlMzkOewRBCbTHGIt =SoYKDycdgmfjPhlMzkOewRBCbTHGIq['endTime']
     if SoYKDycdgmfjPhlMzkOewRBCbTHGiE(SoYKDycdgmfjPhlMzkOewRBCbTHGQx)>SoYKDycdgmfjPhlMzkOewRBCbTHGiE(SoYKDycdgmfjPhlMzkOewRBCbTHGIt) :continue
     if SoYKDycdgmfjPhlMzkOewRBCbTHGiE(SoYKDycdgmfjPhlMzkOewRBCbTHGIQ)<SoYKDycdgmfjPhlMzkOewRBCbTHGiE(SoYKDycdgmfjPhlMzkOewRBCbTHGIV):continue
     if SoYKDycdgmfjPhlMzkOewRBCbTHGiE(SoYKDycdgmfjPhlMzkOewRBCbTHGQx)>=SoYKDycdgmfjPhlMzkOewRBCbTHGiE(SoYKDycdgmfjPhlMzkOewRBCbTHGIV)and SoYKDycdgmfjPhlMzkOewRBCbTHGiE(SoYKDycdgmfjPhlMzkOewRBCbTHGQx)<SoYKDycdgmfjPhlMzkOewRBCbTHGiE(SoYKDycdgmfjPhlMzkOewRBCbTHGIt):SoYKDycdgmfjPhlMzkOewRBCbTHGIa=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.xmlText(SoYKDycdgmfjPhlMzkOewRBCbTHGIq['title'])
     if SoYKDycdgmfjPhlMzkOewRBCbTHGIi:SoYKDycdgmfjPhlMzkOewRBCbTHGIi+='\n'
     SoYKDycdgmfjPhlMzkOewRBCbTHGIi+=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.xmlText(SoYKDycdgmfjPhlMzkOewRBCbTHGIq['title'])+'\n'
     SoYKDycdgmfjPhlMzkOewRBCbTHGIi+=' [%s:%s ~ %s:%s]'%(SoYKDycdgmfjPhlMzkOewRBCbTHGIq['startTime'][8:10],SoYKDycdgmfjPhlMzkOewRBCbTHGIq['startTime'][10:12],SoYKDycdgmfjPhlMzkOewRBCbTHGIq['endTime'][8:10],SoYKDycdgmfjPhlMzkOewRBCbTHGIq['endTime'][10:12])+'\n'
    SoYKDycdgmfjPhlMzkOewRBCbTHGQF[SoYKDycdgmfjPhlMzkOewRBCbTHGIs]={'epg':SoYKDycdgmfjPhlMzkOewRBCbTHGIi,'title':SoYKDycdgmfjPhlMzkOewRBCbTHGIa}
  except SoYKDycdgmfjPhlMzkOewRBCbTHGiu as exception:
   SoYKDycdgmfjPhlMzkOewRBCbTHGir(exception)
  return SoYKDycdgmfjPhlMzkOewRBCbTHGQF
 def Get_EpgInfo_Spotv_spotvon(SoYKDycdgmfjPhlMzkOewRBCbTHGJn,SoYKDycdgmfjPhlMzkOewRBCbTHGIp,epgnm,now_day):
  SoYKDycdgmfjPhlMzkOewRBCbTHGQF =[]
  try:
   SoYKDycdgmfjPhlMzkOewRBCbTHGJv='https://www.spotvon.co.kr/data/onAir/%s/Daily/D%s.asp'%(epgnm,now_day)
   SoYKDycdgmfjPhlMzkOewRBCbTHGJU=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.callRequestCookies('Get',SoYKDycdgmfjPhlMzkOewRBCbTHGJv,payload=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,params=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,headers=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,cookies=SoYKDycdgmfjPhlMzkOewRBCbTHGiL)
   SoYKDycdgmfjPhlMzkOewRBCbTHGJN=json.loads(SoYKDycdgmfjPhlMzkOewRBCbTHGJU.text)
   for SoYKDycdgmfjPhlMzkOewRBCbTHGQE in SoYKDycdgmfjPhlMzkOewRBCbTHGJN:
    SoYKDycdgmfjPhlMzkOewRBCbTHGQu={'title':SoYKDycdgmfjPhlMzkOewRBCbTHGQE['title'],'startTime':SoYKDycdgmfjPhlMzkOewRBCbTHGQE['sch_date'].replace('-','')+SoYKDycdgmfjPhlMzkOewRBCbTHGiF(SoYKDycdgmfjPhlMzkOewRBCbTHGQE['sch_hour']).zfill(2)+SoYKDycdgmfjPhlMzkOewRBCbTHGQE['sch_min']+'00'}
    SoYKDycdgmfjPhlMzkOewRBCbTHGQF.append(SoYKDycdgmfjPhlMzkOewRBCbTHGQu)
   for i in SoYKDycdgmfjPhlMzkOewRBCbTHGix(SoYKDycdgmfjPhlMzkOewRBCbTHGiN(SoYKDycdgmfjPhlMzkOewRBCbTHGQF)):
    if i>0:SoYKDycdgmfjPhlMzkOewRBCbTHGQF[i-1]['endTime']=SoYKDycdgmfjPhlMzkOewRBCbTHGQF[i]['startTime']
    if i==SoYKDycdgmfjPhlMzkOewRBCbTHGiN(SoYKDycdgmfjPhlMzkOewRBCbTHGQF)-1: SoYKDycdgmfjPhlMzkOewRBCbTHGQF[i]['endTime']=now_day+'240000'
  except SoYKDycdgmfjPhlMzkOewRBCbTHGiu as exception:
   SoYKDycdgmfjPhlMzkOewRBCbTHGir(exception)
   return[]
  return SoYKDycdgmfjPhlMzkOewRBCbTHGQF
 def Get_EpgInfo_Spotv_spotvnet(SoYKDycdgmfjPhlMzkOewRBCbTHGJn,SoYKDycdgmfjPhlMzkOewRBCbTHGIp,epgnm,now_day):
  SoYKDycdgmfjPhlMzkOewRBCbTHGQF =[]
  try:
   SoYKDycdgmfjPhlMzkOewRBCbTHGJv='https://www.spotv.net/data/json/schedule/%s/Daily/D%s.json'%(epgnm,now_day)
   SoYKDycdgmfjPhlMzkOewRBCbTHGJU=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.callRequestCookies('Get',SoYKDycdgmfjPhlMzkOewRBCbTHGJv,payload=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,params=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,headers=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,cookies=SoYKDycdgmfjPhlMzkOewRBCbTHGiL)
   SoYKDycdgmfjPhlMzkOewRBCbTHGJN=json.loads(SoYKDycdgmfjPhlMzkOewRBCbTHGJU.text)
   for SoYKDycdgmfjPhlMzkOewRBCbTHGQE in SoYKDycdgmfjPhlMzkOewRBCbTHGJN:
    SoYKDycdgmfjPhlMzkOewRBCbTHGQu={'title':SoYKDycdgmfjPhlMzkOewRBCbTHGQE['title'],'startTime':SoYKDycdgmfjPhlMzkOewRBCbTHGQE['sch_date'].replace('-','')+SoYKDycdgmfjPhlMzkOewRBCbTHGiF(SoYKDycdgmfjPhlMzkOewRBCbTHGQE['sch_hour']).zfill(2)+SoYKDycdgmfjPhlMzkOewRBCbTHGQE['sch_min']+'00'}
    SoYKDycdgmfjPhlMzkOewRBCbTHGQF.append(SoYKDycdgmfjPhlMzkOewRBCbTHGQu)
   for i in SoYKDycdgmfjPhlMzkOewRBCbTHGix(SoYKDycdgmfjPhlMzkOewRBCbTHGiN(SoYKDycdgmfjPhlMzkOewRBCbTHGQF)):
    if i>0:SoYKDycdgmfjPhlMzkOewRBCbTHGQF[i-1]['endTime']=SoYKDycdgmfjPhlMzkOewRBCbTHGQF[i]['startTime']
    if i==SoYKDycdgmfjPhlMzkOewRBCbTHGiN(SoYKDycdgmfjPhlMzkOewRBCbTHGQF)-1: SoYKDycdgmfjPhlMzkOewRBCbTHGQF[i]['endTime']=now_day+'240000'
  except SoYKDycdgmfjPhlMzkOewRBCbTHGiu as exception:
   SoYKDycdgmfjPhlMzkOewRBCbTHGir(exception)
   return[]
  return SoYKDycdgmfjPhlMzkOewRBCbTHGQF
 def GetEventLiveList(SoYKDycdgmfjPhlMzkOewRBCbTHGJn):
  SoYKDycdgmfjPhlMzkOewRBCbTHGQv=[]
  SoYKDycdgmfjPhlMzkOewRBCbTHGIX =0
  try:
   SoYKDycdgmfjPhlMzkOewRBCbTHGIL=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.Get_Now_Datetime()
   SoYKDycdgmfjPhlMzkOewRBCbTHGIW=SoYKDycdgmfjPhlMzkOewRBCbTHGIL.strftime('%Y-%m-%d')
  except SoYKDycdgmfjPhlMzkOewRBCbTHGiu as exception:
   SoYKDycdgmfjPhlMzkOewRBCbTHGir(exception)
   return SoYKDycdgmfjPhlMzkOewRBCbTHGQv,SoYKDycdgmfjPhlMzkOewRBCbTHGIX
  try:
   SoYKDycdgmfjPhlMzkOewRBCbTHGJv=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.API_DOMAIN+'/api/v3/player/lives/'+SoYKDycdgmfjPhlMzkOewRBCbTHGIW 
   SoYKDycdgmfjPhlMzkOewRBCbTHGJq=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.makeDefaultCookies()
   SoYKDycdgmfjPhlMzkOewRBCbTHGJU=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.callRequestCookies('Get',SoYKDycdgmfjPhlMzkOewRBCbTHGJv,payload=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,params=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,headers=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,cookies=SoYKDycdgmfjPhlMzkOewRBCbTHGJq)
   SoYKDycdgmfjPhlMzkOewRBCbTHGIX=SoYKDycdgmfjPhlMzkOewRBCbTHGJU.status_code 
   SoYKDycdgmfjPhlMzkOewRBCbTHGQI=json.loads(SoYKDycdgmfjPhlMzkOewRBCbTHGJU.text)
   for SoYKDycdgmfjPhlMzkOewRBCbTHGIv in SoYKDycdgmfjPhlMzkOewRBCbTHGQI:
    for SoYKDycdgmfjPhlMzkOewRBCbTHGQE in SoYKDycdgmfjPhlMzkOewRBCbTHGIv['liveNowList']:
     if SoYKDycdgmfjPhlMzkOewRBCbTHGQE['gameDesc']['title']==SoYKDycdgmfjPhlMzkOewRBCbTHGiL or SoYKDycdgmfjPhlMzkOewRBCbTHGQE['gameDesc']['title']=='':
      SoYKDycdgmfjPhlMzkOewRBCbTHGIU='%s ( %s : %s )'%(SoYKDycdgmfjPhlMzkOewRBCbTHGQE['leagueName'],SoYKDycdgmfjPhlMzkOewRBCbTHGQE['homeNameShort'],SoYKDycdgmfjPhlMzkOewRBCbTHGQE['awayNameShort'])
     else:
      SoYKDycdgmfjPhlMzkOewRBCbTHGIU=SoYKDycdgmfjPhlMzkOewRBCbTHGQE['gameDesc']['title']
     SoYKDycdgmfjPhlMzkOewRBCbTHGQu={'liveId':SoYKDycdgmfjPhlMzkOewRBCbTHGQE['liveId'],'title':SoYKDycdgmfjPhlMzkOewRBCbTHGIU,'logo':SoYKDycdgmfjPhlMzkOewRBCbTHGQE['gameDesc']['leagueLogo'],'free':SoYKDycdgmfjPhlMzkOewRBCbTHGQE['isFree'],'startTime':SoYKDycdgmfjPhlMzkOewRBCbTHGQE['startTime']}
     SoYKDycdgmfjPhlMzkOewRBCbTHGQv.append(SoYKDycdgmfjPhlMzkOewRBCbTHGQu)
  except SoYKDycdgmfjPhlMzkOewRBCbTHGiu as exception:
   SoYKDycdgmfjPhlMzkOewRBCbTHGir(exception)
  return SoYKDycdgmfjPhlMzkOewRBCbTHGQv,SoYKDycdgmfjPhlMzkOewRBCbTHGIX
 def GetEventLive_videoId(SoYKDycdgmfjPhlMzkOewRBCbTHGJn,liveId):
  SoYKDycdgmfjPhlMzkOewRBCbTHGIE=''
  try:
   SoYKDycdgmfjPhlMzkOewRBCbTHGJv=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.API_DOMAIN+'/api/v3/live/'+liveId
   SoYKDycdgmfjPhlMzkOewRBCbTHGJU=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.callRequestCookies('Get',SoYKDycdgmfjPhlMzkOewRBCbTHGJv,payload=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,params=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,headers=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,cookies=SoYKDycdgmfjPhlMzkOewRBCbTHGiL)
   SoYKDycdgmfjPhlMzkOewRBCbTHGQI=json.loads(SoYKDycdgmfjPhlMzkOewRBCbTHGJU.text)
   SoYKDycdgmfjPhlMzkOewRBCbTHGIu=SoYKDycdgmfjPhlMzkOewRBCbTHGQI['videoId']
   SoYKDycdgmfjPhlMzkOewRBCbTHGIE=SoYKDycdgmfjPhlMzkOewRBCbTHGIu.replace('ref:','')
  except SoYKDycdgmfjPhlMzkOewRBCbTHGiu as exception:
   SoYKDycdgmfjPhlMzkOewRBCbTHGir(exception)
  return SoYKDycdgmfjPhlMzkOewRBCbTHGIE
 def CheckMainEnd(SoYKDycdgmfjPhlMzkOewRBCbTHGJn):
  SoYKDycdgmfjPhlMzkOewRBCbTHGIr=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.SPOTV_PMCODE+SoYKDycdgmfjPhlMzkOewRBCbTHGiF(SoYKDycdgmfjPhlMzkOewRBCbTHGJn.ST['cookies']['spotv_sessionid'])
  SoYKDycdgmfjPhlMzkOewRBCbTHGIr=base64.standard_b64encode(SoYKDycdgmfjPhlMzkOewRBCbTHGIr.encode()).decode('utf-8')
  if SoYKDycdgmfjPhlMzkOewRBCbTHGIr=='OTg3MTgzMzM0Ng==' or SoYKDycdgmfjPhlMzkOewRBCbTHGIr=='OTg3MTgzMzExNw==':return SoYKDycdgmfjPhlMzkOewRBCbTHGiU
  return SoYKDycdgmfjPhlMzkOewRBCbTHGiW
 def CheckSubEnd(SoYKDycdgmfjPhlMzkOewRBCbTHGJn):
  SoYKDycdgmfjPhlMzkOewRBCbTHGJp=SoYKDycdgmfjPhlMzkOewRBCbTHGiW
  try:
   if SoYKDycdgmfjPhlMzkOewRBCbTHGJn.CheckMainEnd():return SoYKDycdgmfjPhlMzkOewRBCbTHGiU 
   SoYKDycdgmfjPhlMzkOewRBCbTHGIF=base64.standard_b64decode(SoYKDycdgmfjPhlMzkOewRBCbTHGJn.ST['cookies']['spotv_subend']).decode('utf-8')[SoYKDycdgmfjPhlMzkOewRBCbTHGJn.SPOTV_PMSIZE:]
   if SoYKDycdgmfjPhlMzkOewRBCbTHGIF=='0':return SoYKDycdgmfjPhlMzkOewRBCbTHGJp
   SoYKDycdgmfjPhlMzkOewRBCbTHGIN =SoYKDycdgmfjPhlMzkOewRBCbTHGiE(SoYKDycdgmfjPhlMzkOewRBCbTHGJn.Get_Now_Datetime().strftime('%Y%m%d'))
   SoYKDycdgmfjPhlMzkOewRBCbTHGIx =SoYKDycdgmfjPhlMzkOewRBCbTHGiE(SoYKDycdgmfjPhlMzkOewRBCbTHGIF)/1000
   SoYKDycdgmfjPhlMzkOewRBCbTHGnJ =SoYKDycdgmfjPhlMzkOewRBCbTHGiE(datetime.datetime.fromtimestamp(SoYKDycdgmfjPhlMzkOewRBCbTHGIx,datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul')).strftime('%Y%m%d'))
   if SoYKDycdgmfjPhlMzkOewRBCbTHGIN<=SoYKDycdgmfjPhlMzkOewRBCbTHGnJ:SoYKDycdgmfjPhlMzkOewRBCbTHGJp=SoYKDycdgmfjPhlMzkOewRBCbTHGiU
  except SoYKDycdgmfjPhlMzkOewRBCbTHGiu as exception:
   SoYKDycdgmfjPhlMzkOewRBCbTHGir(exception)
   return SoYKDycdgmfjPhlMzkOewRBCbTHGJp
  return SoYKDycdgmfjPhlMzkOewRBCbTHGJp
 def GetBroadURL(SoYKDycdgmfjPhlMzkOewRBCbTHGJn,SoYKDycdgmfjPhlMzkOewRBCbTHGIE,mediatype,SoYKDycdgmfjPhlMzkOewRBCbTHGna):
  SoYKDycdgmfjPhlMzkOewRBCbTHGnQ=''
  try:
   if mediatype=='live':
    SoYKDycdgmfjPhlMzkOewRBCbTHGJv=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.API_DOMAIN+'/api/v3/live/'+SoYKDycdgmfjPhlMzkOewRBCbTHGIE
   else:
    SoYKDycdgmfjPhlMzkOewRBCbTHGIE=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.GetReplay_UrlId(SoYKDycdgmfjPhlMzkOewRBCbTHGIE,SoYKDycdgmfjPhlMzkOewRBCbTHGna)
    if SoYKDycdgmfjPhlMzkOewRBCbTHGIE=='':return SoYKDycdgmfjPhlMzkOewRBCbTHGnQ
    SoYKDycdgmfjPhlMzkOewRBCbTHGJv=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.PLAYER_DOMAIN+'/playback/v1/accounts/'+SoYKDycdgmfjPhlMzkOewRBCbTHGiF(SoYKDycdgmfjPhlMzkOewRBCbTHGJn.ST['cookies']['spotv_accountId'])+'/videos/'+SoYKDycdgmfjPhlMzkOewRBCbTHGIE
   SoYKDycdgmfjPhlMzkOewRBCbTHGJX=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.makeDefaultHeaders()
   SoYKDycdgmfjPhlMzkOewRBCbTHGJU=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.callRequestCookies('Get',SoYKDycdgmfjPhlMzkOewRBCbTHGJv,payload=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,params=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,headers=SoYKDycdgmfjPhlMzkOewRBCbTHGJX,cookies=SoYKDycdgmfjPhlMzkOewRBCbTHGiL)
   SoYKDycdgmfjPhlMzkOewRBCbTHGJN=json.loads(SoYKDycdgmfjPhlMzkOewRBCbTHGJU.text)
   SoYKDycdgmfjPhlMzkOewRBCbTHGir(SoYKDycdgmfjPhlMzkOewRBCbTHGJv)
   if mediatype=='live':
    SoYKDycdgmfjPhlMzkOewRBCbTHGnQ=SoYKDycdgmfjPhlMzkOewRBCbTHGJN['hlsUrl2']or SoYKDycdgmfjPhlMzkOewRBCbTHGJN['hlsUrl']
   else:
    SoYKDycdgmfjPhlMzkOewRBCbTHGir(SoYKDycdgmfjPhlMzkOewRBCbTHGJN)
    SoYKDycdgmfjPhlMzkOewRBCbTHGnQ=SoYKDycdgmfjPhlMzkOewRBCbTHGJN['sources'][0]['src']
   SoYKDycdgmfjPhlMzkOewRBCbTHGnQ=SoYKDycdgmfjPhlMzkOewRBCbTHGnQ.replace('http://','https://')
  except SoYKDycdgmfjPhlMzkOewRBCbTHGiu as exception:
   SoYKDycdgmfjPhlMzkOewRBCbTHGir(exception)
  return SoYKDycdgmfjPhlMzkOewRBCbTHGnQ
 def GetTitleGroupList(SoYKDycdgmfjPhlMzkOewRBCbTHGJn):
  SoYKDycdgmfjPhlMzkOewRBCbTHGQv=[]
  try:
   SoYKDycdgmfjPhlMzkOewRBCbTHGJv=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.API_DOMAIN+'/api/v3/home/web'
   SoYKDycdgmfjPhlMzkOewRBCbTHGJU=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.callRequestCookies('Get',SoYKDycdgmfjPhlMzkOewRBCbTHGJv,payload=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,params=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,headers=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,cookies=SoYKDycdgmfjPhlMzkOewRBCbTHGiL)
   SoYKDycdgmfjPhlMzkOewRBCbTHGQI=json.loads(SoYKDycdgmfjPhlMzkOewRBCbTHGJU.text)
   for SoYKDycdgmfjPhlMzkOewRBCbTHGQE in SoYKDycdgmfjPhlMzkOewRBCbTHGQI:
    if SoYKDycdgmfjPhlMzkOewRBCbTHGiF(SoYKDycdgmfjPhlMzkOewRBCbTHGQE['type'])=='3':
     SoYKDycdgmfjPhlMzkOewRBCbTHGnI=''
     for SoYKDycdgmfjPhlMzkOewRBCbTHGni in SoYKDycdgmfjPhlMzkOewRBCbTHGQE['data']['list']:
      SoYKDycdgmfjPhlMzkOewRBCbTHGnA='[%s] %s vs %s\n<%s>\n\n'%(SoYKDycdgmfjPhlMzkOewRBCbTHGni['gameDesc']['roundName'],SoYKDycdgmfjPhlMzkOewRBCbTHGni['gameDesc']['homeNameShort'],SoYKDycdgmfjPhlMzkOewRBCbTHGni['gameDesc']['awayNameShort'],SoYKDycdgmfjPhlMzkOewRBCbTHGni['gameDesc']['beginDate'])
      SoYKDycdgmfjPhlMzkOewRBCbTHGnI+=SoYKDycdgmfjPhlMzkOewRBCbTHGnA
     SoYKDycdgmfjPhlMzkOewRBCbTHGQu={'title':SoYKDycdgmfjPhlMzkOewRBCbTHGQE['title'],'logo':SoYKDycdgmfjPhlMzkOewRBCbTHGQE['logo'],'reagueId':SoYKDycdgmfjPhlMzkOewRBCbTHGiF(SoYKDycdgmfjPhlMzkOewRBCbTHGQE['destId']),'subGame':SoYKDycdgmfjPhlMzkOewRBCbTHGnI}
     SoYKDycdgmfjPhlMzkOewRBCbTHGQv.append(SoYKDycdgmfjPhlMzkOewRBCbTHGQu)
  except SoYKDycdgmfjPhlMzkOewRBCbTHGiu as exception:
   SoYKDycdgmfjPhlMzkOewRBCbTHGir(exception)
  return SoYKDycdgmfjPhlMzkOewRBCbTHGQv
 def GetPopularGroupList(SoYKDycdgmfjPhlMzkOewRBCbTHGJn):
  SoYKDycdgmfjPhlMzkOewRBCbTHGQv=[]
  try:
   SoYKDycdgmfjPhlMzkOewRBCbTHGJv=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.API_DOMAIN+'/api/v3/home/web'
   SoYKDycdgmfjPhlMzkOewRBCbTHGJU=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.callRequestCookies('Get',SoYKDycdgmfjPhlMzkOewRBCbTHGJv,payload=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,params=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,headers=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,cookies=SoYKDycdgmfjPhlMzkOewRBCbTHGiL)
   SoYKDycdgmfjPhlMzkOewRBCbTHGQI=json.loads(SoYKDycdgmfjPhlMzkOewRBCbTHGJU.text)
   for SoYKDycdgmfjPhlMzkOewRBCbTHGQE in SoYKDycdgmfjPhlMzkOewRBCbTHGQI:
    if SoYKDycdgmfjPhlMzkOewRBCbTHGiF(SoYKDycdgmfjPhlMzkOewRBCbTHGQE['type'])=='1' and SoYKDycdgmfjPhlMzkOewRBCbTHGiF(SoYKDycdgmfjPhlMzkOewRBCbTHGQE['destId'])=='4':
     for SoYKDycdgmfjPhlMzkOewRBCbTHGni in SoYKDycdgmfjPhlMzkOewRBCbTHGQE['data']['list']:
      SoYKDycdgmfjPhlMzkOewRBCbTHGnV =SoYKDycdgmfjPhlMzkOewRBCbTHGni['title']
      SoYKDycdgmfjPhlMzkOewRBCbTHGnt =SoYKDycdgmfjPhlMzkOewRBCbTHGni['id']
      SoYKDycdgmfjPhlMzkOewRBCbTHGnp =SoYKDycdgmfjPhlMzkOewRBCbTHGni['vtype']
      SoYKDycdgmfjPhlMzkOewRBCbTHGns =SoYKDycdgmfjPhlMzkOewRBCbTHGni['imgUrl']
      SoYKDycdgmfjPhlMzkOewRBCbTHGna =SoYKDycdgmfjPhlMzkOewRBCbTHGni['vtypeId']
      SoYKDycdgmfjPhlMzkOewRBCbTHGQu={'vodTitle':SoYKDycdgmfjPhlMzkOewRBCbTHGnV,'vodId':SoYKDycdgmfjPhlMzkOewRBCbTHGnt,'vodType':SoYKDycdgmfjPhlMzkOewRBCbTHGnp,'thumbnail':SoYKDycdgmfjPhlMzkOewRBCbTHGns,'vtypeId':SoYKDycdgmfjPhlMzkOewRBCbTHGiF(SoYKDycdgmfjPhlMzkOewRBCbTHGna),'duration':SoYKDycdgmfjPhlMzkOewRBCbTHGiE(SoYKDycdgmfjPhlMzkOewRBCbTHGni['duration']/1000)}
      SoYKDycdgmfjPhlMzkOewRBCbTHGQv.append(SoYKDycdgmfjPhlMzkOewRBCbTHGQu)
  except SoYKDycdgmfjPhlMzkOewRBCbTHGiu as exception:
   SoYKDycdgmfjPhlMzkOewRBCbTHGir(exception)
  return SoYKDycdgmfjPhlMzkOewRBCbTHGQv
 def Get_NowVod_GroupList(SoYKDycdgmfjPhlMzkOewRBCbTHGJn,page_int):
  SoYKDycdgmfjPhlMzkOewRBCbTHGQv=[]
  SoYKDycdgmfjPhlMzkOewRBCbTHGnq=SoYKDycdgmfjPhlMzkOewRBCbTHGiW
  try:
   SoYKDycdgmfjPhlMzkOewRBCbTHGJv=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.API_DOMAIN+'/api/v3/theme/14/list'
   SoYKDycdgmfjPhlMzkOewRBCbTHGnX={'pageItem':'10','pageNo':SoYKDycdgmfjPhlMzkOewRBCbTHGiF(page_int)}
   SoYKDycdgmfjPhlMzkOewRBCbTHGJU=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.callRequestCookies('Get',SoYKDycdgmfjPhlMzkOewRBCbTHGJv,payload=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,params=SoYKDycdgmfjPhlMzkOewRBCbTHGnX,headers=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,cookies=SoYKDycdgmfjPhlMzkOewRBCbTHGiL)
   SoYKDycdgmfjPhlMzkOewRBCbTHGQI=json.loads(SoYKDycdgmfjPhlMzkOewRBCbTHGJU.text)
   for SoYKDycdgmfjPhlMzkOewRBCbTHGQE in SoYKDycdgmfjPhlMzkOewRBCbTHGQI['list']:
    SoYKDycdgmfjPhlMzkOewRBCbTHGnV =SoYKDycdgmfjPhlMzkOewRBCbTHGQE['title']
    SoYKDycdgmfjPhlMzkOewRBCbTHGnt =SoYKDycdgmfjPhlMzkOewRBCbTHGQE['id']
    SoYKDycdgmfjPhlMzkOewRBCbTHGnp =SoYKDycdgmfjPhlMzkOewRBCbTHGQE['vtype']
    SoYKDycdgmfjPhlMzkOewRBCbTHGns =SoYKDycdgmfjPhlMzkOewRBCbTHGQE['imgUrl']
    SoYKDycdgmfjPhlMzkOewRBCbTHGna =SoYKDycdgmfjPhlMzkOewRBCbTHGQE['vtypeId']
    SoYKDycdgmfjPhlMzkOewRBCbTHGQu={'vodTitle':SoYKDycdgmfjPhlMzkOewRBCbTHGnV,'vodId':SoYKDycdgmfjPhlMzkOewRBCbTHGnt,'vodType':SoYKDycdgmfjPhlMzkOewRBCbTHGnp,'thumbnail':SoYKDycdgmfjPhlMzkOewRBCbTHGns,'vtypeId':SoYKDycdgmfjPhlMzkOewRBCbTHGiF(SoYKDycdgmfjPhlMzkOewRBCbTHGna),'duration':SoYKDycdgmfjPhlMzkOewRBCbTHGiE(SoYKDycdgmfjPhlMzkOewRBCbTHGQE['duration']/1000),}
    SoYKDycdgmfjPhlMzkOewRBCbTHGQv.append(SoYKDycdgmfjPhlMzkOewRBCbTHGQu)
    if SoYKDycdgmfjPhlMzkOewRBCbTHGQI['count']>page_int*SoYKDycdgmfjPhlMzkOewRBCbTHGJn.GAMELIST_LIMIT:SoYKDycdgmfjPhlMzkOewRBCbTHGnq=SoYKDycdgmfjPhlMzkOewRBCbTHGiU
  except SoYKDycdgmfjPhlMzkOewRBCbTHGiu as exception:
   SoYKDycdgmfjPhlMzkOewRBCbTHGir(exception)
  return SoYKDycdgmfjPhlMzkOewRBCbTHGQv,SoYKDycdgmfjPhlMzkOewRBCbTHGnq
 def GetSeasonList(SoYKDycdgmfjPhlMzkOewRBCbTHGJn,leagueId):
  SoYKDycdgmfjPhlMzkOewRBCbTHGQv=[]
  SoYKDycdgmfjPhlMzkOewRBCbTHGnL=SoYKDycdgmfjPhlMzkOewRBCbTHGnW=''
  try:
   SoYKDycdgmfjPhlMzkOewRBCbTHGJv=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.API_DOMAIN+'/api/v3/game/league/'+leagueId
   SoYKDycdgmfjPhlMzkOewRBCbTHGJU=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.callRequestCookies('Get',SoYKDycdgmfjPhlMzkOewRBCbTHGJv,payload=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,params=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,headers=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,cookies=SoYKDycdgmfjPhlMzkOewRBCbTHGiL)
   SoYKDycdgmfjPhlMzkOewRBCbTHGQI=json.loads(SoYKDycdgmfjPhlMzkOewRBCbTHGJU.text)
   SoYKDycdgmfjPhlMzkOewRBCbTHGnL=SoYKDycdgmfjPhlMzkOewRBCbTHGQI['name']
   SoYKDycdgmfjPhlMzkOewRBCbTHGnW=SoYKDycdgmfjPhlMzkOewRBCbTHGiF(SoYKDycdgmfjPhlMzkOewRBCbTHGQI['gameTypeId'])
  except SoYKDycdgmfjPhlMzkOewRBCbTHGiu as exception:
   SoYKDycdgmfjPhlMzkOewRBCbTHGir(exception)
   return SoYKDycdgmfjPhlMzkOewRBCbTHGQv
  if SoYKDycdgmfjPhlMzkOewRBCbTHGnW in['2','5','6','8']:
   try:
    SoYKDycdgmfjPhlMzkOewRBCbTHGJv=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.API_DOMAIN+'/api/v3/year/'+leagueId
    SoYKDycdgmfjPhlMzkOewRBCbTHGJU=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.callRequestCookies('Get',SoYKDycdgmfjPhlMzkOewRBCbTHGJv,payload=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,params=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,headers=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,cookies=SoYKDycdgmfjPhlMzkOewRBCbTHGiL)
    SoYKDycdgmfjPhlMzkOewRBCbTHGQI=json.loads(SoYKDycdgmfjPhlMzkOewRBCbTHGJU.text)
    for SoYKDycdgmfjPhlMzkOewRBCbTHGQE in SoYKDycdgmfjPhlMzkOewRBCbTHGQI:
     SoYKDycdgmfjPhlMzkOewRBCbTHGQu={'reagueName':SoYKDycdgmfjPhlMzkOewRBCbTHGnL,'gameTypeId':SoYKDycdgmfjPhlMzkOewRBCbTHGnW,'seasonName':SoYKDycdgmfjPhlMzkOewRBCbTHGiF(SoYKDycdgmfjPhlMzkOewRBCbTHGQE),'seasonId':SoYKDycdgmfjPhlMzkOewRBCbTHGiF(SoYKDycdgmfjPhlMzkOewRBCbTHGQE)}
     SoYKDycdgmfjPhlMzkOewRBCbTHGQv.append(SoYKDycdgmfjPhlMzkOewRBCbTHGQu)
   except SoYKDycdgmfjPhlMzkOewRBCbTHGiu as exception:
    SoYKDycdgmfjPhlMzkOewRBCbTHGir(exception)
    return[]
  else:
   try:
    SoYKDycdgmfjPhlMzkOewRBCbTHGJv=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.API_DOMAIN+'/api/v3/season/'+leagueId
    SoYKDycdgmfjPhlMzkOewRBCbTHGJU=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.callRequestCookies('Get',SoYKDycdgmfjPhlMzkOewRBCbTHGJv,payload=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,params=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,headers=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,cookies=SoYKDycdgmfjPhlMzkOewRBCbTHGiL)
    SoYKDycdgmfjPhlMzkOewRBCbTHGQI=json.loads(SoYKDycdgmfjPhlMzkOewRBCbTHGJU.text)
    for SoYKDycdgmfjPhlMzkOewRBCbTHGQE in SoYKDycdgmfjPhlMzkOewRBCbTHGQI:
     SoYKDycdgmfjPhlMzkOewRBCbTHGQu={'reagueName':SoYKDycdgmfjPhlMzkOewRBCbTHGnL,'gameTypeId':SoYKDycdgmfjPhlMzkOewRBCbTHGnW,'seasonName':SoYKDycdgmfjPhlMzkOewRBCbTHGQE['name'],'seasonId':SoYKDycdgmfjPhlMzkOewRBCbTHGiF(SoYKDycdgmfjPhlMzkOewRBCbTHGQE['id'])}
     SoYKDycdgmfjPhlMzkOewRBCbTHGQv.append(SoYKDycdgmfjPhlMzkOewRBCbTHGQu)
   except SoYKDycdgmfjPhlMzkOewRBCbTHGiu as exception:
    SoYKDycdgmfjPhlMzkOewRBCbTHGir(exception)
    return[]
  return SoYKDycdgmfjPhlMzkOewRBCbTHGQv
 def GetGameList(SoYKDycdgmfjPhlMzkOewRBCbTHGJn,SoYKDycdgmfjPhlMzkOewRBCbTHGnW,leagueId,seasonId,page_int,hidescore=SoYKDycdgmfjPhlMzkOewRBCbTHGiU):
  SoYKDycdgmfjPhlMzkOewRBCbTHGQv=[]
  SoYKDycdgmfjPhlMzkOewRBCbTHGnq=SoYKDycdgmfjPhlMzkOewRBCbTHGiW
  try:
   SoYKDycdgmfjPhlMzkOewRBCbTHGJv=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.API_DOMAIN+'/api/v3/vod/league/detail'
   SoYKDycdgmfjPhlMzkOewRBCbTHGnX={'gameType':SoYKDycdgmfjPhlMzkOewRBCbTHGnW,'leagueId':leagueId,'seasonId':seasonId if SoYKDycdgmfjPhlMzkOewRBCbTHGnW not in['2','5','6','8']else '','teamId':'','roundId':'','year':'' if SoYKDycdgmfjPhlMzkOewRBCbTHGnW not in['2','5','6','8']else seasonId,'pageNo':SoYKDycdgmfjPhlMzkOewRBCbTHGiF(page_int)}
   SoYKDycdgmfjPhlMzkOewRBCbTHGJU=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.callRequestCookies('Get',SoYKDycdgmfjPhlMzkOewRBCbTHGJv,payload=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,params=SoYKDycdgmfjPhlMzkOewRBCbTHGnX,headers=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,cookies=SoYKDycdgmfjPhlMzkOewRBCbTHGiL)
   SoYKDycdgmfjPhlMzkOewRBCbTHGQI=json.loads(SoYKDycdgmfjPhlMzkOewRBCbTHGJU.text)
   SoYKDycdgmfjPhlMzkOewRBCbTHGIv=SoYKDycdgmfjPhlMzkOewRBCbTHGQI['list']
   for SoYKDycdgmfjPhlMzkOewRBCbTHGnv in SoYKDycdgmfjPhlMzkOewRBCbTHGIv:
    for SoYKDycdgmfjPhlMzkOewRBCbTHGQE in SoYKDycdgmfjPhlMzkOewRBCbTHGnv['list']:
     if SoYKDycdgmfjPhlMzkOewRBCbTHGQE['gameDesc']['title']==SoYKDycdgmfjPhlMzkOewRBCbTHGiL or SoYKDycdgmfjPhlMzkOewRBCbTHGQE['gameDesc']['title']=='':
      SoYKDycdgmfjPhlMzkOewRBCbTHGIU ='%s vs %s'%(SoYKDycdgmfjPhlMzkOewRBCbTHGQE['gameDesc']['homeNameShort'],SoYKDycdgmfjPhlMzkOewRBCbTHGQE['gameDesc']['awayNameShort'])
     else:
      SoYKDycdgmfjPhlMzkOewRBCbTHGIU =SoYKDycdgmfjPhlMzkOewRBCbTHGQE['gameDesc']['title']
     SoYKDycdgmfjPhlMzkOewRBCbTHGnU =SoYKDycdgmfjPhlMzkOewRBCbTHGQE['gameDesc']['beginDate']
     SoYKDycdgmfjPhlMzkOewRBCbTHGnE =SoYKDycdgmfjPhlMzkOewRBCbTHGQE['gameDesc']['id']
     SoYKDycdgmfjPhlMzkOewRBCbTHGnu =SoYKDycdgmfjPhlMzkOewRBCbTHGQE['gameDesc']['leagueNameFull']
     SoYKDycdgmfjPhlMzkOewRBCbTHGnr =SoYKDycdgmfjPhlMzkOewRBCbTHGQE['gameDesc']['seasonName']
     SoYKDycdgmfjPhlMzkOewRBCbTHGnF =SoYKDycdgmfjPhlMzkOewRBCbTHGQE['gameDesc']['roundName']
     SoYKDycdgmfjPhlMzkOewRBCbTHGnN =SoYKDycdgmfjPhlMzkOewRBCbTHGQE['gameDesc']['homeName']
     SoYKDycdgmfjPhlMzkOewRBCbTHGnx =SoYKDycdgmfjPhlMzkOewRBCbTHGQE['gameDesc']['awayName']
     SoYKDycdgmfjPhlMzkOewRBCbTHGiJ =SoYKDycdgmfjPhlMzkOewRBCbTHGQE['gameDesc']['homeScore']
     SoYKDycdgmfjPhlMzkOewRBCbTHGiQ =SoYKDycdgmfjPhlMzkOewRBCbTHGQE['gameDesc']['awayScore']
     if hidescore==SoYKDycdgmfjPhlMzkOewRBCbTHGiU:
      SoYKDycdgmfjPhlMzkOewRBCbTHGiI ='%s\n - %s (%s)\n - %s\n\nhome : %s\n\naway : %s'%(SoYKDycdgmfjPhlMzkOewRBCbTHGnu,SoYKDycdgmfjPhlMzkOewRBCbTHGnr,SoYKDycdgmfjPhlMzkOewRBCbTHGnF,SoYKDycdgmfjPhlMzkOewRBCbTHGnU,SoYKDycdgmfjPhlMzkOewRBCbTHGnN,SoYKDycdgmfjPhlMzkOewRBCbTHGnx)
     else:
      SoYKDycdgmfjPhlMzkOewRBCbTHGiI ='%s\n - %s (%s)\n - %s\n\nhome : %s (Score %s)\n\naway : %s (Score %s)'%(SoYKDycdgmfjPhlMzkOewRBCbTHGnu,SoYKDycdgmfjPhlMzkOewRBCbTHGnr,SoYKDycdgmfjPhlMzkOewRBCbTHGnF,SoYKDycdgmfjPhlMzkOewRBCbTHGnU,SoYKDycdgmfjPhlMzkOewRBCbTHGnN,SoYKDycdgmfjPhlMzkOewRBCbTHGiJ,SoYKDycdgmfjPhlMzkOewRBCbTHGnx,SoYKDycdgmfjPhlMzkOewRBCbTHGiQ)
     SoYKDycdgmfjPhlMzkOewRBCbTHGin=SoYKDycdgmfjPhlMzkOewRBCbTHGiI
     SoYKDycdgmfjPhlMzkOewRBCbTHGiA =SoYKDycdgmfjPhlMzkOewRBCbTHGQE['replayVod']['count']
     SoYKDycdgmfjPhlMzkOewRBCbTHGiV=SoYKDycdgmfjPhlMzkOewRBCbTHGQE['highlightVod']['count']
     SoYKDycdgmfjPhlMzkOewRBCbTHGit =SoYKDycdgmfjPhlMzkOewRBCbTHGQE['vods']['count']
     SoYKDycdgmfjPhlMzkOewRBCbTHGns='' 
     SoYKDycdgmfjPhlMzkOewRBCbTHGip=SoYKDycdgmfjPhlMzkOewRBCbTHGiA+SoYKDycdgmfjPhlMzkOewRBCbTHGiV+SoYKDycdgmfjPhlMzkOewRBCbTHGit
     if SoYKDycdgmfjPhlMzkOewRBCbTHGip==0:
      if SoYKDycdgmfjPhlMzkOewRBCbTHGnW=='2':
       SoYKDycdgmfjPhlMzkOewRBCbTHGIU='----- %s -----'%(SoYKDycdgmfjPhlMzkOewRBCbTHGnr)
       SoYKDycdgmfjPhlMzkOewRBCbTHGnU=''
      else:
       SoYKDycdgmfjPhlMzkOewRBCbTHGIU+=' - 관련영상 없음'
       SoYKDycdgmfjPhlMzkOewRBCbTHGin+='\n\n ** 관련영상 없음 **'
     else:
      if SoYKDycdgmfjPhlMzkOewRBCbTHGiA!=0:
       SoYKDycdgmfjPhlMzkOewRBCbTHGns =SoYKDycdgmfjPhlMzkOewRBCbTHGQE['replayVod']['list'][0]['imgUrl']
      elif SoYKDycdgmfjPhlMzkOewRBCbTHGiV!=0:
       SoYKDycdgmfjPhlMzkOewRBCbTHGns =SoYKDycdgmfjPhlMzkOewRBCbTHGQE['highlightVod']['list'][0]['imgUrl']
      else:
       SoYKDycdgmfjPhlMzkOewRBCbTHGns =SoYKDycdgmfjPhlMzkOewRBCbTHGQE['vods']['list'][0]['imgUrl']
     SoYKDycdgmfjPhlMzkOewRBCbTHGQu={'gameTitle':SoYKDycdgmfjPhlMzkOewRBCbTHGIU,'gameId':SoYKDycdgmfjPhlMzkOewRBCbTHGnE,'beginDate':SoYKDycdgmfjPhlMzkOewRBCbTHGnU[:11],'thumbnail':SoYKDycdgmfjPhlMzkOewRBCbTHGns,'info_plot':SoYKDycdgmfjPhlMzkOewRBCbTHGin,'leaguenm':SoYKDycdgmfjPhlMzkOewRBCbTHGnu,'seasonnm':SoYKDycdgmfjPhlMzkOewRBCbTHGnr,'roundnm':SoYKDycdgmfjPhlMzkOewRBCbTHGnF,'totVodCnt':SoYKDycdgmfjPhlMzkOewRBCbTHGip}
     SoYKDycdgmfjPhlMzkOewRBCbTHGQv.append(SoYKDycdgmfjPhlMzkOewRBCbTHGQu)
  except SoYKDycdgmfjPhlMzkOewRBCbTHGiu as exception:
   SoYKDycdgmfjPhlMzkOewRBCbTHGir(exception)
  if SoYKDycdgmfjPhlMzkOewRBCbTHGQI['count']>page_int*SoYKDycdgmfjPhlMzkOewRBCbTHGJn.GAMELIST_LIMIT:SoYKDycdgmfjPhlMzkOewRBCbTHGnq=SoYKDycdgmfjPhlMzkOewRBCbTHGiU
  return SoYKDycdgmfjPhlMzkOewRBCbTHGQv,SoYKDycdgmfjPhlMzkOewRBCbTHGnq
 def GetGameVodList(SoYKDycdgmfjPhlMzkOewRBCbTHGJn,SoYKDycdgmfjPhlMzkOewRBCbTHGnE,vodCount=1000):
  SoYKDycdgmfjPhlMzkOewRBCbTHGQv=[]
  SoYKDycdgmfjPhlMzkOewRBCbTHGis=''
  try:
   SoYKDycdgmfjPhlMzkOewRBCbTHGJv=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.API_DOMAIN+'/api/v3/vod/game'
   SoYKDycdgmfjPhlMzkOewRBCbTHGnX={'gameId':SoYKDycdgmfjPhlMzkOewRBCbTHGnE,'pageItem':SoYKDycdgmfjPhlMzkOewRBCbTHGiF(vodCount)}
   SoYKDycdgmfjPhlMzkOewRBCbTHGJU=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.callRequestCookies('Get',SoYKDycdgmfjPhlMzkOewRBCbTHGJv,payload=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,params=SoYKDycdgmfjPhlMzkOewRBCbTHGnX,headers=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,cookies=SoYKDycdgmfjPhlMzkOewRBCbTHGiL)
   SoYKDycdgmfjPhlMzkOewRBCbTHGQI=json.loads(SoYKDycdgmfjPhlMzkOewRBCbTHGJU.text)
   SoYKDycdgmfjPhlMzkOewRBCbTHGnv=SoYKDycdgmfjPhlMzkOewRBCbTHGQI['list']
   for SoYKDycdgmfjPhlMzkOewRBCbTHGQE in SoYKDycdgmfjPhlMzkOewRBCbTHGnv:
    SoYKDycdgmfjPhlMzkOewRBCbTHGnV =SoYKDycdgmfjPhlMzkOewRBCbTHGQE['title']
    SoYKDycdgmfjPhlMzkOewRBCbTHGnt =SoYKDycdgmfjPhlMzkOewRBCbTHGQE['id']
    SoYKDycdgmfjPhlMzkOewRBCbTHGnp =SoYKDycdgmfjPhlMzkOewRBCbTHGQE['vtype']
    SoYKDycdgmfjPhlMzkOewRBCbTHGns =SoYKDycdgmfjPhlMzkOewRBCbTHGQE['imgUrl']
    SoYKDycdgmfjPhlMzkOewRBCbTHGna =SoYKDycdgmfjPhlMzkOewRBCbTHGQE['vtypeId']
    SoYKDycdgmfjPhlMzkOewRBCbTHGia =SoYKDycdgmfjPhlMzkOewRBCbTHGQE['isFree']
    SoYKDycdgmfjPhlMzkOewRBCbTHGQu={'vodTitle':SoYKDycdgmfjPhlMzkOewRBCbTHGnV,'vodId':SoYKDycdgmfjPhlMzkOewRBCbTHGnt,'vodType':SoYKDycdgmfjPhlMzkOewRBCbTHGnp,'thumbnail':SoYKDycdgmfjPhlMzkOewRBCbTHGns,'vtypeId':SoYKDycdgmfjPhlMzkOewRBCbTHGiF(SoYKDycdgmfjPhlMzkOewRBCbTHGna),'duration':SoYKDycdgmfjPhlMzkOewRBCbTHGiE(SoYKDycdgmfjPhlMzkOewRBCbTHGQE['duration']/1000),'isFree':SoYKDycdgmfjPhlMzkOewRBCbTHGia}
    SoYKDycdgmfjPhlMzkOewRBCbTHGQv.append(SoYKDycdgmfjPhlMzkOewRBCbTHGQu)
  except SoYKDycdgmfjPhlMzkOewRBCbTHGiu as exception:
   SoYKDycdgmfjPhlMzkOewRBCbTHGir(exception)
  return SoYKDycdgmfjPhlMzkOewRBCbTHGQv
 def GetReplay_UrlId(SoYKDycdgmfjPhlMzkOewRBCbTHGJn,SoYKDycdgmfjPhlMzkOewRBCbTHGis,SoYKDycdgmfjPhlMzkOewRBCbTHGna):
  SoYKDycdgmfjPhlMzkOewRBCbTHGiq=''
  try:
   SoYKDycdgmfjPhlMzkOewRBCbTHGJv=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.API_DOMAIN+'/api/v3/vod/'+SoYKDycdgmfjPhlMzkOewRBCbTHGis
   SoYKDycdgmfjPhlMzkOewRBCbTHGJU=SoYKDycdgmfjPhlMzkOewRBCbTHGJn.callRequestCookies('Get',SoYKDycdgmfjPhlMzkOewRBCbTHGJv,payload=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,params=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,headers=SoYKDycdgmfjPhlMzkOewRBCbTHGiL,cookies=SoYKDycdgmfjPhlMzkOewRBCbTHGiL)
   SoYKDycdgmfjPhlMzkOewRBCbTHGQI=json.loads(SoYKDycdgmfjPhlMzkOewRBCbTHGJU.text)
   SoYKDycdgmfjPhlMzkOewRBCbTHGiq=SoYKDycdgmfjPhlMzkOewRBCbTHGQI['videoId']
  except SoYKDycdgmfjPhlMzkOewRBCbTHGiu as exception:
   SoYKDycdgmfjPhlMzkOewRBCbTHGir(exception)
  return SoYKDycdgmfjPhlMzkOewRBCbTHGiq
# Created by pyminifier (https://github.com/liftoff/pyminifier)
