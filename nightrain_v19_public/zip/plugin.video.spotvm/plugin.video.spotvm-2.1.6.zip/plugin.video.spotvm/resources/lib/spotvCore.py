__author__="NightRain"
aTHfUyKYtIiAopGxOsqQlnzMLbXVvF=False
aTHfUyKYtIiAopGxOsqQlnzMLbXVvk=object
aTHfUyKYtIiAopGxOsqQlnzMLbXVvg=None
aTHfUyKYtIiAopGxOsqQlnzMLbXVvh=print
aTHfUyKYtIiAopGxOsqQlnzMLbXVvd=str
aTHfUyKYtIiAopGxOsqQlnzMLbXVvN=True
aTHfUyKYtIiAopGxOsqQlnzMLbXVvE=Exception
aTHfUyKYtIiAopGxOsqQlnzMLbXVvc=int
aTHfUyKYtIiAopGxOsqQlnzMLbXVvD=len
aTHfUyKYtIiAopGxOsqQlnzMLbXVvu=range
import urllib
import re
import json
import sys
import time
import requests
import datetime
import base64
aTHfUyKYtIiAopGxOsqQlnzMLbXVPS={'stream50':1080,'stream40':720,'stream30':540}
aTHfUyKYtIiAopGxOsqQlnzMLbXVPr=[{'name':'NOW','videoId':'ch_spotvnow1','epgtype':'spotvon','epgnm':'spotvon','free':aTHfUyKYtIiAopGxOsqQlnzMLbXVvF,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/ccdb36ce757afc1ca15fc38357d498e4.png'},{'name':'NOW2','videoId':'ch_spotvnow2','epgtype':'spotvon','epgnm':'spotvon2','free':aTHfUyKYtIiAopGxOsqQlnzMLbXVvF,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/8b6bdf6213a715eeba719b2cb9b2c747.png'},{'name':'NBA TV','videoId':'ch_nbatv','epgtype':'-','epgnm':'-','free':aTHfUyKYtIiAopGxOsqQlnzMLbXVvF,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/5036e56d5c6594ea606f7159f59779fe.png'},{'name':'SPOTV','videoId':'ch_spotv','epgtype':'spotvnet','epgnm':'SPOTV','free':aTHfUyKYtIiAopGxOsqQlnzMLbXVvF,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/56688c2e527c6e1b8d68e338057a7dfc.png'},{'name':'SPOTV2','videoId':'ch_spotv2','epgtype':'spotvnet','epgnm':'SPOTV2','free':aTHfUyKYtIiAopGxOsqQlnzMLbXVvF,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20201209/ca6e7a213c84e629985e609ddcda6b17.png'},{'name':'SPOTV Golf & Health','videoId':'ch_spotvplus','epgtype':'spotvnet','epgnm':'SPOTVP','free':aTHfUyKYtIiAopGxOsqQlnzMLbXVvF,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/7aa87953f1211313c3e110cace2628ff.png'},]
aTHfUyKYtIiAopGxOsqQlnzMLbXVPv={'ch_spotvnow1':{'lv':'abf18bbf3b3f4a0db4a41dd2af7f75c6','rv':'__nn__=5981484117001&hdnea=st=1609407000~exp=1609410600~acl=/abf18bbf3b3f4a0db4a41dd2af7f75c6/ap-northeast-1/5764318566001/*~hmac=e28a244d1b6b77d4e0101010816d4cd6ca89d9d31fe6a5290039d2395d81bc03'},'ch_spotvnow2':{'lv':'3054522000fc4d60aabe23d6e5911275','rv':'__nn__=5981484117001&hdnea=st=1609408800~exp=1609412400~acl=/3054522000fc4d60aabe23d6e5911275/ap-northeast-1/5764318566001/*~hmac=323b2deea8e3455fa77405f37b19231c6f0b48a5690b7218df875171ac2d6be6'},'ch_nbatv':{'lv':'31f99a0a6067413ea1b390c41a5c12be','rv':'__nn__=5981484117001&hdnea=st=1609408800~exp=1609412400~acl=/31f99a0a6067413ea1b390c41a5c12be/ap-northeast-1/5764318566001/*~hmac=b7ac24bc4772e3ad2669000919058bba64a6f001c69c8846341c326b089c306c'},'ch_spotv':{'lv':'1f2651c2fea34be9850bfdedf8d9cfdb','rv':'__nn__=5981484117001&hdnea=st=1609408800~exp=1609412400~acl=/1f2651c2fea34be9850bfdedf8d9cfdb/ap-northeast-1/5764318566001/*~hmac=e1f6c44d1be5459cfc40af1e1b204ac9b513bb7405e070da2bff8f115f298133'},'ch_spotv2':{'lv':'7bf3fb8685854892b01e1fc897e7e9b0','rv':'__nn__=5981484117001&hdnea=st=1609408800~exp=1609412400~acl=/7bf3fb8685854892b01e1fc897e7e9b0/ap-northeast-1/5764318566001/*~hmac=e9bb30991cfab98b1976aacabafcd51b63769ede40148f7cc289ffed15398e81'},'ch_spotvplus':{'lv':'242b2b6c0c654f47a07f4e2420f9c184','rv':'__nn__=5981484117001&hdnea=st=1609408800~exp=1609412400~acl=/242b2b6c0c654f47a07f4e2420f9c184/ap-northeast-1/5764318566001/*~hmac=5e4ce0553e709eb60d880bf37bc2e99661767b0a38ecee037fb4d7dce757b922'},}
class aTHfUyKYtIiAopGxOsqQlnzMLbXVPC(aTHfUyKYtIiAopGxOsqQlnzMLbXVvk):
 def __init__(aTHfUyKYtIiAopGxOsqQlnzMLbXVPj):
  aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.SPOTV_SESSIONID=''
  aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.SPOTV_SESSION =''
  aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.SPOTV_ACCOUNTID=''
  aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.SPOTV_POLICYKEY=''
  aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.SPOTV_SUBEND =''
  aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.SPOTV_PMCODE ='987'
  aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.SPOTV_PMSIZE =3
  aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.GAMELIST_LIMIT =10
  aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.API_DOMAIN ='https://www.spotvnow.co.kr'
  aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.BC_DOMAIN ='https://players.brightcove.net'
  aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.PLAYER_DOMAIN ='https://edge.api.brightcove.com'
  aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.STREAM_DOMAIN ='https://gtm-spotv.brightcovecdn.com'
  aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.STREAM_M3U8 ='ap-northeast-1/5764318566001/playlist_dvr'
  aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36'
  aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.DEFAULT_HEADER ={'user-agent':aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.USER_AGENT}
 def callRequestCookies(aTHfUyKYtIiAopGxOsqQlnzMLbXVPj,jobtype,aTHfUyKYtIiAopGxOsqQlnzMLbXVCR,payload=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,params=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,headers=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,cookies=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,redirects=aTHfUyKYtIiAopGxOsqQlnzMLbXVvF):
  aTHfUyKYtIiAopGxOsqQlnzMLbXVPm=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.DEFAULT_HEADER
  if headers:aTHfUyKYtIiAopGxOsqQlnzMLbXVPm.update(headers)
  if jobtype=='Get':
   aTHfUyKYtIiAopGxOsqQlnzMLbXVPW=requests.get(aTHfUyKYtIiAopGxOsqQlnzMLbXVCR,params=params,headers=aTHfUyKYtIiAopGxOsqQlnzMLbXVPm,cookies=cookies,allow_redirects=redirects)
  else:
   aTHfUyKYtIiAopGxOsqQlnzMLbXVPW=requests.post(aTHfUyKYtIiAopGxOsqQlnzMLbXVCR,data=payload,params=params,headers=aTHfUyKYtIiAopGxOsqQlnzMLbXVPm,cookies=cookies,allow_redirects=redirects)
  return aTHfUyKYtIiAopGxOsqQlnzMLbXVPW
 def makeDefaultCookies(aTHfUyKYtIiAopGxOsqQlnzMLbXVPj):
  aTHfUyKYtIiAopGxOsqQlnzMLbXVPR={'SESSION':aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.SPOTV_SESSION}
  return aTHfUyKYtIiAopGxOsqQlnzMLbXVPR
 def xmlText(aTHfUyKYtIiAopGxOsqQlnzMLbXVPj,in_text):
  aTHfUyKYtIiAopGxOsqQlnzMLbXVPJ=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;')
  return aTHfUyKYtIiAopGxOsqQlnzMLbXVPJ
 def GetCredential(aTHfUyKYtIiAopGxOsqQlnzMLbXVPj,user_id,user_pw):
  aTHfUyKYtIiAopGxOsqQlnzMLbXVPB=aTHfUyKYtIiAopGxOsqQlnzMLbXVvF
  aTHfUyKYtIiAopGxOsqQlnzMLbXVPe=aTHfUyKYtIiAopGxOsqQlnzMLbXVPN=aTHfUyKYtIiAopGxOsqQlnzMLbXVPD=aTHfUyKYtIiAopGxOsqQlnzMLbXVPu=aTHfUyKYtIiAopGxOsqQlnzMLbXVPc=''
  try:
   aTHfUyKYtIiAopGxOsqQlnzMLbXVPw=base64.standard_b64encode(user_id.encode("UTF-8")).decode('utf-8')
   aTHfUyKYtIiAopGxOsqQlnzMLbXVPF=base64.standard_b64encode(user_pw.encode("UTF-8")).decode('utf-8')
   aTHfUyKYtIiAopGxOsqQlnzMLbXVPk=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.API_DOMAIN+'/api/v2/login'
   aTHfUyKYtIiAopGxOsqQlnzMLbXVPg={'username':aTHfUyKYtIiAopGxOsqQlnzMLbXVPw,'password':aTHfUyKYtIiAopGxOsqQlnzMLbXVPF}
   aTHfUyKYtIiAopGxOsqQlnzMLbXVPg=json.dumps(aTHfUyKYtIiAopGxOsqQlnzMLbXVPg)
   aTHfUyKYtIiAopGxOsqQlnzMLbXVPh=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.callRequestCookies('Post',aTHfUyKYtIiAopGxOsqQlnzMLbXVPk,payload=aTHfUyKYtIiAopGxOsqQlnzMLbXVPg,params=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,headers=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,cookies=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg)
   aTHfUyKYtIiAopGxOsqQlnzMLbXVvh(aTHfUyKYtIiAopGxOsqQlnzMLbXVPh.status_code)
   for aTHfUyKYtIiAopGxOsqQlnzMLbXVPd in aTHfUyKYtIiAopGxOsqQlnzMLbXVPh.cookies:
    if aTHfUyKYtIiAopGxOsqQlnzMLbXVPd.name=='SESSION':
     aTHfUyKYtIiAopGxOsqQlnzMLbXVPN=aTHfUyKYtIiAopGxOsqQlnzMLbXVPd.value
     break
   if aTHfUyKYtIiAopGxOsqQlnzMLbXVPN=='':return aTHfUyKYtIiAopGxOsqQlnzMLbXVPB
   aTHfUyKYtIiAopGxOsqQlnzMLbXVPE=json.loads(aTHfUyKYtIiAopGxOsqQlnzMLbXVPh.text)
   if not('userId' in aTHfUyKYtIiAopGxOsqQlnzMLbXVPE):return aTHfUyKYtIiAopGxOsqQlnzMLbXVPB
   aTHfUyKYtIiAopGxOsqQlnzMLbXVPe=aTHfUyKYtIiAopGxOsqQlnzMLbXVvd(aTHfUyKYtIiAopGxOsqQlnzMLbXVPE['userId'])
   aTHfUyKYtIiAopGxOsqQlnzMLbXVPc =aTHfUyKYtIiAopGxOsqQlnzMLbXVvd(aTHfUyKYtIiAopGxOsqQlnzMLbXVPE['subEndTime'])
   aTHfUyKYtIiAopGxOsqQlnzMLbXVPD,aTHfUyKYtIiAopGxOsqQlnzMLbXVPu=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.GetPolicyKey()
   if aTHfUyKYtIiAopGxOsqQlnzMLbXVPu=='':return aTHfUyKYtIiAopGxOsqQlnzMLbXVPB
   aTHfUyKYtIiAopGxOsqQlnzMLbXVPB=aTHfUyKYtIiAopGxOsqQlnzMLbXVvN
  except aTHfUyKYtIiAopGxOsqQlnzMLbXVvE as exception:
   aTHfUyKYtIiAopGxOsqQlnzMLbXVPe=aTHfUyKYtIiAopGxOsqQlnzMLbXVPN='' 
   aTHfUyKYtIiAopGxOsqQlnzMLbXVvh(exception)
  aTHfUyKYtIiAopGxOsqQlnzMLbXVCP={'spotv_sessionid':aTHfUyKYtIiAopGxOsqQlnzMLbXVPe,'spotv_session':aTHfUyKYtIiAopGxOsqQlnzMLbXVPN,'spotv_accountId':aTHfUyKYtIiAopGxOsqQlnzMLbXVPD,'spotv_policyKey':aTHfUyKYtIiAopGxOsqQlnzMLbXVPu,'spotv_subend':aTHfUyKYtIiAopGxOsqQlnzMLbXVPc}
  aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.SaveCredential(aTHfUyKYtIiAopGxOsqQlnzMLbXVCP)
  return aTHfUyKYtIiAopGxOsqQlnzMLbXVPB
 def SaveCredential(aTHfUyKYtIiAopGxOsqQlnzMLbXVPj,aTHfUyKYtIiAopGxOsqQlnzMLbXVCP):
  aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.SPOTV_SESSIONID=aTHfUyKYtIiAopGxOsqQlnzMLbXVCP.get('spotv_sessionid')
  aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.SPOTV_SESSION =aTHfUyKYtIiAopGxOsqQlnzMLbXVCP.get('spotv_session')
  aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.SPOTV_ACCOUNTID=aTHfUyKYtIiAopGxOsqQlnzMLbXVCP.get('spotv_accountId')
  aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.SPOTV_POLICYKEY=aTHfUyKYtIiAopGxOsqQlnzMLbXVCP.get('spotv_policyKey')
  aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.SPOTV_SUBEND =aTHfUyKYtIiAopGxOsqQlnzMLbXVCP.get('spotv_subend')
 def LoadCredential(aTHfUyKYtIiAopGxOsqQlnzMLbXVPj):
  aTHfUyKYtIiAopGxOsqQlnzMLbXVCP={'spotv_sessionid':aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.SPOTV_SESSIONID,'spotv_session':aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.SPOTV_SESSION,'spotv_accountId':aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.SPOTV_ACCOUNTID,'spotv_policyKey':aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.SPOTV_POLICYKEY,'spotv_subend':aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.SPOTV_SUBEND}
  return aTHfUyKYtIiAopGxOsqQlnzMLbXVCP
 def Get_Now_Datetime(aTHfUyKYtIiAopGxOsqQlnzMLbXVPj):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_Streamurl_Make(aTHfUyKYtIiAopGxOsqQlnzMLbXVPj,aTHfUyKYtIiAopGxOsqQlnzMLbXVSW):
  aTHfUyKYtIiAopGxOsqQlnzMLbXVCr='%s/%s/%s.m3u8?%s'%(aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.STREAM_DOMAIN,aTHfUyKYtIiAopGxOsqQlnzMLbXVPv.get(aTHfUyKYtIiAopGxOsqQlnzMLbXVSW).get('lv'),aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.STREAM_M3U8,aTHfUyKYtIiAopGxOsqQlnzMLbXVPv.get(aTHfUyKYtIiAopGxOsqQlnzMLbXVSW).get('rv'))
  return aTHfUyKYtIiAopGxOsqQlnzMLbXVCr
 def GetLiveChannelList(aTHfUyKYtIiAopGxOsqQlnzMLbXVPj):
  aTHfUyKYtIiAopGxOsqQlnzMLbXVCv=[]
  aTHfUyKYtIiAopGxOsqQlnzMLbXVCj ={}
  try:
   aTHfUyKYtIiAopGxOsqQlnzMLbXVCj=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.GetEPGList_new()
   for aTHfUyKYtIiAopGxOsqQlnzMLbXVCm in aTHfUyKYtIiAopGxOsqQlnzMLbXVPr:
    aTHfUyKYtIiAopGxOsqQlnzMLbXVCW={'name':aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['name'],'logo':aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['logo'],'videoId':aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['videoId'],'free':aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['free'],'channelepg':aTHfUyKYtIiAopGxOsqQlnzMLbXVCj.get(aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['videoId'])}
    aTHfUyKYtIiAopGxOsqQlnzMLbXVCv.append(aTHfUyKYtIiAopGxOsqQlnzMLbXVCW)
  except aTHfUyKYtIiAopGxOsqQlnzMLbXVvE as exception:
   aTHfUyKYtIiAopGxOsqQlnzMLbXVvh(exception)
  return aTHfUyKYtIiAopGxOsqQlnzMLbXVCv
 def CheckLiveChannel(aTHfUyKYtIiAopGxOsqQlnzMLbXVPj,aTHfUyKYtIiAopGxOsqQlnzMLbXVCE):
  try:
   aTHfUyKYtIiAopGxOsqQlnzMLbXVCR=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.API_DOMAIN+'/api/v2/channel'
   aTHfUyKYtIiAopGxOsqQlnzMLbXVPh=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.callRequestCookies('Get',aTHfUyKYtIiAopGxOsqQlnzMLbXVCR,payload=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,params=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,headers=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,cookies=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg)
   aTHfUyKYtIiAopGxOsqQlnzMLbXVPE=json.loads(aTHfUyKYtIiAopGxOsqQlnzMLbXVPh.text)
   for aTHfUyKYtIiAopGxOsqQlnzMLbXVCm in aTHfUyKYtIiAopGxOsqQlnzMLbXVPE:
    if aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['videoId'].replace('ref:','')==aTHfUyKYtIiAopGxOsqQlnzMLbXVCE:
     return aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['free']
  except aTHfUyKYtIiAopGxOsqQlnzMLbXVvE as exception:
   aTHfUyKYtIiAopGxOsqQlnzMLbXVvh(exception)
  return aTHfUyKYtIiAopGxOsqQlnzMLbXVvF
 def GetEPGList(aTHfUyKYtIiAopGxOsqQlnzMLbXVPj):
  aTHfUyKYtIiAopGxOsqQlnzMLbXVCJ={}
  aTHfUyKYtIiAopGxOsqQlnzMLbXVCB=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.Get_Now_Datetime()
  aTHfUyKYtIiAopGxOsqQlnzMLbXVCe=aTHfUyKYtIiAopGxOsqQlnzMLbXVCB.strftime('%Y%m%d%H%M')
  aTHfUyKYtIiAopGxOsqQlnzMLbXVCw='%s-%s-%s'%(aTHfUyKYtIiAopGxOsqQlnzMLbXVCe[0:4],aTHfUyKYtIiAopGxOsqQlnzMLbXVCe[4:6],aTHfUyKYtIiAopGxOsqQlnzMLbXVCe[6:8])
  aTHfUyKYtIiAopGxOsqQlnzMLbXVCF=(aTHfUyKYtIiAopGxOsqQlnzMLbXVCB+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M')
  try:
   aTHfUyKYtIiAopGxOsqQlnzMLbXVCR=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.API_DOMAIN+'/api/v2/program/'+aTHfUyKYtIiAopGxOsqQlnzMLbXVCw
   aTHfUyKYtIiAopGxOsqQlnzMLbXVPh=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.callRequestCookies('Get',aTHfUyKYtIiAopGxOsqQlnzMLbXVCR,payload=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,params=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,headers=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,cookies=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg)
   aTHfUyKYtIiAopGxOsqQlnzMLbXVPE=json.loads(aTHfUyKYtIiAopGxOsqQlnzMLbXVPh.text)
   aTHfUyKYtIiAopGxOsqQlnzMLbXVCk=-1 
   aTHfUyKYtIiAopGxOsqQlnzMLbXVCg =''
   for aTHfUyKYtIiAopGxOsqQlnzMLbXVCm in aTHfUyKYtIiAopGxOsqQlnzMLbXVPE:
    aTHfUyKYtIiAopGxOsqQlnzMLbXVCh=aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['channelId']
    aTHfUyKYtIiAopGxOsqQlnzMLbXVCd =aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['startTime'].replace('-','').replace(' ','').replace(':','')
    aTHfUyKYtIiAopGxOsqQlnzMLbXVCN =aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['endTime'].replace('-','').replace(' ','').replace(':','')
    if aTHfUyKYtIiAopGxOsqQlnzMLbXVvc(aTHfUyKYtIiAopGxOsqQlnzMLbXVCe)>aTHfUyKYtIiAopGxOsqQlnzMLbXVvc(aTHfUyKYtIiAopGxOsqQlnzMLbXVCN) :continue
    if aTHfUyKYtIiAopGxOsqQlnzMLbXVvc(aTHfUyKYtIiAopGxOsqQlnzMLbXVCF)<aTHfUyKYtIiAopGxOsqQlnzMLbXVvc(aTHfUyKYtIiAopGxOsqQlnzMLbXVCd):continue
    if aTHfUyKYtIiAopGxOsqQlnzMLbXVCk!=aTHfUyKYtIiAopGxOsqQlnzMLbXVCh:
     if aTHfUyKYtIiAopGxOsqQlnzMLbXVCg!='':aTHfUyKYtIiAopGxOsqQlnzMLbXVCJ[aTHfUyKYtIiAopGxOsqQlnzMLbXVCk]=aTHfUyKYtIiAopGxOsqQlnzMLbXVCg
     aTHfUyKYtIiAopGxOsqQlnzMLbXVCk=aTHfUyKYtIiAopGxOsqQlnzMLbXVCh
     aTHfUyKYtIiAopGxOsqQlnzMLbXVCg =''
    if aTHfUyKYtIiAopGxOsqQlnzMLbXVCg:aTHfUyKYtIiAopGxOsqQlnzMLbXVCg+='\n'
    aTHfUyKYtIiAopGxOsqQlnzMLbXVCg+=aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['title']+'\n'
    aTHfUyKYtIiAopGxOsqQlnzMLbXVCg+=' [%s ~ %s]'%(aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['startTime'][-5:],aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['endTime'][-5:])+'\n'
   if aTHfUyKYtIiAopGxOsqQlnzMLbXVCg:aTHfUyKYtIiAopGxOsqQlnzMLbXVCJ[aTHfUyKYtIiAopGxOsqQlnzMLbXVCk]=aTHfUyKYtIiAopGxOsqQlnzMLbXVCg
  except aTHfUyKYtIiAopGxOsqQlnzMLbXVvE as exception:
   aTHfUyKYtIiAopGxOsqQlnzMLbXVvh(exception)
  return aTHfUyKYtIiAopGxOsqQlnzMLbXVCJ
 def GetEPGList_new(aTHfUyKYtIiAopGxOsqQlnzMLbXVPj):
  aTHfUyKYtIiAopGxOsqQlnzMLbXVCJ={}
  aTHfUyKYtIiAopGxOsqQlnzMLbXVCB=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.Get_Now_Datetime()
  aTHfUyKYtIiAopGxOsqQlnzMLbXVCe=aTHfUyKYtIiAopGxOsqQlnzMLbXVCB.strftime('%Y%m%d%H%M00')
  aTHfUyKYtIiAopGxOsqQlnzMLbXVCw='%s%s%s'%(aTHfUyKYtIiAopGxOsqQlnzMLbXVCe[0:4],aTHfUyKYtIiAopGxOsqQlnzMLbXVCe[4:6],aTHfUyKYtIiAopGxOsqQlnzMLbXVCe[6:8])
  aTHfUyKYtIiAopGxOsqQlnzMLbXVCF=(aTHfUyKYtIiAopGxOsqQlnzMLbXVCB+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M00')
  try:
   for aTHfUyKYtIiAopGxOsqQlnzMLbXVCm in aTHfUyKYtIiAopGxOsqQlnzMLbXVPr:
    aTHfUyKYtIiAopGxOsqQlnzMLbXVCE =aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['videoId']
    if aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['epgtype']=='spotvon':
     aTHfUyKYtIiAopGxOsqQlnzMLbXVCg=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.Get_EpgInfo_Spotv_spotvon(aTHfUyKYtIiAopGxOsqQlnzMLbXVCE,aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['epgnm'],aTHfUyKYtIiAopGxOsqQlnzMLbXVCw)
     aTHfUyKYtIiAopGxOsqQlnzMLbXVCJ[aTHfUyKYtIiAopGxOsqQlnzMLbXVCE]=aTHfUyKYtIiAopGxOsqQlnzMLbXVCg
    if aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['epgtype']=='spotvnet':
     aTHfUyKYtIiAopGxOsqQlnzMLbXVCg=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.Get_EpgInfo_Spotv_spotvnet(aTHfUyKYtIiAopGxOsqQlnzMLbXVCE,aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['epgnm'],aTHfUyKYtIiAopGxOsqQlnzMLbXVCw)
     aTHfUyKYtIiAopGxOsqQlnzMLbXVCJ[aTHfUyKYtIiAopGxOsqQlnzMLbXVCE]=aTHfUyKYtIiAopGxOsqQlnzMLbXVCg
   for aTHfUyKYtIiAopGxOsqQlnzMLbXVCc in aTHfUyKYtIiAopGxOsqQlnzMLbXVCJ.keys():
    if aTHfUyKYtIiAopGxOsqQlnzMLbXVvD(aTHfUyKYtIiAopGxOsqQlnzMLbXVCJ.get(aTHfUyKYtIiAopGxOsqQlnzMLbXVCc))==0:continue
    aTHfUyKYtIiAopGxOsqQlnzMLbXVCg =''
    aTHfUyKYtIiAopGxOsqQlnzMLbXVCD=''
    for aTHfUyKYtIiAopGxOsqQlnzMLbXVCu in aTHfUyKYtIiAopGxOsqQlnzMLbXVCJ.get(aTHfUyKYtIiAopGxOsqQlnzMLbXVCc):
     aTHfUyKYtIiAopGxOsqQlnzMLbXVCd =aTHfUyKYtIiAopGxOsqQlnzMLbXVCu['startTime']
     aTHfUyKYtIiAopGxOsqQlnzMLbXVCN =aTHfUyKYtIiAopGxOsqQlnzMLbXVCu['endTime']
     if aTHfUyKYtIiAopGxOsqQlnzMLbXVvc(aTHfUyKYtIiAopGxOsqQlnzMLbXVCe)>aTHfUyKYtIiAopGxOsqQlnzMLbXVvc(aTHfUyKYtIiAopGxOsqQlnzMLbXVCN) :continue
     if aTHfUyKYtIiAopGxOsqQlnzMLbXVvc(aTHfUyKYtIiAopGxOsqQlnzMLbXVCF)<aTHfUyKYtIiAopGxOsqQlnzMLbXVvc(aTHfUyKYtIiAopGxOsqQlnzMLbXVCd):continue
     if aTHfUyKYtIiAopGxOsqQlnzMLbXVvc(aTHfUyKYtIiAopGxOsqQlnzMLbXVCe)>=aTHfUyKYtIiAopGxOsqQlnzMLbXVvc(aTHfUyKYtIiAopGxOsqQlnzMLbXVCd)and aTHfUyKYtIiAopGxOsqQlnzMLbXVvc(aTHfUyKYtIiAopGxOsqQlnzMLbXVCe)<aTHfUyKYtIiAopGxOsqQlnzMLbXVvc(aTHfUyKYtIiAopGxOsqQlnzMLbXVCN):aTHfUyKYtIiAopGxOsqQlnzMLbXVCD=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.xmlText(aTHfUyKYtIiAopGxOsqQlnzMLbXVCu['title'])
     if aTHfUyKYtIiAopGxOsqQlnzMLbXVCg:aTHfUyKYtIiAopGxOsqQlnzMLbXVCg+='\n'
     aTHfUyKYtIiAopGxOsqQlnzMLbXVCg+=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.xmlText(aTHfUyKYtIiAopGxOsqQlnzMLbXVCu['title'])+'\n'
     aTHfUyKYtIiAopGxOsqQlnzMLbXVCg+=' [%s:%s ~ %s:%s]'%(aTHfUyKYtIiAopGxOsqQlnzMLbXVCu['startTime'][8:10],aTHfUyKYtIiAopGxOsqQlnzMLbXVCu['startTime'][10:12],aTHfUyKYtIiAopGxOsqQlnzMLbXVCu['endTime'][8:10],aTHfUyKYtIiAopGxOsqQlnzMLbXVCu['endTime'][10:12])+'\n'
    aTHfUyKYtIiAopGxOsqQlnzMLbXVCJ[aTHfUyKYtIiAopGxOsqQlnzMLbXVCc]={'epg':aTHfUyKYtIiAopGxOsqQlnzMLbXVCg,'title':aTHfUyKYtIiAopGxOsqQlnzMLbXVCD}
  except aTHfUyKYtIiAopGxOsqQlnzMLbXVvE as exception:
   aTHfUyKYtIiAopGxOsqQlnzMLbXVvh(exception)
  return aTHfUyKYtIiAopGxOsqQlnzMLbXVCJ
 def Get_EpgInfo_Spotv_spotvon(aTHfUyKYtIiAopGxOsqQlnzMLbXVPj,aTHfUyKYtIiAopGxOsqQlnzMLbXVCE,epgnm,now_day):
  aTHfUyKYtIiAopGxOsqQlnzMLbXVCJ =[]
  try:
   aTHfUyKYtIiAopGxOsqQlnzMLbXVCR='https://www.spotvon.co.kr/data/onAir/%s/Daily/D%s.asp'%(epgnm,now_day)
   aTHfUyKYtIiAopGxOsqQlnzMLbXVPh=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.callRequestCookies('Get',aTHfUyKYtIiAopGxOsqQlnzMLbXVCR,payload=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,params=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,headers=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,cookies=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg)
   aTHfUyKYtIiAopGxOsqQlnzMLbXVSP=json.loads(aTHfUyKYtIiAopGxOsqQlnzMLbXVPh.text)
   for aTHfUyKYtIiAopGxOsqQlnzMLbXVCm in aTHfUyKYtIiAopGxOsqQlnzMLbXVSP:
    aTHfUyKYtIiAopGxOsqQlnzMLbXVCW={'title':aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['title'],'startTime':aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['sch_date'].replace('-','')+aTHfUyKYtIiAopGxOsqQlnzMLbXVvd(aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['sch_hour']).zfill(2)+aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['sch_min']+'00'}
    aTHfUyKYtIiAopGxOsqQlnzMLbXVCJ.append(aTHfUyKYtIiAopGxOsqQlnzMLbXVCW)
   for i in aTHfUyKYtIiAopGxOsqQlnzMLbXVvu(aTHfUyKYtIiAopGxOsqQlnzMLbXVvD(aTHfUyKYtIiAopGxOsqQlnzMLbXVCJ)):
    if i>0:aTHfUyKYtIiAopGxOsqQlnzMLbXVCJ[i-1]['endTime']=aTHfUyKYtIiAopGxOsqQlnzMLbXVCJ[i]['startTime']
    if i==aTHfUyKYtIiAopGxOsqQlnzMLbXVvD(aTHfUyKYtIiAopGxOsqQlnzMLbXVCJ)-1: aTHfUyKYtIiAopGxOsqQlnzMLbXVCJ[i]['endTime']=now_day+'240000'
  except aTHfUyKYtIiAopGxOsqQlnzMLbXVvE as exception:
   aTHfUyKYtIiAopGxOsqQlnzMLbXVvh(exception)
   return[]
  return aTHfUyKYtIiAopGxOsqQlnzMLbXVCJ
 def Get_EpgInfo_Spotv_spotvnet(aTHfUyKYtIiAopGxOsqQlnzMLbXVPj,aTHfUyKYtIiAopGxOsqQlnzMLbXVCE,epgnm,now_day):
  aTHfUyKYtIiAopGxOsqQlnzMLbXVCJ =[]
  try:
   aTHfUyKYtIiAopGxOsqQlnzMLbXVCR='https://www.spotv.net/data/json/schedule/%s/Daily/D%s.json'%(epgnm,now_day)
   aTHfUyKYtIiAopGxOsqQlnzMLbXVPh=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.callRequestCookies('Get',aTHfUyKYtIiAopGxOsqQlnzMLbXVCR,payload=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,params=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,headers=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,cookies=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg)
   aTHfUyKYtIiAopGxOsqQlnzMLbXVSP=json.loads(aTHfUyKYtIiAopGxOsqQlnzMLbXVPh.text)
   for aTHfUyKYtIiAopGxOsqQlnzMLbXVCm in aTHfUyKYtIiAopGxOsqQlnzMLbXVSP:
    aTHfUyKYtIiAopGxOsqQlnzMLbXVCW={'title':aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['title'],'startTime':aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['sch_date'].replace('-','')+aTHfUyKYtIiAopGxOsqQlnzMLbXVvd(aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['sch_hour']).zfill(2)+aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['sch_min']+'00'}
    aTHfUyKYtIiAopGxOsqQlnzMLbXVCJ.append(aTHfUyKYtIiAopGxOsqQlnzMLbXVCW)
   for i in aTHfUyKYtIiAopGxOsqQlnzMLbXVvu(aTHfUyKYtIiAopGxOsqQlnzMLbXVvD(aTHfUyKYtIiAopGxOsqQlnzMLbXVCJ)):
    if i>0:aTHfUyKYtIiAopGxOsqQlnzMLbXVCJ[i-1]['endTime']=aTHfUyKYtIiAopGxOsqQlnzMLbXVCJ[i]['startTime']
    if i==aTHfUyKYtIiAopGxOsqQlnzMLbXVvD(aTHfUyKYtIiAopGxOsqQlnzMLbXVCJ)-1: aTHfUyKYtIiAopGxOsqQlnzMLbXVCJ[i]['endTime']=now_day+'240000'
  except aTHfUyKYtIiAopGxOsqQlnzMLbXVvE as exception:
   aTHfUyKYtIiAopGxOsqQlnzMLbXVvh(exception)
   return[]
  return aTHfUyKYtIiAopGxOsqQlnzMLbXVCJ
 def GetEventLiveList(aTHfUyKYtIiAopGxOsqQlnzMLbXVPj):
  aTHfUyKYtIiAopGxOsqQlnzMLbXVCv=[]
  aTHfUyKYtIiAopGxOsqQlnzMLbXVSC =0
  try:
   aTHfUyKYtIiAopGxOsqQlnzMLbXVSr=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.Get_Now_Datetime()
   aTHfUyKYtIiAopGxOsqQlnzMLbXVSv=aTHfUyKYtIiAopGxOsqQlnzMLbXVSr.strftime('%Y-%m-%d')
  except aTHfUyKYtIiAopGxOsqQlnzMLbXVvE as exception:
   aTHfUyKYtIiAopGxOsqQlnzMLbXVvh(exception)
   return aTHfUyKYtIiAopGxOsqQlnzMLbXVCv,aTHfUyKYtIiAopGxOsqQlnzMLbXVSC
  try:
   aTHfUyKYtIiAopGxOsqQlnzMLbXVCR=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.API_DOMAIN+'/api/v2/player/lives/'+aTHfUyKYtIiAopGxOsqQlnzMLbXVSv 
   aTHfUyKYtIiAopGxOsqQlnzMLbXVPR=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.makeDefaultCookies()
   aTHfUyKYtIiAopGxOsqQlnzMLbXVPh=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.callRequestCookies('Get',aTHfUyKYtIiAopGxOsqQlnzMLbXVCR,payload=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,params=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,headers=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,cookies=aTHfUyKYtIiAopGxOsqQlnzMLbXVPR)
   aTHfUyKYtIiAopGxOsqQlnzMLbXVSC=aTHfUyKYtIiAopGxOsqQlnzMLbXVPh.status_code 
   aTHfUyKYtIiAopGxOsqQlnzMLbXVPE=json.loads(aTHfUyKYtIiAopGxOsqQlnzMLbXVPh.text)
   for aTHfUyKYtIiAopGxOsqQlnzMLbXVSj in aTHfUyKYtIiAopGxOsqQlnzMLbXVPE:
    for aTHfUyKYtIiAopGxOsqQlnzMLbXVCm in aTHfUyKYtIiAopGxOsqQlnzMLbXVSj['liveNowList']:
     if aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['gameDesc']['title']==aTHfUyKYtIiAopGxOsqQlnzMLbXVvg or aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['gameDesc']['title']=='':
      aTHfUyKYtIiAopGxOsqQlnzMLbXVSm='%s ( %s : %s )'%(aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['leagueName'],aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['homeNameShort'],aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['awayNameShort'])
     else:
      aTHfUyKYtIiAopGxOsqQlnzMLbXVSm=aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['gameDesc']['title']
     aTHfUyKYtIiAopGxOsqQlnzMLbXVCW={'liveId':aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['liveId'],'title':aTHfUyKYtIiAopGxOsqQlnzMLbXVSm,'logo':aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['gameDesc']['leagueLogo'],'free':aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['isFree'],'startTime':aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['startTime']}
     aTHfUyKYtIiAopGxOsqQlnzMLbXVCv.append(aTHfUyKYtIiAopGxOsqQlnzMLbXVCW)
  except aTHfUyKYtIiAopGxOsqQlnzMLbXVvE as exception:
   aTHfUyKYtIiAopGxOsqQlnzMLbXVvh(exception)
  return aTHfUyKYtIiAopGxOsqQlnzMLbXVCv,aTHfUyKYtIiAopGxOsqQlnzMLbXVSC
 def GetEventLive_videoId(aTHfUyKYtIiAopGxOsqQlnzMLbXVPj,liveId):
  aTHfUyKYtIiAopGxOsqQlnzMLbXVSW=''
  try:
   aTHfUyKYtIiAopGxOsqQlnzMLbXVCR=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.API_DOMAIN+'/api/v2/live/'+liveId
   aTHfUyKYtIiAopGxOsqQlnzMLbXVPh=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.callRequestCookies('Get',aTHfUyKYtIiAopGxOsqQlnzMLbXVCR,payload=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,params=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,headers=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,cookies=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg)
   aTHfUyKYtIiAopGxOsqQlnzMLbXVPE=json.loads(aTHfUyKYtIiAopGxOsqQlnzMLbXVPh.text)
   aTHfUyKYtIiAopGxOsqQlnzMLbXVSR=aTHfUyKYtIiAopGxOsqQlnzMLbXVPE['videoId']
   aTHfUyKYtIiAopGxOsqQlnzMLbXVSW=aTHfUyKYtIiAopGxOsqQlnzMLbXVSR.replace('ref:','')
  except aTHfUyKYtIiAopGxOsqQlnzMLbXVvE as exception:
   aTHfUyKYtIiAopGxOsqQlnzMLbXVvh(exception)
  return aTHfUyKYtIiAopGxOsqQlnzMLbXVSW
 def CheckMainEnd(aTHfUyKYtIiAopGxOsqQlnzMLbXVPj):
  aTHfUyKYtIiAopGxOsqQlnzMLbXVSJ=base64.standard_b64encode((aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.SPOTV_PMCODE+aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.SPOTV_SESSIONID).encode()).decode('utf-8')
  if aTHfUyKYtIiAopGxOsqQlnzMLbXVSJ=='OTg3MTgzMzM0Ng==' or aTHfUyKYtIiAopGxOsqQlnzMLbXVSJ=='OTg3MTgzMzExNw==':return aTHfUyKYtIiAopGxOsqQlnzMLbXVvN
  return aTHfUyKYtIiAopGxOsqQlnzMLbXVvF
 def CheckSubEnd(aTHfUyKYtIiAopGxOsqQlnzMLbXVPj):
  aTHfUyKYtIiAopGxOsqQlnzMLbXVSB=aTHfUyKYtIiAopGxOsqQlnzMLbXVvF
  try:
   if aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.CheckMainEnd():return aTHfUyKYtIiAopGxOsqQlnzMLbXVvN 
   if aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.SPOTV_SUBEND=='0':return aTHfUyKYtIiAopGxOsqQlnzMLbXVSB
   aTHfUyKYtIiAopGxOsqQlnzMLbXVSe =aTHfUyKYtIiAopGxOsqQlnzMLbXVvc(aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.Get_Now_Datetime().strftime('%Y%m%d'))
   aTHfUyKYtIiAopGxOsqQlnzMLbXVSw =aTHfUyKYtIiAopGxOsqQlnzMLbXVvc(aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.SPOTV_SUBEND)/1000
   aTHfUyKYtIiAopGxOsqQlnzMLbXVSF =aTHfUyKYtIiAopGxOsqQlnzMLbXVvc(datetime.datetime.fromtimestamp(aTHfUyKYtIiAopGxOsqQlnzMLbXVSw,datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul')).strftime('%Y%m%d'))
   if aTHfUyKYtIiAopGxOsqQlnzMLbXVSe<=aTHfUyKYtIiAopGxOsqQlnzMLbXVSF:aTHfUyKYtIiAopGxOsqQlnzMLbXVSB=aTHfUyKYtIiAopGxOsqQlnzMLbXVvN
  except aTHfUyKYtIiAopGxOsqQlnzMLbXVvE as exception:
   aTHfUyKYtIiAopGxOsqQlnzMLbXVvh(exception)
   return aTHfUyKYtIiAopGxOsqQlnzMLbXVSB
  return aTHfUyKYtIiAopGxOsqQlnzMLbXVSB
 def GetMainJspath(aTHfUyKYtIiAopGxOsqQlnzMLbXVPj):
  aTHfUyKYtIiAopGxOsqQlnzMLbXVSk=''
  try:
   aTHfUyKYtIiAopGxOsqQlnzMLbXVCR=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.API_DOMAIN
   aTHfUyKYtIiAopGxOsqQlnzMLbXVPh=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.callRequestCookies('Get',aTHfUyKYtIiAopGxOsqQlnzMLbXVCR,payload=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,params=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,headers=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,cookies=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg)
   aTHfUyKYtIiAopGxOsqQlnzMLbXVSg=aTHfUyKYtIiAopGxOsqQlnzMLbXVPh.text
   aTHfUyKYtIiAopGxOsqQlnzMLbXVSh =re.findall('https://cdn.spotvnow.co.kr/dist/js/.{20}\.js',aTHfUyKYtIiAopGxOsqQlnzMLbXVSg)[0]
   aTHfUyKYtIiAopGxOsqQlnzMLbXVSk=aTHfUyKYtIiAopGxOsqQlnzMLbXVSh
  except aTHfUyKYtIiAopGxOsqQlnzMLbXVvE as exception:
   aTHfUyKYtIiAopGxOsqQlnzMLbXVvh(exception)
  return aTHfUyKYtIiAopGxOsqQlnzMLbXVSk
 def GetBcPlayerUrl(aTHfUyKYtIiAopGxOsqQlnzMLbXVPj):
  aTHfUyKYtIiAopGxOsqQlnzMLbXVSd=''
  try:
   aTHfUyKYtIiAopGxOsqQlnzMLbXVCR=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.GetMainJspath()
   if aTHfUyKYtIiAopGxOsqQlnzMLbXVCR=='':return aTHfUyKYtIiAopGxOsqQlnzMLbXVSd
   aTHfUyKYtIiAopGxOsqQlnzMLbXVPh=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.callRequestCookies('Get',aTHfUyKYtIiAopGxOsqQlnzMLbXVCR,payload=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,params=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,headers=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,cookies=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg)
   aTHfUyKYtIiAopGxOsqQlnzMLbXVSg=aTHfUyKYtIiAopGxOsqQlnzMLbXVPh.text
   aTHfUyKYtIiAopGxOsqQlnzMLbXVSN =re.findall('bc:\s*\"\d{13}\",\s*player:\s*\".{9}\"',aTHfUyKYtIiAopGxOsqQlnzMLbXVSg)[0]
   aTHfUyKYtIiAopGxOsqQlnzMLbXVSN =aTHfUyKYtIiAopGxOsqQlnzMLbXVSN.replace('bc','"bc"')
   aTHfUyKYtIiAopGxOsqQlnzMLbXVSN =aTHfUyKYtIiAopGxOsqQlnzMLbXVSN.replace('player','"player"')
   aTHfUyKYtIiAopGxOsqQlnzMLbXVSN ='{'+aTHfUyKYtIiAopGxOsqQlnzMLbXVSN+'}'
   aTHfUyKYtIiAopGxOsqQlnzMLbXVSN =json.loads(aTHfUyKYtIiAopGxOsqQlnzMLbXVSN)
   bc =aTHfUyKYtIiAopGxOsqQlnzMLbXVSN['bc']
   aTHfUyKYtIiAopGxOsqQlnzMLbXVSE =aTHfUyKYtIiAopGxOsqQlnzMLbXVSN['player']
   aTHfUyKYtIiAopGxOsqQlnzMLbXVSd="%s/%s/%s_default/index.min.js"%(aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.BC_DOMAIN,bc,aTHfUyKYtIiAopGxOsqQlnzMLbXVSE)
  except aTHfUyKYtIiAopGxOsqQlnzMLbXVvE as exception:
   aTHfUyKYtIiAopGxOsqQlnzMLbXVvh(exception)
  return aTHfUyKYtIiAopGxOsqQlnzMLbXVSd
 def GetPolicyKey(aTHfUyKYtIiAopGxOsqQlnzMLbXVPj):
  aTHfUyKYtIiAopGxOsqQlnzMLbXVSc=policykey=''
  try:
   aTHfUyKYtIiAopGxOsqQlnzMLbXVCR=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.GetBcPlayerUrl()
   if aTHfUyKYtIiAopGxOsqQlnzMLbXVCR=='':return aTHfUyKYtIiAopGxOsqQlnzMLbXVSc,aTHfUyKYtIiAopGxOsqQlnzMLbXVSu
   aTHfUyKYtIiAopGxOsqQlnzMLbXVPh=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.callRequestCookies('Get',aTHfUyKYtIiAopGxOsqQlnzMLbXVCR,payload=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,params=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,headers=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,cookies=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg)
   aTHfUyKYtIiAopGxOsqQlnzMLbXVSg=aTHfUyKYtIiAopGxOsqQlnzMLbXVPh.text
   aTHfUyKYtIiAopGxOsqQlnzMLbXVSh =re.findall('accountId:\s*\"\d{13}\",\s*policyKey:\s*\".[^(){}]{100,300}\"',aTHfUyKYtIiAopGxOsqQlnzMLbXVSg)[0]
   aTHfUyKYtIiAopGxOsqQlnzMLbXVSh =aTHfUyKYtIiAopGxOsqQlnzMLbXVSh.replace('accountId','"accountId"')
   aTHfUyKYtIiAopGxOsqQlnzMLbXVSh =aTHfUyKYtIiAopGxOsqQlnzMLbXVSh.replace('policyKey','"policyKey"')
   aTHfUyKYtIiAopGxOsqQlnzMLbXVSh ='{'+aTHfUyKYtIiAopGxOsqQlnzMLbXVSh+'}'
   aTHfUyKYtIiAopGxOsqQlnzMLbXVSD=json.loads(aTHfUyKYtIiAopGxOsqQlnzMLbXVSh)
   aTHfUyKYtIiAopGxOsqQlnzMLbXVSc =aTHfUyKYtIiAopGxOsqQlnzMLbXVSD['accountId']
   aTHfUyKYtIiAopGxOsqQlnzMLbXVSu =aTHfUyKYtIiAopGxOsqQlnzMLbXVSD['policyKey']
  except aTHfUyKYtIiAopGxOsqQlnzMLbXVvE as exception:
   aTHfUyKYtIiAopGxOsqQlnzMLbXVvh(exception)
  return aTHfUyKYtIiAopGxOsqQlnzMLbXVSc,aTHfUyKYtIiAopGxOsqQlnzMLbXVSu
 def GetBroadURL(aTHfUyKYtIiAopGxOsqQlnzMLbXVPj,aTHfUyKYtIiAopGxOsqQlnzMLbXVSW,mediatype,aTHfUyKYtIiAopGxOsqQlnzMLbXVre):
  aTHfUyKYtIiAopGxOsqQlnzMLbXVrP=''
  try:
   if mediatype=='live':
    aTHfUyKYtIiAopGxOsqQlnzMLbXVSW='ref%3A'+aTHfUyKYtIiAopGxOsqQlnzMLbXVSW
   else:
    aTHfUyKYtIiAopGxOsqQlnzMLbXVSW=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.GetReplay_UrlId(aTHfUyKYtIiAopGxOsqQlnzMLbXVSW,aTHfUyKYtIiAopGxOsqQlnzMLbXVre)
    if aTHfUyKYtIiAopGxOsqQlnzMLbXVSW=='':return aTHfUyKYtIiAopGxOsqQlnzMLbXVrP
   aTHfUyKYtIiAopGxOsqQlnzMLbXVCR=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.PLAYER_DOMAIN+'/playback/v1/accounts/'+aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.SPOTV_ACCOUNTID+'/videos/'+aTHfUyKYtIiAopGxOsqQlnzMLbXVSW
   aTHfUyKYtIiAopGxOsqQlnzMLbXVrC={'accept':'application/json;pk='+aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.SPOTV_POLICYKEY}
   aTHfUyKYtIiAopGxOsqQlnzMLbXVPh=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.callRequestCookies('Get',aTHfUyKYtIiAopGxOsqQlnzMLbXVCR,payload=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,params=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,headers=aTHfUyKYtIiAopGxOsqQlnzMLbXVrC,cookies=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg)
   aTHfUyKYtIiAopGxOsqQlnzMLbXVSP=json.loads(aTHfUyKYtIiAopGxOsqQlnzMLbXVPh.text)
   aTHfUyKYtIiAopGxOsqQlnzMLbXVrP=aTHfUyKYtIiAopGxOsqQlnzMLbXVSP['sources'][0]['src']
   if mediatype=='live':
    aTHfUyKYtIiAopGxOsqQlnzMLbXVrP=aTHfUyKYtIiAopGxOsqQlnzMLbXVrP.replace('playlist.m3u8','playlist_dvr.m3u8')
   aTHfUyKYtIiAopGxOsqQlnzMLbXVrP=aTHfUyKYtIiAopGxOsqQlnzMLbXVrP.replace('http://','https://')
  except aTHfUyKYtIiAopGxOsqQlnzMLbXVvE as exception:
   aTHfUyKYtIiAopGxOsqQlnzMLbXVvh(exception)
  return aTHfUyKYtIiAopGxOsqQlnzMLbXVrP
 def GetTitleGroupList(aTHfUyKYtIiAopGxOsqQlnzMLbXVPj):
  aTHfUyKYtIiAopGxOsqQlnzMLbXVCv=[]
  aTHfUyKYtIiAopGxOsqQlnzMLbXVrS=aTHfUyKYtIiAopGxOsqQlnzMLbXVvF
  try:
   aTHfUyKYtIiAopGxOsqQlnzMLbXVCR=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.API_DOMAIN+'/api/v2/home/web'
   aTHfUyKYtIiAopGxOsqQlnzMLbXVPh=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.callRequestCookies('Get',aTHfUyKYtIiAopGxOsqQlnzMLbXVCR,payload=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,params=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,headers=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,cookies=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg)
   aTHfUyKYtIiAopGxOsqQlnzMLbXVPE=json.loads(aTHfUyKYtIiAopGxOsqQlnzMLbXVPh.text)
   for aTHfUyKYtIiAopGxOsqQlnzMLbXVCm in aTHfUyKYtIiAopGxOsqQlnzMLbXVPE:
    if aTHfUyKYtIiAopGxOsqQlnzMLbXVvd(aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['type'])=='3':
     aTHfUyKYtIiAopGxOsqQlnzMLbXVrv=''
     for aTHfUyKYtIiAopGxOsqQlnzMLbXVrj in aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['data']['list']:
      aTHfUyKYtIiAopGxOsqQlnzMLbXVrm='[%s] %s vs %s\n<%s>\n\n'%(aTHfUyKYtIiAopGxOsqQlnzMLbXVrj['gameDesc']['roundName'],aTHfUyKYtIiAopGxOsqQlnzMLbXVrj['gameDesc']['homeNameShort'],aTHfUyKYtIiAopGxOsqQlnzMLbXVrj['gameDesc']['awayNameShort'],aTHfUyKYtIiAopGxOsqQlnzMLbXVrj['gameDesc']['beginDate'])
      aTHfUyKYtIiAopGxOsqQlnzMLbXVrv+=aTHfUyKYtIiAopGxOsqQlnzMLbXVrm
     aTHfUyKYtIiAopGxOsqQlnzMLbXVCW={'title':aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['title'],'logo':aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['logo'],'reagueId':aTHfUyKYtIiAopGxOsqQlnzMLbXVvd(aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['destId']),'subGame':aTHfUyKYtIiAopGxOsqQlnzMLbXVrv}
     aTHfUyKYtIiAopGxOsqQlnzMLbXVCv.append(aTHfUyKYtIiAopGxOsqQlnzMLbXVCW)
     if aTHfUyKYtIiAopGxOsqQlnzMLbXVvd(aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['destId'])=='13':aTHfUyKYtIiAopGxOsqQlnzMLbXVrS=aTHfUyKYtIiAopGxOsqQlnzMLbXVvN
   if aTHfUyKYtIiAopGxOsqQlnzMLbXVrS==aTHfUyKYtIiAopGxOsqQlnzMLbXVvF:
    aTHfUyKYtIiAopGxOsqQlnzMLbXVCW={'title':'UFC','logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200928/a643c7cf1c285fb0b4469c07d4c09c28.png','reagueId':'13','subGame':''}
    aTHfUyKYtIiAopGxOsqQlnzMLbXVCv.append(aTHfUyKYtIiAopGxOsqQlnzMLbXVCW)
  except aTHfUyKYtIiAopGxOsqQlnzMLbXVvE as exception:
   aTHfUyKYtIiAopGxOsqQlnzMLbXVvh(exception)
  return aTHfUyKYtIiAopGxOsqQlnzMLbXVCv
 def GetPopularGroupList(aTHfUyKYtIiAopGxOsqQlnzMLbXVPj):
  aTHfUyKYtIiAopGxOsqQlnzMLbXVCv=[]
  try:
   aTHfUyKYtIiAopGxOsqQlnzMLbXVCR=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.API_DOMAIN+'/api/v2/home/web'
   aTHfUyKYtIiAopGxOsqQlnzMLbXVPh=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.callRequestCookies('Get',aTHfUyKYtIiAopGxOsqQlnzMLbXVCR,payload=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,params=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,headers=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,cookies=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg)
   aTHfUyKYtIiAopGxOsqQlnzMLbXVPE=json.loads(aTHfUyKYtIiAopGxOsqQlnzMLbXVPh.text)
   for aTHfUyKYtIiAopGxOsqQlnzMLbXVCm in aTHfUyKYtIiAopGxOsqQlnzMLbXVPE:
    if aTHfUyKYtIiAopGxOsqQlnzMLbXVvd(aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['type'])=='1' and aTHfUyKYtIiAopGxOsqQlnzMLbXVvd(aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['destId'])=='4':
     for aTHfUyKYtIiAopGxOsqQlnzMLbXVrj in aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['data']['list']:
      aTHfUyKYtIiAopGxOsqQlnzMLbXVrW =aTHfUyKYtIiAopGxOsqQlnzMLbXVrj['title']
      aTHfUyKYtIiAopGxOsqQlnzMLbXVrR =aTHfUyKYtIiAopGxOsqQlnzMLbXVrj['id']
      aTHfUyKYtIiAopGxOsqQlnzMLbXVrJ =aTHfUyKYtIiAopGxOsqQlnzMLbXVrj['vtype']
      aTHfUyKYtIiAopGxOsqQlnzMLbXVrB =aTHfUyKYtIiAopGxOsqQlnzMLbXVrj['imgUrl']
      aTHfUyKYtIiAopGxOsqQlnzMLbXVre =aTHfUyKYtIiAopGxOsqQlnzMLbXVrj['vtypeId']
      aTHfUyKYtIiAopGxOsqQlnzMLbXVCW={'vodTitle':aTHfUyKYtIiAopGxOsqQlnzMLbXVrW,'vodId':aTHfUyKYtIiAopGxOsqQlnzMLbXVrR,'vodType':aTHfUyKYtIiAopGxOsqQlnzMLbXVrJ,'thumbnail':aTHfUyKYtIiAopGxOsqQlnzMLbXVrB,'vtypeId':aTHfUyKYtIiAopGxOsqQlnzMLbXVvd(aTHfUyKYtIiAopGxOsqQlnzMLbXVre),'duration':aTHfUyKYtIiAopGxOsqQlnzMLbXVvc(aTHfUyKYtIiAopGxOsqQlnzMLbXVrj['duration']/1000)}
      aTHfUyKYtIiAopGxOsqQlnzMLbXVCv.append(aTHfUyKYtIiAopGxOsqQlnzMLbXVCW)
  except aTHfUyKYtIiAopGxOsqQlnzMLbXVvE as exception:
   aTHfUyKYtIiAopGxOsqQlnzMLbXVvh(exception)
  return aTHfUyKYtIiAopGxOsqQlnzMLbXVCv
 def GetSeasonList(aTHfUyKYtIiAopGxOsqQlnzMLbXVPj,leagueId):
  aTHfUyKYtIiAopGxOsqQlnzMLbXVCv=[]
  aTHfUyKYtIiAopGxOsqQlnzMLbXVrw=aTHfUyKYtIiAopGxOsqQlnzMLbXVrF=''
  try:
   aTHfUyKYtIiAopGxOsqQlnzMLbXVCR=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.API_DOMAIN+'/api/v2/game/league/'+leagueId
   aTHfUyKYtIiAopGxOsqQlnzMLbXVPh=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.callRequestCookies('Get',aTHfUyKYtIiAopGxOsqQlnzMLbXVCR,payload=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,params=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,headers=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,cookies=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg)
   aTHfUyKYtIiAopGxOsqQlnzMLbXVPE=json.loads(aTHfUyKYtIiAopGxOsqQlnzMLbXVPh.text)
   aTHfUyKYtIiAopGxOsqQlnzMLbXVrw=aTHfUyKYtIiAopGxOsqQlnzMLbXVPE['name']
   aTHfUyKYtIiAopGxOsqQlnzMLbXVrF=aTHfUyKYtIiAopGxOsqQlnzMLbXVvd(aTHfUyKYtIiAopGxOsqQlnzMLbXVPE['gameTypeId'])
  except aTHfUyKYtIiAopGxOsqQlnzMLbXVvE as exception:
   aTHfUyKYtIiAopGxOsqQlnzMLbXVvh(exception)
   return aTHfUyKYtIiAopGxOsqQlnzMLbXVCv
  if aTHfUyKYtIiAopGxOsqQlnzMLbXVrF=='2':
   try:
    aTHfUyKYtIiAopGxOsqQlnzMLbXVCR=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.API_DOMAIN+'/api/v2/year/'+leagueId
    aTHfUyKYtIiAopGxOsqQlnzMLbXVPh=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.callRequestCookies('Get',aTHfUyKYtIiAopGxOsqQlnzMLbXVCR,payload=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,params=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,headers=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,cookies=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg)
    aTHfUyKYtIiAopGxOsqQlnzMLbXVPE=json.loads(aTHfUyKYtIiAopGxOsqQlnzMLbXVPh.text)
    for aTHfUyKYtIiAopGxOsqQlnzMLbXVCm in aTHfUyKYtIiAopGxOsqQlnzMLbXVPE:
     aTHfUyKYtIiAopGxOsqQlnzMLbXVCW={'reagueName':aTHfUyKYtIiAopGxOsqQlnzMLbXVrw,'gameTypeId':aTHfUyKYtIiAopGxOsqQlnzMLbXVrF,'seasonName':aTHfUyKYtIiAopGxOsqQlnzMLbXVvd(aTHfUyKYtIiAopGxOsqQlnzMLbXVCm),'seasonId':aTHfUyKYtIiAopGxOsqQlnzMLbXVvd(aTHfUyKYtIiAopGxOsqQlnzMLbXVCm)}
     aTHfUyKYtIiAopGxOsqQlnzMLbXVCv.append(aTHfUyKYtIiAopGxOsqQlnzMLbXVCW)
   except aTHfUyKYtIiAopGxOsqQlnzMLbXVvE as exception:
    aTHfUyKYtIiAopGxOsqQlnzMLbXVvh(exception)
    return[]
  else:
   try:
    aTHfUyKYtIiAopGxOsqQlnzMLbXVCR=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.API_DOMAIN+'/api/v2/season/'+leagueId
    aTHfUyKYtIiAopGxOsqQlnzMLbXVPh=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.callRequestCookies('Get',aTHfUyKYtIiAopGxOsqQlnzMLbXVCR,payload=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,params=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,headers=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,cookies=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg)
    aTHfUyKYtIiAopGxOsqQlnzMLbXVPE=json.loads(aTHfUyKYtIiAopGxOsqQlnzMLbXVPh.text)
    for aTHfUyKYtIiAopGxOsqQlnzMLbXVCm in aTHfUyKYtIiAopGxOsqQlnzMLbXVPE:
     aTHfUyKYtIiAopGxOsqQlnzMLbXVCW={'reagueName':aTHfUyKYtIiAopGxOsqQlnzMLbXVrw,'gameTypeId':aTHfUyKYtIiAopGxOsqQlnzMLbXVrF,'seasonName':aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['name'],'seasonId':aTHfUyKYtIiAopGxOsqQlnzMLbXVvd(aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['id'])}
     aTHfUyKYtIiAopGxOsqQlnzMLbXVCv.append(aTHfUyKYtIiAopGxOsqQlnzMLbXVCW)
   except aTHfUyKYtIiAopGxOsqQlnzMLbXVvE as exception:
    aTHfUyKYtIiAopGxOsqQlnzMLbXVvh(exception)
    return[]
  return aTHfUyKYtIiAopGxOsqQlnzMLbXVCv
 def GetGameList(aTHfUyKYtIiAopGxOsqQlnzMLbXVPj,aTHfUyKYtIiAopGxOsqQlnzMLbXVrF,leagueId,seasonId,page_int,hidescore=aTHfUyKYtIiAopGxOsqQlnzMLbXVvN):
  aTHfUyKYtIiAopGxOsqQlnzMLbXVCv=[]
  aTHfUyKYtIiAopGxOsqQlnzMLbXVrk=aTHfUyKYtIiAopGxOsqQlnzMLbXVvF
  try:
   aTHfUyKYtIiAopGxOsqQlnzMLbXVCR=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.API_DOMAIN+'/api/v2/vod/league/detail'
   aTHfUyKYtIiAopGxOsqQlnzMLbXVrg={'gameType':aTHfUyKYtIiAopGxOsqQlnzMLbXVrF,'leagueId':leagueId,'seasonId':seasonId if aTHfUyKYtIiAopGxOsqQlnzMLbXVrF!='2' else '','teamId':'','roundId':'','year':'' if aTHfUyKYtIiAopGxOsqQlnzMLbXVrF!='2' else seasonId,'pageNo':aTHfUyKYtIiAopGxOsqQlnzMLbXVvd(page_int)}
   aTHfUyKYtIiAopGxOsqQlnzMLbXVPh=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.callRequestCookies('Get',aTHfUyKYtIiAopGxOsqQlnzMLbXVCR,payload=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,params=aTHfUyKYtIiAopGxOsqQlnzMLbXVrg,headers=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,cookies=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg)
   aTHfUyKYtIiAopGxOsqQlnzMLbXVPE=json.loads(aTHfUyKYtIiAopGxOsqQlnzMLbXVPh.text)
   aTHfUyKYtIiAopGxOsqQlnzMLbXVSj=aTHfUyKYtIiAopGxOsqQlnzMLbXVPE['list']
   for aTHfUyKYtIiAopGxOsqQlnzMLbXVrh in aTHfUyKYtIiAopGxOsqQlnzMLbXVSj:
    for aTHfUyKYtIiAopGxOsqQlnzMLbXVCm in aTHfUyKYtIiAopGxOsqQlnzMLbXVrh['list']:
     if aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['gameDesc']['title']==aTHfUyKYtIiAopGxOsqQlnzMLbXVvg or aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['gameDesc']['title']=='':
      aTHfUyKYtIiAopGxOsqQlnzMLbXVSm ='%s vs %s'%(aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['gameDesc']['homeNameShort'],aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['gameDesc']['awayNameShort'])
     else:
      aTHfUyKYtIiAopGxOsqQlnzMLbXVSm =aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['gameDesc']['title']
     aTHfUyKYtIiAopGxOsqQlnzMLbXVrd =aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['gameDesc']['beginDate']
     aTHfUyKYtIiAopGxOsqQlnzMLbXVrN =aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['gameDesc']['id']
     aTHfUyKYtIiAopGxOsqQlnzMLbXVrE =aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['gameDesc']['leagueNameFull']
     aTHfUyKYtIiAopGxOsqQlnzMLbXVrc =aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['gameDesc']['seasonName']
     aTHfUyKYtIiAopGxOsqQlnzMLbXVrD =aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['gameDesc']['roundName']
     aTHfUyKYtIiAopGxOsqQlnzMLbXVru =aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['gameDesc']['homeName']
     aTHfUyKYtIiAopGxOsqQlnzMLbXVvP =aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['gameDesc']['awayName']
     aTHfUyKYtIiAopGxOsqQlnzMLbXVvC =aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['gameDesc']['homeScore']
     aTHfUyKYtIiAopGxOsqQlnzMLbXVvS =aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['gameDesc']['awayScore']
     if hidescore==aTHfUyKYtIiAopGxOsqQlnzMLbXVvN:
      aTHfUyKYtIiAopGxOsqQlnzMLbXVvr ='%s\n - %s (%s)\n - %s\n\nhome : %s\n\naway : %s'%(aTHfUyKYtIiAopGxOsqQlnzMLbXVrE,aTHfUyKYtIiAopGxOsqQlnzMLbXVrc,aTHfUyKYtIiAopGxOsqQlnzMLbXVrD,aTHfUyKYtIiAopGxOsqQlnzMLbXVrd,aTHfUyKYtIiAopGxOsqQlnzMLbXVru,aTHfUyKYtIiAopGxOsqQlnzMLbXVvP)
     else:
      aTHfUyKYtIiAopGxOsqQlnzMLbXVvr ='%s\n - %s (%s)\n - %s\n\nhome : %s (Score %s)\n\naway : %s (Score %s)'%(aTHfUyKYtIiAopGxOsqQlnzMLbXVrE,aTHfUyKYtIiAopGxOsqQlnzMLbXVrc,aTHfUyKYtIiAopGxOsqQlnzMLbXVrD,aTHfUyKYtIiAopGxOsqQlnzMLbXVrd,aTHfUyKYtIiAopGxOsqQlnzMLbXVru,aTHfUyKYtIiAopGxOsqQlnzMLbXVvC,aTHfUyKYtIiAopGxOsqQlnzMLbXVvP,aTHfUyKYtIiAopGxOsqQlnzMLbXVvS)
     aTHfUyKYtIiAopGxOsqQlnzMLbXVvj=aTHfUyKYtIiAopGxOsqQlnzMLbXVvr
     aTHfUyKYtIiAopGxOsqQlnzMLbXVvm =aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['replayVod']['count']
     aTHfUyKYtIiAopGxOsqQlnzMLbXVvW=aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['highlightVod']['count']
     aTHfUyKYtIiAopGxOsqQlnzMLbXVvR =aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['vods']['count']
     aTHfUyKYtIiAopGxOsqQlnzMLbXVrB='' 
     aTHfUyKYtIiAopGxOsqQlnzMLbXVvJ=aTHfUyKYtIiAopGxOsqQlnzMLbXVvm+aTHfUyKYtIiAopGxOsqQlnzMLbXVvW+aTHfUyKYtIiAopGxOsqQlnzMLbXVvR
     if aTHfUyKYtIiAopGxOsqQlnzMLbXVvJ==0:
      if aTHfUyKYtIiAopGxOsqQlnzMLbXVrF=='2':
       aTHfUyKYtIiAopGxOsqQlnzMLbXVSm='----- %s -----'%(aTHfUyKYtIiAopGxOsqQlnzMLbXVrc)
       aTHfUyKYtIiAopGxOsqQlnzMLbXVrd=''
      else:
       aTHfUyKYtIiAopGxOsqQlnzMLbXVSm+=' - 관련영상 없음'
       aTHfUyKYtIiAopGxOsqQlnzMLbXVvj+='\n\n ** 관련영상 없음 **'
     else:
      if aTHfUyKYtIiAopGxOsqQlnzMLbXVvm!=0:
       aTHfUyKYtIiAopGxOsqQlnzMLbXVrB =aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['replayVod']['list'][0]['imgUrl']
      elif aTHfUyKYtIiAopGxOsqQlnzMLbXVvW!=0:
       aTHfUyKYtIiAopGxOsqQlnzMLbXVrB =aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['highlightVod']['list'][0]['imgUrl']
      else:
       aTHfUyKYtIiAopGxOsqQlnzMLbXVrB =aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['vods']['list'][0]['imgUrl']
     aTHfUyKYtIiAopGxOsqQlnzMLbXVCW={'gameTitle':aTHfUyKYtIiAopGxOsqQlnzMLbXVSm,'gameId':aTHfUyKYtIiAopGxOsqQlnzMLbXVrN,'beginDate':aTHfUyKYtIiAopGxOsqQlnzMLbXVrd[:11],'thumbnail':aTHfUyKYtIiAopGxOsqQlnzMLbXVrB,'info_plot':aTHfUyKYtIiAopGxOsqQlnzMLbXVvj,'leaguenm':aTHfUyKYtIiAopGxOsqQlnzMLbXVrE,'seasonnm':aTHfUyKYtIiAopGxOsqQlnzMLbXVrc,'roundnm':aTHfUyKYtIiAopGxOsqQlnzMLbXVrD,'totVodCnt':aTHfUyKYtIiAopGxOsqQlnzMLbXVvJ}
     aTHfUyKYtIiAopGxOsqQlnzMLbXVCv.append(aTHfUyKYtIiAopGxOsqQlnzMLbXVCW)
   if aTHfUyKYtIiAopGxOsqQlnzMLbXVrF=='2':
    if aTHfUyKYtIiAopGxOsqQlnzMLbXVPE['count']>page_int*aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.GAMELIST_LIMIT:aTHfUyKYtIiAopGxOsqQlnzMLbXVrk=aTHfUyKYtIiAopGxOsqQlnzMLbXVvN
   else:
    if aTHfUyKYtIiAopGxOsqQlnzMLbXVPE['list'][0]['count']>page_int*aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.GAMELIST_LIMIT:aTHfUyKYtIiAopGxOsqQlnzMLbXVrk=aTHfUyKYtIiAopGxOsqQlnzMLbXVvN
  except aTHfUyKYtIiAopGxOsqQlnzMLbXVvE as exception:
   aTHfUyKYtIiAopGxOsqQlnzMLbXVvh(exception)
  return aTHfUyKYtIiAopGxOsqQlnzMLbXVCv,aTHfUyKYtIiAopGxOsqQlnzMLbXVrk
 def GetGameVodList(aTHfUyKYtIiAopGxOsqQlnzMLbXVPj,aTHfUyKYtIiAopGxOsqQlnzMLbXVrN):
  aTHfUyKYtIiAopGxOsqQlnzMLbXVCv=[]
  aTHfUyKYtIiAopGxOsqQlnzMLbXVvB=''
  try:
   aTHfUyKYtIiAopGxOsqQlnzMLbXVCR=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.API_DOMAIN+'/api/v2/vod/game'
   aTHfUyKYtIiAopGxOsqQlnzMLbXVrg={'gameId':aTHfUyKYtIiAopGxOsqQlnzMLbXVrN,'pageItem':'1000'}
   aTHfUyKYtIiAopGxOsqQlnzMLbXVPh=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.callRequestCookies('Get',aTHfUyKYtIiAopGxOsqQlnzMLbXVCR,payload=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,params=aTHfUyKYtIiAopGxOsqQlnzMLbXVrg,headers=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,cookies=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg)
   aTHfUyKYtIiAopGxOsqQlnzMLbXVPE=json.loads(aTHfUyKYtIiAopGxOsqQlnzMLbXVPh.text)
   aTHfUyKYtIiAopGxOsqQlnzMLbXVrh=aTHfUyKYtIiAopGxOsqQlnzMLbXVPE['list']
   for aTHfUyKYtIiAopGxOsqQlnzMLbXVCm in aTHfUyKYtIiAopGxOsqQlnzMLbXVrh:
    aTHfUyKYtIiAopGxOsqQlnzMLbXVrW =aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['title']
    aTHfUyKYtIiAopGxOsqQlnzMLbXVrR =aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['id']
    aTHfUyKYtIiAopGxOsqQlnzMLbXVrJ =aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['vtype']
    aTHfUyKYtIiAopGxOsqQlnzMLbXVrB =aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['imgUrl']
    aTHfUyKYtIiAopGxOsqQlnzMLbXVre =aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['vtypeId']
    aTHfUyKYtIiAopGxOsqQlnzMLbXVCW={'vodTitle':aTHfUyKYtIiAopGxOsqQlnzMLbXVrW,'vodId':aTHfUyKYtIiAopGxOsqQlnzMLbXVrR,'vodType':aTHfUyKYtIiAopGxOsqQlnzMLbXVrJ,'thumbnail':aTHfUyKYtIiAopGxOsqQlnzMLbXVrB,'vtypeId':aTHfUyKYtIiAopGxOsqQlnzMLbXVvd(aTHfUyKYtIiAopGxOsqQlnzMLbXVre),'duration':aTHfUyKYtIiAopGxOsqQlnzMLbXVvc(aTHfUyKYtIiAopGxOsqQlnzMLbXVCm['duration']/1000)}
    aTHfUyKYtIiAopGxOsqQlnzMLbXVCv.append(aTHfUyKYtIiAopGxOsqQlnzMLbXVCW)
  except aTHfUyKYtIiAopGxOsqQlnzMLbXVvE as exception:
   aTHfUyKYtIiAopGxOsqQlnzMLbXVvh(exception)
  return aTHfUyKYtIiAopGxOsqQlnzMLbXVCv
 def GetReplay_UrlId(aTHfUyKYtIiAopGxOsqQlnzMLbXVPj,aTHfUyKYtIiAopGxOsqQlnzMLbXVvB,aTHfUyKYtIiAopGxOsqQlnzMLbXVre):
  aTHfUyKYtIiAopGxOsqQlnzMLbXVve=aTHfUyKYtIiAopGxOsqQlnzMLbXVSW=''
  aTHfUyKYtIiAopGxOsqQlnzMLbXVvw=''
  try:
   aTHfUyKYtIiAopGxOsqQlnzMLbXVCR=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.API_DOMAIN+'/api/v2/vod/'+aTHfUyKYtIiAopGxOsqQlnzMLbXVvB
   aTHfUyKYtIiAopGxOsqQlnzMLbXVPh=aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.callRequestCookies('Get',aTHfUyKYtIiAopGxOsqQlnzMLbXVCR,payload=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,params=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,headers=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg,cookies=aTHfUyKYtIiAopGxOsqQlnzMLbXVvg)
   aTHfUyKYtIiAopGxOsqQlnzMLbXVPE=json.loads(aTHfUyKYtIiAopGxOsqQlnzMLbXVPh.text)
   aTHfUyKYtIiAopGxOsqQlnzMLbXVve =aTHfUyKYtIiAopGxOsqQlnzMLbXVPE['clipId']
   aTHfUyKYtIiAopGxOsqQlnzMLbXVSW=aTHfUyKYtIiAopGxOsqQlnzMLbXVPE['videoId']
   aTHfUyKYtIiAopGxOsqQlnzMLbXVvw=aTHfUyKYtIiAopGxOsqQlnzMLbXVve
   if aTHfUyKYtIiAopGxOsqQlnzMLbXVPj.CheckSubEnd()or aTHfUyKYtIiAopGxOsqQlnzMLbXVre!='1':aTHfUyKYtIiAopGxOsqQlnzMLbXVvw=aTHfUyKYtIiAopGxOsqQlnzMLbXVSW 
  except aTHfUyKYtIiAopGxOsqQlnzMLbXVvE as exception:
   aTHfUyKYtIiAopGxOsqQlnzMLbXVvh(exception)
  return aTHfUyKYtIiAopGxOsqQlnzMLbXVvw
# Created by pyminifier (https://github.com/liftoff/pyminifier)
