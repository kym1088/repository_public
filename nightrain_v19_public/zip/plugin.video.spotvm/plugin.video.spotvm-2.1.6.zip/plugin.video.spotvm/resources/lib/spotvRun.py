__author__="NightRain"
fQoWwqIUKxbERdDljGspeLaHhJTPnC=object
fQoWwqIUKxbERdDljGspeLaHhJTPnz=None
fQoWwqIUKxbERdDljGspeLaHhJTPnr=False
fQoWwqIUKxbERdDljGspeLaHhJTPnt=True
fQoWwqIUKxbERdDljGspeLaHhJTPnA=int
fQoWwqIUKxbERdDljGspeLaHhJTPnV=len
fQoWwqIUKxbERdDljGspeLaHhJTPni=str
fQoWwqIUKxbERdDljGspeLaHhJTPnk=open
fQoWwqIUKxbERdDljGspeLaHhJTPny=Exception
fQoWwqIUKxbERdDljGspeLaHhJTPnm=print
fQoWwqIUKxbERdDljGspeLaHhJTPnS=dict
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
fQoWwqIUKxbERdDljGspeLaHhJTPXc=[{'title':'Live중계 (경기중에만 재생)','mode':'ELIVE_GROUP','icon':'live.png'},{'title':'-----------------','mode':'XXX'},{'title':'인기영상5','mode':'POP_GROUP'},{'title':'VOD 영상','mode':'VOD_GROUP'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH','icon':'history.png'},]
fQoWwqIUKxbERdDljGspeLaHhJTPXN=xbmcvfs.translatePath(os.path.join(__profile__,'spotv_cookies.json'))
from spotvCore import*
class fQoWwqIUKxbERdDljGspeLaHhJTPXM(fQoWwqIUKxbERdDljGspeLaHhJTPnC):
 def __init__(fQoWwqIUKxbERdDljGspeLaHhJTPXn,fQoWwqIUKxbERdDljGspeLaHhJTPXB,fQoWwqIUKxbERdDljGspeLaHhJTPXu,fQoWwqIUKxbERdDljGspeLaHhJTPXO):
  fQoWwqIUKxbERdDljGspeLaHhJTPXn._addon_url =fQoWwqIUKxbERdDljGspeLaHhJTPXB
  fQoWwqIUKxbERdDljGspeLaHhJTPXn._addon_handle=fQoWwqIUKxbERdDljGspeLaHhJTPXu
  fQoWwqIUKxbERdDljGspeLaHhJTPXn.main_params =fQoWwqIUKxbERdDljGspeLaHhJTPXO
  fQoWwqIUKxbERdDljGspeLaHhJTPXn.SpotvObj =aTHfUyKYtIiAopGxOsqQlnzMLbXVPC() 
 def addon_noti(fQoWwqIUKxbERdDljGspeLaHhJTPXn,sting):
  try:
   fQoWwqIUKxbERdDljGspeLaHhJTPXg=xbmcgui.Dialog()
   fQoWwqIUKxbERdDljGspeLaHhJTPXg.notification(__addonname__,sting)
  except:
   fQoWwqIUKxbERdDljGspeLaHhJTPnz
 def addon_log(fQoWwqIUKxbERdDljGspeLaHhJTPXn,string):
  try:
   fQoWwqIUKxbERdDljGspeLaHhJTPXC=string.encode('utf-8','ignore')
  except:
   fQoWwqIUKxbERdDljGspeLaHhJTPXC='addonException: addon_log'
  fQoWwqIUKxbERdDljGspeLaHhJTPXz=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,fQoWwqIUKxbERdDljGspeLaHhJTPXC),level=fQoWwqIUKxbERdDljGspeLaHhJTPXz)
 def get_keyboard_input(fQoWwqIUKxbERdDljGspeLaHhJTPXn,fQoWwqIUKxbERdDljGspeLaHhJTPXm):
  fQoWwqIUKxbERdDljGspeLaHhJTPXr=fQoWwqIUKxbERdDljGspeLaHhJTPnz
  kb=xbmc.Keyboard()
  kb.setHeading(fQoWwqIUKxbERdDljGspeLaHhJTPXm)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   fQoWwqIUKxbERdDljGspeLaHhJTPXr=kb.getText()
  return fQoWwqIUKxbERdDljGspeLaHhJTPXr
 def get_settings_login_info(fQoWwqIUKxbERdDljGspeLaHhJTPXn):
  fQoWwqIUKxbERdDljGspeLaHhJTPXt =__addon__.getSetting('id')
  fQoWwqIUKxbERdDljGspeLaHhJTPXA =__addon__.getSetting('pw')
  return(fQoWwqIUKxbERdDljGspeLaHhJTPXt,fQoWwqIUKxbERdDljGspeLaHhJTPXA)
 def get_settings_hidescoreyn(fQoWwqIUKxbERdDljGspeLaHhJTPXn):
  fQoWwqIUKxbERdDljGspeLaHhJTPXV =__addon__.getSetting('hidescore')
  if fQoWwqIUKxbERdDljGspeLaHhJTPXV=='false':
   return fQoWwqIUKxbERdDljGspeLaHhJTPnr
  else:
   return fQoWwqIUKxbERdDljGspeLaHhJTPnt
 def set_winCredential(fQoWwqIUKxbERdDljGspeLaHhJTPXn,credential):
  fQoWwqIUKxbERdDljGspeLaHhJTPXi=xbmcgui.Window(10000)
  fQoWwqIUKxbERdDljGspeLaHhJTPXi.setProperty('SPOTV_M_SESSIONID',credential.get('spotv_sessionid'))
  fQoWwqIUKxbERdDljGspeLaHhJTPXi.setProperty('SPOTV_M_SESSION',credential.get('spotv_session'))
  fQoWwqIUKxbERdDljGspeLaHhJTPXi.setProperty('SPOTV_M_ACCOUNTID',credential.get('spotv_accountId'))
  fQoWwqIUKxbERdDljGspeLaHhJTPXi.setProperty('SPOTV_M_POLICYKEY',credential.get('spotv_policyKey'))
  fQoWwqIUKxbERdDljGspeLaHhJTPXi.setProperty('SPOTV_M_SUBEND',credential.get('spotv_subend'))
  fQoWwqIUKxbERdDljGspeLaHhJTPXi.setProperty('SPOTV_M_LOGINTIME',fQoWwqIUKxbERdDljGspeLaHhJTPXn.SpotvObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(fQoWwqIUKxbERdDljGspeLaHhJTPXn):
  fQoWwqIUKxbERdDljGspeLaHhJTPXi=xbmcgui.Window(10000)
  fQoWwqIUKxbERdDljGspeLaHhJTPXk={'spotv_sessionid':fQoWwqIUKxbERdDljGspeLaHhJTPXi.getProperty('SPOTV_M_SESSIONID'),'spotv_session':fQoWwqIUKxbERdDljGspeLaHhJTPXi.getProperty('SPOTV_M_SESSION'),'spotv_accountId':fQoWwqIUKxbERdDljGspeLaHhJTPXi.getProperty('SPOTV_M_ACCOUNTID'),'spotv_policyKey':fQoWwqIUKxbERdDljGspeLaHhJTPXi.getProperty('SPOTV_M_POLICYKEY'),'spotv_subend':fQoWwqIUKxbERdDljGspeLaHhJTPXi.getProperty('SPOTV_M_SUBEND')}
  return fQoWwqIUKxbERdDljGspeLaHhJTPXk
 def add_dir(fQoWwqIUKxbERdDljGspeLaHhJTPXn,label,sublabel='',img='',infoLabels=fQoWwqIUKxbERdDljGspeLaHhJTPnz,isFolder=fQoWwqIUKxbERdDljGspeLaHhJTPnt,params='',isLink=fQoWwqIUKxbERdDljGspeLaHhJTPnr,ContextMenu=fQoWwqIUKxbERdDljGspeLaHhJTPnz):
  fQoWwqIUKxbERdDljGspeLaHhJTPXy='%s?%s'%(fQoWwqIUKxbERdDljGspeLaHhJTPXn._addon_url,urllib.parse.urlencode(params))
  if sublabel:fQoWwqIUKxbERdDljGspeLaHhJTPXm='%s < %s >'%(label,sublabel)
  else: fQoWwqIUKxbERdDljGspeLaHhJTPXm=label
  if not img:img='DefaultFolder.png'
  fQoWwqIUKxbERdDljGspeLaHhJTPXS=xbmcgui.ListItem(fQoWwqIUKxbERdDljGspeLaHhJTPXm)
  fQoWwqIUKxbERdDljGspeLaHhJTPXS.setArt({'thumb':img,'icon':img,'poster':img})
  if infoLabels:fQoWwqIUKxbERdDljGspeLaHhJTPXS.setInfo(type="Video",infoLabels=infoLabels)
  if not isFolder and not isLink:
   fQoWwqIUKxbERdDljGspeLaHhJTPXS.setProperty('IsPlayable','true')
  if ContextMenu:fQoWwqIUKxbERdDljGspeLaHhJTPXS.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(fQoWwqIUKxbERdDljGspeLaHhJTPXn._addon_handle,fQoWwqIUKxbERdDljGspeLaHhJTPXy,fQoWwqIUKxbERdDljGspeLaHhJTPXS,isFolder)
 def get_selQuality(fQoWwqIUKxbERdDljGspeLaHhJTPXn,etype):
  try:
   fQoWwqIUKxbERdDljGspeLaHhJTPXY='selected_quality'
   fQoWwqIUKxbERdDljGspeLaHhJTPXF=[1080,720,540]
   fQoWwqIUKxbERdDljGspeLaHhJTPMX=fQoWwqIUKxbERdDljGspeLaHhJTPnA(__addon__.getSetting(fQoWwqIUKxbERdDljGspeLaHhJTPXY))
   return fQoWwqIUKxbERdDljGspeLaHhJTPXF[fQoWwqIUKxbERdDljGspeLaHhJTPMX]
  except:
   fQoWwqIUKxbERdDljGspeLaHhJTPnz
  return 1080 
 def dp_Main_List(fQoWwqIUKxbERdDljGspeLaHhJTPXn):
  for fQoWwqIUKxbERdDljGspeLaHhJTPMc in fQoWwqIUKxbERdDljGspeLaHhJTPXc:
   fQoWwqIUKxbERdDljGspeLaHhJTPXm=fQoWwqIUKxbERdDljGspeLaHhJTPMc.get('title')
   fQoWwqIUKxbERdDljGspeLaHhJTPMN=''
   fQoWwqIUKxbERdDljGspeLaHhJTPMn={'mode':fQoWwqIUKxbERdDljGspeLaHhJTPMc.get('mode')}
   if fQoWwqIUKxbERdDljGspeLaHhJTPMc.get('mode')=='XXX':
    fQoWwqIUKxbERdDljGspeLaHhJTPMB=fQoWwqIUKxbERdDljGspeLaHhJTPnr
    fQoWwqIUKxbERdDljGspeLaHhJTPMu =fQoWwqIUKxbERdDljGspeLaHhJTPnt
   else:
    fQoWwqIUKxbERdDljGspeLaHhJTPMB=fQoWwqIUKxbERdDljGspeLaHhJTPnt
    fQoWwqIUKxbERdDljGspeLaHhJTPMu =fQoWwqIUKxbERdDljGspeLaHhJTPnr
   if 'icon' in fQoWwqIUKxbERdDljGspeLaHhJTPMc:fQoWwqIUKxbERdDljGspeLaHhJTPMN=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',fQoWwqIUKxbERdDljGspeLaHhJTPMc.get('icon')) 
   fQoWwqIUKxbERdDljGspeLaHhJTPXn.add_dir(fQoWwqIUKxbERdDljGspeLaHhJTPXm,sublabel='',img=fQoWwqIUKxbERdDljGspeLaHhJTPMN,infoLabels=fQoWwqIUKxbERdDljGspeLaHhJTPnz,isFolder=fQoWwqIUKxbERdDljGspeLaHhJTPMB,params=fQoWwqIUKxbERdDljGspeLaHhJTPMn,isLink=fQoWwqIUKxbERdDljGspeLaHhJTPMu)
  if fQoWwqIUKxbERdDljGspeLaHhJTPnV(fQoWwqIUKxbERdDljGspeLaHhJTPXc)>0:xbmcplugin.endOfDirectory(fQoWwqIUKxbERdDljGspeLaHhJTPXn._addon_handle)
 def dp_MainLeague_List(fQoWwqIUKxbERdDljGspeLaHhJTPXn,args):
  fQoWwqIUKxbERdDljGspeLaHhJTPXn.SpotvObj.SaveCredential(fQoWwqIUKxbERdDljGspeLaHhJTPXn.get_winCredential())
  fQoWwqIUKxbERdDljGspeLaHhJTPMv=fQoWwqIUKxbERdDljGspeLaHhJTPXn.SpotvObj.GetTitleGroupList()
  for fQoWwqIUKxbERdDljGspeLaHhJTPMg in fQoWwqIUKxbERdDljGspeLaHhJTPMv:
   fQoWwqIUKxbERdDljGspeLaHhJTPXm =fQoWwqIUKxbERdDljGspeLaHhJTPMg.get('title')
   fQoWwqIUKxbERdDljGspeLaHhJTPMC =fQoWwqIUKxbERdDljGspeLaHhJTPMg.get('logo')
   fQoWwqIUKxbERdDljGspeLaHhJTPMz =fQoWwqIUKxbERdDljGspeLaHhJTPMg.get('reagueId')
   fQoWwqIUKxbERdDljGspeLaHhJTPMr =fQoWwqIUKxbERdDljGspeLaHhJTPMg.get('subGame')
   fQoWwqIUKxbERdDljGspeLaHhJTPMt={'mediatype':'episode','plot':'%s\n\n%s'%(fQoWwqIUKxbERdDljGspeLaHhJTPXm,fQoWwqIUKxbERdDljGspeLaHhJTPMr)}
   fQoWwqIUKxbERdDljGspeLaHhJTPMn={'mode':'LEAGUE_GROUP','reagueId':fQoWwqIUKxbERdDljGspeLaHhJTPMz}
   fQoWwqIUKxbERdDljGspeLaHhJTPXn.add_dir(fQoWwqIUKxbERdDljGspeLaHhJTPXm,sublabel=fQoWwqIUKxbERdDljGspeLaHhJTPnz,img=fQoWwqIUKxbERdDljGspeLaHhJTPMC,infoLabels=fQoWwqIUKxbERdDljGspeLaHhJTPMt,isFolder=fQoWwqIUKxbERdDljGspeLaHhJTPnt,params=fQoWwqIUKxbERdDljGspeLaHhJTPMn)
  if fQoWwqIUKxbERdDljGspeLaHhJTPnV(fQoWwqIUKxbERdDljGspeLaHhJTPMv)>0:xbmcplugin.endOfDirectory(fQoWwqIUKxbERdDljGspeLaHhJTPXn._addon_handle,cacheToDisc=fQoWwqIUKxbERdDljGspeLaHhJTPnr)
 def dp_PopVod_GroupList(fQoWwqIUKxbERdDljGspeLaHhJTPXn,args):
  fQoWwqIUKxbERdDljGspeLaHhJTPXn.SpotvObj.SaveCredential(fQoWwqIUKxbERdDljGspeLaHhJTPXn.get_winCredential())
  fQoWwqIUKxbERdDljGspeLaHhJTPMv=fQoWwqIUKxbERdDljGspeLaHhJTPXn.SpotvObj.GetPopularGroupList()
  for fQoWwqIUKxbERdDljGspeLaHhJTPMg in fQoWwqIUKxbERdDljGspeLaHhJTPMv:
   fQoWwqIUKxbERdDljGspeLaHhJTPMA =fQoWwqIUKxbERdDljGspeLaHhJTPMg.get('vodTitle')
   fQoWwqIUKxbERdDljGspeLaHhJTPMV =fQoWwqIUKxbERdDljGspeLaHhJTPMg.get('vodId')
   fQoWwqIUKxbERdDljGspeLaHhJTPMi =fQoWwqIUKxbERdDljGspeLaHhJTPMg.get('vodType')
   fQoWwqIUKxbERdDljGspeLaHhJTPMC=fQoWwqIUKxbERdDljGspeLaHhJTPMg.get('thumbnail')
   fQoWwqIUKxbERdDljGspeLaHhJTPMk =fQoWwqIUKxbERdDljGspeLaHhJTPMg.get('vtypeId')
   fQoWwqIUKxbERdDljGspeLaHhJTPMy =fQoWwqIUKxbERdDljGspeLaHhJTPMg.get('duration')
   fQoWwqIUKxbERdDljGspeLaHhJTPMt={'mediatype':'video','duration':fQoWwqIUKxbERdDljGspeLaHhJTPMy,'plot':fQoWwqIUKxbERdDljGspeLaHhJTPMA}
   fQoWwqIUKxbERdDljGspeLaHhJTPMn={'mode':'POP_VOD','mediacode':fQoWwqIUKxbERdDljGspeLaHhJTPMV,'mediatype':'vod','vtypeId':fQoWwqIUKxbERdDljGspeLaHhJTPMk}
   fQoWwqIUKxbERdDljGspeLaHhJTPXn.add_dir(fQoWwqIUKxbERdDljGspeLaHhJTPMA,sublabel=fQoWwqIUKxbERdDljGspeLaHhJTPMi,img=fQoWwqIUKxbERdDljGspeLaHhJTPMC,infoLabels=fQoWwqIUKxbERdDljGspeLaHhJTPMt,isFolder=fQoWwqIUKxbERdDljGspeLaHhJTPnr,params=fQoWwqIUKxbERdDljGspeLaHhJTPMn)
  if fQoWwqIUKxbERdDljGspeLaHhJTPnV(fQoWwqIUKxbERdDljGspeLaHhJTPMv)>0:xbmcplugin.endOfDirectory(fQoWwqIUKxbERdDljGspeLaHhJTPXn._addon_handle,cacheToDisc=fQoWwqIUKxbERdDljGspeLaHhJTPnr)
 def dp_Season_List(fQoWwqIUKxbERdDljGspeLaHhJTPXn,args):
  fQoWwqIUKxbERdDljGspeLaHhJTPXn.SpotvObj.SaveCredential(fQoWwqIUKxbERdDljGspeLaHhJTPXn.get_winCredential())
  fQoWwqIUKxbERdDljGspeLaHhJTPMz=args.get('reagueId')
  fQoWwqIUKxbERdDljGspeLaHhJTPMv=fQoWwqIUKxbERdDljGspeLaHhJTPXn.SpotvObj.GetSeasonList(fQoWwqIUKxbERdDljGspeLaHhJTPMz)
  for fQoWwqIUKxbERdDljGspeLaHhJTPMg in fQoWwqIUKxbERdDljGspeLaHhJTPMv:
   fQoWwqIUKxbERdDljGspeLaHhJTPMm =fQoWwqIUKxbERdDljGspeLaHhJTPMg.get('reagueName')
   fQoWwqIUKxbERdDljGspeLaHhJTPMS =fQoWwqIUKxbERdDljGspeLaHhJTPMg.get('gameTypeId')
   fQoWwqIUKxbERdDljGspeLaHhJTPMY =fQoWwqIUKxbERdDljGspeLaHhJTPMg.get('seasonName')
   fQoWwqIUKxbERdDljGspeLaHhJTPMF =fQoWwqIUKxbERdDljGspeLaHhJTPMg.get('seasonId')
   fQoWwqIUKxbERdDljGspeLaHhJTPMt={'mediatype':'episode','plot':'%s - %s'%(fQoWwqIUKxbERdDljGspeLaHhJTPMm,fQoWwqIUKxbERdDljGspeLaHhJTPMY)}
   fQoWwqIUKxbERdDljGspeLaHhJTPMn={'mode':'SEASON_GROUP','reagueId':fQoWwqIUKxbERdDljGspeLaHhJTPMz,'seasonId':fQoWwqIUKxbERdDljGspeLaHhJTPMF,'gameTypeId':fQoWwqIUKxbERdDljGspeLaHhJTPMS,'page':'1'}
   fQoWwqIUKxbERdDljGspeLaHhJTPXn.add_dir(fQoWwqIUKxbERdDljGspeLaHhJTPMm,sublabel=fQoWwqIUKxbERdDljGspeLaHhJTPMY,img='',infoLabels=fQoWwqIUKxbERdDljGspeLaHhJTPMt,isFolder=fQoWwqIUKxbERdDljGspeLaHhJTPnt,params=fQoWwqIUKxbERdDljGspeLaHhJTPMn)
  if fQoWwqIUKxbERdDljGspeLaHhJTPnV(fQoWwqIUKxbERdDljGspeLaHhJTPMv)>0:xbmcplugin.endOfDirectory(fQoWwqIUKxbERdDljGspeLaHhJTPXn._addon_handle,cacheToDisc=fQoWwqIUKxbERdDljGspeLaHhJTPnt)
 def dp_Game_List(fQoWwqIUKxbERdDljGspeLaHhJTPXn,args):
  fQoWwqIUKxbERdDljGspeLaHhJTPXn.SpotvObj.SaveCredential(fQoWwqIUKxbERdDljGspeLaHhJTPXn.get_winCredential())
  fQoWwqIUKxbERdDljGspeLaHhJTPMS=args.get('gameTypeId')
  fQoWwqIUKxbERdDljGspeLaHhJTPMz =args.get('reagueId')
  fQoWwqIUKxbERdDljGspeLaHhJTPMF =args.get('seasonId')
  fQoWwqIUKxbERdDljGspeLaHhJTPcX =fQoWwqIUKxbERdDljGspeLaHhJTPnA(args.get('page'))
  fQoWwqIUKxbERdDljGspeLaHhJTPMv,fQoWwqIUKxbERdDljGspeLaHhJTPcM=fQoWwqIUKxbERdDljGspeLaHhJTPXn.SpotvObj.GetGameList(fQoWwqIUKxbERdDljGspeLaHhJTPMS,fQoWwqIUKxbERdDljGspeLaHhJTPMz,fQoWwqIUKxbERdDljGspeLaHhJTPMF,fQoWwqIUKxbERdDljGspeLaHhJTPcX,hidescore=fQoWwqIUKxbERdDljGspeLaHhJTPXn.get_settings_hidescoreyn())
  for fQoWwqIUKxbERdDljGspeLaHhJTPMg in fQoWwqIUKxbERdDljGspeLaHhJTPMv:
   fQoWwqIUKxbERdDljGspeLaHhJTPcN =fQoWwqIUKxbERdDljGspeLaHhJTPMg.get('gameTitle')
   fQoWwqIUKxbERdDljGspeLaHhJTPcn =fQoWwqIUKxbERdDljGspeLaHhJTPMg.get('beginDate')
   fQoWwqIUKxbERdDljGspeLaHhJTPMC =fQoWwqIUKxbERdDljGspeLaHhJTPMg.get('thumbnail')
   fQoWwqIUKxbERdDljGspeLaHhJTPcB =fQoWwqIUKxbERdDljGspeLaHhJTPMg.get('gameId')
   fQoWwqIUKxbERdDljGspeLaHhJTPcu =fQoWwqIUKxbERdDljGspeLaHhJTPMg.get('totVodCnt')
   fQoWwqIUKxbERdDljGspeLaHhJTPcO =fQoWwqIUKxbERdDljGspeLaHhJTPMg.get('leaguenm')
   fQoWwqIUKxbERdDljGspeLaHhJTPcv =fQoWwqIUKxbERdDljGspeLaHhJTPMg.get('seasonnm')
   fQoWwqIUKxbERdDljGspeLaHhJTPcg =fQoWwqIUKxbERdDljGspeLaHhJTPMg.get('roundnm')
   fQoWwqIUKxbERdDljGspeLaHhJTPcC =fQoWwqIUKxbERdDljGspeLaHhJTPMg.get('info_plot')
   fQoWwqIUKxbERdDljGspeLaHhJTPcz ='%s < %s >'%(fQoWwqIUKxbERdDljGspeLaHhJTPcN,fQoWwqIUKxbERdDljGspeLaHhJTPcn)
   fQoWwqIUKxbERdDljGspeLaHhJTPMt={'mediatype':'video','plot':fQoWwqIUKxbERdDljGspeLaHhJTPcC}
   fQoWwqIUKxbERdDljGspeLaHhJTPMn={'mode':'GAME_VOD_GROUP' if fQoWwqIUKxbERdDljGspeLaHhJTPcu!=0 else 'XXX','saveTitle':fQoWwqIUKxbERdDljGspeLaHhJTPcz,'saveImg':fQoWwqIUKxbERdDljGspeLaHhJTPMC,'saveInfo':fQoWwqIUKxbERdDljGspeLaHhJTPMt['plot'],'gameid':fQoWwqIUKxbERdDljGspeLaHhJTPcB}
   fQoWwqIUKxbERdDljGspeLaHhJTPXn.add_dir(fQoWwqIUKxbERdDljGspeLaHhJTPcN,sublabel=fQoWwqIUKxbERdDljGspeLaHhJTPcn,img=fQoWwqIUKxbERdDljGspeLaHhJTPMC,infoLabels=fQoWwqIUKxbERdDljGspeLaHhJTPMt,isFolder=fQoWwqIUKxbERdDljGspeLaHhJTPnt,params=fQoWwqIUKxbERdDljGspeLaHhJTPMn)
  if fQoWwqIUKxbERdDljGspeLaHhJTPcM:
   fQoWwqIUKxbERdDljGspeLaHhJTPMn['mode'] ='SEASON_GROUP' 
   fQoWwqIUKxbERdDljGspeLaHhJTPMn['reagueId'] =fQoWwqIUKxbERdDljGspeLaHhJTPMz
   fQoWwqIUKxbERdDljGspeLaHhJTPMn['seasonId'] =fQoWwqIUKxbERdDljGspeLaHhJTPMF
   fQoWwqIUKxbERdDljGspeLaHhJTPMn['gameTypeId']=fQoWwqIUKxbERdDljGspeLaHhJTPMS
   fQoWwqIUKxbERdDljGspeLaHhJTPMn['page'] =fQoWwqIUKxbERdDljGspeLaHhJTPni(fQoWwqIUKxbERdDljGspeLaHhJTPcX+1)
   fQoWwqIUKxbERdDljGspeLaHhJTPXm='[B]%s >>[/B]'%'다음 페이지'
   fQoWwqIUKxbERdDljGspeLaHhJTPcr=fQoWwqIUKxbERdDljGspeLaHhJTPni(fQoWwqIUKxbERdDljGspeLaHhJTPcX+1)
   fQoWwqIUKxbERdDljGspeLaHhJTPMN=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   fQoWwqIUKxbERdDljGspeLaHhJTPXn.add_dir(fQoWwqIUKxbERdDljGspeLaHhJTPXm,sublabel=fQoWwqIUKxbERdDljGspeLaHhJTPcr,img=fQoWwqIUKxbERdDljGspeLaHhJTPMN,infoLabels=fQoWwqIUKxbERdDljGspeLaHhJTPnz,isFolder=fQoWwqIUKxbERdDljGspeLaHhJTPnt,params=fQoWwqIUKxbERdDljGspeLaHhJTPMn)
  if fQoWwqIUKxbERdDljGspeLaHhJTPnV(fQoWwqIUKxbERdDljGspeLaHhJTPMv)>0:xbmcplugin.endOfDirectory(fQoWwqIUKxbERdDljGspeLaHhJTPXn._addon_handle,cacheToDisc=fQoWwqIUKxbERdDljGspeLaHhJTPnr)
 def dp_GameVod_List(fQoWwqIUKxbERdDljGspeLaHhJTPXn,args):
  fQoWwqIUKxbERdDljGspeLaHhJTPXn.SpotvObj.SaveCredential(fQoWwqIUKxbERdDljGspeLaHhJTPXn.get_winCredential())
  fQoWwqIUKxbERdDljGspeLaHhJTPct =args.get('gameid')
  fQoWwqIUKxbERdDljGspeLaHhJTPcz=args.get('saveTitle')
  fQoWwqIUKxbERdDljGspeLaHhJTPcA =args.get('saveImg')
  fQoWwqIUKxbERdDljGspeLaHhJTPcV =args.get('saveInfo')
  fQoWwqIUKxbERdDljGspeLaHhJTPMv=fQoWwqIUKxbERdDljGspeLaHhJTPXn.SpotvObj.GetGameVodList(fQoWwqIUKxbERdDljGspeLaHhJTPct)
  for fQoWwqIUKxbERdDljGspeLaHhJTPMg in fQoWwqIUKxbERdDljGspeLaHhJTPMv:
   fQoWwqIUKxbERdDljGspeLaHhJTPMA =fQoWwqIUKxbERdDljGspeLaHhJTPMg.get('vodTitle')
   fQoWwqIUKxbERdDljGspeLaHhJTPMV =fQoWwqIUKxbERdDljGspeLaHhJTPMg.get('vodId')
   fQoWwqIUKxbERdDljGspeLaHhJTPMi =fQoWwqIUKxbERdDljGspeLaHhJTPMg.get('vodType')
   fQoWwqIUKxbERdDljGspeLaHhJTPMC=fQoWwqIUKxbERdDljGspeLaHhJTPMg.get('thumbnail')
   fQoWwqIUKxbERdDljGspeLaHhJTPMk =fQoWwqIUKxbERdDljGspeLaHhJTPMg.get('vtypeId')
   fQoWwqIUKxbERdDljGspeLaHhJTPMy =fQoWwqIUKxbERdDljGspeLaHhJTPMg.get('duration')
   fQoWwqIUKxbERdDljGspeLaHhJTPMt={'mediatype':'video','duration':fQoWwqIUKxbERdDljGspeLaHhJTPMy,'plot':'%s \n\n %s'%(fQoWwqIUKxbERdDljGspeLaHhJTPMA,fQoWwqIUKxbERdDljGspeLaHhJTPcV)}
   fQoWwqIUKxbERdDljGspeLaHhJTPMn={'mode':'GAME_VOD','saveTitle':fQoWwqIUKxbERdDljGspeLaHhJTPcz,'saveImg':fQoWwqIUKxbERdDljGspeLaHhJTPcA,'saveId':fQoWwqIUKxbERdDljGspeLaHhJTPct,'saveInfo':fQoWwqIUKxbERdDljGspeLaHhJTPcV,'mediacode':fQoWwqIUKxbERdDljGspeLaHhJTPMV,'mediatype':'vod','vtypeId':fQoWwqIUKxbERdDljGspeLaHhJTPMk}
   fQoWwqIUKxbERdDljGspeLaHhJTPXn.add_dir(fQoWwqIUKxbERdDljGspeLaHhJTPMA,sublabel=fQoWwqIUKxbERdDljGspeLaHhJTPMi,img=fQoWwqIUKxbERdDljGspeLaHhJTPMC,infoLabels=fQoWwqIUKxbERdDljGspeLaHhJTPMt,isFolder=fQoWwqIUKxbERdDljGspeLaHhJTPnr,params=fQoWwqIUKxbERdDljGspeLaHhJTPMn)
  if fQoWwqIUKxbERdDljGspeLaHhJTPnV(fQoWwqIUKxbERdDljGspeLaHhJTPMv)>0:xbmcplugin.endOfDirectory(fQoWwqIUKxbERdDljGspeLaHhJTPXn._addon_handle,cacheToDisc=fQoWwqIUKxbERdDljGspeLaHhJTPnr)
 def login_main(fQoWwqIUKxbERdDljGspeLaHhJTPXn):
  (fQoWwqIUKxbERdDljGspeLaHhJTPci,fQoWwqIUKxbERdDljGspeLaHhJTPck)=fQoWwqIUKxbERdDljGspeLaHhJTPXn.get_settings_login_info()
  if not(fQoWwqIUKxbERdDljGspeLaHhJTPci and fQoWwqIUKxbERdDljGspeLaHhJTPck):
   fQoWwqIUKxbERdDljGspeLaHhJTPXg=xbmcgui.Dialog()
   fQoWwqIUKxbERdDljGspeLaHhJTPcy=fQoWwqIUKxbERdDljGspeLaHhJTPXg.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if fQoWwqIUKxbERdDljGspeLaHhJTPcy==fQoWwqIUKxbERdDljGspeLaHhJTPnt:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if fQoWwqIUKxbERdDljGspeLaHhJTPXn.cookiefile_check():return
  fQoWwqIUKxbERdDljGspeLaHhJTPcm =fQoWwqIUKxbERdDljGspeLaHhJTPnA(fQoWwqIUKxbERdDljGspeLaHhJTPXn.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))
  fQoWwqIUKxbERdDljGspeLaHhJTPcS=xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINTIME')
  if fQoWwqIUKxbERdDljGspeLaHhJTPcS==fQoWwqIUKxbERdDljGspeLaHhJTPnz or fQoWwqIUKxbERdDljGspeLaHhJTPcS=='':
   fQoWwqIUKxbERdDljGspeLaHhJTPcS=fQoWwqIUKxbERdDljGspeLaHhJTPnA('19000101')
  else:
   fQoWwqIUKxbERdDljGspeLaHhJTPcS=fQoWwqIUKxbERdDljGspeLaHhJTPnA(re.sub('-','',fQoWwqIUKxbERdDljGspeLaHhJTPcS))
  if xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINWAIT')=='TRUE':
   fQoWwqIUKxbERdDljGspeLaHhJTPcY=0
   while fQoWwqIUKxbERdDljGspeLaHhJTPnt:
    fQoWwqIUKxbERdDljGspeLaHhJTPcY+=1
    time.sleep(0.05)
    if fQoWwqIUKxbERdDljGspeLaHhJTPcS>=fQoWwqIUKxbERdDljGspeLaHhJTPcm:return
    if fQoWwqIUKxbERdDljGspeLaHhJTPcY>600:return
  else:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','TRUE')
  if fQoWwqIUKxbERdDljGspeLaHhJTPcS>=fQoWwqIUKxbERdDljGspeLaHhJTPcm:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
   return
  if not fQoWwqIUKxbERdDljGspeLaHhJTPXn.SpotvObj.GetCredential(fQoWwqIUKxbERdDljGspeLaHhJTPci,fQoWwqIUKxbERdDljGspeLaHhJTPck):
   fQoWwqIUKxbERdDljGspeLaHhJTPXn.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
   sys.exit()
  fQoWwqIUKxbERdDljGspeLaHhJTPXn.set_winCredential(fQoWwqIUKxbERdDljGspeLaHhJTPXn.SpotvObj.LoadCredential())
  fQoWwqIUKxbERdDljGspeLaHhJTPXn.cookiefile_save()
  xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
 def dp_LiveChannel_List(fQoWwqIUKxbERdDljGspeLaHhJTPXn,args):
  fQoWwqIUKxbERdDljGspeLaHhJTPXn.SpotvObj.SaveCredential(fQoWwqIUKxbERdDljGspeLaHhJTPXn.get_winCredential())
  fQoWwqIUKxbERdDljGspeLaHhJTPcF=fQoWwqIUKxbERdDljGspeLaHhJTPXn.SpotvObj.GetLiveChannelList()
  for fQoWwqIUKxbERdDljGspeLaHhJTPNX in fQoWwqIUKxbERdDljGspeLaHhJTPcF:
   fQoWwqIUKxbERdDljGspeLaHhJTPXm =fQoWwqIUKxbERdDljGspeLaHhJTPNX.get('name')
   fQoWwqIUKxbERdDljGspeLaHhJTPMC =fQoWwqIUKxbERdDljGspeLaHhJTPNX.get('logo')
   fQoWwqIUKxbERdDljGspeLaHhJTPNM=fQoWwqIUKxbERdDljGspeLaHhJTPNX.get('channelepg')
   fQoWwqIUKxbERdDljGspeLaHhJTPNc =fQoWwqIUKxbERdDljGspeLaHhJTPNX.get('free')
   if fQoWwqIUKxbERdDljGspeLaHhJTPNM:
    fQoWwqIUKxbERdDljGspeLaHhJTPNn =fQoWwqIUKxbERdDljGspeLaHhJTPNM['epg']
    fQoWwqIUKxbERdDljGspeLaHhJTPNB=fQoWwqIUKxbERdDljGspeLaHhJTPNM['title']
   else:
    fQoWwqIUKxbERdDljGspeLaHhJTPNn =''
    fQoWwqIUKxbERdDljGspeLaHhJTPNB=''
   fQoWwqIUKxbERdDljGspeLaHhJTPMt={'plot':'%s\n\n%s'%(fQoWwqIUKxbERdDljGspeLaHhJTPXm,fQoWwqIUKxbERdDljGspeLaHhJTPNn),'mediatype':'video'}
   fQoWwqIUKxbERdDljGspeLaHhJTPMn={'mode':'LIVE','mediacode':fQoWwqIUKxbERdDljGspeLaHhJTPNX.get('videoId'),'free':fQoWwqIUKxbERdDljGspeLaHhJTPNc,'mediatype':'live'}
   if fQoWwqIUKxbERdDljGspeLaHhJTPNc:fQoWwqIUKxbERdDljGspeLaHhJTPXm+=' [free]'
   fQoWwqIUKxbERdDljGspeLaHhJTPXn.add_dir(fQoWwqIUKxbERdDljGspeLaHhJTPXm,sublabel=fQoWwqIUKxbERdDljGspeLaHhJTPNB,img=fQoWwqIUKxbERdDljGspeLaHhJTPMC,infoLabels=fQoWwqIUKxbERdDljGspeLaHhJTPMt,isFolder=fQoWwqIUKxbERdDljGspeLaHhJTPnr,params=fQoWwqIUKxbERdDljGspeLaHhJTPMn)
  if fQoWwqIUKxbERdDljGspeLaHhJTPnV(fQoWwqIUKxbERdDljGspeLaHhJTPcF)>0:xbmcplugin.endOfDirectory(fQoWwqIUKxbERdDljGspeLaHhJTPXn._addon_handle,cacheToDisc=fQoWwqIUKxbERdDljGspeLaHhJTPnr)
 def dp_EventLiveChannel_List(fQoWwqIUKxbERdDljGspeLaHhJTPXn,args):
  fQoWwqIUKxbERdDljGspeLaHhJTPXn.SpotvObj.SaveCredential(fQoWwqIUKxbERdDljGspeLaHhJTPXn.get_winCredential())
  fQoWwqIUKxbERdDljGspeLaHhJTPcF,fQoWwqIUKxbERdDljGspeLaHhJTPNu=fQoWwqIUKxbERdDljGspeLaHhJTPXn.SpotvObj.GetEventLiveList()
  if fQoWwqIUKxbERdDljGspeLaHhJTPNu!=401 and fQoWwqIUKxbERdDljGspeLaHhJTPnV(fQoWwqIUKxbERdDljGspeLaHhJTPcF)==0:
   fQoWwqIUKxbERdDljGspeLaHhJTPXn.addon_noti(__language__(30907).encode('utf8'))
  for fQoWwqIUKxbERdDljGspeLaHhJTPNX in fQoWwqIUKxbERdDljGspeLaHhJTPcF:
   fQoWwqIUKxbERdDljGspeLaHhJTPXm =fQoWwqIUKxbERdDljGspeLaHhJTPNX.get('title')
   fQoWwqIUKxbERdDljGspeLaHhJTPMO =fQoWwqIUKxbERdDljGspeLaHhJTPNX.get('startTime')
   fQoWwqIUKxbERdDljGspeLaHhJTPMC =fQoWwqIUKxbERdDljGspeLaHhJTPNX.get('logo')
   fQoWwqIUKxbERdDljGspeLaHhJTPNc =fQoWwqIUKxbERdDljGspeLaHhJTPNX.get('free')
   fQoWwqIUKxbERdDljGspeLaHhJTPMt={'mediatype':'video','plot':'%s\n\n%s'%(fQoWwqIUKxbERdDljGspeLaHhJTPXm,fQoWwqIUKxbERdDljGspeLaHhJTPMO)}
   fQoWwqIUKxbERdDljGspeLaHhJTPMn={'mode':'ELIVE','mediaid':fQoWwqIUKxbERdDljGspeLaHhJTPNX.get('liveId'),'mediacode':'','free':fQoWwqIUKxbERdDljGspeLaHhJTPNc,'mediatype':'live'}
   if fQoWwqIUKxbERdDljGspeLaHhJTPNc:fQoWwqIUKxbERdDljGspeLaHhJTPXm+=' [free]'
   fQoWwqIUKxbERdDljGspeLaHhJTPXn.add_dir(fQoWwqIUKxbERdDljGspeLaHhJTPXm,sublabel=fQoWwqIUKxbERdDljGspeLaHhJTPMO,img=fQoWwqIUKxbERdDljGspeLaHhJTPMC,infoLabels=fQoWwqIUKxbERdDljGspeLaHhJTPMt,isFolder=fQoWwqIUKxbERdDljGspeLaHhJTPnr,params=fQoWwqIUKxbERdDljGspeLaHhJTPMn)
  if fQoWwqIUKxbERdDljGspeLaHhJTPnV(fQoWwqIUKxbERdDljGspeLaHhJTPcF)>0:xbmcplugin.endOfDirectory(fQoWwqIUKxbERdDljGspeLaHhJTPXn._addon_handle,cacheToDisc=fQoWwqIUKxbERdDljGspeLaHhJTPnt)
  return fQoWwqIUKxbERdDljGspeLaHhJTPNu
 def play_VIDEO(fQoWwqIUKxbERdDljGspeLaHhJTPXn,args):
  fQoWwqIUKxbERdDljGspeLaHhJTPXn.SpotvObj.SaveCredential(fQoWwqIUKxbERdDljGspeLaHhJTPXn.get_winCredential())
  fQoWwqIUKxbERdDljGspeLaHhJTPNO =args.get('mode')
  fQoWwqIUKxbERdDljGspeLaHhJTPNv =args.get('mediacode')
  fQoWwqIUKxbERdDljGspeLaHhJTPNg =args.get('mediatype')
  fQoWwqIUKxbERdDljGspeLaHhJTPMk =args.get('vtypeId')
  if fQoWwqIUKxbERdDljGspeLaHhJTPNO=='LIVE':
   if args.get('free')=='False':
    if fQoWwqIUKxbERdDljGspeLaHhJTPXn.SpotvObj.CheckSubEnd()==fQoWwqIUKxbERdDljGspeLaHhJTPnr:
     fQoWwqIUKxbERdDljGspeLaHhJTPXn.addon_noti(__language__(30908).encode('utf8'))
     return
  elif fQoWwqIUKxbERdDljGspeLaHhJTPNO=='ELIVE':
   if args.get('free')=='False':
    if fQoWwqIUKxbERdDljGspeLaHhJTPXn.SpotvObj.CheckSubEnd()==fQoWwqIUKxbERdDljGspeLaHhJTPnr:
     fQoWwqIUKxbERdDljGspeLaHhJTPXn.addon_noti(__language__(30908).encode('utf8'))
     return
   fQoWwqIUKxbERdDljGspeLaHhJTPNv=fQoWwqIUKxbERdDljGspeLaHhJTPXn.SpotvObj.GetEventLive_videoId(args.get('mediaid'))
  if fQoWwqIUKxbERdDljGspeLaHhJTPNv=='' or fQoWwqIUKxbERdDljGspeLaHhJTPNv==fQoWwqIUKxbERdDljGspeLaHhJTPnz:
   fQoWwqIUKxbERdDljGspeLaHhJTPXn.addon_noti(__language__(30907).encode('utf8'))
   return
  if fQoWwqIUKxbERdDljGspeLaHhJTPNO=='LIVE':
   fQoWwqIUKxbERdDljGspeLaHhJTPNC=fQoWwqIUKxbERdDljGspeLaHhJTPXn.SpotvObj.Get_Streamurl_Make(args.get('mediacode'))
  else:
   fQoWwqIUKxbERdDljGspeLaHhJTPNC=fQoWwqIUKxbERdDljGspeLaHhJTPXn.SpotvObj.GetBroadURL(fQoWwqIUKxbERdDljGspeLaHhJTPNv,fQoWwqIUKxbERdDljGspeLaHhJTPNg,fQoWwqIUKxbERdDljGspeLaHhJTPMk)
  if fQoWwqIUKxbERdDljGspeLaHhJTPNC=='':
   fQoWwqIUKxbERdDljGspeLaHhJTPXn.addon_noti(__language__(30908).encode('utf8'))
   return
  fQoWwqIUKxbERdDljGspeLaHhJTPNz=fQoWwqIUKxbERdDljGspeLaHhJTPNC
  fQoWwqIUKxbERdDljGspeLaHhJTPXn.addon_log(fQoWwqIUKxbERdDljGspeLaHhJTPNz)
  fQoWwqIUKxbERdDljGspeLaHhJTPNr=xbmcgui.ListItem(path=fQoWwqIUKxbERdDljGspeLaHhJTPNz)
  xbmcplugin.setResolvedUrl(fQoWwqIUKxbERdDljGspeLaHhJTPXn._addon_handle,fQoWwqIUKxbERdDljGspeLaHhJTPnt,fQoWwqIUKxbERdDljGspeLaHhJTPNr)
  try:
   if fQoWwqIUKxbERdDljGspeLaHhJTPNg=='vod' and fQoWwqIUKxbERdDljGspeLaHhJTPNO!='POP_VOD':
    fQoWwqIUKxbERdDljGspeLaHhJTPMn={'code':args.get('saveId'),'img':args.get('saveImg'),'title':args.get('saveTitle'),'info':args.get('saveInfo')}
    fQoWwqIUKxbERdDljGspeLaHhJTPXn.Save_Watched_List(fQoWwqIUKxbERdDljGspeLaHhJTPNg,fQoWwqIUKxbERdDljGspeLaHhJTPMn)
  except:
   fQoWwqIUKxbERdDljGspeLaHhJTPnz
 def logout(fQoWwqIUKxbERdDljGspeLaHhJTPXn):
  fQoWwqIUKxbERdDljGspeLaHhJTPXg=xbmcgui.Dialog()
  fQoWwqIUKxbERdDljGspeLaHhJTPcy=fQoWwqIUKxbERdDljGspeLaHhJTPXg.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if fQoWwqIUKxbERdDljGspeLaHhJTPcy==fQoWwqIUKxbERdDljGspeLaHhJTPnr:sys.exit()
  fQoWwqIUKxbERdDljGspeLaHhJTPXn.wininfo_clear()
  if os.path.isfile(fQoWwqIUKxbERdDljGspeLaHhJTPXN):os.remove(fQoWwqIUKxbERdDljGspeLaHhJTPXN)
  fQoWwqIUKxbERdDljGspeLaHhJTPXn.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(fQoWwqIUKxbERdDljGspeLaHhJTPXn):
  fQoWwqIUKxbERdDljGspeLaHhJTPXi=xbmcgui.Window(10000)
  fQoWwqIUKxbERdDljGspeLaHhJTPXi.setProperty('SPOTV_M_SESSIONID','')
  fQoWwqIUKxbERdDljGspeLaHhJTPXi.setProperty('SPOTV_M_SESSION','')
  fQoWwqIUKxbERdDljGspeLaHhJTPXi.setProperty('SPOTV_M_ACCOUNTID','')
  fQoWwqIUKxbERdDljGspeLaHhJTPXi.setProperty('SPOTV_M_POLICYKEY','')
  fQoWwqIUKxbERdDljGspeLaHhJTPXi.setProperty('SPOTV_M_SUBEND','')
  fQoWwqIUKxbERdDljGspeLaHhJTPXi.setProperty('SPOTV_M_LOGINTIME','')
 def cookiefile_save(fQoWwqIUKxbERdDljGspeLaHhJTPXn):
  fQoWwqIUKxbERdDljGspeLaHhJTPNt =fQoWwqIUKxbERdDljGspeLaHhJTPXn.SpotvObj.Get_Now_Datetime()
  fQoWwqIUKxbERdDljGspeLaHhJTPNA=fQoWwqIUKxbERdDljGspeLaHhJTPNt+datetime.timedelta(days=fQoWwqIUKxbERdDljGspeLaHhJTPnA(__addon__.getSetting('cache_ttl')))
  fQoWwqIUKxbERdDljGspeLaHhJTPXi=xbmcgui.Window(10000)
  fQoWwqIUKxbERdDljGspeLaHhJTPNV={'spotv_sessionid':fQoWwqIUKxbERdDljGspeLaHhJTPXi.getProperty('SPOTV_M_SESSIONID'),'spotv_session':fQoWwqIUKxbERdDljGspeLaHhJTPXi.getProperty('SPOTV_M_SESSION'),'spotv_accountId':fQoWwqIUKxbERdDljGspeLaHhJTPXi.getProperty('SPOTV_M_ACCOUNTID'),'spotv_policyKey':base64.standard_b64encode(fQoWwqIUKxbERdDljGspeLaHhJTPXi.getProperty('SPOTV_M_POLICYKEY').encode()).decode('utf-8'),'spotv_subend':base64.standard_b64encode((fQoWwqIUKxbERdDljGspeLaHhJTPXn.SpotvObj.SPOTV_PMCODE+fQoWwqIUKxbERdDljGspeLaHhJTPXi.getProperty('SPOTV_M_SUBEND')).encode()).decode('utf-8'),'spotv_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'spotv_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'spotv_limitdate':fQoWwqIUKxbERdDljGspeLaHhJTPNA.strftime('%Y-%m-%d')}
  try: 
   fp=fQoWwqIUKxbERdDljGspeLaHhJTPnk(fQoWwqIUKxbERdDljGspeLaHhJTPXN,'w',-1,'utf-8')
   json.dump(fQoWwqIUKxbERdDljGspeLaHhJTPNV,fp)
   fp.close()
  except fQoWwqIUKxbERdDljGspeLaHhJTPny as exception:
   fQoWwqIUKxbERdDljGspeLaHhJTPnm(exception)
 def cookiefile_check(fQoWwqIUKxbERdDljGspeLaHhJTPXn):
  fQoWwqIUKxbERdDljGspeLaHhJTPNV={}
  try: 
   fp=fQoWwqIUKxbERdDljGspeLaHhJTPnk(fQoWwqIUKxbERdDljGspeLaHhJTPXN,'r',-1,'utf-8')
   fQoWwqIUKxbERdDljGspeLaHhJTPNV= json.load(fp)
   fp.close()
  except fQoWwqIUKxbERdDljGspeLaHhJTPny as exception:
   fQoWwqIUKxbERdDljGspeLaHhJTPXn.wininfo_clear()
   return fQoWwqIUKxbERdDljGspeLaHhJTPnr
  fQoWwqIUKxbERdDljGspeLaHhJTPci =__addon__.getSetting('id')
  fQoWwqIUKxbERdDljGspeLaHhJTPck =__addon__.getSetting('pw')
  fQoWwqIUKxbERdDljGspeLaHhJTPNV['spotv_id'] =base64.standard_b64decode(fQoWwqIUKxbERdDljGspeLaHhJTPNV['spotv_id']).decode('utf-8')
  fQoWwqIUKxbERdDljGspeLaHhJTPNV['spotv_pw'] =base64.standard_b64decode(fQoWwqIUKxbERdDljGspeLaHhJTPNV['spotv_pw']).decode('utf-8')
  fQoWwqIUKxbERdDljGspeLaHhJTPNV['spotv_policyKey']=base64.standard_b64decode(fQoWwqIUKxbERdDljGspeLaHhJTPNV['spotv_policyKey']).decode('utf-8')
  fQoWwqIUKxbERdDljGspeLaHhJTPNV['spotv_subend']=base64.standard_b64decode(fQoWwqIUKxbERdDljGspeLaHhJTPNV['spotv_subend']).decode('utf-8')[fQoWwqIUKxbERdDljGspeLaHhJTPXn.SpotvObj.SPOTV_PMSIZE:]
  if fQoWwqIUKxbERdDljGspeLaHhJTPci!=fQoWwqIUKxbERdDljGspeLaHhJTPNV['spotv_id']or fQoWwqIUKxbERdDljGspeLaHhJTPck!=fQoWwqIUKxbERdDljGspeLaHhJTPNV['spotv_pw']:
   fQoWwqIUKxbERdDljGspeLaHhJTPXn.wininfo_clear()
   return fQoWwqIUKxbERdDljGspeLaHhJTPnr
  fQoWwqIUKxbERdDljGspeLaHhJTPcm =fQoWwqIUKxbERdDljGspeLaHhJTPnA(fQoWwqIUKxbERdDljGspeLaHhJTPXn.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))
  fQoWwqIUKxbERdDljGspeLaHhJTPNi=fQoWwqIUKxbERdDljGspeLaHhJTPNV['spotv_limitdate']
  fQoWwqIUKxbERdDljGspeLaHhJTPcS =fQoWwqIUKxbERdDljGspeLaHhJTPnA(re.sub('-','',fQoWwqIUKxbERdDljGspeLaHhJTPNi))
  if fQoWwqIUKxbERdDljGspeLaHhJTPcS<fQoWwqIUKxbERdDljGspeLaHhJTPcm:
   fQoWwqIUKxbERdDljGspeLaHhJTPXn.wininfo_clear()
   return fQoWwqIUKxbERdDljGspeLaHhJTPnr
  fQoWwqIUKxbERdDljGspeLaHhJTPXi=xbmcgui.Window(10000)
  fQoWwqIUKxbERdDljGspeLaHhJTPXi.setProperty('SPOTV_M_SESSIONID',fQoWwqIUKxbERdDljGspeLaHhJTPNV['spotv_sessionid'])
  fQoWwqIUKxbERdDljGspeLaHhJTPXi.setProperty('SPOTV_M_SESSION',fQoWwqIUKxbERdDljGspeLaHhJTPNV['spotv_session'])
  fQoWwqIUKxbERdDljGspeLaHhJTPXi.setProperty('SPOTV_M_ACCOUNTID',fQoWwqIUKxbERdDljGspeLaHhJTPNV['spotv_accountId'])
  fQoWwqIUKxbERdDljGspeLaHhJTPXi.setProperty('SPOTV_M_POLICYKEY',fQoWwqIUKxbERdDljGspeLaHhJTPNV['spotv_policyKey'])
  fQoWwqIUKxbERdDljGspeLaHhJTPXi.setProperty('SPOTV_M_SUBEND',fQoWwqIUKxbERdDljGspeLaHhJTPNV['spotv_subend'])
  fQoWwqIUKxbERdDljGspeLaHhJTPXi.setProperty('SPOTV_M_LOGINTIME',fQoWwqIUKxbERdDljGspeLaHhJTPNi)
  return fQoWwqIUKxbERdDljGspeLaHhJTPnt
 def dp_WatchList_Delete(fQoWwqIUKxbERdDljGspeLaHhJTPXn,args):
  fQoWwqIUKxbERdDljGspeLaHhJTPNg=args.get('mediatype')
  fQoWwqIUKxbERdDljGspeLaHhJTPXg=xbmcgui.Dialog()
  fQoWwqIUKxbERdDljGspeLaHhJTPcy=fQoWwqIUKxbERdDljGspeLaHhJTPXg.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if fQoWwqIUKxbERdDljGspeLaHhJTPcy==fQoWwqIUKxbERdDljGspeLaHhJTPnr:sys.exit()
  fQoWwqIUKxbERdDljGspeLaHhJTPXn.Delete_Watched_List(fQoWwqIUKxbERdDljGspeLaHhJTPNg)
  xbmc.executebuiltin("Container.Refresh")
 def Delete_Watched_List(fQoWwqIUKxbERdDljGspeLaHhJTPXn,fQoWwqIUKxbERdDljGspeLaHhJTPNg):
  try:
   fQoWwqIUKxbERdDljGspeLaHhJTPNk=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%fQoWwqIUKxbERdDljGspeLaHhJTPNg))
   fp=fQoWwqIUKxbERdDljGspeLaHhJTPnk(fQoWwqIUKxbERdDljGspeLaHhJTPNk,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   fQoWwqIUKxbERdDljGspeLaHhJTPnz
 def Load_Watched_List(fQoWwqIUKxbERdDljGspeLaHhJTPXn,fQoWwqIUKxbERdDljGspeLaHhJTPNg):
  try:
   fQoWwqIUKxbERdDljGspeLaHhJTPNk=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%fQoWwqIUKxbERdDljGspeLaHhJTPNg))
   fp=fQoWwqIUKxbERdDljGspeLaHhJTPnk(fQoWwqIUKxbERdDljGspeLaHhJTPNk,'r',-1,'utf-8')
   fQoWwqIUKxbERdDljGspeLaHhJTPNy=fp.readlines()
   fp.close()
  except:
   fQoWwqIUKxbERdDljGspeLaHhJTPNy=[]
  return fQoWwqIUKxbERdDljGspeLaHhJTPNy
 def Save_Watched_List(fQoWwqIUKxbERdDljGspeLaHhJTPXn,stype,fQoWwqIUKxbERdDljGspeLaHhJTPXO):
  try:
   fQoWwqIUKxbERdDljGspeLaHhJTPNk=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   fQoWwqIUKxbERdDljGspeLaHhJTPNm=fQoWwqIUKxbERdDljGspeLaHhJTPXn.Load_Watched_List(stype) 
   fp=fQoWwqIUKxbERdDljGspeLaHhJTPnk(fQoWwqIUKxbERdDljGspeLaHhJTPNk,'w',-1,'utf-8')
   fQoWwqIUKxbERdDljGspeLaHhJTPNS=urllib.parse.urlencode(fQoWwqIUKxbERdDljGspeLaHhJTPXO)
   fQoWwqIUKxbERdDljGspeLaHhJTPNS=fQoWwqIUKxbERdDljGspeLaHhJTPNS+'\n'
   fp.write(fQoWwqIUKxbERdDljGspeLaHhJTPNS)
   fQoWwqIUKxbERdDljGspeLaHhJTPNY=0
   for fQoWwqIUKxbERdDljGspeLaHhJTPNF in fQoWwqIUKxbERdDljGspeLaHhJTPNm:
    fQoWwqIUKxbERdDljGspeLaHhJTPnX=fQoWwqIUKxbERdDljGspeLaHhJTPnS(urllib.parse.parse_qsl(fQoWwqIUKxbERdDljGspeLaHhJTPNF))
    fQoWwqIUKxbERdDljGspeLaHhJTPnM=fQoWwqIUKxbERdDljGspeLaHhJTPXO.get('code')
    fQoWwqIUKxbERdDljGspeLaHhJTPnc=fQoWwqIUKxbERdDljGspeLaHhJTPnX.get('code')
    if fQoWwqIUKxbERdDljGspeLaHhJTPnM!=fQoWwqIUKxbERdDljGspeLaHhJTPnc:
     fp.write(fQoWwqIUKxbERdDljGspeLaHhJTPNF)
     fQoWwqIUKxbERdDljGspeLaHhJTPNY+=1
     if fQoWwqIUKxbERdDljGspeLaHhJTPNY>=50:break
   fp.close()
  except:
   fQoWwqIUKxbERdDljGspeLaHhJTPnz
 def dp_Watch_List(fQoWwqIUKxbERdDljGspeLaHhJTPXn,args):
  fQoWwqIUKxbERdDljGspeLaHhJTPNg ='vod'
  if fQoWwqIUKxbERdDljGspeLaHhJTPNg=='vod':
   fQoWwqIUKxbERdDljGspeLaHhJTPnN=fQoWwqIUKxbERdDljGspeLaHhJTPXn.Load_Watched_List(fQoWwqIUKxbERdDljGspeLaHhJTPNg)
   for fQoWwqIUKxbERdDljGspeLaHhJTPnB in fQoWwqIUKxbERdDljGspeLaHhJTPnN:
    fQoWwqIUKxbERdDljGspeLaHhJTPnu=fQoWwqIUKxbERdDljGspeLaHhJTPnS(urllib.parse.parse_qsl(fQoWwqIUKxbERdDljGspeLaHhJTPnB))
    fQoWwqIUKxbERdDljGspeLaHhJTPXm =fQoWwqIUKxbERdDljGspeLaHhJTPnu.get('title')
    fQoWwqIUKxbERdDljGspeLaHhJTPMC=fQoWwqIUKxbERdDljGspeLaHhJTPnu.get('img')
    fQoWwqIUKxbERdDljGspeLaHhJTPNv=fQoWwqIUKxbERdDljGspeLaHhJTPnu.get('code')
    fQoWwqIUKxbERdDljGspeLaHhJTPnO =fQoWwqIUKxbERdDljGspeLaHhJTPnu.get('info')
    fQoWwqIUKxbERdDljGspeLaHhJTPMt={}
    fQoWwqIUKxbERdDljGspeLaHhJTPMt['plot']=fQoWwqIUKxbERdDljGspeLaHhJTPnO
    fQoWwqIUKxbERdDljGspeLaHhJTPMn={'mode':'GAME_VOD_GROUP','gameid':fQoWwqIUKxbERdDljGspeLaHhJTPNv,'saveTitle':fQoWwqIUKxbERdDljGspeLaHhJTPXm,'saveImg':fQoWwqIUKxbERdDljGspeLaHhJTPMC,'saveInfo':fQoWwqIUKxbERdDljGspeLaHhJTPnO,'mediatype':fQoWwqIUKxbERdDljGspeLaHhJTPNg}
    fQoWwqIUKxbERdDljGspeLaHhJTPXn.add_dir(fQoWwqIUKxbERdDljGspeLaHhJTPXm,sublabel='',img=fQoWwqIUKxbERdDljGspeLaHhJTPMC,infoLabels=fQoWwqIUKxbERdDljGspeLaHhJTPMt,isFolder=fQoWwqIUKxbERdDljGspeLaHhJTPnt,params=fQoWwqIUKxbERdDljGspeLaHhJTPMn)
   fQoWwqIUKxbERdDljGspeLaHhJTPMt={'plot':'시청목록을 삭제합니다.'}
   fQoWwqIUKxbERdDljGspeLaHhJTPXm='*** 시청목록 삭제 ***'
   fQoWwqIUKxbERdDljGspeLaHhJTPMn={'mode':'MYVIEW_REMOVE','mediatype':fQoWwqIUKxbERdDljGspeLaHhJTPNg}
   fQoWwqIUKxbERdDljGspeLaHhJTPMN=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   fQoWwqIUKxbERdDljGspeLaHhJTPXn.add_dir(fQoWwqIUKxbERdDljGspeLaHhJTPXm,sublabel='',img=fQoWwqIUKxbERdDljGspeLaHhJTPMN,infoLabels=fQoWwqIUKxbERdDljGspeLaHhJTPMt,isFolder=fQoWwqIUKxbERdDljGspeLaHhJTPnr,params=fQoWwqIUKxbERdDljGspeLaHhJTPMn,isLink=fQoWwqIUKxbERdDljGspeLaHhJTPnt)
   xbmcplugin.endOfDirectory(fQoWwqIUKxbERdDljGspeLaHhJTPXn._addon_handle,cacheToDisc=fQoWwqIUKxbERdDljGspeLaHhJTPnr)
 def spotv_main(fQoWwqIUKxbERdDljGspeLaHhJTPXn):
  fQoWwqIUKxbERdDljGspeLaHhJTPng=fQoWwqIUKxbERdDljGspeLaHhJTPXn.main_params.get('mode',fQoWwqIUKxbERdDljGspeLaHhJTPnz)
  if fQoWwqIUKxbERdDljGspeLaHhJTPng=='LOGOUT':
   fQoWwqIUKxbERdDljGspeLaHhJTPXn.logout()
   return
  fQoWwqIUKxbERdDljGspeLaHhJTPXn.login_main()
  if fQoWwqIUKxbERdDljGspeLaHhJTPng is fQoWwqIUKxbERdDljGspeLaHhJTPnz:
   fQoWwqIUKxbERdDljGspeLaHhJTPXn.dp_Main_List()
  elif fQoWwqIUKxbERdDljGspeLaHhJTPng=='LIVE_GROUP':
   fQoWwqIUKxbERdDljGspeLaHhJTPXn.dp_LiveChannel_List(fQoWwqIUKxbERdDljGspeLaHhJTPXn.main_params)
  elif fQoWwqIUKxbERdDljGspeLaHhJTPng=='ELIVE_GROUP':
   fQoWwqIUKxbERdDljGspeLaHhJTPNu=fQoWwqIUKxbERdDljGspeLaHhJTPXn.dp_EventLiveChannel_List(fQoWwqIUKxbERdDljGspeLaHhJTPXn.main_params)
   if fQoWwqIUKxbERdDljGspeLaHhJTPNu==401:
    if os.path.isfile(fQoWwqIUKxbERdDljGspeLaHhJTPXN):os.remove(fQoWwqIUKxbERdDljGspeLaHhJTPXN)
    fQoWwqIUKxbERdDljGspeLaHhJTPXn.login_main()
    fQoWwqIUKxbERdDljGspeLaHhJTPXn.dp_EventLiveChannel_List(fQoWwqIUKxbERdDljGspeLaHhJTPXn.main_params)
  elif fQoWwqIUKxbERdDljGspeLaHhJTPng in['LIVE','GAME_VOD','POP_VOD','ELIVE']:
   fQoWwqIUKxbERdDljGspeLaHhJTPXn.play_VIDEO(fQoWwqIUKxbERdDljGspeLaHhJTPXn.main_params)
  elif fQoWwqIUKxbERdDljGspeLaHhJTPng=='VOD_GROUP':
   fQoWwqIUKxbERdDljGspeLaHhJTPXn.dp_MainLeague_List(fQoWwqIUKxbERdDljGspeLaHhJTPXn.main_params)
  elif fQoWwqIUKxbERdDljGspeLaHhJTPng=='POP_GROUP':
   fQoWwqIUKxbERdDljGspeLaHhJTPXn.dp_PopVod_GroupList(fQoWwqIUKxbERdDljGspeLaHhJTPXn.main_params)
  elif fQoWwqIUKxbERdDljGspeLaHhJTPng=='LEAGUE_GROUP':
   fQoWwqIUKxbERdDljGspeLaHhJTPXn.dp_Season_List(fQoWwqIUKxbERdDljGspeLaHhJTPXn.main_params)
  elif fQoWwqIUKxbERdDljGspeLaHhJTPng=='SEASON_GROUP':
   fQoWwqIUKxbERdDljGspeLaHhJTPXn.dp_Game_List(fQoWwqIUKxbERdDljGspeLaHhJTPXn.main_params)
  elif fQoWwqIUKxbERdDljGspeLaHhJTPng=='GAME_VOD_GROUP':
   fQoWwqIUKxbERdDljGspeLaHhJTPXn.dp_GameVod_List(fQoWwqIUKxbERdDljGspeLaHhJTPXn.main_params)
  elif fQoWwqIUKxbERdDljGspeLaHhJTPng=='WATCH':
   fQoWwqIUKxbERdDljGspeLaHhJTPXn.dp_Watch_List(fQoWwqIUKxbERdDljGspeLaHhJTPXn.main_params)
  elif fQoWwqIUKxbERdDljGspeLaHhJTPng=='MYVIEW_REMOVE':
   fQoWwqIUKxbERdDljGspeLaHhJTPXn.dp_WatchList_Delete(fQoWwqIUKxbERdDljGspeLaHhJTPXn.main_params)
  else:
   fQoWwqIUKxbERdDljGspeLaHhJTPnz
# Created by pyminifier (https://github.com/liftoff/pyminifier)
