__author__="NightRain"
otcGuEWmdgRIHJjUQYFsKaqlSTkvDO=object
otcGuEWmdgRIHJjUQYFsKaqlSTkvDh=None
otcGuEWmdgRIHJjUQYFsKaqlSTkvDL=False
otcGuEWmdgRIHJjUQYFsKaqlSTkvDf=True
otcGuEWmdgRIHJjUQYFsKaqlSTkvDn=int
otcGuEWmdgRIHJjUQYFsKaqlSTkvDM=len
otcGuEWmdgRIHJjUQYFsKaqlSTkvDi=str
otcGuEWmdgRIHJjUQYFsKaqlSTkvpP=id
otcGuEWmdgRIHJjUQYFsKaqlSTkvpx=open
otcGuEWmdgRIHJjUQYFsKaqlSTkvpC=dict
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
otcGuEWmdgRIHJjUQYFsKaqlSTkvPC=[{'title':'TV 채널 (유료사용자만 지원)','mode':'LIVE_GROUP','icon':'live.png'},{'title':'Live중계 (경기중에만 재생)','mode':'ELIVE_GROUP','icon':'live.png'},{'title':'-----------------','mode':'XXX'},{'title':'오늘의 추천 VOD','mode':'NOW_GROUP'},{'title':'인기영상 5','mode':'POP_GROUP'},{'title':'-----------------','mode':'XXX'},{'title':'VOD (리그, 경기별)','mode':'VOD_GROUP'},{'title':'Watched (시청목록)','mode':'WATCH','icon':'history.png'},]
otcGuEWmdgRIHJjUQYFsKaqlSTkvPw=xbmcvfs.translatePath(os.path.join(__profile__,'spotv_cookies.json'))
from spotvCore import*
class otcGuEWmdgRIHJjUQYFsKaqlSTkvPx(otcGuEWmdgRIHJjUQYFsKaqlSTkvDO):
 def __init__(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD,otcGuEWmdgRIHJjUQYFsKaqlSTkvPp,otcGuEWmdgRIHJjUQYFsKaqlSTkvPe,otcGuEWmdgRIHJjUQYFsKaqlSTkvPb):
  otcGuEWmdgRIHJjUQYFsKaqlSTkvPD._addon_url =otcGuEWmdgRIHJjUQYFsKaqlSTkvPp
  otcGuEWmdgRIHJjUQYFsKaqlSTkvPD._addon_handle=otcGuEWmdgRIHJjUQYFsKaqlSTkvPe
  otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.main_params =otcGuEWmdgRIHJjUQYFsKaqlSTkvPb
  otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.SpotvObj =WunlkOAgsTyLafYGimtvXqCpwFJQhS() 
 def addon_noti(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD,sting):
  try:
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPy=xbmcgui.Dialog()
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPy.notification(__addonname__,sting)
  except:
   otcGuEWmdgRIHJjUQYFsKaqlSTkvDh
 def addon_log(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD,string):
  try:
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPz=string.encode('utf-8','ignore')
  except:
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPz='addonException: addon_log'
  otcGuEWmdgRIHJjUQYFsKaqlSTkvPB=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,otcGuEWmdgRIHJjUQYFsKaqlSTkvPz),level=otcGuEWmdgRIHJjUQYFsKaqlSTkvPB)
 def get_keyboard_input(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD,otcGuEWmdgRIHJjUQYFsKaqlSTkvPh):
  otcGuEWmdgRIHJjUQYFsKaqlSTkvPV=otcGuEWmdgRIHJjUQYFsKaqlSTkvDh
  kb=xbmc.Keyboard()
  kb.setHeading(otcGuEWmdgRIHJjUQYFsKaqlSTkvPh)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPV=kb.getText()
  return otcGuEWmdgRIHJjUQYFsKaqlSTkvPV
 def get_settings_account(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD):
  otcGuEWmdgRIHJjUQYFsKaqlSTkvPX =__addon__.getSetting('id')
  otcGuEWmdgRIHJjUQYFsKaqlSTkvPN =__addon__.getSetting('pw')
  return(otcGuEWmdgRIHJjUQYFsKaqlSTkvPX,otcGuEWmdgRIHJjUQYFsKaqlSTkvPN)
 def get_settings_hidescoreyn(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD):
  otcGuEWmdgRIHJjUQYFsKaqlSTkvPr =__addon__.getSetting('hidescore')
  if otcGuEWmdgRIHJjUQYFsKaqlSTkvPr=='false':
   return otcGuEWmdgRIHJjUQYFsKaqlSTkvDL
  else:
   return otcGuEWmdgRIHJjUQYFsKaqlSTkvDf
 def add_dir(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD,label,sublabel='',img='',infoLabels=otcGuEWmdgRIHJjUQYFsKaqlSTkvDh,isFolder=otcGuEWmdgRIHJjUQYFsKaqlSTkvDf,params='',isLink=otcGuEWmdgRIHJjUQYFsKaqlSTkvDL,ContextMenu=otcGuEWmdgRIHJjUQYFsKaqlSTkvDh):
  otcGuEWmdgRIHJjUQYFsKaqlSTkvPO='%s?%s'%(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD._addon_url,urllib.parse.urlencode(params))
  if sublabel:otcGuEWmdgRIHJjUQYFsKaqlSTkvPh='%s < %s >'%(label,sublabel)
  else: otcGuEWmdgRIHJjUQYFsKaqlSTkvPh=label
  if not img:img='DefaultFolder.png'
  otcGuEWmdgRIHJjUQYFsKaqlSTkvPL=xbmcgui.ListItem(otcGuEWmdgRIHJjUQYFsKaqlSTkvPh)
  otcGuEWmdgRIHJjUQYFsKaqlSTkvPL.setArt({'thumb':img,'icon':img,'poster':img})
  if infoLabels:otcGuEWmdgRIHJjUQYFsKaqlSTkvPL.setInfo(type="Video",infoLabels=infoLabels)
  if not isFolder and not isLink:
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPL.setProperty('IsPlayable','true')
  if ContextMenu:otcGuEWmdgRIHJjUQYFsKaqlSTkvPL.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD._addon_handle,otcGuEWmdgRIHJjUQYFsKaqlSTkvPO,otcGuEWmdgRIHJjUQYFsKaqlSTkvPL,isFolder)
 def get_selQuality(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD,etype):
  try:
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPf='selected_quality'
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPn=[1080,720,540]
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPM=otcGuEWmdgRIHJjUQYFsKaqlSTkvDn(__addon__.getSetting(otcGuEWmdgRIHJjUQYFsKaqlSTkvPf))
   return otcGuEWmdgRIHJjUQYFsKaqlSTkvPn[otcGuEWmdgRIHJjUQYFsKaqlSTkvPM]
  except:
   otcGuEWmdgRIHJjUQYFsKaqlSTkvDh
  return 1080 
 def dp_Main_List(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD):
  for otcGuEWmdgRIHJjUQYFsKaqlSTkvPi in otcGuEWmdgRIHJjUQYFsKaqlSTkvPC:
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPh=otcGuEWmdgRIHJjUQYFsKaqlSTkvPi.get('title')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxP=''
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxC={'mode':otcGuEWmdgRIHJjUQYFsKaqlSTkvPi.get('mode'),'page':'1'}
   if otcGuEWmdgRIHJjUQYFsKaqlSTkvPi.get('mode')=='XXX':
    otcGuEWmdgRIHJjUQYFsKaqlSTkvxw=otcGuEWmdgRIHJjUQYFsKaqlSTkvDL
    otcGuEWmdgRIHJjUQYFsKaqlSTkvxD =otcGuEWmdgRIHJjUQYFsKaqlSTkvDf
   else:
    otcGuEWmdgRIHJjUQYFsKaqlSTkvxw=otcGuEWmdgRIHJjUQYFsKaqlSTkvDf
    otcGuEWmdgRIHJjUQYFsKaqlSTkvxD =otcGuEWmdgRIHJjUQYFsKaqlSTkvDL
   if 'icon' in otcGuEWmdgRIHJjUQYFsKaqlSTkvPi:otcGuEWmdgRIHJjUQYFsKaqlSTkvxP=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',otcGuEWmdgRIHJjUQYFsKaqlSTkvPi.get('icon')) 
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.add_dir(otcGuEWmdgRIHJjUQYFsKaqlSTkvPh,sublabel='',img=otcGuEWmdgRIHJjUQYFsKaqlSTkvxP,infoLabels=otcGuEWmdgRIHJjUQYFsKaqlSTkvDh,isFolder=otcGuEWmdgRIHJjUQYFsKaqlSTkvxw,params=otcGuEWmdgRIHJjUQYFsKaqlSTkvxC,isLink=otcGuEWmdgRIHJjUQYFsKaqlSTkvxD)
  if otcGuEWmdgRIHJjUQYFsKaqlSTkvDM(otcGuEWmdgRIHJjUQYFsKaqlSTkvPC)>0:xbmcplugin.endOfDirectory(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD._addon_handle)
 def dp_MainLeague_List(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD,args):
  otcGuEWmdgRIHJjUQYFsKaqlSTkvxe=otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.SpotvObj.GetTitleGroupList()
  for otcGuEWmdgRIHJjUQYFsKaqlSTkvxb in otcGuEWmdgRIHJjUQYFsKaqlSTkvxe:
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPh =otcGuEWmdgRIHJjUQYFsKaqlSTkvxb.get('title')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxA =otcGuEWmdgRIHJjUQYFsKaqlSTkvxb.get('logo')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxy =otcGuEWmdgRIHJjUQYFsKaqlSTkvxb.get('reagueId')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxz =otcGuEWmdgRIHJjUQYFsKaqlSTkvxb.get('subGame')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxB={'mediatype':'episode','plot':'%s\n\n%s'%(otcGuEWmdgRIHJjUQYFsKaqlSTkvPh,otcGuEWmdgRIHJjUQYFsKaqlSTkvxz)}
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxC={'mode':'LEAGUE_GROUP','reagueId':otcGuEWmdgRIHJjUQYFsKaqlSTkvxy}
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.add_dir(otcGuEWmdgRIHJjUQYFsKaqlSTkvPh,sublabel=otcGuEWmdgRIHJjUQYFsKaqlSTkvDh,img=otcGuEWmdgRIHJjUQYFsKaqlSTkvxA,infoLabels=otcGuEWmdgRIHJjUQYFsKaqlSTkvxB,isFolder=otcGuEWmdgRIHJjUQYFsKaqlSTkvDf,params=otcGuEWmdgRIHJjUQYFsKaqlSTkvxC)
  if otcGuEWmdgRIHJjUQYFsKaqlSTkvDM(otcGuEWmdgRIHJjUQYFsKaqlSTkvxe)>0:xbmcplugin.endOfDirectory(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD._addon_handle,cacheToDisc=otcGuEWmdgRIHJjUQYFsKaqlSTkvDL)
 def dp_NowVod_GroupList(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD,args):
  otcGuEWmdgRIHJjUQYFsKaqlSTkvxV=otcGuEWmdgRIHJjUQYFsKaqlSTkvDn(args.get('page'))
  otcGuEWmdgRIHJjUQYFsKaqlSTkvxe,otcGuEWmdgRIHJjUQYFsKaqlSTkvxX=otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.SpotvObj.Get_NowVod_GroupList(otcGuEWmdgRIHJjUQYFsKaqlSTkvxV)
  for otcGuEWmdgRIHJjUQYFsKaqlSTkvxb in otcGuEWmdgRIHJjUQYFsKaqlSTkvxe:
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxN =otcGuEWmdgRIHJjUQYFsKaqlSTkvxb.get('vodTitle')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxr =otcGuEWmdgRIHJjUQYFsKaqlSTkvxb.get('vodId')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxO =otcGuEWmdgRIHJjUQYFsKaqlSTkvxb.get('vodType')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxA=otcGuEWmdgRIHJjUQYFsKaqlSTkvxb.get('thumbnail')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxh =otcGuEWmdgRIHJjUQYFsKaqlSTkvxb.get('vtypeId')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxL =otcGuEWmdgRIHJjUQYFsKaqlSTkvxb.get('duration')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxB={'mediatype':'episode','duration':otcGuEWmdgRIHJjUQYFsKaqlSTkvxL,'plot':otcGuEWmdgRIHJjUQYFsKaqlSTkvxN}
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxC={'mode':'NOW_VOD','mediacode':otcGuEWmdgRIHJjUQYFsKaqlSTkvxr,'mediatype':'vod','vtypeId':otcGuEWmdgRIHJjUQYFsKaqlSTkvxh}
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.add_dir(otcGuEWmdgRIHJjUQYFsKaqlSTkvxN,sublabel=otcGuEWmdgRIHJjUQYFsKaqlSTkvxO,img=otcGuEWmdgRIHJjUQYFsKaqlSTkvxA,infoLabels=otcGuEWmdgRIHJjUQYFsKaqlSTkvxB,isFolder=otcGuEWmdgRIHJjUQYFsKaqlSTkvDL,params=otcGuEWmdgRIHJjUQYFsKaqlSTkvxC)
  if otcGuEWmdgRIHJjUQYFsKaqlSTkvxX:
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxC['mode'] ='NOW_GROUP' 
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxC['page'] =otcGuEWmdgRIHJjUQYFsKaqlSTkvDi(otcGuEWmdgRIHJjUQYFsKaqlSTkvxV+1)
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPh='[B]%s >>[/B]'%'다음 페이지'
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxf=otcGuEWmdgRIHJjUQYFsKaqlSTkvDi(otcGuEWmdgRIHJjUQYFsKaqlSTkvxV+1)
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxP=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.add_dir(otcGuEWmdgRIHJjUQYFsKaqlSTkvPh,sublabel=otcGuEWmdgRIHJjUQYFsKaqlSTkvxf,img=otcGuEWmdgRIHJjUQYFsKaqlSTkvxP,infoLabels=otcGuEWmdgRIHJjUQYFsKaqlSTkvDh,isFolder=otcGuEWmdgRIHJjUQYFsKaqlSTkvDf,params=otcGuEWmdgRIHJjUQYFsKaqlSTkvxC)
  xbmcplugin.setContent(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD._addon_handle,cacheToDisc=otcGuEWmdgRIHJjUQYFsKaqlSTkvDL)
 def dp_PopVod_GroupList(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD,args):
  otcGuEWmdgRIHJjUQYFsKaqlSTkvxe=otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.SpotvObj.GetPopularGroupList()
  for otcGuEWmdgRIHJjUQYFsKaqlSTkvxb in otcGuEWmdgRIHJjUQYFsKaqlSTkvxe:
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxN =otcGuEWmdgRIHJjUQYFsKaqlSTkvxb.get('vodTitle')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxr =otcGuEWmdgRIHJjUQYFsKaqlSTkvxb.get('vodId')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxO =otcGuEWmdgRIHJjUQYFsKaqlSTkvxb.get('vodType')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxA=otcGuEWmdgRIHJjUQYFsKaqlSTkvxb.get('thumbnail')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxh =otcGuEWmdgRIHJjUQYFsKaqlSTkvxb.get('vtypeId')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxL =otcGuEWmdgRIHJjUQYFsKaqlSTkvxb.get('duration')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxB={'mediatype':'episode','duration':otcGuEWmdgRIHJjUQYFsKaqlSTkvxL,'plot':otcGuEWmdgRIHJjUQYFsKaqlSTkvxN}
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxC={'mode':'POP_VOD','mediacode':otcGuEWmdgRIHJjUQYFsKaqlSTkvxr,'mediatype':'vod','vtypeId':otcGuEWmdgRIHJjUQYFsKaqlSTkvxh}
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.add_dir(otcGuEWmdgRIHJjUQYFsKaqlSTkvxN,sublabel=otcGuEWmdgRIHJjUQYFsKaqlSTkvxO,img=otcGuEWmdgRIHJjUQYFsKaqlSTkvxA,infoLabels=otcGuEWmdgRIHJjUQYFsKaqlSTkvxB,isFolder=otcGuEWmdgRIHJjUQYFsKaqlSTkvDL,params=otcGuEWmdgRIHJjUQYFsKaqlSTkvxC)
  xbmcplugin.setContent(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD._addon_handle,cacheToDisc=otcGuEWmdgRIHJjUQYFsKaqlSTkvDL)
 def dp_Season_List(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD,args):
  otcGuEWmdgRIHJjUQYFsKaqlSTkvxy=args.get('reagueId')
  otcGuEWmdgRIHJjUQYFsKaqlSTkvxe=otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.SpotvObj.GetSeasonList(otcGuEWmdgRIHJjUQYFsKaqlSTkvxy)
  for otcGuEWmdgRIHJjUQYFsKaqlSTkvxb in otcGuEWmdgRIHJjUQYFsKaqlSTkvxe:
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxM =otcGuEWmdgRIHJjUQYFsKaqlSTkvxb.get('reagueName')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxi =otcGuEWmdgRIHJjUQYFsKaqlSTkvxb.get('gameTypeId')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvCP =otcGuEWmdgRIHJjUQYFsKaqlSTkvxb.get('seasonName')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvCx =otcGuEWmdgRIHJjUQYFsKaqlSTkvxb.get('seasonId')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxB={'mediatype':'episode','plot':'%s - %s'%(otcGuEWmdgRIHJjUQYFsKaqlSTkvxM,otcGuEWmdgRIHJjUQYFsKaqlSTkvCP)}
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxC={'mode':'SEASON_GROUP','reagueId':otcGuEWmdgRIHJjUQYFsKaqlSTkvxy,'seasonId':otcGuEWmdgRIHJjUQYFsKaqlSTkvCx,'gameTypeId':otcGuEWmdgRIHJjUQYFsKaqlSTkvxi,'page':'1'}
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.add_dir(otcGuEWmdgRIHJjUQYFsKaqlSTkvxM,sublabel=otcGuEWmdgRIHJjUQYFsKaqlSTkvCP,img='',infoLabels=otcGuEWmdgRIHJjUQYFsKaqlSTkvxB,isFolder=otcGuEWmdgRIHJjUQYFsKaqlSTkvDf,params=otcGuEWmdgRIHJjUQYFsKaqlSTkvxC)
  if otcGuEWmdgRIHJjUQYFsKaqlSTkvDM(otcGuEWmdgRIHJjUQYFsKaqlSTkvxe)>0:xbmcplugin.endOfDirectory(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD._addon_handle,cacheToDisc=otcGuEWmdgRIHJjUQYFsKaqlSTkvDf)
 def dp_Game_List(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD,args):
  otcGuEWmdgRIHJjUQYFsKaqlSTkvxi=args.get('gameTypeId')
  otcGuEWmdgRIHJjUQYFsKaqlSTkvxy =args.get('reagueId')
  otcGuEWmdgRIHJjUQYFsKaqlSTkvCx =args.get('seasonId')
  otcGuEWmdgRIHJjUQYFsKaqlSTkvxV =otcGuEWmdgRIHJjUQYFsKaqlSTkvDn(args.get('page'))
  otcGuEWmdgRIHJjUQYFsKaqlSTkvxe,otcGuEWmdgRIHJjUQYFsKaqlSTkvxX=otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.SpotvObj.GetGameList(otcGuEWmdgRIHJjUQYFsKaqlSTkvxi,otcGuEWmdgRIHJjUQYFsKaqlSTkvxy,otcGuEWmdgRIHJjUQYFsKaqlSTkvCx,otcGuEWmdgRIHJjUQYFsKaqlSTkvxV,hidescore=otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.get_settings_hidescoreyn())
  for otcGuEWmdgRIHJjUQYFsKaqlSTkvxb in otcGuEWmdgRIHJjUQYFsKaqlSTkvxe:
   otcGuEWmdgRIHJjUQYFsKaqlSTkvCw =otcGuEWmdgRIHJjUQYFsKaqlSTkvxb.get('gameTitle')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvCD =otcGuEWmdgRIHJjUQYFsKaqlSTkvxb.get('beginDate')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxA =otcGuEWmdgRIHJjUQYFsKaqlSTkvxb.get('thumbnail')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvCp =otcGuEWmdgRIHJjUQYFsKaqlSTkvxb.get('gameId')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvCe =otcGuEWmdgRIHJjUQYFsKaqlSTkvxb.get('totVodCnt')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvCb =otcGuEWmdgRIHJjUQYFsKaqlSTkvxb.get('leaguenm')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvCA =otcGuEWmdgRIHJjUQYFsKaqlSTkvxb.get('seasonnm')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvCy =otcGuEWmdgRIHJjUQYFsKaqlSTkvxb.get('roundnm')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvCz =otcGuEWmdgRIHJjUQYFsKaqlSTkvxb.get('info_plot')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvCB ='%s < %s >'%(otcGuEWmdgRIHJjUQYFsKaqlSTkvCw,otcGuEWmdgRIHJjUQYFsKaqlSTkvCD)
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxB={'mediatype':'video','plot':otcGuEWmdgRIHJjUQYFsKaqlSTkvCz}
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxC={'mode':'GAME_VOD_GROUP' if otcGuEWmdgRIHJjUQYFsKaqlSTkvCe!=0 else 'XXX','saveTitle':otcGuEWmdgRIHJjUQYFsKaqlSTkvCB,'saveImg':otcGuEWmdgRIHJjUQYFsKaqlSTkvxA,'saveInfo':otcGuEWmdgRIHJjUQYFsKaqlSTkvxB['plot'],'gameid':otcGuEWmdgRIHJjUQYFsKaqlSTkvCp,'totVodCnt':otcGuEWmdgRIHJjUQYFsKaqlSTkvCe,}
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.add_dir(otcGuEWmdgRIHJjUQYFsKaqlSTkvCw,sublabel=otcGuEWmdgRIHJjUQYFsKaqlSTkvCD,img=otcGuEWmdgRIHJjUQYFsKaqlSTkvxA,infoLabels=otcGuEWmdgRIHJjUQYFsKaqlSTkvxB,isFolder=otcGuEWmdgRIHJjUQYFsKaqlSTkvDf,params=otcGuEWmdgRIHJjUQYFsKaqlSTkvxC)
  if otcGuEWmdgRIHJjUQYFsKaqlSTkvxX:
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxC['mode'] ='SEASON_GROUP' 
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxC['reagueId'] =otcGuEWmdgRIHJjUQYFsKaqlSTkvxy
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxC['seasonId'] =otcGuEWmdgRIHJjUQYFsKaqlSTkvCx
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxC['gameTypeId']=otcGuEWmdgRIHJjUQYFsKaqlSTkvxi
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxC['page'] =otcGuEWmdgRIHJjUQYFsKaqlSTkvDi(otcGuEWmdgRIHJjUQYFsKaqlSTkvxV+1)
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPh='[B]%s >>[/B]'%'다음 페이지'
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxf=otcGuEWmdgRIHJjUQYFsKaqlSTkvDi(otcGuEWmdgRIHJjUQYFsKaqlSTkvxV+1)
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxP=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.add_dir(otcGuEWmdgRIHJjUQYFsKaqlSTkvPh,sublabel=otcGuEWmdgRIHJjUQYFsKaqlSTkvxf,img=otcGuEWmdgRIHJjUQYFsKaqlSTkvxP,infoLabels=otcGuEWmdgRIHJjUQYFsKaqlSTkvDh,isFolder=otcGuEWmdgRIHJjUQYFsKaqlSTkvDf,params=otcGuEWmdgRIHJjUQYFsKaqlSTkvxC)
  if otcGuEWmdgRIHJjUQYFsKaqlSTkvDM(otcGuEWmdgRIHJjUQYFsKaqlSTkvxe)>0:xbmcplugin.endOfDirectory(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD._addon_handle,cacheToDisc=otcGuEWmdgRIHJjUQYFsKaqlSTkvDL)
 def dp_GameVod_List(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD,args):
  otcGuEWmdgRIHJjUQYFsKaqlSTkvCV =args.get('gameid')
  otcGuEWmdgRIHJjUQYFsKaqlSTkvCB=args.get('saveTitle')
  otcGuEWmdgRIHJjUQYFsKaqlSTkvCX =args.get('saveImg')
  otcGuEWmdgRIHJjUQYFsKaqlSTkvCN =args.get('saveInfo')
  otcGuEWmdgRIHJjUQYFsKaqlSTkvxe=otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.SpotvObj.GetGameVodList(otcGuEWmdgRIHJjUQYFsKaqlSTkvCV)
  for otcGuEWmdgRIHJjUQYFsKaqlSTkvxb in otcGuEWmdgRIHJjUQYFsKaqlSTkvxe:
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxN =otcGuEWmdgRIHJjUQYFsKaqlSTkvxb.get('vodTitle')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxr =otcGuEWmdgRIHJjUQYFsKaqlSTkvxb.get('vodId')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxO =otcGuEWmdgRIHJjUQYFsKaqlSTkvxb.get('vodType')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxA=otcGuEWmdgRIHJjUQYFsKaqlSTkvxb.get('thumbnail')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxh =otcGuEWmdgRIHJjUQYFsKaqlSTkvxb.get('vtypeId')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxL =otcGuEWmdgRIHJjUQYFsKaqlSTkvxb.get('duration')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxB={'mediatype':'episode','duration':otcGuEWmdgRIHJjUQYFsKaqlSTkvxL,'plot':'%s \n\n %s'%(otcGuEWmdgRIHJjUQYFsKaqlSTkvxN,otcGuEWmdgRIHJjUQYFsKaqlSTkvCN)}
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxC={'mode':'GAME_VOD','saveTitle':otcGuEWmdgRIHJjUQYFsKaqlSTkvCB,'saveImg':otcGuEWmdgRIHJjUQYFsKaqlSTkvCX,'saveId':otcGuEWmdgRIHJjUQYFsKaqlSTkvCV,'saveInfo':otcGuEWmdgRIHJjUQYFsKaqlSTkvCN,'mediacode':otcGuEWmdgRIHJjUQYFsKaqlSTkvxr,'mediatype':'vod','vtypeId':otcGuEWmdgRIHJjUQYFsKaqlSTkvxh}
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.add_dir(otcGuEWmdgRIHJjUQYFsKaqlSTkvxN,sublabel=otcGuEWmdgRIHJjUQYFsKaqlSTkvxO,img=otcGuEWmdgRIHJjUQYFsKaqlSTkvxA,infoLabels=otcGuEWmdgRIHJjUQYFsKaqlSTkvxB,isFolder=otcGuEWmdgRIHJjUQYFsKaqlSTkvDL,params=otcGuEWmdgRIHJjUQYFsKaqlSTkvxC)
  xbmcplugin.setContent(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD._addon_handle,cacheToDisc=otcGuEWmdgRIHJjUQYFsKaqlSTkvDL)
 def login_main(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD):
  (otcGuEWmdgRIHJjUQYFsKaqlSTkvCr,otcGuEWmdgRIHJjUQYFsKaqlSTkvCO)=otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.get_settings_account()
  if not(otcGuEWmdgRIHJjUQYFsKaqlSTkvCr and otcGuEWmdgRIHJjUQYFsKaqlSTkvCO):
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPy=xbmcgui.Dialog()
   otcGuEWmdgRIHJjUQYFsKaqlSTkvCh=otcGuEWmdgRIHJjUQYFsKaqlSTkvPy.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if otcGuEWmdgRIHJjUQYFsKaqlSTkvCh==otcGuEWmdgRIHJjUQYFsKaqlSTkvDf:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.cookiefile_check():return
  if xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINWAIT')=='TRUE':
   otcGuEWmdgRIHJjUQYFsKaqlSTkvCL=0
   while otcGuEWmdgRIHJjUQYFsKaqlSTkvDf:
    otcGuEWmdgRIHJjUQYFsKaqlSTkvCL+=1
    time.sleep(0.05)
    if otcGuEWmdgRIHJjUQYFsKaqlSTkvCL>600:return
  else:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','TRUE')
  otcGuEWmdgRIHJjUQYFsKaqlSTkvCf=otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.SpotvObj.GetCredential(otcGuEWmdgRIHJjUQYFsKaqlSTkvCr,otcGuEWmdgRIHJjUQYFsKaqlSTkvCO)
  if otcGuEWmdgRIHJjUQYFsKaqlSTkvCf:otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.cookiefile_save()
  xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
  if otcGuEWmdgRIHJjUQYFsKaqlSTkvCf==otcGuEWmdgRIHJjUQYFsKaqlSTkvDL:
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_LiveChannel_List(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD,args):
  otcGuEWmdgRIHJjUQYFsKaqlSTkvCn=otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.SpotvObj.GetLiveChannelList()
  for otcGuEWmdgRIHJjUQYFsKaqlSTkvCM in otcGuEWmdgRIHJjUQYFsKaqlSTkvCn:
   otcGuEWmdgRIHJjUQYFsKaqlSTkvpP =otcGuEWmdgRIHJjUQYFsKaqlSTkvCM.get('id')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPh =otcGuEWmdgRIHJjUQYFsKaqlSTkvCM.get('name')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxp =otcGuEWmdgRIHJjUQYFsKaqlSTkvCM.get('programName')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxA =otcGuEWmdgRIHJjUQYFsKaqlSTkvCM.get('logo')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvCi=otcGuEWmdgRIHJjUQYFsKaqlSTkvCM.get('channelepg')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvwP =otcGuEWmdgRIHJjUQYFsKaqlSTkvCM.get('free')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxB={'plot':'%s\n\n%s'%(otcGuEWmdgRIHJjUQYFsKaqlSTkvPh,otcGuEWmdgRIHJjUQYFsKaqlSTkvCi),'mediatype':'episode',}
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxC={'mode':'LIVE','mediacode':otcGuEWmdgRIHJjUQYFsKaqlSTkvpP,'free':otcGuEWmdgRIHJjUQYFsKaqlSTkvwP,'mediatype':'live'}
   if otcGuEWmdgRIHJjUQYFsKaqlSTkvwP:otcGuEWmdgRIHJjUQYFsKaqlSTkvPh+=' [free]'
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.add_dir(otcGuEWmdgRIHJjUQYFsKaqlSTkvPh,sublabel=otcGuEWmdgRIHJjUQYFsKaqlSTkvxp,img=otcGuEWmdgRIHJjUQYFsKaqlSTkvxA,infoLabels=otcGuEWmdgRIHJjUQYFsKaqlSTkvxB,isFolder=otcGuEWmdgRIHJjUQYFsKaqlSTkvDL,params=otcGuEWmdgRIHJjUQYFsKaqlSTkvxC)
  xbmcplugin.setContent(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD._addon_handle,'episodes')
  if otcGuEWmdgRIHJjUQYFsKaqlSTkvDM(otcGuEWmdgRIHJjUQYFsKaqlSTkvCn)>0:xbmcplugin.endOfDirectory(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD._addon_handle,cacheToDisc=otcGuEWmdgRIHJjUQYFsKaqlSTkvDL)
 def dp_EventLiveChannel_List(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD,args):
  otcGuEWmdgRIHJjUQYFsKaqlSTkvCn,otcGuEWmdgRIHJjUQYFsKaqlSTkvwx=otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.SpotvObj.GetEventLiveList()
  if otcGuEWmdgRIHJjUQYFsKaqlSTkvwx!=401 and otcGuEWmdgRIHJjUQYFsKaqlSTkvDM(otcGuEWmdgRIHJjUQYFsKaqlSTkvCn)==0:
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.addon_noti(__language__(30907).encode('utf8'))
  for otcGuEWmdgRIHJjUQYFsKaqlSTkvCM in otcGuEWmdgRIHJjUQYFsKaqlSTkvCn:
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPh =otcGuEWmdgRIHJjUQYFsKaqlSTkvCM.get('title')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxp =otcGuEWmdgRIHJjUQYFsKaqlSTkvCM.get('startTime')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxA =otcGuEWmdgRIHJjUQYFsKaqlSTkvCM.get('logo')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvwP =otcGuEWmdgRIHJjUQYFsKaqlSTkvCM.get('free')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxB={'mediatype':'episode','plot':'%s\n\n%s'%(otcGuEWmdgRIHJjUQYFsKaqlSTkvPh,otcGuEWmdgRIHJjUQYFsKaqlSTkvxp)}
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxC={'mode':'ELIVE','mediacode':otcGuEWmdgRIHJjUQYFsKaqlSTkvCM.get('liveId'),'free':otcGuEWmdgRIHJjUQYFsKaqlSTkvwP,'mediatype':'live'}
   if otcGuEWmdgRIHJjUQYFsKaqlSTkvwP:otcGuEWmdgRIHJjUQYFsKaqlSTkvPh+=' [free]'
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.add_dir(otcGuEWmdgRIHJjUQYFsKaqlSTkvPh,sublabel=otcGuEWmdgRIHJjUQYFsKaqlSTkvxp,img=otcGuEWmdgRIHJjUQYFsKaqlSTkvxA,infoLabels=otcGuEWmdgRIHJjUQYFsKaqlSTkvxB,isFolder=otcGuEWmdgRIHJjUQYFsKaqlSTkvDL,params=otcGuEWmdgRIHJjUQYFsKaqlSTkvxC)
  xbmcplugin.setContent(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD._addon_handle,'episodes')
  if otcGuEWmdgRIHJjUQYFsKaqlSTkvDM(otcGuEWmdgRIHJjUQYFsKaqlSTkvCn)>0:xbmcplugin.endOfDirectory(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD._addon_handle,cacheToDisc=otcGuEWmdgRIHJjUQYFsKaqlSTkvDf)
  return otcGuEWmdgRIHJjUQYFsKaqlSTkvwx
 def play_VIDEO(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD,args):
  otcGuEWmdgRIHJjUQYFsKaqlSTkvwC =args.get('mode')
  otcGuEWmdgRIHJjUQYFsKaqlSTkvwD =args.get('mediacode')
  otcGuEWmdgRIHJjUQYFsKaqlSTkvwp =args.get('mediatype')
  otcGuEWmdgRIHJjUQYFsKaqlSTkvxh =args.get('vtypeId')
  otcGuEWmdgRIHJjUQYFsKaqlSTkvwe =args.get('hlsUrl')
  if otcGuEWmdgRIHJjUQYFsKaqlSTkvwC=='LIVE':
   if args.get('free')=='False':
    if otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.SpotvObj.CheckSubEnd()==otcGuEWmdgRIHJjUQYFsKaqlSTkvDL:
     otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.addon_noti(__language__(30908).encode('utf8'))
     return
  elif otcGuEWmdgRIHJjUQYFsKaqlSTkvwC=='ELIVE':
   if args.get('free')=='False':
    if otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.SpotvObj.CheckSubEnd()==otcGuEWmdgRIHJjUQYFsKaqlSTkvDL:
     otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.addon_noti(__language__(30908).encode('utf8'))
     return
  if otcGuEWmdgRIHJjUQYFsKaqlSTkvwD=='' or otcGuEWmdgRIHJjUQYFsKaqlSTkvwD==otcGuEWmdgRIHJjUQYFsKaqlSTkvDh:
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.addon_noti(__language__(30907).encode('utf8'))
   return
  if otcGuEWmdgRIHJjUQYFsKaqlSTkvwC=='LIVE':
   otcGuEWmdgRIHJjUQYFsKaqlSTkvwb=otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.SpotvObj.GetHlsUrl(otcGuEWmdgRIHJjUQYFsKaqlSTkvwD)
  else:
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.addon_log('mediacode : '+otcGuEWmdgRIHJjUQYFsKaqlSTkvwD)
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.addon_log('mediatype : '+otcGuEWmdgRIHJjUQYFsKaqlSTkvwp)
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.addon_log('vtypeId   : '+otcGuEWmdgRIHJjUQYFsKaqlSTkvDi(otcGuEWmdgRIHJjUQYFsKaqlSTkvxh))
   otcGuEWmdgRIHJjUQYFsKaqlSTkvwb=otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.SpotvObj.GetBroadURL(otcGuEWmdgRIHJjUQYFsKaqlSTkvwD,otcGuEWmdgRIHJjUQYFsKaqlSTkvwp,otcGuEWmdgRIHJjUQYFsKaqlSTkvxh)
  if otcGuEWmdgRIHJjUQYFsKaqlSTkvwb=='':
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.addon_noti(__language__(30908).encode('utf8'))
   return
  otcGuEWmdgRIHJjUQYFsKaqlSTkvwA=otcGuEWmdgRIHJjUQYFsKaqlSTkvwb
  try:
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.addon_log('mainMode  = '+otcGuEWmdgRIHJjUQYFsKaqlSTkvwC)
  except:
   otcGuEWmdgRIHJjUQYFsKaqlSTkvDh
  otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.addon_log(otcGuEWmdgRIHJjUQYFsKaqlSTkvwA)
  otcGuEWmdgRIHJjUQYFsKaqlSTkvwy=xbmcgui.ListItem(path=otcGuEWmdgRIHJjUQYFsKaqlSTkvwA)
  xbmcplugin.setResolvedUrl(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD._addon_handle,otcGuEWmdgRIHJjUQYFsKaqlSTkvDf,otcGuEWmdgRIHJjUQYFsKaqlSTkvwy)
  try:
   if otcGuEWmdgRIHJjUQYFsKaqlSTkvwp=='vod' and otcGuEWmdgRIHJjUQYFsKaqlSTkvwC not in['POP_VOD','NOW_VOD']:
    otcGuEWmdgRIHJjUQYFsKaqlSTkvxC={'code':args.get('saveId'),'img':args.get('saveImg'),'title':args.get('saveTitle'),'info':args.get('saveInfo')}
    otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.Save_Watched_List(otcGuEWmdgRIHJjUQYFsKaqlSTkvwp,otcGuEWmdgRIHJjUQYFsKaqlSTkvxC)
  except:
   otcGuEWmdgRIHJjUQYFsKaqlSTkvDh
 def logout(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD):
  otcGuEWmdgRIHJjUQYFsKaqlSTkvPy=xbmcgui.Dialog()
  otcGuEWmdgRIHJjUQYFsKaqlSTkvCh=otcGuEWmdgRIHJjUQYFsKaqlSTkvPy.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if otcGuEWmdgRIHJjUQYFsKaqlSTkvCh==otcGuEWmdgRIHJjUQYFsKaqlSTkvDL:sys.exit()
  otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.SpotvObj.Init_ST_Total()
  if os.path.isfile(otcGuEWmdgRIHJjUQYFsKaqlSTkvPw):os.remove(otcGuEWmdgRIHJjUQYFsKaqlSTkvPw)
  otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD):
  otcGuEWmdgRIHJjUQYFsKaqlSTkvwz =otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.SpotvObj.Get_Now_Datetime()
  otcGuEWmdgRIHJjUQYFsKaqlSTkvwB=otcGuEWmdgRIHJjUQYFsKaqlSTkvwz+datetime.timedelta(days=otcGuEWmdgRIHJjUQYFsKaqlSTkvDn(__addon__.getSetting('cache_ttl')))
  (otcGuEWmdgRIHJjUQYFsKaqlSTkvCr,otcGuEWmdgRIHJjUQYFsKaqlSTkvCO)=otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.get_settings_account()
  otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.SpotvObj.Save_session_acount(otcGuEWmdgRIHJjUQYFsKaqlSTkvCr,otcGuEWmdgRIHJjUQYFsKaqlSTkvCO)
  otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.SpotvObj.ST['account']['token_limit']=otcGuEWmdgRIHJjUQYFsKaqlSTkvwB.strftime('%Y%m%d')
  otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.SpotvObj.JsonFile_Save(otcGuEWmdgRIHJjUQYFsKaqlSTkvPw,otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.SpotvObj.ST)
 def cookiefile_check(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD):
  otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.SpotvObj.ST=otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.SpotvObj.JsonFile_Load(otcGuEWmdgRIHJjUQYFsKaqlSTkvPw)
  if 'account' not in otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.SpotvObj.ST:
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.SpotvObj.Init_ST_Total()
   return otcGuEWmdgRIHJjUQYFsKaqlSTkvDL
  (otcGuEWmdgRIHJjUQYFsKaqlSTkvwV,otcGuEWmdgRIHJjUQYFsKaqlSTkvwX)=otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.get_settings_account()
  (otcGuEWmdgRIHJjUQYFsKaqlSTkvwN,otcGuEWmdgRIHJjUQYFsKaqlSTkvwr)=otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.SpotvObj.Load_session_acount()
  if otcGuEWmdgRIHJjUQYFsKaqlSTkvwV!=otcGuEWmdgRIHJjUQYFsKaqlSTkvwN or otcGuEWmdgRIHJjUQYFsKaqlSTkvwX!=otcGuEWmdgRIHJjUQYFsKaqlSTkvwr:
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.SpotvObj.Init_ST_Total()
   return otcGuEWmdgRIHJjUQYFsKaqlSTkvDL
  if otcGuEWmdgRIHJjUQYFsKaqlSTkvDn(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))>otcGuEWmdgRIHJjUQYFsKaqlSTkvDn(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.SpotvObj.ST['account']['token_limit']):
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.SpotvObj.Init_ST_Total()
   return otcGuEWmdgRIHJjUQYFsKaqlSTkvDL
  return otcGuEWmdgRIHJjUQYFsKaqlSTkvDf
 def dp_History_Remove(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD,args):
  otcGuEWmdgRIHJjUQYFsKaqlSTkvwO=args.get('delType')
  otcGuEWmdgRIHJjUQYFsKaqlSTkvwh =args.get('sKey')
  otcGuEWmdgRIHJjUQYFsKaqlSTkvwL =args.get('vType')
  otcGuEWmdgRIHJjUQYFsKaqlSTkvPy=xbmcgui.Dialog()
  if otcGuEWmdgRIHJjUQYFsKaqlSTkvwO=='WATCH_ALL':
   otcGuEWmdgRIHJjUQYFsKaqlSTkvCh=otcGuEWmdgRIHJjUQYFsKaqlSTkvPy.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif otcGuEWmdgRIHJjUQYFsKaqlSTkvwO=='WATCH_ONE':
   otcGuEWmdgRIHJjUQYFsKaqlSTkvCh=otcGuEWmdgRIHJjUQYFsKaqlSTkvPy.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  if otcGuEWmdgRIHJjUQYFsKaqlSTkvCh==otcGuEWmdgRIHJjUQYFsKaqlSTkvDL:sys.exit()
  if otcGuEWmdgRIHJjUQYFsKaqlSTkvwO=='WATCH_ALL':
   otcGuEWmdgRIHJjUQYFsKaqlSTkvwf=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%otcGuEWmdgRIHJjUQYFsKaqlSTkvwL))
   if os.path.isfile(otcGuEWmdgRIHJjUQYFsKaqlSTkvwf):os.remove(otcGuEWmdgRIHJjUQYFsKaqlSTkvwf)
  elif otcGuEWmdgRIHJjUQYFsKaqlSTkvwO=='WATCH_ONE':
   otcGuEWmdgRIHJjUQYFsKaqlSTkvwf=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%otcGuEWmdgRIHJjUQYFsKaqlSTkvwL))
   try:
    otcGuEWmdgRIHJjUQYFsKaqlSTkvwn=otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.Load_List_File(otcGuEWmdgRIHJjUQYFsKaqlSTkvwL) 
    fp=otcGuEWmdgRIHJjUQYFsKaqlSTkvpx(otcGuEWmdgRIHJjUQYFsKaqlSTkvwf,'w',-1,'utf-8')
    for otcGuEWmdgRIHJjUQYFsKaqlSTkvwM in otcGuEWmdgRIHJjUQYFsKaqlSTkvwn:
     otcGuEWmdgRIHJjUQYFsKaqlSTkvwi=otcGuEWmdgRIHJjUQYFsKaqlSTkvpC(urllib.parse.parse_qsl(otcGuEWmdgRIHJjUQYFsKaqlSTkvwM))
     otcGuEWmdgRIHJjUQYFsKaqlSTkvDP=otcGuEWmdgRIHJjUQYFsKaqlSTkvwi.get('code').strip()
     if otcGuEWmdgRIHJjUQYFsKaqlSTkvwh!=otcGuEWmdgRIHJjUQYFsKaqlSTkvDP:
      fp.write(otcGuEWmdgRIHJjUQYFsKaqlSTkvwM)
    fp.close()
   except:
    otcGuEWmdgRIHJjUQYFsKaqlSTkvDh
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD,otcGuEWmdgRIHJjUQYFsKaqlSTkvwp):
  try:
   otcGuEWmdgRIHJjUQYFsKaqlSTkvDx=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%otcGuEWmdgRIHJjUQYFsKaqlSTkvwp))
   fp=otcGuEWmdgRIHJjUQYFsKaqlSTkvpx(otcGuEWmdgRIHJjUQYFsKaqlSTkvDx,'r',-1,'utf-8')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvDC=fp.readlines()
   fp.close()
  except:
   otcGuEWmdgRIHJjUQYFsKaqlSTkvDC=[]
  return otcGuEWmdgRIHJjUQYFsKaqlSTkvDC
 def Save_Watched_List(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD,stype,otcGuEWmdgRIHJjUQYFsKaqlSTkvPb):
  try:
   otcGuEWmdgRIHJjUQYFsKaqlSTkvDx=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   otcGuEWmdgRIHJjUQYFsKaqlSTkvwn=otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.Load_List_File(stype) 
   fp=otcGuEWmdgRIHJjUQYFsKaqlSTkvpx(otcGuEWmdgRIHJjUQYFsKaqlSTkvDx,'w',-1,'utf-8')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvDw=urllib.parse.urlencode(otcGuEWmdgRIHJjUQYFsKaqlSTkvPb)
   otcGuEWmdgRIHJjUQYFsKaqlSTkvDw=otcGuEWmdgRIHJjUQYFsKaqlSTkvDw+'\n'
   fp.write(otcGuEWmdgRIHJjUQYFsKaqlSTkvDw)
   otcGuEWmdgRIHJjUQYFsKaqlSTkvDp=0
   for otcGuEWmdgRIHJjUQYFsKaqlSTkvwM in otcGuEWmdgRIHJjUQYFsKaqlSTkvwn:
    otcGuEWmdgRIHJjUQYFsKaqlSTkvwi=otcGuEWmdgRIHJjUQYFsKaqlSTkvpC(urllib.parse.parse_qsl(otcGuEWmdgRIHJjUQYFsKaqlSTkvwM))
    otcGuEWmdgRIHJjUQYFsKaqlSTkvDe=otcGuEWmdgRIHJjUQYFsKaqlSTkvPb.get('code')
    otcGuEWmdgRIHJjUQYFsKaqlSTkvDb=otcGuEWmdgRIHJjUQYFsKaqlSTkvwi.get('code')
    if otcGuEWmdgRIHJjUQYFsKaqlSTkvDe!=otcGuEWmdgRIHJjUQYFsKaqlSTkvDb:
     fp.write(otcGuEWmdgRIHJjUQYFsKaqlSTkvwM)
     otcGuEWmdgRIHJjUQYFsKaqlSTkvDp+=1
     if otcGuEWmdgRIHJjUQYFsKaqlSTkvDp>=50:break
   fp.close()
  except:
   otcGuEWmdgRIHJjUQYFsKaqlSTkvDh
 def dp_Watch_List(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD,args):
  otcGuEWmdgRIHJjUQYFsKaqlSTkvwp ='vod'
  if otcGuEWmdgRIHJjUQYFsKaqlSTkvwp=='vod':
   otcGuEWmdgRIHJjUQYFsKaqlSTkvDA=otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.Load_List_File(otcGuEWmdgRIHJjUQYFsKaqlSTkvwp)
   for otcGuEWmdgRIHJjUQYFsKaqlSTkvDy in otcGuEWmdgRIHJjUQYFsKaqlSTkvDA:
    otcGuEWmdgRIHJjUQYFsKaqlSTkvDz=otcGuEWmdgRIHJjUQYFsKaqlSTkvpC(urllib.parse.parse_qsl(otcGuEWmdgRIHJjUQYFsKaqlSTkvDy))
    otcGuEWmdgRIHJjUQYFsKaqlSTkvPh =otcGuEWmdgRIHJjUQYFsKaqlSTkvDz.get('title')
    otcGuEWmdgRIHJjUQYFsKaqlSTkvxA=otcGuEWmdgRIHJjUQYFsKaqlSTkvDz.get('img')
    otcGuEWmdgRIHJjUQYFsKaqlSTkvwD=otcGuEWmdgRIHJjUQYFsKaqlSTkvDz.get('code')
    otcGuEWmdgRIHJjUQYFsKaqlSTkvDB =otcGuEWmdgRIHJjUQYFsKaqlSTkvDz.get('info')
    otcGuEWmdgRIHJjUQYFsKaqlSTkvxB={}
    otcGuEWmdgRIHJjUQYFsKaqlSTkvxB['plot'] =otcGuEWmdgRIHJjUQYFsKaqlSTkvDB
    otcGuEWmdgRIHJjUQYFsKaqlSTkvxB['mediatype']='tvshow'
    otcGuEWmdgRIHJjUQYFsKaqlSTkvxC={'mode':'GAME_VOD_GROUP','gameid':otcGuEWmdgRIHJjUQYFsKaqlSTkvwD,'saveTitle':otcGuEWmdgRIHJjUQYFsKaqlSTkvPh,'saveImg':otcGuEWmdgRIHJjUQYFsKaqlSTkvxA,'saveInfo':otcGuEWmdgRIHJjUQYFsKaqlSTkvDB,'mediatype':otcGuEWmdgRIHJjUQYFsKaqlSTkvwp}
    otcGuEWmdgRIHJjUQYFsKaqlSTkvDV={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':otcGuEWmdgRIHJjUQYFsKaqlSTkvwD,'vType':otcGuEWmdgRIHJjUQYFsKaqlSTkvwp,}
    otcGuEWmdgRIHJjUQYFsKaqlSTkvDX=urllib.parse.urlencode(otcGuEWmdgRIHJjUQYFsKaqlSTkvDV)
    otcGuEWmdgRIHJjUQYFsKaqlSTkvDN=[('선택된 시청이력 ( %s ) 삭제'%(otcGuEWmdgRIHJjUQYFsKaqlSTkvPh),'RunPlugin(plugin://plugin.video.spotvm/?%s)'%(otcGuEWmdgRIHJjUQYFsKaqlSTkvDX))]
    otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.add_dir(otcGuEWmdgRIHJjUQYFsKaqlSTkvPh,sublabel='',img=otcGuEWmdgRIHJjUQYFsKaqlSTkvxA,infoLabels=otcGuEWmdgRIHJjUQYFsKaqlSTkvxB,isFolder=otcGuEWmdgRIHJjUQYFsKaqlSTkvDf,params=otcGuEWmdgRIHJjUQYFsKaqlSTkvxC,ContextMenu=otcGuEWmdgRIHJjUQYFsKaqlSTkvDN)
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxB={'plot':'시청목록을 삭제합니다.'}
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPh='*** 시청목록 삭제 ***'
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxC={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':otcGuEWmdgRIHJjUQYFsKaqlSTkvwp,}
   otcGuEWmdgRIHJjUQYFsKaqlSTkvxP=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.add_dir(otcGuEWmdgRIHJjUQYFsKaqlSTkvPh,sublabel='',img=otcGuEWmdgRIHJjUQYFsKaqlSTkvxP,infoLabels=otcGuEWmdgRIHJjUQYFsKaqlSTkvxB,isFolder=otcGuEWmdgRIHJjUQYFsKaqlSTkvDL,params=otcGuEWmdgRIHJjUQYFsKaqlSTkvxC,isLink=otcGuEWmdgRIHJjUQYFsKaqlSTkvDf)
   xbmcplugin.endOfDirectory(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD._addon_handle,cacheToDisc=otcGuEWmdgRIHJjUQYFsKaqlSTkvDL)
 def spotv_main(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD):
  otcGuEWmdgRIHJjUQYFsKaqlSTkvDr=otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.main_params.get('mode',otcGuEWmdgRIHJjUQYFsKaqlSTkvDh)
  if otcGuEWmdgRIHJjUQYFsKaqlSTkvDr=='LOGOUT':
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.logout()
   return
  otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.login_main()
  if otcGuEWmdgRIHJjUQYFsKaqlSTkvDr is otcGuEWmdgRIHJjUQYFsKaqlSTkvDh:
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.dp_Main_List()
  elif otcGuEWmdgRIHJjUQYFsKaqlSTkvDr=='LIVE_GROUP':
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.dp_LiveChannel_List(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.main_params)
  elif otcGuEWmdgRIHJjUQYFsKaqlSTkvDr=='ELIVE_GROUP':
   otcGuEWmdgRIHJjUQYFsKaqlSTkvwx=otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.dp_EventLiveChannel_List(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.main_params)
   if otcGuEWmdgRIHJjUQYFsKaqlSTkvwx==401:
    if os.path.isfile(otcGuEWmdgRIHJjUQYFsKaqlSTkvPw):os.remove(otcGuEWmdgRIHJjUQYFsKaqlSTkvPw)
    otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.login_main()
    otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.dp_EventLiveChannel_List(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.main_params)
  elif otcGuEWmdgRIHJjUQYFsKaqlSTkvDr in['LIVE','GAME_VOD','POP_VOD','NOW_VOD','ELIVE']:
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.play_VIDEO(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.main_params)
  elif otcGuEWmdgRIHJjUQYFsKaqlSTkvDr=='VOD_GROUP':
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.dp_MainLeague_List(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.main_params)
  elif otcGuEWmdgRIHJjUQYFsKaqlSTkvDr=='NOW_GROUP':
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.dp_NowVod_GroupList(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.main_params)
  elif otcGuEWmdgRIHJjUQYFsKaqlSTkvDr=='POP_GROUP':
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.dp_PopVod_GroupList(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.main_params)
  elif otcGuEWmdgRIHJjUQYFsKaqlSTkvDr=='LEAGUE_GROUP':
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.dp_Season_List(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.main_params)
  elif otcGuEWmdgRIHJjUQYFsKaqlSTkvDr=='SEASON_GROUP':
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.dp_Game_List(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.main_params)
  elif otcGuEWmdgRIHJjUQYFsKaqlSTkvDr=='GAME_VOD_GROUP':
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.dp_GameVod_List(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.main_params)
  elif otcGuEWmdgRIHJjUQYFsKaqlSTkvDr=='WATCH':
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.dp_Watch_List(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.main_params)
  elif otcGuEWmdgRIHJjUQYFsKaqlSTkvDr=='MYVIEW_REMOVE':
   otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.dp_History_Remove(otcGuEWmdgRIHJjUQYFsKaqlSTkvPD.main_params)
  else:
   otcGuEWmdgRIHJjUQYFsKaqlSTkvDh
# Created by pyminifier (https://github.com/liftoff/pyminifier)
