__author__="NightRain"
WunlkOAgsTyLafYGimtvXqCpwFJQeP=object
WunlkOAgsTyLafYGimtvXqCpwFJQec=None
WunlkOAgsTyLafYGimtvXqCpwFJQeI=False
WunlkOAgsTyLafYGimtvXqCpwFJQex=open
WunlkOAgsTyLafYGimtvXqCpwFJQer=True
WunlkOAgsTyLafYGimtvXqCpwFJQeV=str
WunlkOAgsTyLafYGimtvXqCpwFJQeH=Exception
WunlkOAgsTyLafYGimtvXqCpwFJQeo=print
WunlkOAgsTyLafYGimtvXqCpwFJQeU=int
WunlkOAgsTyLafYGimtvXqCpwFJQej=len
WunlkOAgsTyLafYGimtvXqCpwFJQed=range
import urllib
import re
import json
import sys
import time
import requests
import datetime
import base64
WunlkOAgsTyLafYGimtvXqCpwFJQhD={'stream50':1080,'stream40':720,'stream30':540}
class WunlkOAgsTyLafYGimtvXqCpwFJQhS(WunlkOAgsTyLafYGimtvXqCpwFJQeP):
 def __init__(WunlkOAgsTyLafYGimtvXqCpwFJQhN):
  WunlkOAgsTyLafYGimtvXqCpwFJQhN.SPOTV_PMCODE ='987'
  WunlkOAgsTyLafYGimtvXqCpwFJQhN.SPOTV_PMSIZE =3
  WunlkOAgsTyLafYGimtvXqCpwFJQhN.GAMELIST_LIMIT =10
  WunlkOAgsTyLafYGimtvXqCpwFJQhN.API_DOMAIN ='https://www.spotvnow.co.kr'
  WunlkOAgsTyLafYGimtvXqCpwFJQhN.BC_DOMAIN ='https://players.brightcove.net'
  WunlkOAgsTyLafYGimtvXqCpwFJQhN.PLAYER_DOMAIN ='https://edge.api.brightcove.com'
  WunlkOAgsTyLafYGimtvXqCpwFJQhN.STREAM_DOMAIN ='https://gtm-spotv.brightcovecdn.com'
  WunlkOAgsTyLafYGimtvXqCpwFJQhN.STREAM_M3U8 ='ap-northeast-1/5764318566001/playlist_dvr'
  WunlkOAgsTyLafYGimtvXqCpwFJQhN.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36'
  WunlkOAgsTyLafYGimtvXqCpwFJQhN.DEFAULT_HEADER ={'user-agent':WunlkOAgsTyLafYGimtvXqCpwFJQhN.USER_AGENT}
  WunlkOAgsTyLafYGimtvXqCpwFJQhN.COOKIE_FILE_NAME=''
  WunlkOAgsTyLafYGimtvXqCpwFJQhN.ST ={}
  WunlkOAgsTyLafYGimtvXqCpwFJQhN.Init_ST_Total()
 def Init_ST_Total(WunlkOAgsTyLafYGimtvXqCpwFJQhN):
  WunlkOAgsTyLafYGimtvXqCpwFJQhN.ST={'account':{},'cookies':{'spotv_sessionid':'','spotv_session':'','spotv_accountId':'','spotv_policyKey':'','spotv_subend':'',},}
 def callRequestCookies(WunlkOAgsTyLafYGimtvXqCpwFJQhN,jobtype,WunlkOAgsTyLafYGimtvXqCpwFJQhd,payload=WunlkOAgsTyLafYGimtvXqCpwFJQec,params=WunlkOAgsTyLafYGimtvXqCpwFJQec,headers=WunlkOAgsTyLafYGimtvXqCpwFJQec,cookies=WunlkOAgsTyLafYGimtvXqCpwFJQec,redirects=WunlkOAgsTyLafYGimtvXqCpwFJQeI):
  WunlkOAgsTyLafYGimtvXqCpwFJQhe=WunlkOAgsTyLafYGimtvXqCpwFJQhN.DEFAULT_HEADER
  if headers:WunlkOAgsTyLafYGimtvXqCpwFJQhe.update(headers)
  if jobtype=='Get':
   WunlkOAgsTyLafYGimtvXqCpwFJQhM=requests.get(WunlkOAgsTyLafYGimtvXqCpwFJQhd,params=params,headers=WunlkOAgsTyLafYGimtvXqCpwFJQhe,cookies=cookies,allow_redirects=redirects)
  else:
   WunlkOAgsTyLafYGimtvXqCpwFJQhM=requests.post(WunlkOAgsTyLafYGimtvXqCpwFJQhd,data=payload,params=params,headers=WunlkOAgsTyLafYGimtvXqCpwFJQhe,cookies=cookies,allow_redirects=redirects)
  return WunlkOAgsTyLafYGimtvXqCpwFJQhM
 def JsonFile_Save(WunlkOAgsTyLafYGimtvXqCpwFJQhN,filename,WunlkOAgsTyLafYGimtvXqCpwFJQhR):
  if filename=='':return WunlkOAgsTyLafYGimtvXqCpwFJQeI
  try:
   fp=WunlkOAgsTyLafYGimtvXqCpwFJQex(filename,'w',-1,'utf-8')
   json.dump(WunlkOAgsTyLafYGimtvXqCpwFJQhR,fp,indent=4,ensure_ascii=WunlkOAgsTyLafYGimtvXqCpwFJQeI)
   fp.close()
  except:
   return WunlkOAgsTyLafYGimtvXqCpwFJQeI
  return WunlkOAgsTyLafYGimtvXqCpwFJQer
 def JsonFile_Load(WunlkOAgsTyLafYGimtvXqCpwFJQhN,filename):
  if filename=='':return{}
  try:
   fp=WunlkOAgsTyLafYGimtvXqCpwFJQex(filename,'r',-1,'utf-8')
   WunlkOAgsTyLafYGimtvXqCpwFJQhK=json.load(fp)
   fp.close()
  except:
   return{}
  return WunlkOAgsTyLafYGimtvXqCpwFJQhK
 def Save_session_acount(WunlkOAgsTyLafYGimtvXqCpwFJQhN,WunlkOAgsTyLafYGimtvXqCpwFJQhb,WunlkOAgsTyLafYGimtvXqCpwFJQhz):
  WunlkOAgsTyLafYGimtvXqCpwFJQhN.ST['account']['stid'] =base64.standard_b64encode(WunlkOAgsTyLafYGimtvXqCpwFJQhb.encode()).decode('utf-8')
  WunlkOAgsTyLafYGimtvXqCpwFJQhN.ST['account']['stpw'] =base64.standard_b64encode(WunlkOAgsTyLafYGimtvXqCpwFJQhz.encode()).decode('utf-8')
 def Load_session_acount(WunlkOAgsTyLafYGimtvXqCpwFJQhN):
  try:
   WunlkOAgsTyLafYGimtvXqCpwFJQhb =base64.standard_b64decode(WunlkOAgsTyLafYGimtvXqCpwFJQhN.ST['account']['stid']).decode('utf-8')
   WunlkOAgsTyLafYGimtvXqCpwFJQhz =base64.standard_b64decode(WunlkOAgsTyLafYGimtvXqCpwFJQhN.ST['account']['stpw']).decode('utf-8')
  except:
   return '',''
  return WunlkOAgsTyLafYGimtvXqCpwFJQhb,WunlkOAgsTyLafYGimtvXqCpwFJQhz
 def makeDefaultCookies(WunlkOAgsTyLafYGimtvXqCpwFJQhN):
  WunlkOAgsTyLafYGimtvXqCpwFJQhE={'SESSION':WunlkOAgsTyLafYGimtvXqCpwFJQhN.ST['cookies']['spotv_session']}
  return WunlkOAgsTyLafYGimtvXqCpwFJQhE
 def makeDefaultHeaders(WunlkOAgsTyLafYGimtvXqCpwFJQhN):
  WunlkOAgsTyLafYGimtvXqCpwFJQhP={'accept':'application/json;pk={}'.format(WunlkOAgsTyLafYGimtvXqCpwFJQhN.ST['cookies']['spotv_policyKey'])}
  return WunlkOAgsTyLafYGimtvXqCpwFJQhP
 def xmlText(WunlkOAgsTyLafYGimtvXqCpwFJQhN,in_text):
  WunlkOAgsTyLafYGimtvXqCpwFJQhc=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;')
  return WunlkOAgsTyLafYGimtvXqCpwFJQhc
 def GetCredential(WunlkOAgsTyLafYGimtvXqCpwFJQhN,user_id,user_pw):
  try:
   WunlkOAgsTyLafYGimtvXqCpwFJQhI=base64.standard_b64encode(user_id.encode('UTF-8')).decode('utf-8')
   WunlkOAgsTyLafYGimtvXqCpwFJQhx=base64.standard_b64encode(user_pw.encode('UTF-8')).decode('utf-8')
   WunlkOAgsTyLafYGimtvXqCpwFJQhr=WunlkOAgsTyLafYGimtvXqCpwFJQhN.API_DOMAIN+'/api/v2/login'
   WunlkOAgsTyLafYGimtvXqCpwFJQhV={'username':WunlkOAgsTyLafYGimtvXqCpwFJQhI,'password':WunlkOAgsTyLafYGimtvXqCpwFJQhx}
   WunlkOAgsTyLafYGimtvXqCpwFJQhV=json.dumps(WunlkOAgsTyLafYGimtvXqCpwFJQhV)
   WunlkOAgsTyLafYGimtvXqCpwFJQhH=WunlkOAgsTyLafYGimtvXqCpwFJQhN.callRequestCookies('Post',WunlkOAgsTyLafYGimtvXqCpwFJQhr,payload=WunlkOAgsTyLafYGimtvXqCpwFJQhV,params=WunlkOAgsTyLafYGimtvXqCpwFJQec,headers=WunlkOAgsTyLafYGimtvXqCpwFJQec,cookies=WunlkOAgsTyLafYGimtvXqCpwFJQec)
   WunlkOAgsTyLafYGimtvXqCpwFJQho=json.loads(WunlkOAgsTyLafYGimtvXqCpwFJQhH.text)
   for WunlkOAgsTyLafYGimtvXqCpwFJQhU in WunlkOAgsTyLafYGimtvXqCpwFJQhH.cookies:
    if WunlkOAgsTyLafYGimtvXqCpwFJQhU.name=='SESSION':
     WunlkOAgsTyLafYGimtvXqCpwFJQhN.ST['cookies']['spotv_session']=WunlkOAgsTyLafYGimtvXqCpwFJQhU.value
     break
   if WunlkOAgsTyLafYGimtvXqCpwFJQhN.ST['cookies']['spotv_session']=='':
    WunlkOAgsTyLafYGimtvXqCpwFJQhN.Init_ST_Total()
    return WunlkOAgsTyLafYGimtvXqCpwFJQeI
   WunlkOAgsTyLafYGimtvXqCpwFJQhN.ST['cookies']['spotv_sessionid']=WunlkOAgsTyLafYGimtvXqCpwFJQeV(WunlkOAgsTyLafYGimtvXqCpwFJQho['userId'])
   WunlkOAgsTyLafYGimtvXqCpwFJQhj=WunlkOAgsTyLafYGimtvXqCpwFJQhN.SPOTV_PMCODE+WunlkOAgsTyLafYGimtvXqCpwFJQeV(WunlkOAgsTyLafYGimtvXqCpwFJQho['subEndTime'])
   WunlkOAgsTyLafYGimtvXqCpwFJQhN.ST['cookies']['spotv_subend'] =base64.standard_b64encode(WunlkOAgsTyLafYGimtvXqCpwFJQhj.encode()).decode('utf-8')
   if WunlkOAgsTyLafYGimtvXqCpwFJQhN.GetPolicyKey()==WunlkOAgsTyLafYGimtvXqCpwFJQeI:
    WunlkOAgsTyLafYGimtvXqCpwFJQhN.Init_ST_Total()
    return WunlkOAgsTyLafYGimtvXqCpwFJQeI
  except WunlkOAgsTyLafYGimtvXqCpwFJQeH as exception:
   WunlkOAgsTyLafYGimtvXqCpwFJQeo(exception)
   WunlkOAgsTyLafYGimtvXqCpwFJQhN.Init_ST_Total()
   return WunlkOAgsTyLafYGimtvXqCpwFJQeI
  return WunlkOAgsTyLafYGimtvXqCpwFJQer
 def GetPolicyKey(WunlkOAgsTyLafYGimtvXqCpwFJQhN):
  try:
   WunlkOAgsTyLafYGimtvXqCpwFJQhd=WunlkOAgsTyLafYGimtvXqCpwFJQhN.GetBcPlayerUrl()
   if WunlkOAgsTyLafYGimtvXqCpwFJQhd=='':return WunlkOAgsTyLafYGimtvXqCpwFJQeI
   WunlkOAgsTyLafYGimtvXqCpwFJQhH=WunlkOAgsTyLafYGimtvXqCpwFJQhN.callRequestCookies('Get',WunlkOAgsTyLafYGimtvXqCpwFJQhd,payload=WunlkOAgsTyLafYGimtvXqCpwFJQec,params=WunlkOAgsTyLafYGimtvXqCpwFJQec,headers=WunlkOAgsTyLafYGimtvXqCpwFJQec,cookies=WunlkOAgsTyLafYGimtvXqCpwFJQec)
   WunlkOAgsTyLafYGimtvXqCpwFJQSh=WunlkOAgsTyLafYGimtvXqCpwFJQhH.text
   WunlkOAgsTyLafYGimtvXqCpwFJQSD =re.findall('accountId:\s*\"\d{13}\",\s*policyKey:\s*\".[^(){}]{100,300}\"',WunlkOAgsTyLafYGimtvXqCpwFJQSh)[0]
   WunlkOAgsTyLafYGimtvXqCpwFJQSD =WunlkOAgsTyLafYGimtvXqCpwFJQSD.replace('accountId','"accountId"')
   WunlkOAgsTyLafYGimtvXqCpwFJQSD =WunlkOAgsTyLafYGimtvXqCpwFJQSD.replace('policyKey','"policyKey"')
   WunlkOAgsTyLafYGimtvXqCpwFJQSD ='{'+WunlkOAgsTyLafYGimtvXqCpwFJQSD+'}'
   WunlkOAgsTyLafYGimtvXqCpwFJQSN=json.loads(WunlkOAgsTyLafYGimtvXqCpwFJQSD)
   WunlkOAgsTyLafYGimtvXqCpwFJQhN.ST['cookies']['spotv_accountId']=WunlkOAgsTyLafYGimtvXqCpwFJQSN['accountId']
   WunlkOAgsTyLafYGimtvXqCpwFJQhN.ST['cookies']['spotv_policyKey']=WunlkOAgsTyLafYGimtvXqCpwFJQSN['policyKey']
  except WunlkOAgsTyLafYGimtvXqCpwFJQeH as exception:
   WunlkOAgsTyLafYGimtvXqCpwFJQeo(exception)
   return WunlkOAgsTyLafYGimtvXqCpwFJQeI
  return WunlkOAgsTyLafYGimtvXqCpwFJQer
 def GetBcPlayerUrl(WunlkOAgsTyLafYGimtvXqCpwFJQhN):
  WunlkOAgsTyLafYGimtvXqCpwFJQSe=''
  try:
   WunlkOAgsTyLafYGimtvXqCpwFJQhd=WunlkOAgsTyLafYGimtvXqCpwFJQhN.GetMainJspath()
   if WunlkOAgsTyLafYGimtvXqCpwFJQhd=='':return WunlkOAgsTyLafYGimtvXqCpwFJQSe
   WunlkOAgsTyLafYGimtvXqCpwFJQhH=WunlkOAgsTyLafYGimtvXqCpwFJQhN.callRequestCookies('Get',WunlkOAgsTyLafYGimtvXqCpwFJQhd,payload=WunlkOAgsTyLafYGimtvXqCpwFJQec,params=WunlkOAgsTyLafYGimtvXqCpwFJQec,headers=WunlkOAgsTyLafYGimtvXqCpwFJQec,cookies=WunlkOAgsTyLafYGimtvXqCpwFJQec)
   WunlkOAgsTyLafYGimtvXqCpwFJQSh=WunlkOAgsTyLafYGimtvXqCpwFJQhH.text
   WunlkOAgsTyLafYGimtvXqCpwFJQSM =r'default:{(.*?)}'
   WunlkOAgsTyLafYGimtvXqCpwFJQSR =re.compile(WunlkOAgsTyLafYGimtvXqCpwFJQSM).findall(WunlkOAgsTyLafYGimtvXqCpwFJQSh)[0]
   WunlkOAgsTyLafYGimtvXqCpwFJQSB=r'bc:"(.*?)"'
   WunlkOAgsTyLafYGimtvXqCpwFJQSK=re.compile(WunlkOAgsTyLafYGimtvXqCpwFJQSB).findall(WunlkOAgsTyLafYGimtvXqCpwFJQSR)[0]
   WunlkOAgsTyLafYGimtvXqCpwFJQSb=r'":"(.*?)"'
   WunlkOAgsTyLafYGimtvXqCpwFJQSz=re.compile(WunlkOAgsTyLafYGimtvXqCpwFJQSb).findall(WunlkOAgsTyLafYGimtvXqCpwFJQSR)[0]
   WunlkOAgsTyLafYGimtvXqCpwFJQSe="%s/%s/%s_default/index.min.js"%(WunlkOAgsTyLafYGimtvXqCpwFJQhN.BC_DOMAIN,WunlkOAgsTyLafYGimtvXqCpwFJQSK,WunlkOAgsTyLafYGimtvXqCpwFJQSz)
  except WunlkOAgsTyLafYGimtvXqCpwFJQeH as exception:
   WunlkOAgsTyLafYGimtvXqCpwFJQeo(exception)
  return WunlkOAgsTyLafYGimtvXqCpwFJQSe
 def GetMainJspath(WunlkOAgsTyLafYGimtvXqCpwFJQhN):
  WunlkOAgsTyLafYGimtvXqCpwFJQSE=''
  try:
   WunlkOAgsTyLafYGimtvXqCpwFJQhd=WunlkOAgsTyLafYGimtvXqCpwFJQhN.API_DOMAIN
   WunlkOAgsTyLafYGimtvXqCpwFJQhH=WunlkOAgsTyLafYGimtvXqCpwFJQhN.callRequestCookies('Get',WunlkOAgsTyLafYGimtvXqCpwFJQhd,payload=WunlkOAgsTyLafYGimtvXqCpwFJQec,params=WunlkOAgsTyLafYGimtvXqCpwFJQec,headers=WunlkOAgsTyLafYGimtvXqCpwFJQec,cookies=WunlkOAgsTyLafYGimtvXqCpwFJQec)
   WunlkOAgsTyLafYGimtvXqCpwFJQSh=WunlkOAgsTyLafYGimtvXqCpwFJQhH.text
   WunlkOAgsTyLafYGimtvXqCpwFJQSD =re.findall('https://cdn.spotvnow.co.kr/dist/js/.{20}\.js',WunlkOAgsTyLafYGimtvXqCpwFJQSh)[0]
   WunlkOAgsTyLafYGimtvXqCpwFJQSE=WunlkOAgsTyLafYGimtvXqCpwFJQSD
  except WunlkOAgsTyLafYGimtvXqCpwFJQeH as exception:
   WunlkOAgsTyLafYGimtvXqCpwFJQeo(exception)
  return WunlkOAgsTyLafYGimtvXqCpwFJQSE
 def Get_Now_Datetime(WunlkOAgsTyLafYGimtvXqCpwFJQhN):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetLiveChannelList(WunlkOAgsTyLafYGimtvXqCpwFJQhN):
  WunlkOAgsTyLafYGimtvXqCpwFJQSc=[]
  WunlkOAgsTyLafYGimtvXqCpwFJQSI ={}
  try:
   WunlkOAgsTyLafYGimtvXqCpwFJQhd=WunlkOAgsTyLafYGimtvXqCpwFJQhN.API_DOMAIN+'/api/v2/channel'
   WunlkOAgsTyLafYGimtvXqCpwFJQhH=WunlkOAgsTyLafYGimtvXqCpwFJQhN.callRequestCookies('Get',WunlkOAgsTyLafYGimtvXqCpwFJQhd,payload=WunlkOAgsTyLafYGimtvXqCpwFJQec,params=WunlkOAgsTyLafYGimtvXqCpwFJQec,headers=WunlkOAgsTyLafYGimtvXqCpwFJQec,cookies=WunlkOAgsTyLafYGimtvXqCpwFJQec)
   WunlkOAgsTyLafYGimtvXqCpwFJQho=json.loads(WunlkOAgsTyLafYGimtvXqCpwFJQhH.text)
   WunlkOAgsTyLafYGimtvXqCpwFJQSI=WunlkOAgsTyLafYGimtvXqCpwFJQhN.GetEPGList()
   for WunlkOAgsTyLafYGimtvXqCpwFJQSx in WunlkOAgsTyLafYGimtvXqCpwFJQho:
    WunlkOAgsTyLafYGimtvXqCpwFJQSr={'id':WunlkOAgsTyLafYGimtvXqCpwFJQSx['id'],'name':WunlkOAgsTyLafYGimtvXqCpwFJQSx['name'],'logo':WunlkOAgsTyLafYGimtvXqCpwFJQSx['logo'],'free':WunlkOAgsTyLafYGimtvXqCpwFJQSx['free'],'programName':WunlkOAgsTyLafYGimtvXqCpwFJQSx['programName'],'channelepg':WunlkOAgsTyLafYGimtvXqCpwFJQSI.get(WunlkOAgsTyLafYGimtvXqCpwFJQSx['id']),}
    WunlkOAgsTyLafYGimtvXqCpwFJQSc.append(WunlkOAgsTyLafYGimtvXqCpwFJQSr)
  except WunlkOAgsTyLafYGimtvXqCpwFJQeH as exception:
   WunlkOAgsTyLafYGimtvXqCpwFJQeo(exception)
  return WunlkOAgsTyLafYGimtvXqCpwFJQSc
 def GetHlsUrl(WunlkOAgsTyLafYGimtvXqCpwFJQhN,mediacode):
  WunlkOAgsTyLafYGimtvXqCpwFJQSV=''
  try:
   WunlkOAgsTyLafYGimtvXqCpwFJQhd=WunlkOAgsTyLafYGimtvXqCpwFJQhN.API_DOMAIN+'/api/v2/channel/'+mediacode
   WunlkOAgsTyLafYGimtvXqCpwFJQhH=WunlkOAgsTyLafYGimtvXqCpwFJQhN.callRequestCookies('Get',WunlkOAgsTyLafYGimtvXqCpwFJQhd,payload=WunlkOAgsTyLafYGimtvXqCpwFJQec,params=WunlkOAgsTyLafYGimtvXqCpwFJQec,headers=WunlkOAgsTyLafYGimtvXqCpwFJQec,cookies=WunlkOAgsTyLafYGimtvXqCpwFJQec)
   WunlkOAgsTyLafYGimtvXqCpwFJQho=json.loads(WunlkOAgsTyLafYGimtvXqCpwFJQhH.text)
   WunlkOAgsTyLafYGimtvXqCpwFJQSV=WunlkOAgsTyLafYGimtvXqCpwFJQho['hlsUrl']
  except WunlkOAgsTyLafYGimtvXqCpwFJQeH as exception:
   WunlkOAgsTyLafYGimtvXqCpwFJQeo(exception)
  return WunlkOAgsTyLafYGimtvXqCpwFJQSV
 def GetEPGList(WunlkOAgsTyLafYGimtvXqCpwFJQhN):
  WunlkOAgsTyLafYGimtvXqCpwFJQSH={}
  WunlkOAgsTyLafYGimtvXqCpwFJQSo=WunlkOAgsTyLafYGimtvXqCpwFJQhN.Get_Now_Datetime()
  WunlkOAgsTyLafYGimtvXqCpwFJQSU=WunlkOAgsTyLafYGimtvXqCpwFJQSo.strftime('%Y%m%d%H%M')
  WunlkOAgsTyLafYGimtvXqCpwFJQSj='%s-%s-%s'%(WunlkOAgsTyLafYGimtvXqCpwFJQSU[0:4],WunlkOAgsTyLafYGimtvXqCpwFJQSU[4:6],WunlkOAgsTyLafYGimtvXqCpwFJQSU[6:8])
  WunlkOAgsTyLafYGimtvXqCpwFJQSd=(WunlkOAgsTyLafYGimtvXqCpwFJQSo+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M')
  try:
   WunlkOAgsTyLafYGimtvXqCpwFJQhd=WunlkOAgsTyLafYGimtvXqCpwFJQhN.API_DOMAIN+'/api/v2/program/'+WunlkOAgsTyLafYGimtvXqCpwFJQSj
   WunlkOAgsTyLafYGimtvXqCpwFJQhH=WunlkOAgsTyLafYGimtvXqCpwFJQhN.callRequestCookies('Get',WunlkOAgsTyLafYGimtvXqCpwFJQhd,payload=WunlkOAgsTyLafYGimtvXqCpwFJQec,params=WunlkOAgsTyLafYGimtvXqCpwFJQec,headers=WunlkOAgsTyLafYGimtvXqCpwFJQec,cookies=WunlkOAgsTyLafYGimtvXqCpwFJQec)
   WunlkOAgsTyLafYGimtvXqCpwFJQho=json.loads(WunlkOAgsTyLafYGimtvXqCpwFJQhH.text)
   WunlkOAgsTyLafYGimtvXqCpwFJQDh=-1 
   WunlkOAgsTyLafYGimtvXqCpwFJQDS =''
   for WunlkOAgsTyLafYGimtvXqCpwFJQSx in WunlkOAgsTyLafYGimtvXqCpwFJQho:
    WunlkOAgsTyLafYGimtvXqCpwFJQDN=WunlkOAgsTyLafYGimtvXqCpwFJQSx['channelId']
    WunlkOAgsTyLafYGimtvXqCpwFJQDe =WunlkOAgsTyLafYGimtvXqCpwFJQSx['startTime'].replace('-','').replace(' ','').replace(':','')
    WunlkOAgsTyLafYGimtvXqCpwFJQDM =WunlkOAgsTyLafYGimtvXqCpwFJQSx['endTime'].replace('-','').replace(' ','').replace(':','')
    if WunlkOAgsTyLafYGimtvXqCpwFJQeU(WunlkOAgsTyLafYGimtvXqCpwFJQSU)>WunlkOAgsTyLafYGimtvXqCpwFJQeU(WunlkOAgsTyLafYGimtvXqCpwFJQDM) :continue
    if WunlkOAgsTyLafYGimtvXqCpwFJQeU(WunlkOAgsTyLafYGimtvXqCpwFJQSd)<WunlkOAgsTyLafYGimtvXqCpwFJQeU(WunlkOAgsTyLafYGimtvXqCpwFJQDe):continue
    if WunlkOAgsTyLafYGimtvXqCpwFJQDh!=WunlkOAgsTyLafYGimtvXqCpwFJQDN:
     if WunlkOAgsTyLafYGimtvXqCpwFJQDS!='':WunlkOAgsTyLafYGimtvXqCpwFJQSH[WunlkOAgsTyLafYGimtvXqCpwFJQDh]=WunlkOAgsTyLafYGimtvXqCpwFJQDS
     WunlkOAgsTyLafYGimtvXqCpwFJQDh=WunlkOAgsTyLafYGimtvXqCpwFJQDN
     WunlkOAgsTyLafYGimtvXqCpwFJQDS =''
    if WunlkOAgsTyLafYGimtvXqCpwFJQDS:WunlkOAgsTyLafYGimtvXqCpwFJQDS+='\n'
    WunlkOAgsTyLafYGimtvXqCpwFJQDS+=WunlkOAgsTyLafYGimtvXqCpwFJQSx['title']+'\n'
    WunlkOAgsTyLafYGimtvXqCpwFJQDS+=' [%s ~ %s]'%(WunlkOAgsTyLafYGimtvXqCpwFJQSx['startTime'][-5:],WunlkOAgsTyLafYGimtvXqCpwFJQSx['endTime'][-5:])+'\n'
   if WunlkOAgsTyLafYGimtvXqCpwFJQDS:WunlkOAgsTyLafYGimtvXqCpwFJQSH[WunlkOAgsTyLafYGimtvXqCpwFJQDh]=WunlkOAgsTyLafYGimtvXqCpwFJQDS
  except WunlkOAgsTyLafYGimtvXqCpwFJQeH as exception:
   WunlkOAgsTyLafYGimtvXqCpwFJQeo(exception)
  return WunlkOAgsTyLafYGimtvXqCpwFJQSH
 def GetEPGList_new(WunlkOAgsTyLafYGimtvXqCpwFJQhN):
  WunlkOAgsTyLafYGimtvXqCpwFJQSH={}
  WunlkOAgsTyLafYGimtvXqCpwFJQSo=WunlkOAgsTyLafYGimtvXqCpwFJQhN.Get_Now_Datetime()
  WunlkOAgsTyLafYGimtvXqCpwFJQSU=WunlkOAgsTyLafYGimtvXqCpwFJQSo.strftime('%Y%m%d%H%M00')
  WunlkOAgsTyLafYGimtvXqCpwFJQSj='%s%s%s'%(WunlkOAgsTyLafYGimtvXqCpwFJQSU[0:4],WunlkOAgsTyLafYGimtvXqCpwFJQSU[4:6],WunlkOAgsTyLafYGimtvXqCpwFJQSU[6:8])
  WunlkOAgsTyLafYGimtvXqCpwFJQSd=(WunlkOAgsTyLafYGimtvXqCpwFJQSo+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M00')
  try:
   for WunlkOAgsTyLafYGimtvXqCpwFJQSx in LIVETV_LIST:
    WunlkOAgsTyLafYGimtvXqCpwFJQDR =WunlkOAgsTyLafYGimtvXqCpwFJQSx['videoId']
    if WunlkOAgsTyLafYGimtvXqCpwFJQSx['epgtype']=='spotvon':
     WunlkOAgsTyLafYGimtvXqCpwFJQDS=WunlkOAgsTyLafYGimtvXqCpwFJQhN.Get_EpgInfo_Spotv_spotvon(WunlkOAgsTyLafYGimtvXqCpwFJQDR,WunlkOAgsTyLafYGimtvXqCpwFJQSx['epgnm'],WunlkOAgsTyLafYGimtvXqCpwFJQSj)
     WunlkOAgsTyLafYGimtvXqCpwFJQSH[WunlkOAgsTyLafYGimtvXqCpwFJQDR]=WunlkOAgsTyLafYGimtvXqCpwFJQDS
    if WunlkOAgsTyLafYGimtvXqCpwFJQSx['epgtype']=='spotvnet':
     WunlkOAgsTyLafYGimtvXqCpwFJQDS=WunlkOAgsTyLafYGimtvXqCpwFJQhN.Get_EpgInfo_Spotv_spotvnet(WunlkOAgsTyLafYGimtvXqCpwFJQDR,WunlkOAgsTyLafYGimtvXqCpwFJQSx['epgnm'],WunlkOAgsTyLafYGimtvXqCpwFJQSj)
     WunlkOAgsTyLafYGimtvXqCpwFJQSH[WunlkOAgsTyLafYGimtvXqCpwFJQDR]=WunlkOAgsTyLafYGimtvXqCpwFJQDS
   for WunlkOAgsTyLafYGimtvXqCpwFJQDB in WunlkOAgsTyLafYGimtvXqCpwFJQSH.keys():
    if WunlkOAgsTyLafYGimtvXqCpwFJQej(WunlkOAgsTyLafYGimtvXqCpwFJQSH.get(WunlkOAgsTyLafYGimtvXqCpwFJQDB))==0:continue
    WunlkOAgsTyLafYGimtvXqCpwFJQDS =''
    WunlkOAgsTyLafYGimtvXqCpwFJQDK=''
    for WunlkOAgsTyLafYGimtvXqCpwFJQDb in WunlkOAgsTyLafYGimtvXqCpwFJQSH.get(WunlkOAgsTyLafYGimtvXqCpwFJQDB):
     WunlkOAgsTyLafYGimtvXqCpwFJQDe =WunlkOAgsTyLafYGimtvXqCpwFJQDb['startTime']
     WunlkOAgsTyLafYGimtvXqCpwFJQDM =WunlkOAgsTyLafYGimtvXqCpwFJQDb['endTime']
     if WunlkOAgsTyLafYGimtvXqCpwFJQeU(WunlkOAgsTyLafYGimtvXqCpwFJQSU)>WunlkOAgsTyLafYGimtvXqCpwFJQeU(WunlkOAgsTyLafYGimtvXqCpwFJQDM) :continue
     if WunlkOAgsTyLafYGimtvXqCpwFJQeU(WunlkOAgsTyLafYGimtvXqCpwFJQSd)<WunlkOAgsTyLafYGimtvXqCpwFJQeU(WunlkOAgsTyLafYGimtvXqCpwFJQDe):continue
     if WunlkOAgsTyLafYGimtvXqCpwFJQeU(WunlkOAgsTyLafYGimtvXqCpwFJQSU)>=WunlkOAgsTyLafYGimtvXqCpwFJQeU(WunlkOAgsTyLafYGimtvXqCpwFJQDe)and WunlkOAgsTyLafYGimtvXqCpwFJQeU(WunlkOAgsTyLafYGimtvXqCpwFJQSU)<WunlkOAgsTyLafYGimtvXqCpwFJQeU(WunlkOAgsTyLafYGimtvXqCpwFJQDM):WunlkOAgsTyLafYGimtvXqCpwFJQDK=WunlkOAgsTyLafYGimtvXqCpwFJQhN.xmlText(WunlkOAgsTyLafYGimtvXqCpwFJQDb['title'])
     if WunlkOAgsTyLafYGimtvXqCpwFJQDS:WunlkOAgsTyLafYGimtvXqCpwFJQDS+='\n'
     WunlkOAgsTyLafYGimtvXqCpwFJQDS+=WunlkOAgsTyLafYGimtvXqCpwFJQhN.xmlText(WunlkOAgsTyLafYGimtvXqCpwFJQDb['title'])+'\n'
     WunlkOAgsTyLafYGimtvXqCpwFJQDS+=' [%s:%s ~ %s:%s]'%(WunlkOAgsTyLafYGimtvXqCpwFJQDb['startTime'][8:10],WunlkOAgsTyLafYGimtvXqCpwFJQDb['startTime'][10:12],WunlkOAgsTyLafYGimtvXqCpwFJQDb['endTime'][8:10],WunlkOAgsTyLafYGimtvXqCpwFJQDb['endTime'][10:12])+'\n'
    WunlkOAgsTyLafYGimtvXqCpwFJQSH[WunlkOAgsTyLafYGimtvXqCpwFJQDB]={'epg':WunlkOAgsTyLafYGimtvXqCpwFJQDS,'title':WunlkOAgsTyLafYGimtvXqCpwFJQDK}
  except WunlkOAgsTyLafYGimtvXqCpwFJQeH as exception:
   WunlkOAgsTyLafYGimtvXqCpwFJQeo(exception)
  return WunlkOAgsTyLafYGimtvXqCpwFJQSH
 def Get_EpgInfo_Spotv_spotvon(WunlkOAgsTyLafYGimtvXqCpwFJQhN,WunlkOAgsTyLafYGimtvXqCpwFJQDR,epgnm,now_day):
  WunlkOAgsTyLafYGimtvXqCpwFJQSH =[]
  try:
   WunlkOAgsTyLafYGimtvXqCpwFJQhd='https://www.spotvon.co.kr/data/onAir/%s/Daily/D%s.asp'%(epgnm,now_day)
   WunlkOAgsTyLafYGimtvXqCpwFJQhH=WunlkOAgsTyLafYGimtvXqCpwFJQhN.callRequestCookies('Get',WunlkOAgsTyLafYGimtvXqCpwFJQhd,payload=WunlkOAgsTyLafYGimtvXqCpwFJQec,params=WunlkOAgsTyLafYGimtvXqCpwFJQec,headers=WunlkOAgsTyLafYGimtvXqCpwFJQec,cookies=WunlkOAgsTyLafYGimtvXqCpwFJQec)
   WunlkOAgsTyLafYGimtvXqCpwFJQDz=json.loads(WunlkOAgsTyLafYGimtvXqCpwFJQhH.text)
   for WunlkOAgsTyLafYGimtvXqCpwFJQSx in WunlkOAgsTyLafYGimtvXqCpwFJQDz:
    WunlkOAgsTyLafYGimtvXqCpwFJQSr={'title':WunlkOAgsTyLafYGimtvXqCpwFJQSx['title'],'startTime':WunlkOAgsTyLafYGimtvXqCpwFJQSx['sch_date'].replace('-','')+WunlkOAgsTyLafYGimtvXqCpwFJQeV(WunlkOAgsTyLafYGimtvXqCpwFJQSx['sch_hour']).zfill(2)+WunlkOAgsTyLafYGimtvXqCpwFJQSx['sch_min']+'00'}
    WunlkOAgsTyLafYGimtvXqCpwFJQSH.append(WunlkOAgsTyLafYGimtvXqCpwFJQSr)
   for i in WunlkOAgsTyLafYGimtvXqCpwFJQed(WunlkOAgsTyLafYGimtvXqCpwFJQej(WunlkOAgsTyLafYGimtvXqCpwFJQSH)):
    if i>0:WunlkOAgsTyLafYGimtvXqCpwFJQSH[i-1]['endTime']=WunlkOAgsTyLafYGimtvXqCpwFJQSH[i]['startTime']
    if i==WunlkOAgsTyLafYGimtvXqCpwFJQej(WunlkOAgsTyLafYGimtvXqCpwFJQSH)-1: WunlkOAgsTyLafYGimtvXqCpwFJQSH[i]['endTime']=now_day+'240000'
  except WunlkOAgsTyLafYGimtvXqCpwFJQeH as exception:
   WunlkOAgsTyLafYGimtvXqCpwFJQeo(exception)
   return[]
  return WunlkOAgsTyLafYGimtvXqCpwFJQSH
 def Get_EpgInfo_Spotv_spotvnet(WunlkOAgsTyLafYGimtvXqCpwFJQhN,WunlkOAgsTyLafYGimtvXqCpwFJQDR,epgnm,now_day):
  WunlkOAgsTyLafYGimtvXqCpwFJQSH =[]
  try:
   WunlkOAgsTyLafYGimtvXqCpwFJQhd='https://www.spotv.net/data/json/schedule/%s/Daily/D%s.json'%(epgnm,now_day)
   WunlkOAgsTyLafYGimtvXqCpwFJQhH=WunlkOAgsTyLafYGimtvXqCpwFJQhN.callRequestCookies('Get',WunlkOAgsTyLafYGimtvXqCpwFJQhd,payload=WunlkOAgsTyLafYGimtvXqCpwFJQec,params=WunlkOAgsTyLafYGimtvXqCpwFJQec,headers=WunlkOAgsTyLafYGimtvXqCpwFJQec,cookies=WunlkOAgsTyLafYGimtvXqCpwFJQec)
   WunlkOAgsTyLafYGimtvXqCpwFJQDz=json.loads(WunlkOAgsTyLafYGimtvXqCpwFJQhH.text)
   for WunlkOAgsTyLafYGimtvXqCpwFJQSx in WunlkOAgsTyLafYGimtvXqCpwFJQDz:
    WunlkOAgsTyLafYGimtvXqCpwFJQSr={'title':WunlkOAgsTyLafYGimtvXqCpwFJQSx['title'],'startTime':WunlkOAgsTyLafYGimtvXqCpwFJQSx['sch_date'].replace('-','')+WunlkOAgsTyLafYGimtvXqCpwFJQeV(WunlkOAgsTyLafYGimtvXqCpwFJQSx['sch_hour']).zfill(2)+WunlkOAgsTyLafYGimtvXqCpwFJQSx['sch_min']+'00'}
    WunlkOAgsTyLafYGimtvXqCpwFJQSH.append(WunlkOAgsTyLafYGimtvXqCpwFJQSr)
   for i in WunlkOAgsTyLafYGimtvXqCpwFJQed(WunlkOAgsTyLafYGimtvXqCpwFJQej(WunlkOAgsTyLafYGimtvXqCpwFJQSH)):
    if i>0:WunlkOAgsTyLafYGimtvXqCpwFJQSH[i-1]['endTime']=WunlkOAgsTyLafYGimtvXqCpwFJQSH[i]['startTime']
    if i==WunlkOAgsTyLafYGimtvXqCpwFJQej(WunlkOAgsTyLafYGimtvXqCpwFJQSH)-1: WunlkOAgsTyLafYGimtvXqCpwFJQSH[i]['endTime']=now_day+'240000'
  except WunlkOAgsTyLafYGimtvXqCpwFJQeH as exception:
   WunlkOAgsTyLafYGimtvXqCpwFJQeo(exception)
   return[]
  return WunlkOAgsTyLafYGimtvXqCpwFJQSH
 def GetEventLiveList(WunlkOAgsTyLafYGimtvXqCpwFJQhN):
  WunlkOAgsTyLafYGimtvXqCpwFJQSc=[]
  WunlkOAgsTyLafYGimtvXqCpwFJQDE =0
  try:
   WunlkOAgsTyLafYGimtvXqCpwFJQDP=WunlkOAgsTyLafYGimtvXqCpwFJQhN.Get_Now_Datetime()
   WunlkOAgsTyLafYGimtvXqCpwFJQDc=WunlkOAgsTyLafYGimtvXqCpwFJQDP.strftime('%Y-%m-%d')
  except WunlkOAgsTyLafYGimtvXqCpwFJQeH as exception:
   WunlkOAgsTyLafYGimtvXqCpwFJQeo(exception)
   return WunlkOAgsTyLafYGimtvXqCpwFJQSc,WunlkOAgsTyLafYGimtvXqCpwFJQDE
  try:
   WunlkOAgsTyLafYGimtvXqCpwFJQhd=WunlkOAgsTyLafYGimtvXqCpwFJQhN.API_DOMAIN+'/api/v2/player/lives/'+WunlkOAgsTyLafYGimtvXqCpwFJQDc 
   WunlkOAgsTyLafYGimtvXqCpwFJQhE=WunlkOAgsTyLafYGimtvXqCpwFJQhN.makeDefaultCookies()
   WunlkOAgsTyLafYGimtvXqCpwFJQhH=WunlkOAgsTyLafYGimtvXqCpwFJQhN.callRequestCookies('Get',WunlkOAgsTyLafYGimtvXqCpwFJQhd,payload=WunlkOAgsTyLafYGimtvXqCpwFJQec,params=WunlkOAgsTyLafYGimtvXqCpwFJQec,headers=WunlkOAgsTyLafYGimtvXqCpwFJQec,cookies=WunlkOAgsTyLafYGimtvXqCpwFJQhE)
   WunlkOAgsTyLafYGimtvXqCpwFJQDE=WunlkOAgsTyLafYGimtvXqCpwFJQhH.status_code 
   WunlkOAgsTyLafYGimtvXqCpwFJQho=json.loads(WunlkOAgsTyLafYGimtvXqCpwFJQhH.text)
   for WunlkOAgsTyLafYGimtvXqCpwFJQDI in WunlkOAgsTyLafYGimtvXqCpwFJQho:
    for WunlkOAgsTyLafYGimtvXqCpwFJQSx in WunlkOAgsTyLafYGimtvXqCpwFJQDI['liveNowList']:
     if WunlkOAgsTyLafYGimtvXqCpwFJQSx['gameDesc']['title']==WunlkOAgsTyLafYGimtvXqCpwFJQec or WunlkOAgsTyLafYGimtvXqCpwFJQSx['gameDesc']['title']=='':
      WunlkOAgsTyLafYGimtvXqCpwFJQDx='%s ( %s : %s )'%(WunlkOAgsTyLafYGimtvXqCpwFJQSx['leagueName'],WunlkOAgsTyLafYGimtvXqCpwFJQSx['homeNameShort'],WunlkOAgsTyLafYGimtvXqCpwFJQSx['awayNameShort'])
     else:
      WunlkOAgsTyLafYGimtvXqCpwFJQDx=WunlkOAgsTyLafYGimtvXqCpwFJQSx['gameDesc']['title']
     WunlkOAgsTyLafYGimtvXqCpwFJQSr={'liveId':WunlkOAgsTyLafYGimtvXqCpwFJQSx['liveId'],'title':WunlkOAgsTyLafYGimtvXqCpwFJQDx,'logo':WunlkOAgsTyLafYGimtvXqCpwFJQSx['gameDesc']['leagueLogo'],'free':WunlkOAgsTyLafYGimtvXqCpwFJQSx['isFree'],'startTime':WunlkOAgsTyLafYGimtvXqCpwFJQSx['startTime']}
     WunlkOAgsTyLafYGimtvXqCpwFJQSc.append(WunlkOAgsTyLafYGimtvXqCpwFJQSr)
  except WunlkOAgsTyLafYGimtvXqCpwFJQeH as exception:
   WunlkOAgsTyLafYGimtvXqCpwFJQeo(exception)
  return WunlkOAgsTyLafYGimtvXqCpwFJQSc,WunlkOAgsTyLafYGimtvXqCpwFJQDE
 def GetEventLive_videoId(WunlkOAgsTyLafYGimtvXqCpwFJQhN,liveId):
  WunlkOAgsTyLafYGimtvXqCpwFJQDr=''
  try:
   WunlkOAgsTyLafYGimtvXqCpwFJQhd=WunlkOAgsTyLafYGimtvXqCpwFJQhN.API_DOMAIN+'/api/v2/live/'+liveId
   WunlkOAgsTyLafYGimtvXqCpwFJQhH=WunlkOAgsTyLafYGimtvXqCpwFJQhN.callRequestCookies('Get',WunlkOAgsTyLafYGimtvXqCpwFJQhd,payload=WunlkOAgsTyLafYGimtvXqCpwFJQec,params=WunlkOAgsTyLafYGimtvXqCpwFJQec,headers=WunlkOAgsTyLafYGimtvXqCpwFJQec,cookies=WunlkOAgsTyLafYGimtvXqCpwFJQec)
   WunlkOAgsTyLafYGimtvXqCpwFJQho=json.loads(WunlkOAgsTyLafYGimtvXqCpwFJQhH.text)
   WunlkOAgsTyLafYGimtvXqCpwFJQDV=WunlkOAgsTyLafYGimtvXqCpwFJQho['videoId']
   WunlkOAgsTyLafYGimtvXqCpwFJQDr=WunlkOAgsTyLafYGimtvXqCpwFJQDV.replace('ref:','')
  except WunlkOAgsTyLafYGimtvXqCpwFJQeH as exception:
   WunlkOAgsTyLafYGimtvXqCpwFJQeo(exception)
  return WunlkOAgsTyLafYGimtvXqCpwFJQDr
 def CheckMainEnd(WunlkOAgsTyLafYGimtvXqCpwFJQhN):
  WunlkOAgsTyLafYGimtvXqCpwFJQDH=WunlkOAgsTyLafYGimtvXqCpwFJQhN.SPOTV_PMCODE+WunlkOAgsTyLafYGimtvXqCpwFJQhN.ST['cookies']['spotv_sessionid']
  WunlkOAgsTyLafYGimtvXqCpwFJQDH=base64.standard_b64encode(WunlkOAgsTyLafYGimtvXqCpwFJQDH.encode()).decode('utf-8')
  if WunlkOAgsTyLafYGimtvXqCpwFJQDH=='OTg3MTgzMzM0Ng==' or WunlkOAgsTyLafYGimtvXqCpwFJQDH=='OTg3MTgzMzExNw==':return WunlkOAgsTyLafYGimtvXqCpwFJQer
  return WunlkOAgsTyLafYGimtvXqCpwFJQeI
 def CheckSubEnd(WunlkOAgsTyLafYGimtvXqCpwFJQhN):
  WunlkOAgsTyLafYGimtvXqCpwFJQhK=WunlkOAgsTyLafYGimtvXqCpwFJQeI
  try:
   if WunlkOAgsTyLafYGimtvXqCpwFJQhN.CheckMainEnd():return WunlkOAgsTyLafYGimtvXqCpwFJQer 
   WunlkOAgsTyLafYGimtvXqCpwFJQDo=base64.standard_b64decode(WunlkOAgsTyLafYGimtvXqCpwFJQhN.ST['cookies']['spotv_subend']).decode('utf-8')[WunlkOAgsTyLafYGimtvXqCpwFJQhN.SPOTV_PMSIZE:]
   if WunlkOAgsTyLafYGimtvXqCpwFJQDo=='0':return WunlkOAgsTyLafYGimtvXqCpwFJQhK
   WunlkOAgsTyLafYGimtvXqCpwFJQDU =WunlkOAgsTyLafYGimtvXqCpwFJQeU(WunlkOAgsTyLafYGimtvXqCpwFJQhN.Get_Now_Datetime().strftime('%Y%m%d'))
   WunlkOAgsTyLafYGimtvXqCpwFJQDj =WunlkOAgsTyLafYGimtvXqCpwFJQeU(WunlkOAgsTyLafYGimtvXqCpwFJQDo)/1000
   WunlkOAgsTyLafYGimtvXqCpwFJQDd =WunlkOAgsTyLafYGimtvXqCpwFJQeU(datetime.datetime.fromtimestamp(WunlkOAgsTyLafYGimtvXqCpwFJQDj,datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul')).strftime('%Y%m%d'))
   if WunlkOAgsTyLafYGimtvXqCpwFJQDU<=WunlkOAgsTyLafYGimtvXqCpwFJQDd:WunlkOAgsTyLafYGimtvXqCpwFJQhK=WunlkOAgsTyLafYGimtvXqCpwFJQer
  except WunlkOAgsTyLafYGimtvXqCpwFJQeH as exception:
   WunlkOAgsTyLafYGimtvXqCpwFJQeo(exception)
   return WunlkOAgsTyLafYGimtvXqCpwFJQhK
  return WunlkOAgsTyLafYGimtvXqCpwFJQhK
 def GetBroadURL(WunlkOAgsTyLafYGimtvXqCpwFJQhN,WunlkOAgsTyLafYGimtvXqCpwFJQDr,mediatype,WunlkOAgsTyLafYGimtvXqCpwFJQNz):
  WunlkOAgsTyLafYGimtvXqCpwFJQNh=''
  try:
   if mediatype=='live':
    WunlkOAgsTyLafYGimtvXqCpwFJQhd=WunlkOAgsTyLafYGimtvXqCpwFJQhN.API_DOMAIN+'/api/v2/live/'+WunlkOAgsTyLafYGimtvXqCpwFJQDr
   else:
    WunlkOAgsTyLafYGimtvXqCpwFJQDr=WunlkOAgsTyLafYGimtvXqCpwFJQhN.GetReplay_UrlId(WunlkOAgsTyLafYGimtvXqCpwFJQDr,WunlkOAgsTyLafYGimtvXqCpwFJQNz)
    if WunlkOAgsTyLafYGimtvXqCpwFJQDr=='':return WunlkOAgsTyLafYGimtvXqCpwFJQNh
    WunlkOAgsTyLafYGimtvXqCpwFJQhd=WunlkOAgsTyLafYGimtvXqCpwFJQhN.PLAYER_DOMAIN+'/playback/v1/accounts/'+WunlkOAgsTyLafYGimtvXqCpwFJQhN.ST['cookies']['spotv_accountId']+'/videos/'+WunlkOAgsTyLafYGimtvXqCpwFJQDr
   WunlkOAgsTyLafYGimtvXqCpwFJQhP=WunlkOAgsTyLafYGimtvXqCpwFJQhN.makeDefaultHeaders()
   WunlkOAgsTyLafYGimtvXqCpwFJQhH=WunlkOAgsTyLafYGimtvXqCpwFJQhN.callRequestCookies('Get',WunlkOAgsTyLafYGimtvXqCpwFJQhd,payload=WunlkOAgsTyLafYGimtvXqCpwFJQec,params=WunlkOAgsTyLafYGimtvXqCpwFJQec,headers=WunlkOAgsTyLafYGimtvXqCpwFJQhP,cookies=WunlkOAgsTyLafYGimtvXqCpwFJQec)
   WunlkOAgsTyLafYGimtvXqCpwFJQDz=json.loads(WunlkOAgsTyLafYGimtvXqCpwFJQhH.text)
   if mediatype=='live':
    WunlkOAgsTyLafYGimtvXqCpwFJQNh=WunlkOAgsTyLafYGimtvXqCpwFJQDz['hlsUrl2']or WunlkOAgsTyLafYGimtvXqCpwFJQDz['hlsUrl']
   else:
    WunlkOAgsTyLafYGimtvXqCpwFJQNh=WunlkOAgsTyLafYGimtvXqCpwFJQDz['sources'][0]['src']
   WunlkOAgsTyLafYGimtvXqCpwFJQNh=WunlkOAgsTyLafYGimtvXqCpwFJQNh.replace('http://','https://')
  except WunlkOAgsTyLafYGimtvXqCpwFJQeH as exception:
   WunlkOAgsTyLafYGimtvXqCpwFJQeo(exception)
  return WunlkOAgsTyLafYGimtvXqCpwFJQNh
 def GetTitleGroupList(WunlkOAgsTyLafYGimtvXqCpwFJQhN):
  WunlkOAgsTyLafYGimtvXqCpwFJQSc=[]
  WunlkOAgsTyLafYGimtvXqCpwFJQNS=WunlkOAgsTyLafYGimtvXqCpwFJQeI
  try:
   WunlkOAgsTyLafYGimtvXqCpwFJQhd=WunlkOAgsTyLafYGimtvXqCpwFJQhN.API_DOMAIN+'/api/v2/home/web'
   WunlkOAgsTyLafYGimtvXqCpwFJQhH=WunlkOAgsTyLafYGimtvXqCpwFJQhN.callRequestCookies('Get',WunlkOAgsTyLafYGimtvXqCpwFJQhd,payload=WunlkOAgsTyLafYGimtvXqCpwFJQec,params=WunlkOAgsTyLafYGimtvXqCpwFJQec,headers=WunlkOAgsTyLafYGimtvXqCpwFJQec,cookies=WunlkOAgsTyLafYGimtvXqCpwFJQec)
   WunlkOAgsTyLafYGimtvXqCpwFJQho=json.loads(WunlkOAgsTyLafYGimtvXqCpwFJQhH.text)
   for WunlkOAgsTyLafYGimtvXqCpwFJQSx in WunlkOAgsTyLafYGimtvXqCpwFJQho:
    if WunlkOAgsTyLafYGimtvXqCpwFJQeV(WunlkOAgsTyLafYGimtvXqCpwFJQSx['type'])=='3':
     WunlkOAgsTyLafYGimtvXqCpwFJQND=''
     for WunlkOAgsTyLafYGimtvXqCpwFJQNe in WunlkOAgsTyLafYGimtvXqCpwFJQSx['data']['list']:
      WunlkOAgsTyLafYGimtvXqCpwFJQNM='[%s] %s vs %s\n<%s>\n\n'%(WunlkOAgsTyLafYGimtvXqCpwFJQNe['gameDesc']['roundName'],WunlkOAgsTyLafYGimtvXqCpwFJQNe['gameDesc']['homeNameShort'],WunlkOAgsTyLafYGimtvXqCpwFJQNe['gameDesc']['awayNameShort'],WunlkOAgsTyLafYGimtvXqCpwFJQNe['gameDesc']['beginDate'])
      WunlkOAgsTyLafYGimtvXqCpwFJQND+=WunlkOAgsTyLafYGimtvXqCpwFJQNM
     WunlkOAgsTyLafYGimtvXqCpwFJQSr={'title':WunlkOAgsTyLafYGimtvXqCpwFJQSx['title'],'logo':WunlkOAgsTyLafYGimtvXqCpwFJQSx['logo'],'reagueId':WunlkOAgsTyLafYGimtvXqCpwFJQeV(WunlkOAgsTyLafYGimtvXqCpwFJQSx['destId']),'subGame':WunlkOAgsTyLafYGimtvXqCpwFJQND}
     WunlkOAgsTyLafYGimtvXqCpwFJQSc.append(WunlkOAgsTyLafYGimtvXqCpwFJQSr)
     if WunlkOAgsTyLafYGimtvXqCpwFJQeV(WunlkOAgsTyLafYGimtvXqCpwFJQSx['destId'])=='13':WunlkOAgsTyLafYGimtvXqCpwFJQNS=WunlkOAgsTyLafYGimtvXqCpwFJQer
   if WunlkOAgsTyLafYGimtvXqCpwFJQNS==WunlkOAgsTyLafYGimtvXqCpwFJQeI:
    WunlkOAgsTyLafYGimtvXqCpwFJQSr={'title':'UFC','logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200928/a643c7cf1c285fb0b4469c07d4c09c28.png','reagueId':'13','subGame':''}
    WunlkOAgsTyLafYGimtvXqCpwFJQSc.append(WunlkOAgsTyLafYGimtvXqCpwFJQSr)
  except WunlkOAgsTyLafYGimtvXqCpwFJQeH as exception:
   WunlkOAgsTyLafYGimtvXqCpwFJQeo(exception)
  return WunlkOAgsTyLafYGimtvXqCpwFJQSc
 def GetPopularGroupList(WunlkOAgsTyLafYGimtvXqCpwFJQhN):
  WunlkOAgsTyLafYGimtvXqCpwFJQSc=[]
  try:
   WunlkOAgsTyLafYGimtvXqCpwFJQhd=WunlkOAgsTyLafYGimtvXqCpwFJQhN.API_DOMAIN+'/api/v2/home/web'
   WunlkOAgsTyLafYGimtvXqCpwFJQhH=WunlkOAgsTyLafYGimtvXqCpwFJQhN.callRequestCookies('Get',WunlkOAgsTyLafYGimtvXqCpwFJQhd,payload=WunlkOAgsTyLafYGimtvXqCpwFJQec,params=WunlkOAgsTyLafYGimtvXqCpwFJQec,headers=WunlkOAgsTyLafYGimtvXqCpwFJQec,cookies=WunlkOAgsTyLafYGimtvXqCpwFJQec)
   WunlkOAgsTyLafYGimtvXqCpwFJQho=json.loads(WunlkOAgsTyLafYGimtvXqCpwFJQhH.text)
   for WunlkOAgsTyLafYGimtvXqCpwFJQSx in WunlkOAgsTyLafYGimtvXqCpwFJQho:
    if WunlkOAgsTyLafYGimtvXqCpwFJQeV(WunlkOAgsTyLafYGimtvXqCpwFJQSx['type'])=='1' and WunlkOAgsTyLafYGimtvXqCpwFJQeV(WunlkOAgsTyLafYGimtvXqCpwFJQSx['destId'])=='4':
     for WunlkOAgsTyLafYGimtvXqCpwFJQNe in WunlkOAgsTyLafYGimtvXqCpwFJQSx['data']['list']:
      WunlkOAgsTyLafYGimtvXqCpwFJQNR =WunlkOAgsTyLafYGimtvXqCpwFJQNe['title']
      WunlkOAgsTyLafYGimtvXqCpwFJQNB =WunlkOAgsTyLafYGimtvXqCpwFJQNe['id']
      WunlkOAgsTyLafYGimtvXqCpwFJQNK =WunlkOAgsTyLafYGimtvXqCpwFJQNe['vtype']
      WunlkOAgsTyLafYGimtvXqCpwFJQNb =WunlkOAgsTyLafYGimtvXqCpwFJQNe['imgUrl']
      WunlkOAgsTyLafYGimtvXqCpwFJQNz =WunlkOAgsTyLafYGimtvXqCpwFJQNe['vtypeId']
      WunlkOAgsTyLafYGimtvXqCpwFJQSr={'vodTitle':WunlkOAgsTyLafYGimtvXqCpwFJQNR,'vodId':WunlkOAgsTyLafYGimtvXqCpwFJQNB,'vodType':WunlkOAgsTyLafYGimtvXqCpwFJQNK,'thumbnail':WunlkOAgsTyLafYGimtvXqCpwFJQNb,'vtypeId':WunlkOAgsTyLafYGimtvXqCpwFJQeV(WunlkOAgsTyLafYGimtvXqCpwFJQNz),'duration':WunlkOAgsTyLafYGimtvXqCpwFJQeU(WunlkOAgsTyLafYGimtvXqCpwFJQNe['duration']/1000)}
      WunlkOAgsTyLafYGimtvXqCpwFJQSc.append(WunlkOAgsTyLafYGimtvXqCpwFJQSr)
  except WunlkOAgsTyLafYGimtvXqCpwFJQeH as exception:
   WunlkOAgsTyLafYGimtvXqCpwFJQeo(exception)
  return WunlkOAgsTyLafYGimtvXqCpwFJQSc
 def Get_NowVod_GroupList(WunlkOAgsTyLafYGimtvXqCpwFJQhN,page_int):
  WunlkOAgsTyLafYGimtvXqCpwFJQSc=[]
  WunlkOAgsTyLafYGimtvXqCpwFJQNE=WunlkOAgsTyLafYGimtvXqCpwFJQeI
  try:
   WunlkOAgsTyLafYGimtvXqCpwFJQhd=WunlkOAgsTyLafYGimtvXqCpwFJQhN.API_DOMAIN+'/api/v2/theme/14/list'
   WunlkOAgsTyLafYGimtvXqCpwFJQNP={'pageItem':'10','pageNo':WunlkOAgsTyLafYGimtvXqCpwFJQeV(page_int)}
   WunlkOAgsTyLafYGimtvXqCpwFJQhH=WunlkOAgsTyLafYGimtvXqCpwFJQhN.callRequestCookies('Get',WunlkOAgsTyLafYGimtvXqCpwFJQhd,payload=WunlkOAgsTyLafYGimtvXqCpwFJQec,params=WunlkOAgsTyLafYGimtvXqCpwFJQNP,headers=WunlkOAgsTyLafYGimtvXqCpwFJQec,cookies=WunlkOAgsTyLafYGimtvXqCpwFJQec)
   WunlkOAgsTyLafYGimtvXqCpwFJQho=json.loads(WunlkOAgsTyLafYGimtvXqCpwFJQhH.text)
   for WunlkOAgsTyLafYGimtvXqCpwFJQSx in WunlkOAgsTyLafYGimtvXqCpwFJQho['list']:
    WunlkOAgsTyLafYGimtvXqCpwFJQNR =WunlkOAgsTyLafYGimtvXqCpwFJQSx['title']
    WunlkOAgsTyLafYGimtvXqCpwFJQNB =WunlkOAgsTyLafYGimtvXqCpwFJQSx['id']
    WunlkOAgsTyLafYGimtvXqCpwFJQNK =WunlkOAgsTyLafYGimtvXqCpwFJQSx['vtype']
    WunlkOAgsTyLafYGimtvXqCpwFJQNb =WunlkOAgsTyLafYGimtvXqCpwFJQSx['imgUrl']
    WunlkOAgsTyLafYGimtvXqCpwFJQNz =WunlkOAgsTyLafYGimtvXqCpwFJQSx['vtypeId']
    WunlkOAgsTyLafYGimtvXqCpwFJQSr={'vodTitle':WunlkOAgsTyLafYGimtvXqCpwFJQNR,'vodId':WunlkOAgsTyLafYGimtvXqCpwFJQNB,'vodType':WunlkOAgsTyLafYGimtvXqCpwFJQNK,'thumbnail':WunlkOAgsTyLafYGimtvXqCpwFJQNb,'vtypeId':WunlkOAgsTyLafYGimtvXqCpwFJQeV(WunlkOAgsTyLafYGimtvXqCpwFJQNz),'duration':WunlkOAgsTyLafYGimtvXqCpwFJQeU(WunlkOAgsTyLafYGimtvXqCpwFJQSx['duration']/1000),}
    WunlkOAgsTyLafYGimtvXqCpwFJQSc.append(WunlkOAgsTyLafYGimtvXqCpwFJQSr)
    if WunlkOAgsTyLafYGimtvXqCpwFJQho['count']>page_int*WunlkOAgsTyLafYGimtvXqCpwFJQhN.GAMELIST_LIMIT:WunlkOAgsTyLafYGimtvXqCpwFJQNE=WunlkOAgsTyLafYGimtvXqCpwFJQer
  except WunlkOAgsTyLafYGimtvXqCpwFJQeH as exception:
   WunlkOAgsTyLafYGimtvXqCpwFJQeo(exception)
  return WunlkOAgsTyLafYGimtvXqCpwFJQSc,WunlkOAgsTyLafYGimtvXqCpwFJQNE
 def GetSeasonList(WunlkOAgsTyLafYGimtvXqCpwFJQhN,leagueId):
  WunlkOAgsTyLafYGimtvXqCpwFJQSc=[]
  WunlkOAgsTyLafYGimtvXqCpwFJQNc=WunlkOAgsTyLafYGimtvXqCpwFJQNI=''
  try:
   WunlkOAgsTyLafYGimtvXqCpwFJQhd=WunlkOAgsTyLafYGimtvXqCpwFJQhN.API_DOMAIN+'/api/v2/game/league/'+leagueId
   WunlkOAgsTyLafYGimtvXqCpwFJQhH=WunlkOAgsTyLafYGimtvXqCpwFJQhN.callRequestCookies('Get',WunlkOAgsTyLafYGimtvXqCpwFJQhd,payload=WunlkOAgsTyLafYGimtvXqCpwFJQec,params=WunlkOAgsTyLafYGimtvXqCpwFJQec,headers=WunlkOAgsTyLafYGimtvXqCpwFJQec,cookies=WunlkOAgsTyLafYGimtvXqCpwFJQec)
   WunlkOAgsTyLafYGimtvXqCpwFJQho=json.loads(WunlkOAgsTyLafYGimtvXqCpwFJQhH.text)
   WunlkOAgsTyLafYGimtvXqCpwFJQNc=WunlkOAgsTyLafYGimtvXqCpwFJQho['name']
   WunlkOAgsTyLafYGimtvXqCpwFJQNI=WunlkOAgsTyLafYGimtvXqCpwFJQeV(WunlkOAgsTyLafYGimtvXqCpwFJQho['gameTypeId'])
  except WunlkOAgsTyLafYGimtvXqCpwFJQeH as exception:
   WunlkOAgsTyLafYGimtvXqCpwFJQeo(exception)
   return WunlkOAgsTyLafYGimtvXqCpwFJQSc
  if WunlkOAgsTyLafYGimtvXqCpwFJQNI=='2':
   try:
    WunlkOAgsTyLafYGimtvXqCpwFJQhd=WunlkOAgsTyLafYGimtvXqCpwFJQhN.API_DOMAIN+'/api/v2/year/'+leagueId
    WunlkOAgsTyLafYGimtvXqCpwFJQhH=WunlkOAgsTyLafYGimtvXqCpwFJQhN.callRequestCookies('Get',WunlkOAgsTyLafYGimtvXqCpwFJQhd,payload=WunlkOAgsTyLafYGimtvXqCpwFJQec,params=WunlkOAgsTyLafYGimtvXqCpwFJQec,headers=WunlkOAgsTyLafYGimtvXqCpwFJQec,cookies=WunlkOAgsTyLafYGimtvXqCpwFJQec)
    WunlkOAgsTyLafYGimtvXqCpwFJQho=json.loads(WunlkOAgsTyLafYGimtvXqCpwFJQhH.text)
    for WunlkOAgsTyLafYGimtvXqCpwFJQSx in WunlkOAgsTyLafYGimtvXqCpwFJQho:
     WunlkOAgsTyLafYGimtvXqCpwFJQSr={'reagueName':WunlkOAgsTyLafYGimtvXqCpwFJQNc,'gameTypeId':WunlkOAgsTyLafYGimtvXqCpwFJQNI,'seasonName':WunlkOAgsTyLafYGimtvXqCpwFJQeV(WunlkOAgsTyLafYGimtvXqCpwFJQSx),'seasonId':WunlkOAgsTyLafYGimtvXqCpwFJQeV(WunlkOAgsTyLafYGimtvXqCpwFJQSx)}
     WunlkOAgsTyLafYGimtvXqCpwFJQSc.append(WunlkOAgsTyLafYGimtvXqCpwFJQSr)
   except WunlkOAgsTyLafYGimtvXqCpwFJQeH as exception:
    WunlkOAgsTyLafYGimtvXqCpwFJQeo(exception)
    return[]
  else:
   try:
    WunlkOAgsTyLafYGimtvXqCpwFJQhd=WunlkOAgsTyLafYGimtvXqCpwFJQhN.API_DOMAIN+'/api/v2/season/'+leagueId
    WunlkOAgsTyLafYGimtvXqCpwFJQhH=WunlkOAgsTyLafYGimtvXqCpwFJQhN.callRequestCookies('Get',WunlkOAgsTyLafYGimtvXqCpwFJQhd,payload=WunlkOAgsTyLafYGimtvXqCpwFJQec,params=WunlkOAgsTyLafYGimtvXqCpwFJQec,headers=WunlkOAgsTyLafYGimtvXqCpwFJQec,cookies=WunlkOAgsTyLafYGimtvXqCpwFJQec)
    WunlkOAgsTyLafYGimtvXqCpwFJQho=json.loads(WunlkOAgsTyLafYGimtvXqCpwFJQhH.text)
    for WunlkOAgsTyLafYGimtvXqCpwFJQSx in WunlkOAgsTyLafYGimtvXqCpwFJQho:
     WunlkOAgsTyLafYGimtvXqCpwFJQSr={'reagueName':WunlkOAgsTyLafYGimtvXqCpwFJQNc,'gameTypeId':WunlkOAgsTyLafYGimtvXqCpwFJQNI,'seasonName':WunlkOAgsTyLafYGimtvXqCpwFJQSx['name'],'seasonId':WunlkOAgsTyLafYGimtvXqCpwFJQeV(WunlkOAgsTyLafYGimtvXqCpwFJQSx['id'])}
     WunlkOAgsTyLafYGimtvXqCpwFJQSc.append(WunlkOAgsTyLafYGimtvXqCpwFJQSr)
   except WunlkOAgsTyLafYGimtvXqCpwFJQeH as exception:
    WunlkOAgsTyLafYGimtvXqCpwFJQeo(exception)
    return[]
  return WunlkOAgsTyLafYGimtvXqCpwFJQSc
 def GetGameList(WunlkOAgsTyLafYGimtvXqCpwFJQhN,WunlkOAgsTyLafYGimtvXqCpwFJQNI,leagueId,seasonId,page_int,hidescore=WunlkOAgsTyLafYGimtvXqCpwFJQer):
  WunlkOAgsTyLafYGimtvXqCpwFJQSc=[]
  WunlkOAgsTyLafYGimtvXqCpwFJQNE=WunlkOAgsTyLafYGimtvXqCpwFJQeI
  try:
   WunlkOAgsTyLafYGimtvXqCpwFJQhd=WunlkOAgsTyLafYGimtvXqCpwFJQhN.API_DOMAIN+'/api/v2/vod/league/detail'
   WunlkOAgsTyLafYGimtvXqCpwFJQNP={'gameType':WunlkOAgsTyLafYGimtvXqCpwFJQNI,'leagueId':leagueId,'seasonId':seasonId if WunlkOAgsTyLafYGimtvXqCpwFJQNI!='2' else '','teamId':'','roundId':'','year':'' if WunlkOAgsTyLafYGimtvXqCpwFJQNI!='2' else seasonId,'pageNo':WunlkOAgsTyLafYGimtvXqCpwFJQeV(page_int)}
   WunlkOAgsTyLafYGimtvXqCpwFJQhH=WunlkOAgsTyLafYGimtvXqCpwFJQhN.callRequestCookies('Get',WunlkOAgsTyLafYGimtvXqCpwFJQhd,payload=WunlkOAgsTyLafYGimtvXqCpwFJQec,params=WunlkOAgsTyLafYGimtvXqCpwFJQNP,headers=WunlkOAgsTyLafYGimtvXqCpwFJQec,cookies=WunlkOAgsTyLafYGimtvXqCpwFJQec)
   WunlkOAgsTyLafYGimtvXqCpwFJQho=json.loads(WunlkOAgsTyLafYGimtvXqCpwFJQhH.text)
   WunlkOAgsTyLafYGimtvXqCpwFJQDI=WunlkOAgsTyLafYGimtvXqCpwFJQho['list']
   for WunlkOAgsTyLafYGimtvXqCpwFJQNx in WunlkOAgsTyLafYGimtvXqCpwFJQDI:
    for WunlkOAgsTyLafYGimtvXqCpwFJQSx in WunlkOAgsTyLafYGimtvXqCpwFJQNx['list']:
     if WunlkOAgsTyLafYGimtvXqCpwFJQSx['gameDesc']['title']==WunlkOAgsTyLafYGimtvXqCpwFJQec or WunlkOAgsTyLafYGimtvXqCpwFJQSx['gameDesc']['title']=='':
      WunlkOAgsTyLafYGimtvXqCpwFJQDx ='%s vs %s'%(WunlkOAgsTyLafYGimtvXqCpwFJQSx['gameDesc']['homeNameShort'],WunlkOAgsTyLafYGimtvXqCpwFJQSx['gameDesc']['awayNameShort'])
     else:
      WunlkOAgsTyLafYGimtvXqCpwFJQDx =WunlkOAgsTyLafYGimtvXqCpwFJQSx['gameDesc']['title']
     WunlkOAgsTyLafYGimtvXqCpwFJQNr =WunlkOAgsTyLafYGimtvXqCpwFJQSx['gameDesc']['beginDate']
     WunlkOAgsTyLafYGimtvXqCpwFJQNV =WunlkOAgsTyLafYGimtvXqCpwFJQSx['gameDesc']['id']
     WunlkOAgsTyLafYGimtvXqCpwFJQNH =WunlkOAgsTyLafYGimtvXqCpwFJQSx['gameDesc']['leagueNameFull']
     WunlkOAgsTyLafYGimtvXqCpwFJQNo =WunlkOAgsTyLafYGimtvXqCpwFJQSx['gameDesc']['seasonName']
     WunlkOAgsTyLafYGimtvXqCpwFJQNU =WunlkOAgsTyLafYGimtvXqCpwFJQSx['gameDesc']['roundName']
     WunlkOAgsTyLafYGimtvXqCpwFJQNj =WunlkOAgsTyLafYGimtvXqCpwFJQSx['gameDesc']['homeName']
     WunlkOAgsTyLafYGimtvXqCpwFJQNd =WunlkOAgsTyLafYGimtvXqCpwFJQSx['gameDesc']['awayName']
     WunlkOAgsTyLafYGimtvXqCpwFJQeh =WunlkOAgsTyLafYGimtvXqCpwFJQSx['gameDesc']['homeScore']
     WunlkOAgsTyLafYGimtvXqCpwFJQeS =WunlkOAgsTyLafYGimtvXqCpwFJQSx['gameDesc']['awayScore']
     if hidescore==WunlkOAgsTyLafYGimtvXqCpwFJQer:
      WunlkOAgsTyLafYGimtvXqCpwFJQeD ='%s\n - %s (%s)\n - %s\n\nhome : %s\n\naway : %s'%(WunlkOAgsTyLafYGimtvXqCpwFJQNH,WunlkOAgsTyLafYGimtvXqCpwFJQNo,WunlkOAgsTyLafYGimtvXqCpwFJQNU,WunlkOAgsTyLafYGimtvXqCpwFJQNr,WunlkOAgsTyLafYGimtvXqCpwFJQNj,WunlkOAgsTyLafYGimtvXqCpwFJQNd)
     else:
      WunlkOAgsTyLafYGimtvXqCpwFJQeD ='%s\n - %s (%s)\n - %s\n\nhome : %s (Score %s)\n\naway : %s (Score %s)'%(WunlkOAgsTyLafYGimtvXqCpwFJQNH,WunlkOAgsTyLafYGimtvXqCpwFJQNo,WunlkOAgsTyLafYGimtvXqCpwFJQNU,WunlkOAgsTyLafYGimtvXqCpwFJQNr,WunlkOAgsTyLafYGimtvXqCpwFJQNj,WunlkOAgsTyLafYGimtvXqCpwFJQeh,WunlkOAgsTyLafYGimtvXqCpwFJQNd,WunlkOAgsTyLafYGimtvXqCpwFJQeS)
     WunlkOAgsTyLafYGimtvXqCpwFJQeN=WunlkOAgsTyLafYGimtvXqCpwFJQeD
     WunlkOAgsTyLafYGimtvXqCpwFJQeM =WunlkOAgsTyLafYGimtvXqCpwFJQSx['replayVod']['count']
     WunlkOAgsTyLafYGimtvXqCpwFJQeR=WunlkOAgsTyLafYGimtvXqCpwFJQSx['highlightVod']['count']
     WunlkOAgsTyLafYGimtvXqCpwFJQeB =WunlkOAgsTyLafYGimtvXqCpwFJQSx['vods']['count']
     WunlkOAgsTyLafYGimtvXqCpwFJQNb='' 
     WunlkOAgsTyLafYGimtvXqCpwFJQeK=WunlkOAgsTyLafYGimtvXqCpwFJQeM+WunlkOAgsTyLafYGimtvXqCpwFJQeR+WunlkOAgsTyLafYGimtvXqCpwFJQeB
     if WunlkOAgsTyLafYGimtvXqCpwFJQeK==0:
      if WunlkOAgsTyLafYGimtvXqCpwFJQNI=='2':
       WunlkOAgsTyLafYGimtvXqCpwFJQDx='----- %s -----'%(WunlkOAgsTyLafYGimtvXqCpwFJQNo)
       WunlkOAgsTyLafYGimtvXqCpwFJQNr=''
      else:
       WunlkOAgsTyLafYGimtvXqCpwFJQDx+=' - 관련영상 없음'
       WunlkOAgsTyLafYGimtvXqCpwFJQeN+='\n\n ** 관련영상 없음 **'
     else:
      if WunlkOAgsTyLafYGimtvXqCpwFJQeM!=0:
       WunlkOAgsTyLafYGimtvXqCpwFJQNb =WunlkOAgsTyLafYGimtvXqCpwFJQSx['replayVod']['list'][0]['imgUrl']
      elif WunlkOAgsTyLafYGimtvXqCpwFJQeR!=0:
       WunlkOAgsTyLafYGimtvXqCpwFJQNb =WunlkOAgsTyLafYGimtvXqCpwFJQSx['highlightVod']['list'][0]['imgUrl']
      else:
       WunlkOAgsTyLafYGimtvXqCpwFJQNb =WunlkOAgsTyLafYGimtvXqCpwFJQSx['vods']['list'][0]['imgUrl']
     WunlkOAgsTyLafYGimtvXqCpwFJQSr={'gameTitle':WunlkOAgsTyLafYGimtvXqCpwFJQDx,'gameId':WunlkOAgsTyLafYGimtvXqCpwFJQNV,'beginDate':WunlkOAgsTyLafYGimtvXqCpwFJQNr[:11],'thumbnail':WunlkOAgsTyLafYGimtvXqCpwFJQNb,'info_plot':WunlkOAgsTyLafYGimtvXqCpwFJQeN,'leaguenm':WunlkOAgsTyLafYGimtvXqCpwFJQNH,'seasonnm':WunlkOAgsTyLafYGimtvXqCpwFJQNo,'roundnm':WunlkOAgsTyLafYGimtvXqCpwFJQNU,'totVodCnt':WunlkOAgsTyLafYGimtvXqCpwFJQeK}
     WunlkOAgsTyLafYGimtvXqCpwFJQSc.append(WunlkOAgsTyLafYGimtvXqCpwFJQSr)
  except WunlkOAgsTyLafYGimtvXqCpwFJQeH as exception:
   WunlkOAgsTyLafYGimtvXqCpwFJQeo(exception)
  if WunlkOAgsTyLafYGimtvXqCpwFJQho['count']>page_int*WunlkOAgsTyLafYGimtvXqCpwFJQhN.GAMELIST_LIMIT:WunlkOAgsTyLafYGimtvXqCpwFJQNE=WunlkOAgsTyLafYGimtvXqCpwFJQer
  return WunlkOAgsTyLafYGimtvXqCpwFJQSc,WunlkOAgsTyLafYGimtvXqCpwFJQNE
 def GetGameVodList(WunlkOAgsTyLafYGimtvXqCpwFJQhN,WunlkOAgsTyLafYGimtvXqCpwFJQNV,vodCount=1000):
  WunlkOAgsTyLafYGimtvXqCpwFJQSc=[]
  WunlkOAgsTyLafYGimtvXqCpwFJQeb=''
  try:
   WunlkOAgsTyLafYGimtvXqCpwFJQhd=WunlkOAgsTyLafYGimtvXqCpwFJQhN.API_DOMAIN+'/api/v2/vod/game'
   WunlkOAgsTyLafYGimtvXqCpwFJQNP={'gameId':WunlkOAgsTyLafYGimtvXqCpwFJQNV,'pageItem':WunlkOAgsTyLafYGimtvXqCpwFJQeV(vodCount)}
   WunlkOAgsTyLafYGimtvXqCpwFJQhH=WunlkOAgsTyLafYGimtvXqCpwFJQhN.callRequestCookies('Get',WunlkOAgsTyLafYGimtvXqCpwFJQhd,payload=WunlkOAgsTyLafYGimtvXqCpwFJQec,params=WunlkOAgsTyLafYGimtvXqCpwFJQNP,headers=WunlkOAgsTyLafYGimtvXqCpwFJQec,cookies=WunlkOAgsTyLafYGimtvXqCpwFJQec)
   WunlkOAgsTyLafYGimtvXqCpwFJQho=json.loads(WunlkOAgsTyLafYGimtvXqCpwFJQhH.text)
   WunlkOAgsTyLafYGimtvXqCpwFJQNx=WunlkOAgsTyLafYGimtvXqCpwFJQho['list']
   for WunlkOAgsTyLafYGimtvXqCpwFJQSx in WunlkOAgsTyLafYGimtvXqCpwFJQNx:
    WunlkOAgsTyLafYGimtvXqCpwFJQNR =WunlkOAgsTyLafYGimtvXqCpwFJQSx['title']
    WunlkOAgsTyLafYGimtvXqCpwFJQNB =WunlkOAgsTyLafYGimtvXqCpwFJQSx['id']
    WunlkOAgsTyLafYGimtvXqCpwFJQNK =WunlkOAgsTyLafYGimtvXqCpwFJQSx['vtype']
    WunlkOAgsTyLafYGimtvXqCpwFJQNb =WunlkOAgsTyLafYGimtvXqCpwFJQSx['imgUrl']
    WunlkOAgsTyLafYGimtvXqCpwFJQNz =WunlkOAgsTyLafYGimtvXqCpwFJQSx['vtypeId']
    WunlkOAgsTyLafYGimtvXqCpwFJQez =WunlkOAgsTyLafYGimtvXqCpwFJQSx['isFree']
    WunlkOAgsTyLafYGimtvXqCpwFJQSr={'vodTitle':WunlkOAgsTyLafYGimtvXqCpwFJQNR,'vodId':WunlkOAgsTyLafYGimtvXqCpwFJQNB,'vodType':WunlkOAgsTyLafYGimtvXqCpwFJQNK,'thumbnail':WunlkOAgsTyLafYGimtvXqCpwFJQNb,'vtypeId':WunlkOAgsTyLafYGimtvXqCpwFJQeV(WunlkOAgsTyLafYGimtvXqCpwFJQNz),'duration':WunlkOAgsTyLafYGimtvXqCpwFJQeU(WunlkOAgsTyLafYGimtvXqCpwFJQSx['duration']/1000),'isFree':WunlkOAgsTyLafYGimtvXqCpwFJQez}
    WunlkOAgsTyLafYGimtvXqCpwFJQSc.append(WunlkOAgsTyLafYGimtvXqCpwFJQSr)
  except WunlkOAgsTyLafYGimtvXqCpwFJQeH as exception:
   WunlkOAgsTyLafYGimtvXqCpwFJQeo(exception)
  return WunlkOAgsTyLafYGimtvXqCpwFJQSc
 def GetReplay_UrlId(WunlkOAgsTyLafYGimtvXqCpwFJQhN,WunlkOAgsTyLafYGimtvXqCpwFJQeb,WunlkOAgsTyLafYGimtvXqCpwFJQNz):
  WunlkOAgsTyLafYGimtvXqCpwFJQeE=''
  try:
   WunlkOAgsTyLafYGimtvXqCpwFJQhd=WunlkOAgsTyLafYGimtvXqCpwFJQhN.API_DOMAIN+'/api/v2/vod/'+WunlkOAgsTyLafYGimtvXqCpwFJQeb
   WunlkOAgsTyLafYGimtvXqCpwFJQhH=WunlkOAgsTyLafYGimtvXqCpwFJQhN.callRequestCookies('Get',WunlkOAgsTyLafYGimtvXqCpwFJQhd,payload=WunlkOAgsTyLafYGimtvXqCpwFJQec,params=WunlkOAgsTyLafYGimtvXqCpwFJQec,headers=WunlkOAgsTyLafYGimtvXqCpwFJQec,cookies=WunlkOAgsTyLafYGimtvXqCpwFJQec)
   WunlkOAgsTyLafYGimtvXqCpwFJQho=json.loads(WunlkOAgsTyLafYGimtvXqCpwFJQhH.text)
   WunlkOAgsTyLafYGimtvXqCpwFJQeE=WunlkOAgsTyLafYGimtvXqCpwFJQho['videoId']
  except WunlkOAgsTyLafYGimtvXqCpwFJQeH as exception:
   WunlkOAgsTyLafYGimtvXqCpwFJQeo(exception)
  return WunlkOAgsTyLafYGimtvXqCpwFJQeE
# Created by pyminifier (https://github.com/liftoff/pyminifier)
