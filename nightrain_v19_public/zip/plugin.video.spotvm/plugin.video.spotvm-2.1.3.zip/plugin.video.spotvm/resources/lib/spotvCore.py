__author__="NightRain"
NKXQhgcvMknuJzwCFxrBdAsDSbqpIi=False
NKXQhgcvMknuJzwCFxrBdAsDSbqpIL=object
NKXQhgcvMknuJzwCFxrBdAsDSbqpIa=None
NKXQhgcvMknuJzwCFxrBdAsDSbqpIY=print
NKXQhgcvMknuJzwCFxrBdAsDSbqpIR=str
NKXQhgcvMknuJzwCFxrBdAsDSbqpIV=True
NKXQhgcvMknuJzwCFxrBdAsDSbqpIl=Exception
NKXQhgcvMknuJzwCFxrBdAsDSbqpIm=id
NKXQhgcvMknuJzwCFxrBdAsDSbqpIP=int
NKXQhgcvMknuJzwCFxrBdAsDSbqpIe=len
NKXQhgcvMknuJzwCFxrBdAsDSbqpIH=range
import urllib
import http.cookiejar 
import re
import json
import sys
import time
import requests
import datetime
import base64
NKXQhgcvMknuJzwCFxrBdAsDSbqpOy={'stream50':1080,'stream40':720,'stream30':540}
NKXQhgcvMknuJzwCFxrBdAsDSbqpOj=[{'id':'1','name':'NOW','videoId':'ch_spotvnow1','epgtype':'spotvon','epgnm':'spotvon','free':NKXQhgcvMknuJzwCFxrBdAsDSbqpIi,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/ccdb36ce757afc1ca15fc38357d498e4.png'},{'id':'2','name':'NOW2','videoId':'ch_spotvnow2','epgtype':'spotvon','epgnm':'spotvon2','free':NKXQhgcvMknuJzwCFxrBdAsDSbqpIi,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/8b6bdf6213a715eeba719b2cb9b2c747.png'},{'id':'3','name':'NBA TV','videoId':'ch_nbatv','epgtype':'-','epgnm':'-','free':NKXQhgcvMknuJzwCFxrBdAsDSbqpIi,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/5036e56d5c6594ea606f7159f59779fe.png'},{'id':'9','name':'SPOTV','videoId':'ch_spotv','epgtype':'spotvnet','epgnm':'SPOTV','free':NKXQhgcvMknuJzwCFxrBdAsDSbqpIi,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/56688c2e527c6e1b8d68e338057a7dfc.png'},{'id':'10','name':'SPOTV2','videoId':'ch_spotv2','epgtype':'spotvnet','epgnm':'SPOTV2','free':NKXQhgcvMknuJzwCFxrBdAsDSbqpIi,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20201209/ca6e7a213c84e629985e609ddcda6b17.png'},{'id':'11','name':'SPOTV Golf & Health','videoId':'ch_spotvplus','epgtype':'spotvnet','epgnm':'SPOTVP','free':NKXQhgcvMknuJzwCFxrBdAsDSbqpIi,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/7aa87953f1211313c3e110cace2628ff.png'},]
NKXQhgcvMknuJzwCFxrBdAsDSbqpOI={'1':{'lv':'abf18bbf3b3f4a0db4a41dd2af7f75c6','rv':'__nn__=5981484117001&hdnea=st=1609407000~exp=1609410600~acl=/abf18bbf3b3f4a0db4a41dd2af7f75c6/ap-northeast-1/5764318566001/*~hmac=e28a244d1b6b77d4e0101010816d4cd6ca89d9d31fe6a5290039d2395d81bc03'},'2':{'lv':'3054522000fc4d60aabe23d6e5911275','rv':'__nn__=5981484117001&hdnea=st=1609408800~exp=1609412400~acl=/3054522000fc4d60aabe23d6e5911275/ap-northeast-1/5764318566001/*~hmac=323b2deea8e3455fa77405f37b19231c6f0b48a5690b7218df875171ac2d6be6'},'3':{'lv':'31f99a0a6067413ea1b390c41a5c12be','rv':'__nn__=5981484117001&hdnea=st=1609408800~exp=1609412400~acl=/31f99a0a6067413ea1b390c41a5c12be/ap-northeast-1/5764318566001/*~hmac=b7ac24bc4772e3ad2669000919058bba64a6f001c69c8846341c326b089c306c'},'9':{'lv':'1f2651c2fea34be9850bfdedf8d9cfdb','rv':'__nn__=5981484117001&hdnea=st=1609408800~exp=1609412400~acl=/1f2651c2fea34be9850bfdedf8d9cfdb/ap-northeast-1/5764318566001/*~hmac=e1f6c44d1be5459cfc40af1e1b204ac9b513bb7405e070da2bff8f115f298133'},'10':{'lv':'7bf3fb8685854892b01e1fc897e7e9b0','rv':'__nn__=5981484117001&hdnea=st=1609408800~exp=1609412400~acl=/7bf3fb8685854892b01e1fc897e7e9b0/ap-northeast-1/5764318566001/*~hmac=e9bb30991cfab98b1976aacabafcd51b63769ede40148f7cc289ffed15398e81'},'11':{'lv':'242b2b6c0c654f47a07f4e2420f9c184','rv':'__nn__=5981484117001&hdnea=st=1609408800~exp=1609412400~acl=/242b2b6c0c654f47a07f4e2420f9c184/ap-northeast-1/5764318566001/*~hmac=5e4ce0553e709eb60d880bf37bc2e99661767b0a38ecee037fb4d7dce757b922'},}
class NKXQhgcvMknuJzwCFxrBdAsDSbqpOE(NKXQhgcvMknuJzwCFxrBdAsDSbqpIL):
 def __init__(NKXQhgcvMknuJzwCFxrBdAsDSbqpOt):
  NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.SPOTV_SESSIONID=''
  NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.SPOTV_SESSION =''
  NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.SPOTV_ACCOUNTID=''
  NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.SPOTV_POLICYKEY=''
  NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.SPOTV_SUBEND =''
  NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.SPOTV_PMCODE ='987'
  NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.SPOTV_PMSIZE =3
  NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.GAMELIST_LIMIT =10
  NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.API_DOMAIN ='https://www.spotvnow.co.kr'
  NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.BC_DOMAIN ='https://players.brightcove.net'
  NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.PLAYER_DOMAIN ='https://edge.api.brightcove.com'
  NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.STREAM_DOMAIN ='https://gtm-spotv.brightcovecdn.com'
  NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.STREAM_M3U8 ='ap-northeast-1/5764318566001/playlist_dvr'
  NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36'
  NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.DEFAULT_HEADER ={'user-agent':NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.USER_AGENT}
 def callRequestCookies(NKXQhgcvMknuJzwCFxrBdAsDSbqpOt,jobtype,NKXQhgcvMknuJzwCFxrBdAsDSbqpEU,payload=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,params=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,headers=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,cookies=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,redirects=NKXQhgcvMknuJzwCFxrBdAsDSbqpIi):
  NKXQhgcvMknuJzwCFxrBdAsDSbqpOf=NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.DEFAULT_HEADER
  if headers:NKXQhgcvMknuJzwCFxrBdAsDSbqpOf.update(headers)
  if jobtype=='Get':
   NKXQhgcvMknuJzwCFxrBdAsDSbqpOU=requests.get(NKXQhgcvMknuJzwCFxrBdAsDSbqpEU,params=params,headers=NKXQhgcvMknuJzwCFxrBdAsDSbqpOf,cookies=cookies,allow_redirects=redirects)
  else:
   NKXQhgcvMknuJzwCFxrBdAsDSbqpOU=requests.post(NKXQhgcvMknuJzwCFxrBdAsDSbqpEU,data=payload,params=params,headers=NKXQhgcvMknuJzwCFxrBdAsDSbqpOf,cookies=cookies,allow_redirects=redirects)
  return NKXQhgcvMknuJzwCFxrBdAsDSbqpOU
 def makeDefaultCookies(NKXQhgcvMknuJzwCFxrBdAsDSbqpOt):
  NKXQhgcvMknuJzwCFxrBdAsDSbqpOo={'SESSION':NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.SPOTV_SESSION}
  return NKXQhgcvMknuJzwCFxrBdAsDSbqpOo
 def GetCredential(NKXQhgcvMknuJzwCFxrBdAsDSbqpOt,user_id,user_pw):
  NKXQhgcvMknuJzwCFxrBdAsDSbqpOW=NKXQhgcvMknuJzwCFxrBdAsDSbqpIi
  NKXQhgcvMknuJzwCFxrBdAsDSbqpOT=NKXQhgcvMknuJzwCFxrBdAsDSbqpOV=NKXQhgcvMknuJzwCFxrBdAsDSbqpOP=NKXQhgcvMknuJzwCFxrBdAsDSbqpOe=NKXQhgcvMknuJzwCFxrBdAsDSbqpOm=''
  try:
   NKXQhgcvMknuJzwCFxrBdAsDSbqpOG=base64.standard_b64encode(user_id.encode("UTF-8")).decode('utf-8')
   NKXQhgcvMknuJzwCFxrBdAsDSbqpOi=base64.standard_b64encode(user_pw.encode("UTF-8")).decode('utf-8')
   NKXQhgcvMknuJzwCFxrBdAsDSbqpOL=NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.API_DOMAIN+'/api/v2/login'
   NKXQhgcvMknuJzwCFxrBdAsDSbqpOa={'username':NKXQhgcvMknuJzwCFxrBdAsDSbqpOG,'password':NKXQhgcvMknuJzwCFxrBdAsDSbqpOi}
   NKXQhgcvMknuJzwCFxrBdAsDSbqpOa=json.dumps(NKXQhgcvMknuJzwCFxrBdAsDSbqpOa)
   NKXQhgcvMknuJzwCFxrBdAsDSbqpOY=NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.callRequestCookies('Post',NKXQhgcvMknuJzwCFxrBdAsDSbqpOL,payload=NKXQhgcvMknuJzwCFxrBdAsDSbqpOa,params=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,headers=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,cookies=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa)
   NKXQhgcvMknuJzwCFxrBdAsDSbqpIY(NKXQhgcvMknuJzwCFxrBdAsDSbqpOY.status_code)
   for NKXQhgcvMknuJzwCFxrBdAsDSbqpOR in NKXQhgcvMknuJzwCFxrBdAsDSbqpOY.cookies:
    if NKXQhgcvMknuJzwCFxrBdAsDSbqpOR.name=='SESSION':
     NKXQhgcvMknuJzwCFxrBdAsDSbqpOV=NKXQhgcvMknuJzwCFxrBdAsDSbqpOR.value
     break
   if NKXQhgcvMknuJzwCFxrBdAsDSbqpOV=='':return NKXQhgcvMknuJzwCFxrBdAsDSbqpOW
   NKXQhgcvMknuJzwCFxrBdAsDSbqpOl=json.loads(NKXQhgcvMknuJzwCFxrBdAsDSbqpOY.text)
   if not('userId' in NKXQhgcvMknuJzwCFxrBdAsDSbqpOl):return NKXQhgcvMknuJzwCFxrBdAsDSbqpOW
   NKXQhgcvMknuJzwCFxrBdAsDSbqpOT=NKXQhgcvMknuJzwCFxrBdAsDSbqpIR(NKXQhgcvMknuJzwCFxrBdAsDSbqpOl['userId'])
   NKXQhgcvMknuJzwCFxrBdAsDSbqpOm =NKXQhgcvMknuJzwCFxrBdAsDSbqpIR(NKXQhgcvMknuJzwCFxrBdAsDSbqpOl['subEndTime'])
   NKXQhgcvMknuJzwCFxrBdAsDSbqpOP,NKXQhgcvMknuJzwCFxrBdAsDSbqpOe=NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.GetPolicyKey()
   if NKXQhgcvMknuJzwCFxrBdAsDSbqpOe=='':return NKXQhgcvMknuJzwCFxrBdAsDSbqpOW
   NKXQhgcvMknuJzwCFxrBdAsDSbqpOW=NKXQhgcvMknuJzwCFxrBdAsDSbqpIV
  except NKXQhgcvMknuJzwCFxrBdAsDSbqpIl as exception:
   NKXQhgcvMknuJzwCFxrBdAsDSbqpOT=NKXQhgcvMknuJzwCFxrBdAsDSbqpOV='' 
   NKXQhgcvMknuJzwCFxrBdAsDSbqpIY(exception)
  NKXQhgcvMknuJzwCFxrBdAsDSbqpOH={'spotv_sessionid':NKXQhgcvMknuJzwCFxrBdAsDSbqpOT,'spotv_session':NKXQhgcvMknuJzwCFxrBdAsDSbqpOV,'spotv_accountId':NKXQhgcvMknuJzwCFxrBdAsDSbqpOP,'spotv_policyKey':NKXQhgcvMknuJzwCFxrBdAsDSbqpOe,'spotv_subend':NKXQhgcvMknuJzwCFxrBdAsDSbqpOm}
  NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.SaveCredential(NKXQhgcvMknuJzwCFxrBdAsDSbqpOH)
  return NKXQhgcvMknuJzwCFxrBdAsDSbqpOW
 def SaveCredential(NKXQhgcvMknuJzwCFxrBdAsDSbqpOt,NKXQhgcvMknuJzwCFxrBdAsDSbqpOH):
  NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.SPOTV_SESSIONID=NKXQhgcvMknuJzwCFxrBdAsDSbqpOH.get('spotv_sessionid')
  NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.SPOTV_SESSION =NKXQhgcvMknuJzwCFxrBdAsDSbqpOH.get('spotv_session')
  NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.SPOTV_ACCOUNTID=NKXQhgcvMknuJzwCFxrBdAsDSbqpOH.get('spotv_accountId')
  NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.SPOTV_POLICYKEY=NKXQhgcvMknuJzwCFxrBdAsDSbqpOH.get('spotv_policyKey')
  NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.SPOTV_SUBEND =NKXQhgcvMknuJzwCFxrBdAsDSbqpOH.get('spotv_subend')
 def LoadCredential(NKXQhgcvMknuJzwCFxrBdAsDSbqpOt):
  NKXQhgcvMknuJzwCFxrBdAsDSbqpOH={'spotv_sessionid':NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.SPOTV_SESSIONID,'spotv_session':NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.SPOTV_SESSION,'spotv_accountId':NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.SPOTV_ACCOUNTID,'spotv_policyKey':NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.SPOTV_POLICYKEY,'spotv_subend':NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.SPOTV_SUBEND}
  return NKXQhgcvMknuJzwCFxrBdAsDSbqpOH
 def Get_Now_Datetime(NKXQhgcvMknuJzwCFxrBdAsDSbqpOt):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_Streamurl_Make(NKXQhgcvMknuJzwCFxrBdAsDSbqpOt,NKXQhgcvMknuJzwCFxrBdAsDSbqpIm):
  NKXQhgcvMknuJzwCFxrBdAsDSbqpEy='%s/%s/%s.m3u8?%s'%(NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.STREAM_DOMAIN,NKXQhgcvMknuJzwCFxrBdAsDSbqpOI.get(NKXQhgcvMknuJzwCFxrBdAsDSbqpIm).get('lv'),NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.STREAM_M3U8,NKXQhgcvMknuJzwCFxrBdAsDSbqpOI.get(NKXQhgcvMknuJzwCFxrBdAsDSbqpIm).get('rv'))
  return NKXQhgcvMknuJzwCFxrBdAsDSbqpEy
 def GetLiveChannelList(NKXQhgcvMknuJzwCFxrBdAsDSbqpOt):
  NKXQhgcvMknuJzwCFxrBdAsDSbqpEj=[]
  NKXQhgcvMknuJzwCFxrBdAsDSbqpEI ={}
  try:
   NKXQhgcvMknuJzwCFxrBdAsDSbqpEI=NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.GetEPGList_new()
   for NKXQhgcvMknuJzwCFxrBdAsDSbqpEt in NKXQhgcvMknuJzwCFxrBdAsDSbqpOj:
    NKXQhgcvMknuJzwCFxrBdAsDSbqpEf={'id':NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['id'],'name':NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['name'],'logo':NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['logo'],'videoId':NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['videoId'],'free':NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['free'],'channelepg':NKXQhgcvMknuJzwCFxrBdAsDSbqpEI.get(NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['videoId'])}
    NKXQhgcvMknuJzwCFxrBdAsDSbqpEj.append(NKXQhgcvMknuJzwCFxrBdAsDSbqpEf)
  except NKXQhgcvMknuJzwCFxrBdAsDSbqpIl as exception:
   NKXQhgcvMknuJzwCFxrBdAsDSbqpIY(exception)
  return NKXQhgcvMknuJzwCFxrBdAsDSbqpEj
 def CheckLiveChannel(NKXQhgcvMknuJzwCFxrBdAsDSbqpOt,NKXQhgcvMknuJzwCFxrBdAsDSbqpEl):
  try:
   NKXQhgcvMknuJzwCFxrBdAsDSbqpEU=NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.API_DOMAIN+'/api/v2/channel'
   NKXQhgcvMknuJzwCFxrBdAsDSbqpOY=NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.callRequestCookies('Get',NKXQhgcvMknuJzwCFxrBdAsDSbqpEU,payload=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,params=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,headers=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,cookies=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa)
   NKXQhgcvMknuJzwCFxrBdAsDSbqpOl=json.loads(NKXQhgcvMknuJzwCFxrBdAsDSbqpOY.text)
   for NKXQhgcvMknuJzwCFxrBdAsDSbqpEt in NKXQhgcvMknuJzwCFxrBdAsDSbqpOl:
    if NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['videoId'].replace('ref:','')==NKXQhgcvMknuJzwCFxrBdAsDSbqpEl:
     return NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['free']
  except NKXQhgcvMknuJzwCFxrBdAsDSbqpIl as exception:
   NKXQhgcvMknuJzwCFxrBdAsDSbqpIY(exception)
  return NKXQhgcvMknuJzwCFxrBdAsDSbqpIi
 def GetEPGList(NKXQhgcvMknuJzwCFxrBdAsDSbqpOt):
  NKXQhgcvMknuJzwCFxrBdAsDSbqpEo={}
  NKXQhgcvMknuJzwCFxrBdAsDSbqpEW=NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.Get_Now_Datetime()
  NKXQhgcvMknuJzwCFxrBdAsDSbqpET=NKXQhgcvMknuJzwCFxrBdAsDSbqpEW.strftime('%Y%m%d%H%M')
  NKXQhgcvMknuJzwCFxrBdAsDSbqpEG='%s-%s-%s'%(NKXQhgcvMknuJzwCFxrBdAsDSbqpET[0:4],NKXQhgcvMknuJzwCFxrBdAsDSbqpET[4:6],NKXQhgcvMknuJzwCFxrBdAsDSbqpET[6:8])
  NKXQhgcvMknuJzwCFxrBdAsDSbqpEi=(NKXQhgcvMknuJzwCFxrBdAsDSbqpEW+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M')
  try:
   NKXQhgcvMknuJzwCFxrBdAsDSbqpEU=NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.API_DOMAIN+'/api/v2/program/'+NKXQhgcvMknuJzwCFxrBdAsDSbqpEG
   NKXQhgcvMknuJzwCFxrBdAsDSbqpOY=NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.callRequestCookies('Get',NKXQhgcvMknuJzwCFxrBdAsDSbqpEU,payload=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,params=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,headers=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,cookies=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa)
   NKXQhgcvMknuJzwCFxrBdAsDSbqpOl=json.loads(NKXQhgcvMknuJzwCFxrBdAsDSbqpOY.text)
   NKXQhgcvMknuJzwCFxrBdAsDSbqpEL=-1 
   NKXQhgcvMknuJzwCFxrBdAsDSbqpEa =''
   for NKXQhgcvMknuJzwCFxrBdAsDSbqpEt in NKXQhgcvMknuJzwCFxrBdAsDSbqpOl:
    NKXQhgcvMknuJzwCFxrBdAsDSbqpEY=NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['channelId']
    NKXQhgcvMknuJzwCFxrBdAsDSbqpER =NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['startTime'].replace('-','').replace(' ','').replace(':','')
    NKXQhgcvMknuJzwCFxrBdAsDSbqpEV =NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['endTime'].replace('-','').replace(' ','').replace(':','')
    if NKXQhgcvMknuJzwCFxrBdAsDSbqpIP(NKXQhgcvMknuJzwCFxrBdAsDSbqpET)>NKXQhgcvMknuJzwCFxrBdAsDSbqpIP(NKXQhgcvMknuJzwCFxrBdAsDSbqpEV) :continue
    if NKXQhgcvMknuJzwCFxrBdAsDSbqpIP(NKXQhgcvMknuJzwCFxrBdAsDSbqpEi)<NKXQhgcvMknuJzwCFxrBdAsDSbqpIP(NKXQhgcvMknuJzwCFxrBdAsDSbqpER):continue
    if NKXQhgcvMknuJzwCFxrBdAsDSbqpEL!=NKXQhgcvMknuJzwCFxrBdAsDSbqpEY:
     if NKXQhgcvMknuJzwCFxrBdAsDSbqpEa!='':NKXQhgcvMknuJzwCFxrBdAsDSbqpEo[NKXQhgcvMknuJzwCFxrBdAsDSbqpEL]=NKXQhgcvMknuJzwCFxrBdAsDSbqpEa
     NKXQhgcvMknuJzwCFxrBdAsDSbqpEL=NKXQhgcvMknuJzwCFxrBdAsDSbqpEY
     NKXQhgcvMknuJzwCFxrBdAsDSbqpEa =''
    if NKXQhgcvMknuJzwCFxrBdAsDSbqpEa:NKXQhgcvMknuJzwCFxrBdAsDSbqpEa+='\n'
    NKXQhgcvMknuJzwCFxrBdAsDSbqpEa+=NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['title']+'\n'
    NKXQhgcvMknuJzwCFxrBdAsDSbqpEa+=' [%s ~ %s]'%(NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['startTime'][-5:],NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['endTime'][-5:])+'\n'
   if NKXQhgcvMknuJzwCFxrBdAsDSbqpEa:NKXQhgcvMknuJzwCFxrBdAsDSbqpEo[NKXQhgcvMknuJzwCFxrBdAsDSbqpEL]=NKXQhgcvMknuJzwCFxrBdAsDSbqpEa
  except NKXQhgcvMknuJzwCFxrBdAsDSbqpIl as exception:
   NKXQhgcvMknuJzwCFxrBdAsDSbqpIY(exception)
  return NKXQhgcvMknuJzwCFxrBdAsDSbqpEo
 def GetEPGList_new(NKXQhgcvMknuJzwCFxrBdAsDSbqpOt):
  NKXQhgcvMknuJzwCFxrBdAsDSbqpEo={}
  NKXQhgcvMknuJzwCFxrBdAsDSbqpEW=NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.Get_Now_Datetime()
  NKXQhgcvMknuJzwCFxrBdAsDSbqpET=NKXQhgcvMknuJzwCFxrBdAsDSbqpEW.strftime('%Y%m%d%H%M00')
  NKXQhgcvMknuJzwCFxrBdAsDSbqpEG='%s%s%s'%(NKXQhgcvMknuJzwCFxrBdAsDSbqpET[0:4],NKXQhgcvMknuJzwCFxrBdAsDSbqpET[4:6],NKXQhgcvMknuJzwCFxrBdAsDSbqpET[6:8])
  NKXQhgcvMknuJzwCFxrBdAsDSbqpEi=(NKXQhgcvMknuJzwCFxrBdAsDSbqpEW+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M00')
  try:
   for NKXQhgcvMknuJzwCFxrBdAsDSbqpEt in NKXQhgcvMknuJzwCFxrBdAsDSbqpOj:
    NKXQhgcvMknuJzwCFxrBdAsDSbqpEl =NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['videoId']
    if NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['epgtype']=='spotvon':
     NKXQhgcvMknuJzwCFxrBdAsDSbqpEa=NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.Get_EpgInfo_Spotv_spotvon(NKXQhgcvMknuJzwCFxrBdAsDSbqpEl,NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['epgnm'],NKXQhgcvMknuJzwCFxrBdAsDSbqpEG)
     NKXQhgcvMknuJzwCFxrBdAsDSbqpEo[NKXQhgcvMknuJzwCFxrBdAsDSbqpEl]=NKXQhgcvMknuJzwCFxrBdAsDSbqpEa
    if NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['epgtype']=='spotvnet':
     NKXQhgcvMknuJzwCFxrBdAsDSbqpEa=NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.Get_EpgInfo_Spotv_spotvnet(NKXQhgcvMknuJzwCFxrBdAsDSbqpEl,NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['epgnm'],NKXQhgcvMknuJzwCFxrBdAsDSbqpEG)
     NKXQhgcvMknuJzwCFxrBdAsDSbqpEo[NKXQhgcvMknuJzwCFxrBdAsDSbqpEl]=NKXQhgcvMknuJzwCFxrBdAsDSbqpEa
   for NKXQhgcvMknuJzwCFxrBdAsDSbqpEm in NKXQhgcvMknuJzwCFxrBdAsDSbqpEo.keys():
    if NKXQhgcvMknuJzwCFxrBdAsDSbqpIe(NKXQhgcvMknuJzwCFxrBdAsDSbqpEo.get(NKXQhgcvMknuJzwCFxrBdAsDSbqpEm))==0:continue
    NKXQhgcvMknuJzwCFxrBdAsDSbqpEa =''
    NKXQhgcvMknuJzwCFxrBdAsDSbqpEP=''
    for NKXQhgcvMknuJzwCFxrBdAsDSbqpEe in NKXQhgcvMknuJzwCFxrBdAsDSbqpEo.get(NKXQhgcvMknuJzwCFxrBdAsDSbqpEm):
     NKXQhgcvMknuJzwCFxrBdAsDSbqpER =NKXQhgcvMknuJzwCFxrBdAsDSbqpEe['startTime']
     NKXQhgcvMknuJzwCFxrBdAsDSbqpEV =NKXQhgcvMknuJzwCFxrBdAsDSbqpEe['endTime']
     if NKXQhgcvMknuJzwCFxrBdAsDSbqpIP(NKXQhgcvMknuJzwCFxrBdAsDSbqpET)>NKXQhgcvMknuJzwCFxrBdAsDSbqpIP(NKXQhgcvMknuJzwCFxrBdAsDSbqpEV) :continue
     if NKXQhgcvMknuJzwCFxrBdAsDSbqpIP(NKXQhgcvMknuJzwCFxrBdAsDSbqpEi)<NKXQhgcvMknuJzwCFxrBdAsDSbqpIP(NKXQhgcvMknuJzwCFxrBdAsDSbqpER):continue
     if NKXQhgcvMknuJzwCFxrBdAsDSbqpIP(NKXQhgcvMknuJzwCFxrBdAsDSbqpET)>NKXQhgcvMknuJzwCFxrBdAsDSbqpIP(NKXQhgcvMknuJzwCFxrBdAsDSbqpER)and NKXQhgcvMknuJzwCFxrBdAsDSbqpIP(NKXQhgcvMknuJzwCFxrBdAsDSbqpET)<NKXQhgcvMknuJzwCFxrBdAsDSbqpIP(NKXQhgcvMknuJzwCFxrBdAsDSbqpEV):NKXQhgcvMknuJzwCFxrBdAsDSbqpEP=NKXQhgcvMknuJzwCFxrBdAsDSbqpEe['title']
     if NKXQhgcvMknuJzwCFxrBdAsDSbqpEa:NKXQhgcvMknuJzwCFxrBdAsDSbqpEa+='\n'
     NKXQhgcvMknuJzwCFxrBdAsDSbqpEa+=NKXQhgcvMknuJzwCFxrBdAsDSbqpEe['title']+'\n'
     NKXQhgcvMknuJzwCFxrBdAsDSbqpEa+=' [%s:%s ~ %s:%s]'%(NKXQhgcvMknuJzwCFxrBdAsDSbqpEe['startTime'][8:10],NKXQhgcvMknuJzwCFxrBdAsDSbqpEe['startTime'][10:12],NKXQhgcvMknuJzwCFxrBdAsDSbqpEe['endTime'][8:10],NKXQhgcvMknuJzwCFxrBdAsDSbqpEe['endTime'][10:12])+'\n'
    NKXQhgcvMknuJzwCFxrBdAsDSbqpEo[NKXQhgcvMknuJzwCFxrBdAsDSbqpEm]={'epg':NKXQhgcvMknuJzwCFxrBdAsDSbqpEa,'title':NKXQhgcvMknuJzwCFxrBdAsDSbqpEP}
  except NKXQhgcvMknuJzwCFxrBdAsDSbqpIl as exception:
   NKXQhgcvMknuJzwCFxrBdAsDSbqpIY(exception)
  return NKXQhgcvMknuJzwCFxrBdAsDSbqpEo
 def Get_EpgInfo_Spotv_spotvon(NKXQhgcvMknuJzwCFxrBdAsDSbqpOt,NKXQhgcvMknuJzwCFxrBdAsDSbqpEl,epgnm,now_day):
  NKXQhgcvMknuJzwCFxrBdAsDSbqpEo =[]
  try:
   NKXQhgcvMknuJzwCFxrBdAsDSbqpEU='https://www.spotvon.co.kr/data/onAir/%s/Daily/D%s.asp'%(epgnm,now_day)
   NKXQhgcvMknuJzwCFxrBdAsDSbqpOY=NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.callRequestCookies('Get',NKXQhgcvMknuJzwCFxrBdAsDSbqpEU,payload=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,params=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,headers=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,cookies=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa)
   NKXQhgcvMknuJzwCFxrBdAsDSbqpEH=json.loads(NKXQhgcvMknuJzwCFxrBdAsDSbqpOY.text)
   for NKXQhgcvMknuJzwCFxrBdAsDSbqpEt in NKXQhgcvMknuJzwCFxrBdAsDSbqpEH:
    NKXQhgcvMknuJzwCFxrBdAsDSbqpEf={'title':NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['title'],'startTime':NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['sch_date'].replace('-','')+NKXQhgcvMknuJzwCFxrBdAsDSbqpIR(NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['sch_hour']).zfill(2)+NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['sch_min']+'00'}
    NKXQhgcvMknuJzwCFxrBdAsDSbqpEo.append(NKXQhgcvMknuJzwCFxrBdAsDSbqpEf)
   for i in NKXQhgcvMknuJzwCFxrBdAsDSbqpIH(NKXQhgcvMknuJzwCFxrBdAsDSbqpIe(NKXQhgcvMknuJzwCFxrBdAsDSbqpEo)):
    if i>0:NKXQhgcvMknuJzwCFxrBdAsDSbqpEo[i-1]['endTime']=NKXQhgcvMknuJzwCFxrBdAsDSbqpEo[i]['startTime']
    if i==NKXQhgcvMknuJzwCFxrBdAsDSbqpIe(NKXQhgcvMknuJzwCFxrBdAsDSbqpEo)-1: NKXQhgcvMknuJzwCFxrBdAsDSbqpEo[i]['endTime']=now_day+'240000'
  except NKXQhgcvMknuJzwCFxrBdAsDSbqpIl as exception:
   NKXQhgcvMknuJzwCFxrBdAsDSbqpIY(exception)
   return[]
  return NKXQhgcvMknuJzwCFxrBdAsDSbqpEo
 def Get_EpgInfo_Spotv_spotvnet(NKXQhgcvMknuJzwCFxrBdAsDSbqpOt,NKXQhgcvMknuJzwCFxrBdAsDSbqpEl,epgnm,now_day):
  NKXQhgcvMknuJzwCFxrBdAsDSbqpEo =[]
  try:
   NKXQhgcvMknuJzwCFxrBdAsDSbqpEU='https://www.spotv.net/data/json/schedule/%s/Daily/D%s.json'%(epgnm,now_day)
   NKXQhgcvMknuJzwCFxrBdAsDSbqpOY=NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.callRequestCookies('Get',NKXQhgcvMknuJzwCFxrBdAsDSbqpEU,payload=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,params=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,headers=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,cookies=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa)
   NKXQhgcvMknuJzwCFxrBdAsDSbqpEH=json.loads(NKXQhgcvMknuJzwCFxrBdAsDSbqpOY.text)
   for NKXQhgcvMknuJzwCFxrBdAsDSbqpEt in NKXQhgcvMknuJzwCFxrBdAsDSbqpEH:
    NKXQhgcvMknuJzwCFxrBdAsDSbqpEf={'title':NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['title'],'startTime':NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['sch_date'].replace('-','')+NKXQhgcvMknuJzwCFxrBdAsDSbqpIR(NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['sch_hour']).zfill(2)+NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['sch_min']+'00'}
    NKXQhgcvMknuJzwCFxrBdAsDSbqpEo.append(NKXQhgcvMknuJzwCFxrBdAsDSbqpEf)
   for i in NKXQhgcvMknuJzwCFxrBdAsDSbqpIH(NKXQhgcvMknuJzwCFxrBdAsDSbqpIe(NKXQhgcvMknuJzwCFxrBdAsDSbqpEo)):
    if i>0:NKXQhgcvMknuJzwCFxrBdAsDSbqpEo[i-1]['endTime']=NKXQhgcvMknuJzwCFxrBdAsDSbqpEo[i]['startTime']
    if i==NKXQhgcvMknuJzwCFxrBdAsDSbqpIe(NKXQhgcvMknuJzwCFxrBdAsDSbqpEo)-1: NKXQhgcvMknuJzwCFxrBdAsDSbqpEo[i]['endTime']=now_day+'240000'
  except NKXQhgcvMknuJzwCFxrBdAsDSbqpIl as exception:
   NKXQhgcvMknuJzwCFxrBdAsDSbqpIY(exception)
   return[]
  return NKXQhgcvMknuJzwCFxrBdAsDSbqpEo
 def GetEventLiveList(NKXQhgcvMknuJzwCFxrBdAsDSbqpOt):
  NKXQhgcvMknuJzwCFxrBdAsDSbqpEj=[]
  NKXQhgcvMknuJzwCFxrBdAsDSbqpyO =0
  try:
   NKXQhgcvMknuJzwCFxrBdAsDSbqpyE=NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.Get_Now_Datetime()
   NKXQhgcvMknuJzwCFxrBdAsDSbqpyj=NKXQhgcvMknuJzwCFxrBdAsDSbqpyE.strftime('%Y-%m-%d')
  except NKXQhgcvMknuJzwCFxrBdAsDSbqpIl as exception:
   NKXQhgcvMknuJzwCFxrBdAsDSbqpIY(exception)
   return NKXQhgcvMknuJzwCFxrBdAsDSbqpEj,NKXQhgcvMknuJzwCFxrBdAsDSbqpyO
  try:
   NKXQhgcvMknuJzwCFxrBdAsDSbqpEU=NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.API_DOMAIN+'/api/v2/player/lives/'+NKXQhgcvMknuJzwCFxrBdAsDSbqpyj 
   NKXQhgcvMknuJzwCFxrBdAsDSbqpOo=NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.makeDefaultCookies()
   NKXQhgcvMknuJzwCFxrBdAsDSbqpOY=NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.callRequestCookies('Get',NKXQhgcvMknuJzwCFxrBdAsDSbqpEU,payload=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,params=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,headers=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,cookies=NKXQhgcvMknuJzwCFxrBdAsDSbqpOo)
   NKXQhgcvMknuJzwCFxrBdAsDSbqpyO=NKXQhgcvMknuJzwCFxrBdAsDSbqpOY.status_code 
   NKXQhgcvMknuJzwCFxrBdAsDSbqpOl=json.loads(NKXQhgcvMknuJzwCFxrBdAsDSbqpOY.text)
   for NKXQhgcvMknuJzwCFxrBdAsDSbqpyI in NKXQhgcvMknuJzwCFxrBdAsDSbqpOl:
    for NKXQhgcvMknuJzwCFxrBdAsDSbqpEt in NKXQhgcvMknuJzwCFxrBdAsDSbqpyI['liveNowList']:
     if NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['gameDesc']['title']==NKXQhgcvMknuJzwCFxrBdAsDSbqpIa or NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['gameDesc']['title']=='':
      NKXQhgcvMknuJzwCFxrBdAsDSbqpyt='%s ( %s : %s )'%(NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['leagueName'],NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['homeNameShort'],NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['awayNameShort'])
     else:
      NKXQhgcvMknuJzwCFxrBdAsDSbqpyt=NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['gameDesc']['title']
     NKXQhgcvMknuJzwCFxrBdAsDSbqpEf={'liveId':NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['liveId'],'title':NKXQhgcvMknuJzwCFxrBdAsDSbqpyt,'logo':NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['gameDesc']['leagueLogo'],'free':NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['isFree'],'startTime':NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['startTime']}
     NKXQhgcvMknuJzwCFxrBdAsDSbqpEj.append(NKXQhgcvMknuJzwCFxrBdAsDSbqpEf)
  except NKXQhgcvMknuJzwCFxrBdAsDSbqpIl as exception:
   NKXQhgcvMknuJzwCFxrBdAsDSbqpIY(exception)
  return NKXQhgcvMknuJzwCFxrBdAsDSbqpEj,NKXQhgcvMknuJzwCFxrBdAsDSbqpyO
 def GetEventLive_videoId(NKXQhgcvMknuJzwCFxrBdAsDSbqpOt,liveId):
  NKXQhgcvMknuJzwCFxrBdAsDSbqpyf=''
  try:
   NKXQhgcvMknuJzwCFxrBdAsDSbqpEU=NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.API_DOMAIN+'/api/v2/live/'+liveId
   NKXQhgcvMknuJzwCFxrBdAsDSbqpOY=NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.callRequestCookies('Get',NKXQhgcvMknuJzwCFxrBdAsDSbqpEU,payload=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,params=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,headers=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,cookies=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa)
   NKXQhgcvMknuJzwCFxrBdAsDSbqpOl=json.loads(NKXQhgcvMknuJzwCFxrBdAsDSbqpOY.text)
   NKXQhgcvMknuJzwCFxrBdAsDSbqpyU=NKXQhgcvMknuJzwCFxrBdAsDSbqpOl['videoId']
   NKXQhgcvMknuJzwCFxrBdAsDSbqpyf=NKXQhgcvMknuJzwCFxrBdAsDSbqpyU.replace('ref:','')
  except NKXQhgcvMknuJzwCFxrBdAsDSbqpIl as exception:
   NKXQhgcvMknuJzwCFxrBdAsDSbqpIY(exception)
  return NKXQhgcvMknuJzwCFxrBdAsDSbqpyf
 def CheckMainEnd(NKXQhgcvMknuJzwCFxrBdAsDSbqpOt):
  NKXQhgcvMknuJzwCFxrBdAsDSbqpyo=base64.standard_b64encode((NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.SPOTV_PMCODE+NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.SPOTV_SESSIONID).encode()).decode('utf-8')
  if NKXQhgcvMknuJzwCFxrBdAsDSbqpyo=='OTg3MTgzMzM0Ng==' or NKXQhgcvMknuJzwCFxrBdAsDSbqpyo=='OTg3MTgzMzExNw==':return NKXQhgcvMknuJzwCFxrBdAsDSbqpIV
  return NKXQhgcvMknuJzwCFxrBdAsDSbqpIi
 def CheckSubEnd(NKXQhgcvMknuJzwCFxrBdAsDSbqpOt):
  NKXQhgcvMknuJzwCFxrBdAsDSbqpyW=NKXQhgcvMknuJzwCFxrBdAsDSbqpIi
  try:
   if NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.CheckMainEnd():return NKXQhgcvMknuJzwCFxrBdAsDSbqpIV 
   if NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.SPOTV_SUBEND=='0':return NKXQhgcvMknuJzwCFxrBdAsDSbqpyW
   NKXQhgcvMknuJzwCFxrBdAsDSbqpyT =NKXQhgcvMknuJzwCFxrBdAsDSbqpIP(NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.Get_Now_Datetime().strftime('%Y%m%d'))
   NKXQhgcvMknuJzwCFxrBdAsDSbqpyG =NKXQhgcvMknuJzwCFxrBdAsDSbqpIP(NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.SPOTV_SUBEND)/1000
   NKXQhgcvMknuJzwCFxrBdAsDSbqpyi =NKXQhgcvMknuJzwCFxrBdAsDSbqpIP(datetime.datetime.fromtimestamp(NKXQhgcvMknuJzwCFxrBdAsDSbqpyG,datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul')).strftime('%Y%m%d'))
   if NKXQhgcvMknuJzwCFxrBdAsDSbqpyT<=NKXQhgcvMknuJzwCFxrBdAsDSbqpyi:NKXQhgcvMknuJzwCFxrBdAsDSbqpyW=NKXQhgcvMknuJzwCFxrBdAsDSbqpIV
  except NKXQhgcvMknuJzwCFxrBdAsDSbqpIl as exception:
   NKXQhgcvMknuJzwCFxrBdAsDSbqpIY(exception)
   return NKXQhgcvMknuJzwCFxrBdAsDSbqpyW
  return NKXQhgcvMknuJzwCFxrBdAsDSbqpyW
 def GetMainJspath(NKXQhgcvMknuJzwCFxrBdAsDSbqpOt):
  NKXQhgcvMknuJzwCFxrBdAsDSbqpyL=''
  try:
   NKXQhgcvMknuJzwCFxrBdAsDSbqpEU=NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.API_DOMAIN
   NKXQhgcvMknuJzwCFxrBdAsDSbqpOY=NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.callRequestCookies('Get',NKXQhgcvMknuJzwCFxrBdAsDSbqpEU,payload=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,params=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,headers=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,cookies=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa)
   NKXQhgcvMknuJzwCFxrBdAsDSbqpya=NKXQhgcvMknuJzwCFxrBdAsDSbqpOY.text
   NKXQhgcvMknuJzwCFxrBdAsDSbqpyY =re.findall('https://cdn.spotvnow.co.kr/dist/js/.{20}\.js',NKXQhgcvMknuJzwCFxrBdAsDSbqpya)[0]
   NKXQhgcvMknuJzwCFxrBdAsDSbqpyL=NKXQhgcvMknuJzwCFxrBdAsDSbqpyY
  except NKXQhgcvMknuJzwCFxrBdAsDSbqpIl as exception:
   NKXQhgcvMknuJzwCFxrBdAsDSbqpIY(exception)
  return NKXQhgcvMknuJzwCFxrBdAsDSbqpyL
 def GetBcPlayerUrl(NKXQhgcvMknuJzwCFxrBdAsDSbqpOt):
  NKXQhgcvMknuJzwCFxrBdAsDSbqpyR=''
  try:
   NKXQhgcvMknuJzwCFxrBdAsDSbqpEU=NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.GetMainJspath()
   if NKXQhgcvMknuJzwCFxrBdAsDSbqpEU=='':return NKXQhgcvMknuJzwCFxrBdAsDSbqpyR
   NKXQhgcvMknuJzwCFxrBdAsDSbqpOY=NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.callRequestCookies('Get',NKXQhgcvMknuJzwCFxrBdAsDSbqpEU,payload=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,params=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,headers=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,cookies=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa)
   NKXQhgcvMknuJzwCFxrBdAsDSbqpya=NKXQhgcvMknuJzwCFxrBdAsDSbqpOY.text
   NKXQhgcvMknuJzwCFxrBdAsDSbqpyV =re.findall('bc:\s*\"\d{13}\",\s*player:\s*\".{9}\"',NKXQhgcvMknuJzwCFxrBdAsDSbqpya)[0]
   NKXQhgcvMknuJzwCFxrBdAsDSbqpyV =NKXQhgcvMknuJzwCFxrBdAsDSbqpyV.replace('bc','"bc"')
   NKXQhgcvMknuJzwCFxrBdAsDSbqpyV =NKXQhgcvMknuJzwCFxrBdAsDSbqpyV.replace('player','"player"')
   NKXQhgcvMknuJzwCFxrBdAsDSbqpyV ='{'+NKXQhgcvMknuJzwCFxrBdAsDSbqpyV+'}'
   NKXQhgcvMknuJzwCFxrBdAsDSbqpyV =json.loads(NKXQhgcvMknuJzwCFxrBdAsDSbqpyV)
   bc =NKXQhgcvMknuJzwCFxrBdAsDSbqpyV['bc']
   NKXQhgcvMknuJzwCFxrBdAsDSbqpyl =NKXQhgcvMknuJzwCFxrBdAsDSbqpyV['player']
   NKXQhgcvMknuJzwCFxrBdAsDSbqpyR="%s/%s/%s_default/index.min.js"%(NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.BC_DOMAIN,bc,NKXQhgcvMknuJzwCFxrBdAsDSbqpyl)
  except NKXQhgcvMknuJzwCFxrBdAsDSbqpIl as exception:
   NKXQhgcvMknuJzwCFxrBdAsDSbqpIY(exception)
  return NKXQhgcvMknuJzwCFxrBdAsDSbqpyR
 def GetPolicyKey(NKXQhgcvMknuJzwCFxrBdAsDSbqpOt):
  NKXQhgcvMknuJzwCFxrBdAsDSbqpym=policykey=''
  try:
   NKXQhgcvMknuJzwCFxrBdAsDSbqpEU=NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.GetBcPlayerUrl()
   if NKXQhgcvMknuJzwCFxrBdAsDSbqpEU=='':return NKXQhgcvMknuJzwCFxrBdAsDSbqpym,NKXQhgcvMknuJzwCFxrBdAsDSbqpye
   NKXQhgcvMknuJzwCFxrBdAsDSbqpOY=NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.callRequestCookies('Get',NKXQhgcvMknuJzwCFxrBdAsDSbqpEU,payload=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,params=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,headers=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,cookies=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa)
   NKXQhgcvMknuJzwCFxrBdAsDSbqpya=NKXQhgcvMknuJzwCFxrBdAsDSbqpOY.text
   NKXQhgcvMknuJzwCFxrBdAsDSbqpyY =re.findall('accountId:\s*\"\d{13}\",\s*policyKey:\s*\".[^(){}]{100,300}\"',NKXQhgcvMknuJzwCFxrBdAsDSbqpya)[0]
   NKXQhgcvMknuJzwCFxrBdAsDSbqpyY =NKXQhgcvMknuJzwCFxrBdAsDSbqpyY.replace('accountId','"accountId"')
   NKXQhgcvMknuJzwCFxrBdAsDSbqpyY =NKXQhgcvMknuJzwCFxrBdAsDSbqpyY.replace('policyKey','"policyKey"')
   NKXQhgcvMknuJzwCFxrBdAsDSbqpyY ='{'+NKXQhgcvMknuJzwCFxrBdAsDSbqpyY+'}'
   NKXQhgcvMknuJzwCFxrBdAsDSbqpyP=json.loads(NKXQhgcvMknuJzwCFxrBdAsDSbqpyY)
   NKXQhgcvMknuJzwCFxrBdAsDSbqpym =NKXQhgcvMknuJzwCFxrBdAsDSbqpyP['accountId']
   NKXQhgcvMknuJzwCFxrBdAsDSbqpye =NKXQhgcvMknuJzwCFxrBdAsDSbqpyP['policyKey']
  except NKXQhgcvMknuJzwCFxrBdAsDSbqpIl as exception:
   NKXQhgcvMknuJzwCFxrBdAsDSbqpIY(exception)
  return NKXQhgcvMknuJzwCFxrBdAsDSbqpym,NKXQhgcvMknuJzwCFxrBdAsDSbqpye
 def GetBroadURL(NKXQhgcvMknuJzwCFxrBdAsDSbqpOt,NKXQhgcvMknuJzwCFxrBdAsDSbqpyf,mediatype,NKXQhgcvMknuJzwCFxrBdAsDSbqpjT):
  NKXQhgcvMknuJzwCFxrBdAsDSbqpyH=''
  try:
   if mediatype=='live':
    NKXQhgcvMknuJzwCFxrBdAsDSbqpyf='ref%3A'+NKXQhgcvMknuJzwCFxrBdAsDSbqpyf
   else:
    NKXQhgcvMknuJzwCFxrBdAsDSbqpyf=NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.GetReplay_UrlId(NKXQhgcvMknuJzwCFxrBdAsDSbqpyf,NKXQhgcvMknuJzwCFxrBdAsDSbqpjT)
    if NKXQhgcvMknuJzwCFxrBdAsDSbqpyf=='':return NKXQhgcvMknuJzwCFxrBdAsDSbqpyH
   NKXQhgcvMknuJzwCFxrBdAsDSbqpEU=NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.PLAYER_DOMAIN+'/playback/v1/accounts/'+NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.SPOTV_ACCOUNTID+'/videos/'+NKXQhgcvMknuJzwCFxrBdAsDSbqpyf
   NKXQhgcvMknuJzwCFxrBdAsDSbqpjO={'accept':'application/json;pk='+NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.SPOTV_POLICYKEY}
   NKXQhgcvMknuJzwCFxrBdAsDSbqpOY=NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.callRequestCookies('Get',NKXQhgcvMknuJzwCFxrBdAsDSbqpEU,payload=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,params=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,headers=NKXQhgcvMknuJzwCFxrBdAsDSbqpjO,cookies=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa)
   NKXQhgcvMknuJzwCFxrBdAsDSbqpEH=json.loads(NKXQhgcvMknuJzwCFxrBdAsDSbqpOY.text)
   NKXQhgcvMknuJzwCFxrBdAsDSbqpyH=NKXQhgcvMknuJzwCFxrBdAsDSbqpEH['sources'][0]['src']
   if mediatype=='live':
    NKXQhgcvMknuJzwCFxrBdAsDSbqpyH=NKXQhgcvMknuJzwCFxrBdAsDSbqpyH.replace('playlist.m3u8','playlist_dvr.m3u8')
   NKXQhgcvMknuJzwCFxrBdAsDSbqpyH=NKXQhgcvMknuJzwCFxrBdAsDSbqpyH.replace('http://','https://')
  except NKXQhgcvMknuJzwCFxrBdAsDSbqpIl as exception:
   NKXQhgcvMknuJzwCFxrBdAsDSbqpIY(exception)
  return NKXQhgcvMknuJzwCFxrBdAsDSbqpyH
 def GetTitleGroupList(NKXQhgcvMknuJzwCFxrBdAsDSbqpOt):
  NKXQhgcvMknuJzwCFxrBdAsDSbqpEj=[]
  NKXQhgcvMknuJzwCFxrBdAsDSbqpjE=NKXQhgcvMknuJzwCFxrBdAsDSbqpIi
  try:
   NKXQhgcvMknuJzwCFxrBdAsDSbqpEU=NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.API_DOMAIN+'/api/v2/home/web'
   NKXQhgcvMknuJzwCFxrBdAsDSbqpOY=NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.callRequestCookies('Get',NKXQhgcvMknuJzwCFxrBdAsDSbqpEU,payload=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,params=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,headers=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,cookies=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa)
   NKXQhgcvMknuJzwCFxrBdAsDSbqpOl=json.loads(NKXQhgcvMknuJzwCFxrBdAsDSbqpOY.text)
   for NKXQhgcvMknuJzwCFxrBdAsDSbqpEt in NKXQhgcvMknuJzwCFxrBdAsDSbqpOl:
    if NKXQhgcvMknuJzwCFxrBdAsDSbqpIR(NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['type'])=='3':
     NKXQhgcvMknuJzwCFxrBdAsDSbqpjy=''
     for NKXQhgcvMknuJzwCFxrBdAsDSbqpjI in NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['data']['list']:
      NKXQhgcvMknuJzwCFxrBdAsDSbqpjt='[%s] %s vs %s\n<%s>\n\n'%(NKXQhgcvMknuJzwCFxrBdAsDSbqpjI['gameDesc']['roundName'],NKXQhgcvMknuJzwCFxrBdAsDSbqpjI['gameDesc']['homeNameShort'],NKXQhgcvMknuJzwCFxrBdAsDSbqpjI['gameDesc']['awayNameShort'],NKXQhgcvMknuJzwCFxrBdAsDSbqpjI['gameDesc']['beginDate'])
      NKXQhgcvMknuJzwCFxrBdAsDSbqpjy+=NKXQhgcvMknuJzwCFxrBdAsDSbqpjt
     NKXQhgcvMknuJzwCFxrBdAsDSbqpEf={'title':NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['title'],'logo':NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['logo'],'reagueId':NKXQhgcvMknuJzwCFxrBdAsDSbqpIR(NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['destId']),'subGame':NKXQhgcvMknuJzwCFxrBdAsDSbqpjy}
     NKXQhgcvMknuJzwCFxrBdAsDSbqpEj.append(NKXQhgcvMknuJzwCFxrBdAsDSbqpEf)
     if NKXQhgcvMknuJzwCFxrBdAsDSbqpIR(NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['destId'])=='13':NKXQhgcvMknuJzwCFxrBdAsDSbqpjE=NKXQhgcvMknuJzwCFxrBdAsDSbqpIV
   if NKXQhgcvMknuJzwCFxrBdAsDSbqpjE==NKXQhgcvMknuJzwCFxrBdAsDSbqpIi:
    NKXQhgcvMknuJzwCFxrBdAsDSbqpEf={'title':'UFC','logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200928/a643c7cf1c285fb0b4469c07d4c09c28.png','reagueId':'13','subGame':''}
    NKXQhgcvMknuJzwCFxrBdAsDSbqpEj.append(NKXQhgcvMknuJzwCFxrBdAsDSbqpEf)
  except NKXQhgcvMknuJzwCFxrBdAsDSbqpIl as exception:
   NKXQhgcvMknuJzwCFxrBdAsDSbqpIY(exception)
  return NKXQhgcvMknuJzwCFxrBdAsDSbqpEj
 def GetPopularGroupList(NKXQhgcvMknuJzwCFxrBdAsDSbqpOt):
  NKXQhgcvMknuJzwCFxrBdAsDSbqpEj=[]
  try:
   NKXQhgcvMknuJzwCFxrBdAsDSbqpEU=NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.API_DOMAIN+'/api/v2/home/web'
   NKXQhgcvMknuJzwCFxrBdAsDSbqpOY=NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.callRequestCookies('Get',NKXQhgcvMknuJzwCFxrBdAsDSbqpEU,payload=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,params=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,headers=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,cookies=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa)
   NKXQhgcvMknuJzwCFxrBdAsDSbqpOl=json.loads(NKXQhgcvMknuJzwCFxrBdAsDSbqpOY.text)
   for NKXQhgcvMknuJzwCFxrBdAsDSbqpEt in NKXQhgcvMknuJzwCFxrBdAsDSbqpOl:
    if NKXQhgcvMknuJzwCFxrBdAsDSbqpIR(NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['type'])=='1' and NKXQhgcvMknuJzwCFxrBdAsDSbqpIR(NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['destId'])=='4':
     for NKXQhgcvMknuJzwCFxrBdAsDSbqpjI in NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['data']['list']:
      NKXQhgcvMknuJzwCFxrBdAsDSbqpjf =NKXQhgcvMknuJzwCFxrBdAsDSbqpjI['title']
      NKXQhgcvMknuJzwCFxrBdAsDSbqpjU =NKXQhgcvMknuJzwCFxrBdAsDSbqpjI['id']
      NKXQhgcvMknuJzwCFxrBdAsDSbqpjo =NKXQhgcvMknuJzwCFxrBdAsDSbqpjI['vtype']
      NKXQhgcvMknuJzwCFxrBdAsDSbqpjW =NKXQhgcvMknuJzwCFxrBdAsDSbqpjI['imgUrl']
      NKXQhgcvMknuJzwCFxrBdAsDSbqpjT =NKXQhgcvMknuJzwCFxrBdAsDSbqpjI['vtypeId']
      NKXQhgcvMknuJzwCFxrBdAsDSbqpEf={'vodTitle':NKXQhgcvMknuJzwCFxrBdAsDSbqpjf,'vodId':NKXQhgcvMknuJzwCFxrBdAsDSbqpjU,'vodType':NKXQhgcvMknuJzwCFxrBdAsDSbqpjo,'thumbnail':NKXQhgcvMknuJzwCFxrBdAsDSbqpjW,'vtypeId':NKXQhgcvMknuJzwCFxrBdAsDSbqpIR(NKXQhgcvMknuJzwCFxrBdAsDSbqpjT),'duration':NKXQhgcvMknuJzwCFxrBdAsDSbqpIP(NKXQhgcvMknuJzwCFxrBdAsDSbqpjI['duration']/1000)}
      NKXQhgcvMknuJzwCFxrBdAsDSbqpEj.append(NKXQhgcvMknuJzwCFxrBdAsDSbqpEf)
  except NKXQhgcvMknuJzwCFxrBdAsDSbqpIl as exception:
   NKXQhgcvMknuJzwCFxrBdAsDSbqpIY(exception)
  return NKXQhgcvMknuJzwCFxrBdAsDSbqpEj
 def GetSeasonList(NKXQhgcvMknuJzwCFxrBdAsDSbqpOt,leagueId):
  NKXQhgcvMknuJzwCFxrBdAsDSbqpEj=[]
  NKXQhgcvMknuJzwCFxrBdAsDSbqpjG=NKXQhgcvMknuJzwCFxrBdAsDSbqpji=''
  try:
   NKXQhgcvMknuJzwCFxrBdAsDSbqpEU=NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.API_DOMAIN+'/api/v2/game/league/'+leagueId
   NKXQhgcvMknuJzwCFxrBdAsDSbqpOY=NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.callRequestCookies('Get',NKXQhgcvMknuJzwCFxrBdAsDSbqpEU,payload=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,params=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,headers=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,cookies=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa)
   NKXQhgcvMknuJzwCFxrBdAsDSbqpOl=json.loads(NKXQhgcvMknuJzwCFxrBdAsDSbqpOY.text)
   NKXQhgcvMknuJzwCFxrBdAsDSbqpjG=NKXQhgcvMknuJzwCFxrBdAsDSbqpOl['name']
   NKXQhgcvMknuJzwCFxrBdAsDSbqpji=NKXQhgcvMknuJzwCFxrBdAsDSbqpIR(NKXQhgcvMknuJzwCFxrBdAsDSbqpOl['gameTypeId'])
  except NKXQhgcvMknuJzwCFxrBdAsDSbqpIl as exception:
   NKXQhgcvMknuJzwCFxrBdAsDSbqpIY(exception)
   return NKXQhgcvMknuJzwCFxrBdAsDSbqpEj
  if NKXQhgcvMknuJzwCFxrBdAsDSbqpji=='2':
   try:
    NKXQhgcvMknuJzwCFxrBdAsDSbqpEU=NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.API_DOMAIN+'/api/v2/year/'+leagueId
    NKXQhgcvMknuJzwCFxrBdAsDSbqpOY=NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.callRequestCookies('Get',NKXQhgcvMknuJzwCFxrBdAsDSbqpEU,payload=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,params=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,headers=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,cookies=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa)
    NKXQhgcvMknuJzwCFxrBdAsDSbqpOl=json.loads(NKXQhgcvMknuJzwCFxrBdAsDSbqpOY.text)
    for NKXQhgcvMknuJzwCFxrBdAsDSbqpEt in NKXQhgcvMknuJzwCFxrBdAsDSbqpOl:
     NKXQhgcvMknuJzwCFxrBdAsDSbqpEf={'reagueName':NKXQhgcvMknuJzwCFxrBdAsDSbqpjG,'gameTypeId':NKXQhgcvMknuJzwCFxrBdAsDSbqpji,'seasonName':NKXQhgcvMknuJzwCFxrBdAsDSbqpIR(NKXQhgcvMknuJzwCFxrBdAsDSbqpEt),'seasonId':NKXQhgcvMknuJzwCFxrBdAsDSbqpIR(NKXQhgcvMknuJzwCFxrBdAsDSbqpEt)}
     NKXQhgcvMknuJzwCFxrBdAsDSbqpEj.append(NKXQhgcvMknuJzwCFxrBdAsDSbqpEf)
   except NKXQhgcvMknuJzwCFxrBdAsDSbqpIl as exception:
    NKXQhgcvMknuJzwCFxrBdAsDSbqpIY(exception)
    return[]
  else:
   try:
    NKXQhgcvMknuJzwCFxrBdAsDSbqpEU=NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.API_DOMAIN+'/api/v2/season/'+leagueId
    NKXQhgcvMknuJzwCFxrBdAsDSbqpOY=NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.callRequestCookies('Get',NKXQhgcvMknuJzwCFxrBdAsDSbqpEU,payload=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,params=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,headers=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,cookies=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa)
    NKXQhgcvMknuJzwCFxrBdAsDSbqpOl=json.loads(NKXQhgcvMknuJzwCFxrBdAsDSbqpOY.text)
    for NKXQhgcvMknuJzwCFxrBdAsDSbqpEt in NKXQhgcvMknuJzwCFxrBdAsDSbqpOl:
     NKXQhgcvMknuJzwCFxrBdAsDSbqpEf={'reagueName':NKXQhgcvMknuJzwCFxrBdAsDSbqpjG,'gameTypeId':NKXQhgcvMknuJzwCFxrBdAsDSbqpji,'seasonName':NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['name'],'seasonId':NKXQhgcvMknuJzwCFxrBdAsDSbqpIR(NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['id'])}
     NKXQhgcvMknuJzwCFxrBdAsDSbqpEj.append(NKXQhgcvMknuJzwCFxrBdAsDSbqpEf)
   except NKXQhgcvMknuJzwCFxrBdAsDSbqpIl as exception:
    NKXQhgcvMknuJzwCFxrBdAsDSbqpIY(exception)
    return[]
  return NKXQhgcvMknuJzwCFxrBdAsDSbqpEj
 def GetGameList(NKXQhgcvMknuJzwCFxrBdAsDSbqpOt,NKXQhgcvMknuJzwCFxrBdAsDSbqpji,leagueId,seasonId,page_int,hidescore=NKXQhgcvMknuJzwCFxrBdAsDSbqpIV):
  NKXQhgcvMknuJzwCFxrBdAsDSbqpEj=[]
  NKXQhgcvMknuJzwCFxrBdAsDSbqpjL=NKXQhgcvMknuJzwCFxrBdAsDSbqpIi
  try:
   NKXQhgcvMknuJzwCFxrBdAsDSbqpEU=NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.API_DOMAIN+'/api/v2/vod/league/detail'
   NKXQhgcvMknuJzwCFxrBdAsDSbqpja={'gameType':NKXQhgcvMknuJzwCFxrBdAsDSbqpji,'leagueId':leagueId,'seasonId':seasonId if NKXQhgcvMknuJzwCFxrBdAsDSbqpji!='2' else '','teamId':'','roundId':'','year':'' if NKXQhgcvMknuJzwCFxrBdAsDSbqpji!='2' else seasonId,'pageNo':NKXQhgcvMknuJzwCFxrBdAsDSbqpIR(page_int)}
   NKXQhgcvMknuJzwCFxrBdAsDSbqpOY=NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.callRequestCookies('Get',NKXQhgcvMknuJzwCFxrBdAsDSbqpEU,payload=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,params=NKXQhgcvMknuJzwCFxrBdAsDSbqpja,headers=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,cookies=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa)
   NKXQhgcvMknuJzwCFxrBdAsDSbqpOl=json.loads(NKXQhgcvMknuJzwCFxrBdAsDSbqpOY.text)
   NKXQhgcvMknuJzwCFxrBdAsDSbqpyI=NKXQhgcvMknuJzwCFxrBdAsDSbqpOl['list']
   for NKXQhgcvMknuJzwCFxrBdAsDSbqpjY in NKXQhgcvMknuJzwCFxrBdAsDSbqpyI:
    for NKXQhgcvMknuJzwCFxrBdAsDSbqpEt in NKXQhgcvMknuJzwCFxrBdAsDSbqpjY['list']:
     if NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['gameDesc']['title']==NKXQhgcvMknuJzwCFxrBdAsDSbqpIa or NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['gameDesc']['title']=='':
      NKXQhgcvMknuJzwCFxrBdAsDSbqpyt ='%s vs %s'%(NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['gameDesc']['homeNameShort'],NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['gameDesc']['awayNameShort'])
     else:
      NKXQhgcvMknuJzwCFxrBdAsDSbqpyt =NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['gameDesc']['title']
     NKXQhgcvMknuJzwCFxrBdAsDSbqpjR =NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['gameDesc']['beginDate']
     NKXQhgcvMknuJzwCFxrBdAsDSbqpjV =NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['gameDesc']['id']
     NKXQhgcvMknuJzwCFxrBdAsDSbqpjl =NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['gameDesc']['leagueNameFull']
     NKXQhgcvMknuJzwCFxrBdAsDSbqpjm =NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['gameDesc']['seasonName']
     NKXQhgcvMknuJzwCFxrBdAsDSbqpjP =NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['gameDesc']['roundName']
     NKXQhgcvMknuJzwCFxrBdAsDSbqpje =NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['gameDesc']['homeName']
     NKXQhgcvMknuJzwCFxrBdAsDSbqpjH =NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['gameDesc']['awayName']
     NKXQhgcvMknuJzwCFxrBdAsDSbqpIO =NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['gameDesc']['homeScore']
     NKXQhgcvMknuJzwCFxrBdAsDSbqpIE =NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['gameDesc']['awayScore']
     if hidescore==NKXQhgcvMknuJzwCFxrBdAsDSbqpIV:
      NKXQhgcvMknuJzwCFxrBdAsDSbqpIy ='%s\n - %s (%s)\n - %s\n\nhome : %s\n\naway : %s'%(NKXQhgcvMknuJzwCFxrBdAsDSbqpjl,NKXQhgcvMknuJzwCFxrBdAsDSbqpjm,NKXQhgcvMknuJzwCFxrBdAsDSbqpjP,NKXQhgcvMknuJzwCFxrBdAsDSbqpjR,NKXQhgcvMknuJzwCFxrBdAsDSbqpje,NKXQhgcvMknuJzwCFxrBdAsDSbqpjH)
     else:
      NKXQhgcvMknuJzwCFxrBdAsDSbqpIy ='%s\n - %s (%s)\n - %s\n\nhome : %s (Score %s)\n\naway : %s (Score %s)'%(NKXQhgcvMknuJzwCFxrBdAsDSbqpjl,NKXQhgcvMknuJzwCFxrBdAsDSbqpjm,NKXQhgcvMknuJzwCFxrBdAsDSbqpjP,NKXQhgcvMknuJzwCFxrBdAsDSbqpjR,NKXQhgcvMknuJzwCFxrBdAsDSbqpje,NKXQhgcvMknuJzwCFxrBdAsDSbqpIO,NKXQhgcvMknuJzwCFxrBdAsDSbqpjH,NKXQhgcvMknuJzwCFxrBdAsDSbqpIE)
     NKXQhgcvMknuJzwCFxrBdAsDSbqpIj=NKXQhgcvMknuJzwCFxrBdAsDSbqpIy
     NKXQhgcvMknuJzwCFxrBdAsDSbqpIt =NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['replayVod']['count']
     NKXQhgcvMknuJzwCFxrBdAsDSbqpIf=NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['highlightVod']['count']
     NKXQhgcvMknuJzwCFxrBdAsDSbqpIU =NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['vods']['count']
     NKXQhgcvMknuJzwCFxrBdAsDSbqpjW='' 
     NKXQhgcvMknuJzwCFxrBdAsDSbqpIo=NKXQhgcvMknuJzwCFxrBdAsDSbqpIt+NKXQhgcvMknuJzwCFxrBdAsDSbqpIf+NKXQhgcvMknuJzwCFxrBdAsDSbqpIU
     if NKXQhgcvMknuJzwCFxrBdAsDSbqpIo==0:
      if NKXQhgcvMknuJzwCFxrBdAsDSbqpji=='2':
       NKXQhgcvMknuJzwCFxrBdAsDSbqpyt='----- %s -----'%(NKXQhgcvMknuJzwCFxrBdAsDSbqpjm)
       NKXQhgcvMknuJzwCFxrBdAsDSbqpjR=''
      else:
       NKXQhgcvMknuJzwCFxrBdAsDSbqpyt+=' - 관련영상 없음'
       NKXQhgcvMknuJzwCFxrBdAsDSbqpIj+='\n\n ** 관련영상 없음 **'
     else:
      if NKXQhgcvMknuJzwCFxrBdAsDSbqpIt!=0:
       NKXQhgcvMknuJzwCFxrBdAsDSbqpjW =NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['replayVod']['list'][0]['imgUrl']
      elif NKXQhgcvMknuJzwCFxrBdAsDSbqpIf!=0:
       NKXQhgcvMknuJzwCFxrBdAsDSbqpjW =NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['highlightVod']['list'][0]['imgUrl']
      else:
       NKXQhgcvMknuJzwCFxrBdAsDSbqpjW =NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['vods']['list'][0]['imgUrl']
     NKXQhgcvMknuJzwCFxrBdAsDSbqpEf={'gameTitle':NKXQhgcvMknuJzwCFxrBdAsDSbqpyt,'gameId':NKXQhgcvMknuJzwCFxrBdAsDSbqpjV,'beginDate':NKXQhgcvMknuJzwCFxrBdAsDSbqpjR[:11],'thumbnail':NKXQhgcvMknuJzwCFxrBdAsDSbqpjW,'info_plot':NKXQhgcvMknuJzwCFxrBdAsDSbqpIj,'leaguenm':NKXQhgcvMknuJzwCFxrBdAsDSbqpjl,'seasonnm':NKXQhgcvMknuJzwCFxrBdAsDSbqpjm,'roundnm':NKXQhgcvMknuJzwCFxrBdAsDSbqpjP,'totVodCnt':NKXQhgcvMknuJzwCFxrBdAsDSbqpIo}
     NKXQhgcvMknuJzwCFxrBdAsDSbqpEj.append(NKXQhgcvMknuJzwCFxrBdAsDSbqpEf)
   if NKXQhgcvMknuJzwCFxrBdAsDSbqpji=='2':
    if NKXQhgcvMknuJzwCFxrBdAsDSbqpOl['count']>page_int*NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.GAMELIST_LIMIT:NKXQhgcvMknuJzwCFxrBdAsDSbqpjL=NKXQhgcvMknuJzwCFxrBdAsDSbqpIV
   else:
    if NKXQhgcvMknuJzwCFxrBdAsDSbqpOl['list'][0]['count']>page_int*NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.GAMELIST_LIMIT:NKXQhgcvMknuJzwCFxrBdAsDSbqpjL=NKXQhgcvMknuJzwCFxrBdAsDSbqpIV
  except NKXQhgcvMknuJzwCFxrBdAsDSbqpIl as exception:
   NKXQhgcvMknuJzwCFxrBdAsDSbqpIY(exception)
  return NKXQhgcvMknuJzwCFxrBdAsDSbqpEj,NKXQhgcvMknuJzwCFxrBdAsDSbqpjL
 def GetGameVodList(NKXQhgcvMknuJzwCFxrBdAsDSbqpOt,NKXQhgcvMknuJzwCFxrBdAsDSbqpjV):
  NKXQhgcvMknuJzwCFxrBdAsDSbqpEj=[]
  NKXQhgcvMknuJzwCFxrBdAsDSbqpIW=''
  try:
   NKXQhgcvMknuJzwCFxrBdAsDSbqpEU=NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.API_DOMAIN+'/api/v2/vod/game'
   NKXQhgcvMknuJzwCFxrBdAsDSbqpja={'gameId':NKXQhgcvMknuJzwCFxrBdAsDSbqpjV,'pageItem':'1000'}
   NKXQhgcvMknuJzwCFxrBdAsDSbqpOY=NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.callRequestCookies('Get',NKXQhgcvMknuJzwCFxrBdAsDSbqpEU,payload=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,params=NKXQhgcvMknuJzwCFxrBdAsDSbqpja,headers=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,cookies=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa)
   NKXQhgcvMknuJzwCFxrBdAsDSbqpOl=json.loads(NKXQhgcvMknuJzwCFxrBdAsDSbqpOY.text)
   NKXQhgcvMknuJzwCFxrBdAsDSbqpjY=NKXQhgcvMknuJzwCFxrBdAsDSbqpOl['list']
   for NKXQhgcvMknuJzwCFxrBdAsDSbqpEt in NKXQhgcvMknuJzwCFxrBdAsDSbqpjY:
    NKXQhgcvMknuJzwCFxrBdAsDSbqpjf =NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['title']
    NKXQhgcvMknuJzwCFxrBdAsDSbqpjU =NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['id']
    NKXQhgcvMknuJzwCFxrBdAsDSbqpjo =NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['vtype']
    NKXQhgcvMknuJzwCFxrBdAsDSbqpjW =NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['imgUrl']
    NKXQhgcvMknuJzwCFxrBdAsDSbqpjT =NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['vtypeId']
    NKXQhgcvMknuJzwCFxrBdAsDSbqpEf={'vodTitle':NKXQhgcvMknuJzwCFxrBdAsDSbqpjf,'vodId':NKXQhgcvMknuJzwCFxrBdAsDSbqpjU,'vodType':NKXQhgcvMknuJzwCFxrBdAsDSbqpjo,'thumbnail':NKXQhgcvMknuJzwCFxrBdAsDSbqpjW,'vtypeId':NKXQhgcvMknuJzwCFxrBdAsDSbqpIR(NKXQhgcvMknuJzwCFxrBdAsDSbqpjT),'duration':NKXQhgcvMknuJzwCFxrBdAsDSbqpIP(NKXQhgcvMknuJzwCFxrBdAsDSbqpEt['duration']/1000)}
    NKXQhgcvMknuJzwCFxrBdAsDSbqpEj.append(NKXQhgcvMknuJzwCFxrBdAsDSbqpEf)
  except NKXQhgcvMknuJzwCFxrBdAsDSbqpIl as exception:
   NKXQhgcvMknuJzwCFxrBdAsDSbqpIY(exception)
  return NKXQhgcvMknuJzwCFxrBdAsDSbqpEj
 def GetReplay_UrlId(NKXQhgcvMknuJzwCFxrBdAsDSbqpOt,NKXQhgcvMknuJzwCFxrBdAsDSbqpIW,NKXQhgcvMknuJzwCFxrBdAsDSbqpjT):
  NKXQhgcvMknuJzwCFxrBdAsDSbqpIT=NKXQhgcvMknuJzwCFxrBdAsDSbqpyf=''
  NKXQhgcvMknuJzwCFxrBdAsDSbqpIG=''
  try:
   NKXQhgcvMknuJzwCFxrBdAsDSbqpEU=NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.API_DOMAIN+'/api/v2/vod/'+NKXQhgcvMknuJzwCFxrBdAsDSbqpIW
   NKXQhgcvMknuJzwCFxrBdAsDSbqpOY=NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.callRequestCookies('Get',NKXQhgcvMknuJzwCFxrBdAsDSbqpEU,payload=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,params=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,headers=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa,cookies=NKXQhgcvMknuJzwCFxrBdAsDSbqpIa)
   NKXQhgcvMknuJzwCFxrBdAsDSbqpOl=json.loads(NKXQhgcvMknuJzwCFxrBdAsDSbqpOY.text)
   NKXQhgcvMknuJzwCFxrBdAsDSbqpIT =NKXQhgcvMknuJzwCFxrBdAsDSbqpOl['clipId']
   NKXQhgcvMknuJzwCFxrBdAsDSbqpyf=NKXQhgcvMknuJzwCFxrBdAsDSbqpOl['videoId']
   NKXQhgcvMknuJzwCFxrBdAsDSbqpIG=NKXQhgcvMknuJzwCFxrBdAsDSbqpIT
   if NKXQhgcvMknuJzwCFxrBdAsDSbqpOt.CheckSubEnd()or NKXQhgcvMknuJzwCFxrBdAsDSbqpjT!='1':NKXQhgcvMknuJzwCFxrBdAsDSbqpIG=NKXQhgcvMknuJzwCFxrBdAsDSbqpyf 
  except NKXQhgcvMknuJzwCFxrBdAsDSbqpIl as exception:
   NKXQhgcvMknuJzwCFxrBdAsDSbqpIY(exception)
  return NKXQhgcvMknuJzwCFxrBdAsDSbqpIG
# Created by pyminifier (https://github.com/liftoff/pyminifier)
