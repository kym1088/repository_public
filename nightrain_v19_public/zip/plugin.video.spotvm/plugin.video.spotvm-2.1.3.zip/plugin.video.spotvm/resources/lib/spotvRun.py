__author__="NightRain"
eMTtXKOdwzpuWImkEFqiAGHrLPgQJV=object
eMTtXKOdwzpuWImkEFqiAGHrLPgQJx=None
eMTtXKOdwzpuWImkEFqiAGHrLPgQJv=False
eMTtXKOdwzpuWImkEFqiAGHrLPgQJn=True
eMTtXKOdwzpuWImkEFqiAGHrLPgQJc=int
eMTtXKOdwzpuWImkEFqiAGHrLPgQJD=len
eMTtXKOdwzpuWImkEFqiAGHrLPgQJa=str
eMTtXKOdwzpuWImkEFqiAGHrLPgQJl=open
eMTtXKOdwzpuWImkEFqiAGHrLPgQJb=Exception
eMTtXKOdwzpuWImkEFqiAGHrLPgQJU=print
eMTtXKOdwzpuWImkEFqiAGHrLPgQJR=dict
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
eMTtXKOdwzpuWImkEFqiAGHrLPgQhN=[{'title':'TV 채널 (유료사용자만 지원)','mode':'LIVE_GROUP'},{'title':'Live중계 (독점,현지)','mode':'ELIVE_GROUP'},{'title':'-----------------','mode':'XXX'},{'title':'인기영상5','mode':'POP_GROUP'},{'title':'VOD 영상','mode':'VOD_GROUP'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH'}]
eMTtXKOdwzpuWImkEFqiAGHrLPgQhY=xbmcvfs.translatePath(os.path.join(__profile__,'spotv_cookies.json'))
from spotvCore import*
class eMTtXKOdwzpuWImkEFqiAGHrLPgQhy(eMTtXKOdwzpuWImkEFqiAGHrLPgQJV):
 def __init__(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ,eMTtXKOdwzpuWImkEFqiAGHrLPgQho,eMTtXKOdwzpuWImkEFqiAGHrLPgQhs,eMTtXKOdwzpuWImkEFqiAGHrLPgQhC):
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ._addon_url =eMTtXKOdwzpuWImkEFqiAGHrLPgQho
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ._addon_handle=eMTtXKOdwzpuWImkEFqiAGHrLPgQhs
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.main_params =eMTtXKOdwzpuWImkEFqiAGHrLPgQhC
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.SpotvObj =NKXQhgcvMknuJzwCFxrBdAsDSbqpOE() 
 def addon_noti(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ,sting):
  try:
   eMTtXKOdwzpuWImkEFqiAGHrLPgQhx=xbmcgui.Dialog()
   eMTtXKOdwzpuWImkEFqiAGHrLPgQhx.notification(__addonname__,sting)
  except:
   eMTtXKOdwzpuWImkEFqiAGHrLPgQJx
 def addon_log(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ,string):
  try:
   eMTtXKOdwzpuWImkEFqiAGHrLPgQhv=string.encode('utf-8','ignore')
  except:
   eMTtXKOdwzpuWImkEFqiAGHrLPgQhv='addonException: addon_log'
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhn=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,eMTtXKOdwzpuWImkEFqiAGHrLPgQhv),level=eMTtXKOdwzpuWImkEFqiAGHrLPgQhn)
 def get_keyboard_input(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ,eMTtXKOdwzpuWImkEFqiAGHrLPgQhf):
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhc=eMTtXKOdwzpuWImkEFqiAGHrLPgQJx
  kb=xbmc.Keyboard()
  kb.setHeading(eMTtXKOdwzpuWImkEFqiAGHrLPgQhf)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   eMTtXKOdwzpuWImkEFqiAGHrLPgQhc=kb.getText()
  return eMTtXKOdwzpuWImkEFqiAGHrLPgQhc
 def get_settings_login_info(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ):
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhD =__addon__.getSetting('id')
  eMTtXKOdwzpuWImkEFqiAGHrLPgQha =__addon__.getSetting('pw')
  return(eMTtXKOdwzpuWImkEFqiAGHrLPgQhD,eMTtXKOdwzpuWImkEFqiAGHrLPgQha)
 def get_settings_hidescoreyn(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ):
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhl =__addon__.getSetting('hidescore')
  if eMTtXKOdwzpuWImkEFqiAGHrLPgQhl=='false':
   return eMTtXKOdwzpuWImkEFqiAGHrLPgQJv
  else:
   return eMTtXKOdwzpuWImkEFqiAGHrLPgQJn
 def set_winCredential(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ,credential):
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhb=xbmcgui.Window(10000)
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhb.setProperty('SPOTV_M_SESSIONID',credential.get('spotv_sessionid'))
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhb.setProperty('SPOTV_M_SESSION',credential.get('spotv_session'))
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhb.setProperty('SPOTV_M_ACCOUNTID',credential.get('spotv_accountId'))
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhb.setProperty('SPOTV_M_POLICYKEY',credential.get('spotv_policyKey'))
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhb.setProperty('SPOTV_M_SUBEND',credential.get('spotv_subend'))
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhb.setProperty('SPOTV_M_LOGINTIME',eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.SpotvObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ):
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhb=xbmcgui.Window(10000)
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhU={'spotv_sessionid':eMTtXKOdwzpuWImkEFqiAGHrLPgQhb.getProperty('SPOTV_M_SESSIONID'),'spotv_session':eMTtXKOdwzpuWImkEFqiAGHrLPgQhb.getProperty('SPOTV_M_SESSION'),'spotv_accountId':eMTtXKOdwzpuWImkEFqiAGHrLPgQhb.getProperty('SPOTV_M_ACCOUNTID'),'spotv_policyKey':eMTtXKOdwzpuWImkEFqiAGHrLPgQhb.getProperty('SPOTV_M_POLICYKEY'),'spotv_subend':eMTtXKOdwzpuWImkEFqiAGHrLPgQhb.getProperty('SPOTV_M_SUBEND')}
  return eMTtXKOdwzpuWImkEFqiAGHrLPgQhU
 def add_dir(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ,label,sublabel='',img='',infoLabels=eMTtXKOdwzpuWImkEFqiAGHrLPgQJx,isFolder=eMTtXKOdwzpuWImkEFqiAGHrLPgQJn,params=''):
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhR='%s?%s'%(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ._addon_url,urllib.parse.urlencode(params))
  if sublabel:eMTtXKOdwzpuWImkEFqiAGHrLPgQhf='%s < %s >'%(label,sublabel)
  else: eMTtXKOdwzpuWImkEFqiAGHrLPgQhf=label
  if not img:img='DefaultFolder.png'
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhS=xbmcgui.ListItem(eMTtXKOdwzpuWImkEFqiAGHrLPgQhf)
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhS.setArt({'thumb':img,'icon':img,'poster':img})
  if infoLabels:eMTtXKOdwzpuWImkEFqiAGHrLPgQhS.setInfo(type="Video",infoLabels=infoLabels)
  if not isFolder:eMTtXKOdwzpuWImkEFqiAGHrLPgQhS.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ._addon_handle,eMTtXKOdwzpuWImkEFqiAGHrLPgQhR,eMTtXKOdwzpuWImkEFqiAGHrLPgQhS,isFolder)
 def get_selQuality(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ,etype):
  try:
   eMTtXKOdwzpuWImkEFqiAGHrLPgQhj='selected_quality'
   eMTtXKOdwzpuWImkEFqiAGHrLPgQhB=[1080,720,540]
   eMTtXKOdwzpuWImkEFqiAGHrLPgQyh=eMTtXKOdwzpuWImkEFqiAGHrLPgQJc(__addon__.getSetting(eMTtXKOdwzpuWImkEFqiAGHrLPgQhj))
   return eMTtXKOdwzpuWImkEFqiAGHrLPgQhB[eMTtXKOdwzpuWImkEFqiAGHrLPgQyh]
  except:
   eMTtXKOdwzpuWImkEFqiAGHrLPgQJx
  return 1080 
 def dp_Main_List(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ):
  for eMTtXKOdwzpuWImkEFqiAGHrLPgQyN in eMTtXKOdwzpuWImkEFqiAGHrLPgQhN:
   eMTtXKOdwzpuWImkEFqiAGHrLPgQhf=eMTtXKOdwzpuWImkEFqiAGHrLPgQyN.get('title')
   eMTtXKOdwzpuWImkEFqiAGHrLPgQyY={'mode':eMTtXKOdwzpuWImkEFqiAGHrLPgQyN.get('mode')}
   if eMTtXKOdwzpuWImkEFqiAGHrLPgQyN.get('mode')=='XXX':
    eMTtXKOdwzpuWImkEFqiAGHrLPgQyJ=eMTtXKOdwzpuWImkEFqiAGHrLPgQJv
   else:
    eMTtXKOdwzpuWImkEFqiAGHrLPgQyJ=eMTtXKOdwzpuWImkEFqiAGHrLPgQJn
   eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.add_dir(eMTtXKOdwzpuWImkEFqiAGHrLPgQhf,sublabel='',img='',infoLabels=eMTtXKOdwzpuWImkEFqiAGHrLPgQJx,isFolder=eMTtXKOdwzpuWImkEFqiAGHrLPgQyJ,params=eMTtXKOdwzpuWImkEFqiAGHrLPgQyY)
  if eMTtXKOdwzpuWImkEFqiAGHrLPgQJD(eMTtXKOdwzpuWImkEFqiAGHrLPgQhN)>0:xbmcplugin.endOfDirectory(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ._addon_handle)
 def dp_MainLeague_List(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ,args):
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.SpotvObj.SaveCredential(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.get_winCredential())
  eMTtXKOdwzpuWImkEFqiAGHrLPgQys=eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.SpotvObj.GetTitleGroupList()
  for eMTtXKOdwzpuWImkEFqiAGHrLPgQyC in eMTtXKOdwzpuWImkEFqiAGHrLPgQys:
   eMTtXKOdwzpuWImkEFqiAGHrLPgQhf =eMTtXKOdwzpuWImkEFqiAGHrLPgQyC.get('title')
   eMTtXKOdwzpuWImkEFqiAGHrLPgQyV =eMTtXKOdwzpuWImkEFqiAGHrLPgQyC.get('logo')
   eMTtXKOdwzpuWImkEFqiAGHrLPgQyx =eMTtXKOdwzpuWImkEFqiAGHrLPgQyC.get('reagueId')
   eMTtXKOdwzpuWImkEFqiAGHrLPgQyv =eMTtXKOdwzpuWImkEFqiAGHrLPgQyC.get('subGame')
   eMTtXKOdwzpuWImkEFqiAGHrLPgQyn={'mediatype':'episode','plot':'%s\n\n%s'%(eMTtXKOdwzpuWImkEFqiAGHrLPgQhf,eMTtXKOdwzpuWImkEFqiAGHrLPgQyv)}
   eMTtXKOdwzpuWImkEFqiAGHrLPgQyY={'mode':'LEAGUE_GROUP','reagueId':eMTtXKOdwzpuWImkEFqiAGHrLPgQyx}
   eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.add_dir(eMTtXKOdwzpuWImkEFqiAGHrLPgQhf,sublabel=eMTtXKOdwzpuWImkEFqiAGHrLPgQJx,img=eMTtXKOdwzpuWImkEFqiAGHrLPgQyV,infoLabels=eMTtXKOdwzpuWImkEFqiAGHrLPgQyn,isFolder=eMTtXKOdwzpuWImkEFqiAGHrLPgQJn,params=eMTtXKOdwzpuWImkEFqiAGHrLPgQyY)
  if eMTtXKOdwzpuWImkEFqiAGHrLPgQJD(eMTtXKOdwzpuWImkEFqiAGHrLPgQys)>0:xbmcplugin.endOfDirectory(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ._addon_handle,cacheToDisc=eMTtXKOdwzpuWImkEFqiAGHrLPgQJv)
 def dp_PopVod_GroupList(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ,args):
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.SpotvObj.SaveCredential(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.get_winCredential())
  eMTtXKOdwzpuWImkEFqiAGHrLPgQys=eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.SpotvObj.GetPopularGroupList()
  for eMTtXKOdwzpuWImkEFqiAGHrLPgQyC in eMTtXKOdwzpuWImkEFqiAGHrLPgQys:
   eMTtXKOdwzpuWImkEFqiAGHrLPgQyc =eMTtXKOdwzpuWImkEFqiAGHrLPgQyC.get('vodTitle')
   eMTtXKOdwzpuWImkEFqiAGHrLPgQyD =eMTtXKOdwzpuWImkEFqiAGHrLPgQyC.get('vodId')
   eMTtXKOdwzpuWImkEFqiAGHrLPgQya =eMTtXKOdwzpuWImkEFqiAGHrLPgQyC.get('vodType')
   eMTtXKOdwzpuWImkEFqiAGHrLPgQyV=eMTtXKOdwzpuWImkEFqiAGHrLPgQyC.get('thumbnail')
   eMTtXKOdwzpuWImkEFqiAGHrLPgQyl =eMTtXKOdwzpuWImkEFqiAGHrLPgQyC.get('vtypeId')
   eMTtXKOdwzpuWImkEFqiAGHrLPgQyb =eMTtXKOdwzpuWImkEFqiAGHrLPgQyC.get('duration')
   eMTtXKOdwzpuWImkEFqiAGHrLPgQyn={'mediatype':'video','duration':eMTtXKOdwzpuWImkEFqiAGHrLPgQyb,'plot':eMTtXKOdwzpuWImkEFqiAGHrLPgQyc}
   eMTtXKOdwzpuWImkEFqiAGHrLPgQyY={'mode':'POP_VOD','mediacode':eMTtXKOdwzpuWImkEFqiAGHrLPgQyD,'mediatype':'vod','vtypeId':eMTtXKOdwzpuWImkEFqiAGHrLPgQyl}
   eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.add_dir(eMTtXKOdwzpuWImkEFqiAGHrLPgQyc,sublabel=eMTtXKOdwzpuWImkEFqiAGHrLPgQya,img=eMTtXKOdwzpuWImkEFqiAGHrLPgQyV,infoLabels=eMTtXKOdwzpuWImkEFqiAGHrLPgQyn,isFolder=eMTtXKOdwzpuWImkEFqiAGHrLPgQJv,params=eMTtXKOdwzpuWImkEFqiAGHrLPgQyY)
  if eMTtXKOdwzpuWImkEFqiAGHrLPgQJD(eMTtXKOdwzpuWImkEFqiAGHrLPgQys)>0:xbmcplugin.endOfDirectory(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ._addon_handle,cacheToDisc=eMTtXKOdwzpuWImkEFqiAGHrLPgQJv)
 def dp_Season_List(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ,args):
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.SpotvObj.SaveCredential(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.get_winCredential())
  eMTtXKOdwzpuWImkEFqiAGHrLPgQyx=args.get('reagueId')
  eMTtXKOdwzpuWImkEFqiAGHrLPgQys=eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.SpotvObj.GetSeasonList(eMTtXKOdwzpuWImkEFqiAGHrLPgQyx)
  for eMTtXKOdwzpuWImkEFqiAGHrLPgQyC in eMTtXKOdwzpuWImkEFqiAGHrLPgQys:
   eMTtXKOdwzpuWImkEFqiAGHrLPgQyU =eMTtXKOdwzpuWImkEFqiAGHrLPgQyC.get('reagueName')
   eMTtXKOdwzpuWImkEFqiAGHrLPgQyR =eMTtXKOdwzpuWImkEFqiAGHrLPgQyC.get('gameTypeId')
   eMTtXKOdwzpuWImkEFqiAGHrLPgQyf =eMTtXKOdwzpuWImkEFqiAGHrLPgQyC.get('seasonName')
   eMTtXKOdwzpuWImkEFqiAGHrLPgQyS =eMTtXKOdwzpuWImkEFqiAGHrLPgQyC.get('seasonId')
   eMTtXKOdwzpuWImkEFqiAGHrLPgQyn={'mediatype':'episode','plot':'%s - %s'%(eMTtXKOdwzpuWImkEFqiAGHrLPgQyU,eMTtXKOdwzpuWImkEFqiAGHrLPgQyf)}
   eMTtXKOdwzpuWImkEFqiAGHrLPgQyY={'mode':'SEASON_GROUP','reagueId':eMTtXKOdwzpuWImkEFqiAGHrLPgQyx,'seasonId':eMTtXKOdwzpuWImkEFqiAGHrLPgQyS,'gameTypeId':eMTtXKOdwzpuWImkEFqiAGHrLPgQyR,'page':'1'}
   eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.add_dir(eMTtXKOdwzpuWImkEFqiAGHrLPgQyU,sublabel=eMTtXKOdwzpuWImkEFqiAGHrLPgQyf,img='',infoLabels=eMTtXKOdwzpuWImkEFqiAGHrLPgQyn,isFolder=eMTtXKOdwzpuWImkEFqiAGHrLPgQJn,params=eMTtXKOdwzpuWImkEFqiAGHrLPgQyY)
  if eMTtXKOdwzpuWImkEFqiAGHrLPgQJD(eMTtXKOdwzpuWImkEFqiAGHrLPgQys)>0:xbmcplugin.endOfDirectory(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ._addon_handle,cacheToDisc=eMTtXKOdwzpuWImkEFqiAGHrLPgQJn)
 def dp_Game_List(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ,args):
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.SpotvObj.SaveCredential(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.get_winCredential())
  eMTtXKOdwzpuWImkEFqiAGHrLPgQyR=args.get('gameTypeId')
  eMTtXKOdwzpuWImkEFqiAGHrLPgQyx =args.get('reagueId')
  eMTtXKOdwzpuWImkEFqiAGHrLPgQyS =args.get('seasonId')
  eMTtXKOdwzpuWImkEFqiAGHrLPgQyj =eMTtXKOdwzpuWImkEFqiAGHrLPgQJc(args.get('page'))
  eMTtXKOdwzpuWImkEFqiAGHrLPgQys,eMTtXKOdwzpuWImkEFqiAGHrLPgQyB=eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.SpotvObj.GetGameList(eMTtXKOdwzpuWImkEFqiAGHrLPgQyR,eMTtXKOdwzpuWImkEFqiAGHrLPgQyx,eMTtXKOdwzpuWImkEFqiAGHrLPgQyS,eMTtXKOdwzpuWImkEFqiAGHrLPgQyj,hidescore=eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.get_settings_hidescoreyn())
  for eMTtXKOdwzpuWImkEFqiAGHrLPgQyC in eMTtXKOdwzpuWImkEFqiAGHrLPgQys:
   eMTtXKOdwzpuWImkEFqiAGHrLPgQNh =eMTtXKOdwzpuWImkEFqiAGHrLPgQyC.get('gameTitle')
   eMTtXKOdwzpuWImkEFqiAGHrLPgQNy =eMTtXKOdwzpuWImkEFqiAGHrLPgQyC.get('beginDate')
   eMTtXKOdwzpuWImkEFqiAGHrLPgQyV =eMTtXKOdwzpuWImkEFqiAGHrLPgQyC.get('thumbnail')
   eMTtXKOdwzpuWImkEFqiAGHrLPgQNY =eMTtXKOdwzpuWImkEFqiAGHrLPgQyC.get('gameId')
   eMTtXKOdwzpuWImkEFqiAGHrLPgQNJ =eMTtXKOdwzpuWImkEFqiAGHrLPgQyC.get('totVodCnt')
   eMTtXKOdwzpuWImkEFqiAGHrLPgQNo =eMTtXKOdwzpuWImkEFqiAGHrLPgQyC.get('leaguenm')
   eMTtXKOdwzpuWImkEFqiAGHrLPgQNs =eMTtXKOdwzpuWImkEFqiAGHrLPgQyC.get('seasonnm')
   eMTtXKOdwzpuWImkEFqiAGHrLPgQNC =eMTtXKOdwzpuWImkEFqiAGHrLPgQyC.get('roundnm')
   eMTtXKOdwzpuWImkEFqiAGHrLPgQNV =eMTtXKOdwzpuWImkEFqiAGHrLPgQyC.get('info_plot')
   eMTtXKOdwzpuWImkEFqiAGHrLPgQNx ='%s < %s >'%(eMTtXKOdwzpuWImkEFqiAGHrLPgQNh,eMTtXKOdwzpuWImkEFqiAGHrLPgQNy)
   eMTtXKOdwzpuWImkEFqiAGHrLPgQyn={'mediatype':'video','plot':eMTtXKOdwzpuWImkEFqiAGHrLPgQNV}
   eMTtXKOdwzpuWImkEFqiAGHrLPgQyY={'mode':'GAME_VOD_GROUP' if eMTtXKOdwzpuWImkEFqiAGHrLPgQNJ!=0 else 'XXX','saveTitle':eMTtXKOdwzpuWImkEFqiAGHrLPgQNx,'saveImg':eMTtXKOdwzpuWImkEFqiAGHrLPgQyV,'saveInfo':eMTtXKOdwzpuWImkEFqiAGHrLPgQyn['plot'],'gameid':eMTtXKOdwzpuWImkEFqiAGHrLPgQNY}
   eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.add_dir(eMTtXKOdwzpuWImkEFqiAGHrLPgQNh,sublabel=eMTtXKOdwzpuWImkEFqiAGHrLPgQNy,img=eMTtXKOdwzpuWImkEFqiAGHrLPgQyV,infoLabels=eMTtXKOdwzpuWImkEFqiAGHrLPgQyn,isFolder=eMTtXKOdwzpuWImkEFqiAGHrLPgQJn,params=eMTtXKOdwzpuWImkEFqiAGHrLPgQyY)
  if eMTtXKOdwzpuWImkEFqiAGHrLPgQyB:
   eMTtXKOdwzpuWImkEFqiAGHrLPgQyY['mode'] ='SEASON_GROUP' 
   eMTtXKOdwzpuWImkEFqiAGHrLPgQyY['reagueId'] =eMTtXKOdwzpuWImkEFqiAGHrLPgQyx
   eMTtXKOdwzpuWImkEFqiAGHrLPgQyY['seasonId'] =eMTtXKOdwzpuWImkEFqiAGHrLPgQyS
   eMTtXKOdwzpuWImkEFqiAGHrLPgQyY['gameTypeId']=eMTtXKOdwzpuWImkEFqiAGHrLPgQyR
   eMTtXKOdwzpuWImkEFqiAGHrLPgQyY['page'] =eMTtXKOdwzpuWImkEFqiAGHrLPgQJa(eMTtXKOdwzpuWImkEFqiAGHrLPgQyj+1)
   eMTtXKOdwzpuWImkEFqiAGHrLPgQhf='[B]%s >>[/B]'%'다음 페이지'
   eMTtXKOdwzpuWImkEFqiAGHrLPgQNv=eMTtXKOdwzpuWImkEFqiAGHrLPgQJa(eMTtXKOdwzpuWImkEFqiAGHrLPgQyj+1)
   eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.add_dir(eMTtXKOdwzpuWImkEFqiAGHrLPgQhf,sublabel=eMTtXKOdwzpuWImkEFqiAGHrLPgQNv,img='',infoLabels=eMTtXKOdwzpuWImkEFqiAGHrLPgQJx,isFolder=eMTtXKOdwzpuWImkEFqiAGHrLPgQJn,params=eMTtXKOdwzpuWImkEFqiAGHrLPgQyY)
  if eMTtXKOdwzpuWImkEFqiAGHrLPgQJD(eMTtXKOdwzpuWImkEFqiAGHrLPgQys)>0:xbmcplugin.endOfDirectory(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ._addon_handle,cacheToDisc=eMTtXKOdwzpuWImkEFqiAGHrLPgQJv)
 def dp_GameVod_List(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ,args):
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.SpotvObj.SaveCredential(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.get_winCredential())
  eMTtXKOdwzpuWImkEFqiAGHrLPgQNn =args.get('gameid')
  eMTtXKOdwzpuWImkEFqiAGHrLPgQNx=args.get('saveTitle')
  eMTtXKOdwzpuWImkEFqiAGHrLPgQNc =args.get('saveImg')
  eMTtXKOdwzpuWImkEFqiAGHrLPgQND =args.get('saveInfo')
  eMTtXKOdwzpuWImkEFqiAGHrLPgQys=eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.SpotvObj.GetGameVodList(eMTtXKOdwzpuWImkEFqiAGHrLPgQNn)
  for eMTtXKOdwzpuWImkEFqiAGHrLPgQyC in eMTtXKOdwzpuWImkEFqiAGHrLPgQys:
   eMTtXKOdwzpuWImkEFqiAGHrLPgQyc =eMTtXKOdwzpuWImkEFqiAGHrLPgQyC.get('vodTitle')
   eMTtXKOdwzpuWImkEFqiAGHrLPgQyD =eMTtXKOdwzpuWImkEFqiAGHrLPgQyC.get('vodId')
   eMTtXKOdwzpuWImkEFqiAGHrLPgQya =eMTtXKOdwzpuWImkEFqiAGHrLPgQyC.get('vodType')
   eMTtXKOdwzpuWImkEFqiAGHrLPgQyV=eMTtXKOdwzpuWImkEFqiAGHrLPgQyC.get('thumbnail')
   eMTtXKOdwzpuWImkEFqiAGHrLPgQyl =eMTtXKOdwzpuWImkEFqiAGHrLPgQyC.get('vtypeId')
   eMTtXKOdwzpuWImkEFqiAGHrLPgQyb =eMTtXKOdwzpuWImkEFqiAGHrLPgQyC.get('duration')
   eMTtXKOdwzpuWImkEFqiAGHrLPgQyn={'mediatype':'video','duration':eMTtXKOdwzpuWImkEFqiAGHrLPgQyb,'plot':'%s \n\n %s'%(eMTtXKOdwzpuWImkEFqiAGHrLPgQyc,eMTtXKOdwzpuWImkEFqiAGHrLPgQND)}
   eMTtXKOdwzpuWImkEFqiAGHrLPgQyY={'mode':'GAME_VOD','saveTitle':eMTtXKOdwzpuWImkEFqiAGHrLPgQNx,'saveImg':eMTtXKOdwzpuWImkEFqiAGHrLPgQNc,'saveId':eMTtXKOdwzpuWImkEFqiAGHrLPgQNn,'saveInfo':eMTtXKOdwzpuWImkEFqiAGHrLPgQND,'mediacode':eMTtXKOdwzpuWImkEFqiAGHrLPgQyD,'mediatype':'vod','vtypeId':eMTtXKOdwzpuWImkEFqiAGHrLPgQyl}
   eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.add_dir(eMTtXKOdwzpuWImkEFqiAGHrLPgQyc,sublabel=eMTtXKOdwzpuWImkEFqiAGHrLPgQya,img=eMTtXKOdwzpuWImkEFqiAGHrLPgQyV,infoLabels=eMTtXKOdwzpuWImkEFqiAGHrLPgQyn,isFolder=eMTtXKOdwzpuWImkEFqiAGHrLPgQJv,params=eMTtXKOdwzpuWImkEFqiAGHrLPgQyY)
  if eMTtXKOdwzpuWImkEFqiAGHrLPgQJD(eMTtXKOdwzpuWImkEFqiAGHrLPgQys)>0:xbmcplugin.endOfDirectory(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ._addon_handle,cacheToDisc=eMTtXKOdwzpuWImkEFqiAGHrLPgQJv)
 def login_main(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ):
  (eMTtXKOdwzpuWImkEFqiAGHrLPgQNa,eMTtXKOdwzpuWImkEFqiAGHrLPgQNl)=eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.get_settings_login_info()
  if not(eMTtXKOdwzpuWImkEFqiAGHrLPgQNa and eMTtXKOdwzpuWImkEFqiAGHrLPgQNl):
   eMTtXKOdwzpuWImkEFqiAGHrLPgQhx=xbmcgui.Dialog()
   eMTtXKOdwzpuWImkEFqiAGHrLPgQNb=eMTtXKOdwzpuWImkEFqiAGHrLPgQhx.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if eMTtXKOdwzpuWImkEFqiAGHrLPgQNb==eMTtXKOdwzpuWImkEFqiAGHrLPgQJn:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.cookiefile_check():return
  eMTtXKOdwzpuWImkEFqiAGHrLPgQNU =eMTtXKOdwzpuWImkEFqiAGHrLPgQJc(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))
  eMTtXKOdwzpuWImkEFqiAGHrLPgQNR=xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINTIME')
  if eMTtXKOdwzpuWImkEFqiAGHrLPgQNR==eMTtXKOdwzpuWImkEFqiAGHrLPgQJx or eMTtXKOdwzpuWImkEFqiAGHrLPgQNR=='':
   eMTtXKOdwzpuWImkEFqiAGHrLPgQNR=eMTtXKOdwzpuWImkEFqiAGHrLPgQJc('19000101')
  else:
   eMTtXKOdwzpuWImkEFqiAGHrLPgQNR=eMTtXKOdwzpuWImkEFqiAGHrLPgQJc(re.sub('-','',eMTtXKOdwzpuWImkEFqiAGHrLPgQNR))
  if xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINWAIT')=='TRUE':
   eMTtXKOdwzpuWImkEFqiAGHrLPgQNf=0
   while eMTtXKOdwzpuWImkEFqiAGHrLPgQJn:
    eMTtXKOdwzpuWImkEFqiAGHrLPgQNf+=1
    time.sleep(0.05)
    if eMTtXKOdwzpuWImkEFqiAGHrLPgQNR>=eMTtXKOdwzpuWImkEFqiAGHrLPgQNU:return
    if eMTtXKOdwzpuWImkEFqiAGHrLPgQNf>600:return
  else:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','TRUE')
  if eMTtXKOdwzpuWImkEFqiAGHrLPgQNR>=eMTtXKOdwzpuWImkEFqiAGHrLPgQNU:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
   return
  if not eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.SpotvObj.GetCredential(eMTtXKOdwzpuWImkEFqiAGHrLPgQNa,eMTtXKOdwzpuWImkEFqiAGHrLPgQNl):
   eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
   sys.exit()
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.set_winCredential(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.SpotvObj.LoadCredential())
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.cookiefile_save()
  xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
 def dp_LiveChannel_List(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ,args):
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.SpotvObj.SaveCredential(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.get_winCredential())
  eMTtXKOdwzpuWImkEFqiAGHrLPgQNS=eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.SpotvObj.GetLiveChannelList()
  for eMTtXKOdwzpuWImkEFqiAGHrLPgQNj in eMTtXKOdwzpuWImkEFqiAGHrLPgQNS:
   eMTtXKOdwzpuWImkEFqiAGHrLPgQhf =eMTtXKOdwzpuWImkEFqiAGHrLPgQNj.get('name')
   eMTtXKOdwzpuWImkEFqiAGHrLPgQyV =eMTtXKOdwzpuWImkEFqiAGHrLPgQNj.get('logo')
   eMTtXKOdwzpuWImkEFqiAGHrLPgQNB=eMTtXKOdwzpuWImkEFqiAGHrLPgQNj.get('channelepg')
   eMTtXKOdwzpuWImkEFqiAGHrLPgQYh =eMTtXKOdwzpuWImkEFqiAGHrLPgQNj.get('free')
   if eMTtXKOdwzpuWImkEFqiAGHrLPgQNB:
    eMTtXKOdwzpuWImkEFqiAGHrLPgQYy =eMTtXKOdwzpuWImkEFqiAGHrLPgQNB['epg']
    eMTtXKOdwzpuWImkEFqiAGHrLPgQYN=eMTtXKOdwzpuWImkEFqiAGHrLPgQNB['title']
   else:
    eMTtXKOdwzpuWImkEFqiAGHrLPgQYy =''
    eMTtXKOdwzpuWImkEFqiAGHrLPgQYN=''
   eMTtXKOdwzpuWImkEFqiAGHrLPgQyn={'plot':'%s\n\n%s'%(eMTtXKOdwzpuWImkEFqiAGHrLPgQhf,eMTtXKOdwzpuWImkEFqiAGHrLPgQYy),'mediatype':'video'}
   eMTtXKOdwzpuWImkEFqiAGHrLPgQyY={'mode':'LIVE','mediaid':eMTtXKOdwzpuWImkEFqiAGHrLPgQNj.get('id'),'mediacode':eMTtXKOdwzpuWImkEFqiAGHrLPgQNj.get('videoId'),'free':eMTtXKOdwzpuWImkEFqiAGHrLPgQYh,'mediatype':'live'}
   if eMTtXKOdwzpuWImkEFqiAGHrLPgQYh:eMTtXKOdwzpuWImkEFqiAGHrLPgQhf+=' [free]'
   eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.add_dir(eMTtXKOdwzpuWImkEFqiAGHrLPgQhf,sublabel=eMTtXKOdwzpuWImkEFqiAGHrLPgQYN,img=eMTtXKOdwzpuWImkEFqiAGHrLPgQyV,infoLabels=eMTtXKOdwzpuWImkEFqiAGHrLPgQyn,isFolder=eMTtXKOdwzpuWImkEFqiAGHrLPgQJv,params=eMTtXKOdwzpuWImkEFqiAGHrLPgQyY)
  if eMTtXKOdwzpuWImkEFqiAGHrLPgQJD(eMTtXKOdwzpuWImkEFqiAGHrLPgQNS)>0:xbmcplugin.endOfDirectory(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ._addon_handle,cacheToDisc=eMTtXKOdwzpuWImkEFqiAGHrLPgQJv)
 def dp_EventLiveChannel_List(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ,args):
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.SpotvObj.SaveCredential(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.get_winCredential())
  eMTtXKOdwzpuWImkEFqiAGHrLPgQNS,eMTtXKOdwzpuWImkEFqiAGHrLPgQYJ=eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.SpotvObj.GetEventLiveList()
  if eMTtXKOdwzpuWImkEFqiAGHrLPgQYJ!=401 and eMTtXKOdwzpuWImkEFqiAGHrLPgQJD(eMTtXKOdwzpuWImkEFqiAGHrLPgQNS)==0:
   eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.addon_noti(__language__(30907).encode('utf8'))
  for eMTtXKOdwzpuWImkEFqiAGHrLPgQNj in eMTtXKOdwzpuWImkEFqiAGHrLPgQNS:
   eMTtXKOdwzpuWImkEFqiAGHrLPgQhf =eMTtXKOdwzpuWImkEFqiAGHrLPgQNj.get('title')
   eMTtXKOdwzpuWImkEFqiAGHrLPgQyo =eMTtXKOdwzpuWImkEFqiAGHrLPgQNj.get('startTime')
   eMTtXKOdwzpuWImkEFqiAGHrLPgQyV =eMTtXKOdwzpuWImkEFqiAGHrLPgQNj.get('logo')
   eMTtXKOdwzpuWImkEFqiAGHrLPgQYh =eMTtXKOdwzpuWImkEFqiAGHrLPgQNj.get('free')
   eMTtXKOdwzpuWImkEFqiAGHrLPgQyn={'mediatype':'video','plot':'%s\n\n%s'%(eMTtXKOdwzpuWImkEFqiAGHrLPgQhf,eMTtXKOdwzpuWImkEFqiAGHrLPgQyo)}
   eMTtXKOdwzpuWImkEFqiAGHrLPgQyY={'mode':'ELIVE','mediaid':eMTtXKOdwzpuWImkEFqiAGHrLPgQNj.get('liveId'),'mediacode':'','free':eMTtXKOdwzpuWImkEFqiAGHrLPgQYh,'mediatype':'live'}
   if eMTtXKOdwzpuWImkEFqiAGHrLPgQYh:eMTtXKOdwzpuWImkEFqiAGHrLPgQhf+=' [free]'
   eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.add_dir(eMTtXKOdwzpuWImkEFqiAGHrLPgQhf,sublabel=eMTtXKOdwzpuWImkEFqiAGHrLPgQyo,img=eMTtXKOdwzpuWImkEFqiAGHrLPgQyV,infoLabels=eMTtXKOdwzpuWImkEFqiAGHrLPgQyn,isFolder=eMTtXKOdwzpuWImkEFqiAGHrLPgQJv,params=eMTtXKOdwzpuWImkEFqiAGHrLPgQyY)
  if eMTtXKOdwzpuWImkEFqiAGHrLPgQJD(eMTtXKOdwzpuWImkEFqiAGHrLPgQNS)>0:xbmcplugin.endOfDirectory(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ._addon_handle,cacheToDisc=eMTtXKOdwzpuWImkEFqiAGHrLPgQJn)
  return eMTtXKOdwzpuWImkEFqiAGHrLPgQYJ
 def play_VIDEO(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ,args):
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.SpotvObj.SaveCredential(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.get_winCredential())
  eMTtXKOdwzpuWImkEFqiAGHrLPgQYo =args.get('mode')
  eMTtXKOdwzpuWImkEFqiAGHrLPgQYs =args.get('mediacode')
  eMTtXKOdwzpuWImkEFqiAGHrLPgQYC =args.get('mediatype')
  eMTtXKOdwzpuWImkEFqiAGHrLPgQyl =args.get('vtypeId')
  if eMTtXKOdwzpuWImkEFqiAGHrLPgQYo=='LIVE':
   if args.get('free')=='False':
    if eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.SpotvObj.CheckSubEnd()==eMTtXKOdwzpuWImkEFqiAGHrLPgQJv:
     eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.addon_noti(__language__(30908).encode('utf8'))
     return
  elif eMTtXKOdwzpuWImkEFqiAGHrLPgQYo=='ELIVE':
   if args.get('free')=='False':
    if eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.SpotvObj.CheckSubEnd()==eMTtXKOdwzpuWImkEFqiAGHrLPgQJv:
     eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.addon_noti(__language__(30908).encode('utf8'))
     return
   eMTtXKOdwzpuWImkEFqiAGHrLPgQYs=eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.SpotvObj.GetEventLive_videoId(args.get('mediaid'))
  if eMTtXKOdwzpuWImkEFqiAGHrLPgQYs=='' or eMTtXKOdwzpuWImkEFqiAGHrLPgQYs==eMTtXKOdwzpuWImkEFqiAGHrLPgQJx:
   eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.addon_noti(__language__(30907).encode('utf8'))
   return
  if eMTtXKOdwzpuWImkEFqiAGHrLPgQYo=='LIVE':
   eMTtXKOdwzpuWImkEFqiAGHrLPgQYV=eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.SpotvObj.Get_Streamurl_Make(args.get('mediaid'))
  else:
   eMTtXKOdwzpuWImkEFqiAGHrLPgQYV=eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.SpotvObj.GetBroadURL(eMTtXKOdwzpuWImkEFqiAGHrLPgQYs,eMTtXKOdwzpuWImkEFqiAGHrLPgQYC,eMTtXKOdwzpuWImkEFqiAGHrLPgQyl)
  if eMTtXKOdwzpuWImkEFqiAGHrLPgQYV=='':
   eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.addon_noti(__language__(30908).encode('utf8'))
   return
  eMTtXKOdwzpuWImkEFqiAGHrLPgQYx=eMTtXKOdwzpuWImkEFqiAGHrLPgQYV
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.addon_log(eMTtXKOdwzpuWImkEFqiAGHrLPgQYx)
  eMTtXKOdwzpuWImkEFqiAGHrLPgQYv=xbmcgui.ListItem(path=eMTtXKOdwzpuWImkEFqiAGHrLPgQYx)
  xbmcplugin.setResolvedUrl(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ._addon_handle,eMTtXKOdwzpuWImkEFqiAGHrLPgQJn,eMTtXKOdwzpuWImkEFqiAGHrLPgQYv)
  try:
   if eMTtXKOdwzpuWImkEFqiAGHrLPgQYC=='vod' and eMTtXKOdwzpuWImkEFqiAGHrLPgQYo!='POP_VOD':
    eMTtXKOdwzpuWImkEFqiAGHrLPgQyY={'code':args.get('saveId'),'img':args.get('saveImg'),'title':args.get('saveTitle'),'info':args.get('saveInfo')}
    eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.Save_Watched_List(eMTtXKOdwzpuWImkEFqiAGHrLPgQYC,eMTtXKOdwzpuWImkEFqiAGHrLPgQyY)
  except:
   eMTtXKOdwzpuWImkEFqiAGHrLPgQJx
 def logout(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ):
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhx=xbmcgui.Dialog()
  eMTtXKOdwzpuWImkEFqiAGHrLPgQNb=eMTtXKOdwzpuWImkEFqiAGHrLPgQhx.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if eMTtXKOdwzpuWImkEFqiAGHrLPgQNb==eMTtXKOdwzpuWImkEFqiAGHrLPgQJv:sys.exit()
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.wininfo_clear()
  if os.path.isfile(eMTtXKOdwzpuWImkEFqiAGHrLPgQhY):os.remove(eMTtXKOdwzpuWImkEFqiAGHrLPgQhY)
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ):
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhb=xbmcgui.Window(10000)
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhb.setProperty('SPOTV_M_SESSIONID','')
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhb.setProperty('SPOTV_M_SESSION','')
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhb.setProperty('SPOTV_M_ACCOUNTID','')
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhb.setProperty('SPOTV_M_POLICYKEY','')
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhb.setProperty('SPOTV_M_SUBEND','')
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhb.setProperty('SPOTV_M_LOGINTIME','')
 def cookiefile_save(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ):
  eMTtXKOdwzpuWImkEFqiAGHrLPgQYn =eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.SpotvObj.Get_Now_Datetime()
  eMTtXKOdwzpuWImkEFqiAGHrLPgQYc=eMTtXKOdwzpuWImkEFqiAGHrLPgQYn+datetime.timedelta(days=eMTtXKOdwzpuWImkEFqiAGHrLPgQJc(__addon__.getSetting('cache_ttl')))
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhb=xbmcgui.Window(10000)
  eMTtXKOdwzpuWImkEFqiAGHrLPgQYD={'spotv_sessionid':eMTtXKOdwzpuWImkEFqiAGHrLPgQhb.getProperty('SPOTV_M_SESSIONID'),'spotv_session':eMTtXKOdwzpuWImkEFqiAGHrLPgQhb.getProperty('SPOTV_M_SESSION'),'spotv_accountId':eMTtXKOdwzpuWImkEFqiAGHrLPgQhb.getProperty('SPOTV_M_ACCOUNTID'),'spotv_policyKey':base64.standard_b64encode(eMTtXKOdwzpuWImkEFqiAGHrLPgQhb.getProperty('SPOTV_M_POLICYKEY').encode()).decode('utf-8'),'spotv_subend':base64.standard_b64encode((eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.SpotvObj.SPOTV_PMCODE+eMTtXKOdwzpuWImkEFqiAGHrLPgQhb.getProperty('SPOTV_M_SUBEND')).encode()).decode('utf-8'),'spotv_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'spotv_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'spotv_limitdate':eMTtXKOdwzpuWImkEFqiAGHrLPgQYc.strftime('%Y-%m-%d')}
  try: 
   fp=eMTtXKOdwzpuWImkEFqiAGHrLPgQJl(eMTtXKOdwzpuWImkEFqiAGHrLPgQhY,'w',-1,'utf-8')
   json.dump(eMTtXKOdwzpuWImkEFqiAGHrLPgQYD,fp)
   fp.close()
  except eMTtXKOdwzpuWImkEFqiAGHrLPgQJb as exception:
   eMTtXKOdwzpuWImkEFqiAGHrLPgQJU(exception)
 def cookiefile_check(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ):
  eMTtXKOdwzpuWImkEFqiAGHrLPgQYD={}
  try: 
   fp=eMTtXKOdwzpuWImkEFqiAGHrLPgQJl(eMTtXKOdwzpuWImkEFqiAGHrLPgQhY,'r',-1,'utf-8')
   eMTtXKOdwzpuWImkEFqiAGHrLPgQYD= json.load(fp)
   fp.close()
  except eMTtXKOdwzpuWImkEFqiAGHrLPgQJb as exception:
   eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.wininfo_clear()
   return eMTtXKOdwzpuWImkEFqiAGHrLPgQJv
  eMTtXKOdwzpuWImkEFqiAGHrLPgQNa =__addon__.getSetting('id')
  eMTtXKOdwzpuWImkEFqiAGHrLPgQNl =__addon__.getSetting('pw')
  eMTtXKOdwzpuWImkEFqiAGHrLPgQYD['spotv_id'] =base64.standard_b64decode(eMTtXKOdwzpuWImkEFqiAGHrLPgQYD['spotv_id']).decode('utf-8')
  eMTtXKOdwzpuWImkEFqiAGHrLPgQYD['spotv_pw'] =base64.standard_b64decode(eMTtXKOdwzpuWImkEFqiAGHrLPgQYD['spotv_pw']).decode('utf-8')
  eMTtXKOdwzpuWImkEFqiAGHrLPgQYD['spotv_policyKey']=base64.standard_b64decode(eMTtXKOdwzpuWImkEFqiAGHrLPgQYD['spotv_policyKey']).decode('utf-8')
  eMTtXKOdwzpuWImkEFqiAGHrLPgQYD['spotv_subend']=base64.standard_b64decode(eMTtXKOdwzpuWImkEFqiAGHrLPgQYD['spotv_subend']).decode('utf-8')[eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.SpotvObj.SPOTV_PMSIZE:]
  if eMTtXKOdwzpuWImkEFqiAGHrLPgQNa!=eMTtXKOdwzpuWImkEFqiAGHrLPgQYD['spotv_id']or eMTtXKOdwzpuWImkEFqiAGHrLPgQNl!=eMTtXKOdwzpuWImkEFqiAGHrLPgQYD['spotv_pw']:
   eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.wininfo_clear()
   return eMTtXKOdwzpuWImkEFqiAGHrLPgQJv
  eMTtXKOdwzpuWImkEFqiAGHrLPgQNU =eMTtXKOdwzpuWImkEFqiAGHrLPgQJc(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))
  eMTtXKOdwzpuWImkEFqiAGHrLPgQYa=eMTtXKOdwzpuWImkEFqiAGHrLPgQYD['spotv_limitdate']
  eMTtXKOdwzpuWImkEFqiAGHrLPgQNR =eMTtXKOdwzpuWImkEFqiAGHrLPgQJc(re.sub('-','',eMTtXKOdwzpuWImkEFqiAGHrLPgQYa))
  if eMTtXKOdwzpuWImkEFqiAGHrLPgQNR<eMTtXKOdwzpuWImkEFqiAGHrLPgQNU:
   eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.wininfo_clear()
   return eMTtXKOdwzpuWImkEFqiAGHrLPgQJv
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhb=xbmcgui.Window(10000)
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhb.setProperty('SPOTV_M_SESSIONID',eMTtXKOdwzpuWImkEFqiAGHrLPgQYD['spotv_sessionid'])
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhb.setProperty('SPOTV_M_SESSION',eMTtXKOdwzpuWImkEFqiAGHrLPgQYD['spotv_session'])
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhb.setProperty('SPOTV_M_ACCOUNTID',eMTtXKOdwzpuWImkEFqiAGHrLPgQYD['spotv_accountId'])
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhb.setProperty('SPOTV_M_POLICYKEY',eMTtXKOdwzpuWImkEFqiAGHrLPgQYD['spotv_policyKey'])
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhb.setProperty('SPOTV_M_SUBEND',eMTtXKOdwzpuWImkEFqiAGHrLPgQYD['spotv_subend'])
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhb.setProperty('SPOTV_M_LOGINTIME',eMTtXKOdwzpuWImkEFqiAGHrLPgQYa)
  return eMTtXKOdwzpuWImkEFqiAGHrLPgQJn
 def dp_WatchList_Delete(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ,args):
  eMTtXKOdwzpuWImkEFqiAGHrLPgQYC=args.get('mediatype')
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhx=xbmcgui.Dialog()
  eMTtXKOdwzpuWImkEFqiAGHrLPgQNb=eMTtXKOdwzpuWImkEFqiAGHrLPgQhx.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if eMTtXKOdwzpuWImkEFqiAGHrLPgQNb==eMTtXKOdwzpuWImkEFqiAGHrLPgQJv:sys.exit()
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.Delete_Watched_List(eMTtXKOdwzpuWImkEFqiAGHrLPgQYC)
  xbmc.executebuiltin("Container.Refresh")
 def Delete_Watched_List(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ,eMTtXKOdwzpuWImkEFqiAGHrLPgQYC):
  try:
   eMTtXKOdwzpuWImkEFqiAGHrLPgQYl=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%eMTtXKOdwzpuWImkEFqiAGHrLPgQYC))
   fp=eMTtXKOdwzpuWImkEFqiAGHrLPgQJl(eMTtXKOdwzpuWImkEFqiAGHrLPgQYl,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   eMTtXKOdwzpuWImkEFqiAGHrLPgQJx
 def Load_Watched_List(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ,eMTtXKOdwzpuWImkEFqiAGHrLPgQYC):
  try:
   eMTtXKOdwzpuWImkEFqiAGHrLPgQYl=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%eMTtXKOdwzpuWImkEFqiAGHrLPgQYC))
   fp=eMTtXKOdwzpuWImkEFqiAGHrLPgQJl(eMTtXKOdwzpuWImkEFqiAGHrLPgQYl,'r',-1,'utf-8')
   eMTtXKOdwzpuWImkEFqiAGHrLPgQYb=fp.readlines()
   fp.close()
  except:
   eMTtXKOdwzpuWImkEFqiAGHrLPgQYb=[]
  return eMTtXKOdwzpuWImkEFqiAGHrLPgQYb
 def Save_Watched_List(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ,stype,eMTtXKOdwzpuWImkEFqiAGHrLPgQhC):
  try:
   eMTtXKOdwzpuWImkEFqiAGHrLPgQYl=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   eMTtXKOdwzpuWImkEFqiAGHrLPgQYU=eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.Load_Watched_List(stype) 
   fp=eMTtXKOdwzpuWImkEFqiAGHrLPgQJl(eMTtXKOdwzpuWImkEFqiAGHrLPgQYl,'w',-1,'utf-8')
   eMTtXKOdwzpuWImkEFqiAGHrLPgQYR=urllib.parse.urlencode(eMTtXKOdwzpuWImkEFqiAGHrLPgQhC)
   eMTtXKOdwzpuWImkEFqiAGHrLPgQYR=eMTtXKOdwzpuWImkEFqiAGHrLPgQYR+'\n'
   fp.write(eMTtXKOdwzpuWImkEFqiAGHrLPgQYR)
   eMTtXKOdwzpuWImkEFqiAGHrLPgQYf=0
   for eMTtXKOdwzpuWImkEFqiAGHrLPgQYS in eMTtXKOdwzpuWImkEFqiAGHrLPgQYU:
    eMTtXKOdwzpuWImkEFqiAGHrLPgQYj=eMTtXKOdwzpuWImkEFqiAGHrLPgQJR(urllib.parse.parse_qsl(eMTtXKOdwzpuWImkEFqiAGHrLPgQYS))
    eMTtXKOdwzpuWImkEFqiAGHrLPgQYB=eMTtXKOdwzpuWImkEFqiAGHrLPgQhC.get('code')
    eMTtXKOdwzpuWImkEFqiAGHrLPgQJh=eMTtXKOdwzpuWImkEFqiAGHrLPgQYj.get('code')
    if eMTtXKOdwzpuWImkEFqiAGHrLPgQYB!=eMTtXKOdwzpuWImkEFqiAGHrLPgQJh:
     fp.write(eMTtXKOdwzpuWImkEFqiAGHrLPgQYS)
     eMTtXKOdwzpuWImkEFqiAGHrLPgQYf+=1
     if eMTtXKOdwzpuWImkEFqiAGHrLPgQYf>=50:break
   fp.close()
  except:
   eMTtXKOdwzpuWImkEFqiAGHrLPgQJx
 def dp_Watch_List(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ,args):
  eMTtXKOdwzpuWImkEFqiAGHrLPgQYC ='vod'
  if eMTtXKOdwzpuWImkEFqiAGHrLPgQYC=='vod':
   eMTtXKOdwzpuWImkEFqiAGHrLPgQJy=eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.Load_Watched_List(eMTtXKOdwzpuWImkEFqiAGHrLPgQYC)
   for eMTtXKOdwzpuWImkEFqiAGHrLPgQJN in eMTtXKOdwzpuWImkEFqiAGHrLPgQJy:
    eMTtXKOdwzpuWImkEFqiAGHrLPgQJY=eMTtXKOdwzpuWImkEFqiAGHrLPgQJR(urllib.parse.parse_qsl(eMTtXKOdwzpuWImkEFqiAGHrLPgQJN))
    eMTtXKOdwzpuWImkEFqiAGHrLPgQhf =eMTtXKOdwzpuWImkEFqiAGHrLPgQJY.get('title')
    eMTtXKOdwzpuWImkEFqiAGHrLPgQyV=eMTtXKOdwzpuWImkEFqiAGHrLPgQJY.get('img')
    eMTtXKOdwzpuWImkEFqiAGHrLPgQYs=eMTtXKOdwzpuWImkEFqiAGHrLPgQJY.get('code')
    eMTtXKOdwzpuWImkEFqiAGHrLPgQJo =eMTtXKOdwzpuWImkEFqiAGHrLPgQJY.get('info')
    eMTtXKOdwzpuWImkEFqiAGHrLPgQyn={}
    eMTtXKOdwzpuWImkEFqiAGHrLPgQyn['plot']=eMTtXKOdwzpuWImkEFqiAGHrLPgQJo
    eMTtXKOdwzpuWImkEFqiAGHrLPgQyY={'mode':'GAME_VOD_GROUP','gameid':eMTtXKOdwzpuWImkEFqiAGHrLPgQYs,'saveTitle':eMTtXKOdwzpuWImkEFqiAGHrLPgQhf,'saveImg':eMTtXKOdwzpuWImkEFqiAGHrLPgQyV,'saveInfo':eMTtXKOdwzpuWImkEFqiAGHrLPgQJo,'mediatype':eMTtXKOdwzpuWImkEFqiAGHrLPgQYC}
    eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.add_dir(eMTtXKOdwzpuWImkEFqiAGHrLPgQhf,sublabel='',img=eMTtXKOdwzpuWImkEFqiAGHrLPgQyV,infoLabels=eMTtXKOdwzpuWImkEFqiAGHrLPgQyn,isFolder=eMTtXKOdwzpuWImkEFqiAGHrLPgQJn,params=eMTtXKOdwzpuWImkEFqiAGHrLPgQyY)
   eMTtXKOdwzpuWImkEFqiAGHrLPgQyn={'plot':'시청목록을 삭제합니다.'}
   eMTtXKOdwzpuWImkEFqiAGHrLPgQhf='*** 시청목록 삭제 ***'
   eMTtXKOdwzpuWImkEFqiAGHrLPgQyY={'mode':'MYVIEW_REMOVE','mediatype':eMTtXKOdwzpuWImkEFqiAGHrLPgQYC}
   eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.add_dir(eMTtXKOdwzpuWImkEFqiAGHrLPgQhf,sublabel='',img='',infoLabels=eMTtXKOdwzpuWImkEFqiAGHrLPgQyn,isFolder=eMTtXKOdwzpuWImkEFqiAGHrLPgQJv,params=eMTtXKOdwzpuWImkEFqiAGHrLPgQyY)
   xbmcplugin.endOfDirectory(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ._addon_handle,cacheToDisc=eMTtXKOdwzpuWImkEFqiAGHrLPgQJv)
 def spotv_main(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ):
  eMTtXKOdwzpuWImkEFqiAGHrLPgQJC=eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.main_params.get('mode',eMTtXKOdwzpuWImkEFqiAGHrLPgQJx)
  if eMTtXKOdwzpuWImkEFqiAGHrLPgQJC=='LOGOUT':
   eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.logout()
   return
  eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.login_main()
  if eMTtXKOdwzpuWImkEFqiAGHrLPgQJC is eMTtXKOdwzpuWImkEFqiAGHrLPgQJx:
   eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.dp_Main_List()
  elif eMTtXKOdwzpuWImkEFqiAGHrLPgQJC=='LIVE_GROUP':
   eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.dp_LiveChannel_List(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.main_params)
  elif eMTtXKOdwzpuWImkEFqiAGHrLPgQJC=='ELIVE_GROUP':
   eMTtXKOdwzpuWImkEFqiAGHrLPgQYJ=eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.dp_EventLiveChannel_List(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.main_params)
   if eMTtXKOdwzpuWImkEFqiAGHrLPgQYJ==401:
    if os.path.isfile(eMTtXKOdwzpuWImkEFqiAGHrLPgQhY):os.remove(eMTtXKOdwzpuWImkEFqiAGHrLPgQhY)
    eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.login_main()
    eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.dp_EventLiveChannel_List(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.main_params)
  elif eMTtXKOdwzpuWImkEFqiAGHrLPgQJC in['LIVE','GAME_VOD','POP_VOD','ELIVE']:
   eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.play_VIDEO(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.main_params)
  elif eMTtXKOdwzpuWImkEFqiAGHrLPgQJC=='VOD_GROUP':
   eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.dp_MainLeague_List(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.main_params)
  elif eMTtXKOdwzpuWImkEFqiAGHrLPgQJC=='POP_GROUP':
   eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.dp_PopVod_GroupList(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.main_params)
  elif eMTtXKOdwzpuWImkEFqiAGHrLPgQJC=='LEAGUE_GROUP':
   eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.dp_Season_List(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.main_params)
  elif eMTtXKOdwzpuWImkEFqiAGHrLPgQJC=='SEASON_GROUP':
   eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.dp_Game_List(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.main_params)
  elif eMTtXKOdwzpuWImkEFqiAGHrLPgQJC=='GAME_VOD_GROUP':
   eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.dp_GameVod_List(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.main_params)
  elif eMTtXKOdwzpuWImkEFqiAGHrLPgQJC=='WATCH':
   eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.dp_Watch_List(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.main_params)
  elif eMTtXKOdwzpuWImkEFqiAGHrLPgQJC=='MYVIEW_REMOVE':
   eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.dp_WatchList_Delete(eMTtXKOdwzpuWImkEFqiAGHrLPgQhJ.main_params)
  else:
   eMTtXKOdwzpuWImkEFqiAGHrLPgQJx
# Created by pyminifier (https://github.com/liftoff/pyminifier)
