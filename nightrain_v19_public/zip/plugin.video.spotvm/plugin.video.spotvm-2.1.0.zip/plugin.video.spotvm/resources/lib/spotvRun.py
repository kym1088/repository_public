__author__="NightRain"
HMcuKDXxeaFCOYUQtWBpilsJkEbhTv=object
HMcuKDXxeaFCOYUQtWBpilsJkEbhTm=None
HMcuKDXxeaFCOYUQtWBpilsJkEbhTL=True
HMcuKDXxeaFCOYUQtWBpilsJkEbhTN=int
HMcuKDXxeaFCOYUQtWBpilsJkEbhTP=False
HMcuKDXxeaFCOYUQtWBpilsJkEbhTA=len
HMcuKDXxeaFCOYUQtWBpilsJkEbhTI=str
HMcuKDXxeaFCOYUQtWBpilsJkEbhTj=open
HMcuKDXxeaFCOYUQtWBpilsJkEbhTg=Exception
HMcuKDXxeaFCOYUQtWBpilsJkEbhTy=print
HMcuKDXxeaFCOYUQtWBpilsJkEbhTR=dict
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
HMcuKDXxeaFCOYUQtWBpilsJkEbhoS=[{'title':'TV 채널','mode':'LIVE_GROUP'},{'title':'Live중계 (독점,현지)','mode':'ELIVE_GROUP'},{'title':'-----------------','mode':'XXX'},{'title':'인기영상5','mode':'POP_GROUP'},{'title':'VOD 영상','mode':'VOD_GROUP'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH'}]
HMcuKDXxeaFCOYUQtWBpilsJkEbhov ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
HMcuKDXxeaFCOYUQtWBpilsJkEbhoT=xbmcvfs.translatePath(os.path.join(__profile__,'spotv_cookies.json'))
from spotvCore import*
class HMcuKDXxeaFCOYUQtWBpilsJkEbhoG(HMcuKDXxeaFCOYUQtWBpilsJkEbhTv):
 def __init__(HMcuKDXxeaFCOYUQtWBpilsJkEbhom,HMcuKDXxeaFCOYUQtWBpilsJkEbhoL,HMcuKDXxeaFCOYUQtWBpilsJkEbhoN,HMcuKDXxeaFCOYUQtWBpilsJkEbhoP):
  HMcuKDXxeaFCOYUQtWBpilsJkEbhom._addon_url =HMcuKDXxeaFCOYUQtWBpilsJkEbhoL
  HMcuKDXxeaFCOYUQtWBpilsJkEbhom._addon_handle=HMcuKDXxeaFCOYUQtWBpilsJkEbhoN
  HMcuKDXxeaFCOYUQtWBpilsJkEbhom.main_params =HMcuKDXxeaFCOYUQtWBpilsJkEbhoP
  HMcuKDXxeaFCOYUQtWBpilsJkEbhom.SpotvObj =CsunNxhvXFyrweDVMYEbWmIUakotlJ() 
 def addon_noti(HMcuKDXxeaFCOYUQtWBpilsJkEbhom,sting):
  try:
   HMcuKDXxeaFCOYUQtWBpilsJkEbhoI=xbmcgui.Dialog()
   HMcuKDXxeaFCOYUQtWBpilsJkEbhoI.notification(__addonname__,sting)
  except:
   HMcuKDXxeaFCOYUQtWBpilsJkEbhTm
 def addon_log(HMcuKDXxeaFCOYUQtWBpilsJkEbhom,string):
  try:
   HMcuKDXxeaFCOYUQtWBpilsJkEbhoj=string.encode('utf-8','ignore')
  except:
   HMcuKDXxeaFCOYUQtWBpilsJkEbhoj='addonException: addon_log'
  HMcuKDXxeaFCOYUQtWBpilsJkEbhog=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,HMcuKDXxeaFCOYUQtWBpilsJkEbhoj),level=HMcuKDXxeaFCOYUQtWBpilsJkEbhog)
 def get_keyboard_input(HMcuKDXxeaFCOYUQtWBpilsJkEbhom,HMcuKDXxeaFCOYUQtWBpilsJkEbhoq):
  HMcuKDXxeaFCOYUQtWBpilsJkEbhoy=HMcuKDXxeaFCOYUQtWBpilsJkEbhTm
  kb=xbmc.Keyboard()
  kb.setHeading(HMcuKDXxeaFCOYUQtWBpilsJkEbhoq)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   HMcuKDXxeaFCOYUQtWBpilsJkEbhoy=kb.getText()
  return HMcuKDXxeaFCOYUQtWBpilsJkEbhoy
 def get_settings_login_info(HMcuKDXxeaFCOYUQtWBpilsJkEbhom):
  HMcuKDXxeaFCOYUQtWBpilsJkEbhoR =__addon__.getSetting('id')
  HMcuKDXxeaFCOYUQtWBpilsJkEbhoz =__addon__.getSetting('pw')
  return(HMcuKDXxeaFCOYUQtWBpilsJkEbhoR,HMcuKDXxeaFCOYUQtWBpilsJkEbhoz)
 def set_winCredential(HMcuKDXxeaFCOYUQtWBpilsJkEbhom,credential):
  HMcuKDXxeaFCOYUQtWBpilsJkEbhow=xbmcgui.Window(10000)
  HMcuKDXxeaFCOYUQtWBpilsJkEbhow.setProperty('SPOTV_M_SESSIONID',credential.get('spotv_sessionid'))
  HMcuKDXxeaFCOYUQtWBpilsJkEbhow.setProperty('SPOTV_M_SESSION',credential.get('spotv_session'))
  HMcuKDXxeaFCOYUQtWBpilsJkEbhow.setProperty('SPOTV_M_ACCOUNTID',credential.get('spotv_accountId'))
  HMcuKDXxeaFCOYUQtWBpilsJkEbhow.setProperty('SPOTV_M_POLICYKEY',credential.get('spotv_policyKey'))
  HMcuKDXxeaFCOYUQtWBpilsJkEbhow.setProperty('SPOTV_M_SUBEND',credential.get('spotv_subend'))
  HMcuKDXxeaFCOYUQtWBpilsJkEbhow.setProperty('SPOTV_M_LOGINTIME',HMcuKDXxeaFCOYUQtWBpilsJkEbhom.SpotvObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(HMcuKDXxeaFCOYUQtWBpilsJkEbhom):
  HMcuKDXxeaFCOYUQtWBpilsJkEbhow=xbmcgui.Window(10000)
  HMcuKDXxeaFCOYUQtWBpilsJkEbhof={'spotv_sessionid':HMcuKDXxeaFCOYUQtWBpilsJkEbhow.getProperty('SPOTV_M_SESSIONID'),'spotv_session':HMcuKDXxeaFCOYUQtWBpilsJkEbhow.getProperty('SPOTV_M_SESSION'),'spotv_accountId':HMcuKDXxeaFCOYUQtWBpilsJkEbhow.getProperty('SPOTV_M_ACCOUNTID'),'spotv_policyKey':HMcuKDXxeaFCOYUQtWBpilsJkEbhow.getProperty('SPOTV_M_POLICYKEY'),'spotv_subend':HMcuKDXxeaFCOYUQtWBpilsJkEbhow.getProperty('SPOTV_M_SUBEND')}
  return HMcuKDXxeaFCOYUQtWBpilsJkEbhof
 def add_dir(HMcuKDXxeaFCOYUQtWBpilsJkEbhom,label,sublabel='',img='',infoLabels=HMcuKDXxeaFCOYUQtWBpilsJkEbhTm,isFolder=HMcuKDXxeaFCOYUQtWBpilsJkEbhTL,params=''):
  HMcuKDXxeaFCOYUQtWBpilsJkEbhod='%s?%s'%(HMcuKDXxeaFCOYUQtWBpilsJkEbhom._addon_url,urllib.parse.urlencode(params))
  if sublabel:HMcuKDXxeaFCOYUQtWBpilsJkEbhoq='%s < %s >'%(label,sublabel)
  else: HMcuKDXxeaFCOYUQtWBpilsJkEbhoq=label
  if not img:img='DefaultFolder.png'
  HMcuKDXxeaFCOYUQtWBpilsJkEbhor=xbmcgui.ListItem(HMcuKDXxeaFCOYUQtWBpilsJkEbhoq)
  HMcuKDXxeaFCOYUQtWBpilsJkEbhor.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:HMcuKDXxeaFCOYUQtWBpilsJkEbhor.setInfo(type="Video",infoLabels=infoLabels)
  if not isFolder:HMcuKDXxeaFCOYUQtWBpilsJkEbhor.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(HMcuKDXxeaFCOYUQtWBpilsJkEbhom._addon_handle,HMcuKDXxeaFCOYUQtWBpilsJkEbhod,HMcuKDXxeaFCOYUQtWBpilsJkEbhor,isFolder)
 def get_selQuality(HMcuKDXxeaFCOYUQtWBpilsJkEbhom,etype):
  try:
   HMcuKDXxeaFCOYUQtWBpilsJkEbhoV='selected_quality'
   HMcuKDXxeaFCOYUQtWBpilsJkEbhon=[1080,720,540]
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGo=HMcuKDXxeaFCOYUQtWBpilsJkEbhTN(__addon__.getSetting(HMcuKDXxeaFCOYUQtWBpilsJkEbhoV))
   return HMcuKDXxeaFCOYUQtWBpilsJkEbhon[HMcuKDXxeaFCOYUQtWBpilsJkEbhGo]
  except:
   HMcuKDXxeaFCOYUQtWBpilsJkEbhTm
  return 1080 
 def dp_Main_List(HMcuKDXxeaFCOYUQtWBpilsJkEbhom):
  for HMcuKDXxeaFCOYUQtWBpilsJkEbhGS in HMcuKDXxeaFCOYUQtWBpilsJkEbhoS:
   HMcuKDXxeaFCOYUQtWBpilsJkEbhoq=HMcuKDXxeaFCOYUQtWBpilsJkEbhGS.get('title')
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGv={'mode':HMcuKDXxeaFCOYUQtWBpilsJkEbhGS.get('mode')}
   if HMcuKDXxeaFCOYUQtWBpilsJkEbhGS.get('mode')=='XXX':
    HMcuKDXxeaFCOYUQtWBpilsJkEbhGT=HMcuKDXxeaFCOYUQtWBpilsJkEbhTP
   else:
    HMcuKDXxeaFCOYUQtWBpilsJkEbhGT=HMcuKDXxeaFCOYUQtWBpilsJkEbhTL
   HMcuKDXxeaFCOYUQtWBpilsJkEbhom.add_dir(HMcuKDXxeaFCOYUQtWBpilsJkEbhoq,sublabel='',img='',infoLabels=HMcuKDXxeaFCOYUQtWBpilsJkEbhTm,isFolder=HMcuKDXxeaFCOYUQtWBpilsJkEbhGT,params=HMcuKDXxeaFCOYUQtWBpilsJkEbhGv)
  if HMcuKDXxeaFCOYUQtWBpilsJkEbhTA(HMcuKDXxeaFCOYUQtWBpilsJkEbhoS)>0:xbmcplugin.endOfDirectory(HMcuKDXxeaFCOYUQtWBpilsJkEbhom._addon_handle)
 def dp_MainLeague_List(HMcuKDXxeaFCOYUQtWBpilsJkEbhom,args):
  HMcuKDXxeaFCOYUQtWBpilsJkEbhom.SpotvObj.SaveCredential(HMcuKDXxeaFCOYUQtWBpilsJkEbhom.get_winCredential())
  HMcuKDXxeaFCOYUQtWBpilsJkEbhGL=HMcuKDXxeaFCOYUQtWBpilsJkEbhom.SpotvObj.GetTitleGroupList()
  for HMcuKDXxeaFCOYUQtWBpilsJkEbhGN in HMcuKDXxeaFCOYUQtWBpilsJkEbhGL:
   HMcuKDXxeaFCOYUQtWBpilsJkEbhoq =HMcuKDXxeaFCOYUQtWBpilsJkEbhGN.get('title')
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGP =HMcuKDXxeaFCOYUQtWBpilsJkEbhGN.get('logo')
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGA =HMcuKDXxeaFCOYUQtWBpilsJkEbhGN.get('reagueId')
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGI =HMcuKDXxeaFCOYUQtWBpilsJkEbhGN.get('subGame')
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGj=HMcuKDXxeaFCOYUQtWBpilsJkEbhGN.get('info')
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGj['plot']='%s\n\n%s'%(HMcuKDXxeaFCOYUQtWBpilsJkEbhoq,HMcuKDXxeaFCOYUQtWBpilsJkEbhGI)
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGv={'mode':'LEAGUE_GROUP','reagueId':HMcuKDXxeaFCOYUQtWBpilsJkEbhGA}
   HMcuKDXxeaFCOYUQtWBpilsJkEbhom.add_dir(HMcuKDXxeaFCOYUQtWBpilsJkEbhoq,sublabel=HMcuKDXxeaFCOYUQtWBpilsJkEbhTm,img=HMcuKDXxeaFCOYUQtWBpilsJkEbhGP,infoLabels=HMcuKDXxeaFCOYUQtWBpilsJkEbhGj,isFolder=HMcuKDXxeaFCOYUQtWBpilsJkEbhTL,params=HMcuKDXxeaFCOYUQtWBpilsJkEbhGv)
  if HMcuKDXxeaFCOYUQtWBpilsJkEbhTA(HMcuKDXxeaFCOYUQtWBpilsJkEbhGL)>0:xbmcplugin.endOfDirectory(HMcuKDXxeaFCOYUQtWBpilsJkEbhom._addon_handle,cacheToDisc=HMcuKDXxeaFCOYUQtWBpilsJkEbhTP)
 def dp_PopVod_GroupList(HMcuKDXxeaFCOYUQtWBpilsJkEbhom,args):
  HMcuKDXxeaFCOYUQtWBpilsJkEbhom.SpotvObj.SaveCredential(HMcuKDXxeaFCOYUQtWBpilsJkEbhom.get_winCredential())
  HMcuKDXxeaFCOYUQtWBpilsJkEbhGL=HMcuKDXxeaFCOYUQtWBpilsJkEbhom.SpotvObj.GetPopularGroupList()
  for HMcuKDXxeaFCOYUQtWBpilsJkEbhGN in HMcuKDXxeaFCOYUQtWBpilsJkEbhGL:
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGg =HMcuKDXxeaFCOYUQtWBpilsJkEbhGN.get('vodTitle')
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGy =HMcuKDXxeaFCOYUQtWBpilsJkEbhGN.get('vodId')
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGR =HMcuKDXxeaFCOYUQtWBpilsJkEbhGN.get('vodType')
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGP=HMcuKDXxeaFCOYUQtWBpilsJkEbhGN.get('thumbnail')
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGz =HMcuKDXxeaFCOYUQtWBpilsJkEbhGN.get('vtypeId')
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGj=HMcuKDXxeaFCOYUQtWBpilsJkEbhGN.get('info')
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGj['plot']=HMcuKDXxeaFCOYUQtWBpilsJkEbhGg
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGv={'mode':'POP_VOD','mediacode':HMcuKDXxeaFCOYUQtWBpilsJkEbhGy,'mediatype':'vod','vtypeId':HMcuKDXxeaFCOYUQtWBpilsJkEbhGz}
   HMcuKDXxeaFCOYUQtWBpilsJkEbhom.add_dir(HMcuKDXxeaFCOYUQtWBpilsJkEbhGg,sublabel=HMcuKDXxeaFCOYUQtWBpilsJkEbhGR,img=HMcuKDXxeaFCOYUQtWBpilsJkEbhGP,infoLabels=HMcuKDXxeaFCOYUQtWBpilsJkEbhGj,isFolder=HMcuKDXxeaFCOYUQtWBpilsJkEbhTP,params=HMcuKDXxeaFCOYUQtWBpilsJkEbhGv)
  if HMcuKDXxeaFCOYUQtWBpilsJkEbhTA(HMcuKDXxeaFCOYUQtWBpilsJkEbhGL)>0:xbmcplugin.endOfDirectory(HMcuKDXxeaFCOYUQtWBpilsJkEbhom._addon_handle,cacheToDisc=HMcuKDXxeaFCOYUQtWBpilsJkEbhTP)
 def dp_Season_List(HMcuKDXxeaFCOYUQtWBpilsJkEbhom,args):
  HMcuKDXxeaFCOYUQtWBpilsJkEbhom.SpotvObj.SaveCredential(HMcuKDXxeaFCOYUQtWBpilsJkEbhom.get_winCredential())
  HMcuKDXxeaFCOYUQtWBpilsJkEbhGA=args.get('reagueId')
  HMcuKDXxeaFCOYUQtWBpilsJkEbhGL=HMcuKDXxeaFCOYUQtWBpilsJkEbhom.SpotvObj.GetSeasonList(HMcuKDXxeaFCOYUQtWBpilsJkEbhGA)
  for HMcuKDXxeaFCOYUQtWBpilsJkEbhGN in HMcuKDXxeaFCOYUQtWBpilsJkEbhGL:
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGw =HMcuKDXxeaFCOYUQtWBpilsJkEbhGN.get('reagueName')
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGf =HMcuKDXxeaFCOYUQtWBpilsJkEbhGN.get('gameTypeId')
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGd =HMcuKDXxeaFCOYUQtWBpilsJkEbhGN.get('seasonName')
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGq =HMcuKDXxeaFCOYUQtWBpilsJkEbhGN.get('seasonId')
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGj=HMcuKDXxeaFCOYUQtWBpilsJkEbhGN.get('info')
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGj['plot']='%s - %s'%(HMcuKDXxeaFCOYUQtWBpilsJkEbhGw,HMcuKDXxeaFCOYUQtWBpilsJkEbhGd)
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGv={'mode':'SEASON_GROUP','reagueId':HMcuKDXxeaFCOYUQtWBpilsJkEbhGA,'seasonId':HMcuKDXxeaFCOYUQtWBpilsJkEbhGq,'gameTypeId':HMcuKDXxeaFCOYUQtWBpilsJkEbhGf,'page':'1'}
   HMcuKDXxeaFCOYUQtWBpilsJkEbhom.add_dir(HMcuKDXxeaFCOYUQtWBpilsJkEbhGw,sublabel=HMcuKDXxeaFCOYUQtWBpilsJkEbhGd,img='',infoLabels=HMcuKDXxeaFCOYUQtWBpilsJkEbhGj,isFolder=HMcuKDXxeaFCOYUQtWBpilsJkEbhTL,params=HMcuKDXxeaFCOYUQtWBpilsJkEbhGv)
  if HMcuKDXxeaFCOYUQtWBpilsJkEbhTA(HMcuKDXxeaFCOYUQtWBpilsJkEbhGL)>0:xbmcplugin.endOfDirectory(HMcuKDXxeaFCOYUQtWBpilsJkEbhom._addon_handle,cacheToDisc=HMcuKDXxeaFCOYUQtWBpilsJkEbhTL)
 def dp_Game_List(HMcuKDXxeaFCOYUQtWBpilsJkEbhom,args):
  HMcuKDXxeaFCOYUQtWBpilsJkEbhom.SpotvObj.SaveCredential(HMcuKDXxeaFCOYUQtWBpilsJkEbhom.get_winCredential())
  HMcuKDXxeaFCOYUQtWBpilsJkEbhGf=args.get('gameTypeId')
  HMcuKDXxeaFCOYUQtWBpilsJkEbhGA =args.get('reagueId')
  HMcuKDXxeaFCOYUQtWBpilsJkEbhGq =args.get('seasonId')
  HMcuKDXxeaFCOYUQtWBpilsJkEbhGr =HMcuKDXxeaFCOYUQtWBpilsJkEbhTN(args.get('page'))
  HMcuKDXxeaFCOYUQtWBpilsJkEbhGL,HMcuKDXxeaFCOYUQtWBpilsJkEbhGV=HMcuKDXxeaFCOYUQtWBpilsJkEbhom.SpotvObj.GetGameList(HMcuKDXxeaFCOYUQtWBpilsJkEbhGf,HMcuKDXxeaFCOYUQtWBpilsJkEbhGA,HMcuKDXxeaFCOYUQtWBpilsJkEbhGq,HMcuKDXxeaFCOYUQtWBpilsJkEbhGr)
  for HMcuKDXxeaFCOYUQtWBpilsJkEbhGN in HMcuKDXxeaFCOYUQtWBpilsJkEbhGL:
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGn =HMcuKDXxeaFCOYUQtWBpilsJkEbhGN.get('gameTitle')
   HMcuKDXxeaFCOYUQtWBpilsJkEbhSo =HMcuKDXxeaFCOYUQtWBpilsJkEbhGN.get('beginDate')
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGP =HMcuKDXxeaFCOYUQtWBpilsJkEbhGN.get('thumbnail')
   HMcuKDXxeaFCOYUQtWBpilsJkEbhSG =HMcuKDXxeaFCOYUQtWBpilsJkEbhGN.get('gameId')
   HMcuKDXxeaFCOYUQtWBpilsJkEbhSv =HMcuKDXxeaFCOYUQtWBpilsJkEbhGN.get('totVodCnt')
   HMcuKDXxeaFCOYUQtWBpilsJkEbhST =HMcuKDXxeaFCOYUQtWBpilsJkEbhGN.get('leaguenm')
   HMcuKDXxeaFCOYUQtWBpilsJkEbhSm =HMcuKDXxeaFCOYUQtWBpilsJkEbhGN.get('seasonnm')
   HMcuKDXxeaFCOYUQtWBpilsJkEbhSL =HMcuKDXxeaFCOYUQtWBpilsJkEbhGN.get('roundnm')
   HMcuKDXxeaFCOYUQtWBpilsJkEbhSN ='%s < %s >'%(HMcuKDXxeaFCOYUQtWBpilsJkEbhGn,HMcuKDXxeaFCOYUQtWBpilsJkEbhSo)
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGj=HMcuKDXxeaFCOYUQtWBpilsJkEbhGN.get('info')
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGv={'mode':'GAME_VOD_GROUP' if HMcuKDXxeaFCOYUQtWBpilsJkEbhSv!=0 else 'XXX','saveTitle':HMcuKDXxeaFCOYUQtWBpilsJkEbhSN,'saveImg':HMcuKDXxeaFCOYUQtWBpilsJkEbhGP,'saveInfo':HMcuKDXxeaFCOYUQtWBpilsJkEbhGj['plot'],'gameid':HMcuKDXxeaFCOYUQtWBpilsJkEbhSG}
   HMcuKDXxeaFCOYUQtWBpilsJkEbhom.add_dir(HMcuKDXxeaFCOYUQtWBpilsJkEbhGn,sublabel=HMcuKDXxeaFCOYUQtWBpilsJkEbhSo,img=HMcuKDXxeaFCOYUQtWBpilsJkEbhGP,infoLabels=HMcuKDXxeaFCOYUQtWBpilsJkEbhGj,isFolder=HMcuKDXxeaFCOYUQtWBpilsJkEbhTL,params=HMcuKDXxeaFCOYUQtWBpilsJkEbhGv)
  if HMcuKDXxeaFCOYUQtWBpilsJkEbhGV:
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGv['mode'] ='SEASON_GROUP' 
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGv['reagueId'] =HMcuKDXxeaFCOYUQtWBpilsJkEbhGA
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGv['seasonId'] =HMcuKDXxeaFCOYUQtWBpilsJkEbhGq
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGv['gameTypeId']=HMcuKDXxeaFCOYUQtWBpilsJkEbhGf
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGv['page'] =HMcuKDXxeaFCOYUQtWBpilsJkEbhTI(HMcuKDXxeaFCOYUQtWBpilsJkEbhGr+1)
   HMcuKDXxeaFCOYUQtWBpilsJkEbhoq='[B]%s >>[/B]'%'다음 페이지'
   HMcuKDXxeaFCOYUQtWBpilsJkEbhSP=HMcuKDXxeaFCOYUQtWBpilsJkEbhTI(HMcuKDXxeaFCOYUQtWBpilsJkEbhGr+1)
   HMcuKDXxeaFCOYUQtWBpilsJkEbhom.add_dir(HMcuKDXxeaFCOYUQtWBpilsJkEbhoq,sublabel=HMcuKDXxeaFCOYUQtWBpilsJkEbhSP,img='',infoLabels=HMcuKDXxeaFCOYUQtWBpilsJkEbhTm,isFolder=HMcuKDXxeaFCOYUQtWBpilsJkEbhTL,params=HMcuKDXxeaFCOYUQtWBpilsJkEbhGv)
  if HMcuKDXxeaFCOYUQtWBpilsJkEbhTA(HMcuKDXxeaFCOYUQtWBpilsJkEbhGL)>0:xbmcplugin.endOfDirectory(HMcuKDXxeaFCOYUQtWBpilsJkEbhom._addon_handle,cacheToDisc=HMcuKDXxeaFCOYUQtWBpilsJkEbhTP)
 def dp_GameVod_List(HMcuKDXxeaFCOYUQtWBpilsJkEbhom,args):
  HMcuKDXxeaFCOYUQtWBpilsJkEbhom.SpotvObj.SaveCredential(HMcuKDXxeaFCOYUQtWBpilsJkEbhom.get_winCredential())
  HMcuKDXxeaFCOYUQtWBpilsJkEbhSA =args.get('gameid')
  HMcuKDXxeaFCOYUQtWBpilsJkEbhSN=args.get('saveTitle')
  HMcuKDXxeaFCOYUQtWBpilsJkEbhSI =args.get('saveImg')
  HMcuKDXxeaFCOYUQtWBpilsJkEbhSj =args.get('saveInfo')
  HMcuKDXxeaFCOYUQtWBpilsJkEbhGL=HMcuKDXxeaFCOYUQtWBpilsJkEbhom.SpotvObj.GetGameVodList(HMcuKDXxeaFCOYUQtWBpilsJkEbhSA)
  for HMcuKDXxeaFCOYUQtWBpilsJkEbhGN in HMcuKDXxeaFCOYUQtWBpilsJkEbhGL:
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGg =HMcuKDXxeaFCOYUQtWBpilsJkEbhGN.get('vodTitle')
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGy =HMcuKDXxeaFCOYUQtWBpilsJkEbhGN.get('vodId')
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGR =HMcuKDXxeaFCOYUQtWBpilsJkEbhGN.get('vodType')
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGP=HMcuKDXxeaFCOYUQtWBpilsJkEbhGN.get('thumbnail')
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGz =HMcuKDXxeaFCOYUQtWBpilsJkEbhGN.get('vtypeId')
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGj=HMcuKDXxeaFCOYUQtWBpilsJkEbhGN.get('info')
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGj['plot']='%s \n\n %s'%(HMcuKDXxeaFCOYUQtWBpilsJkEbhGg,HMcuKDXxeaFCOYUQtWBpilsJkEbhSj)
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGv={'mode':'GAME_VOD','saveTitle':HMcuKDXxeaFCOYUQtWBpilsJkEbhSN,'saveImg':HMcuKDXxeaFCOYUQtWBpilsJkEbhSI,'saveId':HMcuKDXxeaFCOYUQtWBpilsJkEbhSA,'saveInfo':HMcuKDXxeaFCOYUQtWBpilsJkEbhSj,'mediacode':HMcuKDXxeaFCOYUQtWBpilsJkEbhGy,'mediatype':'vod','vtypeId':HMcuKDXxeaFCOYUQtWBpilsJkEbhGz}
   HMcuKDXxeaFCOYUQtWBpilsJkEbhom.add_dir(HMcuKDXxeaFCOYUQtWBpilsJkEbhGg,sublabel=HMcuKDXxeaFCOYUQtWBpilsJkEbhGR,img=HMcuKDXxeaFCOYUQtWBpilsJkEbhGP,infoLabels=HMcuKDXxeaFCOYUQtWBpilsJkEbhGj,isFolder=HMcuKDXxeaFCOYUQtWBpilsJkEbhTP,params=HMcuKDXxeaFCOYUQtWBpilsJkEbhGv)
  if HMcuKDXxeaFCOYUQtWBpilsJkEbhTA(HMcuKDXxeaFCOYUQtWBpilsJkEbhGL)>0:xbmcplugin.endOfDirectory(HMcuKDXxeaFCOYUQtWBpilsJkEbhom._addon_handle,cacheToDisc=HMcuKDXxeaFCOYUQtWBpilsJkEbhTP)
 def login_main(HMcuKDXxeaFCOYUQtWBpilsJkEbhom):
  (HMcuKDXxeaFCOYUQtWBpilsJkEbhSg,HMcuKDXxeaFCOYUQtWBpilsJkEbhSy)=HMcuKDXxeaFCOYUQtWBpilsJkEbhom.get_settings_login_info()
  if not(HMcuKDXxeaFCOYUQtWBpilsJkEbhSg and HMcuKDXxeaFCOYUQtWBpilsJkEbhSy):
   HMcuKDXxeaFCOYUQtWBpilsJkEbhoI=xbmcgui.Dialog()
   HMcuKDXxeaFCOYUQtWBpilsJkEbhSR=HMcuKDXxeaFCOYUQtWBpilsJkEbhoI.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if HMcuKDXxeaFCOYUQtWBpilsJkEbhSR==HMcuKDXxeaFCOYUQtWBpilsJkEbhTL:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if HMcuKDXxeaFCOYUQtWBpilsJkEbhom.cookiefile_check():return
  HMcuKDXxeaFCOYUQtWBpilsJkEbhSz =HMcuKDXxeaFCOYUQtWBpilsJkEbhTN(HMcuKDXxeaFCOYUQtWBpilsJkEbhom.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))
  HMcuKDXxeaFCOYUQtWBpilsJkEbhSw=xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINTIME')
  if HMcuKDXxeaFCOYUQtWBpilsJkEbhSw==HMcuKDXxeaFCOYUQtWBpilsJkEbhTm or HMcuKDXxeaFCOYUQtWBpilsJkEbhSw=='':
   HMcuKDXxeaFCOYUQtWBpilsJkEbhSw=HMcuKDXxeaFCOYUQtWBpilsJkEbhTN('19000101')
  else:
   HMcuKDXxeaFCOYUQtWBpilsJkEbhSw=HMcuKDXxeaFCOYUQtWBpilsJkEbhTN(re.sub('-','',HMcuKDXxeaFCOYUQtWBpilsJkEbhSw))
  if xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINWAIT')=='TRUE':
   HMcuKDXxeaFCOYUQtWBpilsJkEbhSf=0
   while HMcuKDXxeaFCOYUQtWBpilsJkEbhTL:
    HMcuKDXxeaFCOYUQtWBpilsJkEbhSf+=1
    time.sleep(0.05)
    if HMcuKDXxeaFCOYUQtWBpilsJkEbhSw>=HMcuKDXxeaFCOYUQtWBpilsJkEbhSz:return
    if HMcuKDXxeaFCOYUQtWBpilsJkEbhSf>600:return
  else:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','TRUE')
  if HMcuKDXxeaFCOYUQtWBpilsJkEbhSw>=HMcuKDXxeaFCOYUQtWBpilsJkEbhSz:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
   return
  if not HMcuKDXxeaFCOYUQtWBpilsJkEbhom.SpotvObj.GetCredential(HMcuKDXxeaFCOYUQtWBpilsJkEbhSg,HMcuKDXxeaFCOYUQtWBpilsJkEbhSy):
   HMcuKDXxeaFCOYUQtWBpilsJkEbhom.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
   sys.exit()
  HMcuKDXxeaFCOYUQtWBpilsJkEbhom.set_winCredential(HMcuKDXxeaFCOYUQtWBpilsJkEbhom.SpotvObj.LoadCredential())
  HMcuKDXxeaFCOYUQtWBpilsJkEbhom.cookiefile_save()
  xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
 def dp_LiveChannel_List(HMcuKDXxeaFCOYUQtWBpilsJkEbhom,args):
  HMcuKDXxeaFCOYUQtWBpilsJkEbhom.SpotvObj.SaveCredential(HMcuKDXxeaFCOYUQtWBpilsJkEbhom.get_winCredential())
  HMcuKDXxeaFCOYUQtWBpilsJkEbhSd=HMcuKDXxeaFCOYUQtWBpilsJkEbhom.SpotvObj.GetLiveChannelList()
  for HMcuKDXxeaFCOYUQtWBpilsJkEbhSq in HMcuKDXxeaFCOYUQtWBpilsJkEbhSd:
   HMcuKDXxeaFCOYUQtWBpilsJkEbhoq =HMcuKDXxeaFCOYUQtWBpilsJkEbhSq.get('name')
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGm =HMcuKDXxeaFCOYUQtWBpilsJkEbhSq.get('programName')
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGP =HMcuKDXxeaFCOYUQtWBpilsJkEbhSq.get('logo')
   HMcuKDXxeaFCOYUQtWBpilsJkEbhSr=HMcuKDXxeaFCOYUQtWBpilsJkEbhSq.get('channelepg')
   HMcuKDXxeaFCOYUQtWBpilsJkEbhSV =HMcuKDXxeaFCOYUQtWBpilsJkEbhSq.get('free')
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGj=HMcuKDXxeaFCOYUQtWBpilsJkEbhSq.get('info')
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGj['plot']='%s'%(HMcuKDXxeaFCOYUQtWBpilsJkEbhSr)
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGv={'mode':'LIVE','mediaid':HMcuKDXxeaFCOYUQtWBpilsJkEbhSq.get('id'),'mediacode':HMcuKDXxeaFCOYUQtWBpilsJkEbhSq.get('videoId'),'free':HMcuKDXxeaFCOYUQtWBpilsJkEbhSV,'mediatype':'live'}
   if HMcuKDXxeaFCOYUQtWBpilsJkEbhSV:HMcuKDXxeaFCOYUQtWBpilsJkEbhoq+=' [free]'
   HMcuKDXxeaFCOYUQtWBpilsJkEbhom.add_dir(HMcuKDXxeaFCOYUQtWBpilsJkEbhoq,sublabel=HMcuKDXxeaFCOYUQtWBpilsJkEbhGm,img=HMcuKDXxeaFCOYUQtWBpilsJkEbhGP,infoLabels=HMcuKDXxeaFCOYUQtWBpilsJkEbhGj,isFolder=HMcuKDXxeaFCOYUQtWBpilsJkEbhTP,params=HMcuKDXxeaFCOYUQtWBpilsJkEbhGv)
  if HMcuKDXxeaFCOYUQtWBpilsJkEbhTA(HMcuKDXxeaFCOYUQtWBpilsJkEbhSd)>0:xbmcplugin.endOfDirectory(HMcuKDXxeaFCOYUQtWBpilsJkEbhom._addon_handle,cacheToDisc=HMcuKDXxeaFCOYUQtWBpilsJkEbhTP)
 def dp_EventLiveChannel_List(HMcuKDXxeaFCOYUQtWBpilsJkEbhom,args):
  HMcuKDXxeaFCOYUQtWBpilsJkEbhom.SpotvObj.SaveCredential(HMcuKDXxeaFCOYUQtWBpilsJkEbhom.get_winCredential())
  HMcuKDXxeaFCOYUQtWBpilsJkEbhSd,HMcuKDXxeaFCOYUQtWBpilsJkEbhSn=HMcuKDXxeaFCOYUQtWBpilsJkEbhom.SpotvObj.GetEventLiveList()
  if HMcuKDXxeaFCOYUQtWBpilsJkEbhSn!=401 and HMcuKDXxeaFCOYUQtWBpilsJkEbhTA(HMcuKDXxeaFCOYUQtWBpilsJkEbhSd)==0:
   HMcuKDXxeaFCOYUQtWBpilsJkEbhom.addon_noti(__language__(30907).encode('utf8'))
  for HMcuKDXxeaFCOYUQtWBpilsJkEbhSq in HMcuKDXxeaFCOYUQtWBpilsJkEbhSd:
   HMcuKDXxeaFCOYUQtWBpilsJkEbhoq =HMcuKDXxeaFCOYUQtWBpilsJkEbhSq.get('title')
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGm =HMcuKDXxeaFCOYUQtWBpilsJkEbhSq.get('startTime')
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGP =HMcuKDXxeaFCOYUQtWBpilsJkEbhSq.get('logo')
   HMcuKDXxeaFCOYUQtWBpilsJkEbhSV =HMcuKDXxeaFCOYUQtWBpilsJkEbhSq.get('free')
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGj=HMcuKDXxeaFCOYUQtWBpilsJkEbhSq.get('info')
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGj['plot']='%s\n\n%s'%(HMcuKDXxeaFCOYUQtWBpilsJkEbhoq,HMcuKDXxeaFCOYUQtWBpilsJkEbhGm)
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGv={'mode':'ELIVE','mediaid':HMcuKDXxeaFCOYUQtWBpilsJkEbhSq.get('liveId'),'mediacode':'','free':HMcuKDXxeaFCOYUQtWBpilsJkEbhSV,'mediatype':'live'}
   if HMcuKDXxeaFCOYUQtWBpilsJkEbhSV:HMcuKDXxeaFCOYUQtWBpilsJkEbhoq+=' [free]'
   HMcuKDXxeaFCOYUQtWBpilsJkEbhom.add_dir(HMcuKDXxeaFCOYUQtWBpilsJkEbhoq,sublabel=HMcuKDXxeaFCOYUQtWBpilsJkEbhGm,img=HMcuKDXxeaFCOYUQtWBpilsJkEbhGP,infoLabels=HMcuKDXxeaFCOYUQtWBpilsJkEbhGj,isFolder=HMcuKDXxeaFCOYUQtWBpilsJkEbhTP,params=HMcuKDXxeaFCOYUQtWBpilsJkEbhGv)
  if HMcuKDXxeaFCOYUQtWBpilsJkEbhTA(HMcuKDXxeaFCOYUQtWBpilsJkEbhSd)>0:xbmcplugin.endOfDirectory(HMcuKDXxeaFCOYUQtWBpilsJkEbhom._addon_handle,cacheToDisc=HMcuKDXxeaFCOYUQtWBpilsJkEbhTL)
  return HMcuKDXxeaFCOYUQtWBpilsJkEbhSn
 def play_VIDEO(HMcuKDXxeaFCOYUQtWBpilsJkEbhom,args):
  HMcuKDXxeaFCOYUQtWBpilsJkEbhom.SpotvObj.SaveCredential(HMcuKDXxeaFCOYUQtWBpilsJkEbhom.get_winCredential())
  HMcuKDXxeaFCOYUQtWBpilsJkEbhvo =args.get('mode')
  HMcuKDXxeaFCOYUQtWBpilsJkEbhvG =args.get('mediacode')
  HMcuKDXxeaFCOYUQtWBpilsJkEbhvS =args.get('mediatype')
  HMcuKDXxeaFCOYUQtWBpilsJkEbhGz =args.get('vtypeId')
  if HMcuKDXxeaFCOYUQtWBpilsJkEbhvo=='LIVE':
   if HMcuKDXxeaFCOYUQtWBpilsJkEbhom.SpotvObj.CheckLiveChannel(HMcuKDXxeaFCOYUQtWBpilsJkEbhvG)==HMcuKDXxeaFCOYUQtWBpilsJkEbhTP:
    if HMcuKDXxeaFCOYUQtWBpilsJkEbhom.SpotvObj.CheckSubEnd()==HMcuKDXxeaFCOYUQtWBpilsJkEbhTP:
     HMcuKDXxeaFCOYUQtWBpilsJkEbhom.addon_noti(__language__(30908).encode('utf8'))
     return
  elif HMcuKDXxeaFCOYUQtWBpilsJkEbhvo=='ELIVE':
   if args.get('free')=='False':
    if HMcuKDXxeaFCOYUQtWBpilsJkEbhom.SpotvObj.CheckSubEnd()==HMcuKDXxeaFCOYUQtWBpilsJkEbhTP:
     HMcuKDXxeaFCOYUQtWBpilsJkEbhom.addon_noti(__language__(30908).encode('utf8'))
     return
   HMcuKDXxeaFCOYUQtWBpilsJkEbhvG=HMcuKDXxeaFCOYUQtWBpilsJkEbhom.SpotvObj.GetEventLive_videoId(args.get('mediaid'))
  if HMcuKDXxeaFCOYUQtWBpilsJkEbhvG=='' or HMcuKDXxeaFCOYUQtWBpilsJkEbhvG==HMcuKDXxeaFCOYUQtWBpilsJkEbhTm:
   HMcuKDXxeaFCOYUQtWBpilsJkEbhom.addon_noti(__language__(30907).encode('utf8'))
   return
  HMcuKDXxeaFCOYUQtWBpilsJkEbhvT=HMcuKDXxeaFCOYUQtWBpilsJkEbhom.SpotvObj.GetBroadURL(HMcuKDXxeaFCOYUQtWBpilsJkEbhvG,HMcuKDXxeaFCOYUQtWBpilsJkEbhvS,HMcuKDXxeaFCOYUQtWBpilsJkEbhGz)
  if HMcuKDXxeaFCOYUQtWBpilsJkEbhvT=='':
   HMcuKDXxeaFCOYUQtWBpilsJkEbhom.addon_noti(__language__(30908).encode('utf8'))
   return
  HMcuKDXxeaFCOYUQtWBpilsJkEbhvm=HMcuKDXxeaFCOYUQtWBpilsJkEbhvT
  HMcuKDXxeaFCOYUQtWBpilsJkEbhom.addon_log(HMcuKDXxeaFCOYUQtWBpilsJkEbhvm)
  HMcuKDXxeaFCOYUQtWBpilsJkEbhvL=xbmcgui.ListItem(path=HMcuKDXxeaFCOYUQtWBpilsJkEbhvm)
  xbmcplugin.setResolvedUrl(HMcuKDXxeaFCOYUQtWBpilsJkEbhom._addon_handle,HMcuKDXxeaFCOYUQtWBpilsJkEbhTL,HMcuKDXxeaFCOYUQtWBpilsJkEbhvL)
  try:
   if HMcuKDXxeaFCOYUQtWBpilsJkEbhvS=='vod' and HMcuKDXxeaFCOYUQtWBpilsJkEbhvo!='POP_VOD':
    HMcuKDXxeaFCOYUQtWBpilsJkEbhGv={'code':args.get('saveId'),'img':args.get('saveImg'),'title':args.get('saveTitle'),'info':args.get('saveInfo')}
    HMcuKDXxeaFCOYUQtWBpilsJkEbhom.Save_Watched_List(HMcuKDXxeaFCOYUQtWBpilsJkEbhvS,HMcuKDXxeaFCOYUQtWBpilsJkEbhGv)
  except:
   HMcuKDXxeaFCOYUQtWBpilsJkEbhTm
 def logout(HMcuKDXxeaFCOYUQtWBpilsJkEbhom):
  HMcuKDXxeaFCOYUQtWBpilsJkEbhoI=xbmcgui.Dialog()
  HMcuKDXxeaFCOYUQtWBpilsJkEbhSR=HMcuKDXxeaFCOYUQtWBpilsJkEbhoI.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if HMcuKDXxeaFCOYUQtWBpilsJkEbhSR==HMcuKDXxeaFCOYUQtWBpilsJkEbhTP:sys.exit()
  HMcuKDXxeaFCOYUQtWBpilsJkEbhom.wininfo_clear()
  if os.path.isfile(HMcuKDXxeaFCOYUQtWBpilsJkEbhoT):os.remove(HMcuKDXxeaFCOYUQtWBpilsJkEbhoT)
  HMcuKDXxeaFCOYUQtWBpilsJkEbhom.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(HMcuKDXxeaFCOYUQtWBpilsJkEbhom):
  HMcuKDXxeaFCOYUQtWBpilsJkEbhow=xbmcgui.Window(10000)
  HMcuKDXxeaFCOYUQtWBpilsJkEbhow.setProperty('SPOTV_M_SESSIONID','')
  HMcuKDXxeaFCOYUQtWBpilsJkEbhow.setProperty('SPOTV_M_SESSION','')
  HMcuKDXxeaFCOYUQtWBpilsJkEbhow.setProperty('SPOTV_M_ACCOUNTID','')
  HMcuKDXxeaFCOYUQtWBpilsJkEbhow.setProperty('SPOTV_M_POLICYKEY','')
  HMcuKDXxeaFCOYUQtWBpilsJkEbhow.setProperty('SPOTV_M_SUBEND','')
  HMcuKDXxeaFCOYUQtWBpilsJkEbhow.setProperty('SPOTV_M_LOGINTIME','')
 def cookiefile_save(HMcuKDXxeaFCOYUQtWBpilsJkEbhom):
  HMcuKDXxeaFCOYUQtWBpilsJkEbhvN =HMcuKDXxeaFCOYUQtWBpilsJkEbhom.SpotvObj.Get_Now_Datetime()
  HMcuKDXxeaFCOYUQtWBpilsJkEbhvP=HMcuKDXxeaFCOYUQtWBpilsJkEbhvN+datetime.timedelta(days=HMcuKDXxeaFCOYUQtWBpilsJkEbhTN(__addon__.getSetting('cache_ttl')))
  HMcuKDXxeaFCOYUQtWBpilsJkEbhow=xbmcgui.Window(10000)
  HMcuKDXxeaFCOYUQtWBpilsJkEbhvA={'spotv_sessionid':HMcuKDXxeaFCOYUQtWBpilsJkEbhow.getProperty('SPOTV_M_SESSIONID'),'spotv_session':HMcuKDXxeaFCOYUQtWBpilsJkEbhow.getProperty('SPOTV_M_SESSION'),'spotv_accountId':HMcuKDXxeaFCOYUQtWBpilsJkEbhow.getProperty('SPOTV_M_ACCOUNTID'),'spotv_policyKey':base64.standard_b64encode(HMcuKDXxeaFCOYUQtWBpilsJkEbhow.getProperty('SPOTV_M_POLICYKEY').encode()).decode('utf-8'),'spotv_subend':base64.standard_b64encode((HMcuKDXxeaFCOYUQtWBpilsJkEbhom.SpotvObj.SPOTV_PMCODE+HMcuKDXxeaFCOYUQtWBpilsJkEbhow.getProperty('SPOTV_M_SUBEND')).encode()).decode('utf-8'),'spotv_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'spotv_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'spotv_limitdate':HMcuKDXxeaFCOYUQtWBpilsJkEbhvP.strftime('%Y-%m-%d')}
  try: 
   fp=HMcuKDXxeaFCOYUQtWBpilsJkEbhTj(HMcuKDXxeaFCOYUQtWBpilsJkEbhoT,'w',-1,'utf-8')
   json.dump(HMcuKDXxeaFCOYUQtWBpilsJkEbhvA,fp)
   fp.close()
  except HMcuKDXxeaFCOYUQtWBpilsJkEbhTg as exception:
   HMcuKDXxeaFCOYUQtWBpilsJkEbhTy(exception)
 def cookiefile_check(HMcuKDXxeaFCOYUQtWBpilsJkEbhom):
  HMcuKDXxeaFCOYUQtWBpilsJkEbhvA={}
  try: 
   fp=HMcuKDXxeaFCOYUQtWBpilsJkEbhTj(HMcuKDXxeaFCOYUQtWBpilsJkEbhoT,'r',-1,'utf-8')
   HMcuKDXxeaFCOYUQtWBpilsJkEbhvA= json.load(fp)
   fp.close()
  except HMcuKDXxeaFCOYUQtWBpilsJkEbhTg as exception:
   HMcuKDXxeaFCOYUQtWBpilsJkEbhom.wininfo_clear()
   return HMcuKDXxeaFCOYUQtWBpilsJkEbhTP
  HMcuKDXxeaFCOYUQtWBpilsJkEbhSg =__addon__.getSetting('id')
  HMcuKDXxeaFCOYUQtWBpilsJkEbhSy =__addon__.getSetting('pw')
  HMcuKDXxeaFCOYUQtWBpilsJkEbhvA['spotv_id'] =base64.standard_b64decode(HMcuKDXxeaFCOYUQtWBpilsJkEbhvA['spotv_id']).decode('utf-8')
  HMcuKDXxeaFCOYUQtWBpilsJkEbhvA['spotv_pw'] =base64.standard_b64decode(HMcuKDXxeaFCOYUQtWBpilsJkEbhvA['spotv_pw']).decode('utf-8')
  HMcuKDXxeaFCOYUQtWBpilsJkEbhvA['spotv_policyKey']=base64.standard_b64decode(HMcuKDXxeaFCOYUQtWBpilsJkEbhvA['spotv_policyKey']).decode('utf-8')
  HMcuKDXxeaFCOYUQtWBpilsJkEbhvA['spotv_subend']=base64.standard_b64decode(HMcuKDXxeaFCOYUQtWBpilsJkEbhvA['spotv_subend']).decode('utf-8')[HMcuKDXxeaFCOYUQtWBpilsJkEbhom.SpotvObj.SPOTV_PMSIZE:]
  if HMcuKDXxeaFCOYUQtWBpilsJkEbhSg!=HMcuKDXxeaFCOYUQtWBpilsJkEbhvA['spotv_id']or HMcuKDXxeaFCOYUQtWBpilsJkEbhSy!=HMcuKDXxeaFCOYUQtWBpilsJkEbhvA['spotv_pw']:
   HMcuKDXxeaFCOYUQtWBpilsJkEbhom.wininfo_clear()
   return HMcuKDXxeaFCOYUQtWBpilsJkEbhTP
  HMcuKDXxeaFCOYUQtWBpilsJkEbhSz =HMcuKDXxeaFCOYUQtWBpilsJkEbhTN(HMcuKDXxeaFCOYUQtWBpilsJkEbhom.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))
  HMcuKDXxeaFCOYUQtWBpilsJkEbhvI=HMcuKDXxeaFCOYUQtWBpilsJkEbhvA['spotv_limitdate']
  HMcuKDXxeaFCOYUQtWBpilsJkEbhSw =HMcuKDXxeaFCOYUQtWBpilsJkEbhTN(re.sub('-','',HMcuKDXxeaFCOYUQtWBpilsJkEbhvI))
  if HMcuKDXxeaFCOYUQtWBpilsJkEbhSw<HMcuKDXxeaFCOYUQtWBpilsJkEbhSz:
   HMcuKDXxeaFCOYUQtWBpilsJkEbhom.wininfo_clear()
   return HMcuKDXxeaFCOYUQtWBpilsJkEbhTP
  HMcuKDXxeaFCOYUQtWBpilsJkEbhow=xbmcgui.Window(10000)
  HMcuKDXxeaFCOYUQtWBpilsJkEbhow.setProperty('SPOTV_M_SESSIONID',HMcuKDXxeaFCOYUQtWBpilsJkEbhvA['spotv_sessionid'])
  HMcuKDXxeaFCOYUQtWBpilsJkEbhow.setProperty('SPOTV_M_SESSION',HMcuKDXxeaFCOYUQtWBpilsJkEbhvA['spotv_session'])
  HMcuKDXxeaFCOYUQtWBpilsJkEbhow.setProperty('SPOTV_M_ACCOUNTID',HMcuKDXxeaFCOYUQtWBpilsJkEbhvA['spotv_accountId'])
  HMcuKDXxeaFCOYUQtWBpilsJkEbhow.setProperty('SPOTV_M_POLICYKEY',HMcuKDXxeaFCOYUQtWBpilsJkEbhvA['spotv_policyKey'])
  HMcuKDXxeaFCOYUQtWBpilsJkEbhow.setProperty('SPOTV_M_SUBEND',HMcuKDXxeaFCOYUQtWBpilsJkEbhvA['spotv_subend'])
  HMcuKDXxeaFCOYUQtWBpilsJkEbhow.setProperty('SPOTV_M_LOGINTIME',HMcuKDXxeaFCOYUQtWBpilsJkEbhvI)
  return HMcuKDXxeaFCOYUQtWBpilsJkEbhTL
 def dp_WatchList_Delete(HMcuKDXxeaFCOYUQtWBpilsJkEbhom,args):
  HMcuKDXxeaFCOYUQtWBpilsJkEbhvS=args.get('mediatype')
  HMcuKDXxeaFCOYUQtWBpilsJkEbhoI=xbmcgui.Dialog()
  HMcuKDXxeaFCOYUQtWBpilsJkEbhSR=HMcuKDXxeaFCOYUQtWBpilsJkEbhoI.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if HMcuKDXxeaFCOYUQtWBpilsJkEbhSR==HMcuKDXxeaFCOYUQtWBpilsJkEbhTP:sys.exit()
  HMcuKDXxeaFCOYUQtWBpilsJkEbhom.Delete_Watched_List(HMcuKDXxeaFCOYUQtWBpilsJkEbhvS)
  xbmc.executebuiltin("Container.Refresh")
 def Delete_Watched_List(HMcuKDXxeaFCOYUQtWBpilsJkEbhom,HMcuKDXxeaFCOYUQtWBpilsJkEbhvS):
  try:
   HMcuKDXxeaFCOYUQtWBpilsJkEbhvj=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%HMcuKDXxeaFCOYUQtWBpilsJkEbhvS))
   fp=HMcuKDXxeaFCOYUQtWBpilsJkEbhTj(HMcuKDXxeaFCOYUQtWBpilsJkEbhvj,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   HMcuKDXxeaFCOYUQtWBpilsJkEbhTm
 def Load_Watched_List(HMcuKDXxeaFCOYUQtWBpilsJkEbhom,HMcuKDXxeaFCOYUQtWBpilsJkEbhvS):
  try:
   HMcuKDXxeaFCOYUQtWBpilsJkEbhvj=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%HMcuKDXxeaFCOYUQtWBpilsJkEbhvS))
   fp=HMcuKDXxeaFCOYUQtWBpilsJkEbhTj(HMcuKDXxeaFCOYUQtWBpilsJkEbhvj,'r',-1,'utf-8')
   HMcuKDXxeaFCOYUQtWBpilsJkEbhvg=fp.readlines()
   fp.close()
  except:
   HMcuKDXxeaFCOYUQtWBpilsJkEbhvg=[]
  return HMcuKDXxeaFCOYUQtWBpilsJkEbhvg
 def Save_Watched_List(HMcuKDXxeaFCOYUQtWBpilsJkEbhom,stype,HMcuKDXxeaFCOYUQtWBpilsJkEbhoP):
  try:
   HMcuKDXxeaFCOYUQtWBpilsJkEbhvj=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   HMcuKDXxeaFCOYUQtWBpilsJkEbhvy=HMcuKDXxeaFCOYUQtWBpilsJkEbhom.Load_Watched_List(stype) 
   fp=HMcuKDXxeaFCOYUQtWBpilsJkEbhTj(HMcuKDXxeaFCOYUQtWBpilsJkEbhvj,'w',-1,'utf-8')
   HMcuKDXxeaFCOYUQtWBpilsJkEbhvR=urllib.parse.urlencode(HMcuKDXxeaFCOYUQtWBpilsJkEbhoP)
   HMcuKDXxeaFCOYUQtWBpilsJkEbhvR=HMcuKDXxeaFCOYUQtWBpilsJkEbhvR+'\n'
   fp.write(HMcuKDXxeaFCOYUQtWBpilsJkEbhvR)
   HMcuKDXxeaFCOYUQtWBpilsJkEbhvz=0
   for HMcuKDXxeaFCOYUQtWBpilsJkEbhvw in HMcuKDXxeaFCOYUQtWBpilsJkEbhvy:
    HMcuKDXxeaFCOYUQtWBpilsJkEbhvf=HMcuKDXxeaFCOYUQtWBpilsJkEbhTR(urllib.parse.parse_qsl(HMcuKDXxeaFCOYUQtWBpilsJkEbhvw))
    HMcuKDXxeaFCOYUQtWBpilsJkEbhvd=HMcuKDXxeaFCOYUQtWBpilsJkEbhoP.get('code')
    HMcuKDXxeaFCOYUQtWBpilsJkEbhvq=HMcuKDXxeaFCOYUQtWBpilsJkEbhvf.get('code')
    if HMcuKDXxeaFCOYUQtWBpilsJkEbhvd!=HMcuKDXxeaFCOYUQtWBpilsJkEbhvq:
     fp.write(HMcuKDXxeaFCOYUQtWBpilsJkEbhvw)
     HMcuKDXxeaFCOYUQtWBpilsJkEbhvz+=1
     if HMcuKDXxeaFCOYUQtWBpilsJkEbhvz>=50:break
   fp.close()
  except:
   HMcuKDXxeaFCOYUQtWBpilsJkEbhTm
 def dp_Watch_List(HMcuKDXxeaFCOYUQtWBpilsJkEbhom,args):
  HMcuKDXxeaFCOYUQtWBpilsJkEbhvS ='vod'
  if HMcuKDXxeaFCOYUQtWBpilsJkEbhvS=='vod':
   HMcuKDXxeaFCOYUQtWBpilsJkEbhvr=HMcuKDXxeaFCOYUQtWBpilsJkEbhom.Load_Watched_List(HMcuKDXxeaFCOYUQtWBpilsJkEbhvS)
   for HMcuKDXxeaFCOYUQtWBpilsJkEbhvV in HMcuKDXxeaFCOYUQtWBpilsJkEbhvr:
    HMcuKDXxeaFCOYUQtWBpilsJkEbhvn=HMcuKDXxeaFCOYUQtWBpilsJkEbhTR(urllib.parse.parse_qsl(HMcuKDXxeaFCOYUQtWBpilsJkEbhvV))
    HMcuKDXxeaFCOYUQtWBpilsJkEbhoq =HMcuKDXxeaFCOYUQtWBpilsJkEbhvn.get('title')
    HMcuKDXxeaFCOYUQtWBpilsJkEbhGP=HMcuKDXxeaFCOYUQtWBpilsJkEbhvn.get('img')
    HMcuKDXxeaFCOYUQtWBpilsJkEbhvG=HMcuKDXxeaFCOYUQtWBpilsJkEbhvn.get('code')
    HMcuKDXxeaFCOYUQtWBpilsJkEbhTo =HMcuKDXxeaFCOYUQtWBpilsJkEbhvn.get('info')
    HMcuKDXxeaFCOYUQtWBpilsJkEbhGj={}
    HMcuKDXxeaFCOYUQtWBpilsJkEbhGj['plot']=HMcuKDXxeaFCOYUQtWBpilsJkEbhTo
    HMcuKDXxeaFCOYUQtWBpilsJkEbhGv={'mode':'GAME_VOD_GROUP','gameid':HMcuKDXxeaFCOYUQtWBpilsJkEbhvG,'saveTitle':HMcuKDXxeaFCOYUQtWBpilsJkEbhoq,'saveImg':HMcuKDXxeaFCOYUQtWBpilsJkEbhGP,'saveInfo':HMcuKDXxeaFCOYUQtWBpilsJkEbhTo,'mediatype':HMcuKDXxeaFCOYUQtWBpilsJkEbhvS}
    HMcuKDXxeaFCOYUQtWBpilsJkEbhom.add_dir(HMcuKDXxeaFCOYUQtWBpilsJkEbhoq,sublabel='',img=HMcuKDXxeaFCOYUQtWBpilsJkEbhGP,infoLabels=HMcuKDXxeaFCOYUQtWBpilsJkEbhGj,isFolder=HMcuKDXxeaFCOYUQtWBpilsJkEbhTL,params=HMcuKDXxeaFCOYUQtWBpilsJkEbhGv)
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGj={'plot':'시청목록을 삭제합니다.'}
   HMcuKDXxeaFCOYUQtWBpilsJkEbhoq='*** 시청목록 삭제 ***'
   HMcuKDXxeaFCOYUQtWBpilsJkEbhGv={'mode':'MYVIEW_REMOVE','mediatype':HMcuKDXxeaFCOYUQtWBpilsJkEbhvS}
   HMcuKDXxeaFCOYUQtWBpilsJkEbhom.add_dir(HMcuKDXxeaFCOYUQtWBpilsJkEbhoq,sublabel='',img='',infoLabels=HMcuKDXxeaFCOYUQtWBpilsJkEbhGj,isFolder=HMcuKDXxeaFCOYUQtWBpilsJkEbhTP,params=HMcuKDXxeaFCOYUQtWBpilsJkEbhGv)
   xbmcplugin.endOfDirectory(HMcuKDXxeaFCOYUQtWBpilsJkEbhom._addon_handle,cacheToDisc=HMcuKDXxeaFCOYUQtWBpilsJkEbhTP)
 def spotv_main(HMcuKDXxeaFCOYUQtWBpilsJkEbhom):
  HMcuKDXxeaFCOYUQtWBpilsJkEbhTS=HMcuKDXxeaFCOYUQtWBpilsJkEbhom.main_params.get('mode',HMcuKDXxeaFCOYUQtWBpilsJkEbhTm)
  if HMcuKDXxeaFCOYUQtWBpilsJkEbhTS=='LOGOUT':
   HMcuKDXxeaFCOYUQtWBpilsJkEbhom.logout()
   return
  HMcuKDXxeaFCOYUQtWBpilsJkEbhom.login_main()
  if HMcuKDXxeaFCOYUQtWBpilsJkEbhTS is HMcuKDXxeaFCOYUQtWBpilsJkEbhTm:
   HMcuKDXxeaFCOYUQtWBpilsJkEbhom.dp_Main_List()
  elif HMcuKDXxeaFCOYUQtWBpilsJkEbhTS=='LIVE_GROUP':
   HMcuKDXxeaFCOYUQtWBpilsJkEbhom.dp_LiveChannel_List(HMcuKDXxeaFCOYUQtWBpilsJkEbhom.main_params)
  elif HMcuKDXxeaFCOYUQtWBpilsJkEbhTS=='ELIVE_GROUP':
   HMcuKDXxeaFCOYUQtWBpilsJkEbhSn=HMcuKDXxeaFCOYUQtWBpilsJkEbhom.dp_EventLiveChannel_List(HMcuKDXxeaFCOYUQtWBpilsJkEbhom.main_params)
   if HMcuKDXxeaFCOYUQtWBpilsJkEbhSn==401:
    if os.path.isfile(HMcuKDXxeaFCOYUQtWBpilsJkEbhoT):os.remove(HMcuKDXxeaFCOYUQtWBpilsJkEbhoT)
    HMcuKDXxeaFCOYUQtWBpilsJkEbhom.login_main()
    HMcuKDXxeaFCOYUQtWBpilsJkEbhom.dp_EventLiveChannel_List(HMcuKDXxeaFCOYUQtWBpilsJkEbhom.main_params)
  elif HMcuKDXxeaFCOYUQtWBpilsJkEbhTS in['LIVE','GAME_VOD','POP_VOD','ELIVE']:
   HMcuKDXxeaFCOYUQtWBpilsJkEbhom.play_VIDEO(HMcuKDXxeaFCOYUQtWBpilsJkEbhom.main_params)
  elif HMcuKDXxeaFCOYUQtWBpilsJkEbhTS=='VOD_GROUP':
   HMcuKDXxeaFCOYUQtWBpilsJkEbhom.dp_MainLeague_List(HMcuKDXxeaFCOYUQtWBpilsJkEbhom.main_params)
  elif HMcuKDXxeaFCOYUQtWBpilsJkEbhTS=='POP_GROUP':
   HMcuKDXxeaFCOYUQtWBpilsJkEbhom.dp_PopVod_GroupList(HMcuKDXxeaFCOYUQtWBpilsJkEbhom.main_params)
  elif HMcuKDXxeaFCOYUQtWBpilsJkEbhTS=='LEAGUE_GROUP':
   HMcuKDXxeaFCOYUQtWBpilsJkEbhom.dp_Season_List(HMcuKDXxeaFCOYUQtWBpilsJkEbhom.main_params)
  elif HMcuKDXxeaFCOYUQtWBpilsJkEbhTS=='SEASON_GROUP':
   HMcuKDXxeaFCOYUQtWBpilsJkEbhom.dp_Game_List(HMcuKDXxeaFCOYUQtWBpilsJkEbhom.main_params)
  elif HMcuKDXxeaFCOYUQtWBpilsJkEbhTS=='GAME_VOD_GROUP':
   HMcuKDXxeaFCOYUQtWBpilsJkEbhom.dp_GameVod_List(HMcuKDXxeaFCOYUQtWBpilsJkEbhom.main_params)
  elif HMcuKDXxeaFCOYUQtWBpilsJkEbhTS=='WATCH':
   HMcuKDXxeaFCOYUQtWBpilsJkEbhom.dp_Watch_List(HMcuKDXxeaFCOYUQtWBpilsJkEbhom.main_params)
  elif HMcuKDXxeaFCOYUQtWBpilsJkEbhTS=='MYVIEW_REMOVE':
   HMcuKDXxeaFCOYUQtWBpilsJkEbhom.dp_WatchList_Delete(HMcuKDXxeaFCOYUQtWBpilsJkEbhom.main_params)
  else:
   HMcuKDXxeaFCOYUQtWBpilsJkEbhTm
# Created by pyminifier (https://github.com/liftoff/pyminifier)
