__author__="NightRain"
CsunNxhvXFyrweDVMYEbWmIUakotcP=object
CsunNxhvXFyrweDVMYEbWmIUakotcz=None
CsunNxhvXFyrweDVMYEbWmIUakotcK=False
CsunNxhvXFyrweDVMYEbWmIUakotcT=print
CsunNxhvXFyrweDVMYEbWmIUakotcd=str
CsunNxhvXFyrweDVMYEbWmIUakotcO=True
CsunNxhvXFyrweDVMYEbWmIUakotcS=Exception
CsunNxhvXFyrweDVMYEbWmIUakotcB=range
CsunNxhvXFyrweDVMYEbWmIUakotcA=int
import urllib
import http.cookiejar 
import re
import json
import sys
import time
import requests
import datetime
import base64
CsunNxhvXFyrweDVMYEbWmIUakotli ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
CsunNxhvXFyrweDVMYEbWmIUakotlQ={'stream50':1080,'stream40':720,'stream30':540}
class CsunNxhvXFyrweDVMYEbWmIUakotlJ(CsunNxhvXFyrweDVMYEbWmIUakotcP):
 def __init__(CsunNxhvXFyrweDVMYEbWmIUakotlc):
  CsunNxhvXFyrweDVMYEbWmIUakotlc.SPOTV_SESSIONID=''
  CsunNxhvXFyrweDVMYEbWmIUakotlc.SPOTV_SESSION =''
  CsunNxhvXFyrweDVMYEbWmIUakotlc.SPOTV_ACCOUNTID=''
  CsunNxhvXFyrweDVMYEbWmIUakotlc.SPOTV_POLICYKEY=''
  CsunNxhvXFyrweDVMYEbWmIUakotlc.SPOTV_SUBEND =''
  CsunNxhvXFyrweDVMYEbWmIUakotlc.SPOTV_PMCODE ='987'
  CsunNxhvXFyrweDVMYEbWmIUakotlc.SPOTV_PMSIZE =3
  CsunNxhvXFyrweDVMYEbWmIUakotlc.GAMELIST_LIMIT =10
  CsunNxhvXFyrweDVMYEbWmIUakotlc.API_DOMAIN ='https://www.spotvnow.co.kr'
  CsunNxhvXFyrweDVMYEbWmIUakotlc.BC_DOMAIN ='https://players.brightcove.net'
  CsunNxhvXFyrweDVMYEbWmIUakotlc.PLAYER_DOMAIN ='https://edge.api.brightcove.com'
  CsunNxhvXFyrweDVMYEbWmIUakotlc.DEFAULT_HEADER ={'user-agent':CsunNxhvXFyrweDVMYEbWmIUakotli}
 def callRequestCookies(CsunNxhvXFyrweDVMYEbWmIUakotlc,jobtype,CsunNxhvXFyrweDVMYEbWmIUakotJQ,payload=CsunNxhvXFyrweDVMYEbWmIUakotcz,params=CsunNxhvXFyrweDVMYEbWmIUakotcz,headers=CsunNxhvXFyrweDVMYEbWmIUakotcz,cookies=CsunNxhvXFyrweDVMYEbWmIUakotcz,redirects=CsunNxhvXFyrweDVMYEbWmIUakotcK):
  CsunNxhvXFyrweDVMYEbWmIUakotlf=CsunNxhvXFyrweDVMYEbWmIUakotlc.DEFAULT_HEADER
  if headers:CsunNxhvXFyrweDVMYEbWmIUakotlf.update(headers)
  if jobtype=='Get':
   CsunNxhvXFyrweDVMYEbWmIUakotlP=requests.get(CsunNxhvXFyrweDVMYEbWmIUakotJQ,params=params,headers=CsunNxhvXFyrweDVMYEbWmIUakotlf,cookies=cookies,allow_redirects=redirects)
  else:
   CsunNxhvXFyrweDVMYEbWmIUakotlP=requests.post(CsunNxhvXFyrweDVMYEbWmIUakotJQ,data=payload,params=params,headers=CsunNxhvXFyrweDVMYEbWmIUakotlf,cookies=cookies,allow_redirects=redirects)
  return CsunNxhvXFyrweDVMYEbWmIUakotlP
 def makeDefaultCookies(CsunNxhvXFyrweDVMYEbWmIUakotlc):
  CsunNxhvXFyrweDVMYEbWmIUakotlz={'SESSION':CsunNxhvXFyrweDVMYEbWmIUakotlc.SPOTV_SESSION}
  return CsunNxhvXFyrweDVMYEbWmIUakotlz
 def GetCredential(CsunNxhvXFyrweDVMYEbWmIUakotlc,user_id,user_pw):
  CsunNxhvXFyrweDVMYEbWmIUakotlK=CsunNxhvXFyrweDVMYEbWmIUakotcK
  CsunNxhvXFyrweDVMYEbWmIUakotlT=CsunNxhvXFyrweDVMYEbWmIUakotlG=CsunNxhvXFyrweDVMYEbWmIUakotlL=CsunNxhvXFyrweDVMYEbWmIUakotlR=CsunNxhvXFyrweDVMYEbWmIUakotlH=''
  try:
   CsunNxhvXFyrweDVMYEbWmIUakotld=base64.standard_b64encode(user_id.encode("UTF-8")).decode('utf-8')
   CsunNxhvXFyrweDVMYEbWmIUakotlO=base64.standard_b64encode(user_pw.encode("UTF-8")).decode('utf-8')
   CsunNxhvXFyrweDVMYEbWmIUakotlS=CsunNxhvXFyrweDVMYEbWmIUakotlc.API_DOMAIN+'/api/v2/login'
   CsunNxhvXFyrweDVMYEbWmIUakotlB={'username':CsunNxhvXFyrweDVMYEbWmIUakotld,'password':CsunNxhvXFyrweDVMYEbWmIUakotlO}
   CsunNxhvXFyrweDVMYEbWmIUakotlB=json.dumps(CsunNxhvXFyrweDVMYEbWmIUakotlB)
   CsunNxhvXFyrweDVMYEbWmIUakotlA=CsunNxhvXFyrweDVMYEbWmIUakotlc.callRequestCookies('Post',CsunNxhvXFyrweDVMYEbWmIUakotlS,payload=CsunNxhvXFyrweDVMYEbWmIUakotlB,params=CsunNxhvXFyrweDVMYEbWmIUakotcz,headers=CsunNxhvXFyrweDVMYEbWmIUakotcz,cookies=CsunNxhvXFyrweDVMYEbWmIUakotcz)
   CsunNxhvXFyrweDVMYEbWmIUakotcT(CsunNxhvXFyrweDVMYEbWmIUakotlA.status_code)
   for CsunNxhvXFyrweDVMYEbWmIUakotlg in CsunNxhvXFyrweDVMYEbWmIUakotlA.cookies:
    if CsunNxhvXFyrweDVMYEbWmIUakotlg.name=='SESSION':
     CsunNxhvXFyrweDVMYEbWmIUakotlG=CsunNxhvXFyrweDVMYEbWmIUakotlg.value
     break
   if CsunNxhvXFyrweDVMYEbWmIUakotlG=='':return CsunNxhvXFyrweDVMYEbWmIUakotlK
   CsunNxhvXFyrweDVMYEbWmIUakotlp=json.loads(CsunNxhvXFyrweDVMYEbWmIUakotlA.text)
   if not('userId' in CsunNxhvXFyrweDVMYEbWmIUakotlp):return CsunNxhvXFyrweDVMYEbWmIUakotlK
   CsunNxhvXFyrweDVMYEbWmIUakotlT=CsunNxhvXFyrweDVMYEbWmIUakotcd(CsunNxhvXFyrweDVMYEbWmIUakotlp['userId'])
   CsunNxhvXFyrweDVMYEbWmIUakotlH =CsunNxhvXFyrweDVMYEbWmIUakotcd(CsunNxhvXFyrweDVMYEbWmIUakotlp['subEndTime'])
   CsunNxhvXFyrweDVMYEbWmIUakotlL,CsunNxhvXFyrweDVMYEbWmIUakotlR=CsunNxhvXFyrweDVMYEbWmIUakotlc.GetPolicyKey()
   if CsunNxhvXFyrweDVMYEbWmIUakotlR=='':return CsunNxhvXFyrweDVMYEbWmIUakotlK
   CsunNxhvXFyrweDVMYEbWmIUakotlK=CsunNxhvXFyrweDVMYEbWmIUakotcO
  except CsunNxhvXFyrweDVMYEbWmIUakotcS as exception:
   CsunNxhvXFyrweDVMYEbWmIUakotlT=CsunNxhvXFyrweDVMYEbWmIUakotlG='' 
   CsunNxhvXFyrweDVMYEbWmIUakotcT(exception)
  CsunNxhvXFyrweDVMYEbWmIUakotlj={'spotv_sessionid':CsunNxhvXFyrweDVMYEbWmIUakotlT,'spotv_session':CsunNxhvXFyrweDVMYEbWmIUakotlG,'spotv_accountId':CsunNxhvXFyrweDVMYEbWmIUakotlL,'spotv_policyKey':CsunNxhvXFyrweDVMYEbWmIUakotlR,'spotv_subend':CsunNxhvXFyrweDVMYEbWmIUakotlH}
  CsunNxhvXFyrweDVMYEbWmIUakotlc.SaveCredential(CsunNxhvXFyrweDVMYEbWmIUakotlj)
  return CsunNxhvXFyrweDVMYEbWmIUakotlK
 def SaveCredential(CsunNxhvXFyrweDVMYEbWmIUakotlc,CsunNxhvXFyrweDVMYEbWmIUakotlj):
  CsunNxhvXFyrweDVMYEbWmIUakotlc.SPOTV_SESSIONID=CsunNxhvXFyrweDVMYEbWmIUakotlj.get('spotv_sessionid')
  CsunNxhvXFyrweDVMYEbWmIUakotlc.SPOTV_SESSION =CsunNxhvXFyrweDVMYEbWmIUakotlj.get('spotv_session')
  CsunNxhvXFyrweDVMYEbWmIUakotlc.SPOTV_ACCOUNTID=CsunNxhvXFyrweDVMYEbWmIUakotlj.get('spotv_accountId')
  CsunNxhvXFyrweDVMYEbWmIUakotlc.SPOTV_POLICYKEY=CsunNxhvXFyrweDVMYEbWmIUakotlj.get('spotv_policyKey')
  CsunNxhvXFyrweDVMYEbWmIUakotlc.SPOTV_SUBEND =CsunNxhvXFyrweDVMYEbWmIUakotlj.get('spotv_subend')
 def LoadCredential(CsunNxhvXFyrweDVMYEbWmIUakotlc):
  CsunNxhvXFyrweDVMYEbWmIUakotlj={'spotv_sessionid':CsunNxhvXFyrweDVMYEbWmIUakotlc.SPOTV_SESSIONID,'spotv_session':CsunNxhvXFyrweDVMYEbWmIUakotlc.SPOTV_SESSION,'spotv_accountId':CsunNxhvXFyrweDVMYEbWmIUakotlc.SPOTV_ACCOUNTID,'spotv_policyKey':CsunNxhvXFyrweDVMYEbWmIUakotlc.SPOTV_POLICYKEY,'spotv_subend':CsunNxhvXFyrweDVMYEbWmIUakotlc.SPOTV_SUBEND}
  return CsunNxhvXFyrweDVMYEbWmIUakotlj
 def Get_Now_Datetime(CsunNxhvXFyrweDVMYEbWmIUakotlc):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetLiveChannelList(CsunNxhvXFyrweDVMYEbWmIUakotlc):
  CsunNxhvXFyrweDVMYEbWmIUakotJl=[]
  CsunNxhvXFyrweDVMYEbWmIUakotJi ={}
  try:
   CsunNxhvXFyrweDVMYEbWmIUakotJQ=CsunNxhvXFyrweDVMYEbWmIUakotlc.API_DOMAIN+'/api/v2/channel'
   CsunNxhvXFyrweDVMYEbWmIUakotlA=CsunNxhvXFyrweDVMYEbWmIUakotlc.callRequestCookies('Get',CsunNxhvXFyrweDVMYEbWmIUakotJQ,payload=CsunNxhvXFyrweDVMYEbWmIUakotcz,params=CsunNxhvXFyrweDVMYEbWmIUakotcz,headers=CsunNxhvXFyrweDVMYEbWmIUakotcz,cookies=CsunNxhvXFyrweDVMYEbWmIUakotcz)
   CsunNxhvXFyrweDVMYEbWmIUakotlp=json.loads(CsunNxhvXFyrweDVMYEbWmIUakotlA.text)
   CsunNxhvXFyrweDVMYEbWmIUakotJi=CsunNxhvXFyrweDVMYEbWmIUakotlc.GetEPGList()
   for i in CsunNxhvXFyrweDVMYEbWmIUakotcB(2):
    for CsunNxhvXFyrweDVMYEbWmIUakotJc in CsunNxhvXFyrweDVMYEbWmIUakotlp:
     CsunNxhvXFyrweDVMYEbWmIUakotJf={}
     CsunNxhvXFyrweDVMYEbWmIUakotJf['mediatype']='video'
     CsunNxhvXFyrweDVMYEbWmIUakotJf['title'] =CsunNxhvXFyrweDVMYEbWmIUakotJc['programName']
     CsunNxhvXFyrweDVMYEbWmIUakotJf['studio'] =CsunNxhvXFyrweDVMYEbWmIUakotJc['name']
     CsunNxhvXFyrweDVMYEbWmIUakotJP={'id':CsunNxhvXFyrweDVMYEbWmIUakotJc['id'],'name':CsunNxhvXFyrweDVMYEbWmIUakotJc['name'],'logo':CsunNxhvXFyrweDVMYEbWmIUakotJc['logo'],'videoId':CsunNxhvXFyrweDVMYEbWmIUakotJc['videoId'].replace('ref:',''),'free':CsunNxhvXFyrweDVMYEbWmIUakotJc['free'],'programName':CsunNxhvXFyrweDVMYEbWmIUakotJc['programName'],'channelepg':CsunNxhvXFyrweDVMYEbWmIUakotJi.get(CsunNxhvXFyrweDVMYEbWmIUakotJc['id']),'info':CsunNxhvXFyrweDVMYEbWmIUakotJf}
     if i==0:
      if CsunNxhvXFyrweDVMYEbWmIUakotJc['free']==CsunNxhvXFyrweDVMYEbWmIUakotcK:CsunNxhvXFyrweDVMYEbWmIUakotJl.append(CsunNxhvXFyrweDVMYEbWmIUakotJP)
     else:
      if CsunNxhvXFyrweDVMYEbWmIUakotJc['free']==CsunNxhvXFyrweDVMYEbWmIUakotcO:CsunNxhvXFyrweDVMYEbWmIUakotJl.append(CsunNxhvXFyrweDVMYEbWmIUakotJP)
  except CsunNxhvXFyrweDVMYEbWmIUakotcS as exception:
   CsunNxhvXFyrweDVMYEbWmIUakotcT(exception)
  return CsunNxhvXFyrweDVMYEbWmIUakotJl
 def CheckLiveChannel(CsunNxhvXFyrweDVMYEbWmIUakotlc,channelid):
  try:
   CsunNxhvXFyrweDVMYEbWmIUakotJQ=CsunNxhvXFyrweDVMYEbWmIUakotlc.API_DOMAIN+'/api/v2/channel'
   CsunNxhvXFyrweDVMYEbWmIUakotlA=CsunNxhvXFyrweDVMYEbWmIUakotlc.callRequestCookies('Get',CsunNxhvXFyrweDVMYEbWmIUakotJQ,payload=CsunNxhvXFyrweDVMYEbWmIUakotcz,params=CsunNxhvXFyrweDVMYEbWmIUakotcz,headers=CsunNxhvXFyrweDVMYEbWmIUakotcz,cookies=CsunNxhvXFyrweDVMYEbWmIUakotcz)
   CsunNxhvXFyrweDVMYEbWmIUakotlp=json.loads(CsunNxhvXFyrweDVMYEbWmIUakotlA.text)
   for CsunNxhvXFyrweDVMYEbWmIUakotJc in CsunNxhvXFyrweDVMYEbWmIUakotlp:
    if CsunNxhvXFyrweDVMYEbWmIUakotJc['videoId'].replace('ref:','')==channelid:
     return CsunNxhvXFyrweDVMYEbWmIUakotJc['free']
  except CsunNxhvXFyrweDVMYEbWmIUakotcS as exception:
   CsunNxhvXFyrweDVMYEbWmIUakotcT(exception)
  return CsunNxhvXFyrweDVMYEbWmIUakotcK
 def GetEPGList(CsunNxhvXFyrweDVMYEbWmIUakotlc):
  CsunNxhvXFyrweDVMYEbWmIUakotJz={}
  CsunNxhvXFyrweDVMYEbWmIUakotJK=CsunNxhvXFyrweDVMYEbWmIUakotlc.Get_Now_Datetime()
  CsunNxhvXFyrweDVMYEbWmIUakotJT=CsunNxhvXFyrweDVMYEbWmIUakotJK.strftime('%Y%m%d%H%M')
  CsunNxhvXFyrweDVMYEbWmIUakotJd='%s-%s-%s'%(CsunNxhvXFyrweDVMYEbWmIUakotJT[0:4],CsunNxhvXFyrweDVMYEbWmIUakotJT[4:6],CsunNxhvXFyrweDVMYEbWmIUakotJT[6:8])
  CsunNxhvXFyrweDVMYEbWmIUakotJO=(CsunNxhvXFyrweDVMYEbWmIUakotJK+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M')
  try:
   CsunNxhvXFyrweDVMYEbWmIUakotJQ=CsunNxhvXFyrweDVMYEbWmIUakotlc.API_DOMAIN+'/api/v2/program/'+CsunNxhvXFyrweDVMYEbWmIUakotJd
   CsunNxhvXFyrweDVMYEbWmIUakotlA=CsunNxhvXFyrweDVMYEbWmIUakotlc.callRequestCookies('Get',CsunNxhvXFyrweDVMYEbWmIUakotJQ,payload=CsunNxhvXFyrweDVMYEbWmIUakotcz,params=CsunNxhvXFyrweDVMYEbWmIUakotcz,headers=CsunNxhvXFyrweDVMYEbWmIUakotcz,cookies=CsunNxhvXFyrweDVMYEbWmIUakotcz)
   CsunNxhvXFyrweDVMYEbWmIUakotlp=json.loads(CsunNxhvXFyrweDVMYEbWmIUakotlA.text)
   CsunNxhvXFyrweDVMYEbWmIUakotJS=-1 
   CsunNxhvXFyrweDVMYEbWmIUakotJB =''
   for CsunNxhvXFyrweDVMYEbWmIUakotJc in CsunNxhvXFyrweDVMYEbWmIUakotlp:
    CsunNxhvXFyrweDVMYEbWmIUakotJA=CsunNxhvXFyrweDVMYEbWmIUakotJc['channelId']
    CsunNxhvXFyrweDVMYEbWmIUakotJg =CsunNxhvXFyrweDVMYEbWmIUakotJc['startTime'].replace('-','').replace(' ','').replace(':','')
    CsunNxhvXFyrweDVMYEbWmIUakotJG =CsunNxhvXFyrweDVMYEbWmIUakotJc['endTime'].replace('-','').replace(' ','').replace(':','')
    if CsunNxhvXFyrweDVMYEbWmIUakotcA(CsunNxhvXFyrweDVMYEbWmIUakotJT)>CsunNxhvXFyrweDVMYEbWmIUakotcA(CsunNxhvXFyrweDVMYEbWmIUakotJG) :continue
    if CsunNxhvXFyrweDVMYEbWmIUakotcA(CsunNxhvXFyrweDVMYEbWmIUakotJO)<CsunNxhvXFyrweDVMYEbWmIUakotcA(CsunNxhvXFyrweDVMYEbWmIUakotJg):continue
    if CsunNxhvXFyrweDVMYEbWmIUakotJS!=CsunNxhvXFyrweDVMYEbWmIUakotJA:
     if CsunNxhvXFyrweDVMYEbWmIUakotJB!='':CsunNxhvXFyrweDVMYEbWmIUakotJz[CsunNxhvXFyrweDVMYEbWmIUakotJS]=CsunNxhvXFyrweDVMYEbWmIUakotJB
     CsunNxhvXFyrweDVMYEbWmIUakotJS=CsunNxhvXFyrweDVMYEbWmIUakotJA
     CsunNxhvXFyrweDVMYEbWmIUakotJB =''
    if CsunNxhvXFyrweDVMYEbWmIUakotJB:CsunNxhvXFyrweDVMYEbWmIUakotJB+='\n'
    CsunNxhvXFyrweDVMYEbWmIUakotJB+=CsunNxhvXFyrweDVMYEbWmIUakotJc['title']+'\n'
    CsunNxhvXFyrweDVMYEbWmIUakotJB+=' [%s ~ %s]'%(CsunNxhvXFyrweDVMYEbWmIUakotJc['startTime'][-5:],CsunNxhvXFyrweDVMYEbWmIUakotJc['endTime'][-5:])+'\n'
   if CsunNxhvXFyrweDVMYEbWmIUakotJB:CsunNxhvXFyrweDVMYEbWmIUakotJz[CsunNxhvXFyrweDVMYEbWmIUakotJS]=CsunNxhvXFyrweDVMYEbWmIUakotJB
  except CsunNxhvXFyrweDVMYEbWmIUakotcS as exception:
   CsunNxhvXFyrweDVMYEbWmIUakotcT(exception)
  return CsunNxhvXFyrweDVMYEbWmIUakotJz
 def GetEventLiveList(CsunNxhvXFyrweDVMYEbWmIUakotlc):
  CsunNxhvXFyrweDVMYEbWmIUakotJl=[]
  CsunNxhvXFyrweDVMYEbWmIUakotJp =0
  try:
   CsunNxhvXFyrweDVMYEbWmIUakotJH=CsunNxhvXFyrweDVMYEbWmIUakotlc.Get_Now_Datetime()
   CsunNxhvXFyrweDVMYEbWmIUakotJL=CsunNxhvXFyrweDVMYEbWmIUakotJH.strftime('%Y-%m-%d')
  except CsunNxhvXFyrweDVMYEbWmIUakotcS as exception:
   CsunNxhvXFyrweDVMYEbWmIUakotcT(exception)
   return CsunNxhvXFyrweDVMYEbWmIUakotJl,CsunNxhvXFyrweDVMYEbWmIUakotJp
  try:
   CsunNxhvXFyrweDVMYEbWmIUakotJQ=CsunNxhvXFyrweDVMYEbWmIUakotlc.API_DOMAIN+'/api/v2/player/lives/'+CsunNxhvXFyrweDVMYEbWmIUakotJL 
   CsunNxhvXFyrweDVMYEbWmIUakotlz=CsunNxhvXFyrweDVMYEbWmIUakotlc.makeDefaultCookies()
   CsunNxhvXFyrweDVMYEbWmIUakotlA=CsunNxhvXFyrweDVMYEbWmIUakotlc.callRequestCookies('Get',CsunNxhvXFyrweDVMYEbWmIUakotJQ,payload=CsunNxhvXFyrweDVMYEbWmIUakotcz,params=CsunNxhvXFyrweDVMYEbWmIUakotcz,headers=CsunNxhvXFyrweDVMYEbWmIUakotcz,cookies=CsunNxhvXFyrweDVMYEbWmIUakotlz)
   CsunNxhvXFyrweDVMYEbWmIUakotJp=CsunNxhvXFyrweDVMYEbWmIUakotlA.status_code 
   CsunNxhvXFyrweDVMYEbWmIUakotlp=json.loads(CsunNxhvXFyrweDVMYEbWmIUakotlA.text)
   for CsunNxhvXFyrweDVMYEbWmIUakotJR in CsunNxhvXFyrweDVMYEbWmIUakotlp:
    for CsunNxhvXFyrweDVMYEbWmIUakotJc in CsunNxhvXFyrweDVMYEbWmIUakotJR['liveNowList']:
     CsunNxhvXFyrweDVMYEbWmIUakotJf={}
     CsunNxhvXFyrweDVMYEbWmIUakotJf['mediatype']='video'
     if CsunNxhvXFyrweDVMYEbWmIUakotJc['gameDesc']['title']==CsunNxhvXFyrweDVMYEbWmIUakotcz or CsunNxhvXFyrweDVMYEbWmIUakotJc['gameDesc']['title']=='':
      CsunNxhvXFyrweDVMYEbWmIUakotJj='%s ( %s : %s )'%(CsunNxhvXFyrweDVMYEbWmIUakotJc['leagueName'],CsunNxhvXFyrweDVMYEbWmIUakotJc['homeNameShort'],CsunNxhvXFyrweDVMYEbWmIUakotJc['awayNameShort'])
     else:
      CsunNxhvXFyrweDVMYEbWmIUakotJj=CsunNxhvXFyrweDVMYEbWmIUakotJc['gameDesc']['title']
     CsunNxhvXFyrweDVMYEbWmIUakotJP={'liveId':CsunNxhvXFyrweDVMYEbWmIUakotJc['liveId'],'title':CsunNxhvXFyrweDVMYEbWmIUakotJj,'logo':CsunNxhvXFyrweDVMYEbWmIUakotJc['gameDesc']['leagueLogo'],'free':CsunNxhvXFyrweDVMYEbWmIUakotJc['isFree'],'startTime':CsunNxhvXFyrweDVMYEbWmIUakotJc['startTime'],'info':CsunNxhvXFyrweDVMYEbWmIUakotJf}
     CsunNxhvXFyrweDVMYEbWmIUakotJl.append(CsunNxhvXFyrweDVMYEbWmIUakotJP)
  except CsunNxhvXFyrweDVMYEbWmIUakotcS as exception:
   CsunNxhvXFyrweDVMYEbWmIUakotcT(exception)
  return CsunNxhvXFyrweDVMYEbWmIUakotJl,CsunNxhvXFyrweDVMYEbWmIUakotJp
 def GetEventLiveList_sub(CsunNxhvXFyrweDVMYEbWmIUakotlc,tDate):
  CsunNxhvXFyrweDVMYEbWmIUakotJl=[]
  try:
   CsunNxhvXFyrweDVMYEbWmIUakotJQ=CsunNxhvXFyrweDVMYEbWmIUakotlc.API_DOMAIN+'/api/v2/player/lives/'+tDate
   CsunNxhvXFyrweDVMYEbWmIUakotlz=CsunNxhvXFyrweDVMYEbWmIUakotlc.makeDefaultCookies()
   CsunNxhvXFyrweDVMYEbWmIUakotlA=CsunNxhvXFyrweDVMYEbWmIUakotlc.callRequestCookies('Get',CsunNxhvXFyrweDVMYEbWmIUakotJQ,payload=CsunNxhvXFyrweDVMYEbWmIUakotcz,params=CsunNxhvXFyrweDVMYEbWmIUakotcz,headers=CsunNxhvXFyrweDVMYEbWmIUakotcz,cookies=CsunNxhvXFyrweDVMYEbWmIUakotlz)
   CsunNxhvXFyrweDVMYEbWmIUakotlp=json.loads(CsunNxhvXFyrweDVMYEbWmIUakotlA.text)
   for CsunNxhvXFyrweDVMYEbWmIUakotJR in CsunNxhvXFyrweDVMYEbWmIUakotlp:
    for CsunNxhvXFyrweDVMYEbWmIUakotJc in CsunNxhvXFyrweDVMYEbWmIUakotJR['liveNowList']:
     CsunNxhvXFyrweDVMYEbWmIUakotJf={}
     CsunNxhvXFyrweDVMYEbWmIUakotJf['mediatype']='video'
     if CsunNxhvXFyrweDVMYEbWmIUakotJc['gameDesc']['title']==CsunNxhvXFyrweDVMYEbWmIUakotcz or CsunNxhvXFyrweDVMYEbWmIUakotJc['gameDesc']['title']=='':
      CsunNxhvXFyrweDVMYEbWmIUakotJj='%s ( %s : %s )'%(CsunNxhvXFyrweDVMYEbWmIUakotJc['leagueName'],CsunNxhvXFyrweDVMYEbWmIUakotJc['homeNameShort'],CsunNxhvXFyrweDVMYEbWmIUakotJc['awayNameShort'])
     else:
      CsunNxhvXFyrweDVMYEbWmIUakotJj=CsunNxhvXFyrweDVMYEbWmIUakotJc['gameDesc']['title']
     CsunNxhvXFyrweDVMYEbWmIUakotJP={'liveId':CsunNxhvXFyrweDVMYEbWmIUakotJc['liveId'],'title':CsunNxhvXFyrweDVMYEbWmIUakotJj,'logo':CsunNxhvXFyrweDVMYEbWmIUakotJc['gameDesc']['leagueLogo'],'free':CsunNxhvXFyrweDVMYEbWmIUakotJc['isFree'],'startTime':CsunNxhvXFyrweDVMYEbWmIUakotJc['startTime'],'info':CsunNxhvXFyrweDVMYEbWmIUakotJf}
     CsunNxhvXFyrweDVMYEbWmIUakotJl.append(CsunNxhvXFyrweDVMYEbWmIUakotJP)
  except CsunNxhvXFyrweDVMYEbWmIUakotcS as exception:
   CsunNxhvXFyrweDVMYEbWmIUakotcT(exception)
  return CsunNxhvXFyrweDVMYEbWmIUakotJl
 def GetEventLive_videoId(CsunNxhvXFyrweDVMYEbWmIUakotlc,liveId):
  CsunNxhvXFyrweDVMYEbWmIUakotJq=''
  try:
   CsunNxhvXFyrweDVMYEbWmIUakotJQ=CsunNxhvXFyrweDVMYEbWmIUakotlc.API_DOMAIN+'/api/v2/live/'+liveId
   CsunNxhvXFyrweDVMYEbWmIUakotlA=CsunNxhvXFyrweDVMYEbWmIUakotlc.callRequestCookies('Get',CsunNxhvXFyrweDVMYEbWmIUakotJQ,payload=CsunNxhvXFyrweDVMYEbWmIUakotcz,params=CsunNxhvXFyrweDVMYEbWmIUakotcz,headers=CsunNxhvXFyrweDVMYEbWmIUakotcz,cookies=CsunNxhvXFyrweDVMYEbWmIUakotcz)
   CsunNxhvXFyrweDVMYEbWmIUakotlp=json.loads(CsunNxhvXFyrweDVMYEbWmIUakotlA.text)
   CsunNxhvXFyrweDVMYEbWmIUakotil=CsunNxhvXFyrweDVMYEbWmIUakotlp['videoId']
   CsunNxhvXFyrweDVMYEbWmIUakotJq=CsunNxhvXFyrweDVMYEbWmIUakotil.replace('ref:','')
  except CsunNxhvXFyrweDVMYEbWmIUakotcS as exception:
   CsunNxhvXFyrweDVMYEbWmIUakotcT(exception)
  return CsunNxhvXFyrweDVMYEbWmIUakotJq
 def CheckMainEnd(CsunNxhvXFyrweDVMYEbWmIUakotlc):
  CsunNxhvXFyrweDVMYEbWmIUakotiJ=base64.standard_b64encode((CsunNxhvXFyrweDVMYEbWmIUakotlc.SPOTV_PMCODE+CsunNxhvXFyrweDVMYEbWmIUakotlc.SPOTV_SESSIONID).encode()).decode('utf-8')
  if CsunNxhvXFyrweDVMYEbWmIUakotiJ=='OTg3MTgzMzM0Ng==' or CsunNxhvXFyrweDVMYEbWmIUakotiJ=='OTg3MTgzMzExNw==':return CsunNxhvXFyrweDVMYEbWmIUakotcO
  return CsunNxhvXFyrweDVMYEbWmIUakotcK
 def CheckSubEnd(CsunNxhvXFyrweDVMYEbWmIUakotlc):
  CsunNxhvXFyrweDVMYEbWmIUakotiQ=CsunNxhvXFyrweDVMYEbWmIUakotcK
  try:
   if CsunNxhvXFyrweDVMYEbWmIUakotlc.CheckMainEnd():return CsunNxhvXFyrweDVMYEbWmIUakotcO 
   if CsunNxhvXFyrweDVMYEbWmIUakotlc.SPOTV_SUBEND=='0':return CsunNxhvXFyrweDVMYEbWmIUakotiQ
   CsunNxhvXFyrweDVMYEbWmIUakotic =CsunNxhvXFyrweDVMYEbWmIUakotcA(CsunNxhvXFyrweDVMYEbWmIUakotlc.Get_Now_Datetime().strftime('%Y%m%d'))
   CsunNxhvXFyrweDVMYEbWmIUakotif =CsunNxhvXFyrweDVMYEbWmIUakotcA(CsunNxhvXFyrweDVMYEbWmIUakotlc.SPOTV_SUBEND)/1000
   CsunNxhvXFyrweDVMYEbWmIUakotiP =CsunNxhvXFyrweDVMYEbWmIUakotcA(datetime.datetime.fromtimestamp(CsunNxhvXFyrweDVMYEbWmIUakotif,datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul')).strftime('%Y%m%d'))
   if CsunNxhvXFyrweDVMYEbWmIUakotic<=CsunNxhvXFyrweDVMYEbWmIUakotiP:CsunNxhvXFyrweDVMYEbWmIUakotiQ=CsunNxhvXFyrweDVMYEbWmIUakotcO
  except CsunNxhvXFyrweDVMYEbWmIUakotcS as exception:
   CsunNxhvXFyrweDVMYEbWmIUakotcT(exception)
   return CsunNxhvXFyrweDVMYEbWmIUakotiQ
  return CsunNxhvXFyrweDVMYEbWmIUakotiQ
 def GetMainJspath(CsunNxhvXFyrweDVMYEbWmIUakotlc):
  CsunNxhvXFyrweDVMYEbWmIUakotiz=''
  try:
   CsunNxhvXFyrweDVMYEbWmIUakotJQ=CsunNxhvXFyrweDVMYEbWmIUakotlc.API_DOMAIN
   CsunNxhvXFyrweDVMYEbWmIUakotlA=CsunNxhvXFyrweDVMYEbWmIUakotlc.callRequestCookies('Get',CsunNxhvXFyrweDVMYEbWmIUakotJQ,payload=CsunNxhvXFyrweDVMYEbWmIUakotcz,params=CsunNxhvXFyrweDVMYEbWmIUakotcz,headers=CsunNxhvXFyrweDVMYEbWmIUakotcz,cookies=CsunNxhvXFyrweDVMYEbWmIUakotcz)
   CsunNxhvXFyrweDVMYEbWmIUakotiK=CsunNxhvXFyrweDVMYEbWmIUakotlA.text
   CsunNxhvXFyrweDVMYEbWmIUakotiT =re.findall('https://cdn.spotvnow.co.kr/dist/js/.{20}\.js',CsunNxhvXFyrweDVMYEbWmIUakotiK)[0]
   CsunNxhvXFyrweDVMYEbWmIUakotiz=CsunNxhvXFyrweDVMYEbWmIUakotiT
  except CsunNxhvXFyrweDVMYEbWmIUakotcS as exception:
   CsunNxhvXFyrweDVMYEbWmIUakotcT(exception)
  return CsunNxhvXFyrweDVMYEbWmIUakotiz
 def GetBcPlayerUrl(CsunNxhvXFyrweDVMYEbWmIUakotlc):
  CsunNxhvXFyrweDVMYEbWmIUakotid=''
  try:
   CsunNxhvXFyrweDVMYEbWmIUakotJQ=CsunNxhvXFyrweDVMYEbWmIUakotlc.GetMainJspath()
   if CsunNxhvXFyrweDVMYEbWmIUakotJQ=='':return CsunNxhvXFyrweDVMYEbWmIUakotid
   CsunNxhvXFyrweDVMYEbWmIUakotlA=CsunNxhvXFyrweDVMYEbWmIUakotlc.callRequestCookies('Get',CsunNxhvXFyrweDVMYEbWmIUakotJQ,payload=CsunNxhvXFyrweDVMYEbWmIUakotcz,params=CsunNxhvXFyrweDVMYEbWmIUakotcz,headers=CsunNxhvXFyrweDVMYEbWmIUakotcz,cookies=CsunNxhvXFyrweDVMYEbWmIUakotcz)
   CsunNxhvXFyrweDVMYEbWmIUakotiK=CsunNxhvXFyrweDVMYEbWmIUakotlA.text
   CsunNxhvXFyrweDVMYEbWmIUakotiO =re.findall('bc:\s*\"\d{13}\",\s*player:\s*\".{9}\"',CsunNxhvXFyrweDVMYEbWmIUakotiK)[0]
   CsunNxhvXFyrweDVMYEbWmIUakotiO =CsunNxhvXFyrweDVMYEbWmIUakotiO.replace('bc','"bc"')
   CsunNxhvXFyrweDVMYEbWmIUakotiO =CsunNxhvXFyrweDVMYEbWmIUakotiO.replace('player','"player"')
   CsunNxhvXFyrweDVMYEbWmIUakotiO ='{'+CsunNxhvXFyrweDVMYEbWmIUakotiO+'}'
   CsunNxhvXFyrweDVMYEbWmIUakotiO =json.loads(CsunNxhvXFyrweDVMYEbWmIUakotiO)
   bc =CsunNxhvXFyrweDVMYEbWmIUakotiO['bc']
   CsunNxhvXFyrweDVMYEbWmIUakotiS =CsunNxhvXFyrweDVMYEbWmIUakotiO['player']
   CsunNxhvXFyrweDVMYEbWmIUakotid="%s/%s/%s_default/index.min.js"%(CsunNxhvXFyrweDVMYEbWmIUakotlc.BC_DOMAIN,bc,CsunNxhvXFyrweDVMYEbWmIUakotiS)
  except CsunNxhvXFyrweDVMYEbWmIUakotcS as exception:
   CsunNxhvXFyrweDVMYEbWmIUakotcT(exception)
  return CsunNxhvXFyrweDVMYEbWmIUakotid
 def GetPolicyKey(CsunNxhvXFyrweDVMYEbWmIUakotlc):
  CsunNxhvXFyrweDVMYEbWmIUakotiB=policykey=''
  try:
   CsunNxhvXFyrweDVMYEbWmIUakotJQ=CsunNxhvXFyrweDVMYEbWmIUakotlc.GetBcPlayerUrl()
   if CsunNxhvXFyrweDVMYEbWmIUakotJQ=='':return CsunNxhvXFyrweDVMYEbWmIUakotiB,CsunNxhvXFyrweDVMYEbWmIUakotig
   CsunNxhvXFyrweDVMYEbWmIUakotlA=CsunNxhvXFyrweDVMYEbWmIUakotlc.callRequestCookies('Get',CsunNxhvXFyrweDVMYEbWmIUakotJQ,payload=CsunNxhvXFyrweDVMYEbWmIUakotcz,params=CsunNxhvXFyrweDVMYEbWmIUakotcz,headers=CsunNxhvXFyrweDVMYEbWmIUakotcz,cookies=CsunNxhvXFyrweDVMYEbWmIUakotcz)
   CsunNxhvXFyrweDVMYEbWmIUakotiK=CsunNxhvXFyrweDVMYEbWmIUakotlA.text
   CsunNxhvXFyrweDVMYEbWmIUakotiT =re.findall('accountId:\s*\"\d{13}\",\s*policyKey:\s*\".[^(){}]{100,300}\"',CsunNxhvXFyrweDVMYEbWmIUakotiK)[0]
   CsunNxhvXFyrweDVMYEbWmIUakotiT =CsunNxhvXFyrweDVMYEbWmIUakotiT.replace('accountId','"accountId"')
   CsunNxhvXFyrweDVMYEbWmIUakotiT =CsunNxhvXFyrweDVMYEbWmIUakotiT.replace('policyKey','"policyKey"')
   CsunNxhvXFyrweDVMYEbWmIUakotiT ='{'+CsunNxhvXFyrweDVMYEbWmIUakotiT+'}'
   CsunNxhvXFyrweDVMYEbWmIUakotiA=json.loads(CsunNxhvXFyrweDVMYEbWmIUakotiT)
   CsunNxhvXFyrweDVMYEbWmIUakotiB =CsunNxhvXFyrweDVMYEbWmIUakotiA['accountId']
   CsunNxhvXFyrweDVMYEbWmIUakotig =CsunNxhvXFyrweDVMYEbWmIUakotiA['policyKey']
  except CsunNxhvXFyrweDVMYEbWmIUakotcS as exception:
   CsunNxhvXFyrweDVMYEbWmIUakotcT(exception)
  return CsunNxhvXFyrweDVMYEbWmIUakotiB,CsunNxhvXFyrweDVMYEbWmIUakotig
 def GetBroadURL(CsunNxhvXFyrweDVMYEbWmIUakotlc,CsunNxhvXFyrweDVMYEbWmIUakotJq,mediatype,CsunNxhvXFyrweDVMYEbWmIUakotQf):
  CsunNxhvXFyrweDVMYEbWmIUakotiG=''
  try:
   if mediatype=='live':
    CsunNxhvXFyrweDVMYEbWmIUakotJq='ref%3A'+CsunNxhvXFyrweDVMYEbWmIUakotJq
   else:
    CsunNxhvXFyrweDVMYEbWmIUakotJq=CsunNxhvXFyrweDVMYEbWmIUakotlc.GetReplay_UrlId(CsunNxhvXFyrweDVMYEbWmIUakotJq,CsunNxhvXFyrweDVMYEbWmIUakotQf)
    if CsunNxhvXFyrweDVMYEbWmIUakotJq=='':return CsunNxhvXFyrweDVMYEbWmIUakotiG
   CsunNxhvXFyrweDVMYEbWmIUakotJQ=CsunNxhvXFyrweDVMYEbWmIUakotlc.PLAYER_DOMAIN+'/playback/v1/accounts/'+CsunNxhvXFyrweDVMYEbWmIUakotlc.SPOTV_ACCOUNTID+'/videos/'+CsunNxhvXFyrweDVMYEbWmIUakotJq
   CsunNxhvXFyrweDVMYEbWmIUakotip={'accept':'application/json;pk='+CsunNxhvXFyrweDVMYEbWmIUakotlc.SPOTV_POLICYKEY}
   CsunNxhvXFyrweDVMYEbWmIUakotlA=CsunNxhvXFyrweDVMYEbWmIUakotlc.callRequestCookies('Get',CsunNxhvXFyrweDVMYEbWmIUakotJQ,payload=CsunNxhvXFyrweDVMYEbWmIUakotcz,params=CsunNxhvXFyrweDVMYEbWmIUakotcz,headers=CsunNxhvXFyrweDVMYEbWmIUakotip,cookies=CsunNxhvXFyrweDVMYEbWmIUakotcz)
   CsunNxhvXFyrweDVMYEbWmIUakotiH=json.loads(CsunNxhvXFyrweDVMYEbWmIUakotlA.text)
   CsunNxhvXFyrweDVMYEbWmIUakotiG=CsunNxhvXFyrweDVMYEbWmIUakotiH['sources'][0]['src']
   if mediatype=='live':
    CsunNxhvXFyrweDVMYEbWmIUakotiG=CsunNxhvXFyrweDVMYEbWmIUakotiG.replace('playlist.m3u8','playlist_dvr.m3u8')
   CsunNxhvXFyrweDVMYEbWmIUakotiG=CsunNxhvXFyrweDVMYEbWmIUakotiG.replace('http://','https://')
  except CsunNxhvXFyrweDVMYEbWmIUakotcS as exception:
   CsunNxhvXFyrweDVMYEbWmIUakotcT(exception)
  return CsunNxhvXFyrweDVMYEbWmIUakotiG
 def GetTitleGroupList(CsunNxhvXFyrweDVMYEbWmIUakotlc):
  CsunNxhvXFyrweDVMYEbWmIUakotJl=[]
  CsunNxhvXFyrweDVMYEbWmIUakotiL=CsunNxhvXFyrweDVMYEbWmIUakotcK
  try:
   CsunNxhvXFyrweDVMYEbWmIUakotJQ=CsunNxhvXFyrweDVMYEbWmIUakotlc.API_DOMAIN+'/api/v2/home/web'
   CsunNxhvXFyrweDVMYEbWmIUakotlA=CsunNxhvXFyrweDVMYEbWmIUakotlc.callRequestCookies('Get',CsunNxhvXFyrweDVMYEbWmIUakotJQ,payload=CsunNxhvXFyrweDVMYEbWmIUakotcz,params=CsunNxhvXFyrweDVMYEbWmIUakotcz,headers=CsunNxhvXFyrweDVMYEbWmIUakotcz,cookies=CsunNxhvXFyrweDVMYEbWmIUakotcz)
   CsunNxhvXFyrweDVMYEbWmIUakotlp=json.loads(CsunNxhvXFyrweDVMYEbWmIUakotlA.text)
   for CsunNxhvXFyrweDVMYEbWmIUakotJc in CsunNxhvXFyrweDVMYEbWmIUakotlp:
    CsunNxhvXFyrweDVMYEbWmIUakotJf={}
    CsunNxhvXFyrweDVMYEbWmIUakotJf['mediatype']='episode'
    if CsunNxhvXFyrweDVMYEbWmIUakotcd(CsunNxhvXFyrweDVMYEbWmIUakotJc['type'])=='3':
     CsunNxhvXFyrweDVMYEbWmIUakotiR=''
     for CsunNxhvXFyrweDVMYEbWmIUakotij in CsunNxhvXFyrweDVMYEbWmIUakotJc['data']['list']:
      CsunNxhvXFyrweDVMYEbWmIUakotiq='[%s] %s vs %s\n<%s>\n\n'%(CsunNxhvXFyrweDVMYEbWmIUakotij['gameDesc']['roundName'],CsunNxhvXFyrweDVMYEbWmIUakotij['gameDesc']['homeNameShort'],CsunNxhvXFyrweDVMYEbWmIUakotij['gameDesc']['awayNameShort'],CsunNxhvXFyrweDVMYEbWmIUakotij['gameDesc']['beginDate'])
      CsunNxhvXFyrweDVMYEbWmIUakotiR+=CsunNxhvXFyrweDVMYEbWmIUakotiq
     CsunNxhvXFyrweDVMYEbWmIUakotJP={'title':CsunNxhvXFyrweDVMYEbWmIUakotJc['title'],'logo':CsunNxhvXFyrweDVMYEbWmIUakotJc['logo'],'reagueId':CsunNxhvXFyrweDVMYEbWmIUakotcd(CsunNxhvXFyrweDVMYEbWmIUakotJc['destId']),'subGame':CsunNxhvXFyrweDVMYEbWmIUakotiR,'info':CsunNxhvXFyrweDVMYEbWmIUakotJf}
     CsunNxhvXFyrweDVMYEbWmIUakotJl.append(CsunNxhvXFyrweDVMYEbWmIUakotJP)
     if CsunNxhvXFyrweDVMYEbWmIUakotcd(CsunNxhvXFyrweDVMYEbWmIUakotJc['destId'])=='13':CsunNxhvXFyrweDVMYEbWmIUakotiL=CsunNxhvXFyrweDVMYEbWmIUakotcO
   if CsunNxhvXFyrweDVMYEbWmIUakotiL==CsunNxhvXFyrweDVMYEbWmIUakotcK:
    CsunNxhvXFyrweDVMYEbWmIUakotJf={'mediatype':'episode'}
    CsunNxhvXFyrweDVMYEbWmIUakotJP={'title':'UFC','logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200928/a643c7cf1c285fb0b4469c07d4c09c28.png','reagueId':'13','subGame':'','info':CsunNxhvXFyrweDVMYEbWmIUakotJf}
    CsunNxhvXFyrweDVMYEbWmIUakotJl.append(CsunNxhvXFyrweDVMYEbWmIUakotJP)
  except CsunNxhvXFyrweDVMYEbWmIUakotcS as exception:
   CsunNxhvXFyrweDVMYEbWmIUakotcT(exception)
  return CsunNxhvXFyrweDVMYEbWmIUakotJl
 def GetPopularGroupList(CsunNxhvXFyrweDVMYEbWmIUakotlc):
  CsunNxhvXFyrweDVMYEbWmIUakotJl=[]
  try:
   CsunNxhvXFyrweDVMYEbWmIUakotJQ=CsunNxhvXFyrweDVMYEbWmIUakotlc.API_DOMAIN+'/api/v2/home/web'
   CsunNxhvXFyrweDVMYEbWmIUakotlA=CsunNxhvXFyrweDVMYEbWmIUakotlc.callRequestCookies('Get',CsunNxhvXFyrweDVMYEbWmIUakotJQ,payload=CsunNxhvXFyrweDVMYEbWmIUakotcz,params=CsunNxhvXFyrweDVMYEbWmIUakotcz,headers=CsunNxhvXFyrweDVMYEbWmIUakotcz,cookies=CsunNxhvXFyrweDVMYEbWmIUakotcz)
   CsunNxhvXFyrweDVMYEbWmIUakotlp=json.loads(CsunNxhvXFyrweDVMYEbWmIUakotlA.text)
   for CsunNxhvXFyrweDVMYEbWmIUakotJc in CsunNxhvXFyrweDVMYEbWmIUakotlp:
    CsunNxhvXFyrweDVMYEbWmIUakotJf={}
    CsunNxhvXFyrweDVMYEbWmIUakotJf['mediatype']='episode'
    if CsunNxhvXFyrweDVMYEbWmIUakotcd(CsunNxhvXFyrweDVMYEbWmIUakotJc['type'])=='1' and CsunNxhvXFyrweDVMYEbWmIUakotcd(CsunNxhvXFyrweDVMYEbWmIUakotJc['destId'])=='4':
     for CsunNxhvXFyrweDVMYEbWmIUakotij in CsunNxhvXFyrweDVMYEbWmIUakotJc['data']['list']:
      CsunNxhvXFyrweDVMYEbWmIUakotJf={}
      CsunNxhvXFyrweDVMYEbWmIUakotJf['mediatype']='video'
      CsunNxhvXFyrweDVMYEbWmIUakotQl =CsunNxhvXFyrweDVMYEbWmIUakotij['title']
      CsunNxhvXFyrweDVMYEbWmIUakotQJ =CsunNxhvXFyrweDVMYEbWmIUakotij['id']
      CsunNxhvXFyrweDVMYEbWmIUakotQi =CsunNxhvXFyrweDVMYEbWmIUakotij['vtype']
      CsunNxhvXFyrweDVMYEbWmIUakotQc =CsunNxhvXFyrweDVMYEbWmIUakotij['imgUrl']
      CsunNxhvXFyrweDVMYEbWmIUakotQf =CsunNxhvXFyrweDVMYEbWmIUakotij['vtypeId']
      CsunNxhvXFyrweDVMYEbWmIUakotJf['duration'] =CsunNxhvXFyrweDVMYEbWmIUakotcA(CsunNxhvXFyrweDVMYEbWmIUakotij['duration']/1000)
      CsunNxhvXFyrweDVMYEbWmIUakotJP={'vodTitle':CsunNxhvXFyrweDVMYEbWmIUakotQl,'vodId':CsunNxhvXFyrweDVMYEbWmIUakotQJ,'vodType':CsunNxhvXFyrweDVMYEbWmIUakotQi,'thumbnail':CsunNxhvXFyrweDVMYEbWmIUakotQc,'info':CsunNxhvXFyrweDVMYEbWmIUakotJf,'vtypeId':CsunNxhvXFyrweDVMYEbWmIUakotcd(CsunNxhvXFyrweDVMYEbWmIUakotQf)}
      CsunNxhvXFyrweDVMYEbWmIUakotJl.append(CsunNxhvXFyrweDVMYEbWmIUakotJP)
  except CsunNxhvXFyrweDVMYEbWmIUakotcS as exception:
   CsunNxhvXFyrweDVMYEbWmIUakotcT(exception)
  return CsunNxhvXFyrweDVMYEbWmIUakotJl
 def GetSeasonList(CsunNxhvXFyrweDVMYEbWmIUakotlc,leagueId):
  CsunNxhvXFyrweDVMYEbWmIUakotJl=[]
  CsunNxhvXFyrweDVMYEbWmIUakotQP=CsunNxhvXFyrweDVMYEbWmIUakotQz=''
  try:
   CsunNxhvXFyrweDVMYEbWmIUakotJQ=CsunNxhvXFyrweDVMYEbWmIUakotlc.API_DOMAIN+'/api/v2/game/league/'+leagueId
   CsunNxhvXFyrweDVMYEbWmIUakotlA=CsunNxhvXFyrweDVMYEbWmIUakotlc.callRequestCookies('Get',CsunNxhvXFyrweDVMYEbWmIUakotJQ,payload=CsunNxhvXFyrweDVMYEbWmIUakotcz,params=CsunNxhvXFyrweDVMYEbWmIUakotcz,headers=CsunNxhvXFyrweDVMYEbWmIUakotcz,cookies=CsunNxhvXFyrweDVMYEbWmIUakotcz)
   CsunNxhvXFyrweDVMYEbWmIUakotlp=json.loads(CsunNxhvXFyrweDVMYEbWmIUakotlA.text)
   CsunNxhvXFyrweDVMYEbWmIUakotQP=CsunNxhvXFyrweDVMYEbWmIUakotlp['name']
   CsunNxhvXFyrweDVMYEbWmIUakotQz=CsunNxhvXFyrweDVMYEbWmIUakotcd(CsunNxhvXFyrweDVMYEbWmIUakotlp['gameTypeId'])
  except CsunNxhvXFyrweDVMYEbWmIUakotcS as exception:
   CsunNxhvXFyrweDVMYEbWmIUakotcT(exception)
   return CsunNxhvXFyrweDVMYEbWmIUakotJl
  if CsunNxhvXFyrweDVMYEbWmIUakotQz=='2':
   try:
    CsunNxhvXFyrweDVMYEbWmIUakotJQ=CsunNxhvXFyrweDVMYEbWmIUakotlc.API_DOMAIN+'/api/v2/year/'+leagueId
    CsunNxhvXFyrweDVMYEbWmIUakotlA=CsunNxhvXFyrweDVMYEbWmIUakotlc.callRequestCookies('Get',CsunNxhvXFyrweDVMYEbWmIUakotJQ,payload=CsunNxhvXFyrweDVMYEbWmIUakotcz,params=CsunNxhvXFyrweDVMYEbWmIUakotcz,headers=CsunNxhvXFyrweDVMYEbWmIUakotcz,cookies=CsunNxhvXFyrweDVMYEbWmIUakotcz)
    CsunNxhvXFyrweDVMYEbWmIUakotlp=json.loads(CsunNxhvXFyrweDVMYEbWmIUakotlA.text)
    for CsunNxhvXFyrweDVMYEbWmIUakotJc in CsunNxhvXFyrweDVMYEbWmIUakotlp:
     CsunNxhvXFyrweDVMYEbWmIUakotJf={}
     CsunNxhvXFyrweDVMYEbWmIUakotJf['mediatype']='episode'
     CsunNxhvXFyrweDVMYEbWmIUakotJP={'reagueName':CsunNxhvXFyrweDVMYEbWmIUakotQP,'gameTypeId':CsunNxhvXFyrweDVMYEbWmIUakotQz,'seasonName':CsunNxhvXFyrweDVMYEbWmIUakotcd(CsunNxhvXFyrweDVMYEbWmIUakotJc),'seasonId':CsunNxhvXFyrweDVMYEbWmIUakotcd(CsunNxhvXFyrweDVMYEbWmIUakotJc),'info':CsunNxhvXFyrweDVMYEbWmIUakotJf}
     CsunNxhvXFyrweDVMYEbWmIUakotJl.append(CsunNxhvXFyrweDVMYEbWmIUakotJP)
   except CsunNxhvXFyrweDVMYEbWmIUakotcS as exception:
    CsunNxhvXFyrweDVMYEbWmIUakotcT(exception)
    return[]
  else:
   try:
    CsunNxhvXFyrweDVMYEbWmIUakotJQ=CsunNxhvXFyrweDVMYEbWmIUakotlc.API_DOMAIN+'/api/v2/season/'+leagueId
    CsunNxhvXFyrweDVMYEbWmIUakotlA=CsunNxhvXFyrweDVMYEbWmIUakotlc.callRequestCookies('Get',CsunNxhvXFyrweDVMYEbWmIUakotJQ,payload=CsunNxhvXFyrweDVMYEbWmIUakotcz,params=CsunNxhvXFyrweDVMYEbWmIUakotcz,headers=CsunNxhvXFyrweDVMYEbWmIUakotcz,cookies=CsunNxhvXFyrweDVMYEbWmIUakotcz)
    CsunNxhvXFyrweDVMYEbWmIUakotlp=json.loads(CsunNxhvXFyrweDVMYEbWmIUakotlA.text)
    for CsunNxhvXFyrweDVMYEbWmIUakotJc in CsunNxhvXFyrweDVMYEbWmIUakotlp:
     CsunNxhvXFyrweDVMYEbWmIUakotJf={}
     CsunNxhvXFyrweDVMYEbWmIUakotJf['mediatype']='episode'
     CsunNxhvXFyrweDVMYEbWmIUakotJP={'reagueName':CsunNxhvXFyrweDVMYEbWmIUakotQP,'gameTypeId':CsunNxhvXFyrweDVMYEbWmIUakotQz,'seasonName':CsunNxhvXFyrweDVMYEbWmIUakotJc['name'],'seasonId':CsunNxhvXFyrweDVMYEbWmIUakotcd(CsunNxhvXFyrweDVMYEbWmIUakotJc['id']),'info':CsunNxhvXFyrweDVMYEbWmIUakotJf}
     CsunNxhvXFyrweDVMYEbWmIUakotJl.append(CsunNxhvXFyrweDVMYEbWmIUakotJP)
   except CsunNxhvXFyrweDVMYEbWmIUakotcS as exception:
    CsunNxhvXFyrweDVMYEbWmIUakotcT(exception)
    return[]
  return CsunNxhvXFyrweDVMYEbWmIUakotJl
 def GetGameList(CsunNxhvXFyrweDVMYEbWmIUakotlc,CsunNxhvXFyrweDVMYEbWmIUakotQz,leagueId,seasonId,page_int):
  CsunNxhvXFyrweDVMYEbWmIUakotJl=[]
  CsunNxhvXFyrweDVMYEbWmIUakotQK=CsunNxhvXFyrweDVMYEbWmIUakotcK
  try:
   CsunNxhvXFyrweDVMYEbWmIUakotJQ=CsunNxhvXFyrweDVMYEbWmIUakotlc.API_DOMAIN+'/api/v2/vod/league/detail'
   CsunNxhvXFyrweDVMYEbWmIUakotQT={'gameType':CsunNxhvXFyrweDVMYEbWmIUakotQz,'leagueId':leagueId,'seasonId':seasonId if CsunNxhvXFyrweDVMYEbWmIUakotQz!='2' else '','teamId':'','roundId':'','year':'' if CsunNxhvXFyrweDVMYEbWmIUakotQz!='2' else seasonId,'pageNo':CsunNxhvXFyrweDVMYEbWmIUakotcd(page_int)}
   CsunNxhvXFyrweDVMYEbWmIUakotlA=CsunNxhvXFyrweDVMYEbWmIUakotlc.callRequestCookies('Get',CsunNxhvXFyrweDVMYEbWmIUakotJQ,payload=CsunNxhvXFyrweDVMYEbWmIUakotcz,params=CsunNxhvXFyrweDVMYEbWmIUakotQT,headers=CsunNxhvXFyrweDVMYEbWmIUakotcz,cookies=CsunNxhvXFyrweDVMYEbWmIUakotcz)
   CsunNxhvXFyrweDVMYEbWmIUakotlp=json.loads(CsunNxhvXFyrweDVMYEbWmIUakotlA.text)
   CsunNxhvXFyrweDVMYEbWmIUakotJR=CsunNxhvXFyrweDVMYEbWmIUakotlp['list']
   for CsunNxhvXFyrweDVMYEbWmIUakotQd in CsunNxhvXFyrweDVMYEbWmIUakotJR:
    for CsunNxhvXFyrweDVMYEbWmIUakotJc in CsunNxhvXFyrweDVMYEbWmIUakotQd['list']:
     CsunNxhvXFyrweDVMYEbWmIUakotJf={}
     CsunNxhvXFyrweDVMYEbWmIUakotJf['mediatype']='video'
     if CsunNxhvXFyrweDVMYEbWmIUakotJc['gameDesc']['title']==CsunNxhvXFyrweDVMYEbWmIUakotcz or CsunNxhvXFyrweDVMYEbWmIUakotJc['gameDesc']['title']=='':
      CsunNxhvXFyrweDVMYEbWmIUakotJj ='%s vs %s'%(CsunNxhvXFyrweDVMYEbWmIUakotJc['gameDesc']['homeNameShort'],CsunNxhvXFyrweDVMYEbWmIUakotJc['gameDesc']['awayNameShort'])
     else:
      CsunNxhvXFyrweDVMYEbWmIUakotJj =CsunNxhvXFyrweDVMYEbWmIUakotJc['gameDesc']['title']
     CsunNxhvXFyrweDVMYEbWmIUakotQO =CsunNxhvXFyrweDVMYEbWmIUakotJc['gameDesc']['beginDate']
     CsunNxhvXFyrweDVMYEbWmIUakotQS =CsunNxhvXFyrweDVMYEbWmIUakotJc['gameDesc']['id']
     CsunNxhvXFyrweDVMYEbWmIUakotQB =CsunNxhvXFyrweDVMYEbWmIUakotJc['gameDesc']['leagueNameFull']
     CsunNxhvXFyrweDVMYEbWmIUakotQA =CsunNxhvXFyrweDVMYEbWmIUakotJc['gameDesc']['seasonName']
     CsunNxhvXFyrweDVMYEbWmIUakotQg =CsunNxhvXFyrweDVMYEbWmIUakotJc['gameDesc']['roundName']
     CsunNxhvXFyrweDVMYEbWmIUakotQG =CsunNxhvXFyrweDVMYEbWmIUakotJc['gameDesc']['homeName']
     CsunNxhvXFyrweDVMYEbWmIUakotQp =CsunNxhvXFyrweDVMYEbWmIUakotJc['gameDesc']['awayName']
     CsunNxhvXFyrweDVMYEbWmIUakotQH =CsunNxhvXFyrweDVMYEbWmIUakotJc['gameDesc']['homeScore']
     CsunNxhvXFyrweDVMYEbWmIUakotQL =CsunNxhvXFyrweDVMYEbWmIUakotJc['gameDesc']['awayScore']
     CsunNxhvXFyrweDVMYEbWmIUakotQR ='%s\n - %s (%s)\n - %s\n\nhome : %s (Score %s)\n\naway : %s (Score %s)'%(CsunNxhvXFyrweDVMYEbWmIUakotQB,CsunNxhvXFyrweDVMYEbWmIUakotQA,CsunNxhvXFyrweDVMYEbWmIUakotQg,CsunNxhvXFyrweDVMYEbWmIUakotQO,CsunNxhvXFyrweDVMYEbWmIUakotQG,CsunNxhvXFyrweDVMYEbWmIUakotQH,CsunNxhvXFyrweDVMYEbWmIUakotQp,CsunNxhvXFyrweDVMYEbWmIUakotQL)
     CsunNxhvXFyrweDVMYEbWmIUakotJf['plot']=CsunNxhvXFyrweDVMYEbWmIUakotQR
     CsunNxhvXFyrweDVMYEbWmIUakotQj =CsunNxhvXFyrweDVMYEbWmIUakotJc['replayVod']['count']
     CsunNxhvXFyrweDVMYEbWmIUakotQq=CsunNxhvXFyrweDVMYEbWmIUakotJc['highlightVod']['count']
     CsunNxhvXFyrweDVMYEbWmIUakotcl =CsunNxhvXFyrweDVMYEbWmIUakotJc['vods']['count']
     CsunNxhvXFyrweDVMYEbWmIUakotQc='' 
     CsunNxhvXFyrweDVMYEbWmIUakotcJ=CsunNxhvXFyrweDVMYEbWmIUakotQj+CsunNxhvXFyrweDVMYEbWmIUakotQq+CsunNxhvXFyrweDVMYEbWmIUakotcl
     if CsunNxhvXFyrweDVMYEbWmIUakotcJ==0:
      if CsunNxhvXFyrweDVMYEbWmIUakotQz=='2':
       CsunNxhvXFyrweDVMYEbWmIUakotJj='----- %s -----'%(CsunNxhvXFyrweDVMYEbWmIUakotQA)
       CsunNxhvXFyrweDVMYEbWmIUakotQO=''
      else:
       CsunNxhvXFyrweDVMYEbWmIUakotJj+=' - 관련영상 없음'
       CsunNxhvXFyrweDVMYEbWmIUakotJf['plot']+='\n\n ** 관련영상 없음 **'
     else:
      if CsunNxhvXFyrweDVMYEbWmIUakotQj!=0:
       CsunNxhvXFyrweDVMYEbWmIUakotQc =CsunNxhvXFyrweDVMYEbWmIUakotJc['replayVod']['list'][0]['imgUrl']
      elif CsunNxhvXFyrweDVMYEbWmIUakotQq!=0:
       CsunNxhvXFyrweDVMYEbWmIUakotQc =CsunNxhvXFyrweDVMYEbWmIUakotJc['highlightVod']['list'][0]['imgUrl']
      else:
       CsunNxhvXFyrweDVMYEbWmIUakotQc =CsunNxhvXFyrweDVMYEbWmIUakotJc['vods']['list'][0]['imgUrl']
     CsunNxhvXFyrweDVMYEbWmIUakotJP={'gameTitle':CsunNxhvXFyrweDVMYEbWmIUakotJj,'gameId':CsunNxhvXFyrweDVMYEbWmIUakotQS,'beginDate':CsunNxhvXFyrweDVMYEbWmIUakotQO[:11],'thumbnail':CsunNxhvXFyrweDVMYEbWmIUakotQc,'info':CsunNxhvXFyrweDVMYEbWmIUakotJf,'leaguenm':CsunNxhvXFyrweDVMYEbWmIUakotQB,'seasonnm':CsunNxhvXFyrweDVMYEbWmIUakotQA,'roundnm':CsunNxhvXFyrweDVMYEbWmIUakotQg,'totVodCnt':CsunNxhvXFyrweDVMYEbWmIUakotcJ}
     CsunNxhvXFyrweDVMYEbWmIUakotJl.append(CsunNxhvXFyrweDVMYEbWmIUakotJP)
   if CsunNxhvXFyrweDVMYEbWmIUakotQz=='2':
    if CsunNxhvXFyrweDVMYEbWmIUakotlp['count']>page_int*CsunNxhvXFyrweDVMYEbWmIUakotlc.GAMELIST_LIMIT:CsunNxhvXFyrweDVMYEbWmIUakotQK=CsunNxhvXFyrweDVMYEbWmIUakotcO
   else:
    if CsunNxhvXFyrweDVMYEbWmIUakotlp['list'][0]['count']>page_int*CsunNxhvXFyrweDVMYEbWmIUakotlc.GAMELIST_LIMIT:CsunNxhvXFyrweDVMYEbWmIUakotQK=CsunNxhvXFyrweDVMYEbWmIUakotcO
  except CsunNxhvXFyrweDVMYEbWmIUakotcS as exception:
   CsunNxhvXFyrweDVMYEbWmIUakotcT(exception)
  return CsunNxhvXFyrweDVMYEbWmIUakotJl,CsunNxhvXFyrweDVMYEbWmIUakotQK
 def GetGameVodList(CsunNxhvXFyrweDVMYEbWmIUakotlc,CsunNxhvXFyrweDVMYEbWmIUakotQS):
  CsunNxhvXFyrweDVMYEbWmIUakotJl=[]
  CsunNxhvXFyrweDVMYEbWmIUakotci=''
  try:
   CsunNxhvXFyrweDVMYEbWmIUakotJQ=CsunNxhvXFyrweDVMYEbWmIUakotlc.API_DOMAIN+'/api/v2/vod/game'
   CsunNxhvXFyrweDVMYEbWmIUakotQT={'gameId':CsunNxhvXFyrweDVMYEbWmIUakotQS,'pageItem':'1000'}
   CsunNxhvXFyrweDVMYEbWmIUakotlA=CsunNxhvXFyrweDVMYEbWmIUakotlc.callRequestCookies('Get',CsunNxhvXFyrweDVMYEbWmIUakotJQ,payload=CsunNxhvXFyrweDVMYEbWmIUakotcz,params=CsunNxhvXFyrweDVMYEbWmIUakotQT,headers=CsunNxhvXFyrweDVMYEbWmIUakotcz,cookies=CsunNxhvXFyrweDVMYEbWmIUakotcz)
   CsunNxhvXFyrweDVMYEbWmIUakotlp=json.loads(CsunNxhvXFyrweDVMYEbWmIUakotlA.text)
   CsunNxhvXFyrweDVMYEbWmIUakotQd=CsunNxhvXFyrweDVMYEbWmIUakotlp['list']
   for CsunNxhvXFyrweDVMYEbWmIUakotJc in CsunNxhvXFyrweDVMYEbWmIUakotQd:
    CsunNxhvXFyrweDVMYEbWmIUakotJf={}
    CsunNxhvXFyrweDVMYEbWmIUakotJf['mediatype']='video'
    CsunNxhvXFyrweDVMYEbWmIUakotQl =CsunNxhvXFyrweDVMYEbWmIUakotJc['title']
    CsunNxhvXFyrweDVMYEbWmIUakotQJ =CsunNxhvXFyrweDVMYEbWmIUakotJc['id']
    CsunNxhvXFyrweDVMYEbWmIUakotQi =CsunNxhvXFyrweDVMYEbWmIUakotJc['vtype']
    CsunNxhvXFyrweDVMYEbWmIUakotQc =CsunNxhvXFyrweDVMYEbWmIUakotJc['imgUrl']
    CsunNxhvXFyrweDVMYEbWmIUakotQf =CsunNxhvXFyrweDVMYEbWmIUakotJc['vtypeId']
    CsunNxhvXFyrweDVMYEbWmIUakotJf['duration'] =CsunNxhvXFyrweDVMYEbWmIUakotcA(CsunNxhvXFyrweDVMYEbWmIUakotJc['duration']/1000)
    CsunNxhvXFyrweDVMYEbWmIUakotJP={'vodTitle':CsunNxhvXFyrweDVMYEbWmIUakotQl,'vodId':CsunNxhvXFyrweDVMYEbWmIUakotQJ,'vodType':CsunNxhvXFyrweDVMYEbWmIUakotQi,'thumbnail':CsunNxhvXFyrweDVMYEbWmIUakotQc,'info':CsunNxhvXFyrweDVMYEbWmIUakotJf,'vtypeId':CsunNxhvXFyrweDVMYEbWmIUakotcd(CsunNxhvXFyrweDVMYEbWmIUakotQf)}
    CsunNxhvXFyrweDVMYEbWmIUakotJl.append(CsunNxhvXFyrweDVMYEbWmIUakotJP)
  except CsunNxhvXFyrweDVMYEbWmIUakotcS as exception:
   CsunNxhvXFyrweDVMYEbWmIUakotcT(exception)
  return CsunNxhvXFyrweDVMYEbWmIUakotJl
 def GetReplay_UrlId(CsunNxhvXFyrweDVMYEbWmIUakotlc,CsunNxhvXFyrweDVMYEbWmIUakotci,CsunNxhvXFyrweDVMYEbWmIUakotQf):
  CsunNxhvXFyrweDVMYEbWmIUakotcQ=CsunNxhvXFyrweDVMYEbWmIUakotJq=''
  CsunNxhvXFyrweDVMYEbWmIUakotcf=''
  try:
   CsunNxhvXFyrweDVMYEbWmIUakotJQ=CsunNxhvXFyrweDVMYEbWmIUakotlc.API_DOMAIN+'/api/v2/vod/'+CsunNxhvXFyrweDVMYEbWmIUakotci
   CsunNxhvXFyrweDVMYEbWmIUakotlA=CsunNxhvXFyrweDVMYEbWmIUakotlc.callRequestCookies('Get',CsunNxhvXFyrweDVMYEbWmIUakotJQ,payload=CsunNxhvXFyrweDVMYEbWmIUakotcz,params=CsunNxhvXFyrweDVMYEbWmIUakotcz,headers=CsunNxhvXFyrweDVMYEbWmIUakotcz,cookies=CsunNxhvXFyrweDVMYEbWmIUakotcz)
   CsunNxhvXFyrweDVMYEbWmIUakotlp=json.loads(CsunNxhvXFyrweDVMYEbWmIUakotlA.text)
   CsunNxhvXFyrweDVMYEbWmIUakotcQ =CsunNxhvXFyrweDVMYEbWmIUakotlp['clipId']
   CsunNxhvXFyrweDVMYEbWmIUakotJq=CsunNxhvXFyrweDVMYEbWmIUakotlp['videoId']
   CsunNxhvXFyrweDVMYEbWmIUakotcf=CsunNxhvXFyrweDVMYEbWmIUakotcQ
   if CsunNxhvXFyrweDVMYEbWmIUakotlc.CheckSubEnd()or CsunNxhvXFyrweDVMYEbWmIUakotQf!='1':CsunNxhvXFyrweDVMYEbWmIUakotcf=CsunNxhvXFyrweDVMYEbWmIUakotJq 
  except CsunNxhvXFyrweDVMYEbWmIUakotcS as exception:
   CsunNxhvXFyrweDVMYEbWmIUakotcT(exception)
  return CsunNxhvXFyrweDVMYEbWmIUakotcf
# Created by pyminifier (https://github.com/liftoff/pyminifier)
