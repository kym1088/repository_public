__author__="NightRain"
lBqLpecaUTiVzGwgXortPfnxWQsHMK=object
lBqLpecaUTiVzGwgXortPfnxWQsHME=None
lBqLpecaUTiVzGwgXortPfnxWQsHMk=False
lBqLpecaUTiVzGwgXortPfnxWQsHMj=True
lBqLpecaUTiVzGwgXortPfnxWQsHMR=int
lBqLpecaUTiVzGwgXortPfnxWQsHMJ=len
lBqLpecaUTiVzGwgXortPfnxWQsHMh=str
lBqLpecaUTiVzGwgXortPfnxWQsHMA=open
lBqLpecaUTiVzGwgXortPfnxWQsHMv=Exception
lBqLpecaUTiVzGwgXortPfnxWQsHMy=print
lBqLpecaUTiVzGwgXortPfnxWQsHMD=dict
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmc.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
lBqLpecaUTiVzGwgXortPfnxWQsHIY=[{'title':'TV 채널','mode':'LIVE_GROUP'},{'title':'Live중계 (독점,현지)','mode':'ELIVE_GROUP'},{'title':'-----------------','mode':'XXX'},{'title':'인기영상5','mode':'POP_GROUP'},{'title':'VOD 영상','mode':'VOD_GROUP'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH'}]
lBqLpecaUTiVzGwgXortPfnxWQsHIm ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36'
lBqLpecaUTiVzGwgXortPfnxWQsHIM=xbmc.translatePath(os.path.join(__profile__,'spotv_cookies.json'))
from spotvCore import*
class lBqLpecaUTiVzGwgXortPfnxWQsHIC(lBqLpecaUTiVzGwgXortPfnxWQsHMK):
 def __init__(lBqLpecaUTiVzGwgXortPfnxWQsHIK,lBqLpecaUTiVzGwgXortPfnxWQsHIE,lBqLpecaUTiVzGwgXortPfnxWQsHIk,lBqLpecaUTiVzGwgXortPfnxWQsHIj):
  lBqLpecaUTiVzGwgXortPfnxWQsHIK._addon_url =lBqLpecaUTiVzGwgXortPfnxWQsHIE
  lBqLpecaUTiVzGwgXortPfnxWQsHIK._addon_handle=lBqLpecaUTiVzGwgXortPfnxWQsHIk
  lBqLpecaUTiVzGwgXortPfnxWQsHIK.main_params =lBqLpecaUTiVzGwgXortPfnxWQsHIj
  lBqLpecaUTiVzGwgXortPfnxWQsHIK.SpotvObj =wmXlvOcyJeIxCzKruUPTEQDBShLWYt() 
 def addon_noti(lBqLpecaUTiVzGwgXortPfnxWQsHIK,sting):
  try:
   lBqLpecaUTiVzGwgXortPfnxWQsHIJ=xbmcgui.Dialog()
   lBqLpecaUTiVzGwgXortPfnxWQsHIJ.notification(__addonname__,sting)
  except:
   lBqLpecaUTiVzGwgXortPfnxWQsHME
 def addon_log(lBqLpecaUTiVzGwgXortPfnxWQsHIK,string,isDebug=lBqLpecaUTiVzGwgXortPfnxWQsHMk):
  try:
   lBqLpecaUTiVzGwgXortPfnxWQsHIh=string.encode('utf-8','ignore')
  except:
   lBqLpecaUTiVzGwgXortPfnxWQsHIh='addonException: addon_log'
  if isDebug:lBqLpecaUTiVzGwgXortPfnxWQsHIA=xbmc.LOGDEBUG
  else:lBqLpecaUTiVzGwgXortPfnxWQsHIA=xbmc.LOGNOTICE
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,lBqLpecaUTiVzGwgXortPfnxWQsHIh),level=lBqLpecaUTiVzGwgXortPfnxWQsHIA)
 def get_keyboard_input(lBqLpecaUTiVzGwgXortPfnxWQsHIK,lBqLpecaUTiVzGwgXortPfnxWQsHIO):
  lBqLpecaUTiVzGwgXortPfnxWQsHIv=lBqLpecaUTiVzGwgXortPfnxWQsHME
  kb=xbmc.Keyboard()
  kb.setHeading(lBqLpecaUTiVzGwgXortPfnxWQsHIO)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   lBqLpecaUTiVzGwgXortPfnxWQsHIv=kb.getText()
  return lBqLpecaUTiVzGwgXortPfnxWQsHIv
 def get_settings_login_info(lBqLpecaUTiVzGwgXortPfnxWQsHIK):
  lBqLpecaUTiVzGwgXortPfnxWQsHIy =__addon__.getSetting('id')
  lBqLpecaUTiVzGwgXortPfnxWQsHID =__addon__.getSetting('pw')
  return(lBqLpecaUTiVzGwgXortPfnxWQsHIy,lBqLpecaUTiVzGwgXortPfnxWQsHID)
 def set_winCredential(lBqLpecaUTiVzGwgXortPfnxWQsHIK,credential):
  lBqLpecaUTiVzGwgXortPfnxWQsHIu=xbmcgui.Window(10000)
  lBqLpecaUTiVzGwgXortPfnxWQsHIu.setProperty('SPOTV_M_SESSIONID',credential.get('spotv_sessionid'))
  lBqLpecaUTiVzGwgXortPfnxWQsHIu.setProperty('SPOTV_M_SESSION',credential.get('spotv_session'))
  lBqLpecaUTiVzGwgXortPfnxWQsHIu.setProperty('SPOTV_M_ACCOUNTID',credential.get('spotv_accountId'))
  lBqLpecaUTiVzGwgXortPfnxWQsHIu.setProperty('SPOTV_M_POLICYKEY',credential.get('spotv_policyKey'))
  lBqLpecaUTiVzGwgXortPfnxWQsHIu.setProperty('SPOTV_M_SUBEND',credential.get('spotv_subend'))
  lBqLpecaUTiVzGwgXortPfnxWQsHIu.setProperty('SPOTV_M_LOGINTIME',lBqLpecaUTiVzGwgXortPfnxWQsHIK.SpotvObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(lBqLpecaUTiVzGwgXortPfnxWQsHIK):
  lBqLpecaUTiVzGwgXortPfnxWQsHIu=xbmcgui.Window(10000)
  lBqLpecaUTiVzGwgXortPfnxWQsHIF={'spotv_sessionid':lBqLpecaUTiVzGwgXortPfnxWQsHIu.getProperty('SPOTV_M_SESSIONID'),'spotv_session':lBqLpecaUTiVzGwgXortPfnxWQsHIu.getProperty('SPOTV_M_SESSION'),'spotv_accountId':lBqLpecaUTiVzGwgXortPfnxWQsHIu.getProperty('SPOTV_M_ACCOUNTID'),'spotv_policyKey':lBqLpecaUTiVzGwgXortPfnxWQsHIu.getProperty('SPOTV_M_POLICYKEY'),'spotv_subend':lBqLpecaUTiVzGwgXortPfnxWQsHIu.getProperty('SPOTV_M_SUBEND')}
  return lBqLpecaUTiVzGwgXortPfnxWQsHIF
 def add_dir(lBqLpecaUTiVzGwgXortPfnxWQsHIK,label,sublabel='',img='',infoLabels=lBqLpecaUTiVzGwgXortPfnxWQsHME,isFolder=lBqLpecaUTiVzGwgXortPfnxWQsHMj,params=''):
  lBqLpecaUTiVzGwgXortPfnxWQsHIS='%s?%s'%(lBqLpecaUTiVzGwgXortPfnxWQsHIK._addon_url,urllib.parse.urlencode(params))
  if sublabel:lBqLpecaUTiVzGwgXortPfnxWQsHIO='%s < %s >'%(label,sublabel)
  else: lBqLpecaUTiVzGwgXortPfnxWQsHIO=label
  if not img:img='DefaultFolder.png'
  lBqLpecaUTiVzGwgXortPfnxWQsHIb=xbmcgui.ListItem(lBqLpecaUTiVzGwgXortPfnxWQsHIO)
  lBqLpecaUTiVzGwgXortPfnxWQsHIb.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:lBqLpecaUTiVzGwgXortPfnxWQsHIb.setInfo(type="Video",infoLabels=infoLabels)
  if not isFolder:lBqLpecaUTiVzGwgXortPfnxWQsHIb.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(lBqLpecaUTiVzGwgXortPfnxWQsHIK._addon_handle,lBqLpecaUTiVzGwgXortPfnxWQsHIS,lBqLpecaUTiVzGwgXortPfnxWQsHIb,isFolder)
 def get_selQuality(lBqLpecaUTiVzGwgXortPfnxWQsHIK,etype):
  try:
   lBqLpecaUTiVzGwgXortPfnxWQsHId='selected_quality'
   lBqLpecaUTiVzGwgXortPfnxWQsHIN=[1080,720,540]
   lBqLpecaUTiVzGwgXortPfnxWQsHCI=lBqLpecaUTiVzGwgXortPfnxWQsHMR(__addon__.getSetting(lBqLpecaUTiVzGwgXortPfnxWQsHId))
   return lBqLpecaUTiVzGwgXortPfnxWQsHIN[lBqLpecaUTiVzGwgXortPfnxWQsHCI]
  except:
   lBqLpecaUTiVzGwgXortPfnxWQsHME
  return 1080 
 def dp_Main_List(lBqLpecaUTiVzGwgXortPfnxWQsHIK):
  for lBqLpecaUTiVzGwgXortPfnxWQsHCY in lBqLpecaUTiVzGwgXortPfnxWQsHIY:
   lBqLpecaUTiVzGwgXortPfnxWQsHIO=lBqLpecaUTiVzGwgXortPfnxWQsHCY.get('title')
   lBqLpecaUTiVzGwgXortPfnxWQsHCm={'mode':lBqLpecaUTiVzGwgXortPfnxWQsHCY.get('mode')}
   if lBqLpecaUTiVzGwgXortPfnxWQsHCY.get('mode')=='XXX':
    lBqLpecaUTiVzGwgXortPfnxWQsHCM=lBqLpecaUTiVzGwgXortPfnxWQsHMk
   else:
    lBqLpecaUTiVzGwgXortPfnxWQsHCM=lBqLpecaUTiVzGwgXortPfnxWQsHMj
   lBqLpecaUTiVzGwgXortPfnxWQsHIK.add_dir(lBqLpecaUTiVzGwgXortPfnxWQsHIO,sublabel='',img='',infoLabels=lBqLpecaUTiVzGwgXortPfnxWQsHME,isFolder=lBqLpecaUTiVzGwgXortPfnxWQsHCM,params=lBqLpecaUTiVzGwgXortPfnxWQsHCm)
  if lBqLpecaUTiVzGwgXortPfnxWQsHMJ(lBqLpecaUTiVzGwgXortPfnxWQsHIY)>0:xbmcplugin.endOfDirectory(lBqLpecaUTiVzGwgXortPfnxWQsHIK._addon_handle)
 def dp_MainLeague_List(lBqLpecaUTiVzGwgXortPfnxWQsHIK,args):
  lBqLpecaUTiVzGwgXortPfnxWQsHIK.SpotvObj.SaveCredential(lBqLpecaUTiVzGwgXortPfnxWQsHIK.get_winCredential())
  lBqLpecaUTiVzGwgXortPfnxWQsHCE=lBqLpecaUTiVzGwgXortPfnxWQsHIK.SpotvObj.GetTitleGroupList()
  for lBqLpecaUTiVzGwgXortPfnxWQsHCk in lBqLpecaUTiVzGwgXortPfnxWQsHCE:
   lBqLpecaUTiVzGwgXortPfnxWQsHIO =lBqLpecaUTiVzGwgXortPfnxWQsHCk.get('title')
   lBqLpecaUTiVzGwgXortPfnxWQsHCj =lBqLpecaUTiVzGwgXortPfnxWQsHCk.get('logo')
   lBqLpecaUTiVzGwgXortPfnxWQsHCR =lBqLpecaUTiVzGwgXortPfnxWQsHCk.get('reagueId')
   lBqLpecaUTiVzGwgXortPfnxWQsHCJ =lBqLpecaUTiVzGwgXortPfnxWQsHCk.get('subGame')
   lBqLpecaUTiVzGwgXortPfnxWQsHCh=lBqLpecaUTiVzGwgXortPfnxWQsHCk.get('info')
   lBqLpecaUTiVzGwgXortPfnxWQsHCh['plot']='%s\n\n%s'%(lBqLpecaUTiVzGwgXortPfnxWQsHIO,lBqLpecaUTiVzGwgXortPfnxWQsHCJ)
   lBqLpecaUTiVzGwgXortPfnxWQsHCm={'mode':'LEAGUE_GROUP','reagueId':lBqLpecaUTiVzGwgXortPfnxWQsHCR}
   lBqLpecaUTiVzGwgXortPfnxWQsHIK.add_dir(lBqLpecaUTiVzGwgXortPfnxWQsHIO,sublabel=lBqLpecaUTiVzGwgXortPfnxWQsHME,img=lBqLpecaUTiVzGwgXortPfnxWQsHCj,infoLabels=lBqLpecaUTiVzGwgXortPfnxWQsHCh,isFolder=lBqLpecaUTiVzGwgXortPfnxWQsHMj,params=lBqLpecaUTiVzGwgXortPfnxWQsHCm)
  if lBqLpecaUTiVzGwgXortPfnxWQsHMJ(lBqLpecaUTiVzGwgXortPfnxWQsHCE)>0:xbmcplugin.endOfDirectory(lBqLpecaUTiVzGwgXortPfnxWQsHIK._addon_handle,cacheToDisc=lBqLpecaUTiVzGwgXortPfnxWQsHMk)
 def dp_PopVod_GroupList(lBqLpecaUTiVzGwgXortPfnxWQsHIK,args):
  lBqLpecaUTiVzGwgXortPfnxWQsHIK.SpotvObj.SaveCredential(lBqLpecaUTiVzGwgXortPfnxWQsHIK.get_winCredential())
  lBqLpecaUTiVzGwgXortPfnxWQsHCE=lBqLpecaUTiVzGwgXortPfnxWQsHIK.SpotvObj.GetPopularGroupList()
  for lBqLpecaUTiVzGwgXortPfnxWQsHCk in lBqLpecaUTiVzGwgXortPfnxWQsHCE:
   lBqLpecaUTiVzGwgXortPfnxWQsHCA =lBqLpecaUTiVzGwgXortPfnxWQsHCk.get('vodTitle')
   lBqLpecaUTiVzGwgXortPfnxWQsHCv =lBqLpecaUTiVzGwgXortPfnxWQsHCk.get('vodId')
   lBqLpecaUTiVzGwgXortPfnxWQsHCy =lBqLpecaUTiVzGwgXortPfnxWQsHCk.get('vodType')
   lBqLpecaUTiVzGwgXortPfnxWQsHCj=lBqLpecaUTiVzGwgXortPfnxWQsHCk.get('thumbnail')
   lBqLpecaUTiVzGwgXortPfnxWQsHCD =lBqLpecaUTiVzGwgXortPfnxWQsHCk.get('vtypeId')
   lBqLpecaUTiVzGwgXortPfnxWQsHCh=lBqLpecaUTiVzGwgXortPfnxWQsHCk.get('info')
   lBqLpecaUTiVzGwgXortPfnxWQsHCh['plot']=lBqLpecaUTiVzGwgXortPfnxWQsHCA
   lBqLpecaUTiVzGwgXortPfnxWQsHCm={'mode':'POP_VOD','mediacode':lBqLpecaUTiVzGwgXortPfnxWQsHCv,'mediatype':'vod','vtypeId':lBqLpecaUTiVzGwgXortPfnxWQsHCD}
   lBqLpecaUTiVzGwgXortPfnxWQsHIK.add_dir(lBqLpecaUTiVzGwgXortPfnxWQsHCA,sublabel=lBqLpecaUTiVzGwgXortPfnxWQsHCy,img=lBqLpecaUTiVzGwgXortPfnxWQsHCj,infoLabels=lBqLpecaUTiVzGwgXortPfnxWQsHCh,isFolder=lBqLpecaUTiVzGwgXortPfnxWQsHMk,params=lBqLpecaUTiVzGwgXortPfnxWQsHCm)
  if lBqLpecaUTiVzGwgXortPfnxWQsHMJ(lBqLpecaUTiVzGwgXortPfnxWQsHCE)>0:xbmcplugin.endOfDirectory(lBqLpecaUTiVzGwgXortPfnxWQsHIK._addon_handle,cacheToDisc=lBqLpecaUTiVzGwgXortPfnxWQsHMk)
 def dp_Season_List(lBqLpecaUTiVzGwgXortPfnxWQsHIK,args):
  lBqLpecaUTiVzGwgXortPfnxWQsHIK.SpotvObj.SaveCredential(lBqLpecaUTiVzGwgXortPfnxWQsHIK.get_winCredential())
  lBqLpecaUTiVzGwgXortPfnxWQsHCR=args.get('reagueId')
  lBqLpecaUTiVzGwgXortPfnxWQsHCE=lBqLpecaUTiVzGwgXortPfnxWQsHIK.SpotvObj.GetSeasonList(lBqLpecaUTiVzGwgXortPfnxWQsHCR)
  for lBqLpecaUTiVzGwgXortPfnxWQsHCk in lBqLpecaUTiVzGwgXortPfnxWQsHCE:
   lBqLpecaUTiVzGwgXortPfnxWQsHCu =lBqLpecaUTiVzGwgXortPfnxWQsHCk.get('reagueName')
   lBqLpecaUTiVzGwgXortPfnxWQsHCF =lBqLpecaUTiVzGwgXortPfnxWQsHCk.get('gameTypeId')
   lBqLpecaUTiVzGwgXortPfnxWQsHCS =lBqLpecaUTiVzGwgXortPfnxWQsHCk.get('seasonName')
   lBqLpecaUTiVzGwgXortPfnxWQsHCO =lBqLpecaUTiVzGwgXortPfnxWQsHCk.get('seasonId')
   lBqLpecaUTiVzGwgXortPfnxWQsHCh=lBqLpecaUTiVzGwgXortPfnxWQsHCk.get('info')
   lBqLpecaUTiVzGwgXortPfnxWQsHCh['plot']='%s - %s'%(lBqLpecaUTiVzGwgXortPfnxWQsHCu,lBqLpecaUTiVzGwgXortPfnxWQsHCS)
   lBqLpecaUTiVzGwgXortPfnxWQsHCm={'mode':'SEASON_GROUP','reagueId':lBqLpecaUTiVzGwgXortPfnxWQsHCR,'seasonId':lBqLpecaUTiVzGwgXortPfnxWQsHCO,'gameTypeId':lBqLpecaUTiVzGwgXortPfnxWQsHCF,'page':'1'}
   lBqLpecaUTiVzGwgXortPfnxWQsHIK.add_dir(lBqLpecaUTiVzGwgXortPfnxWQsHCu,sublabel=lBqLpecaUTiVzGwgXortPfnxWQsHCS,img='',infoLabels=lBqLpecaUTiVzGwgXortPfnxWQsHCh,isFolder=lBqLpecaUTiVzGwgXortPfnxWQsHMj,params=lBqLpecaUTiVzGwgXortPfnxWQsHCm)
  if lBqLpecaUTiVzGwgXortPfnxWQsHMJ(lBqLpecaUTiVzGwgXortPfnxWQsHCE)>0:xbmcplugin.endOfDirectory(lBqLpecaUTiVzGwgXortPfnxWQsHIK._addon_handle,cacheToDisc=lBqLpecaUTiVzGwgXortPfnxWQsHMj)
 def dp_Game_List(lBqLpecaUTiVzGwgXortPfnxWQsHIK,args):
  lBqLpecaUTiVzGwgXortPfnxWQsHIK.SpotvObj.SaveCredential(lBqLpecaUTiVzGwgXortPfnxWQsHIK.get_winCredential())
  lBqLpecaUTiVzGwgXortPfnxWQsHCF=args.get('gameTypeId')
  lBqLpecaUTiVzGwgXortPfnxWQsHCR =args.get('reagueId')
  lBqLpecaUTiVzGwgXortPfnxWQsHCO =args.get('seasonId')
  lBqLpecaUTiVzGwgXortPfnxWQsHCb =lBqLpecaUTiVzGwgXortPfnxWQsHMR(args.get('page'))
  lBqLpecaUTiVzGwgXortPfnxWQsHCE,lBqLpecaUTiVzGwgXortPfnxWQsHCd=lBqLpecaUTiVzGwgXortPfnxWQsHIK.SpotvObj.GetGameList(lBqLpecaUTiVzGwgXortPfnxWQsHCF,lBqLpecaUTiVzGwgXortPfnxWQsHCR,lBqLpecaUTiVzGwgXortPfnxWQsHCO,lBqLpecaUTiVzGwgXortPfnxWQsHCb)
  for lBqLpecaUTiVzGwgXortPfnxWQsHCk in lBqLpecaUTiVzGwgXortPfnxWQsHCE:
   lBqLpecaUTiVzGwgXortPfnxWQsHCN =lBqLpecaUTiVzGwgXortPfnxWQsHCk.get('gameTitle')
   lBqLpecaUTiVzGwgXortPfnxWQsHYI =lBqLpecaUTiVzGwgXortPfnxWQsHCk.get('beginDate')
   lBqLpecaUTiVzGwgXortPfnxWQsHCj =lBqLpecaUTiVzGwgXortPfnxWQsHCk.get('thumbnail')
   lBqLpecaUTiVzGwgXortPfnxWQsHYC =lBqLpecaUTiVzGwgXortPfnxWQsHCk.get('gameId')
   lBqLpecaUTiVzGwgXortPfnxWQsHYm =lBqLpecaUTiVzGwgXortPfnxWQsHCk.get('totVodCnt')
   lBqLpecaUTiVzGwgXortPfnxWQsHYM =lBqLpecaUTiVzGwgXortPfnxWQsHCk.get('leaguenm')
   lBqLpecaUTiVzGwgXortPfnxWQsHYK =lBqLpecaUTiVzGwgXortPfnxWQsHCk.get('seasonnm')
   lBqLpecaUTiVzGwgXortPfnxWQsHYE =lBqLpecaUTiVzGwgXortPfnxWQsHCk.get('roundnm')
   lBqLpecaUTiVzGwgXortPfnxWQsHYk ='%s < %s >'%(lBqLpecaUTiVzGwgXortPfnxWQsHCN,lBqLpecaUTiVzGwgXortPfnxWQsHYI)
   lBqLpecaUTiVzGwgXortPfnxWQsHCh=lBqLpecaUTiVzGwgXortPfnxWQsHCk.get('info')
   lBqLpecaUTiVzGwgXortPfnxWQsHCm={'mode':'GAME_VOD_GROUP' if lBqLpecaUTiVzGwgXortPfnxWQsHYm!=0 else 'XXX','saveTitle':lBqLpecaUTiVzGwgXortPfnxWQsHYk,'saveImg':lBqLpecaUTiVzGwgXortPfnxWQsHCj,'saveInfo':lBqLpecaUTiVzGwgXortPfnxWQsHCh['plot'],'gameid':lBqLpecaUTiVzGwgXortPfnxWQsHYC}
   lBqLpecaUTiVzGwgXortPfnxWQsHIK.add_dir(lBqLpecaUTiVzGwgXortPfnxWQsHCN,sublabel=lBqLpecaUTiVzGwgXortPfnxWQsHYI,img=lBqLpecaUTiVzGwgXortPfnxWQsHCj,infoLabels=lBqLpecaUTiVzGwgXortPfnxWQsHCh,isFolder=lBqLpecaUTiVzGwgXortPfnxWQsHMj,params=lBqLpecaUTiVzGwgXortPfnxWQsHCm)
  if lBqLpecaUTiVzGwgXortPfnxWQsHCd:
   lBqLpecaUTiVzGwgXortPfnxWQsHCm['mode'] ='SEASON_GROUP' 
   lBqLpecaUTiVzGwgXortPfnxWQsHCm['reagueId'] =lBqLpecaUTiVzGwgXortPfnxWQsHCR
   lBqLpecaUTiVzGwgXortPfnxWQsHCm['seasonId'] =lBqLpecaUTiVzGwgXortPfnxWQsHCO
   lBqLpecaUTiVzGwgXortPfnxWQsHCm['gameTypeId']=lBqLpecaUTiVzGwgXortPfnxWQsHCF
   lBqLpecaUTiVzGwgXortPfnxWQsHCm['page'] =lBqLpecaUTiVzGwgXortPfnxWQsHMh(lBqLpecaUTiVzGwgXortPfnxWQsHCb+1)
   lBqLpecaUTiVzGwgXortPfnxWQsHIO='[B]%s >>[/B]'%'다음 페이지'
   lBqLpecaUTiVzGwgXortPfnxWQsHYj=lBqLpecaUTiVzGwgXortPfnxWQsHMh(lBqLpecaUTiVzGwgXortPfnxWQsHCb+1)
   lBqLpecaUTiVzGwgXortPfnxWQsHIK.add_dir(lBqLpecaUTiVzGwgXortPfnxWQsHIO,sublabel=lBqLpecaUTiVzGwgXortPfnxWQsHYj,img='',infoLabels=lBqLpecaUTiVzGwgXortPfnxWQsHME,isFolder=lBqLpecaUTiVzGwgXortPfnxWQsHMj,params=lBqLpecaUTiVzGwgXortPfnxWQsHCm)
  if lBqLpecaUTiVzGwgXortPfnxWQsHMJ(lBqLpecaUTiVzGwgXortPfnxWQsHCE)>0:xbmcplugin.endOfDirectory(lBqLpecaUTiVzGwgXortPfnxWQsHIK._addon_handle,cacheToDisc=lBqLpecaUTiVzGwgXortPfnxWQsHMk)
 def dp_GameVod_List(lBqLpecaUTiVzGwgXortPfnxWQsHIK,args):
  lBqLpecaUTiVzGwgXortPfnxWQsHIK.SpotvObj.SaveCredential(lBqLpecaUTiVzGwgXortPfnxWQsHIK.get_winCredential())
  lBqLpecaUTiVzGwgXortPfnxWQsHYR =args.get('gameid')
  lBqLpecaUTiVzGwgXortPfnxWQsHYk=args.get('saveTitle')
  lBqLpecaUTiVzGwgXortPfnxWQsHYJ =args.get('saveImg')
  lBqLpecaUTiVzGwgXortPfnxWQsHYh =args.get('saveInfo')
  lBqLpecaUTiVzGwgXortPfnxWQsHCE=lBqLpecaUTiVzGwgXortPfnxWQsHIK.SpotvObj.GetGameVodList(lBqLpecaUTiVzGwgXortPfnxWQsHYR)
  for lBqLpecaUTiVzGwgXortPfnxWQsHCk in lBqLpecaUTiVzGwgXortPfnxWQsHCE:
   lBqLpecaUTiVzGwgXortPfnxWQsHCA =lBqLpecaUTiVzGwgXortPfnxWQsHCk.get('vodTitle')
   lBqLpecaUTiVzGwgXortPfnxWQsHCv =lBqLpecaUTiVzGwgXortPfnxWQsHCk.get('vodId')
   lBqLpecaUTiVzGwgXortPfnxWQsHCy =lBqLpecaUTiVzGwgXortPfnxWQsHCk.get('vodType')
   lBqLpecaUTiVzGwgXortPfnxWQsHCj=lBqLpecaUTiVzGwgXortPfnxWQsHCk.get('thumbnail')
   lBqLpecaUTiVzGwgXortPfnxWQsHCD =lBqLpecaUTiVzGwgXortPfnxWQsHCk.get('vtypeId')
   lBqLpecaUTiVzGwgXortPfnxWQsHCh=lBqLpecaUTiVzGwgXortPfnxWQsHCk.get('info')
   lBqLpecaUTiVzGwgXortPfnxWQsHCh['plot']='%s \n\n %s'%(lBqLpecaUTiVzGwgXortPfnxWQsHCA,lBqLpecaUTiVzGwgXortPfnxWQsHYh)
   lBqLpecaUTiVzGwgXortPfnxWQsHCm={'mode':'GAME_VOD','saveTitle':lBqLpecaUTiVzGwgXortPfnxWQsHYk,'saveImg':lBqLpecaUTiVzGwgXortPfnxWQsHYJ,'saveId':lBqLpecaUTiVzGwgXortPfnxWQsHYR,'saveInfo':lBqLpecaUTiVzGwgXortPfnxWQsHYh,'mediacode':lBqLpecaUTiVzGwgXortPfnxWQsHCv,'mediatype':'vod','vtypeId':lBqLpecaUTiVzGwgXortPfnxWQsHCD}
   lBqLpecaUTiVzGwgXortPfnxWQsHIK.add_dir(lBqLpecaUTiVzGwgXortPfnxWQsHCA,sublabel=lBqLpecaUTiVzGwgXortPfnxWQsHCy,img=lBqLpecaUTiVzGwgXortPfnxWQsHCj,infoLabels=lBqLpecaUTiVzGwgXortPfnxWQsHCh,isFolder=lBqLpecaUTiVzGwgXortPfnxWQsHMk,params=lBqLpecaUTiVzGwgXortPfnxWQsHCm)
  if lBqLpecaUTiVzGwgXortPfnxWQsHMJ(lBqLpecaUTiVzGwgXortPfnxWQsHCE)>0:xbmcplugin.endOfDirectory(lBqLpecaUTiVzGwgXortPfnxWQsHIK._addon_handle,cacheToDisc=lBqLpecaUTiVzGwgXortPfnxWQsHMk)
 def login_main(lBqLpecaUTiVzGwgXortPfnxWQsHIK):
  (lBqLpecaUTiVzGwgXortPfnxWQsHYA,lBqLpecaUTiVzGwgXortPfnxWQsHYv)=lBqLpecaUTiVzGwgXortPfnxWQsHIK.get_settings_login_info()
  if not(lBqLpecaUTiVzGwgXortPfnxWQsHYA and lBqLpecaUTiVzGwgXortPfnxWQsHYv):
   lBqLpecaUTiVzGwgXortPfnxWQsHIJ=xbmcgui.Dialog()
   lBqLpecaUTiVzGwgXortPfnxWQsHYy=lBqLpecaUTiVzGwgXortPfnxWQsHIJ.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if lBqLpecaUTiVzGwgXortPfnxWQsHYy==lBqLpecaUTiVzGwgXortPfnxWQsHMj:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if lBqLpecaUTiVzGwgXortPfnxWQsHIK.cookiefile_check():return
  lBqLpecaUTiVzGwgXortPfnxWQsHYD =lBqLpecaUTiVzGwgXortPfnxWQsHMR(lBqLpecaUTiVzGwgXortPfnxWQsHIK.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))
  lBqLpecaUTiVzGwgXortPfnxWQsHYu=xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINTIME')
  if lBqLpecaUTiVzGwgXortPfnxWQsHYu==lBqLpecaUTiVzGwgXortPfnxWQsHME or lBqLpecaUTiVzGwgXortPfnxWQsHYu=='':
   lBqLpecaUTiVzGwgXortPfnxWQsHYu=lBqLpecaUTiVzGwgXortPfnxWQsHMR('19000101')
  else:
   lBqLpecaUTiVzGwgXortPfnxWQsHYu=lBqLpecaUTiVzGwgXortPfnxWQsHMR(re.sub('-','',lBqLpecaUTiVzGwgXortPfnxWQsHYu))
  if xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINWAIT')=='TRUE':
   lBqLpecaUTiVzGwgXortPfnxWQsHYF=0
   while lBqLpecaUTiVzGwgXortPfnxWQsHMj:
    lBqLpecaUTiVzGwgXortPfnxWQsHYF+=1
    time.sleep(0.05)
    if lBqLpecaUTiVzGwgXortPfnxWQsHYu>=lBqLpecaUTiVzGwgXortPfnxWQsHYD:return
    if lBqLpecaUTiVzGwgXortPfnxWQsHYF>600:return
  else:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','TRUE')
  if lBqLpecaUTiVzGwgXortPfnxWQsHYu>=lBqLpecaUTiVzGwgXortPfnxWQsHYD:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
   return
  if not lBqLpecaUTiVzGwgXortPfnxWQsHIK.SpotvObj.GetCredential(lBqLpecaUTiVzGwgXortPfnxWQsHYA,lBqLpecaUTiVzGwgXortPfnxWQsHYv):
   lBqLpecaUTiVzGwgXortPfnxWQsHIK.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
   sys.exit()
  lBqLpecaUTiVzGwgXortPfnxWQsHIK.set_winCredential(lBqLpecaUTiVzGwgXortPfnxWQsHIK.SpotvObj.LoadCredential())
  lBqLpecaUTiVzGwgXortPfnxWQsHIK.cookiefile_save()
  xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
 def dp_LiveChannel_List(lBqLpecaUTiVzGwgXortPfnxWQsHIK,args):
  lBqLpecaUTiVzGwgXortPfnxWQsHIK.SpotvObj.SaveCredential(lBqLpecaUTiVzGwgXortPfnxWQsHIK.get_winCredential())
  lBqLpecaUTiVzGwgXortPfnxWQsHYS=lBqLpecaUTiVzGwgXortPfnxWQsHIK.SpotvObj.GetLiveChannelList()
  for lBqLpecaUTiVzGwgXortPfnxWQsHYO in lBqLpecaUTiVzGwgXortPfnxWQsHYS:
   lBqLpecaUTiVzGwgXortPfnxWQsHIO =lBqLpecaUTiVzGwgXortPfnxWQsHYO.get('name')
   lBqLpecaUTiVzGwgXortPfnxWQsHCK =lBqLpecaUTiVzGwgXortPfnxWQsHYO.get('programName')
   lBqLpecaUTiVzGwgXortPfnxWQsHCj =lBqLpecaUTiVzGwgXortPfnxWQsHYO.get('logo')
   lBqLpecaUTiVzGwgXortPfnxWQsHYb=lBqLpecaUTiVzGwgXortPfnxWQsHYO.get('channelepg')
   lBqLpecaUTiVzGwgXortPfnxWQsHYd =lBqLpecaUTiVzGwgXortPfnxWQsHYO.get('free')
   lBqLpecaUTiVzGwgXortPfnxWQsHCh=lBqLpecaUTiVzGwgXortPfnxWQsHYO.get('info')
   lBqLpecaUTiVzGwgXortPfnxWQsHCh['plot']='%s'%(lBqLpecaUTiVzGwgXortPfnxWQsHYb)
   lBqLpecaUTiVzGwgXortPfnxWQsHCm={'mode':'LIVE','mediaid':lBqLpecaUTiVzGwgXortPfnxWQsHYO.get('id'),'mediacode':lBqLpecaUTiVzGwgXortPfnxWQsHYO.get('videoId'),'free':lBqLpecaUTiVzGwgXortPfnxWQsHYd,'mediatype':'live'}
   if lBqLpecaUTiVzGwgXortPfnxWQsHYd:lBqLpecaUTiVzGwgXortPfnxWQsHIO+=' [free]'
   lBqLpecaUTiVzGwgXortPfnxWQsHIK.add_dir(lBqLpecaUTiVzGwgXortPfnxWQsHIO,sublabel=lBqLpecaUTiVzGwgXortPfnxWQsHCK,img=lBqLpecaUTiVzGwgXortPfnxWQsHCj,infoLabels=lBqLpecaUTiVzGwgXortPfnxWQsHCh,isFolder=lBqLpecaUTiVzGwgXortPfnxWQsHMk,params=lBqLpecaUTiVzGwgXortPfnxWQsHCm)
  if lBqLpecaUTiVzGwgXortPfnxWQsHMJ(lBqLpecaUTiVzGwgXortPfnxWQsHYS)>0:xbmcplugin.endOfDirectory(lBqLpecaUTiVzGwgXortPfnxWQsHIK._addon_handle,cacheToDisc=lBqLpecaUTiVzGwgXortPfnxWQsHMk)
 def dp_EventLiveChannel_List(lBqLpecaUTiVzGwgXortPfnxWQsHIK,args):
  lBqLpecaUTiVzGwgXortPfnxWQsHIK.SpotvObj.SaveCredential(lBqLpecaUTiVzGwgXortPfnxWQsHIK.get_winCredential())
  lBqLpecaUTiVzGwgXortPfnxWQsHYS,lBqLpecaUTiVzGwgXortPfnxWQsHYN=lBqLpecaUTiVzGwgXortPfnxWQsHIK.SpotvObj.GetEventLiveList()
  for lBqLpecaUTiVzGwgXortPfnxWQsHYO in lBqLpecaUTiVzGwgXortPfnxWQsHYS:
   lBqLpecaUTiVzGwgXortPfnxWQsHIO =lBqLpecaUTiVzGwgXortPfnxWQsHYO.get('title')
   lBqLpecaUTiVzGwgXortPfnxWQsHCK =lBqLpecaUTiVzGwgXortPfnxWQsHYO.get('startTime')
   lBqLpecaUTiVzGwgXortPfnxWQsHCj =lBqLpecaUTiVzGwgXortPfnxWQsHYO.get('logo')
   lBqLpecaUTiVzGwgXortPfnxWQsHYd =lBqLpecaUTiVzGwgXortPfnxWQsHYO.get('free')
   lBqLpecaUTiVzGwgXortPfnxWQsHCh=lBqLpecaUTiVzGwgXortPfnxWQsHYO.get('info')
   lBqLpecaUTiVzGwgXortPfnxWQsHCh['plot']='%s\n\n%s'%(lBqLpecaUTiVzGwgXortPfnxWQsHIO,lBqLpecaUTiVzGwgXortPfnxWQsHCK)
   lBqLpecaUTiVzGwgXortPfnxWQsHCm={'mode':'ELIVE','mediaid':lBqLpecaUTiVzGwgXortPfnxWQsHYO.get('liveId'),'mediacode':'','free':lBqLpecaUTiVzGwgXortPfnxWQsHYd,'mediatype':'live'}
   if lBqLpecaUTiVzGwgXortPfnxWQsHYd:lBqLpecaUTiVzGwgXortPfnxWQsHIO+=' [free]'
   lBqLpecaUTiVzGwgXortPfnxWQsHIK.add_dir(lBqLpecaUTiVzGwgXortPfnxWQsHIO,sublabel=lBqLpecaUTiVzGwgXortPfnxWQsHCK,img=lBqLpecaUTiVzGwgXortPfnxWQsHCj,infoLabels=lBqLpecaUTiVzGwgXortPfnxWQsHCh,isFolder=lBqLpecaUTiVzGwgXortPfnxWQsHMk,params=lBqLpecaUTiVzGwgXortPfnxWQsHCm)
  if lBqLpecaUTiVzGwgXortPfnxWQsHMJ(lBqLpecaUTiVzGwgXortPfnxWQsHYS)>0:xbmcplugin.endOfDirectory(lBqLpecaUTiVzGwgXortPfnxWQsHIK._addon_handle,cacheToDisc=lBqLpecaUTiVzGwgXortPfnxWQsHMj)
  return lBqLpecaUTiVzGwgXortPfnxWQsHYN
 def play_VIDEO(lBqLpecaUTiVzGwgXortPfnxWQsHIK,args):
  lBqLpecaUTiVzGwgXortPfnxWQsHIK.SpotvObj.SaveCredential(lBqLpecaUTiVzGwgXortPfnxWQsHIK.get_winCredential())
  if args.get('free')=='False':
   if lBqLpecaUTiVzGwgXortPfnxWQsHIK.SpotvObj.CheckSubEnd()==lBqLpecaUTiVzGwgXortPfnxWQsHMk:
    lBqLpecaUTiVzGwgXortPfnxWQsHIK.addon_noti(__language__(30908).encode('utf8'))
    return
  lBqLpecaUTiVzGwgXortPfnxWQsHmI =args.get('mode')
  lBqLpecaUTiVzGwgXortPfnxWQsHmC =args.get('mediacode')
  lBqLpecaUTiVzGwgXortPfnxWQsHmY =args.get('mediatype')
  lBqLpecaUTiVzGwgXortPfnxWQsHCD =args.get('vtypeId')
  if args.get('mode')=='ELIVE':
   lBqLpecaUTiVzGwgXortPfnxWQsHmC=lBqLpecaUTiVzGwgXortPfnxWQsHIK.SpotvObj.GetEventLive_videoId(args.get('mediaid'))
  if lBqLpecaUTiVzGwgXortPfnxWQsHmC=='' or lBqLpecaUTiVzGwgXortPfnxWQsHmC==lBqLpecaUTiVzGwgXortPfnxWQsHME:
   lBqLpecaUTiVzGwgXortPfnxWQsHIK.addon_noti(__language__(30907).encode('utf8'))
   return
  lBqLpecaUTiVzGwgXortPfnxWQsHmM=lBqLpecaUTiVzGwgXortPfnxWQsHIK.SpotvObj.GetBroadURL(lBqLpecaUTiVzGwgXortPfnxWQsHmC,lBqLpecaUTiVzGwgXortPfnxWQsHmY,lBqLpecaUTiVzGwgXortPfnxWQsHCD)
  if lBqLpecaUTiVzGwgXortPfnxWQsHmM=='':
   lBqLpecaUTiVzGwgXortPfnxWQsHIK.addon_noti(__language__(30908).encode('utf8'))
   return
  lBqLpecaUTiVzGwgXortPfnxWQsHmK=lBqLpecaUTiVzGwgXortPfnxWQsHmM
  lBqLpecaUTiVzGwgXortPfnxWQsHIK.addon_log(lBqLpecaUTiVzGwgXortPfnxWQsHmK,lBqLpecaUTiVzGwgXortPfnxWQsHMk)
  lBqLpecaUTiVzGwgXortPfnxWQsHmE=xbmcgui.ListItem(path=lBqLpecaUTiVzGwgXortPfnxWQsHmK)
  xbmcplugin.setResolvedUrl(lBqLpecaUTiVzGwgXortPfnxWQsHIK._addon_handle,lBqLpecaUTiVzGwgXortPfnxWQsHMj,lBqLpecaUTiVzGwgXortPfnxWQsHmE)
  try:
   if lBqLpecaUTiVzGwgXortPfnxWQsHmY=='vod' and lBqLpecaUTiVzGwgXortPfnxWQsHmI!='POP_VOD':
    lBqLpecaUTiVzGwgXortPfnxWQsHCm={'code':args.get('saveId'),'img':args.get('saveImg'),'title':args.get('saveTitle'),'info':args.get('saveInfo')}
    lBqLpecaUTiVzGwgXortPfnxWQsHIK.Save_Watched_List(lBqLpecaUTiVzGwgXortPfnxWQsHmY,lBqLpecaUTiVzGwgXortPfnxWQsHCm)
  except:
   lBqLpecaUTiVzGwgXortPfnxWQsHME
 def logout(lBqLpecaUTiVzGwgXortPfnxWQsHIK):
  lBqLpecaUTiVzGwgXortPfnxWQsHIJ=xbmcgui.Dialog()
  lBqLpecaUTiVzGwgXortPfnxWQsHYy=lBqLpecaUTiVzGwgXortPfnxWQsHIJ.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if lBqLpecaUTiVzGwgXortPfnxWQsHYy==lBqLpecaUTiVzGwgXortPfnxWQsHMk:sys.exit()
  lBqLpecaUTiVzGwgXortPfnxWQsHIK.wininfo_clear()
  if os.path.isfile(lBqLpecaUTiVzGwgXortPfnxWQsHIM):os.remove(lBqLpecaUTiVzGwgXortPfnxWQsHIM)
  lBqLpecaUTiVzGwgXortPfnxWQsHIK.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(lBqLpecaUTiVzGwgXortPfnxWQsHIK):
  lBqLpecaUTiVzGwgXortPfnxWQsHIu=xbmcgui.Window(10000)
  lBqLpecaUTiVzGwgXortPfnxWQsHIu.setProperty('SPOTV_M_SESSIONID','')
  lBqLpecaUTiVzGwgXortPfnxWQsHIu.setProperty('SPOTV_M_SESSION','')
  lBqLpecaUTiVzGwgXortPfnxWQsHIu.setProperty('SPOTV_M_ACCOUNTID','')
  lBqLpecaUTiVzGwgXortPfnxWQsHIu.setProperty('SPOTV_M_POLICYKEY','')
  lBqLpecaUTiVzGwgXortPfnxWQsHIu.setProperty('SPOTV_M_SUBEND','')
  lBqLpecaUTiVzGwgXortPfnxWQsHIu.setProperty('SPOTV_M_LOGINTIME','')
 def cookiefile_save(lBqLpecaUTiVzGwgXortPfnxWQsHIK):
  lBqLpecaUTiVzGwgXortPfnxWQsHmk =lBqLpecaUTiVzGwgXortPfnxWQsHIK.SpotvObj.Get_Now_Datetime()
  lBqLpecaUTiVzGwgXortPfnxWQsHmj=lBqLpecaUTiVzGwgXortPfnxWQsHmk+datetime.timedelta(days=lBqLpecaUTiVzGwgXortPfnxWQsHMR(__addon__.getSetting('cache_ttl')))
  lBqLpecaUTiVzGwgXortPfnxWQsHIu=xbmcgui.Window(10000)
  lBqLpecaUTiVzGwgXortPfnxWQsHmR={'spotv_sessionid':lBqLpecaUTiVzGwgXortPfnxWQsHIu.getProperty('SPOTV_M_SESSIONID'),'spotv_session':lBqLpecaUTiVzGwgXortPfnxWQsHIu.getProperty('SPOTV_M_SESSION'),'spotv_accountId':lBqLpecaUTiVzGwgXortPfnxWQsHIu.getProperty('SPOTV_M_ACCOUNTID'),'spotv_policyKey':base64.standard_b64encode(lBqLpecaUTiVzGwgXortPfnxWQsHIu.getProperty('SPOTV_M_POLICYKEY').encode()).decode('utf-8'),'spotv_subend':base64.standard_b64encode((lBqLpecaUTiVzGwgXortPfnxWQsHIK.SpotvObj.SPOTV_PMCODE+lBqLpecaUTiVzGwgXortPfnxWQsHIu.getProperty('SPOTV_M_SUBEND')).encode()).decode('utf-8'),'spotv_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'spotv_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'spotv_limitdate':lBqLpecaUTiVzGwgXortPfnxWQsHmj.strftime('%Y-%m-%d')}
  try: 
   fp=lBqLpecaUTiVzGwgXortPfnxWQsHMA(lBqLpecaUTiVzGwgXortPfnxWQsHIM,'w',-1,'utf-8')
   json.dump(lBqLpecaUTiVzGwgXortPfnxWQsHmR,fp)
   fp.close()
  except lBqLpecaUTiVzGwgXortPfnxWQsHMv as exception:
   lBqLpecaUTiVzGwgXortPfnxWQsHMy(exception)
 def cookiefile_check(lBqLpecaUTiVzGwgXortPfnxWQsHIK):
  lBqLpecaUTiVzGwgXortPfnxWQsHmR={}
  try: 
   fp=lBqLpecaUTiVzGwgXortPfnxWQsHMA(lBqLpecaUTiVzGwgXortPfnxWQsHIM,'r',-1,'utf-8')
   lBqLpecaUTiVzGwgXortPfnxWQsHmR= json.load(fp)
   fp.close()
  except lBqLpecaUTiVzGwgXortPfnxWQsHMv as exception:
   lBqLpecaUTiVzGwgXortPfnxWQsHIK.wininfo_clear()
   return lBqLpecaUTiVzGwgXortPfnxWQsHMk
  lBqLpecaUTiVzGwgXortPfnxWQsHYA =__addon__.getSetting('id')
  lBqLpecaUTiVzGwgXortPfnxWQsHYv =__addon__.getSetting('pw')
  lBqLpecaUTiVzGwgXortPfnxWQsHmR['spotv_id'] =base64.standard_b64decode(lBqLpecaUTiVzGwgXortPfnxWQsHmR['spotv_id']).decode('utf-8')
  lBqLpecaUTiVzGwgXortPfnxWQsHmR['spotv_pw'] =base64.standard_b64decode(lBqLpecaUTiVzGwgXortPfnxWQsHmR['spotv_pw']).decode('utf-8')
  lBqLpecaUTiVzGwgXortPfnxWQsHmR['spotv_policyKey']=base64.standard_b64decode(lBqLpecaUTiVzGwgXortPfnxWQsHmR['spotv_policyKey']).decode('utf-8')
  lBqLpecaUTiVzGwgXortPfnxWQsHmR['spotv_subend']=base64.standard_b64decode(lBqLpecaUTiVzGwgXortPfnxWQsHmR['spotv_subend']).decode('utf-8')[lBqLpecaUTiVzGwgXortPfnxWQsHIK.SpotvObj.SPOTV_PMSIZE:]
  if lBqLpecaUTiVzGwgXortPfnxWQsHYA!=lBqLpecaUTiVzGwgXortPfnxWQsHmR['spotv_id']or lBqLpecaUTiVzGwgXortPfnxWQsHYv!=lBqLpecaUTiVzGwgXortPfnxWQsHmR['spotv_pw']:
   lBqLpecaUTiVzGwgXortPfnxWQsHIK.wininfo_clear()
   return lBqLpecaUTiVzGwgXortPfnxWQsHMk
  lBqLpecaUTiVzGwgXortPfnxWQsHYD =lBqLpecaUTiVzGwgXortPfnxWQsHMR(lBqLpecaUTiVzGwgXortPfnxWQsHIK.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))
  lBqLpecaUTiVzGwgXortPfnxWQsHmJ=lBqLpecaUTiVzGwgXortPfnxWQsHmR['spotv_limitdate']
  lBqLpecaUTiVzGwgXortPfnxWQsHYu =lBqLpecaUTiVzGwgXortPfnxWQsHMR(re.sub('-','',lBqLpecaUTiVzGwgXortPfnxWQsHmJ))
  if lBqLpecaUTiVzGwgXortPfnxWQsHYu<lBqLpecaUTiVzGwgXortPfnxWQsHYD:
   lBqLpecaUTiVzGwgXortPfnxWQsHIK.wininfo_clear()
   return lBqLpecaUTiVzGwgXortPfnxWQsHMk
  lBqLpecaUTiVzGwgXortPfnxWQsHIu=xbmcgui.Window(10000)
  lBqLpecaUTiVzGwgXortPfnxWQsHIu.setProperty('SPOTV_M_SESSIONID',lBqLpecaUTiVzGwgXortPfnxWQsHmR['spotv_sessionid'])
  lBqLpecaUTiVzGwgXortPfnxWQsHIu.setProperty('SPOTV_M_SESSION',lBqLpecaUTiVzGwgXortPfnxWQsHmR['spotv_session'])
  lBqLpecaUTiVzGwgXortPfnxWQsHIu.setProperty('SPOTV_M_ACCOUNTID',lBqLpecaUTiVzGwgXortPfnxWQsHmR['spotv_accountId'])
  lBqLpecaUTiVzGwgXortPfnxWQsHIu.setProperty('SPOTV_M_POLICYKEY',lBqLpecaUTiVzGwgXortPfnxWQsHmR['spotv_policyKey'])
  lBqLpecaUTiVzGwgXortPfnxWQsHIu.setProperty('SPOTV_M_SUBEND',lBqLpecaUTiVzGwgXortPfnxWQsHmR['spotv_subend'])
  lBqLpecaUTiVzGwgXortPfnxWQsHIu.setProperty('SPOTV_M_LOGINTIME',lBqLpecaUTiVzGwgXortPfnxWQsHmJ)
  return lBqLpecaUTiVzGwgXortPfnxWQsHMj
 def dp_WatchList_Delete(lBqLpecaUTiVzGwgXortPfnxWQsHIK,args):
  lBqLpecaUTiVzGwgXortPfnxWQsHmY=args.get('mediatype')
  lBqLpecaUTiVzGwgXortPfnxWQsHIJ=xbmcgui.Dialog()
  lBqLpecaUTiVzGwgXortPfnxWQsHYy=lBqLpecaUTiVzGwgXortPfnxWQsHIJ.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if lBqLpecaUTiVzGwgXortPfnxWQsHYy==lBqLpecaUTiVzGwgXortPfnxWQsHMk:sys.exit()
  lBqLpecaUTiVzGwgXortPfnxWQsHIK.Delete_Watched_List(lBqLpecaUTiVzGwgXortPfnxWQsHmY)
  xbmc.executebuiltin("Container.Refresh")
 def Delete_Watched_List(lBqLpecaUTiVzGwgXortPfnxWQsHIK,lBqLpecaUTiVzGwgXortPfnxWQsHmY):
  try:
   lBqLpecaUTiVzGwgXortPfnxWQsHmh=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%lBqLpecaUTiVzGwgXortPfnxWQsHmY))
   fp=lBqLpecaUTiVzGwgXortPfnxWQsHMA(lBqLpecaUTiVzGwgXortPfnxWQsHmh,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   lBqLpecaUTiVzGwgXortPfnxWQsHME
 def Load_Watched_List(lBqLpecaUTiVzGwgXortPfnxWQsHIK,lBqLpecaUTiVzGwgXortPfnxWQsHmY):
  try:
   lBqLpecaUTiVzGwgXortPfnxWQsHmh=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%lBqLpecaUTiVzGwgXortPfnxWQsHmY))
   fp=lBqLpecaUTiVzGwgXortPfnxWQsHMA(lBqLpecaUTiVzGwgXortPfnxWQsHmh,'r',-1,'utf-8')
   lBqLpecaUTiVzGwgXortPfnxWQsHmA=fp.readlines()
   fp.close()
  except:
   lBqLpecaUTiVzGwgXortPfnxWQsHmA=[]
  return lBqLpecaUTiVzGwgXortPfnxWQsHmA
 def Save_Watched_List(lBqLpecaUTiVzGwgXortPfnxWQsHIK,stype,lBqLpecaUTiVzGwgXortPfnxWQsHIj):
  try:
   lBqLpecaUTiVzGwgXortPfnxWQsHmh=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   lBqLpecaUTiVzGwgXortPfnxWQsHmv=lBqLpecaUTiVzGwgXortPfnxWQsHIK.Load_Watched_List(stype) 
   fp=lBqLpecaUTiVzGwgXortPfnxWQsHMA(lBqLpecaUTiVzGwgXortPfnxWQsHmh,'w',-1,'utf-8')
   lBqLpecaUTiVzGwgXortPfnxWQsHmy=urllib.parse.urlencode(lBqLpecaUTiVzGwgXortPfnxWQsHIj)
   lBqLpecaUTiVzGwgXortPfnxWQsHmy=lBqLpecaUTiVzGwgXortPfnxWQsHmy+'\n'
   fp.write(lBqLpecaUTiVzGwgXortPfnxWQsHmy)
   lBqLpecaUTiVzGwgXortPfnxWQsHmD=0
   for lBqLpecaUTiVzGwgXortPfnxWQsHmu in lBqLpecaUTiVzGwgXortPfnxWQsHmv:
    lBqLpecaUTiVzGwgXortPfnxWQsHmF=lBqLpecaUTiVzGwgXortPfnxWQsHMD(urllib.parse.parse_qsl(lBqLpecaUTiVzGwgXortPfnxWQsHmu))
    lBqLpecaUTiVzGwgXortPfnxWQsHmS=lBqLpecaUTiVzGwgXortPfnxWQsHIj.get('code')
    lBqLpecaUTiVzGwgXortPfnxWQsHmO=lBqLpecaUTiVzGwgXortPfnxWQsHmF.get('code')
    if lBqLpecaUTiVzGwgXortPfnxWQsHmS!=lBqLpecaUTiVzGwgXortPfnxWQsHmO:
     fp.write(lBqLpecaUTiVzGwgXortPfnxWQsHmu)
     lBqLpecaUTiVzGwgXortPfnxWQsHmD+=1
     if lBqLpecaUTiVzGwgXortPfnxWQsHmD>=50:break
   fp.close()
  except:
   lBqLpecaUTiVzGwgXortPfnxWQsHME
 def dp_Watch_List(lBqLpecaUTiVzGwgXortPfnxWQsHIK,args):
  lBqLpecaUTiVzGwgXortPfnxWQsHmY ='vod'
  if lBqLpecaUTiVzGwgXortPfnxWQsHmY=='vod':
   lBqLpecaUTiVzGwgXortPfnxWQsHmb=lBqLpecaUTiVzGwgXortPfnxWQsHIK.Load_Watched_List(lBqLpecaUTiVzGwgXortPfnxWQsHmY)
   for lBqLpecaUTiVzGwgXortPfnxWQsHmd in lBqLpecaUTiVzGwgXortPfnxWQsHmb:
    lBqLpecaUTiVzGwgXortPfnxWQsHmN=lBqLpecaUTiVzGwgXortPfnxWQsHMD(urllib.parse.parse_qsl(lBqLpecaUTiVzGwgXortPfnxWQsHmd))
    lBqLpecaUTiVzGwgXortPfnxWQsHIO =lBqLpecaUTiVzGwgXortPfnxWQsHmN.get('title')
    lBqLpecaUTiVzGwgXortPfnxWQsHCj=lBqLpecaUTiVzGwgXortPfnxWQsHmN.get('img')
    lBqLpecaUTiVzGwgXortPfnxWQsHmC=lBqLpecaUTiVzGwgXortPfnxWQsHmN.get('code')
    lBqLpecaUTiVzGwgXortPfnxWQsHMI =lBqLpecaUTiVzGwgXortPfnxWQsHmN.get('info')
    lBqLpecaUTiVzGwgXortPfnxWQsHCh={}
    lBqLpecaUTiVzGwgXortPfnxWQsHCh['plot']=lBqLpecaUTiVzGwgXortPfnxWQsHMI
    lBqLpecaUTiVzGwgXortPfnxWQsHCm={'mode':'GAME_VOD_GROUP','gameid':lBqLpecaUTiVzGwgXortPfnxWQsHmC,'saveTitle':lBqLpecaUTiVzGwgXortPfnxWQsHIO,'saveImg':lBqLpecaUTiVzGwgXortPfnxWQsHCj,'saveInfo':lBqLpecaUTiVzGwgXortPfnxWQsHMI,'mediatype':lBqLpecaUTiVzGwgXortPfnxWQsHmY}
    lBqLpecaUTiVzGwgXortPfnxWQsHIK.add_dir(lBqLpecaUTiVzGwgXortPfnxWQsHIO,sublabel='',img=lBqLpecaUTiVzGwgXortPfnxWQsHCj,infoLabels=lBqLpecaUTiVzGwgXortPfnxWQsHCh,isFolder=lBqLpecaUTiVzGwgXortPfnxWQsHMj,params=lBqLpecaUTiVzGwgXortPfnxWQsHCm)
   lBqLpecaUTiVzGwgXortPfnxWQsHCh={'plot':'시청목록을 삭제합니다.'}
   lBqLpecaUTiVzGwgXortPfnxWQsHIO='*** 시청목록 삭제 ***'
   lBqLpecaUTiVzGwgXortPfnxWQsHCm={'mode':'MYVIEW_REMOVE','mediatype':lBqLpecaUTiVzGwgXortPfnxWQsHmY}
   lBqLpecaUTiVzGwgXortPfnxWQsHIK.add_dir(lBqLpecaUTiVzGwgXortPfnxWQsHIO,sublabel='',img='',infoLabels=lBqLpecaUTiVzGwgXortPfnxWQsHCh,isFolder=lBqLpecaUTiVzGwgXortPfnxWQsHMk,params=lBqLpecaUTiVzGwgXortPfnxWQsHCm)
   xbmcplugin.endOfDirectory(lBqLpecaUTiVzGwgXortPfnxWQsHIK._addon_handle,cacheToDisc=lBqLpecaUTiVzGwgXortPfnxWQsHMk)
 def spotv_main(lBqLpecaUTiVzGwgXortPfnxWQsHIK):
  lBqLpecaUTiVzGwgXortPfnxWQsHMY=lBqLpecaUTiVzGwgXortPfnxWQsHIK.main_params.get('mode',lBqLpecaUTiVzGwgXortPfnxWQsHME)
  if lBqLpecaUTiVzGwgXortPfnxWQsHMY=='LOGOUT':
   lBqLpecaUTiVzGwgXortPfnxWQsHIK.logout()
   return
  lBqLpecaUTiVzGwgXortPfnxWQsHIK.login_main()
  if lBqLpecaUTiVzGwgXortPfnxWQsHMY is lBqLpecaUTiVzGwgXortPfnxWQsHME:
   lBqLpecaUTiVzGwgXortPfnxWQsHIK.dp_Main_List()
  elif lBqLpecaUTiVzGwgXortPfnxWQsHMY=='LIVE_GROUP':
   lBqLpecaUTiVzGwgXortPfnxWQsHIK.dp_LiveChannel_List(lBqLpecaUTiVzGwgXortPfnxWQsHIK.main_params)
  elif lBqLpecaUTiVzGwgXortPfnxWQsHMY=='ELIVE_GROUP':
   lBqLpecaUTiVzGwgXortPfnxWQsHMm=lBqLpecaUTiVzGwgXortPfnxWQsHIK.dp_EventLiveChannel_List(lBqLpecaUTiVzGwgXortPfnxWQsHIK.main_params)
   if lBqLpecaUTiVzGwgXortPfnxWQsHMm==401:
    if os.path.isfile(lBqLpecaUTiVzGwgXortPfnxWQsHIM):os.remove(lBqLpecaUTiVzGwgXortPfnxWQsHIM)
    lBqLpecaUTiVzGwgXortPfnxWQsHIK.login_main()
    lBqLpecaUTiVzGwgXortPfnxWQsHIK.dp_EventLiveChannel_List(lBqLpecaUTiVzGwgXortPfnxWQsHIK.main_params)
  elif lBqLpecaUTiVzGwgXortPfnxWQsHMY in['LIVE','GAME_VOD','POP_VOD','ELIVE']:
   lBqLpecaUTiVzGwgXortPfnxWQsHIK.play_VIDEO(lBqLpecaUTiVzGwgXortPfnxWQsHIK.main_params)
  elif lBqLpecaUTiVzGwgXortPfnxWQsHMY=='VOD_GROUP':
   lBqLpecaUTiVzGwgXortPfnxWQsHIK.dp_MainLeague_List(lBqLpecaUTiVzGwgXortPfnxWQsHIK.main_params)
  elif lBqLpecaUTiVzGwgXortPfnxWQsHMY=='POP_GROUP':
   lBqLpecaUTiVzGwgXortPfnxWQsHIK.dp_PopVod_GroupList(lBqLpecaUTiVzGwgXortPfnxWQsHIK.main_params)
  elif lBqLpecaUTiVzGwgXortPfnxWQsHMY=='LEAGUE_GROUP':
   lBqLpecaUTiVzGwgXortPfnxWQsHIK.dp_Season_List(lBqLpecaUTiVzGwgXortPfnxWQsHIK.main_params)
  elif lBqLpecaUTiVzGwgXortPfnxWQsHMY=='SEASON_GROUP':
   lBqLpecaUTiVzGwgXortPfnxWQsHIK.dp_Game_List(lBqLpecaUTiVzGwgXortPfnxWQsHIK.main_params)
  elif lBqLpecaUTiVzGwgXortPfnxWQsHMY=='GAME_VOD_GROUP':
   lBqLpecaUTiVzGwgXortPfnxWQsHIK.dp_GameVod_List(lBqLpecaUTiVzGwgXortPfnxWQsHIK.main_params)
  elif lBqLpecaUTiVzGwgXortPfnxWQsHMY=='WATCH':
   lBqLpecaUTiVzGwgXortPfnxWQsHIK.dp_Watch_List(lBqLpecaUTiVzGwgXortPfnxWQsHIK.main_params)
  elif lBqLpecaUTiVzGwgXortPfnxWQsHMY=='MYVIEW_REMOVE':
   lBqLpecaUTiVzGwgXortPfnxWQsHIK.dp_WatchList_Delete(lBqLpecaUTiVzGwgXortPfnxWQsHIK.main_params)
  else:
   lBqLpecaUTiVzGwgXortPfnxWQsHME
# Created by pyminifier (https://github.com/liftoff/pyminifier)
