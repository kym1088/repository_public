__author__="NightRain"
wmXlvOcyJeIxCzKruUPTEQDBShLWfp=object
wmXlvOcyJeIxCzKruUPTEQDBShLWfA=None
wmXlvOcyJeIxCzKruUPTEQDBShLWfd=False
wmXlvOcyJeIxCzKruUPTEQDBShLWfa=print
wmXlvOcyJeIxCzKruUPTEQDBShLWfG=str
wmXlvOcyJeIxCzKruUPTEQDBShLWfM=True
wmXlvOcyJeIxCzKruUPTEQDBShLWfb=Exception
wmXlvOcyJeIxCzKruUPTEQDBShLWfg=int
import urllib
import http.cookiejar 
import re
import json
import sys
import time
import requests
import datetime
import base64
wmXlvOcyJeIxCzKruUPTEQDBShLWYj ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36'
wmXlvOcyJeIxCzKruUPTEQDBShLWYo={'stream50':1080,'stream40':720,'stream30':540}
class wmXlvOcyJeIxCzKruUPTEQDBShLWYt(wmXlvOcyJeIxCzKruUPTEQDBShLWfp):
 def __init__(wmXlvOcyJeIxCzKruUPTEQDBShLWYf):
  wmXlvOcyJeIxCzKruUPTEQDBShLWYf.SPOTV_SESSIONID=''
  wmXlvOcyJeIxCzKruUPTEQDBShLWYf.SPOTV_SESSION =''
  wmXlvOcyJeIxCzKruUPTEQDBShLWYf.SPOTV_ACCOUNTID=''
  wmXlvOcyJeIxCzKruUPTEQDBShLWYf.SPOTV_POLICYKEY=''
  wmXlvOcyJeIxCzKruUPTEQDBShLWYf.SPOTV_SUBEND =''
  wmXlvOcyJeIxCzKruUPTEQDBShLWYf.SPOTV_PMCODE ='987'
  wmXlvOcyJeIxCzKruUPTEQDBShLWYf.SPOTV_PMSIZE =3
  wmXlvOcyJeIxCzKruUPTEQDBShLWYf.GAMELIST_LIMIT =10
  wmXlvOcyJeIxCzKruUPTEQDBShLWYf.API_DOMAIN ='https://www.spotvnow.co.kr'
  wmXlvOcyJeIxCzKruUPTEQDBShLWYf.BC_DOMAIN ='https://players.brightcove.net'
  wmXlvOcyJeIxCzKruUPTEQDBShLWYf.PLAYER_DOMAIN ='https://edge.api.brightcove.com'
  wmXlvOcyJeIxCzKruUPTEQDBShLWYf.DEFAULT_HEADER ={'user-agent':wmXlvOcyJeIxCzKruUPTEQDBShLWYj}
 def callRequestCookies(wmXlvOcyJeIxCzKruUPTEQDBShLWYf,jobtype,wmXlvOcyJeIxCzKruUPTEQDBShLWto,payload=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,params=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,headers=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,cookies=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,redirects=wmXlvOcyJeIxCzKruUPTEQDBShLWfd):
  wmXlvOcyJeIxCzKruUPTEQDBShLWYH=wmXlvOcyJeIxCzKruUPTEQDBShLWYf.DEFAULT_HEADER
  if headers:wmXlvOcyJeIxCzKruUPTEQDBShLWYH.update(headers)
  if jobtype=='Get':
   wmXlvOcyJeIxCzKruUPTEQDBShLWYp=requests.get(wmXlvOcyJeIxCzKruUPTEQDBShLWto,params=params,headers=wmXlvOcyJeIxCzKruUPTEQDBShLWYH,cookies=cookies,allow_redirects=redirects)
  else:
   wmXlvOcyJeIxCzKruUPTEQDBShLWYp=requests.post(wmXlvOcyJeIxCzKruUPTEQDBShLWto,data=payload,params=params,headers=wmXlvOcyJeIxCzKruUPTEQDBShLWYH,cookies=cookies,allow_redirects=redirects)
  return wmXlvOcyJeIxCzKruUPTEQDBShLWYp
 def makeDefaultCookies(wmXlvOcyJeIxCzKruUPTEQDBShLWYf):
  wmXlvOcyJeIxCzKruUPTEQDBShLWYA={'SESSION':wmXlvOcyJeIxCzKruUPTEQDBShLWYf.SPOTV_SESSION}
  return wmXlvOcyJeIxCzKruUPTEQDBShLWYA
 def GetCredential(wmXlvOcyJeIxCzKruUPTEQDBShLWYf,user_id,user_pw):
  wmXlvOcyJeIxCzKruUPTEQDBShLWYd=wmXlvOcyJeIxCzKruUPTEQDBShLWfd
  wmXlvOcyJeIxCzKruUPTEQDBShLWYa=wmXlvOcyJeIxCzKruUPTEQDBShLWYk=wmXlvOcyJeIxCzKruUPTEQDBShLWYF=wmXlvOcyJeIxCzKruUPTEQDBShLWYN=wmXlvOcyJeIxCzKruUPTEQDBShLWYR=''
  try:
   wmXlvOcyJeIxCzKruUPTEQDBShLWYG=base64.standard_b64encode(user_id.encode("UTF-8")).decode('utf-8')
   wmXlvOcyJeIxCzKruUPTEQDBShLWYM=base64.standard_b64encode(user_pw.encode("UTF-8")).decode('utf-8')
   wmXlvOcyJeIxCzKruUPTEQDBShLWYb=wmXlvOcyJeIxCzKruUPTEQDBShLWYf.API_DOMAIN+'/api/v2/login'
   wmXlvOcyJeIxCzKruUPTEQDBShLWYg={'username':wmXlvOcyJeIxCzKruUPTEQDBShLWYG,'password':wmXlvOcyJeIxCzKruUPTEQDBShLWYM}
   wmXlvOcyJeIxCzKruUPTEQDBShLWYg=json.dumps(wmXlvOcyJeIxCzKruUPTEQDBShLWYg)
   wmXlvOcyJeIxCzKruUPTEQDBShLWYV=wmXlvOcyJeIxCzKruUPTEQDBShLWYf.callRequestCookies('Post',wmXlvOcyJeIxCzKruUPTEQDBShLWYb,payload=wmXlvOcyJeIxCzKruUPTEQDBShLWYg,params=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,headers=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,cookies=wmXlvOcyJeIxCzKruUPTEQDBShLWfA)
   wmXlvOcyJeIxCzKruUPTEQDBShLWfa(wmXlvOcyJeIxCzKruUPTEQDBShLWYV.status_code)
   for wmXlvOcyJeIxCzKruUPTEQDBShLWYn in wmXlvOcyJeIxCzKruUPTEQDBShLWYV.cookies:
    if wmXlvOcyJeIxCzKruUPTEQDBShLWYn.name=='SESSION':
     wmXlvOcyJeIxCzKruUPTEQDBShLWYk=wmXlvOcyJeIxCzKruUPTEQDBShLWYn.value
     break
   if wmXlvOcyJeIxCzKruUPTEQDBShLWYk=='':return wmXlvOcyJeIxCzKruUPTEQDBShLWYd
   wmXlvOcyJeIxCzKruUPTEQDBShLWYq=json.loads(wmXlvOcyJeIxCzKruUPTEQDBShLWYV.text)
   if not('userId' in wmXlvOcyJeIxCzKruUPTEQDBShLWYq):return wmXlvOcyJeIxCzKruUPTEQDBShLWYd
   wmXlvOcyJeIxCzKruUPTEQDBShLWYa=wmXlvOcyJeIxCzKruUPTEQDBShLWfG(wmXlvOcyJeIxCzKruUPTEQDBShLWYq['userId'])
   wmXlvOcyJeIxCzKruUPTEQDBShLWYR =wmXlvOcyJeIxCzKruUPTEQDBShLWfG(wmXlvOcyJeIxCzKruUPTEQDBShLWYq['subEndTime'])
   wmXlvOcyJeIxCzKruUPTEQDBShLWYF,wmXlvOcyJeIxCzKruUPTEQDBShLWYN=wmXlvOcyJeIxCzKruUPTEQDBShLWYf.GetPolicyKey()
   if wmXlvOcyJeIxCzKruUPTEQDBShLWYN=='':return wmXlvOcyJeIxCzKruUPTEQDBShLWYd
   wmXlvOcyJeIxCzKruUPTEQDBShLWYd=wmXlvOcyJeIxCzKruUPTEQDBShLWfM
  except wmXlvOcyJeIxCzKruUPTEQDBShLWfb as exception:
   wmXlvOcyJeIxCzKruUPTEQDBShLWYa=wmXlvOcyJeIxCzKruUPTEQDBShLWYk='' 
   wmXlvOcyJeIxCzKruUPTEQDBShLWfa(exception)
  wmXlvOcyJeIxCzKruUPTEQDBShLWYs={'spotv_sessionid':wmXlvOcyJeIxCzKruUPTEQDBShLWYa,'spotv_session':wmXlvOcyJeIxCzKruUPTEQDBShLWYk,'spotv_accountId':wmXlvOcyJeIxCzKruUPTEQDBShLWYF,'spotv_policyKey':wmXlvOcyJeIxCzKruUPTEQDBShLWYN,'spotv_subend':wmXlvOcyJeIxCzKruUPTEQDBShLWYR}
  wmXlvOcyJeIxCzKruUPTEQDBShLWYf.SaveCredential(wmXlvOcyJeIxCzKruUPTEQDBShLWYs)
  return wmXlvOcyJeIxCzKruUPTEQDBShLWYd
 def SaveCredential(wmXlvOcyJeIxCzKruUPTEQDBShLWYf,wmXlvOcyJeIxCzKruUPTEQDBShLWYs):
  wmXlvOcyJeIxCzKruUPTEQDBShLWYf.SPOTV_SESSIONID=wmXlvOcyJeIxCzKruUPTEQDBShLWYs.get('spotv_sessionid')
  wmXlvOcyJeIxCzKruUPTEQDBShLWYf.SPOTV_SESSION =wmXlvOcyJeIxCzKruUPTEQDBShLWYs.get('spotv_session')
  wmXlvOcyJeIxCzKruUPTEQDBShLWYf.SPOTV_ACCOUNTID=wmXlvOcyJeIxCzKruUPTEQDBShLWYs.get('spotv_accountId')
  wmXlvOcyJeIxCzKruUPTEQDBShLWYf.SPOTV_POLICYKEY=wmXlvOcyJeIxCzKruUPTEQDBShLWYs.get('spotv_policyKey')
  wmXlvOcyJeIxCzKruUPTEQDBShLWYf.SPOTV_SUBEND =wmXlvOcyJeIxCzKruUPTEQDBShLWYs.get('spotv_subend')
 def LoadCredential(wmXlvOcyJeIxCzKruUPTEQDBShLWYf):
  wmXlvOcyJeIxCzKruUPTEQDBShLWYs={'spotv_sessionid':wmXlvOcyJeIxCzKruUPTEQDBShLWYf.SPOTV_SESSIONID,'spotv_session':wmXlvOcyJeIxCzKruUPTEQDBShLWYf.SPOTV_SESSION,'spotv_accountId':wmXlvOcyJeIxCzKruUPTEQDBShLWYf.SPOTV_ACCOUNTID,'spotv_policyKey':wmXlvOcyJeIxCzKruUPTEQDBShLWYf.SPOTV_POLICYKEY,'spotv_subend':wmXlvOcyJeIxCzKruUPTEQDBShLWYf.SPOTV_SUBEND}
  return wmXlvOcyJeIxCzKruUPTEQDBShLWYs
 def Get_Now_Datetime(wmXlvOcyJeIxCzKruUPTEQDBShLWYf):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetLiveChannelList(wmXlvOcyJeIxCzKruUPTEQDBShLWYf):
  wmXlvOcyJeIxCzKruUPTEQDBShLWtY=[]
  wmXlvOcyJeIxCzKruUPTEQDBShLWtj ={}
  try:
   wmXlvOcyJeIxCzKruUPTEQDBShLWto=wmXlvOcyJeIxCzKruUPTEQDBShLWYf.API_DOMAIN+'/api/v2/channel'
   wmXlvOcyJeIxCzKruUPTEQDBShLWYV=wmXlvOcyJeIxCzKruUPTEQDBShLWYf.callRequestCookies('Get',wmXlvOcyJeIxCzKruUPTEQDBShLWto,payload=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,params=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,headers=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,cookies=wmXlvOcyJeIxCzKruUPTEQDBShLWfA)
   wmXlvOcyJeIxCzKruUPTEQDBShLWYq=json.loads(wmXlvOcyJeIxCzKruUPTEQDBShLWYV.text)
   wmXlvOcyJeIxCzKruUPTEQDBShLWtj=wmXlvOcyJeIxCzKruUPTEQDBShLWYf.GetEPGList()
   for wmXlvOcyJeIxCzKruUPTEQDBShLWtf in wmXlvOcyJeIxCzKruUPTEQDBShLWYq:
    wmXlvOcyJeIxCzKruUPTEQDBShLWtH={}
    wmXlvOcyJeIxCzKruUPTEQDBShLWtH['mediatype']='video'
    wmXlvOcyJeIxCzKruUPTEQDBShLWtH['title'] =wmXlvOcyJeIxCzKruUPTEQDBShLWtf['programName']
    wmXlvOcyJeIxCzKruUPTEQDBShLWtH['studio'] =wmXlvOcyJeIxCzKruUPTEQDBShLWtf['name']
    wmXlvOcyJeIxCzKruUPTEQDBShLWtp={'id':wmXlvOcyJeIxCzKruUPTEQDBShLWtf['id'],'name':wmXlvOcyJeIxCzKruUPTEQDBShLWtf['name'],'logo':wmXlvOcyJeIxCzKruUPTEQDBShLWtf['logo'],'videoId':wmXlvOcyJeIxCzKruUPTEQDBShLWtf['videoId'].replace('ref:',''),'free':wmXlvOcyJeIxCzKruUPTEQDBShLWtf['free'],'programName':wmXlvOcyJeIxCzKruUPTEQDBShLWtf['programName'],'channelepg':wmXlvOcyJeIxCzKruUPTEQDBShLWtj.get(wmXlvOcyJeIxCzKruUPTEQDBShLWtf['id']),'info':wmXlvOcyJeIxCzKruUPTEQDBShLWtH}
    wmXlvOcyJeIxCzKruUPTEQDBShLWtY.append(wmXlvOcyJeIxCzKruUPTEQDBShLWtp)
  except wmXlvOcyJeIxCzKruUPTEQDBShLWfb as exception:
   wmXlvOcyJeIxCzKruUPTEQDBShLWfa(exception)
  return wmXlvOcyJeIxCzKruUPTEQDBShLWtY
 def GetEPGList(wmXlvOcyJeIxCzKruUPTEQDBShLWYf):
  wmXlvOcyJeIxCzKruUPTEQDBShLWtA={}
  wmXlvOcyJeIxCzKruUPTEQDBShLWtd=wmXlvOcyJeIxCzKruUPTEQDBShLWYf.Get_Now_Datetime()
  wmXlvOcyJeIxCzKruUPTEQDBShLWta=wmXlvOcyJeIxCzKruUPTEQDBShLWtd.strftime('%Y%m%d%H%M')
  wmXlvOcyJeIxCzKruUPTEQDBShLWtG='%s-%s-%s'%(wmXlvOcyJeIxCzKruUPTEQDBShLWta[0:4],wmXlvOcyJeIxCzKruUPTEQDBShLWta[4:6],wmXlvOcyJeIxCzKruUPTEQDBShLWta[6:8])
  wmXlvOcyJeIxCzKruUPTEQDBShLWtM=(wmXlvOcyJeIxCzKruUPTEQDBShLWtd+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M')
  try:
   wmXlvOcyJeIxCzKruUPTEQDBShLWto=wmXlvOcyJeIxCzKruUPTEQDBShLWYf.API_DOMAIN+'/api/v2/program/'+wmXlvOcyJeIxCzKruUPTEQDBShLWtG
   wmXlvOcyJeIxCzKruUPTEQDBShLWYV=wmXlvOcyJeIxCzKruUPTEQDBShLWYf.callRequestCookies('Get',wmXlvOcyJeIxCzKruUPTEQDBShLWto,payload=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,params=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,headers=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,cookies=wmXlvOcyJeIxCzKruUPTEQDBShLWfA)
   wmXlvOcyJeIxCzKruUPTEQDBShLWYq=json.loads(wmXlvOcyJeIxCzKruUPTEQDBShLWYV.text)
   wmXlvOcyJeIxCzKruUPTEQDBShLWtb=-1 
   wmXlvOcyJeIxCzKruUPTEQDBShLWtg =''
   for wmXlvOcyJeIxCzKruUPTEQDBShLWtf in wmXlvOcyJeIxCzKruUPTEQDBShLWYq:
    wmXlvOcyJeIxCzKruUPTEQDBShLWtV=wmXlvOcyJeIxCzKruUPTEQDBShLWtf['channelId']
    wmXlvOcyJeIxCzKruUPTEQDBShLWtn =wmXlvOcyJeIxCzKruUPTEQDBShLWtf['startTime'].replace('-','').replace(' ','').replace(':','')
    wmXlvOcyJeIxCzKruUPTEQDBShLWtk =wmXlvOcyJeIxCzKruUPTEQDBShLWtf['endTime'].replace('-','').replace(' ','').replace(':','')
    if wmXlvOcyJeIxCzKruUPTEQDBShLWfg(wmXlvOcyJeIxCzKruUPTEQDBShLWta)>wmXlvOcyJeIxCzKruUPTEQDBShLWfg(wmXlvOcyJeIxCzKruUPTEQDBShLWtk) :continue
    if wmXlvOcyJeIxCzKruUPTEQDBShLWfg(wmXlvOcyJeIxCzKruUPTEQDBShLWtM)<wmXlvOcyJeIxCzKruUPTEQDBShLWfg(wmXlvOcyJeIxCzKruUPTEQDBShLWtn):continue
    if wmXlvOcyJeIxCzKruUPTEQDBShLWtb!=wmXlvOcyJeIxCzKruUPTEQDBShLWtV:
     if wmXlvOcyJeIxCzKruUPTEQDBShLWtg!='':wmXlvOcyJeIxCzKruUPTEQDBShLWtA[wmXlvOcyJeIxCzKruUPTEQDBShLWtb]=wmXlvOcyJeIxCzKruUPTEQDBShLWtg
     wmXlvOcyJeIxCzKruUPTEQDBShLWtb=wmXlvOcyJeIxCzKruUPTEQDBShLWtV
     wmXlvOcyJeIxCzKruUPTEQDBShLWtg =''
    if wmXlvOcyJeIxCzKruUPTEQDBShLWtg:wmXlvOcyJeIxCzKruUPTEQDBShLWtg+='\n'
    wmXlvOcyJeIxCzKruUPTEQDBShLWtg+=wmXlvOcyJeIxCzKruUPTEQDBShLWtf['title']+'\n'
    wmXlvOcyJeIxCzKruUPTEQDBShLWtg+=' [%s ~ %s]'%(wmXlvOcyJeIxCzKruUPTEQDBShLWtf['startTime'][-5:],wmXlvOcyJeIxCzKruUPTEQDBShLWtf['endTime'][-5:])+'\n'
   if wmXlvOcyJeIxCzKruUPTEQDBShLWtg:wmXlvOcyJeIxCzKruUPTEQDBShLWtA[wmXlvOcyJeIxCzKruUPTEQDBShLWtb]=wmXlvOcyJeIxCzKruUPTEQDBShLWtg
  except wmXlvOcyJeIxCzKruUPTEQDBShLWfb as exception:
   wmXlvOcyJeIxCzKruUPTEQDBShLWfa(exception)
  return wmXlvOcyJeIxCzKruUPTEQDBShLWtA
 def GetEventLiveList(wmXlvOcyJeIxCzKruUPTEQDBShLWYf):
  wmXlvOcyJeIxCzKruUPTEQDBShLWtY=[]
  wmXlvOcyJeIxCzKruUPTEQDBShLWtq =0
  try:
   wmXlvOcyJeIxCzKruUPTEQDBShLWtR=wmXlvOcyJeIxCzKruUPTEQDBShLWYf.Get_Now_Datetime()
   wmXlvOcyJeIxCzKruUPTEQDBShLWtF=wmXlvOcyJeIxCzKruUPTEQDBShLWtR.strftime('%Y-%m-%d')
  except wmXlvOcyJeIxCzKruUPTEQDBShLWfb as exception:
   wmXlvOcyJeIxCzKruUPTEQDBShLWfa(exception)
   return wmXlvOcyJeIxCzKruUPTEQDBShLWtY,wmXlvOcyJeIxCzKruUPTEQDBShLWtq
  try:
   wmXlvOcyJeIxCzKruUPTEQDBShLWto=wmXlvOcyJeIxCzKruUPTEQDBShLWYf.API_DOMAIN+'/api/v2/player/lives/'+wmXlvOcyJeIxCzKruUPTEQDBShLWtF 
   wmXlvOcyJeIxCzKruUPTEQDBShLWYA=wmXlvOcyJeIxCzKruUPTEQDBShLWYf.makeDefaultCookies()
   wmXlvOcyJeIxCzKruUPTEQDBShLWYV=wmXlvOcyJeIxCzKruUPTEQDBShLWYf.callRequestCookies('Get',wmXlvOcyJeIxCzKruUPTEQDBShLWto,payload=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,params=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,headers=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,cookies=wmXlvOcyJeIxCzKruUPTEQDBShLWYA)
   wmXlvOcyJeIxCzKruUPTEQDBShLWtq=wmXlvOcyJeIxCzKruUPTEQDBShLWYV.status_code 
   wmXlvOcyJeIxCzKruUPTEQDBShLWYq=json.loads(wmXlvOcyJeIxCzKruUPTEQDBShLWYV.text)
   for wmXlvOcyJeIxCzKruUPTEQDBShLWtN in wmXlvOcyJeIxCzKruUPTEQDBShLWYq:
    for wmXlvOcyJeIxCzKruUPTEQDBShLWtf in wmXlvOcyJeIxCzKruUPTEQDBShLWtN['liveNowList']:
     wmXlvOcyJeIxCzKruUPTEQDBShLWtH={}
     wmXlvOcyJeIxCzKruUPTEQDBShLWtH['mediatype']='video'
     if wmXlvOcyJeIxCzKruUPTEQDBShLWtf['gameDesc']['title']==wmXlvOcyJeIxCzKruUPTEQDBShLWfA or wmXlvOcyJeIxCzKruUPTEQDBShLWtf['gameDesc']['title']=='':
      wmXlvOcyJeIxCzKruUPTEQDBShLWts='%s ( %s : %s )'%(wmXlvOcyJeIxCzKruUPTEQDBShLWtf['leagueName'],wmXlvOcyJeIxCzKruUPTEQDBShLWtf['homeNameShort'],wmXlvOcyJeIxCzKruUPTEQDBShLWtf['awayNameShort'])
     else:
      wmXlvOcyJeIxCzKruUPTEQDBShLWts=wmXlvOcyJeIxCzKruUPTEQDBShLWtf['gameDesc']['title']
     wmXlvOcyJeIxCzKruUPTEQDBShLWtp={'liveId':wmXlvOcyJeIxCzKruUPTEQDBShLWtf['liveId'],'title':wmXlvOcyJeIxCzKruUPTEQDBShLWts,'logo':wmXlvOcyJeIxCzKruUPTEQDBShLWtf['gameDesc']['leagueLogo'],'free':wmXlvOcyJeIxCzKruUPTEQDBShLWtf['isFree'],'startTime':wmXlvOcyJeIxCzKruUPTEQDBShLWtf['startTime'],'info':wmXlvOcyJeIxCzKruUPTEQDBShLWtH}
     wmXlvOcyJeIxCzKruUPTEQDBShLWtY.append(wmXlvOcyJeIxCzKruUPTEQDBShLWtp)
  except wmXlvOcyJeIxCzKruUPTEQDBShLWfb as exception:
   wmXlvOcyJeIxCzKruUPTEQDBShLWfa(exception)
  return wmXlvOcyJeIxCzKruUPTEQDBShLWtY,wmXlvOcyJeIxCzKruUPTEQDBShLWtq
 def GetEventLiveList_sub(wmXlvOcyJeIxCzKruUPTEQDBShLWYf,tDate):
  wmXlvOcyJeIxCzKruUPTEQDBShLWtY=[]
  try:
   wmXlvOcyJeIxCzKruUPTEQDBShLWto=wmXlvOcyJeIxCzKruUPTEQDBShLWYf.API_DOMAIN+'/api/v2/player/lives/'+tDate
   wmXlvOcyJeIxCzKruUPTEQDBShLWYA=wmXlvOcyJeIxCzKruUPTEQDBShLWYf.makeDefaultCookies()
   wmXlvOcyJeIxCzKruUPTEQDBShLWYV=wmXlvOcyJeIxCzKruUPTEQDBShLWYf.callRequestCookies('Get',wmXlvOcyJeIxCzKruUPTEQDBShLWto,payload=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,params=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,headers=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,cookies=wmXlvOcyJeIxCzKruUPTEQDBShLWYA)
   wmXlvOcyJeIxCzKruUPTEQDBShLWYq=json.loads(wmXlvOcyJeIxCzKruUPTEQDBShLWYV.text)
   for wmXlvOcyJeIxCzKruUPTEQDBShLWtN in wmXlvOcyJeIxCzKruUPTEQDBShLWYq:
    for wmXlvOcyJeIxCzKruUPTEQDBShLWtf in wmXlvOcyJeIxCzKruUPTEQDBShLWtN['liveNowList']:
     wmXlvOcyJeIxCzKruUPTEQDBShLWtH={}
     wmXlvOcyJeIxCzKruUPTEQDBShLWtH['mediatype']='video'
     if wmXlvOcyJeIxCzKruUPTEQDBShLWtf['gameDesc']['title']==wmXlvOcyJeIxCzKruUPTEQDBShLWfA or wmXlvOcyJeIxCzKruUPTEQDBShLWtf['gameDesc']['title']=='':
      wmXlvOcyJeIxCzKruUPTEQDBShLWts='%s ( %s : %s )'%(wmXlvOcyJeIxCzKruUPTEQDBShLWtf['leagueName'],wmXlvOcyJeIxCzKruUPTEQDBShLWtf['homeNameShort'],wmXlvOcyJeIxCzKruUPTEQDBShLWtf['awayNameShort'])
     else:
      wmXlvOcyJeIxCzKruUPTEQDBShLWts=wmXlvOcyJeIxCzKruUPTEQDBShLWtf['gameDesc']['title']
     wmXlvOcyJeIxCzKruUPTEQDBShLWtp={'liveId':wmXlvOcyJeIxCzKruUPTEQDBShLWtf['liveId'],'title':wmXlvOcyJeIxCzKruUPTEQDBShLWts,'logo':wmXlvOcyJeIxCzKruUPTEQDBShLWtf['gameDesc']['leagueLogo'],'free':wmXlvOcyJeIxCzKruUPTEQDBShLWtf['isFree'],'startTime':wmXlvOcyJeIxCzKruUPTEQDBShLWtf['startTime'],'info':wmXlvOcyJeIxCzKruUPTEQDBShLWtH}
     wmXlvOcyJeIxCzKruUPTEQDBShLWtY.append(wmXlvOcyJeIxCzKruUPTEQDBShLWtp)
  except wmXlvOcyJeIxCzKruUPTEQDBShLWfb as exception:
   wmXlvOcyJeIxCzKruUPTEQDBShLWfa(exception)
  return wmXlvOcyJeIxCzKruUPTEQDBShLWtY
 def GetEventLive_videoId(wmXlvOcyJeIxCzKruUPTEQDBShLWYf,liveId):
  wmXlvOcyJeIxCzKruUPTEQDBShLWti=''
  try:
   wmXlvOcyJeIxCzKruUPTEQDBShLWto=wmXlvOcyJeIxCzKruUPTEQDBShLWYf.API_DOMAIN+'/api/v2/live/'+liveId
   wmXlvOcyJeIxCzKruUPTEQDBShLWYV=wmXlvOcyJeIxCzKruUPTEQDBShLWYf.callRequestCookies('Get',wmXlvOcyJeIxCzKruUPTEQDBShLWto,payload=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,params=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,headers=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,cookies=wmXlvOcyJeIxCzKruUPTEQDBShLWfA)
   wmXlvOcyJeIxCzKruUPTEQDBShLWYq=json.loads(wmXlvOcyJeIxCzKruUPTEQDBShLWYV.text)
   wmXlvOcyJeIxCzKruUPTEQDBShLWjY=wmXlvOcyJeIxCzKruUPTEQDBShLWYq['videoId']
   wmXlvOcyJeIxCzKruUPTEQDBShLWti=wmXlvOcyJeIxCzKruUPTEQDBShLWjY.replace('ref:','')
  except wmXlvOcyJeIxCzKruUPTEQDBShLWfb as exception:
   wmXlvOcyJeIxCzKruUPTEQDBShLWfa(exception)
  return wmXlvOcyJeIxCzKruUPTEQDBShLWti
 def CheckMainEnd(wmXlvOcyJeIxCzKruUPTEQDBShLWYf):
  wmXlvOcyJeIxCzKruUPTEQDBShLWjt=base64.standard_b64encode((wmXlvOcyJeIxCzKruUPTEQDBShLWYf.SPOTV_PMCODE+wmXlvOcyJeIxCzKruUPTEQDBShLWYf.SPOTV_SESSIONID).encode()).decode('utf-8')
  if wmXlvOcyJeIxCzKruUPTEQDBShLWjt=='OTg3MTgzMzM0Ng==' or wmXlvOcyJeIxCzKruUPTEQDBShLWjt=='OTg3MTgzMzExNw==':return wmXlvOcyJeIxCzKruUPTEQDBShLWfM
  return wmXlvOcyJeIxCzKruUPTEQDBShLWfd
 def CheckSubEnd(wmXlvOcyJeIxCzKruUPTEQDBShLWYf):
  wmXlvOcyJeIxCzKruUPTEQDBShLWjo=wmXlvOcyJeIxCzKruUPTEQDBShLWfd
  try:
   if wmXlvOcyJeIxCzKruUPTEQDBShLWYf.CheckMainEnd():return wmXlvOcyJeIxCzKruUPTEQDBShLWfM 
   if wmXlvOcyJeIxCzKruUPTEQDBShLWYf.SPOTV_SUBEND=='0':return wmXlvOcyJeIxCzKruUPTEQDBShLWjo
   wmXlvOcyJeIxCzKruUPTEQDBShLWjf =wmXlvOcyJeIxCzKruUPTEQDBShLWfg(wmXlvOcyJeIxCzKruUPTEQDBShLWYf.Get_Now_Datetime().strftime('%Y%m%d'))
   wmXlvOcyJeIxCzKruUPTEQDBShLWjH =wmXlvOcyJeIxCzKruUPTEQDBShLWfg(wmXlvOcyJeIxCzKruUPTEQDBShLWYf.SPOTV_SUBEND)/1000
   wmXlvOcyJeIxCzKruUPTEQDBShLWjp =wmXlvOcyJeIxCzKruUPTEQDBShLWfg(datetime.datetime.fromtimestamp(wmXlvOcyJeIxCzKruUPTEQDBShLWjH,datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul')).strftime('%Y%m%d'))
   if wmXlvOcyJeIxCzKruUPTEQDBShLWjf<=wmXlvOcyJeIxCzKruUPTEQDBShLWjp:wmXlvOcyJeIxCzKruUPTEQDBShLWjo=wmXlvOcyJeIxCzKruUPTEQDBShLWfM
  except wmXlvOcyJeIxCzKruUPTEQDBShLWfb as exception:
   wmXlvOcyJeIxCzKruUPTEQDBShLWfa(exception)
   return wmXlvOcyJeIxCzKruUPTEQDBShLWjo
  return wmXlvOcyJeIxCzKruUPTEQDBShLWjo
 def GetMainJspath(wmXlvOcyJeIxCzKruUPTEQDBShLWYf):
  wmXlvOcyJeIxCzKruUPTEQDBShLWjA=''
  try:
   wmXlvOcyJeIxCzKruUPTEQDBShLWto=wmXlvOcyJeIxCzKruUPTEQDBShLWYf.API_DOMAIN
   wmXlvOcyJeIxCzKruUPTEQDBShLWYV=wmXlvOcyJeIxCzKruUPTEQDBShLWYf.callRequestCookies('Get',wmXlvOcyJeIxCzKruUPTEQDBShLWto,payload=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,params=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,headers=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,cookies=wmXlvOcyJeIxCzKruUPTEQDBShLWfA)
   wmXlvOcyJeIxCzKruUPTEQDBShLWjd=wmXlvOcyJeIxCzKruUPTEQDBShLWYV.text
   wmXlvOcyJeIxCzKruUPTEQDBShLWja =re.findall('https://cdn.spotvnow.co.kr/dist/js/.{20}\.js',wmXlvOcyJeIxCzKruUPTEQDBShLWjd)[0]
   wmXlvOcyJeIxCzKruUPTEQDBShLWjA=wmXlvOcyJeIxCzKruUPTEQDBShLWja
  except wmXlvOcyJeIxCzKruUPTEQDBShLWfb as exception:
   wmXlvOcyJeIxCzKruUPTEQDBShLWfa(exception)
  return wmXlvOcyJeIxCzKruUPTEQDBShLWjA
 def GetBcPlayerUrl(wmXlvOcyJeIxCzKruUPTEQDBShLWYf):
  wmXlvOcyJeIxCzKruUPTEQDBShLWjG=''
  try:
   wmXlvOcyJeIxCzKruUPTEQDBShLWto=wmXlvOcyJeIxCzKruUPTEQDBShLWYf.GetMainJspath()
   if wmXlvOcyJeIxCzKruUPTEQDBShLWto=='':return wmXlvOcyJeIxCzKruUPTEQDBShLWjG
   wmXlvOcyJeIxCzKruUPTEQDBShLWYV=wmXlvOcyJeIxCzKruUPTEQDBShLWYf.callRequestCookies('Get',wmXlvOcyJeIxCzKruUPTEQDBShLWto,payload=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,params=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,headers=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,cookies=wmXlvOcyJeIxCzKruUPTEQDBShLWfA)
   wmXlvOcyJeIxCzKruUPTEQDBShLWjd=wmXlvOcyJeIxCzKruUPTEQDBShLWYV.text
   wmXlvOcyJeIxCzKruUPTEQDBShLWjM =re.findall('bc:\s*\"\d{13}\",\s*player:\s*\".{9}\"',wmXlvOcyJeIxCzKruUPTEQDBShLWjd)[0]
   wmXlvOcyJeIxCzKruUPTEQDBShLWjM =wmXlvOcyJeIxCzKruUPTEQDBShLWjM.replace('bc','"bc"')
   wmXlvOcyJeIxCzKruUPTEQDBShLWjM =wmXlvOcyJeIxCzKruUPTEQDBShLWjM.replace('player','"player"')
   wmXlvOcyJeIxCzKruUPTEQDBShLWjM ='{'+wmXlvOcyJeIxCzKruUPTEQDBShLWjM+'}'
   wmXlvOcyJeIxCzKruUPTEQDBShLWjM =json.loads(wmXlvOcyJeIxCzKruUPTEQDBShLWjM)
   bc =wmXlvOcyJeIxCzKruUPTEQDBShLWjM['bc']
   wmXlvOcyJeIxCzKruUPTEQDBShLWjb =wmXlvOcyJeIxCzKruUPTEQDBShLWjM['player']
   wmXlvOcyJeIxCzKruUPTEQDBShLWjG="%s/%s/%s_default/index.min.js"%(wmXlvOcyJeIxCzKruUPTEQDBShLWYf.BC_DOMAIN,bc,wmXlvOcyJeIxCzKruUPTEQDBShLWjb)
  except wmXlvOcyJeIxCzKruUPTEQDBShLWfb as exception:
   wmXlvOcyJeIxCzKruUPTEQDBShLWfa(exception)
  return wmXlvOcyJeIxCzKruUPTEQDBShLWjG
 def GetPolicyKey(wmXlvOcyJeIxCzKruUPTEQDBShLWYf):
  wmXlvOcyJeIxCzKruUPTEQDBShLWjg=policykey=''
  try:
   wmXlvOcyJeIxCzKruUPTEQDBShLWto=wmXlvOcyJeIxCzKruUPTEQDBShLWYf.GetBcPlayerUrl()
   if wmXlvOcyJeIxCzKruUPTEQDBShLWto=='':return wmXlvOcyJeIxCzKruUPTEQDBShLWjg,wmXlvOcyJeIxCzKruUPTEQDBShLWjn
   wmXlvOcyJeIxCzKruUPTEQDBShLWYV=wmXlvOcyJeIxCzKruUPTEQDBShLWYf.callRequestCookies('Get',wmXlvOcyJeIxCzKruUPTEQDBShLWto,payload=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,params=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,headers=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,cookies=wmXlvOcyJeIxCzKruUPTEQDBShLWfA)
   wmXlvOcyJeIxCzKruUPTEQDBShLWjd=wmXlvOcyJeIxCzKruUPTEQDBShLWYV.text
   wmXlvOcyJeIxCzKruUPTEQDBShLWja =re.findall('accountId:\s*\"\d{13}\",\s*policyKey:\s*\".[^(){}]{100,300}\"',wmXlvOcyJeIxCzKruUPTEQDBShLWjd)[0]
   wmXlvOcyJeIxCzKruUPTEQDBShLWja =wmXlvOcyJeIxCzKruUPTEQDBShLWja.replace('accountId','"accountId"')
   wmXlvOcyJeIxCzKruUPTEQDBShLWja =wmXlvOcyJeIxCzKruUPTEQDBShLWja.replace('policyKey','"policyKey"')
   wmXlvOcyJeIxCzKruUPTEQDBShLWja ='{'+wmXlvOcyJeIxCzKruUPTEQDBShLWja+'}'
   wmXlvOcyJeIxCzKruUPTEQDBShLWjV=json.loads(wmXlvOcyJeIxCzKruUPTEQDBShLWja)
   wmXlvOcyJeIxCzKruUPTEQDBShLWjg =wmXlvOcyJeIxCzKruUPTEQDBShLWjV['accountId']
   wmXlvOcyJeIxCzKruUPTEQDBShLWjn =wmXlvOcyJeIxCzKruUPTEQDBShLWjV['policyKey']
  except wmXlvOcyJeIxCzKruUPTEQDBShLWfb as exception:
   wmXlvOcyJeIxCzKruUPTEQDBShLWfa(exception)
  return wmXlvOcyJeIxCzKruUPTEQDBShLWjg,wmXlvOcyJeIxCzKruUPTEQDBShLWjn
 def GetBroadURL(wmXlvOcyJeIxCzKruUPTEQDBShLWYf,wmXlvOcyJeIxCzKruUPTEQDBShLWti,mediatype,wmXlvOcyJeIxCzKruUPTEQDBShLWoH):
  wmXlvOcyJeIxCzKruUPTEQDBShLWjk=''
  try:
   if mediatype=='live':
    wmXlvOcyJeIxCzKruUPTEQDBShLWti='ref%3A'+wmXlvOcyJeIxCzKruUPTEQDBShLWti
   else:
    wmXlvOcyJeIxCzKruUPTEQDBShLWti=wmXlvOcyJeIxCzKruUPTEQDBShLWYf.GetReplay_UrlId(wmXlvOcyJeIxCzKruUPTEQDBShLWti,wmXlvOcyJeIxCzKruUPTEQDBShLWoH)
    if wmXlvOcyJeIxCzKruUPTEQDBShLWti=='':return wmXlvOcyJeIxCzKruUPTEQDBShLWjk
   wmXlvOcyJeIxCzKruUPTEQDBShLWto=wmXlvOcyJeIxCzKruUPTEQDBShLWYf.PLAYER_DOMAIN+'/playback/v1/accounts/'+wmXlvOcyJeIxCzKruUPTEQDBShLWYf.SPOTV_ACCOUNTID+'/videos/'+wmXlvOcyJeIxCzKruUPTEQDBShLWti
   wmXlvOcyJeIxCzKruUPTEQDBShLWjq={'accept':'application/json;pk='+wmXlvOcyJeIxCzKruUPTEQDBShLWYf.SPOTV_POLICYKEY}
   wmXlvOcyJeIxCzKruUPTEQDBShLWYV=wmXlvOcyJeIxCzKruUPTEQDBShLWYf.callRequestCookies('Get',wmXlvOcyJeIxCzKruUPTEQDBShLWto,payload=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,params=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,headers=wmXlvOcyJeIxCzKruUPTEQDBShLWjq,cookies=wmXlvOcyJeIxCzKruUPTEQDBShLWfA)
   wmXlvOcyJeIxCzKruUPTEQDBShLWjR=json.loads(wmXlvOcyJeIxCzKruUPTEQDBShLWYV.text)
   wmXlvOcyJeIxCzKruUPTEQDBShLWjk=wmXlvOcyJeIxCzKruUPTEQDBShLWjR['sources'][0]['src']
   if mediatype=='live':
    wmXlvOcyJeIxCzKruUPTEQDBShLWjk=wmXlvOcyJeIxCzKruUPTEQDBShLWjk.replace('playlist.m3u8','playlist_dvr.m3u8')
   wmXlvOcyJeIxCzKruUPTEQDBShLWjk=wmXlvOcyJeIxCzKruUPTEQDBShLWjk.replace('http://','https://')
  except wmXlvOcyJeIxCzKruUPTEQDBShLWfb as exception:
   wmXlvOcyJeIxCzKruUPTEQDBShLWfa(exception)
  return wmXlvOcyJeIxCzKruUPTEQDBShLWjk
 def GetTitleGroupList(wmXlvOcyJeIxCzKruUPTEQDBShLWYf):
  wmXlvOcyJeIxCzKruUPTEQDBShLWtY=[]
  wmXlvOcyJeIxCzKruUPTEQDBShLWjF=wmXlvOcyJeIxCzKruUPTEQDBShLWfd
  try:
   wmXlvOcyJeIxCzKruUPTEQDBShLWto=wmXlvOcyJeIxCzKruUPTEQDBShLWYf.API_DOMAIN+'/api/v2/home/web'
   wmXlvOcyJeIxCzKruUPTEQDBShLWYV=wmXlvOcyJeIxCzKruUPTEQDBShLWYf.callRequestCookies('Get',wmXlvOcyJeIxCzKruUPTEQDBShLWto,payload=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,params=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,headers=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,cookies=wmXlvOcyJeIxCzKruUPTEQDBShLWfA)
   wmXlvOcyJeIxCzKruUPTEQDBShLWYq=json.loads(wmXlvOcyJeIxCzKruUPTEQDBShLWYV.text)
   for wmXlvOcyJeIxCzKruUPTEQDBShLWtf in wmXlvOcyJeIxCzKruUPTEQDBShLWYq:
    wmXlvOcyJeIxCzKruUPTEQDBShLWtH={}
    wmXlvOcyJeIxCzKruUPTEQDBShLWtH['mediatype']='episode'
    if wmXlvOcyJeIxCzKruUPTEQDBShLWfG(wmXlvOcyJeIxCzKruUPTEQDBShLWtf['type'])=='3':
     wmXlvOcyJeIxCzKruUPTEQDBShLWjN=''
     for wmXlvOcyJeIxCzKruUPTEQDBShLWjs in wmXlvOcyJeIxCzKruUPTEQDBShLWtf['data']['list']:
      wmXlvOcyJeIxCzKruUPTEQDBShLWji='[%s] %s vs %s\n<%s>\n\n'%(wmXlvOcyJeIxCzKruUPTEQDBShLWjs['gameDesc']['roundName'],wmXlvOcyJeIxCzKruUPTEQDBShLWjs['gameDesc']['homeNameShort'],wmXlvOcyJeIxCzKruUPTEQDBShLWjs['gameDesc']['awayNameShort'],wmXlvOcyJeIxCzKruUPTEQDBShLWjs['gameDesc']['beginDate'])
      wmXlvOcyJeIxCzKruUPTEQDBShLWjN+=wmXlvOcyJeIxCzKruUPTEQDBShLWji
     wmXlvOcyJeIxCzKruUPTEQDBShLWtp={'title':wmXlvOcyJeIxCzKruUPTEQDBShLWtf['title'],'logo':wmXlvOcyJeIxCzKruUPTEQDBShLWtf['logo'],'reagueId':wmXlvOcyJeIxCzKruUPTEQDBShLWfG(wmXlvOcyJeIxCzKruUPTEQDBShLWtf['destId']),'subGame':wmXlvOcyJeIxCzKruUPTEQDBShLWjN,'info':wmXlvOcyJeIxCzKruUPTEQDBShLWtH}
     wmXlvOcyJeIxCzKruUPTEQDBShLWtY.append(wmXlvOcyJeIxCzKruUPTEQDBShLWtp)
     if wmXlvOcyJeIxCzKruUPTEQDBShLWfG(wmXlvOcyJeIxCzKruUPTEQDBShLWtf['destId'])=='13':wmXlvOcyJeIxCzKruUPTEQDBShLWjF=wmXlvOcyJeIxCzKruUPTEQDBShLWfM
   if wmXlvOcyJeIxCzKruUPTEQDBShLWjF==wmXlvOcyJeIxCzKruUPTEQDBShLWfd:
    wmXlvOcyJeIxCzKruUPTEQDBShLWtH={'mediatype':'episode'}
    wmXlvOcyJeIxCzKruUPTEQDBShLWtp={'title':'UFC','logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200928/a643c7cf1c285fb0b4469c07d4c09c28.png','reagueId':'13','subGame':'','info':wmXlvOcyJeIxCzKruUPTEQDBShLWtH}
    wmXlvOcyJeIxCzKruUPTEQDBShLWtY.append(wmXlvOcyJeIxCzKruUPTEQDBShLWtp)
  except wmXlvOcyJeIxCzKruUPTEQDBShLWfb as exception:
   wmXlvOcyJeIxCzKruUPTEQDBShLWfa(exception)
  return wmXlvOcyJeIxCzKruUPTEQDBShLWtY
 def GetPopularGroupList(wmXlvOcyJeIxCzKruUPTEQDBShLWYf):
  wmXlvOcyJeIxCzKruUPTEQDBShLWtY=[]
  try:
   wmXlvOcyJeIxCzKruUPTEQDBShLWto=wmXlvOcyJeIxCzKruUPTEQDBShLWYf.API_DOMAIN+'/api/v2/home/web'
   wmXlvOcyJeIxCzKruUPTEQDBShLWYV=wmXlvOcyJeIxCzKruUPTEQDBShLWYf.callRequestCookies('Get',wmXlvOcyJeIxCzKruUPTEQDBShLWto,payload=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,params=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,headers=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,cookies=wmXlvOcyJeIxCzKruUPTEQDBShLWfA)
   wmXlvOcyJeIxCzKruUPTEQDBShLWYq=json.loads(wmXlvOcyJeIxCzKruUPTEQDBShLWYV.text)
   for wmXlvOcyJeIxCzKruUPTEQDBShLWtf in wmXlvOcyJeIxCzKruUPTEQDBShLWYq:
    wmXlvOcyJeIxCzKruUPTEQDBShLWtH={}
    wmXlvOcyJeIxCzKruUPTEQDBShLWtH['mediatype']='episode'
    if wmXlvOcyJeIxCzKruUPTEQDBShLWfG(wmXlvOcyJeIxCzKruUPTEQDBShLWtf['type'])=='1' and wmXlvOcyJeIxCzKruUPTEQDBShLWfG(wmXlvOcyJeIxCzKruUPTEQDBShLWtf['destId'])=='4':
     for wmXlvOcyJeIxCzKruUPTEQDBShLWjs in wmXlvOcyJeIxCzKruUPTEQDBShLWtf['data']['list']:
      wmXlvOcyJeIxCzKruUPTEQDBShLWtH={}
      wmXlvOcyJeIxCzKruUPTEQDBShLWtH['mediatype']='video'
      wmXlvOcyJeIxCzKruUPTEQDBShLWoY =wmXlvOcyJeIxCzKruUPTEQDBShLWjs['title']
      wmXlvOcyJeIxCzKruUPTEQDBShLWot =wmXlvOcyJeIxCzKruUPTEQDBShLWjs['id']
      wmXlvOcyJeIxCzKruUPTEQDBShLWoj =wmXlvOcyJeIxCzKruUPTEQDBShLWjs['vtype']
      wmXlvOcyJeIxCzKruUPTEQDBShLWof =wmXlvOcyJeIxCzKruUPTEQDBShLWjs['imgUrl']
      wmXlvOcyJeIxCzKruUPTEQDBShLWoH =wmXlvOcyJeIxCzKruUPTEQDBShLWjs['vtypeId']
      wmXlvOcyJeIxCzKruUPTEQDBShLWtH['duration'] =wmXlvOcyJeIxCzKruUPTEQDBShLWfg(wmXlvOcyJeIxCzKruUPTEQDBShLWjs['duration']/1000)
      wmXlvOcyJeIxCzKruUPTEQDBShLWtp={'vodTitle':wmXlvOcyJeIxCzKruUPTEQDBShLWoY,'vodId':wmXlvOcyJeIxCzKruUPTEQDBShLWot,'vodType':wmXlvOcyJeIxCzKruUPTEQDBShLWoj,'thumbnail':wmXlvOcyJeIxCzKruUPTEQDBShLWof,'info':wmXlvOcyJeIxCzKruUPTEQDBShLWtH,'vtypeId':wmXlvOcyJeIxCzKruUPTEQDBShLWfG(wmXlvOcyJeIxCzKruUPTEQDBShLWoH)}
      wmXlvOcyJeIxCzKruUPTEQDBShLWtY.append(wmXlvOcyJeIxCzKruUPTEQDBShLWtp)
  except wmXlvOcyJeIxCzKruUPTEQDBShLWfb as exception:
   wmXlvOcyJeIxCzKruUPTEQDBShLWfa(exception)
  return wmXlvOcyJeIxCzKruUPTEQDBShLWtY
 def GetSeasonList(wmXlvOcyJeIxCzKruUPTEQDBShLWYf,leagueId):
  wmXlvOcyJeIxCzKruUPTEQDBShLWtY=[]
  wmXlvOcyJeIxCzKruUPTEQDBShLWop=wmXlvOcyJeIxCzKruUPTEQDBShLWoA=''
  try:
   wmXlvOcyJeIxCzKruUPTEQDBShLWto=wmXlvOcyJeIxCzKruUPTEQDBShLWYf.API_DOMAIN+'/api/v2/game/league/'+leagueId
   wmXlvOcyJeIxCzKruUPTEQDBShLWYV=wmXlvOcyJeIxCzKruUPTEQDBShLWYf.callRequestCookies('Get',wmXlvOcyJeIxCzKruUPTEQDBShLWto,payload=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,params=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,headers=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,cookies=wmXlvOcyJeIxCzKruUPTEQDBShLWfA)
   wmXlvOcyJeIxCzKruUPTEQDBShLWYq=json.loads(wmXlvOcyJeIxCzKruUPTEQDBShLWYV.text)
   wmXlvOcyJeIxCzKruUPTEQDBShLWop=wmXlvOcyJeIxCzKruUPTEQDBShLWYq['name']
   wmXlvOcyJeIxCzKruUPTEQDBShLWoA=wmXlvOcyJeIxCzKruUPTEQDBShLWfG(wmXlvOcyJeIxCzKruUPTEQDBShLWYq['gameTypeId'])
  except wmXlvOcyJeIxCzKruUPTEQDBShLWfb as exception:
   wmXlvOcyJeIxCzKruUPTEQDBShLWfa(exception)
   return wmXlvOcyJeIxCzKruUPTEQDBShLWtY
  if wmXlvOcyJeIxCzKruUPTEQDBShLWoA=='2':
   try:
    wmXlvOcyJeIxCzKruUPTEQDBShLWto=wmXlvOcyJeIxCzKruUPTEQDBShLWYf.API_DOMAIN+'/api/v2/year/'+leagueId
    wmXlvOcyJeIxCzKruUPTEQDBShLWYV=wmXlvOcyJeIxCzKruUPTEQDBShLWYf.callRequestCookies('Get',wmXlvOcyJeIxCzKruUPTEQDBShLWto,payload=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,params=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,headers=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,cookies=wmXlvOcyJeIxCzKruUPTEQDBShLWfA)
    wmXlvOcyJeIxCzKruUPTEQDBShLWYq=json.loads(wmXlvOcyJeIxCzKruUPTEQDBShLWYV.text)
    for wmXlvOcyJeIxCzKruUPTEQDBShLWtf in wmXlvOcyJeIxCzKruUPTEQDBShLWYq:
     wmXlvOcyJeIxCzKruUPTEQDBShLWtH={}
     wmXlvOcyJeIxCzKruUPTEQDBShLWtH['mediatype']='episode'
     wmXlvOcyJeIxCzKruUPTEQDBShLWtp={'reagueName':wmXlvOcyJeIxCzKruUPTEQDBShLWop,'gameTypeId':wmXlvOcyJeIxCzKruUPTEQDBShLWoA,'seasonName':wmXlvOcyJeIxCzKruUPTEQDBShLWfG(wmXlvOcyJeIxCzKruUPTEQDBShLWtf),'seasonId':wmXlvOcyJeIxCzKruUPTEQDBShLWfG(wmXlvOcyJeIxCzKruUPTEQDBShLWtf),'info':wmXlvOcyJeIxCzKruUPTEQDBShLWtH}
     wmXlvOcyJeIxCzKruUPTEQDBShLWtY.append(wmXlvOcyJeIxCzKruUPTEQDBShLWtp)
   except wmXlvOcyJeIxCzKruUPTEQDBShLWfb as exception:
    wmXlvOcyJeIxCzKruUPTEQDBShLWfa(exception)
    return[]
  else:
   try:
    wmXlvOcyJeIxCzKruUPTEQDBShLWto=wmXlvOcyJeIxCzKruUPTEQDBShLWYf.API_DOMAIN+'/api/v2/season/'+leagueId
    wmXlvOcyJeIxCzKruUPTEQDBShLWYV=wmXlvOcyJeIxCzKruUPTEQDBShLWYf.callRequestCookies('Get',wmXlvOcyJeIxCzKruUPTEQDBShLWto,payload=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,params=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,headers=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,cookies=wmXlvOcyJeIxCzKruUPTEQDBShLWfA)
    wmXlvOcyJeIxCzKruUPTEQDBShLWYq=json.loads(wmXlvOcyJeIxCzKruUPTEQDBShLWYV.text)
    for wmXlvOcyJeIxCzKruUPTEQDBShLWtf in wmXlvOcyJeIxCzKruUPTEQDBShLWYq:
     wmXlvOcyJeIxCzKruUPTEQDBShLWtH={}
     wmXlvOcyJeIxCzKruUPTEQDBShLWtH['mediatype']='episode'
     wmXlvOcyJeIxCzKruUPTEQDBShLWtp={'reagueName':wmXlvOcyJeIxCzKruUPTEQDBShLWop,'gameTypeId':wmXlvOcyJeIxCzKruUPTEQDBShLWoA,'seasonName':wmXlvOcyJeIxCzKruUPTEQDBShLWtf['name'],'seasonId':wmXlvOcyJeIxCzKruUPTEQDBShLWfG(wmXlvOcyJeIxCzKruUPTEQDBShLWtf['id']),'info':wmXlvOcyJeIxCzKruUPTEQDBShLWtH}
     wmXlvOcyJeIxCzKruUPTEQDBShLWtY.append(wmXlvOcyJeIxCzKruUPTEQDBShLWtp)
   except wmXlvOcyJeIxCzKruUPTEQDBShLWfb as exception:
    wmXlvOcyJeIxCzKruUPTEQDBShLWfa(exception)
    return[]
  return wmXlvOcyJeIxCzKruUPTEQDBShLWtY
 def GetGameList(wmXlvOcyJeIxCzKruUPTEQDBShLWYf,wmXlvOcyJeIxCzKruUPTEQDBShLWoA,leagueId,seasonId,page_int):
  wmXlvOcyJeIxCzKruUPTEQDBShLWtY=[]
  wmXlvOcyJeIxCzKruUPTEQDBShLWod=wmXlvOcyJeIxCzKruUPTEQDBShLWfd
  try:
   wmXlvOcyJeIxCzKruUPTEQDBShLWto=wmXlvOcyJeIxCzKruUPTEQDBShLWYf.API_DOMAIN+'/api/v2/vod/league/detail'
   wmXlvOcyJeIxCzKruUPTEQDBShLWoa={'gameType':wmXlvOcyJeIxCzKruUPTEQDBShLWoA,'leagueId':leagueId,'seasonId':seasonId if wmXlvOcyJeIxCzKruUPTEQDBShLWoA!='2' else '','teamId':'','roundId':'','year':'' if wmXlvOcyJeIxCzKruUPTEQDBShLWoA!='2' else seasonId,'pageNo':wmXlvOcyJeIxCzKruUPTEQDBShLWfG(page_int)}
   wmXlvOcyJeIxCzKruUPTEQDBShLWYV=wmXlvOcyJeIxCzKruUPTEQDBShLWYf.callRequestCookies('Get',wmXlvOcyJeIxCzKruUPTEQDBShLWto,payload=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,params=wmXlvOcyJeIxCzKruUPTEQDBShLWoa,headers=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,cookies=wmXlvOcyJeIxCzKruUPTEQDBShLWfA)
   wmXlvOcyJeIxCzKruUPTEQDBShLWYq=json.loads(wmXlvOcyJeIxCzKruUPTEQDBShLWYV.text)
   wmXlvOcyJeIxCzKruUPTEQDBShLWtN=wmXlvOcyJeIxCzKruUPTEQDBShLWYq['list']
   for wmXlvOcyJeIxCzKruUPTEQDBShLWoG in wmXlvOcyJeIxCzKruUPTEQDBShLWtN:
    for wmXlvOcyJeIxCzKruUPTEQDBShLWtf in wmXlvOcyJeIxCzKruUPTEQDBShLWoG['list']:
     wmXlvOcyJeIxCzKruUPTEQDBShLWtH={}
     wmXlvOcyJeIxCzKruUPTEQDBShLWtH['mediatype']='video'
     if wmXlvOcyJeIxCzKruUPTEQDBShLWtf['gameDesc']['title']==wmXlvOcyJeIxCzKruUPTEQDBShLWfA or wmXlvOcyJeIxCzKruUPTEQDBShLWtf['gameDesc']['title']=='':
      wmXlvOcyJeIxCzKruUPTEQDBShLWts ='%s vs %s'%(wmXlvOcyJeIxCzKruUPTEQDBShLWtf['gameDesc']['homeNameShort'],wmXlvOcyJeIxCzKruUPTEQDBShLWtf['gameDesc']['awayNameShort'])
     else:
      wmXlvOcyJeIxCzKruUPTEQDBShLWts =wmXlvOcyJeIxCzKruUPTEQDBShLWtf['gameDesc']['title']
     wmXlvOcyJeIxCzKruUPTEQDBShLWoM =wmXlvOcyJeIxCzKruUPTEQDBShLWtf['gameDesc']['beginDate']
     wmXlvOcyJeIxCzKruUPTEQDBShLWob =wmXlvOcyJeIxCzKruUPTEQDBShLWtf['gameDesc']['id']
     wmXlvOcyJeIxCzKruUPTEQDBShLWog =wmXlvOcyJeIxCzKruUPTEQDBShLWtf['gameDesc']['leagueNameFull']
     wmXlvOcyJeIxCzKruUPTEQDBShLWoV =wmXlvOcyJeIxCzKruUPTEQDBShLWtf['gameDesc']['seasonName']
     wmXlvOcyJeIxCzKruUPTEQDBShLWon =wmXlvOcyJeIxCzKruUPTEQDBShLWtf['gameDesc']['roundName']
     wmXlvOcyJeIxCzKruUPTEQDBShLWok =wmXlvOcyJeIxCzKruUPTEQDBShLWtf['gameDesc']['homeName']
     wmXlvOcyJeIxCzKruUPTEQDBShLWoq =wmXlvOcyJeIxCzKruUPTEQDBShLWtf['gameDesc']['awayName']
     wmXlvOcyJeIxCzKruUPTEQDBShLWoR =wmXlvOcyJeIxCzKruUPTEQDBShLWtf['gameDesc']['homeScore']
     wmXlvOcyJeIxCzKruUPTEQDBShLWoF =wmXlvOcyJeIxCzKruUPTEQDBShLWtf['gameDesc']['awayScore']
     wmXlvOcyJeIxCzKruUPTEQDBShLWoN ='%s\n - %s (%s)\n - %s\n\nhome : %s (Score %s)\n\naway : %s (Score %s)'%(wmXlvOcyJeIxCzKruUPTEQDBShLWog,wmXlvOcyJeIxCzKruUPTEQDBShLWoV,wmXlvOcyJeIxCzKruUPTEQDBShLWon,wmXlvOcyJeIxCzKruUPTEQDBShLWoM,wmXlvOcyJeIxCzKruUPTEQDBShLWok,wmXlvOcyJeIxCzKruUPTEQDBShLWoR,wmXlvOcyJeIxCzKruUPTEQDBShLWoq,wmXlvOcyJeIxCzKruUPTEQDBShLWoF)
     wmXlvOcyJeIxCzKruUPTEQDBShLWtH['plot']=wmXlvOcyJeIxCzKruUPTEQDBShLWoN
     wmXlvOcyJeIxCzKruUPTEQDBShLWos =wmXlvOcyJeIxCzKruUPTEQDBShLWtf['replayVod']['count']
     wmXlvOcyJeIxCzKruUPTEQDBShLWoi=wmXlvOcyJeIxCzKruUPTEQDBShLWtf['highlightVod']['count']
     wmXlvOcyJeIxCzKruUPTEQDBShLWfY =wmXlvOcyJeIxCzKruUPTEQDBShLWtf['vods']['count']
     wmXlvOcyJeIxCzKruUPTEQDBShLWof='' 
     wmXlvOcyJeIxCzKruUPTEQDBShLWft=wmXlvOcyJeIxCzKruUPTEQDBShLWos+wmXlvOcyJeIxCzKruUPTEQDBShLWoi+wmXlvOcyJeIxCzKruUPTEQDBShLWfY
     if wmXlvOcyJeIxCzKruUPTEQDBShLWft==0:
      if wmXlvOcyJeIxCzKruUPTEQDBShLWoA=='2':
       wmXlvOcyJeIxCzKruUPTEQDBShLWts='----- %s -----'%(wmXlvOcyJeIxCzKruUPTEQDBShLWoV)
       wmXlvOcyJeIxCzKruUPTEQDBShLWoM=''
      else:
       wmXlvOcyJeIxCzKruUPTEQDBShLWts+=' - 관련영상 없음'
       wmXlvOcyJeIxCzKruUPTEQDBShLWtH['plot']+='\n\n ** 관련영상 없음 **'
     else:
      if wmXlvOcyJeIxCzKruUPTEQDBShLWos!=0:
       wmXlvOcyJeIxCzKruUPTEQDBShLWof =wmXlvOcyJeIxCzKruUPTEQDBShLWtf['replayVod']['list'][0]['imgUrl']
      elif wmXlvOcyJeIxCzKruUPTEQDBShLWoi!=0:
       wmXlvOcyJeIxCzKruUPTEQDBShLWof =wmXlvOcyJeIxCzKruUPTEQDBShLWtf['highlightVod']['list'][0]['imgUrl']
      else:
       wmXlvOcyJeIxCzKruUPTEQDBShLWof =wmXlvOcyJeIxCzKruUPTEQDBShLWtf['vods']['list'][0]['imgUrl']
     wmXlvOcyJeIxCzKruUPTEQDBShLWtp={'gameTitle':wmXlvOcyJeIxCzKruUPTEQDBShLWts,'gameId':wmXlvOcyJeIxCzKruUPTEQDBShLWob,'beginDate':wmXlvOcyJeIxCzKruUPTEQDBShLWoM[:11],'thumbnail':wmXlvOcyJeIxCzKruUPTEQDBShLWof,'info':wmXlvOcyJeIxCzKruUPTEQDBShLWtH,'leaguenm':wmXlvOcyJeIxCzKruUPTEQDBShLWog,'seasonnm':wmXlvOcyJeIxCzKruUPTEQDBShLWoV,'roundnm':wmXlvOcyJeIxCzKruUPTEQDBShLWon,'totVodCnt':wmXlvOcyJeIxCzKruUPTEQDBShLWft}
     wmXlvOcyJeIxCzKruUPTEQDBShLWtY.append(wmXlvOcyJeIxCzKruUPTEQDBShLWtp)
   if wmXlvOcyJeIxCzKruUPTEQDBShLWoA=='2':
    if wmXlvOcyJeIxCzKruUPTEQDBShLWYq['count']>page_int*wmXlvOcyJeIxCzKruUPTEQDBShLWYf.GAMELIST_LIMIT:wmXlvOcyJeIxCzKruUPTEQDBShLWod=wmXlvOcyJeIxCzKruUPTEQDBShLWfM
   else:
    if wmXlvOcyJeIxCzKruUPTEQDBShLWYq['list'][0]['count']>page_int*wmXlvOcyJeIxCzKruUPTEQDBShLWYf.GAMELIST_LIMIT:wmXlvOcyJeIxCzKruUPTEQDBShLWod=wmXlvOcyJeIxCzKruUPTEQDBShLWfM
  except wmXlvOcyJeIxCzKruUPTEQDBShLWfb as exception:
   wmXlvOcyJeIxCzKruUPTEQDBShLWfa(exception)
  return wmXlvOcyJeIxCzKruUPTEQDBShLWtY,wmXlvOcyJeIxCzKruUPTEQDBShLWod
 def GetGameVodList(wmXlvOcyJeIxCzKruUPTEQDBShLWYf,wmXlvOcyJeIxCzKruUPTEQDBShLWob):
  wmXlvOcyJeIxCzKruUPTEQDBShLWtY=[]
  wmXlvOcyJeIxCzKruUPTEQDBShLWfj=''
  try:
   wmXlvOcyJeIxCzKruUPTEQDBShLWto=wmXlvOcyJeIxCzKruUPTEQDBShLWYf.API_DOMAIN+'/api/v2/vod/game'
   wmXlvOcyJeIxCzKruUPTEQDBShLWoa={'gameId':wmXlvOcyJeIxCzKruUPTEQDBShLWob,'pageItem':'1000'}
   wmXlvOcyJeIxCzKruUPTEQDBShLWYV=wmXlvOcyJeIxCzKruUPTEQDBShLWYf.callRequestCookies('Get',wmXlvOcyJeIxCzKruUPTEQDBShLWto,payload=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,params=wmXlvOcyJeIxCzKruUPTEQDBShLWoa,headers=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,cookies=wmXlvOcyJeIxCzKruUPTEQDBShLWfA)
   wmXlvOcyJeIxCzKruUPTEQDBShLWYq=json.loads(wmXlvOcyJeIxCzKruUPTEQDBShLWYV.text)
   wmXlvOcyJeIxCzKruUPTEQDBShLWoG=wmXlvOcyJeIxCzKruUPTEQDBShLWYq['list']
   for wmXlvOcyJeIxCzKruUPTEQDBShLWtf in wmXlvOcyJeIxCzKruUPTEQDBShLWoG:
    wmXlvOcyJeIxCzKruUPTEQDBShLWtH={}
    wmXlvOcyJeIxCzKruUPTEQDBShLWtH['mediatype']='video'
    wmXlvOcyJeIxCzKruUPTEQDBShLWoY =wmXlvOcyJeIxCzKruUPTEQDBShLWtf['title']
    wmXlvOcyJeIxCzKruUPTEQDBShLWot =wmXlvOcyJeIxCzKruUPTEQDBShLWtf['id']
    wmXlvOcyJeIxCzKruUPTEQDBShLWoj =wmXlvOcyJeIxCzKruUPTEQDBShLWtf['vtype']
    wmXlvOcyJeIxCzKruUPTEQDBShLWof =wmXlvOcyJeIxCzKruUPTEQDBShLWtf['imgUrl']
    wmXlvOcyJeIxCzKruUPTEQDBShLWoH =wmXlvOcyJeIxCzKruUPTEQDBShLWtf['vtypeId']
    wmXlvOcyJeIxCzKruUPTEQDBShLWtH['duration'] =wmXlvOcyJeIxCzKruUPTEQDBShLWfg(wmXlvOcyJeIxCzKruUPTEQDBShLWtf['duration']/1000)
    wmXlvOcyJeIxCzKruUPTEQDBShLWtp={'vodTitle':wmXlvOcyJeIxCzKruUPTEQDBShLWoY,'vodId':wmXlvOcyJeIxCzKruUPTEQDBShLWot,'vodType':wmXlvOcyJeIxCzKruUPTEQDBShLWoj,'thumbnail':wmXlvOcyJeIxCzKruUPTEQDBShLWof,'info':wmXlvOcyJeIxCzKruUPTEQDBShLWtH,'vtypeId':wmXlvOcyJeIxCzKruUPTEQDBShLWfG(wmXlvOcyJeIxCzKruUPTEQDBShLWoH)}
    wmXlvOcyJeIxCzKruUPTEQDBShLWtY.append(wmXlvOcyJeIxCzKruUPTEQDBShLWtp)
  except wmXlvOcyJeIxCzKruUPTEQDBShLWfb as exception:
   wmXlvOcyJeIxCzKruUPTEQDBShLWfa(exception)
  return wmXlvOcyJeIxCzKruUPTEQDBShLWtY
 def GetReplay_UrlId(wmXlvOcyJeIxCzKruUPTEQDBShLWYf,wmXlvOcyJeIxCzKruUPTEQDBShLWfj,wmXlvOcyJeIxCzKruUPTEQDBShLWoH):
  wmXlvOcyJeIxCzKruUPTEQDBShLWfo=wmXlvOcyJeIxCzKruUPTEQDBShLWti=''
  wmXlvOcyJeIxCzKruUPTEQDBShLWfH=''
  try:
   wmXlvOcyJeIxCzKruUPTEQDBShLWto=wmXlvOcyJeIxCzKruUPTEQDBShLWYf.API_DOMAIN+'/api/v2/vod/'+wmXlvOcyJeIxCzKruUPTEQDBShLWfj
   wmXlvOcyJeIxCzKruUPTEQDBShLWYV=wmXlvOcyJeIxCzKruUPTEQDBShLWYf.callRequestCookies('Get',wmXlvOcyJeIxCzKruUPTEQDBShLWto,payload=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,params=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,headers=wmXlvOcyJeIxCzKruUPTEQDBShLWfA,cookies=wmXlvOcyJeIxCzKruUPTEQDBShLWfA)
   wmXlvOcyJeIxCzKruUPTEQDBShLWYq=json.loads(wmXlvOcyJeIxCzKruUPTEQDBShLWYV.text)
   wmXlvOcyJeIxCzKruUPTEQDBShLWfo =wmXlvOcyJeIxCzKruUPTEQDBShLWYq['clipId']
   wmXlvOcyJeIxCzKruUPTEQDBShLWti=wmXlvOcyJeIxCzKruUPTEQDBShLWYq['videoId']
   wmXlvOcyJeIxCzKruUPTEQDBShLWfH=wmXlvOcyJeIxCzKruUPTEQDBShLWfo
   if wmXlvOcyJeIxCzKruUPTEQDBShLWYf.CheckSubEnd()or wmXlvOcyJeIxCzKruUPTEQDBShLWoH!='1':wmXlvOcyJeIxCzKruUPTEQDBShLWfH=wmXlvOcyJeIxCzKruUPTEQDBShLWti 
  except wmXlvOcyJeIxCzKruUPTEQDBShLWfb as exception:
   wmXlvOcyJeIxCzKruUPTEQDBShLWfa(exception)
  return wmXlvOcyJeIxCzKruUPTEQDBShLWfH
# Created by pyminifier (https://github.com/liftoff/pyminifier)
