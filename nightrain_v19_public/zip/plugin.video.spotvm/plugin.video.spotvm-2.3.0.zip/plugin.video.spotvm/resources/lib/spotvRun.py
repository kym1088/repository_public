__author__="NightRain"
vKGiVYfqbaHPcTMRohCSXzmnpElgWj=object
vKGiVYfqbaHPcTMRohCSXzmnpElgWD=None
vKGiVYfqbaHPcTMRohCSXzmnpElgWA=False
vKGiVYfqbaHPcTMRohCSXzmnpElgQF=True
vKGiVYfqbaHPcTMRohCSXzmnpElgQL=getattr
vKGiVYfqbaHPcTMRohCSXzmnpElgQI=type
vKGiVYfqbaHPcTMRohCSXzmnpElgQB=int
vKGiVYfqbaHPcTMRohCSXzmnpElgQW=list
vKGiVYfqbaHPcTMRohCSXzmnpElgQN=len
vKGiVYfqbaHPcTMRohCSXzmnpElgQu=str
vKGiVYfqbaHPcTMRohCSXzmnpElgQs=id
vKGiVYfqbaHPcTMRohCSXzmnpElgQJ=open
vKGiVYfqbaHPcTMRohCSXzmnpElgQt=dict
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
vKGiVYfqbaHPcTMRohCSXzmnpElgFI=[{'title':'TV 채널 (유료사용자만 지원)','mode':'LIVE_GROUP','icon':'live.png'},{'title':'Live중계 (경기중에만 재생)','mode':'ELIVE_GROUP','icon':'live.png'},{'title':'-----------------','mode':'XXX'},{'title':'오늘의 추천 VOD','mode':'NOW_GROUP'},{'title':'인기영상 5','mode':'POP_GROUP'},{'title':'-----------------','mode':'XXX'},{'title':'VOD (리그, 경기별)','mode':'VOD_GROUP'},{'title':'Watched (시청목록)','mode':'WATCH','icon':'history.png'},]
vKGiVYfqbaHPcTMRohCSXzmnpElgFB={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
vKGiVYfqbaHPcTMRohCSXzmnpElgFW=xbmcvfs.translatePath(os.path.join(__profile__,'spotv_cookies.json'))
from spotvCore import*
class vKGiVYfqbaHPcTMRohCSXzmnpElgFL(vKGiVYfqbaHPcTMRohCSXzmnpElgWj):
 def __init__(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ,vKGiVYfqbaHPcTMRohCSXzmnpElgFN,vKGiVYfqbaHPcTMRohCSXzmnpElgFu,vKGiVYfqbaHPcTMRohCSXzmnpElgFs):
  vKGiVYfqbaHPcTMRohCSXzmnpElgFQ._addon_url =vKGiVYfqbaHPcTMRohCSXzmnpElgFN
  vKGiVYfqbaHPcTMRohCSXzmnpElgFQ._addon_handle=vKGiVYfqbaHPcTMRohCSXzmnpElgFu
  vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.main_params =vKGiVYfqbaHPcTMRohCSXzmnpElgFs
  vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.SpotvObj =dIgPAXqneCWjrycuLJpvFwxEDQzYim() 
 def addon_noti(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ,sting):
  try:
   vKGiVYfqbaHPcTMRohCSXzmnpElgFt=xbmcgui.Dialog()
   vKGiVYfqbaHPcTMRohCSXzmnpElgFt.notification(__addonname__,sting)
  except:
   vKGiVYfqbaHPcTMRohCSXzmnpElgWD
 def addon_log(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ,string):
  try:
   vKGiVYfqbaHPcTMRohCSXzmnpElgFx=string.encode('utf-8','ignore')
  except:
   vKGiVYfqbaHPcTMRohCSXzmnpElgFx='addonException: addon_log'
  vKGiVYfqbaHPcTMRohCSXzmnpElgFd=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,vKGiVYfqbaHPcTMRohCSXzmnpElgFx),level=vKGiVYfqbaHPcTMRohCSXzmnpElgFd)
 def get_keyboard_input(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ,vKGiVYfqbaHPcTMRohCSXzmnpElgFO):
  vKGiVYfqbaHPcTMRohCSXzmnpElgFk=vKGiVYfqbaHPcTMRohCSXzmnpElgWD
  kb=xbmc.Keyboard()
  kb.setHeading(vKGiVYfqbaHPcTMRohCSXzmnpElgFO)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   vKGiVYfqbaHPcTMRohCSXzmnpElgFk=kb.getText()
  return vKGiVYfqbaHPcTMRohCSXzmnpElgFk
 def get_settings_account(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ):
  vKGiVYfqbaHPcTMRohCSXzmnpElgFy =__addon__.getSetting('id')
  vKGiVYfqbaHPcTMRohCSXzmnpElgFU =__addon__.getSetting('pw')
  return(vKGiVYfqbaHPcTMRohCSXzmnpElgFy,vKGiVYfqbaHPcTMRohCSXzmnpElgFU)
 def get_settings_hidescoreyn(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ):
  vKGiVYfqbaHPcTMRohCSXzmnpElgFw =__addon__.getSetting('hidescore')
  if vKGiVYfqbaHPcTMRohCSXzmnpElgFw=='false':
   return vKGiVYfqbaHPcTMRohCSXzmnpElgWA
  else:
   return vKGiVYfqbaHPcTMRohCSXzmnpElgQF
 def add_dir(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ,label,sublabel='',img='',infoLabels=vKGiVYfqbaHPcTMRohCSXzmnpElgWD,isFolder=vKGiVYfqbaHPcTMRohCSXzmnpElgQF,params='',isLink=vKGiVYfqbaHPcTMRohCSXzmnpElgWA,ContextMenu=vKGiVYfqbaHPcTMRohCSXzmnpElgWD):
  vKGiVYfqbaHPcTMRohCSXzmnpElgFr='%s?%s'%(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ._addon_url,urllib.parse.urlencode(params))
  if sublabel:vKGiVYfqbaHPcTMRohCSXzmnpElgFO='%s < %s >'%(label,sublabel)
  else: vKGiVYfqbaHPcTMRohCSXzmnpElgFO=label
  if not img:img='DefaultFolder.png'
  vKGiVYfqbaHPcTMRohCSXzmnpElgFe=xbmcgui.ListItem(vKGiVYfqbaHPcTMRohCSXzmnpElgFO)
  vKGiVYfqbaHPcTMRohCSXzmnpElgFe.setArt({'thumb':img,'icon':img,'poster':img})
  if vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.SpotvObj.KodiVersion>=20:
   if infoLabels:vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.Set_InfoTag(vKGiVYfqbaHPcTMRohCSXzmnpElgFe.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:vKGiVYfqbaHPcTMRohCSXzmnpElgFe.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   vKGiVYfqbaHPcTMRohCSXzmnpElgFe.setProperty('IsPlayable','true')
  if ContextMenu:vKGiVYfqbaHPcTMRohCSXzmnpElgFe.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ._addon_handle,vKGiVYfqbaHPcTMRohCSXzmnpElgFr,vKGiVYfqbaHPcTMRohCSXzmnpElgFe,isFolder)
 def Set_InfoTag(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ,video_InfoTag:xbmc.InfoTagVideo,vKGiVYfqbaHPcTMRohCSXzmnpElgLs):
  for vKGiVYfqbaHPcTMRohCSXzmnpElgFj,value in vKGiVYfqbaHPcTMRohCSXzmnpElgLs.items():
   if vKGiVYfqbaHPcTMRohCSXzmnpElgFB[vKGiVYfqbaHPcTMRohCSXzmnpElgFj]['type']=='string':
    vKGiVYfqbaHPcTMRohCSXzmnpElgQL(video_InfoTag,vKGiVYfqbaHPcTMRohCSXzmnpElgFB[vKGiVYfqbaHPcTMRohCSXzmnpElgFj]['func'])(value)
   elif vKGiVYfqbaHPcTMRohCSXzmnpElgFB[vKGiVYfqbaHPcTMRohCSXzmnpElgFj]['type']=='int':
    if vKGiVYfqbaHPcTMRohCSXzmnpElgQI(value)==vKGiVYfqbaHPcTMRohCSXzmnpElgQB:
     vKGiVYfqbaHPcTMRohCSXzmnpElgFD=vKGiVYfqbaHPcTMRohCSXzmnpElgQB(value)
    else:
     vKGiVYfqbaHPcTMRohCSXzmnpElgFD=0
    vKGiVYfqbaHPcTMRohCSXzmnpElgQL(video_InfoTag,vKGiVYfqbaHPcTMRohCSXzmnpElgFB[vKGiVYfqbaHPcTMRohCSXzmnpElgFj]['func'])(vKGiVYfqbaHPcTMRohCSXzmnpElgFD)
   elif vKGiVYfqbaHPcTMRohCSXzmnpElgFB[vKGiVYfqbaHPcTMRohCSXzmnpElgFj]['type']=='actor':
    if value!=[]:
     vKGiVYfqbaHPcTMRohCSXzmnpElgQL(video_InfoTag,vKGiVYfqbaHPcTMRohCSXzmnpElgFB[vKGiVYfqbaHPcTMRohCSXzmnpElgFj]['func'])([xbmc.Actor(name)for name in value])
   elif vKGiVYfqbaHPcTMRohCSXzmnpElgFB[vKGiVYfqbaHPcTMRohCSXzmnpElgFj]['type']=='list':
    if vKGiVYfqbaHPcTMRohCSXzmnpElgQI(value)==vKGiVYfqbaHPcTMRohCSXzmnpElgQW:
     vKGiVYfqbaHPcTMRohCSXzmnpElgQL(video_InfoTag,vKGiVYfqbaHPcTMRohCSXzmnpElgFB[vKGiVYfqbaHPcTMRohCSXzmnpElgFj]['func'])(value)
    else:
     vKGiVYfqbaHPcTMRohCSXzmnpElgQL(video_InfoTag,vKGiVYfqbaHPcTMRohCSXzmnpElgFB[vKGiVYfqbaHPcTMRohCSXzmnpElgFj]['func'])([value])
 def get_selQuality(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ,etype):
  try:
   vKGiVYfqbaHPcTMRohCSXzmnpElgFA='selected_quality'
   vKGiVYfqbaHPcTMRohCSXzmnpElgLF=[1080,720,540]
   vKGiVYfqbaHPcTMRohCSXzmnpElgLI=vKGiVYfqbaHPcTMRohCSXzmnpElgQB(__addon__.getSetting(vKGiVYfqbaHPcTMRohCSXzmnpElgFA))
   return vKGiVYfqbaHPcTMRohCSXzmnpElgLF[vKGiVYfqbaHPcTMRohCSXzmnpElgLI]
  except:
   vKGiVYfqbaHPcTMRohCSXzmnpElgWD
  return 1080 
 def dp_Main_List(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ):
  for vKGiVYfqbaHPcTMRohCSXzmnpElgLB in vKGiVYfqbaHPcTMRohCSXzmnpElgFI:
   vKGiVYfqbaHPcTMRohCSXzmnpElgFO=vKGiVYfqbaHPcTMRohCSXzmnpElgLB.get('title')
   vKGiVYfqbaHPcTMRohCSXzmnpElgLW=''
   vKGiVYfqbaHPcTMRohCSXzmnpElgLQ={'mode':vKGiVYfqbaHPcTMRohCSXzmnpElgLB.get('mode'),'page':'1'}
   if vKGiVYfqbaHPcTMRohCSXzmnpElgLB.get('mode')=='XXX':
    vKGiVYfqbaHPcTMRohCSXzmnpElgLN=vKGiVYfqbaHPcTMRohCSXzmnpElgWA
    vKGiVYfqbaHPcTMRohCSXzmnpElgLu =vKGiVYfqbaHPcTMRohCSXzmnpElgQF
   else:
    vKGiVYfqbaHPcTMRohCSXzmnpElgLN=vKGiVYfqbaHPcTMRohCSXzmnpElgQF
    vKGiVYfqbaHPcTMRohCSXzmnpElgLu =vKGiVYfqbaHPcTMRohCSXzmnpElgWA
   vKGiVYfqbaHPcTMRohCSXzmnpElgLs={'title':vKGiVYfqbaHPcTMRohCSXzmnpElgFO,'plot':vKGiVYfqbaHPcTMRohCSXzmnpElgFO}
   if vKGiVYfqbaHPcTMRohCSXzmnpElgLB.get('mode')=='XXX':vKGiVYfqbaHPcTMRohCSXzmnpElgLs=vKGiVYfqbaHPcTMRohCSXzmnpElgWD
   if 'icon' in vKGiVYfqbaHPcTMRohCSXzmnpElgLB:vKGiVYfqbaHPcTMRohCSXzmnpElgLW=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',vKGiVYfqbaHPcTMRohCSXzmnpElgLB.get('icon')) 
   vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.add_dir(vKGiVYfqbaHPcTMRohCSXzmnpElgFO,sublabel='',img=vKGiVYfqbaHPcTMRohCSXzmnpElgLW,infoLabels=vKGiVYfqbaHPcTMRohCSXzmnpElgLs,isFolder=vKGiVYfqbaHPcTMRohCSXzmnpElgLN,params=vKGiVYfqbaHPcTMRohCSXzmnpElgLQ,isLink=vKGiVYfqbaHPcTMRohCSXzmnpElgLu)
  if vKGiVYfqbaHPcTMRohCSXzmnpElgQN(vKGiVYfqbaHPcTMRohCSXzmnpElgFI)>0:xbmcplugin.endOfDirectory(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ._addon_handle,cacheToDisc=vKGiVYfqbaHPcTMRohCSXzmnpElgWA)
 def dp_MainLeague_List(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ,args):
  vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.addon_log('dp_MainLeague_List')
  vKGiVYfqbaHPcTMRohCSXzmnpElgLt=vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.SpotvObj.GetTitleGroupList()
  vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.addon_log('dp_MainLeague_List cnt : '+vKGiVYfqbaHPcTMRohCSXzmnpElgQu(vKGiVYfqbaHPcTMRohCSXzmnpElgQN(vKGiVYfqbaHPcTMRohCSXzmnpElgLt)))
  for vKGiVYfqbaHPcTMRohCSXzmnpElgLx in vKGiVYfqbaHPcTMRohCSXzmnpElgLt:
   vKGiVYfqbaHPcTMRohCSXzmnpElgFO =vKGiVYfqbaHPcTMRohCSXzmnpElgLx.get('title')
   vKGiVYfqbaHPcTMRohCSXzmnpElgLd =vKGiVYfqbaHPcTMRohCSXzmnpElgLx.get('logo')
   vKGiVYfqbaHPcTMRohCSXzmnpElgLk =vKGiVYfqbaHPcTMRohCSXzmnpElgLx.get('reagueId')
   vKGiVYfqbaHPcTMRohCSXzmnpElgLy =vKGiVYfqbaHPcTMRohCSXzmnpElgLx.get('subGame')
   vKGiVYfqbaHPcTMRohCSXzmnpElgLU={'mediatype':'episode','plot':'%s\n\n%s'%(vKGiVYfqbaHPcTMRohCSXzmnpElgFO,vKGiVYfqbaHPcTMRohCSXzmnpElgLy)}
   vKGiVYfqbaHPcTMRohCSXzmnpElgLQ={'mode':'LEAGUE_GROUP','reagueId':vKGiVYfqbaHPcTMRohCSXzmnpElgLk}
   vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.add_dir(vKGiVYfqbaHPcTMRohCSXzmnpElgFO,sublabel=vKGiVYfqbaHPcTMRohCSXzmnpElgWD,img=vKGiVYfqbaHPcTMRohCSXzmnpElgLd,infoLabels=vKGiVYfqbaHPcTMRohCSXzmnpElgLU,isFolder=vKGiVYfqbaHPcTMRohCSXzmnpElgQF,params=vKGiVYfqbaHPcTMRohCSXzmnpElgLQ)
  if vKGiVYfqbaHPcTMRohCSXzmnpElgQN(vKGiVYfqbaHPcTMRohCSXzmnpElgLt)>0:xbmcplugin.endOfDirectory(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ._addon_handle,cacheToDisc=vKGiVYfqbaHPcTMRohCSXzmnpElgWA)
 def dp_NowVod_GroupList(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ,args):
  vKGiVYfqbaHPcTMRohCSXzmnpElgLw=vKGiVYfqbaHPcTMRohCSXzmnpElgQB(args.get('page'))
  vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.addon_log('dp_NowVod_GroupList page : '+vKGiVYfqbaHPcTMRohCSXzmnpElgQu(vKGiVYfqbaHPcTMRohCSXzmnpElgLw))
  vKGiVYfqbaHPcTMRohCSXzmnpElgLt,vKGiVYfqbaHPcTMRohCSXzmnpElgLr=vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.SpotvObj.Get_NowVod_GroupList(vKGiVYfqbaHPcTMRohCSXzmnpElgLw)
  vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.addon_log('dp_NowVod_GroupList cnt : '+vKGiVYfqbaHPcTMRohCSXzmnpElgQu(vKGiVYfqbaHPcTMRohCSXzmnpElgQN(vKGiVYfqbaHPcTMRohCSXzmnpElgLt)))
  for vKGiVYfqbaHPcTMRohCSXzmnpElgLx in vKGiVYfqbaHPcTMRohCSXzmnpElgLt:
   vKGiVYfqbaHPcTMRohCSXzmnpElgLO =vKGiVYfqbaHPcTMRohCSXzmnpElgLx.get('vodTitle')
   vKGiVYfqbaHPcTMRohCSXzmnpElgLe =vKGiVYfqbaHPcTMRohCSXzmnpElgLx.get('vodId')
   vKGiVYfqbaHPcTMRohCSXzmnpElgLj =vKGiVYfqbaHPcTMRohCSXzmnpElgLx.get('vodType')
   vKGiVYfqbaHPcTMRohCSXzmnpElgLd=vKGiVYfqbaHPcTMRohCSXzmnpElgLx.get('thumbnail')
   vKGiVYfqbaHPcTMRohCSXzmnpElgLD =vKGiVYfqbaHPcTMRohCSXzmnpElgLx.get('vtypeId')
   vKGiVYfqbaHPcTMRohCSXzmnpElgLA =vKGiVYfqbaHPcTMRohCSXzmnpElgLx.get('duration')
   vKGiVYfqbaHPcTMRohCSXzmnpElgLU={'mediatype':'episode','duration':vKGiVYfqbaHPcTMRohCSXzmnpElgLA,'plot':vKGiVYfqbaHPcTMRohCSXzmnpElgLO}
   vKGiVYfqbaHPcTMRohCSXzmnpElgLQ={'mode':'NOW_VOD','mediacode':vKGiVYfqbaHPcTMRohCSXzmnpElgLe,'mediatype':'vod','vtypeId':vKGiVYfqbaHPcTMRohCSXzmnpElgLD}
   vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.add_dir(vKGiVYfqbaHPcTMRohCSXzmnpElgLO,sublabel=vKGiVYfqbaHPcTMRohCSXzmnpElgLj,img=vKGiVYfqbaHPcTMRohCSXzmnpElgLd,infoLabels=vKGiVYfqbaHPcTMRohCSXzmnpElgLU,isFolder=vKGiVYfqbaHPcTMRohCSXzmnpElgWA,params=vKGiVYfqbaHPcTMRohCSXzmnpElgLQ)
  if vKGiVYfqbaHPcTMRohCSXzmnpElgLr:
   vKGiVYfqbaHPcTMRohCSXzmnpElgLQ['mode'] ='NOW_GROUP' 
   vKGiVYfqbaHPcTMRohCSXzmnpElgLQ['page'] =vKGiVYfqbaHPcTMRohCSXzmnpElgQu(vKGiVYfqbaHPcTMRohCSXzmnpElgLw+1)
   vKGiVYfqbaHPcTMRohCSXzmnpElgFO='[B]%s >>[/B]'%'다음 페이지'
   vKGiVYfqbaHPcTMRohCSXzmnpElgIF=vKGiVYfqbaHPcTMRohCSXzmnpElgQu(vKGiVYfqbaHPcTMRohCSXzmnpElgLw+1)
   vKGiVYfqbaHPcTMRohCSXzmnpElgLW=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.add_dir(vKGiVYfqbaHPcTMRohCSXzmnpElgFO,sublabel=vKGiVYfqbaHPcTMRohCSXzmnpElgIF,img=vKGiVYfqbaHPcTMRohCSXzmnpElgLW,infoLabels=vKGiVYfqbaHPcTMRohCSXzmnpElgWD,isFolder=vKGiVYfqbaHPcTMRohCSXzmnpElgQF,params=vKGiVYfqbaHPcTMRohCSXzmnpElgLQ)
  xbmcplugin.setContent(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ._addon_handle,cacheToDisc=vKGiVYfqbaHPcTMRohCSXzmnpElgWA)
 def dp_PopVod_GroupList(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ,args):
  vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.addon_log('dp_PopVod_GroupList ')
  vKGiVYfqbaHPcTMRohCSXzmnpElgLt=vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.SpotvObj.GetPopularGroupList()
  vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.addon_log('dp_PopVod_GroupList cnt : '+vKGiVYfqbaHPcTMRohCSXzmnpElgQu(vKGiVYfqbaHPcTMRohCSXzmnpElgQN(vKGiVYfqbaHPcTMRohCSXzmnpElgLt)))
  for vKGiVYfqbaHPcTMRohCSXzmnpElgLx in vKGiVYfqbaHPcTMRohCSXzmnpElgLt:
   vKGiVYfqbaHPcTMRohCSXzmnpElgLO =vKGiVYfqbaHPcTMRohCSXzmnpElgLx.get('vodTitle')
   vKGiVYfqbaHPcTMRohCSXzmnpElgLe =vKGiVYfqbaHPcTMRohCSXzmnpElgLx.get('vodId')
   vKGiVYfqbaHPcTMRohCSXzmnpElgLj =vKGiVYfqbaHPcTMRohCSXzmnpElgLx.get('vodType')
   vKGiVYfqbaHPcTMRohCSXzmnpElgLd=vKGiVYfqbaHPcTMRohCSXzmnpElgLx.get('thumbnail')
   vKGiVYfqbaHPcTMRohCSXzmnpElgLD =vKGiVYfqbaHPcTMRohCSXzmnpElgLx.get('vtypeId')
   vKGiVYfqbaHPcTMRohCSXzmnpElgLA =vKGiVYfqbaHPcTMRohCSXzmnpElgLx.get('duration')
   vKGiVYfqbaHPcTMRohCSXzmnpElgLU={'mediatype':'episode','duration':vKGiVYfqbaHPcTMRohCSXzmnpElgLA,'plot':vKGiVYfqbaHPcTMRohCSXzmnpElgLO}
   vKGiVYfqbaHPcTMRohCSXzmnpElgLQ={'mode':'POP_VOD','mediacode':vKGiVYfqbaHPcTMRohCSXzmnpElgLe,'mediatype':'vod','vtypeId':vKGiVYfqbaHPcTMRohCSXzmnpElgLD}
   vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.add_dir(vKGiVYfqbaHPcTMRohCSXzmnpElgLO,sublabel=vKGiVYfqbaHPcTMRohCSXzmnpElgLj,img=vKGiVYfqbaHPcTMRohCSXzmnpElgLd,infoLabels=vKGiVYfqbaHPcTMRohCSXzmnpElgLU,isFolder=vKGiVYfqbaHPcTMRohCSXzmnpElgWA,params=vKGiVYfqbaHPcTMRohCSXzmnpElgLQ)
  xbmcplugin.setContent(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ._addon_handle,cacheToDisc=vKGiVYfqbaHPcTMRohCSXzmnpElgWA)
 def dp_Season_List(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ,args):
  vKGiVYfqbaHPcTMRohCSXzmnpElgLk=args.get('reagueId')
  vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.addon_log('Season_List - reagueId : '+vKGiVYfqbaHPcTMRohCSXzmnpElgLk)
  vKGiVYfqbaHPcTMRohCSXzmnpElgLt=vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.SpotvObj.GetSeasonList(vKGiVYfqbaHPcTMRohCSXzmnpElgLk)
  for vKGiVYfqbaHPcTMRohCSXzmnpElgLx in vKGiVYfqbaHPcTMRohCSXzmnpElgLt:
   vKGiVYfqbaHPcTMRohCSXzmnpElgIB =vKGiVYfqbaHPcTMRohCSXzmnpElgLx.get('reagueName')
   vKGiVYfqbaHPcTMRohCSXzmnpElgIW =vKGiVYfqbaHPcTMRohCSXzmnpElgLx.get('gameTypeId')
   vKGiVYfqbaHPcTMRohCSXzmnpElgIQ =vKGiVYfqbaHPcTMRohCSXzmnpElgLx.get('seasonName')
   vKGiVYfqbaHPcTMRohCSXzmnpElgIN =vKGiVYfqbaHPcTMRohCSXzmnpElgLx.get('seasonId')
   vKGiVYfqbaHPcTMRohCSXzmnpElgLU={'mediatype':'episode','plot':'%s - %s'%(vKGiVYfqbaHPcTMRohCSXzmnpElgIB,vKGiVYfqbaHPcTMRohCSXzmnpElgIQ)}
   vKGiVYfqbaHPcTMRohCSXzmnpElgLQ={'mode':'SEASON_GROUP','reagueId':vKGiVYfqbaHPcTMRohCSXzmnpElgLk,'seasonId':vKGiVYfqbaHPcTMRohCSXzmnpElgIN,'gameTypeId':vKGiVYfqbaHPcTMRohCSXzmnpElgIW,'page':'1'}
   vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.add_dir(vKGiVYfqbaHPcTMRohCSXzmnpElgIB,sublabel=vKGiVYfqbaHPcTMRohCSXzmnpElgIQ,img='',infoLabels=vKGiVYfqbaHPcTMRohCSXzmnpElgLU,isFolder=vKGiVYfqbaHPcTMRohCSXzmnpElgQF,params=vKGiVYfqbaHPcTMRohCSXzmnpElgLQ)
  if vKGiVYfqbaHPcTMRohCSXzmnpElgQN(vKGiVYfqbaHPcTMRohCSXzmnpElgLt)>0:xbmcplugin.endOfDirectory(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ._addon_handle,cacheToDisc=vKGiVYfqbaHPcTMRohCSXzmnpElgWA)
 def dp_Game_List(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ,args):
  vKGiVYfqbaHPcTMRohCSXzmnpElgIW=args.get('gameTypeId')
  vKGiVYfqbaHPcTMRohCSXzmnpElgLk =args.get('reagueId')
  vKGiVYfqbaHPcTMRohCSXzmnpElgIN =args.get('seasonId')
  vKGiVYfqbaHPcTMRohCSXzmnpElgLw =vKGiVYfqbaHPcTMRohCSXzmnpElgQB(args.get('page'))
  vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.addon_log('Game_List - gameTypeId : '+vKGiVYfqbaHPcTMRohCSXzmnpElgIW)
  vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.addon_log('Game_List - reagueId   : '+vKGiVYfqbaHPcTMRohCSXzmnpElgLk)
  vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.addon_log('Game_List - seasonId   : '+vKGiVYfqbaHPcTMRohCSXzmnpElgIN)
  vKGiVYfqbaHPcTMRohCSXzmnpElgLt,vKGiVYfqbaHPcTMRohCSXzmnpElgLr=vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.SpotvObj.GetGameList(vKGiVYfqbaHPcTMRohCSXzmnpElgIW,vKGiVYfqbaHPcTMRohCSXzmnpElgLk,vKGiVYfqbaHPcTMRohCSXzmnpElgIN,vKGiVYfqbaHPcTMRohCSXzmnpElgLw,hidescore=vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.get_settings_hidescoreyn())
  for vKGiVYfqbaHPcTMRohCSXzmnpElgLx in vKGiVYfqbaHPcTMRohCSXzmnpElgLt:
   vKGiVYfqbaHPcTMRohCSXzmnpElgIu =vKGiVYfqbaHPcTMRohCSXzmnpElgLx.get('gameTitle')
   vKGiVYfqbaHPcTMRohCSXzmnpElgIs =vKGiVYfqbaHPcTMRohCSXzmnpElgLx.get('beginDate')
   vKGiVYfqbaHPcTMRohCSXzmnpElgLd =vKGiVYfqbaHPcTMRohCSXzmnpElgLx.get('thumbnail')
   vKGiVYfqbaHPcTMRohCSXzmnpElgIJ =vKGiVYfqbaHPcTMRohCSXzmnpElgLx.get('gameId')
   vKGiVYfqbaHPcTMRohCSXzmnpElgIt =vKGiVYfqbaHPcTMRohCSXzmnpElgLx.get('totVodCnt')
   vKGiVYfqbaHPcTMRohCSXzmnpElgIx =vKGiVYfqbaHPcTMRohCSXzmnpElgLx.get('leaguenm')
   vKGiVYfqbaHPcTMRohCSXzmnpElgId =vKGiVYfqbaHPcTMRohCSXzmnpElgLx.get('seasonnm')
   vKGiVYfqbaHPcTMRohCSXzmnpElgIk =vKGiVYfqbaHPcTMRohCSXzmnpElgLx.get('roundnm')
   vKGiVYfqbaHPcTMRohCSXzmnpElgIy =vKGiVYfqbaHPcTMRohCSXzmnpElgLx.get('info_plot')
   vKGiVYfqbaHPcTMRohCSXzmnpElgIU ='%s < %s >'%(vKGiVYfqbaHPcTMRohCSXzmnpElgIu,vKGiVYfqbaHPcTMRohCSXzmnpElgIs)
   vKGiVYfqbaHPcTMRohCSXzmnpElgLU={'mediatype':'video','plot':vKGiVYfqbaHPcTMRohCSXzmnpElgIy}
   vKGiVYfqbaHPcTMRohCSXzmnpElgLQ={'mode':'GAME_VOD_GROUP' if vKGiVYfqbaHPcTMRohCSXzmnpElgIt!=0 else 'XXX','saveTitle':vKGiVYfqbaHPcTMRohCSXzmnpElgIU,'saveImg':vKGiVYfqbaHPcTMRohCSXzmnpElgLd,'saveInfo':vKGiVYfqbaHPcTMRohCSXzmnpElgLU['plot'],'gameid':vKGiVYfqbaHPcTMRohCSXzmnpElgIJ,'totVodCnt':vKGiVYfqbaHPcTMRohCSXzmnpElgIt,}
   vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.add_dir(vKGiVYfqbaHPcTMRohCSXzmnpElgIu,sublabel=vKGiVYfqbaHPcTMRohCSXzmnpElgIs,img=vKGiVYfqbaHPcTMRohCSXzmnpElgLd,infoLabels=vKGiVYfqbaHPcTMRohCSXzmnpElgLU,isFolder=vKGiVYfqbaHPcTMRohCSXzmnpElgQF,params=vKGiVYfqbaHPcTMRohCSXzmnpElgLQ)
  if vKGiVYfqbaHPcTMRohCSXzmnpElgLr:
   vKGiVYfqbaHPcTMRohCSXzmnpElgLQ['mode'] ='SEASON_GROUP' 
   vKGiVYfqbaHPcTMRohCSXzmnpElgLQ['reagueId'] =vKGiVYfqbaHPcTMRohCSXzmnpElgLk
   vKGiVYfqbaHPcTMRohCSXzmnpElgLQ['seasonId'] =vKGiVYfqbaHPcTMRohCSXzmnpElgIN
   vKGiVYfqbaHPcTMRohCSXzmnpElgLQ['gameTypeId']=vKGiVYfqbaHPcTMRohCSXzmnpElgIW
   vKGiVYfqbaHPcTMRohCSXzmnpElgLQ['page'] =vKGiVYfqbaHPcTMRohCSXzmnpElgQu(vKGiVYfqbaHPcTMRohCSXzmnpElgLw+1)
   vKGiVYfqbaHPcTMRohCSXzmnpElgFO='[B]%s >>[/B]'%'다음 페이지'
   vKGiVYfqbaHPcTMRohCSXzmnpElgIF=vKGiVYfqbaHPcTMRohCSXzmnpElgQu(vKGiVYfqbaHPcTMRohCSXzmnpElgLw+1)
   vKGiVYfqbaHPcTMRohCSXzmnpElgLW=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.add_dir(vKGiVYfqbaHPcTMRohCSXzmnpElgFO,sublabel=vKGiVYfqbaHPcTMRohCSXzmnpElgIF,img=vKGiVYfqbaHPcTMRohCSXzmnpElgLW,infoLabels=vKGiVYfqbaHPcTMRohCSXzmnpElgWD,isFolder=vKGiVYfqbaHPcTMRohCSXzmnpElgQF,params=vKGiVYfqbaHPcTMRohCSXzmnpElgLQ)
  if vKGiVYfqbaHPcTMRohCSXzmnpElgQN(vKGiVYfqbaHPcTMRohCSXzmnpElgLt)>0:xbmcplugin.endOfDirectory(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ._addon_handle,cacheToDisc=vKGiVYfqbaHPcTMRohCSXzmnpElgWA)
 def dp_GameVod_List(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ,args):
  vKGiVYfqbaHPcTMRohCSXzmnpElgIw =args.get('gameid')
  vKGiVYfqbaHPcTMRohCSXzmnpElgIU=args.get('saveTitle')
  vKGiVYfqbaHPcTMRohCSXzmnpElgIr =args.get('saveImg')
  vKGiVYfqbaHPcTMRohCSXzmnpElgIO =args.get('saveInfo')
  vKGiVYfqbaHPcTMRohCSXzmnpElgLt=vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.SpotvObj.GetGameVodList(vKGiVYfqbaHPcTMRohCSXzmnpElgIw)
  for vKGiVYfqbaHPcTMRohCSXzmnpElgLx in vKGiVYfqbaHPcTMRohCSXzmnpElgLt:
   vKGiVYfqbaHPcTMRohCSXzmnpElgLO =vKGiVYfqbaHPcTMRohCSXzmnpElgLx.get('vodTitle')
   vKGiVYfqbaHPcTMRohCSXzmnpElgLe =vKGiVYfqbaHPcTMRohCSXzmnpElgLx.get('vodId')
   vKGiVYfqbaHPcTMRohCSXzmnpElgLj =vKGiVYfqbaHPcTMRohCSXzmnpElgLx.get('vodType')
   vKGiVYfqbaHPcTMRohCSXzmnpElgLd=vKGiVYfqbaHPcTMRohCSXzmnpElgLx.get('thumbnail')
   vKGiVYfqbaHPcTMRohCSXzmnpElgLD =vKGiVYfqbaHPcTMRohCSXzmnpElgLx.get('vtypeId')
   vKGiVYfqbaHPcTMRohCSXzmnpElgLA =vKGiVYfqbaHPcTMRohCSXzmnpElgLx.get('duration')
   vKGiVYfqbaHPcTMRohCSXzmnpElgLU={'mediatype':'episode','duration':vKGiVYfqbaHPcTMRohCSXzmnpElgLA,'plot':'%s \n\n %s'%(vKGiVYfqbaHPcTMRohCSXzmnpElgLO,vKGiVYfqbaHPcTMRohCSXzmnpElgIO)}
   vKGiVYfqbaHPcTMRohCSXzmnpElgLQ={'mode':'GAME_VOD','saveTitle':vKGiVYfqbaHPcTMRohCSXzmnpElgIU,'saveImg':vKGiVYfqbaHPcTMRohCSXzmnpElgIr,'saveId':vKGiVYfqbaHPcTMRohCSXzmnpElgIw,'saveInfo':vKGiVYfqbaHPcTMRohCSXzmnpElgIO,'mediacode':vKGiVYfqbaHPcTMRohCSXzmnpElgLe,'mediatype':'vod','vtypeId':vKGiVYfqbaHPcTMRohCSXzmnpElgLD}
   vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.add_dir(vKGiVYfqbaHPcTMRohCSXzmnpElgLO,sublabel=vKGiVYfqbaHPcTMRohCSXzmnpElgLj,img=vKGiVYfqbaHPcTMRohCSXzmnpElgLd,infoLabels=vKGiVYfqbaHPcTMRohCSXzmnpElgLU,isFolder=vKGiVYfqbaHPcTMRohCSXzmnpElgWA,params=vKGiVYfqbaHPcTMRohCSXzmnpElgLQ)
  xbmcplugin.setContent(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ._addon_handle,cacheToDisc=vKGiVYfqbaHPcTMRohCSXzmnpElgWA)
 def login_main(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ):
  (vKGiVYfqbaHPcTMRohCSXzmnpElgIe,vKGiVYfqbaHPcTMRohCSXzmnpElgIj)=vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.get_settings_account()
  if not(vKGiVYfqbaHPcTMRohCSXzmnpElgIe and vKGiVYfqbaHPcTMRohCSXzmnpElgIj):
   vKGiVYfqbaHPcTMRohCSXzmnpElgFt=xbmcgui.Dialog()
   vKGiVYfqbaHPcTMRohCSXzmnpElgID=vKGiVYfqbaHPcTMRohCSXzmnpElgFt.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if vKGiVYfqbaHPcTMRohCSXzmnpElgID==vKGiVYfqbaHPcTMRohCSXzmnpElgQF:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.cookiefile_check():return
  if xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINWAIT')=='TRUE':
   vKGiVYfqbaHPcTMRohCSXzmnpElgIA=0
   while vKGiVYfqbaHPcTMRohCSXzmnpElgQF:
    vKGiVYfqbaHPcTMRohCSXzmnpElgIA+=1
    time.sleep(0.05)
    if vKGiVYfqbaHPcTMRohCSXzmnpElgIA>600:return
  else:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','TRUE')
  vKGiVYfqbaHPcTMRohCSXzmnpElgBF=vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.SpotvObj.GetCredential_new(vKGiVYfqbaHPcTMRohCSXzmnpElgIe,vKGiVYfqbaHPcTMRohCSXzmnpElgIj)
  if vKGiVYfqbaHPcTMRohCSXzmnpElgBF:vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.cookiefile_save()
  xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
  if vKGiVYfqbaHPcTMRohCSXzmnpElgBF==vKGiVYfqbaHPcTMRohCSXzmnpElgWA:
   vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_LiveChannel_List(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ,args):
  vKGiVYfqbaHPcTMRohCSXzmnpElgBL=vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.SpotvObj.GetLiveChannelList()
  for vKGiVYfqbaHPcTMRohCSXzmnpElgBI in vKGiVYfqbaHPcTMRohCSXzmnpElgBL:
   vKGiVYfqbaHPcTMRohCSXzmnpElgQs =vKGiVYfqbaHPcTMRohCSXzmnpElgBI.get('id')
   vKGiVYfqbaHPcTMRohCSXzmnpElgFO =vKGiVYfqbaHPcTMRohCSXzmnpElgBI.get('name')
   vKGiVYfqbaHPcTMRohCSXzmnpElgLJ =vKGiVYfqbaHPcTMRohCSXzmnpElgBI.get('programName')
   vKGiVYfqbaHPcTMRohCSXzmnpElgLd =vKGiVYfqbaHPcTMRohCSXzmnpElgBI.get('logo')
   vKGiVYfqbaHPcTMRohCSXzmnpElgBW=vKGiVYfqbaHPcTMRohCSXzmnpElgBI.get('channelepg')
   vKGiVYfqbaHPcTMRohCSXzmnpElgBQ =vKGiVYfqbaHPcTMRohCSXzmnpElgBI.get('free')
   vKGiVYfqbaHPcTMRohCSXzmnpElgLU={'plot':'%s\n\n%s'%(vKGiVYfqbaHPcTMRohCSXzmnpElgFO,vKGiVYfqbaHPcTMRohCSXzmnpElgBW),'mediatype':'episode',}
   vKGiVYfqbaHPcTMRohCSXzmnpElgLQ={'mode':'LIVE','mediacode':vKGiVYfqbaHPcTMRohCSXzmnpElgQs,'free':vKGiVYfqbaHPcTMRohCSXzmnpElgBQ,'mediatype':'live'}
   if vKGiVYfqbaHPcTMRohCSXzmnpElgBQ:vKGiVYfqbaHPcTMRohCSXzmnpElgFO+=' [free]'
   vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.add_dir(vKGiVYfqbaHPcTMRohCSXzmnpElgFO,sublabel=vKGiVYfqbaHPcTMRohCSXzmnpElgLJ,img=vKGiVYfqbaHPcTMRohCSXzmnpElgLd,infoLabels=vKGiVYfqbaHPcTMRohCSXzmnpElgLU,isFolder=vKGiVYfqbaHPcTMRohCSXzmnpElgWA,params=vKGiVYfqbaHPcTMRohCSXzmnpElgLQ)
  xbmcplugin.setContent(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ._addon_handle,'episodes')
  if vKGiVYfqbaHPcTMRohCSXzmnpElgQN(vKGiVYfqbaHPcTMRohCSXzmnpElgBL)>0:xbmcplugin.endOfDirectory(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ._addon_handle,cacheToDisc=vKGiVYfqbaHPcTMRohCSXzmnpElgWA)
 def dp_EventLiveChannel_List(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ,args):
  vKGiVYfqbaHPcTMRohCSXzmnpElgBL,vKGiVYfqbaHPcTMRohCSXzmnpElgBN=vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.SpotvObj.GetEventLiveList()
  if vKGiVYfqbaHPcTMRohCSXzmnpElgBN!=401 and vKGiVYfqbaHPcTMRohCSXzmnpElgQN(vKGiVYfqbaHPcTMRohCSXzmnpElgBL)==0:
   vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.addon_noti(__language__(30907).encode('utf8'))
  for vKGiVYfqbaHPcTMRohCSXzmnpElgBI in vKGiVYfqbaHPcTMRohCSXzmnpElgBL:
   vKGiVYfqbaHPcTMRohCSXzmnpElgFO =vKGiVYfqbaHPcTMRohCSXzmnpElgBI.get('title')
   vKGiVYfqbaHPcTMRohCSXzmnpElgLJ =vKGiVYfqbaHPcTMRohCSXzmnpElgBI.get('startTime')
   vKGiVYfqbaHPcTMRohCSXzmnpElgLd =vKGiVYfqbaHPcTMRohCSXzmnpElgBI.get('logo')
   vKGiVYfqbaHPcTMRohCSXzmnpElgBQ =vKGiVYfqbaHPcTMRohCSXzmnpElgBI.get('free')
   vKGiVYfqbaHPcTMRohCSXzmnpElgLU={'mediatype':'episode','plot':'%s\n\n%s'%(vKGiVYfqbaHPcTMRohCSXzmnpElgFO,vKGiVYfqbaHPcTMRohCSXzmnpElgLJ)}
   vKGiVYfqbaHPcTMRohCSXzmnpElgLQ={'mode':'ELIVE','mediacode':vKGiVYfqbaHPcTMRohCSXzmnpElgBI.get('liveId'),'free':vKGiVYfqbaHPcTMRohCSXzmnpElgBQ,'mediatype':'live'}
   if vKGiVYfqbaHPcTMRohCSXzmnpElgBQ:vKGiVYfqbaHPcTMRohCSXzmnpElgFO+=' [free]'
   vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.add_dir(vKGiVYfqbaHPcTMRohCSXzmnpElgFO,sublabel=vKGiVYfqbaHPcTMRohCSXzmnpElgLJ,img=vKGiVYfqbaHPcTMRohCSXzmnpElgLd,infoLabels=vKGiVYfqbaHPcTMRohCSXzmnpElgLU,isFolder=vKGiVYfqbaHPcTMRohCSXzmnpElgWA,params=vKGiVYfqbaHPcTMRohCSXzmnpElgLQ)
  xbmcplugin.setContent(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ._addon_handle,'episodes')
  if vKGiVYfqbaHPcTMRohCSXzmnpElgQN(vKGiVYfqbaHPcTMRohCSXzmnpElgBL)>0:xbmcplugin.endOfDirectory(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ._addon_handle,cacheToDisc=vKGiVYfqbaHPcTMRohCSXzmnpElgWA)
  return vKGiVYfqbaHPcTMRohCSXzmnpElgBN
 def play_VIDEO(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ,args):
  vKGiVYfqbaHPcTMRohCSXzmnpElgBu =args.get('mode')
  vKGiVYfqbaHPcTMRohCSXzmnpElgBs =args.get('mediacode')
  vKGiVYfqbaHPcTMRohCSXzmnpElgBJ =args.get('mediatype')
  vKGiVYfqbaHPcTMRohCSXzmnpElgLD =args.get('vtypeId')
  vKGiVYfqbaHPcTMRohCSXzmnpElgBt =args.get('hlsUrl')
  if vKGiVYfqbaHPcTMRohCSXzmnpElgBu=='LIVE':
   if args.get('free')=='False':
    if vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.SpotvObj.CheckSubEnd()==vKGiVYfqbaHPcTMRohCSXzmnpElgWA:
     vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.addon_noti(__language__(30908).encode('utf8'))
     return
  elif vKGiVYfqbaHPcTMRohCSXzmnpElgBu=='ELIVE':
   if args.get('free')=='False':
    if vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.SpotvObj.CheckSubEnd()==vKGiVYfqbaHPcTMRohCSXzmnpElgWA:
     vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.addon_noti(__language__(30908).encode('utf8'))
     return
  if vKGiVYfqbaHPcTMRohCSXzmnpElgBs=='' or vKGiVYfqbaHPcTMRohCSXzmnpElgBs==vKGiVYfqbaHPcTMRohCSXzmnpElgWD:
   vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.addon_noti(__language__(30907).encode('utf8'))
   return
  if vKGiVYfqbaHPcTMRohCSXzmnpElgBu=='LIVE':
   vKGiVYfqbaHPcTMRohCSXzmnpElgBx=vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.SpotvObj.GetHlsUrl(vKGiVYfqbaHPcTMRohCSXzmnpElgBs)
  else:
   vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.addon_log('mediacode : '+vKGiVYfqbaHPcTMRohCSXzmnpElgBs)
   vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.addon_log('mediatype : '+vKGiVYfqbaHPcTMRohCSXzmnpElgBJ)
   vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.addon_log('vtypeId   : '+vKGiVYfqbaHPcTMRohCSXzmnpElgQu(vKGiVYfqbaHPcTMRohCSXzmnpElgLD))
   vKGiVYfqbaHPcTMRohCSXzmnpElgBx=vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.SpotvObj.GetBroadURL(vKGiVYfqbaHPcTMRohCSXzmnpElgBs,vKGiVYfqbaHPcTMRohCSXzmnpElgBJ,vKGiVYfqbaHPcTMRohCSXzmnpElgLD)
  if vKGiVYfqbaHPcTMRohCSXzmnpElgBx=='':
   vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.addon_noti(__language__(30908).encode('utf8'))
   return
  vKGiVYfqbaHPcTMRohCSXzmnpElgBd=vKGiVYfqbaHPcTMRohCSXzmnpElgBx
  try:
   vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.addon_log('mainMode  = '+vKGiVYfqbaHPcTMRohCSXzmnpElgBu)
  except:
   vKGiVYfqbaHPcTMRohCSXzmnpElgWD
  vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.addon_log(vKGiVYfqbaHPcTMRohCSXzmnpElgBd)
  vKGiVYfqbaHPcTMRohCSXzmnpElgBk=xbmcgui.ListItem(path=vKGiVYfqbaHPcTMRohCSXzmnpElgBd)
  xbmcplugin.setResolvedUrl(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ._addon_handle,vKGiVYfqbaHPcTMRohCSXzmnpElgQF,vKGiVYfqbaHPcTMRohCSXzmnpElgBk)
  try:
   if vKGiVYfqbaHPcTMRohCSXzmnpElgBJ=='vod' and vKGiVYfqbaHPcTMRohCSXzmnpElgBu not in['POP_VOD','NOW_VOD']:
    vKGiVYfqbaHPcTMRohCSXzmnpElgLQ={'code':args.get('saveId'),'img':args.get('saveImg'),'title':args.get('saveTitle'),'info':args.get('saveInfo')}
    vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.Save_Watched_List(vKGiVYfqbaHPcTMRohCSXzmnpElgBJ,vKGiVYfqbaHPcTMRohCSXzmnpElgLQ)
  except:
   vKGiVYfqbaHPcTMRohCSXzmnpElgWD
 def logout(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ):
  vKGiVYfqbaHPcTMRohCSXzmnpElgFt=xbmcgui.Dialog()
  vKGiVYfqbaHPcTMRohCSXzmnpElgID=vKGiVYfqbaHPcTMRohCSXzmnpElgFt.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if vKGiVYfqbaHPcTMRohCSXzmnpElgID==vKGiVYfqbaHPcTMRohCSXzmnpElgWA:sys.exit()
  vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.SpotvObj.Init_ST_Total()
  if os.path.isfile(vKGiVYfqbaHPcTMRohCSXzmnpElgFW):os.remove(vKGiVYfqbaHPcTMRohCSXzmnpElgFW)
  vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ):
  vKGiVYfqbaHPcTMRohCSXzmnpElgBy =vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.SpotvObj.Get_Now_Datetime()
  vKGiVYfqbaHPcTMRohCSXzmnpElgBU=vKGiVYfqbaHPcTMRohCSXzmnpElgBy+datetime.timedelta(days=0)
  (vKGiVYfqbaHPcTMRohCSXzmnpElgIe,vKGiVYfqbaHPcTMRohCSXzmnpElgIj)=vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.get_settings_account()
  vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.SpotvObj.Save_session_acount(vKGiVYfqbaHPcTMRohCSXzmnpElgIe,vKGiVYfqbaHPcTMRohCSXzmnpElgIj)
  vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.SpotvObj.ST['account']['token_limit']=vKGiVYfqbaHPcTMRohCSXzmnpElgBU.strftime('%Y%m%d')
  vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.SpotvObj.JsonFile_Save(vKGiVYfqbaHPcTMRohCSXzmnpElgFW,vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.SpotvObj.ST)
 def cookiefile_check(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ):
  vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.SpotvObj.ST=vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.SpotvObj.JsonFile_Load(vKGiVYfqbaHPcTMRohCSXzmnpElgFW)
  if 'account' not in vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.SpotvObj.ST:
   vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.SpotvObj.Init_ST_Total()
   return vKGiVYfqbaHPcTMRohCSXzmnpElgWA
  (vKGiVYfqbaHPcTMRohCSXzmnpElgBw,vKGiVYfqbaHPcTMRohCSXzmnpElgBr)=vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.get_settings_account()
  (vKGiVYfqbaHPcTMRohCSXzmnpElgBO,vKGiVYfqbaHPcTMRohCSXzmnpElgBe)=vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.SpotvObj.Load_session_acount()
  if vKGiVYfqbaHPcTMRohCSXzmnpElgBw!=vKGiVYfqbaHPcTMRohCSXzmnpElgBO or vKGiVYfqbaHPcTMRohCSXzmnpElgBr!=vKGiVYfqbaHPcTMRohCSXzmnpElgBe:
   vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.SpotvObj.Init_ST_Total()
   return vKGiVYfqbaHPcTMRohCSXzmnpElgWA
  if vKGiVYfqbaHPcTMRohCSXzmnpElgQB(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))>vKGiVYfqbaHPcTMRohCSXzmnpElgQB(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.SpotvObj.ST['account']['token_limit']):
   vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.SpotvObj.Init_ST_Total()
   return vKGiVYfqbaHPcTMRohCSXzmnpElgWA
  return vKGiVYfqbaHPcTMRohCSXzmnpElgQF
 def dp_History_Remove(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ,args):
  vKGiVYfqbaHPcTMRohCSXzmnpElgBj=args.get('delType')
  vKGiVYfqbaHPcTMRohCSXzmnpElgBD =args.get('sKey')
  vKGiVYfqbaHPcTMRohCSXzmnpElgBA =args.get('vType')
  vKGiVYfqbaHPcTMRohCSXzmnpElgFt=xbmcgui.Dialog()
  if vKGiVYfqbaHPcTMRohCSXzmnpElgBj=='WATCH_ALL':
   vKGiVYfqbaHPcTMRohCSXzmnpElgID=vKGiVYfqbaHPcTMRohCSXzmnpElgFt.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif vKGiVYfqbaHPcTMRohCSXzmnpElgBj=='WATCH_ONE':
   vKGiVYfqbaHPcTMRohCSXzmnpElgID=vKGiVYfqbaHPcTMRohCSXzmnpElgFt.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  if vKGiVYfqbaHPcTMRohCSXzmnpElgID==vKGiVYfqbaHPcTMRohCSXzmnpElgWA:sys.exit()
  if vKGiVYfqbaHPcTMRohCSXzmnpElgBj=='WATCH_ALL':
   vKGiVYfqbaHPcTMRohCSXzmnpElgWF=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%vKGiVYfqbaHPcTMRohCSXzmnpElgBA))
   if os.path.isfile(vKGiVYfqbaHPcTMRohCSXzmnpElgWF):os.remove(vKGiVYfqbaHPcTMRohCSXzmnpElgWF)
  elif vKGiVYfqbaHPcTMRohCSXzmnpElgBj=='WATCH_ONE':
   vKGiVYfqbaHPcTMRohCSXzmnpElgWF=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%vKGiVYfqbaHPcTMRohCSXzmnpElgBA))
   try:
    vKGiVYfqbaHPcTMRohCSXzmnpElgWL=vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.Load_List_File(vKGiVYfqbaHPcTMRohCSXzmnpElgBA) 
    fp=vKGiVYfqbaHPcTMRohCSXzmnpElgQJ(vKGiVYfqbaHPcTMRohCSXzmnpElgWF,'w',-1,'utf-8')
    for vKGiVYfqbaHPcTMRohCSXzmnpElgWI in vKGiVYfqbaHPcTMRohCSXzmnpElgWL:
     vKGiVYfqbaHPcTMRohCSXzmnpElgWB=vKGiVYfqbaHPcTMRohCSXzmnpElgQt(urllib.parse.parse_qsl(vKGiVYfqbaHPcTMRohCSXzmnpElgWI))
     vKGiVYfqbaHPcTMRohCSXzmnpElgWQ=vKGiVYfqbaHPcTMRohCSXzmnpElgWB.get('code').strip()
     if vKGiVYfqbaHPcTMRohCSXzmnpElgBD!=vKGiVYfqbaHPcTMRohCSXzmnpElgWQ:
      fp.write(vKGiVYfqbaHPcTMRohCSXzmnpElgWI)
    fp.close()
   except:
    vKGiVYfqbaHPcTMRohCSXzmnpElgWD
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ,vKGiVYfqbaHPcTMRohCSXzmnpElgBJ):
  try:
   vKGiVYfqbaHPcTMRohCSXzmnpElgWN=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%vKGiVYfqbaHPcTMRohCSXzmnpElgBJ))
   fp=vKGiVYfqbaHPcTMRohCSXzmnpElgQJ(vKGiVYfqbaHPcTMRohCSXzmnpElgWN,'r',-1,'utf-8')
   vKGiVYfqbaHPcTMRohCSXzmnpElgWu=fp.readlines()
   fp.close()
  except:
   vKGiVYfqbaHPcTMRohCSXzmnpElgWu=[]
  return vKGiVYfqbaHPcTMRohCSXzmnpElgWu
 def Save_Watched_List(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ,stype,vKGiVYfqbaHPcTMRohCSXzmnpElgFs):
  try:
   vKGiVYfqbaHPcTMRohCSXzmnpElgWN=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   vKGiVYfqbaHPcTMRohCSXzmnpElgWL=vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.Load_List_File(stype) 
   fp=vKGiVYfqbaHPcTMRohCSXzmnpElgQJ(vKGiVYfqbaHPcTMRohCSXzmnpElgWN,'w',-1,'utf-8')
   vKGiVYfqbaHPcTMRohCSXzmnpElgWs=urllib.parse.urlencode(vKGiVYfqbaHPcTMRohCSXzmnpElgFs)
   vKGiVYfqbaHPcTMRohCSXzmnpElgWs=vKGiVYfqbaHPcTMRohCSXzmnpElgWs+'\n'
   fp.write(vKGiVYfqbaHPcTMRohCSXzmnpElgWs)
   vKGiVYfqbaHPcTMRohCSXzmnpElgWJ=0
   for vKGiVYfqbaHPcTMRohCSXzmnpElgWI in vKGiVYfqbaHPcTMRohCSXzmnpElgWL:
    vKGiVYfqbaHPcTMRohCSXzmnpElgWB=vKGiVYfqbaHPcTMRohCSXzmnpElgQt(urllib.parse.parse_qsl(vKGiVYfqbaHPcTMRohCSXzmnpElgWI))
    vKGiVYfqbaHPcTMRohCSXzmnpElgWt=vKGiVYfqbaHPcTMRohCSXzmnpElgFs.get('code')
    vKGiVYfqbaHPcTMRohCSXzmnpElgWx=vKGiVYfqbaHPcTMRohCSXzmnpElgWB.get('code')
    if vKGiVYfqbaHPcTMRohCSXzmnpElgWt!=vKGiVYfqbaHPcTMRohCSXzmnpElgWx:
     fp.write(vKGiVYfqbaHPcTMRohCSXzmnpElgWI)
     vKGiVYfqbaHPcTMRohCSXzmnpElgWJ+=1
     if vKGiVYfqbaHPcTMRohCSXzmnpElgWJ>=50:break
   fp.close()
  except:
   vKGiVYfqbaHPcTMRohCSXzmnpElgWD
 def dp_Watch_List(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ,args):
  vKGiVYfqbaHPcTMRohCSXzmnpElgBJ ='vod'
  if vKGiVYfqbaHPcTMRohCSXzmnpElgBJ=='vod':
   vKGiVYfqbaHPcTMRohCSXzmnpElgWd=vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.Load_List_File(vKGiVYfqbaHPcTMRohCSXzmnpElgBJ)
   for vKGiVYfqbaHPcTMRohCSXzmnpElgWk in vKGiVYfqbaHPcTMRohCSXzmnpElgWd:
    vKGiVYfqbaHPcTMRohCSXzmnpElgWy=vKGiVYfqbaHPcTMRohCSXzmnpElgQt(urllib.parse.parse_qsl(vKGiVYfqbaHPcTMRohCSXzmnpElgWk))
    vKGiVYfqbaHPcTMRohCSXzmnpElgFO =vKGiVYfqbaHPcTMRohCSXzmnpElgWy.get('title')
    vKGiVYfqbaHPcTMRohCSXzmnpElgLd=vKGiVYfqbaHPcTMRohCSXzmnpElgWy.get('img')
    vKGiVYfqbaHPcTMRohCSXzmnpElgBs=vKGiVYfqbaHPcTMRohCSXzmnpElgWy.get('code')
    vKGiVYfqbaHPcTMRohCSXzmnpElgWU =vKGiVYfqbaHPcTMRohCSXzmnpElgWy.get('info')
    vKGiVYfqbaHPcTMRohCSXzmnpElgLU={}
    vKGiVYfqbaHPcTMRohCSXzmnpElgLU['plot'] =vKGiVYfqbaHPcTMRohCSXzmnpElgWU
    vKGiVYfqbaHPcTMRohCSXzmnpElgLU['mediatype']='tvshow'
    vKGiVYfqbaHPcTMRohCSXzmnpElgLQ={'mode':'GAME_VOD_GROUP','gameid':vKGiVYfqbaHPcTMRohCSXzmnpElgBs,'saveTitle':vKGiVYfqbaHPcTMRohCSXzmnpElgFO,'saveImg':vKGiVYfqbaHPcTMRohCSXzmnpElgLd,'saveInfo':vKGiVYfqbaHPcTMRohCSXzmnpElgWU,'mediatype':vKGiVYfqbaHPcTMRohCSXzmnpElgBJ}
    vKGiVYfqbaHPcTMRohCSXzmnpElgWw={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':vKGiVYfqbaHPcTMRohCSXzmnpElgBs,'vType':vKGiVYfqbaHPcTMRohCSXzmnpElgBJ,}
    vKGiVYfqbaHPcTMRohCSXzmnpElgWr=urllib.parse.urlencode(vKGiVYfqbaHPcTMRohCSXzmnpElgWw)
    vKGiVYfqbaHPcTMRohCSXzmnpElgWO=[('선택된 시청이력 ( %s ) 삭제'%(vKGiVYfqbaHPcTMRohCSXzmnpElgFO),'RunPlugin(plugin://plugin.video.spotvm/?%s)'%(vKGiVYfqbaHPcTMRohCSXzmnpElgWr))]
    vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.add_dir(vKGiVYfqbaHPcTMRohCSXzmnpElgFO,sublabel='',img=vKGiVYfqbaHPcTMRohCSXzmnpElgLd,infoLabels=vKGiVYfqbaHPcTMRohCSXzmnpElgLU,isFolder=vKGiVYfqbaHPcTMRohCSXzmnpElgQF,params=vKGiVYfqbaHPcTMRohCSXzmnpElgLQ,ContextMenu=vKGiVYfqbaHPcTMRohCSXzmnpElgWO)
   vKGiVYfqbaHPcTMRohCSXzmnpElgLU={'plot':'시청목록을 삭제합니다.'}
   vKGiVYfqbaHPcTMRohCSXzmnpElgFO='*** 시청목록 삭제 ***'
   vKGiVYfqbaHPcTMRohCSXzmnpElgLQ={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':vKGiVYfqbaHPcTMRohCSXzmnpElgBJ,}
   vKGiVYfqbaHPcTMRohCSXzmnpElgLW=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.add_dir(vKGiVYfqbaHPcTMRohCSXzmnpElgFO,sublabel='',img=vKGiVYfqbaHPcTMRohCSXzmnpElgLW,infoLabels=vKGiVYfqbaHPcTMRohCSXzmnpElgLU,isFolder=vKGiVYfqbaHPcTMRohCSXzmnpElgWA,params=vKGiVYfqbaHPcTMRohCSXzmnpElgLQ,isLink=vKGiVYfqbaHPcTMRohCSXzmnpElgQF)
   xbmcplugin.endOfDirectory(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ._addon_handle,cacheToDisc=vKGiVYfqbaHPcTMRohCSXzmnpElgWA)
 def spotv_main(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ):
  vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.SpotvObj.KodiVersion=vKGiVYfqbaHPcTMRohCSXzmnpElgQB(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  vKGiVYfqbaHPcTMRohCSXzmnpElgWe=vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.main_params.get('mode',vKGiVYfqbaHPcTMRohCSXzmnpElgWD)
  if vKGiVYfqbaHPcTMRohCSXzmnpElgWe=='LOGOUT':
   vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.logout()
   return
  vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.login_main()
  if vKGiVYfqbaHPcTMRohCSXzmnpElgWe is vKGiVYfqbaHPcTMRohCSXzmnpElgWD:
   vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.dp_Main_List()
  elif vKGiVYfqbaHPcTMRohCSXzmnpElgWe=='LIVE_GROUP':
   vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.dp_LiveChannel_List(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.main_params)
  elif vKGiVYfqbaHPcTMRohCSXzmnpElgWe=='ELIVE_GROUP':
   vKGiVYfqbaHPcTMRohCSXzmnpElgBN=vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.dp_EventLiveChannel_List(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.main_params)
   if vKGiVYfqbaHPcTMRohCSXzmnpElgBN==401:
    if os.path.isfile(vKGiVYfqbaHPcTMRohCSXzmnpElgFW):os.remove(vKGiVYfqbaHPcTMRohCSXzmnpElgFW)
    vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.login_main()
    vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.dp_EventLiveChannel_List(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.main_params)
  elif vKGiVYfqbaHPcTMRohCSXzmnpElgWe in['LIVE','GAME_VOD','POP_VOD','NOW_VOD','ELIVE']:
   vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.play_VIDEO(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.main_params)
  elif vKGiVYfqbaHPcTMRohCSXzmnpElgWe=='VOD_GROUP':
   vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.dp_MainLeague_List(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.main_params)
  elif vKGiVYfqbaHPcTMRohCSXzmnpElgWe=='NOW_GROUP':
   vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.dp_NowVod_GroupList(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.main_params)
  elif vKGiVYfqbaHPcTMRohCSXzmnpElgWe=='POP_GROUP':
   vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.dp_PopVod_GroupList(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.main_params)
  elif vKGiVYfqbaHPcTMRohCSXzmnpElgWe=='LEAGUE_GROUP':
   vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.dp_Season_List(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.main_params)
  elif vKGiVYfqbaHPcTMRohCSXzmnpElgWe=='SEASON_GROUP':
   vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.dp_Game_List(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.main_params)
  elif vKGiVYfqbaHPcTMRohCSXzmnpElgWe=='GAME_VOD_GROUP':
   vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.dp_GameVod_List(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.main_params)
  elif vKGiVYfqbaHPcTMRohCSXzmnpElgWe=='WATCH':
   vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.dp_Watch_List(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.main_params)
  elif vKGiVYfqbaHPcTMRohCSXzmnpElgWe=='MYVIEW_REMOVE':
   vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.dp_History_Remove(vKGiVYfqbaHPcTMRohCSXzmnpElgFQ.main_params)
  else:
   vKGiVYfqbaHPcTMRohCSXzmnpElgWD
# Created by pyminifier (https://github.com/liftoff/pyminifier)
