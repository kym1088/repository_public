__author__="NightRain"
dIgPAXqneCWjrycuLJpvFwxEDQzYKU=object
dIgPAXqneCWjrycuLJpvFwxEDQzYKk=None
dIgPAXqneCWjrycuLJpvFwxEDQzYKH=False
dIgPAXqneCWjrycuLJpvFwxEDQzYKT=str
dIgPAXqneCWjrycuLJpvFwxEDQzYKN=open
dIgPAXqneCWjrycuLJpvFwxEDQzYKV=True
dIgPAXqneCWjrycuLJpvFwxEDQzYKl=int
dIgPAXqneCWjrycuLJpvFwxEDQzYKs=Exception
dIgPAXqneCWjrycuLJpvFwxEDQzYbi=print
dIgPAXqneCWjrycuLJpvFwxEDQzYbm=len
dIgPAXqneCWjrycuLJpvFwxEDQzYbS=range
import urllib
import re
import json
import sys
import time
import requests
import datetime
import base64
import random
dIgPAXqneCWjrycuLJpvFwxEDQzYiS={'stream50':1080,'stream40':720,'stream30':540}
class dIgPAXqneCWjrycuLJpvFwxEDQzYim(dIgPAXqneCWjrycuLJpvFwxEDQzYKU):
 def __init__(dIgPAXqneCWjrycuLJpvFwxEDQzYia):
  dIgPAXqneCWjrycuLJpvFwxEDQzYia.SPOTV_PMCODE ='987'
  dIgPAXqneCWjrycuLJpvFwxEDQzYia.SPOTV_PMSIZE =3
  dIgPAXqneCWjrycuLJpvFwxEDQzYia.GAMELIST_LIMIT =10
  dIgPAXqneCWjrycuLJpvFwxEDQzYia.API_DOMAIN ='https://www.spotvnow.co.kr'
  dIgPAXqneCWjrycuLJpvFwxEDQzYia.BC_DOMAIN ='https://players.brightcove.net'
  dIgPAXqneCWjrycuLJpvFwxEDQzYia.PLAYER_DOMAIN ='https://edge.api.brightcove.com'
  dIgPAXqneCWjrycuLJpvFwxEDQzYia.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36'
  dIgPAXqneCWjrycuLJpvFwxEDQzYia.DEFAULT_HEADER ={'user-agent':dIgPAXqneCWjrycuLJpvFwxEDQzYia.USER_AGENT}
  dIgPAXqneCWjrycuLJpvFwxEDQzYia.COOKIE_FILE_NAME=''
  dIgPAXqneCWjrycuLJpvFwxEDQzYia.KodiVersion =20
  dIgPAXqneCWjrycuLJpvFwxEDQzYia.ST ={}
  dIgPAXqneCWjrycuLJpvFwxEDQzYia.Init_ST_Total()
 def Init_ST_Total(dIgPAXqneCWjrycuLJpvFwxEDQzYia):
  dIgPAXqneCWjrycuLJpvFwxEDQzYia.ST={'account':{},'cookies':{},}
 def addon_log(dIgPAXqneCWjrycuLJpvFwxEDQzYia,string):
  import xbmcaddon,xbmc
  __version__=xbmcaddon.Addon().getAddonInfo('version')
  __addonid__=xbmcaddon.Addon().getAddonInfo('id')
  try:
   dIgPAXqneCWjrycuLJpvFwxEDQzYiK=string.encode('utf-8','ignore')
  except:
   dIgPAXqneCWjrycuLJpvFwxEDQzYiK='addonException: addon_log'
  dIgPAXqneCWjrycuLJpvFwxEDQzYib=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,dIgPAXqneCWjrycuLJpvFwxEDQzYiK),level=dIgPAXqneCWjrycuLJpvFwxEDQzYib)
 def callRequestCookies(dIgPAXqneCWjrycuLJpvFwxEDQzYia,jobtype,dIgPAXqneCWjrycuLJpvFwxEDQzYiH,payload=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,json=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,params=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,headers=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,cookies=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,redirects=dIgPAXqneCWjrycuLJpvFwxEDQzYKH):
  dIgPAXqneCWjrycuLJpvFwxEDQzYiM=dIgPAXqneCWjrycuLJpvFwxEDQzYia.DEFAULT_HEADER
  if headers:dIgPAXqneCWjrycuLJpvFwxEDQzYiM.update(headers)
  if jobtype=='Get':
   dIgPAXqneCWjrycuLJpvFwxEDQzYiO=requests.get(dIgPAXqneCWjrycuLJpvFwxEDQzYiH,params=params,headers=dIgPAXqneCWjrycuLJpvFwxEDQzYiM,cookies=cookies,allow_redirects=redirects)
  else:
   dIgPAXqneCWjrycuLJpvFwxEDQzYiO=requests.post(dIgPAXqneCWjrycuLJpvFwxEDQzYiH,data=payload,json=json,params=params,headers=dIgPAXqneCWjrycuLJpvFwxEDQzYiM,cookies=cookies,allow_redirects=redirects)
  try:
   dIgPAXqneCWjrycuLJpvFwxEDQzYia.addon_log(dIgPAXqneCWjrycuLJpvFwxEDQzYKT(dIgPAXqneCWjrycuLJpvFwxEDQzYiO.status_code)+' : '+dIgPAXqneCWjrycuLJpvFwxEDQzYiO.url)
  except:
   dIgPAXqneCWjrycuLJpvFwxEDQzYKk
  return dIgPAXqneCWjrycuLJpvFwxEDQzYiO
 def JsonFile_Save(dIgPAXqneCWjrycuLJpvFwxEDQzYia,filename,dIgPAXqneCWjrycuLJpvFwxEDQzYif):
  if filename=='':return dIgPAXqneCWjrycuLJpvFwxEDQzYKH
  try:
   fp=dIgPAXqneCWjrycuLJpvFwxEDQzYKN(filename,'w',-1,'utf-8')
   json.dump(dIgPAXqneCWjrycuLJpvFwxEDQzYif,fp,indent=4,ensure_ascii=dIgPAXqneCWjrycuLJpvFwxEDQzYKH)
   fp.close()
  except:
   return dIgPAXqneCWjrycuLJpvFwxEDQzYKH
  return dIgPAXqneCWjrycuLJpvFwxEDQzYKV
 def JsonFile_Load(dIgPAXqneCWjrycuLJpvFwxEDQzYia,filename):
  if filename=='':return{}
  try:
   fp=dIgPAXqneCWjrycuLJpvFwxEDQzYKN(filename,'r',-1,'utf-8')
   dIgPAXqneCWjrycuLJpvFwxEDQzYiR=json.load(fp)
   fp.close()
  except:
   return{}
  return dIgPAXqneCWjrycuLJpvFwxEDQzYiR
 def Save_session_acount(dIgPAXqneCWjrycuLJpvFwxEDQzYia,dIgPAXqneCWjrycuLJpvFwxEDQzYio,dIgPAXqneCWjrycuLJpvFwxEDQzYih):
  dIgPAXqneCWjrycuLJpvFwxEDQzYia.ST['account']['stid'] =base64.standard_b64encode(dIgPAXqneCWjrycuLJpvFwxEDQzYio.encode()).decode('utf-8')
  dIgPAXqneCWjrycuLJpvFwxEDQzYia.ST['account']['stpw'] =base64.standard_b64encode(dIgPAXqneCWjrycuLJpvFwxEDQzYih.encode()).decode('utf-8')
 def Load_session_acount(dIgPAXqneCWjrycuLJpvFwxEDQzYia):
  try:
   dIgPAXqneCWjrycuLJpvFwxEDQzYio =base64.standard_b64decode(dIgPAXqneCWjrycuLJpvFwxEDQzYia.ST['account']['stid']).decode('utf-8')
   dIgPAXqneCWjrycuLJpvFwxEDQzYih =base64.standard_b64decode(dIgPAXqneCWjrycuLJpvFwxEDQzYia.ST['account']['stpw']).decode('utf-8')
  except:
   return '',''
  return dIgPAXqneCWjrycuLJpvFwxEDQzYio,dIgPAXqneCWjrycuLJpvFwxEDQzYih
 def makeDefaultCookies(dIgPAXqneCWjrycuLJpvFwxEDQzYia):
  dIgPAXqneCWjrycuLJpvFwxEDQzYiB={'id_token':dIgPAXqneCWjrycuLJpvFwxEDQzYia.ST['cookies']['id_token']}
  return dIgPAXqneCWjrycuLJpvFwxEDQzYiB
 def makeDefaultHeaders(dIgPAXqneCWjrycuLJpvFwxEDQzYia):
  dIgPAXqneCWjrycuLJpvFwxEDQzYit={'accept':'application/json;pk={}'.format(dIgPAXqneCWjrycuLJpvFwxEDQzYia.ST['cookies']['spotv_policyKey'])}
  return dIgPAXqneCWjrycuLJpvFwxEDQzYit
 def xmlText(dIgPAXqneCWjrycuLJpvFwxEDQzYia,in_text):
  dIgPAXqneCWjrycuLJpvFwxEDQzYiU=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;')
  return dIgPAXqneCWjrycuLJpvFwxEDQzYiU
 def GetNoCache(dIgPAXqneCWjrycuLJpvFwxEDQzYia,timetype=1):
  if timetype==1:
   return dIgPAXqneCWjrycuLJpvFwxEDQzYKl(time.time())
  else:
   return dIgPAXqneCWjrycuLJpvFwxEDQzYKl(time.time()*1000)
 def GetCredential_new(dIgPAXqneCWjrycuLJpvFwxEDQzYia,user_id,user_pw):
  dIgPAXqneCWjrycuLJpvFwxEDQzYik=requests.session()
  try:
   dIgPAXqneCWjrycuLJpvFwxEDQzYiH='https://nid.spotvnow.co.kr/api/v3/oauth2/authorize/spotvnow?return_url=https%3A%2F%2Fwww.spotvnow.co.kr%2Fcheck&err_return_url=https%3A%2F%2Fwww.spotvnow.co.kr%2Fabout&logout_url=https%3A%2F%2Fwww.spotvnow.co.kr%2Fintro'
   dIgPAXqneCWjrycuLJpvFwxEDQzYit={'User-Agent':dIgPAXqneCWjrycuLJpvFwxEDQzYia.USER_AGENT,}
   while(dIgPAXqneCWjrycuLJpvFwxEDQzYiH not in['',dIgPAXqneCWjrycuLJpvFwxEDQzYKk]):
    dIgPAXqneCWjrycuLJpvFwxEDQzYiT=dIgPAXqneCWjrycuLJpvFwxEDQzYik.get(dIgPAXqneCWjrycuLJpvFwxEDQzYiH,params=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,headers=dIgPAXqneCWjrycuLJpvFwxEDQzYit,cookies=dIgPAXqneCWjrycuLJpvFwxEDQzYia.ST['cookies'],allow_redirects=dIgPAXqneCWjrycuLJpvFwxEDQzYKH)
    dIgPAXqneCWjrycuLJpvFwxEDQzYiH =dIgPAXqneCWjrycuLJpvFwxEDQzYiT.headers.get('location')
    for dIgPAXqneCWjrycuLJpvFwxEDQzYiN in dIgPAXqneCWjrycuLJpvFwxEDQzYiT.cookies:
     if dIgPAXqneCWjrycuLJpvFwxEDQzYiN.value not in['',dIgPAXqneCWjrycuLJpvFwxEDQzYKk]:
      dIgPAXqneCWjrycuLJpvFwxEDQzYia.ST['cookies'][dIgPAXqneCWjrycuLJpvFwxEDQzYiN.name]=dIgPAXqneCWjrycuLJpvFwxEDQzYiN.value
    if dIgPAXqneCWjrycuLJpvFwxEDQzYiT.status_code==200:break
   if dIgPAXqneCWjrycuLJpvFwxEDQzYia.ST['cookies']['login_challenge']=='':
    dIgPAXqneCWjrycuLJpvFwxEDQzYia.Init_ST_Total()
    return dIgPAXqneCWjrycuLJpvFwxEDQzYKH
  except dIgPAXqneCWjrycuLJpvFwxEDQzYKs as exception:
   dIgPAXqneCWjrycuLJpvFwxEDQzYbi(exception)
   dIgPAXqneCWjrycuLJpvFwxEDQzYia.Init_ST_Total()
   return dIgPAXqneCWjrycuLJpvFwxEDQzYKH
  try:
   dIgPAXqneCWjrycuLJpvFwxEDQzYiV=base64.standard_b64encode(user_id.encode('UTF-8')).decode('utf-8')
   dIgPAXqneCWjrycuLJpvFwxEDQzYil=base64.standard_b64encode(user_pw.encode('UTF-8')).decode('utf-8')
   dIgPAXqneCWjrycuLJpvFwxEDQzYiH='https://nid.spotvnow.co.kr/api/v3/user-auth/login'
   dIgPAXqneCWjrycuLJpvFwxEDQzYit={'User-Agent':dIgPAXqneCWjrycuLJpvFwxEDQzYia.USER_AGENT,}
   dIgPAXqneCWjrycuLJpvFwxEDQzYis={'username':dIgPAXqneCWjrycuLJpvFwxEDQzYiV,'password':dIgPAXqneCWjrycuLJpvFwxEDQzYil,'remember':dIgPAXqneCWjrycuLJpvFwxEDQzYKV,'err_return_url':'https://www.spotvnow.co.kr/intro',}
   dIgPAXqneCWjrycuLJpvFwxEDQzYiT=dIgPAXqneCWjrycuLJpvFwxEDQzYik.post(dIgPAXqneCWjrycuLJpvFwxEDQzYiH,data=dIgPAXqneCWjrycuLJpvFwxEDQzYis,params=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,headers=dIgPAXqneCWjrycuLJpvFwxEDQzYit,cookies=dIgPAXqneCWjrycuLJpvFwxEDQzYia.ST['cookies'],allow_redirects=dIgPAXqneCWjrycuLJpvFwxEDQzYKH)
   for dIgPAXqneCWjrycuLJpvFwxEDQzYiN in dIgPAXqneCWjrycuLJpvFwxEDQzYiT.cookies:
    if dIgPAXqneCWjrycuLJpvFwxEDQzYiN.value not in['',dIgPAXqneCWjrycuLJpvFwxEDQzYKk]:
     dIgPAXqneCWjrycuLJpvFwxEDQzYia.ST['cookies'][dIgPAXqneCWjrycuLJpvFwxEDQzYiN.name]=dIgPAXqneCWjrycuLJpvFwxEDQzYiN.value
   dIgPAXqneCWjrycuLJpvFwxEDQzYiH=dIgPAXqneCWjrycuLJpvFwxEDQzYiT.headers.get('location')
   while(dIgPAXqneCWjrycuLJpvFwxEDQzYiH not in['',dIgPAXqneCWjrycuLJpvFwxEDQzYKk]):
    dIgPAXqneCWjrycuLJpvFwxEDQzYit={'user-agent':dIgPAXqneCWjrycuLJpvFwxEDQzYia.USER_AGENT,}
    dIgPAXqneCWjrycuLJpvFwxEDQzYiT=dIgPAXqneCWjrycuLJpvFwxEDQzYik.get(dIgPAXqneCWjrycuLJpvFwxEDQzYiH,params=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,headers=dIgPAXqneCWjrycuLJpvFwxEDQzYit,cookies=dIgPAXqneCWjrycuLJpvFwxEDQzYia.ST['cookies'],allow_redirects=dIgPAXqneCWjrycuLJpvFwxEDQzYKH)
    dIgPAXqneCWjrycuLJpvFwxEDQzYiH =dIgPAXqneCWjrycuLJpvFwxEDQzYiT.headers.get('location')
    for dIgPAXqneCWjrycuLJpvFwxEDQzYiN in dIgPAXqneCWjrycuLJpvFwxEDQzYiT.cookies:
     if dIgPAXqneCWjrycuLJpvFwxEDQzYiN.value not in['',dIgPAXqneCWjrycuLJpvFwxEDQzYKk]:
      dIgPAXqneCWjrycuLJpvFwxEDQzYia.ST['cookies'][dIgPAXqneCWjrycuLJpvFwxEDQzYiN.name]=dIgPAXqneCWjrycuLJpvFwxEDQzYiN.value
    if dIgPAXqneCWjrycuLJpvFwxEDQzYiT.status_code==200:break
   if dIgPAXqneCWjrycuLJpvFwxEDQzYia.ST['cookies']['id_token']=='':
    dIgPAXqneCWjrycuLJpvFwxEDQzYia.Init_ST_Total()
    return dIgPAXqneCWjrycuLJpvFwxEDQzYKH
  except dIgPAXqneCWjrycuLJpvFwxEDQzYKs as exception:
   dIgPAXqneCWjrycuLJpvFwxEDQzYbi(exception)
   dIgPAXqneCWjrycuLJpvFwxEDQzYia.Init_ST_Total()
   return dIgPAXqneCWjrycuLJpvFwxEDQzYKH
  try:
   dIgPAXqneCWjrycuLJpvFwxEDQzYiH=dIgPAXqneCWjrycuLJpvFwxEDQzYia.API_DOMAIN+'/api/v3/session' 
   dIgPAXqneCWjrycuLJpvFwxEDQzYiB=dIgPAXqneCWjrycuLJpvFwxEDQzYia.makeDefaultCookies()
   dIgPAXqneCWjrycuLJpvFwxEDQzYiT=dIgPAXqneCWjrycuLJpvFwxEDQzYia.callRequestCookies('Get',dIgPAXqneCWjrycuLJpvFwxEDQzYiH,params=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,headers=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,cookies=dIgPAXqneCWjrycuLJpvFwxEDQzYiB)
   dIgPAXqneCWjrycuLJpvFwxEDQzYmi=json.loads(dIgPAXqneCWjrycuLJpvFwxEDQzYiT.text)
   dIgPAXqneCWjrycuLJpvFwxEDQzYia.ST['cookies']['spotv_sessionid']=dIgPAXqneCWjrycuLJpvFwxEDQzYmi.get('userId')
   dIgPAXqneCWjrycuLJpvFwxEDQzYmS=dIgPAXqneCWjrycuLJpvFwxEDQzYia.SPOTV_PMCODE+dIgPAXqneCWjrycuLJpvFwxEDQzYKT(dIgPAXqneCWjrycuLJpvFwxEDQzYmi['subEndTime'])
   dIgPAXqneCWjrycuLJpvFwxEDQzYia.ST['cookies']['spotv_subend'] =base64.standard_b64encode(dIgPAXqneCWjrycuLJpvFwxEDQzYmS.encode()).decode('utf-8')
  except dIgPAXqneCWjrycuLJpvFwxEDQzYKs as exception:
   dIgPAXqneCWjrycuLJpvFwxEDQzYbi(exception)
   dIgPAXqneCWjrycuLJpvFwxEDQzYia.Init_ST_Total()
   return dIgPAXqneCWjrycuLJpvFwxEDQzYKH
  try:
   if dIgPAXqneCWjrycuLJpvFwxEDQzYmi['subEndTime']in[0,'0',dIgPAXqneCWjrycuLJpvFwxEDQzYKk]:
    dIgPAXqneCWjrycuLJpvFwxEDQzYiH=dIgPAXqneCWjrycuLJpvFwxEDQzYia.API_DOMAIN+'/api/v3/user/sub/scope' 
    dIgPAXqneCWjrycuLJpvFwxEDQzYiB=dIgPAXqneCWjrycuLJpvFwxEDQzYia.makeDefaultCookies()
    dIgPAXqneCWjrycuLJpvFwxEDQzYiT=dIgPAXqneCWjrycuLJpvFwxEDQzYia.callRequestCookies('Get',dIgPAXqneCWjrycuLJpvFwxEDQzYiH,params=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,headers=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,cookies=dIgPAXqneCWjrycuLJpvFwxEDQzYiB)
    dIgPAXqneCWjrycuLJpvFwxEDQzYmi=json.loads(dIgPAXqneCWjrycuLJpvFwxEDQzYiT.text)
    if dIgPAXqneCWjrycuLJpvFwxEDQzYmi.get('endDate')==dIgPAXqneCWjrycuLJpvFwxEDQzYKk:
     dIgPAXqneCWjrycuLJpvFwxEDQzYmS=dIgPAXqneCWjrycuLJpvFwxEDQzYia.SPOTV_PMCODE+'0'
     dIgPAXqneCWjrycuLJpvFwxEDQzYia.ST['cookies']['spotv_subend'] =base64.standard_b64encode(dIgPAXqneCWjrycuLJpvFwxEDQzYmS.encode()).decode('utf-8')
    else:
     dIgPAXqneCWjrycuLJpvFwxEDQzYma=datetime.datetime.strptime(dIgPAXqneCWjrycuLJpvFwxEDQzYmi.get('endDate'),'%Y-%m-%d %H:%M:%S')
     dIgPAXqneCWjrycuLJpvFwxEDQzYmS=dIgPAXqneCWjrycuLJpvFwxEDQzYKl(time.mktime(dIgPAXqneCWjrycuLJpvFwxEDQzYma.timetuple()))
     dIgPAXqneCWjrycuLJpvFwxEDQzYmS=dIgPAXqneCWjrycuLJpvFwxEDQzYia.SPOTV_PMCODE+dIgPAXqneCWjrycuLJpvFwxEDQzYKT(dIgPAXqneCWjrycuLJpvFwxEDQzYmS)+'000'
     dIgPAXqneCWjrycuLJpvFwxEDQzYia.ST['cookies']['spotv_subend'] =base64.standard_b64encode(dIgPAXqneCWjrycuLJpvFwxEDQzYmS.encode()).decode('utf-8')
  except dIgPAXqneCWjrycuLJpvFwxEDQzYKs as exception:
   dIgPAXqneCWjrycuLJpvFwxEDQzYbi(exception)
   dIgPAXqneCWjrycuLJpvFwxEDQzYia.Init_ST_Total()
   return dIgPAXqneCWjrycuLJpvFwxEDQzYKH
  if dIgPAXqneCWjrycuLJpvFwxEDQzYia.GetPolicyKey()==dIgPAXqneCWjrycuLJpvFwxEDQzYKH:
   dIgPAXqneCWjrycuLJpvFwxEDQzYia.Init_ST_Total()
   return dIgPAXqneCWjrycuLJpvFwxEDQzYKH
  '''
  https://players.brightcove.net/5764318566001/2SXVGLGl4_default/index.min.js
    options: {accountId: "5764318566001", policyKey: "BCpkADawqM072_NUcqm8RBVoMGIaio2x979NvYhN4Zrs685jLKKYmCx_ssySm_0HFSnwPKQIbaekH1PnWGFk-nQCtuky-DlMgN4KNvNlPYjsojAi1fU9ozEXVSpULPylDb8STvOgPf-F941V-RbByAkzD8CgApyhBS8TNN-yDc17gnFUj82OEBP8DEo" }  
  '''  
  return dIgPAXqneCWjrycuLJpvFwxEDQzYKV
 def GetCredential(dIgPAXqneCWjrycuLJpvFwxEDQzYia,user_id,user_pw):
  try:
   dIgPAXqneCWjrycuLJpvFwxEDQzYiV=base64.standard_b64encode(user_id.encode('UTF-8')).decode('utf-8')
   dIgPAXqneCWjrycuLJpvFwxEDQzYil=base64.standard_b64encode(user_pw.encode('UTF-8')).decode('utf-8')
   dIgPAXqneCWjrycuLJpvFwxEDQzYmK=dIgPAXqneCWjrycuLJpvFwxEDQzYia.API_DOMAIN+'/api/v2/login'
   dIgPAXqneCWjrycuLJpvFwxEDQzYis={'username':dIgPAXqneCWjrycuLJpvFwxEDQzYiV,'password':dIgPAXqneCWjrycuLJpvFwxEDQzYil}
   dIgPAXqneCWjrycuLJpvFwxEDQzYis=json.dumps(dIgPAXqneCWjrycuLJpvFwxEDQzYis)
   dIgPAXqneCWjrycuLJpvFwxEDQzYiT=dIgPAXqneCWjrycuLJpvFwxEDQzYia.callRequestCookies('Post',dIgPAXqneCWjrycuLJpvFwxEDQzYmK,payload=dIgPAXqneCWjrycuLJpvFwxEDQzYis,params=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,headers=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,cookies=dIgPAXqneCWjrycuLJpvFwxEDQzYKk)
   dIgPAXqneCWjrycuLJpvFwxEDQzYmb=json.loads(dIgPAXqneCWjrycuLJpvFwxEDQzYiT.text)
   for dIgPAXqneCWjrycuLJpvFwxEDQzYiN in dIgPAXqneCWjrycuLJpvFwxEDQzYiT.cookies:
    if dIgPAXqneCWjrycuLJpvFwxEDQzYiN.name=='SESSION':
     dIgPAXqneCWjrycuLJpvFwxEDQzYia.ST['cookies']['spotv_session']=dIgPAXqneCWjrycuLJpvFwxEDQzYiN.value
     break
   if dIgPAXqneCWjrycuLJpvFwxEDQzYia.ST['cookies']['spotv_session']=='':
    dIgPAXqneCWjrycuLJpvFwxEDQzYia.Init_ST_Total()
    return dIgPAXqneCWjrycuLJpvFwxEDQzYKH
   dIgPAXqneCWjrycuLJpvFwxEDQzYia.ST['cookies']['spotv_sessionid']=dIgPAXqneCWjrycuLJpvFwxEDQzYKT(dIgPAXqneCWjrycuLJpvFwxEDQzYmb['userId'])
   dIgPAXqneCWjrycuLJpvFwxEDQzYmS=dIgPAXqneCWjrycuLJpvFwxEDQzYia.SPOTV_PMCODE+dIgPAXqneCWjrycuLJpvFwxEDQzYKT(dIgPAXqneCWjrycuLJpvFwxEDQzYmb['subEndTime'])
   dIgPAXqneCWjrycuLJpvFwxEDQzYia.ST['cookies']['spotv_subend'] =base64.standard_b64encode(dIgPAXqneCWjrycuLJpvFwxEDQzYmS.encode()).decode('utf-8')
   if dIgPAXqneCWjrycuLJpvFwxEDQzYia.GetPolicyKey()==dIgPAXqneCWjrycuLJpvFwxEDQzYKH:
    dIgPAXqneCWjrycuLJpvFwxEDQzYia.Init_ST_Total()
    return dIgPAXqneCWjrycuLJpvFwxEDQzYKH
  except dIgPAXqneCWjrycuLJpvFwxEDQzYKs as exception:
   dIgPAXqneCWjrycuLJpvFwxEDQzYbi(exception)
   dIgPAXqneCWjrycuLJpvFwxEDQzYia.Init_ST_Total()
   return dIgPAXqneCWjrycuLJpvFwxEDQzYKH
  return dIgPAXqneCWjrycuLJpvFwxEDQzYKV
 def GetPolicyKey(dIgPAXqneCWjrycuLJpvFwxEDQzYia):
  try:
   dIgPAXqneCWjrycuLJpvFwxEDQzYiH=dIgPAXqneCWjrycuLJpvFwxEDQzYia.GetMainJspath()
   if dIgPAXqneCWjrycuLJpvFwxEDQzYiH=='':return dIgPAXqneCWjrycuLJpvFwxEDQzYKH
   dIgPAXqneCWjrycuLJpvFwxEDQzYiT=dIgPAXqneCWjrycuLJpvFwxEDQzYia.callRequestCookies('Get',dIgPAXqneCWjrycuLJpvFwxEDQzYiH,payload=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,params=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,headers=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,cookies=dIgPAXqneCWjrycuLJpvFwxEDQzYKk)
   dIgPAXqneCWjrycuLJpvFwxEDQzYmM=dIgPAXqneCWjrycuLJpvFwxEDQzYiT.text
   dIgPAXqneCWjrycuLJpvFwxEDQzYmO =re.findall('accountId:\s*\"\d{13}\",\s*policyKey:\s*\".[^(){}]{100,300}\"',dIgPAXqneCWjrycuLJpvFwxEDQzYmM)[0]
   dIgPAXqneCWjrycuLJpvFwxEDQzYmO =dIgPAXqneCWjrycuLJpvFwxEDQzYmO.replace('accountId','"accountId"')
   dIgPAXqneCWjrycuLJpvFwxEDQzYmO =dIgPAXqneCWjrycuLJpvFwxEDQzYmO.replace('policyKey','"policyKey"')
   dIgPAXqneCWjrycuLJpvFwxEDQzYmO ='{'+dIgPAXqneCWjrycuLJpvFwxEDQzYmO+'}'
   dIgPAXqneCWjrycuLJpvFwxEDQzYmf=json.loads(dIgPAXqneCWjrycuLJpvFwxEDQzYmO)
   dIgPAXqneCWjrycuLJpvFwxEDQzYia.ST['cookies']['spotv_accountId']=dIgPAXqneCWjrycuLJpvFwxEDQzYmf['accountId']
   dIgPAXqneCWjrycuLJpvFwxEDQzYia.ST['cookies']['spotv_policyKey']=dIgPAXqneCWjrycuLJpvFwxEDQzYmf['policyKey']
   dIgPAXqneCWjrycuLJpvFwxEDQzYbi(dIgPAXqneCWjrycuLJpvFwxEDQzYia.ST['cookies'])
  except dIgPAXqneCWjrycuLJpvFwxEDQzYKs as exception:
   dIgPAXqneCWjrycuLJpvFwxEDQzYbi(exception)
   return dIgPAXqneCWjrycuLJpvFwxEDQzYKH
  return dIgPAXqneCWjrycuLJpvFwxEDQzYKV
 def GetBcPlayerUrl(dIgPAXqneCWjrycuLJpvFwxEDQzYia):
  dIgPAXqneCWjrycuLJpvFwxEDQzYmG=''
  try:
   dIgPAXqneCWjrycuLJpvFwxEDQzYiH=dIgPAXqneCWjrycuLJpvFwxEDQzYia.GetMainJspath()
   if dIgPAXqneCWjrycuLJpvFwxEDQzYiH=='':return dIgPAXqneCWjrycuLJpvFwxEDQzYmG
   dIgPAXqneCWjrycuLJpvFwxEDQzYbi(dIgPAXqneCWjrycuLJpvFwxEDQzYiH)
   dIgPAXqneCWjrycuLJpvFwxEDQzYiT=dIgPAXqneCWjrycuLJpvFwxEDQzYia.callRequestCookies('Get',dIgPAXqneCWjrycuLJpvFwxEDQzYiH,payload=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,params=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,headers=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,cookies=dIgPAXqneCWjrycuLJpvFwxEDQzYKk)
   dIgPAXqneCWjrycuLJpvFwxEDQzYmM=dIgPAXqneCWjrycuLJpvFwxEDQzYiT.text
   dIgPAXqneCWjrycuLJpvFwxEDQzYmR =r'default:{(.*?)}'
   dIgPAXqneCWjrycuLJpvFwxEDQzYmo =re.compile(dIgPAXqneCWjrycuLJpvFwxEDQzYmR).findall(dIgPAXqneCWjrycuLJpvFwxEDQzYmM)[0]
   dIgPAXqneCWjrycuLJpvFwxEDQzYmh=r'bc:"(.*?)"'
   dIgPAXqneCWjrycuLJpvFwxEDQzYmB=re.compile(dIgPAXqneCWjrycuLJpvFwxEDQzYmh).findall(dIgPAXqneCWjrycuLJpvFwxEDQzYmo)[0]
   dIgPAXqneCWjrycuLJpvFwxEDQzYmt=r'":"(.*?)"'
   dIgPAXqneCWjrycuLJpvFwxEDQzYmU=re.compile(dIgPAXqneCWjrycuLJpvFwxEDQzYmt).findall(dIgPAXqneCWjrycuLJpvFwxEDQzYmo)[0]
   dIgPAXqneCWjrycuLJpvFwxEDQzYmG="%s/%s/%s_default/index.min.js"%(dIgPAXqneCWjrycuLJpvFwxEDQzYia.BC_DOMAIN,dIgPAXqneCWjrycuLJpvFwxEDQzYmB,dIgPAXqneCWjrycuLJpvFwxEDQzYmU)
  except dIgPAXqneCWjrycuLJpvFwxEDQzYKs as exception:
   dIgPAXqneCWjrycuLJpvFwxEDQzYbi(exception)
  return dIgPAXqneCWjrycuLJpvFwxEDQzYmG
 def GetMainJspath(dIgPAXqneCWjrycuLJpvFwxEDQzYia):
  dIgPAXqneCWjrycuLJpvFwxEDQzYmk=''
  try:
   dIgPAXqneCWjrycuLJpvFwxEDQzYiH=dIgPAXqneCWjrycuLJpvFwxEDQzYia.API_DOMAIN
   dIgPAXqneCWjrycuLJpvFwxEDQzYiT=dIgPAXqneCWjrycuLJpvFwxEDQzYia.callRequestCookies('Get',dIgPAXqneCWjrycuLJpvFwxEDQzYiH,payload=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,params=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,headers=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,cookies=dIgPAXqneCWjrycuLJpvFwxEDQzYKk)
   dIgPAXqneCWjrycuLJpvFwxEDQzYmM=dIgPAXqneCWjrycuLJpvFwxEDQzYiT.text
   dIgPAXqneCWjrycuLJpvFwxEDQzYmO =re.findall('https://cdn.spotvnow.co.kr/dist/js/.{20}\.js',dIgPAXqneCWjrycuLJpvFwxEDQzYmM)[0]
   dIgPAXqneCWjrycuLJpvFwxEDQzYmk=dIgPAXqneCWjrycuLJpvFwxEDQzYmO
  except dIgPAXqneCWjrycuLJpvFwxEDQzYKs as exception:
   dIgPAXqneCWjrycuLJpvFwxEDQzYbi(exception)
  return dIgPAXqneCWjrycuLJpvFwxEDQzYmk
 def Get_Now_Datetime(dIgPAXqneCWjrycuLJpvFwxEDQzYia):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetLiveChannelList(dIgPAXqneCWjrycuLJpvFwxEDQzYia):
  dIgPAXqneCWjrycuLJpvFwxEDQzYmT=[]
  dIgPAXqneCWjrycuLJpvFwxEDQzYmN ={}
  try:
   dIgPAXqneCWjrycuLJpvFwxEDQzYiH=dIgPAXqneCWjrycuLJpvFwxEDQzYia.API_DOMAIN+'/api/v3/channel'
   dIgPAXqneCWjrycuLJpvFwxEDQzYiT=dIgPAXqneCWjrycuLJpvFwxEDQzYia.callRequestCookies('Get',dIgPAXqneCWjrycuLJpvFwxEDQzYiH,payload=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,params=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,headers=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,cookies=dIgPAXqneCWjrycuLJpvFwxEDQzYKk)
   dIgPAXqneCWjrycuLJpvFwxEDQzYmb=json.loads(dIgPAXqneCWjrycuLJpvFwxEDQzYiT.text)
   dIgPAXqneCWjrycuLJpvFwxEDQzYmN=dIgPAXqneCWjrycuLJpvFwxEDQzYia.GetEPGList()
   for dIgPAXqneCWjrycuLJpvFwxEDQzYmV in dIgPAXqneCWjrycuLJpvFwxEDQzYmb:
    dIgPAXqneCWjrycuLJpvFwxEDQzYml={'id':dIgPAXqneCWjrycuLJpvFwxEDQzYmV['id'],'name':dIgPAXqneCWjrycuLJpvFwxEDQzYmV['name'],'logo':dIgPAXqneCWjrycuLJpvFwxEDQzYmV['logo'],'free':dIgPAXqneCWjrycuLJpvFwxEDQzYmV['free'],'programName':dIgPAXqneCWjrycuLJpvFwxEDQzYmV['programName'],'channelepg':dIgPAXqneCWjrycuLJpvFwxEDQzYmN.get(dIgPAXqneCWjrycuLJpvFwxEDQzYmV['id']),}
    dIgPAXqneCWjrycuLJpvFwxEDQzYmT.append(dIgPAXqneCWjrycuLJpvFwxEDQzYml)
  except dIgPAXqneCWjrycuLJpvFwxEDQzYKs as exception:
   dIgPAXqneCWjrycuLJpvFwxEDQzYbi(exception)
  return dIgPAXqneCWjrycuLJpvFwxEDQzYmT
 def GetHlsUrl(dIgPAXqneCWjrycuLJpvFwxEDQzYia,mediacode):
  dIgPAXqneCWjrycuLJpvFwxEDQzYms=''
  try:
   dIgPAXqneCWjrycuLJpvFwxEDQzYiH=dIgPAXqneCWjrycuLJpvFwxEDQzYia.API_DOMAIN+'/api/v3/channel/'+mediacode
   dIgPAXqneCWjrycuLJpvFwxEDQzYiT=dIgPAXqneCWjrycuLJpvFwxEDQzYia.callRequestCookies('Get',dIgPAXqneCWjrycuLJpvFwxEDQzYiH,payload=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,params=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,headers=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,cookies=dIgPAXqneCWjrycuLJpvFwxEDQzYKk)
   dIgPAXqneCWjrycuLJpvFwxEDQzYmb=json.loads(dIgPAXqneCWjrycuLJpvFwxEDQzYiT.text)
   dIgPAXqneCWjrycuLJpvFwxEDQzYms=dIgPAXqneCWjrycuLJpvFwxEDQzYmb['hlsUrl']
  except dIgPAXqneCWjrycuLJpvFwxEDQzYKs as exception:
   dIgPAXqneCWjrycuLJpvFwxEDQzYbi(exception)
  return dIgPAXqneCWjrycuLJpvFwxEDQzYms
 def GetEPGList(dIgPAXqneCWjrycuLJpvFwxEDQzYia):
  dIgPAXqneCWjrycuLJpvFwxEDQzYSi={}
  dIgPAXqneCWjrycuLJpvFwxEDQzYSm=dIgPAXqneCWjrycuLJpvFwxEDQzYia.Get_Now_Datetime()
  dIgPAXqneCWjrycuLJpvFwxEDQzYSa=dIgPAXqneCWjrycuLJpvFwxEDQzYSm.strftime('%Y%m%d%H%M')
  dIgPAXqneCWjrycuLJpvFwxEDQzYSK='%s-%s-%s'%(dIgPAXqneCWjrycuLJpvFwxEDQzYSa[0:4],dIgPAXqneCWjrycuLJpvFwxEDQzYSa[4:6],dIgPAXqneCWjrycuLJpvFwxEDQzYSa[6:8])
  dIgPAXqneCWjrycuLJpvFwxEDQzYSb=(dIgPAXqneCWjrycuLJpvFwxEDQzYSm+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M')
  try:
   dIgPAXqneCWjrycuLJpvFwxEDQzYiH=dIgPAXqneCWjrycuLJpvFwxEDQzYia.API_DOMAIN+'/api/v3/program/'+dIgPAXqneCWjrycuLJpvFwxEDQzYSK
   dIgPAXqneCWjrycuLJpvFwxEDQzYiT=dIgPAXqneCWjrycuLJpvFwxEDQzYia.callRequestCookies('Get',dIgPAXqneCWjrycuLJpvFwxEDQzYiH,payload=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,params=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,headers=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,cookies=dIgPAXqneCWjrycuLJpvFwxEDQzYKk)
   dIgPAXqneCWjrycuLJpvFwxEDQzYmb=json.loads(dIgPAXqneCWjrycuLJpvFwxEDQzYiT.text)
   dIgPAXqneCWjrycuLJpvFwxEDQzYSM=-1 
   dIgPAXqneCWjrycuLJpvFwxEDQzYSO =''
   for dIgPAXqneCWjrycuLJpvFwxEDQzYmV in dIgPAXqneCWjrycuLJpvFwxEDQzYmb:
    dIgPAXqneCWjrycuLJpvFwxEDQzYSf=dIgPAXqneCWjrycuLJpvFwxEDQzYmV['channelId']
    dIgPAXqneCWjrycuLJpvFwxEDQzYSG =dIgPAXqneCWjrycuLJpvFwxEDQzYmV['startTime'].replace('-','').replace(' ','').replace(':','')
    dIgPAXqneCWjrycuLJpvFwxEDQzYSR =dIgPAXqneCWjrycuLJpvFwxEDQzYmV['endTime'].replace('-','').replace(' ','').replace(':','')
    if dIgPAXqneCWjrycuLJpvFwxEDQzYKl(dIgPAXqneCWjrycuLJpvFwxEDQzYSa)>dIgPAXqneCWjrycuLJpvFwxEDQzYKl(dIgPAXqneCWjrycuLJpvFwxEDQzYSR) :continue
    if dIgPAXqneCWjrycuLJpvFwxEDQzYKl(dIgPAXqneCWjrycuLJpvFwxEDQzYSb)<dIgPAXqneCWjrycuLJpvFwxEDQzYKl(dIgPAXqneCWjrycuLJpvFwxEDQzYSG):continue
    if dIgPAXqneCWjrycuLJpvFwxEDQzYSM!=dIgPAXqneCWjrycuLJpvFwxEDQzYSf:
     if dIgPAXqneCWjrycuLJpvFwxEDQzYSO!='':dIgPAXqneCWjrycuLJpvFwxEDQzYSi[dIgPAXqneCWjrycuLJpvFwxEDQzYSM]=dIgPAXqneCWjrycuLJpvFwxEDQzYSO
     dIgPAXqneCWjrycuLJpvFwxEDQzYSM=dIgPAXqneCWjrycuLJpvFwxEDQzYSf
     dIgPAXqneCWjrycuLJpvFwxEDQzYSO =''
    if dIgPAXqneCWjrycuLJpvFwxEDQzYSO:dIgPAXqneCWjrycuLJpvFwxEDQzYSO+='\n'
    dIgPAXqneCWjrycuLJpvFwxEDQzYSO+=dIgPAXqneCWjrycuLJpvFwxEDQzYmV['title']+'\n'
    dIgPAXqneCWjrycuLJpvFwxEDQzYSO+=' [%s ~ %s]'%(dIgPAXqneCWjrycuLJpvFwxEDQzYmV['startTime'][-5:],dIgPAXqneCWjrycuLJpvFwxEDQzYmV['endTime'][-5:])+'\n'
   if dIgPAXqneCWjrycuLJpvFwxEDQzYSO:dIgPAXqneCWjrycuLJpvFwxEDQzYSi[dIgPAXqneCWjrycuLJpvFwxEDQzYSM]=dIgPAXqneCWjrycuLJpvFwxEDQzYSO
  except dIgPAXqneCWjrycuLJpvFwxEDQzYKs as exception:
   dIgPAXqneCWjrycuLJpvFwxEDQzYbi(exception)
  return dIgPAXqneCWjrycuLJpvFwxEDQzYSi
 def GetEPGList_new(dIgPAXqneCWjrycuLJpvFwxEDQzYia):
  dIgPAXqneCWjrycuLJpvFwxEDQzYSi={}
  dIgPAXqneCWjrycuLJpvFwxEDQzYSm=dIgPAXqneCWjrycuLJpvFwxEDQzYia.Get_Now_Datetime()
  dIgPAXqneCWjrycuLJpvFwxEDQzYSa=dIgPAXqneCWjrycuLJpvFwxEDQzYSm.strftime('%Y%m%d%H%M00')
  dIgPAXqneCWjrycuLJpvFwxEDQzYSK='%s%s%s'%(dIgPAXqneCWjrycuLJpvFwxEDQzYSa[0:4],dIgPAXqneCWjrycuLJpvFwxEDQzYSa[4:6],dIgPAXqneCWjrycuLJpvFwxEDQzYSa[6:8])
  dIgPAXqneCWjrycuLJpvFwxEDQzYSb=(dIgPAXqneCWjrycuLJpvFwxEDQzYSm+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M00')
  try:
   for dIgPAXqneCWjrycuLJpvFwxEDQzYmV in LIVETV_LIST:
    dIgPAXqneCWjrycuLJpvFwxEDQzYSo =dIgPAXqneCWjrycuLJpvFwxEDQzYmV['videoId']
    if dIgPAXqneCWjrycuLJpvFwxEDQzYmV['epgtype']=='spotvon':
     dIgPAXqneCWjrycuLJpvFwxEDQzYSO=dIgPAXqneCWjrycuLJpvFwxEDQzYia.Get_EpgInfo_Spotv_spotvon(dIgPAXqneCWjrycuLJpvFwxEDQzYSo,dIgPAXqneCWjrycuLJpvFwxEDQzYmV['epgnm'],dIgPAXqneCWjrycuLJpvFwxEDQzYSK)
     dIgPAXqneCWjrycuLJpvFwxEDQzYSi[dIgPAXqneCWjrycuLJpvFwxEDQzYSo]=dIgPAXqneCWjrycuLJpvFwxEDQzYSO
    if dIgPAXqneCWjrycuLJpvFwxEDQzYmV['epgtype']=='spotvnet':
     dIgPAXqneCWjrycuLJpvFwxEDQzYSO=dIgPAXqneCWjrycuLJpvFwxEDQzYia.Get_EpgInfo_Spotv_spotvnet(dIgPAXqneCWjrycuLJpvFwxEDQzYSo,dIgPAXqneCWjrycuLJpvFwxEDQzYmV['epgnm'],dIgPAXqneCWjrycuLJpvFwxEDQzYSK)
     dIgPAXqneCWjrycuLJpvFwxEDQzYSi[dIgPAXqneCWjrycuLJpvFwxEDQzYSo]=dIgPAXqneCWjrycuLJpvFwxEDQzYSO
   for dIgPAXqneCWjrycuLJpvFwxEDQzYSh in dIgPAXqneCWjrycuLJpvFwxEDQzYSi.keys():
    if dIgPAXqneCWjrycuLJpvFwxEDQzYbm(dIgPAXqneCWjrycuLJpvFwxEDQzYSi.get(dIgPAXqneCWjrycuLJpvFwxEDQzYSh))==0:continue
    dIgPAXqneCWjrycuLJpvFwxEDQzYSO =''
    dIgPAXqneCWjrycuLJpvFwxEDQzYSB=''
    for dIgPAXqneCWjrycuLJpvFwxEDQzYSt in dIgPAXqneCWjrycuLJpvFwxEDQzYSi.get(dIgPAXqneCWjrycuLJpvFwxEDQzYSh):
     dIgPAXqneCWjrycuLJpvFwxEDQzYSG =dIgPAXqneCWjrycuLJpvFwxEDQzYSt['startTime']
     dIgPAXqneCWjrycuLJpvFwxEDQzYSR =dIgPAXqneCWjrycuLJpvFwxEDQzYSt['endTime']
     if dIgPAXqneCWjrycuLJpvFwxEDQzYKl(dIgPAXqneCWjrycuLJpvFwxEDQzYSa)>dIgPAXqneCWjrycuLJpvFwxEDQzYKl(dIgPAXqneCWjrycuLJpvFwxEDQzYSR) :continue
     if dIgPAXqneCWjrycuLJpvFwxEDQzYKl(dIgPAXqneCWjrycuLJpvFwxEDQzYSb)<dIgPAXqneCWjrycuLJpvFwxEDQzYKl(dIgPAXqneCWjrycuLJpvFwxEDQzYSG):continue
     if dIgPAXqneCWjrycuLJpvFwxEDQzYKl(dIgPAXqneCWjrycuLJpvFwxEDQzYSa)>=dIgPAXqneCWjrycuLJpvFwxEDQzYKl(dIgPAXqneCWjrycuLJpvFwxEDQzYSG)and dIgPAXqneCWjrycuLJpvFwxEDQzYKl(dIgPAXqneCWjrycuLJpvFwxEDQzYSa)<dIgPAXqneCWjrycuLJpvFwxEDQzYKl(dIgPAXqneCWjrycuLJpvFwxEDQzYSR):dIgPAXqneCWjrycuLJpvFwxEDQzYSB=dIgPAXqneCWjrycuLJpvFwxEDQzYia.xmlText(dIgPAXqneCWjrycuLJpvFwxEDQzYSt['title'])
     if dIgPAXqneCWjrycuLJpvFwxEDQzYSO:dIgPAXqneCWjrycuLJpvFwxEDQzYSO+='\n'
     dIgPAXqneCWjrycuLJpvFwxEDQzYSO+=dIgPAXqneCWjrycuLJpvFwxEDQzYia.xmlText(dIgPAXqneCWjrycuLJpvFwxEDQzYSt['title'])+'\n'
     dIgPAXqneCWjrycuLJpvFwxEDQzYSO+=' [%s:%s ~ %s:%s]'%(dIgPAXqneCWjrycuLJpvFwxEDQzYSt['startTime'][8:10],dIgPAXqneCWjrycuLJpvFwxEDQzYSt['startTime'][10:12],dIgPAXqneCWjrycuLJpvFwxEDQzYSt['endTime'][8:10],dIgPAXqneCWjrycuLJpvFwxEDQzYSt['endTime'][10:12])+'\n'
    dIgPAXqneCWjrycuLJpvFwxEDQzYSi[dIgPAXqneCWjrycuLJpvFwxEDQzYSh]={'epg':dIgPAXqneCWjrycuLJpvFwxEDQzYSO,'title':dIgPAXqneCWjrycuLJpvFwxEDQzYSB}
  except dIgPAXqneCWjrycuLJpvFwxEDQzYKs as exception:
   dIgPAXqneCWjrycuLJpvFwxEDQzYbi(exception)
  return dIgPAXqneCWjrycuLJpvFwxEDQzYSi
 def Get_EpgInfo_Spotv_spotvon(dIgPAXqneCWjrycuLJpvFwxEDQzYia,dIgPAXqneCWjrycuLJpvFwxEDQzYSo,epgnm,now_day):
  dIgPAXqneCWjrycuLJpvFwxEDQzYSi =[]
  try:
   dIgPAXqneCWjrycuLJpvFwxEDQzYiH='https://www.spotvon.co.kr/data/onAir/%s/Daily/D%s.asp'%(epgnm,now_day)
   dIgPAXqneCWjrycuLJpvFwxEDQzYiT=dIgPAXqneCWjrycuLJpvFwxEDQzYia.callRequestCookies('Get',dIgPAXqneCWjrycuLJpvFwxEDQzYiH,payload=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,params=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,headers=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,cookies=dIgPAXqneCWjrycuLJpvFwxEDQzYKk)
   dIgPAXqneCWjrycuLJpvFwxEDQzYmi=json.loads(dIgPAXqneCWjrycuLJpvFwxEDQzYiT.text)
   for dIgPAXqneCWjrycuLJpvFwxEDQzYmV in dIgPAXqneCWjrycuLJpvFwxEDQzYmi:
    dIgPAXqneCWjrycuLJpvFwxEDQzYml={'title':dIgPAXqneCWjrycuLJpvFwxEDQzYmV['title'],'startTime':dIgPAXqneCWjrycuLJpvFwxEDQzYmV['sch_date'].replace('-','')+dIgPAXqneCWjrycuLJpvFwxEDQzYKT(dIgPAXqneCWjrycuLJpvFwxEDQzYmV['sch_hour']).zfill(2)+dIgPAXqneCWjrycuLJpvFwxEDQzYmV['sch_min']+'00'}
    dIgPAXqneCWjrycuLJpvFwxEDQzYSi.append(dIgPAXqneCWjrycuLJpvFwxEDQzYml)
   for i in dIgPAXqneCWjrycuLJpvFwxEDQzYbS(dIgPAXqneCWjrycuLJpvFwxEDQzYbm(dIgPAXqneCWjrycuLJpvFwxEDQzYSi)):
    if i>0:dIgPAXqneCWjrycuLJpvFwxEDQzYSi[i-1]['endTime']=dIgPAXqneCWjrycuLJpvFwxEDQzYSi[i]['startTime']
    if i==dIgPAXqneCWjrycuLJpvFwxEDQzYbm(dIgPAXqneCWjrycuLJpvFwxEDQzYSi)-1: dIgPAXqneCWjrycuLJpvFwxEDQzYSi[i]['endTime']=now_day+'240000'
  except dIgPAXqneCWjrycuLJpvFwxEDQzYKs as exception:
   dIgPAXqneCWjrycuLJpvFwxEDQzYbi(exception)
   return[]
  return dIgPAXqneCWjrycuLJpvFwxEDQzYSi
 def Get_EpgInfo_Spotv_spotvnet(dIgPAXqneCWjrycuLJpvFwxEDQzYia,dIgPAXqneCWjrycuLJpvFwxEDQzYSo,epgnm,now_day):
  dIgPAXqneCWjrycuLJpvFwxEDQzYSi =[]
  try:
   dIgPAXqneCWjrycuLJpvFwxEDQzYiH='https://www.spotv.net/data/json/schedule/%s/Daily/D%s.json'%(epgnm,now_day)
   dIgPAXqneCWjrycuLJpvFwxEDQzYiT=dIgPAXqneCWjrycuLJpvFwxEDQzYia.callRequestCookies('Get',dIgPAXqneCWjrycuLJpvFwxEDQzYiH,payload=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,params=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,headers=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,cookies=dIgPAXqneCWjrycuLJpvFwxEDQzYKk)
   dIgPAXqneCWjrycuLJpvFwxEDQzYmi=json.loads(dIgPAXqneCWjrycuLJpvFwxEDQzYiT.text)
   for dIgPAXqneCWjrycuLJpvFwxEDQzYmV in dIgPAXqneCWjrycuLJpvFwxEDQzYmi:
    dIgPAXqneCWjrycuLJpvFwxEDQzYml={'title':dIgPAXqneCWjrycuLJpvFwxEDQzYmV['title'],'startTime':dIgPAXqneCWjrycuLJpvFwxEDQzYmV['sch_date'].replace('-','')+dIgPAXqneCWjrycuLJpvFwxEDQzYKT(dIgPAXqneCWjrycuLJpvFwxEDQzYmV['sch_hour']).zfill(2)+dIgPAXqneCWjrycuLJpvFwxEDQzYmV['sch_min']+'00'}
    dIgPAXqneCWjrycuLJpvFwxEDQzYSi.append(dIgPAXqneCWjrycuLJpvFwxEDQzYml)
   for i in dIgPAXqneCWjrycuLJpvFwxEDQzYbS(dIgPAXqneCWjrycuLJpvFwxEDQzYbm(dIgPAXqneCWjrycuLJpvFwxEDQzYSi)):
    if i>0:dIgPAXqneCWjrycuLJpvFwxEDQzYSi[i-1]['endTime']=dIgPAXqneCWjrycuLJpvFwxEDQzYSi[i]['startTime']
    if i==dIgPAXqneCWjrycuLJpvFwxEDQzYbm(dIgPAXqneCWjrycuLJpvFwxEDQzYSi)-1: dIgPAXqneCWjrycuLJpvFwxEDQzYSi[i]['endTime']=now_day+'240000'
  except dIgPAXqneCWjrycuLJpvFwxEDQzYKs as exception:
   dIgPAXqneCWjrycuLJpvFwxEDQzYbi(exception)
   return[]
  return dIgPAXqneCWjrycuLJpvFwxEDQzYSi
 def GetEventLiveList(dIgPAXqneCWjrycuLJpvFwxEDQzYia):
  dIgPAXqneCWjrycuLJpvFwxEDQzYmT=[]
  dIgPAXqneCWjrycuLJpvFwxEDQzYSU =0
  try:
   dIgPAXqneCWjrycuLJpvFwxEDQzYSk=dIgPAXqneCWjrycuLJpvFwxEDQzYia.Get_Now_Datetime()
   dIgPAXqneCWjrycuLJpvFwxEDQzYSH=dIgPAXqneCWjrycuLJpvFwxEDQzYSk.strftime('%Y-%m-%d')
  except dIgPAXqneCWjrycuLJpvFwxEDQzYKs as exception:
   dIgPAXqneCWjrycuLJpvFwxEDQzYbi(exception)
   return dIgPAXqneCWjrycuLJpvFwxEDQzYmT,dIgPAXqneCWjrycuLJpvFwxEDQzYSU
  dIgPAXqneCWjrycuLJpvFwxEDQzYiH=dIgPAXqneCWjrycuLJpvFwxEDQzYia.API_DOMAIN+'/api/v3/player/lives/'+dIgPAXqneCWjrycuLJpvFwxEDQzYSH 
  dIgPAXqneCWjrycuLJpvFwxEDQzYiB=dIgPAXqneCWjrycuLJpvFwxEDQzYia.makeDefaultCookies()
  dIgPAXqneCWjrycuLJpvFwxEDQzYiT=dIgPAXqneCWjrycuLJpvFwxEDQzYia.callRequestCookies('Get',dIgPAXqneCWjrycuLJpvFwxEDQzYiH,payload=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,params=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,headers=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,cookies=dIgPAXqneCWjrycuLJpvFwxEDQzYiB)
  dIgPAXqneCWjrycuLJpvFwxEDQzYSU=dIgPAXqneCWjrycuLJpvFwxEDQzYiT.status_code 
  if dIgPAXqneCWjrycuLJpvFwxEDQzYSU!=200:return dIgPAXqneCWjrycuLJpvFwxEDQzYmT,dIgPAXqneCWjrycuLJpvFwxEDQzYSU
  dIgPAXqneCWjrycuLJpvFwxEDQzYmb=json.loads(dIgPAXqneCWjrycuLJpvFwxEDQzYiT.text)
  for dIgPAXqneCWjrycuLJpvFwxEDQzYST in dIgPAXqneCWjrycuLJpvFwxEDQzYmb:
   for dIgPAXqneCWjrycuLJpvFwxEDQzYmV in dIgPAXqneCWjrycuLJpvFwxEDQzYST['liveNowList']:
    if dIgPAXqneCWjrycuLJpvFwxEDQzYmV['gameDesc']['title']==dIgPAXqneCWjrycuLJpvFwxEDQzYKk or dIgPAXqneCWjrycuLJpvFwxEDQzYmV['gameDesc']['title']=='':
     dIgPAXqneCWjrycuLJpvFwxEDQzYSN='%s ( %s : %s )'%(dIgPAXqneCWjrycuLJpvFwxEDQzYmV['leagueName'],dIgPAXqneCWjrycuLJpvFwxEDQzYmV['homeNameShort'],dIgPAXqneCWjrycuLJpvFwxEDQzYmV['awayNameShort'])
    else:
     dIgPAXqneCWjrycuLJpvFwxEDQzYSN=dIgPAXqneCWjrycuLJpvFwxEDQzYmV['gameDesc']['title']
    dIgPAXqneCWjrycuLJpvFwxEDQzYml={'liveId':dIgPAXqneCWjrycuLJpvFwxEDQzYmV['liveId'],'title':dIgPAXqneCWjrycuLJpvFwxEDQzYSN,'logo':dIgPAXqneCWjrycuLJpvFwxEDQzYmV['gameDesc']['leagueLogo'],'free':dIgPAXqneCWjrycuLJpvFwxEDQzYmV['isFree'],'startTime':dIgPAXqneCWjrycuLJpvFwxEDQzYmV['startTime']}
    dIgPAXqneCWjrycuLJpvFwxEDQzYmT.append(dIgPAXqneCWjrycuLJpvFwxEDQzYml)
  return dIgPAXqneCWjrycuLJpvFwxEDQzYmT,dIgPAXqneCWjrycuLJpvFwxEDQzYSU
 def GetEventLive_videoId(dIgPAXqneCWjrycuLJpvFwxEDQzYia,liveId):
  dIgPAXqneCWjrycuLJpvFwxEDQzYSV=''
  try:
   dIgPAXqneCWjrycuLJpvFwxEDQzYiH=dIgPAXqneCWjrycuLJpvFwxEDQzYia.API_DOMAIN+'/api/v3/live/'+liveId
   dIgPAXqneCWjrycuLJpvFwxEDQzYiT=dIgPAXqneCWjrycuLJpvFwxEDQzYia.callRequestCookies('Get',dIgPAXqneCWjrycuLJpvFwxEDQzYiH,payload=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,params=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,headers=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,cookies=dIgPAXqneCWjrycuLJpvFwxEDQzYKk)
   dIgPAXqneCWjrycuLJpvFwxEDQzYmb=json.loads(dIgPAXqneCWjrycuLJpvFwxEDQzYiT.text)
   dIgPAXqneCWjrycuLJpvFwxEDQzYSl=dIgPAXqneCWjrycuLJpvFwxEDQzYmb['videoId']
   dIgPAXqneCWjrycuLJpvFwxEDQzYSV=dIgPAXqneCWjrycuLJpvFwxEDQzYSl.replace('ref:','')
  except dIgPAXqneCWjrycuLJpvFwxEDQzYKs as exception:
   dIgPAXqneCWjrycuLJpvFwxEDQzYbi(exception)
  return dIgPAXqneCWjrycuLJpvFwxEDQzYSV
 def CheckMainEnd(dIgPAXqneCWjrycuLJpvFwxEDQzYia):
  dIgPAXqneCWjrycuLJpvFwxEDQzYSs=dIgPAXqneCWjrycuLJpvFwxEDQzYia.SPOTV_PMCODE+dIgPAXqneCWjrycuLJpvFwxEDQzYKT(dIgPAXqneCWjrycuLJpvFwxEDQzYia.ST['cookies']['spotv_sessionid'])
  dIgPAXqneCWjrycuLJpvFwxEDQzYSs=base64.standard_b64encode(dIgPAXqneCWjrycuLJpvFwxEDQzYSs.encode()).decode('utf-8')
  if dIgPAXqneCWjrycuLJpvFwxEDQzYSs=='OTg3MTgzMzM0Ng==' or dIgPAXqneCWjrycuLJpvFwxEDQzYSs=='OTg3MTgzMzExNw==':return dIgPAXqneCWjrycuLJpvFwxEDQzYKV
  return dIgPAXqneCWjrycuLJpvFwxEDQzYKH
 def CheckSubEnd(dIgPAXqneCWjrycuLJpvFwxEDQzYia):
  dIgPAXqneCWjrycuLJpvFwxEDQzYiR=dIgPAXqneCWjrycuLJpvFwxEDQzYKH
  try:
   if dIgPAXqneCWjrycuLJpvFwxEDQzYia.CheckMainEnd():return dIgPAXqneCWjrycuLJpvFwxEDQzYKV 
   dIgPAXqneCWjrycuLJpvFwxEDQzYai=base64.standard_b64decode(dIgPAXqneCWjrycuLJpvFwxEDQzYia.ST['cookies']['spotv_subend']).decode('utf-8')[dIgPAXqneCWjrycuLJpvFwxEDQzYia.SPOTV_PMSIZE:]
   if dIgPAXqneCWjrycuLJpvFwxEDQzYai=='0':return dIgPAXqneCWjrycuLJpvFwxEDQzYiR
   dIgPAXqneCWjrycuLJpvFwxEDQzYam =dIgPAXqneCWjrycuLJpvFwxEDQzYKl(dIgPAXqneCWjrycuLJpvFwxEDQzYia.Get_Now_Datetime().strftime('%Y%m%d'))
   dIgPAXqneCWjrycuLJpvFwxEDQzYaS =dIgPAXqneCWjrycuLJpvFwxEDQzYKl(dIgPAXqneCWjrycuLJpvFwxEDQzYai)/1000
   dIgPAXqneCWjrycuLJpvFwxEDQzYaK =dIgPAXqneCWjrycuLJpvFwxEDQzYKl(datetime.datetime.fromtimestamp(dIgPAXqneCWjrycuLJpvFwxEDQzYaS,datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul')).strftime('%Y%m%d'))
   if dIgPAXqneCWjrycuLJpvFwxEDQzYam<=dIgPAXqneCWjrycuLJpvFwxEDQzYaK:dIgPAXqneCWjrycuLJpvFwxEDQzYiR=dIgPAXqneCWjrycuLJpvFwxEDQzYKV
  except dIgPAXqneCWjrycuLJpvFwxEDQzYKs as exception:
   dIgPAXqneCWjrycuLJpvFwxEDQzYbi(exception)
   return dIgPAXqneCWjrycuLJpvFwxEDQzYiR
  return dIgPAXqneCWjrycuLJpvFwxEDQzYiR
 def GetBroadURL(dIgPAXqneCWjrycuLJpvFwxEDQzYia,dIgPAXqneCWjrycuLJpvFwxEDQzYSV,mediatype,dIgPAXqneCWjrycuLJpvFwxEDQzYaB):
  dIgPAXqneCWjrycuLJpvFwxEDQzYab=''
  try:
   if mediatype=='live':
    dIgPAXqneCWjrycuLJpvFwxEDQzYiH=dIgPAXqneCWjrycuLJpvFwxEDQzYia.API_DOMAIN+'/api/v3/live/'+dIgPAXqneCWjrycuLJpvFwxEDQzYSV
   else:
    dIgPAXqneCWjrycuLJpvFwxEDQzYSV=dIgPAXqneCWjrycuLJpvFwxEDQzYia.GetReplay_UrlId(dIgPAXqneCWjrycuLJpvFwxEDQzYSV,dIgPAXqneCWjrycuLJpvFwxEDQzYaB)
    if dIgPAXqneCWjrycuLJpvFwxEDQzYSV=='':return dIgPAXqneCWjrycuLJpvFwxEDQzYab
    dIgPAXqneCWjrycuLJpvFwxEDQzYiH=dIgPAXqneCWjrycuLJpvFwxEDQzYia.PLAYER_DOMAIN+'/playback/v1/accounts/'+dIgPAXqneCWjrycuLJpvFwxEDQzYKT(dIgPAXqneCWjrycuLJpvFwxEDQzYia.ST['cookies']['spotv_accountId'])+'/videos/'+dIgPAXqneCWjrycuLJpvFwxEDQzYSV
   dIgPAXqneCWjrycuLJpvFwxEDQzYit=dIgPAXqneCWjrycuLJpvFwxEDQzYia.makeDefaultHeaders()
   dIgPAXqneCWjrycuLJpvFwxEDQzYiT=dIgPAXqneCWjrycuLJpvFwxEDQzYia.callRequestCookies('Get',dIgPAXqneCWjrycuLJpvFwxEDQzYiH,payload=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,params=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,headers=dIgPAXqneCWjrycuLJpvFwxEDQzYit,cookies=dIgPAXqneCWjrycuLJpvFwxEDQzYKk)
   dIgPAXqneCWjrycuLJpvFwxEDQzYmi=json.loads(dIgPAXqneCWjrycuLJpvFwxEDQzYiT.text)
   dIgPAXqneCWjrycuLJpvFwxEDQzYbi(dIgPAXqneCWjrycuLJpvFwxEDQzYiH)
   if mediatype=='live':
    dIgPAXqneCWjrycuLJpvFwxEDQzYab=dIgPAXqneCWjrycuLJpvFwxEDQzYmi['hlsUrl2']or dIgPAXqneCWjrycuLJpvFwxEDQzYmi['hlsUrl']
   else:
    dIgPAXqneCWjrycuLJpvFwxEDQzYbi(dIgPAXqneCWjrycuLJpvFwxEDQzYmi)
    dIgPAXqneCWjrycuLJpvFwxEDQzYab=dIgPAXqneCWjrycuLJpvFwxEDQzYmi['sources'][0]['src']
   dIgPAXqneCWjrycuLJpvFwxEDQzYab=dIgPAXqneCWjrycuLJpvFwxEDQzYab.replace('http://','https://')
  except dIgPAXqneCWjrycuLJpvFwxEDQzYKs as exception:
   dIgPAXqneCWjrycuLJpvFwxEDQzYbi(exception)
  return dIgPAXqneCWjrycuLJpvFwxEDQzYab
 def GetTitleGroupList(dIgPAXqneCWjrycuLJpvFwxEDQzYia):
  dIgPAXqneCWjrycuLJpvFwxEDQzYmT=[]
  dIgPAXqneCWjrycuLJpvFwxEDQzYiH=dIgPAXqneCWjrycuLJpvFwxEDQzYia.API_DOMAIN+'/api/v3/home/web'
  dIgPAXqneCWjrycuLJpvFwxEDQzYiT=dIgPAXqneCWjrycuLJpvFwxEDQzYia.callRequestCookies('Get',dIgPAXqneCWjrycuLJpvFwxEDQzYiH,payload=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,params=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,headers=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,cookies=dIgPAXqneCWjrycuLJpvFwxEDQzYKk)
  dIgPAXqneCWjrycuLJpvFwxEDQzYmb=json.loads(dIgPAXqneCWjrycuLJpvFwxEDQzYiT.text)
  for dIgPAXqneCWjrycuLJpvFwxEDQzYmV in dIgPAXqneCWjrycuLJpvFwxEDQzYmb:
   if dIgPAXqneCWjrycuLJpvFwxEDQzYKT(dIgPAXqneCWjrycuLJpvFwxEDQzYmV['type'])=='3':
    dIgPAXqneCWjrycuLJpvFwxEDQzYaM=''
    for dIgPAXqneCWjrycuLJpvFwxEDQzYaO in dIgPAXqneCWjrycuLJpvFwxEDQzYmV['data']['list']:
     dIgPAXqneCWjrycuLJpvFwxEDQzYaf='[%s] %s vs %s\n<%s>\n\n'%(dIgPAXqneCWjrycuLJpvFwxEDQzYaO['gameDesc']['roundName'],dIgPAXqneCWjrycuLJpvFwxEDQzYaO['gameDesc']['homeNameShort'],dIgPAXqneCWjrycuLJpvFwxEDQzYaO['gameDesc']['awayNameShort'],dIgPAXqneCWjrycuLJpvFwxEDQzYaO['gameDesc']['beginDate'])
     dIgPAXqneCWjrycuLJpvFwxEDQzYaM+=dIgPAXqneCWjrycuLJpvFwxEDQzYaf
    dIgPAXqneCWjrycuLJpvFwxEDQzYml={'title':dIgPAXqneCWjrycuLJpvFwxEDQzYmV['title'],'logo':dIgPAXqneCWjrycuLJpvFwxEDQzYmV['logo'],'reagueId':dIgPAXqneCWjrycuLJpvFwxEDQzYKT(dIgPAXqneCWjrycuLJpvFwxEDQzYmV['destId']),'subGame':dIgPAXqneCWjrycuLJpvFwxEDQzYaM,}
    dIgPAXqneCWjrycuLJpvFwxEDQzYmT.append(dIgPAXqneCWjrycuLJpvFwxEDQzYml)
  return dIgPAXqneCWjrycuLJpvFwxEDQzYmT
 def GetPopularGroupList(dIgPAXqneCWjrycuLJpvFwxEDQzYia):
  dIgPAXqneCWjrycuLJpvFwxEDQzYmT=[]
  dIgPAXqneCWjrycuLJpvFwxEDQzYiH=dIgPAXqneCWjrycuLJpvFwxEDQzYia.API_DOMAIN+'/api/v3/home/web'
  dIgPAXqneCWjrycuLJpvFwxEDQzYiT=dIgPAXqneCWjrycuLJpvFwxEDQzYia.callRequestCookies('Get',dIgPAXqneCWjrycuLJpvFwxEDQzYiH,payload=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,params=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,headers=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,cookies=dIgPAXqneCWjrycuLJpvFwxEDQzYKk)
  dIgPAXqneCWjrycuLJpvFwxEDQzYmb=json.loads(dIgPAXqneCWjrycuLJpvFwxEDQzYiT.text)
  for dIgPAXqneCWjrycuLJpvFwxEDQzYmV in dIgPAXqneCWjrycuLJpvFwxEDQzYmb:
   if dIgPAXqneCWjrycuLJpvFwxEDQzYKT(dIgPAXqneCWjrycuLJpvFwxEDQzYmV['type'])=='1' and dIgPAXqneCWjrycuLJpvFwxEDQzYKT(dIgPAXqneCWjrycuLJpvFwxEDQzYmV['destId'])=='4':
    for dIgPAXqneCWjrycuLJpvFwxEDQzYaO in dIgPAXqneCWjrycuLJpvFwxEDQzYmV['data']['list']:
     dIgPAXqneCWjrycuLJpvFwxEDQzYaG =dIgPAXqneCWjrycuLJpvFwxEDQzYaO['title']
     dIgPAXqneCWjrycuLJpvFwxEDQzYaR =dIgPAXqneCWjrycuLJpvFwxEDQzYaO['id']
     dIgPAXqneCWjrycuLJpvFwxEDQzYao =dIgPAXqneCWjrycuLJpvFwxEDQzYaO['vtype']
     dIgPAXqneCWjrycuLJpvFwxEDQzYah =dIgPAXqneCWjrycuLJpvFwxEDQzYaO['imgUrl']
     dIgPAXqneCWjrycuLJpvFwxEDQzYaB =dIgPAXqneCWjrycuLJpvFwxEDQzYaO['vtypeId']
     dIgPAXqneCWjrycuLJpvFwxEDQzYml={'vodTitle':dIgPAXqneCWjrycuLJpvFwxEDQzYaG,'vodId':dIgPAXqneCWjrycuLJpvFwxEDQzYaR,'vodType':dIgPAXqneCWjrycuLJpvFwxEDQzYao,'thumbnail':dIgPAXqneCWjrycuLJpvFwxEDQzYah,'vtypeId':dIgPAXqneCWjrycuLJpvFwxEDQzYKT(dIgPAXqneCWjrycuLJpvFwxEDQzYaB),'duration':dIgPAXqneCWjrycuLJpvFwxEDQzYKl(dIgPAXqneCWjrycuLJpvFwxEDQzYaO['duration']/1000),}
     dIgPAXqneCWjrycuLJpvFwxEDQzYmT.append(dIgPAXqneCWjrycuLJpvFwxEDQzYml)
  return dIgPAXqneCWjrycuLJpvFwxEDQzYmT
 def Get_NowVod_GroupList(dIgPAXqneCWjrycuLJpvFwxEDQzYia,page_int):
  dIgPAXqneCWjrycuLJpvFwxEDQzYmT=[]
  dIgPAXqneCWjrycuLJpvFwxEDQzYat=dIgPAXqneCWjrycuLJpvFwxEDQzYKH
  dIgPAXqneCWjrycuLJpvFwxEDQzYiH=dIgPAXqneCWjrycuLJpvFwxEDQzYia.API_DOMAIN+'/api/v3/theme/14/list'
  dIgPAXqneCWjrycuLJpvFwxEDQzYaU={'pageItem':'10','pageNo':dIgPAXqneCWjrycuLJpvFwxEDQzYKT(page_int)}
  dIgPAXqneCWjrycuLJpvFwxEDQzYiT=dIgPAXqneCWjrycuLJpvFwxEDQzYia.callRequestCookies('Get',dIgPAXqneCWjrycuLJpvFwxEDQzYiH,payload=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,params=dIgPAXqneCWjrycuLJpvFwxEDQzYaU,headers=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,cookies=dIgPAXqneCWjrycuLJpvFwxEDQzYKk)
  dIgPAXqneCWjrycuLJpvFwxEDQzYmb=json.loads(dIgPAXqneCWjrycuLJpvFwxEDQzYiT.text)
  for dIgPAXqneCWjrycuLJpvFwxEDQzYmV in dIgPAXqneCWjrycuLJpvFwxEDQzYmb['list']:
   dIgPAXqneCWjrycuLJpvFwxEDQzYaG =dIgPAXqneCWjrycuLJpvFwxEDQzYmV['title']
   dIgPAXqneCWjrycuLJpvFwxEDQzYaR =dIgPAXqneCWjrycuLJpvFwxEDQzYmV['id']
   dIgPAXqneCWjrycuLJpvFwxEDQzYao =dIgPAXqneCWjrycuLJpvFwxEDQzYmV['vtype']
   dIgPAXqneCWjrycuLJpvFwxEDQzYah =dIgPAXqneCWjrycuLJpvFwxEDQzYmV['imgUrl']
   dIgPAXqneCWjrycuLJpvFwxEDQzYaB =dIgPAXqneCWjrycuLJpvFwxEDQzYmV['vtypeId']
   dIgPAXqneCWjrycuLJpvFwxEDQzYml={'vodTitle':dIgPAXqneCWjrycuLJpvFwxEDQzYaG,'vodId':dIgPAXqneCWjrycuLJpvFwxEDQzYaR,'vodType':dIgPAXqneCWjrycuLJpvFwxEDQzYao,'thumbnail':dIgPAXqneCWjrycuLJpvFwxEDQzYah,'vtypeId':dIgPAXqneCWjrycuLJpvFwxEDQzYKT(dIgPAXqneCWjrycuLJpvFwxEDQzYaB),'duration':dIgPAXqneCWjrycuLJpvFwxEDQzYKl(dIgPAXqneCWjrycuLJpvFwxEDQzYmV['duration']/1000),}
   dIgPAXqneCWjrycuLJpvFwxEDQzYmT.append(dIgPAXqneCWjrycuLJpvFwxEDQzYml)
   if dIgPAXqneCWjrycuLJpvFwxEDQzYmb['count']>page_int*dIgPAXqneCWjrycuLJpvFwxEDQzYia.GAMELIST_LIMIT:dIgPAXqneCWjrycuLJpvFwxEDQzYat=dIgPAXqneCWjrycuLJpvFwxEDQzYKV
  return dIgPAXqneCWjrycuLJpvFwxEDQzYmT,dIgPAXqneCWjrycuLJpvFwxEDQzYat
 def GetSeasonList(dIgPAXqneCWjrycuLJpvFwxEDQzYia,leagueId):
  dIgPAXqneCWjrycuLJpvFwxEDQzYmT=[]
  dIgPAXqneCWjrycuLJpvFwxEDQzYak=dIgPAXqneCWjrycuLJpvFwxEDQzYaH=''
  try:
   dIgPAXqneCWjrycuLJpvFwxEDQzYiH=dIgPAXqneCWjrycuLJpvFwxEDQzYia.API_DOMAIN+'/api/v3/game/league/'+leagueId
   dIgPAXqneCWjrycuLJpvFwxEDQzYiT=dIgPAXqneCWjrycuLJpvFwxEDQzYia.callRequestCookies('Get',dIgPAXqneCWjrycuLJpvFwxEDQzYiH,payload=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,params=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,headers=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,cookies=dIgPAXqneCWjrycuLJpvFwxEDQzYKk)
   dIgPAXqneCWjrycuLJpvFwxEDQzYmb=json.loads(dIgPAXqneCWjrycuLJpvFwxEDQzYiT.text)
   dIgPAXqneCWjrycuLJpvFwxEDQzYak=dIgPAXqneCWjrycuLJpvFwxEDQzYmb['name']
   dIgPAXqneCWjrycuLJpvFwxEDQzYaH=dIgPAXqneCWjrycuLJpvFwxEDQzYKT(dIgPAXqneCWjrycuLJpvFwxEDQzYmb['gameTypeId'])
  except dIgPAXqneCWjrycuLJpvFwxEDQzYKs as exception:
   dIgPAXqneCWjrycuLJpvFwxEDQzYbi(exception)
   return dIgPAXqneCWjrycuLJpvFwxEDQzYmT
  if dIgPAXqneCWjrycuLJpvFwxEDQzYaH in['2','5','6','8']:
   try:
    dIgPAXqneCWjrycuLJpvFwxEDQzYiH=dIgPAXqneCWjrycuLJpvFwxEDQzYia.API_DOMAIN+'/api/v3/year/'+leagueId
    dIgPAXqneCWjrycuLJpvFwxEDQzYiT=dIgPAXqneCWjrycuLJpvFwxEDQzYia.callRequestCookies('Get',dIgPAXqneCWjrycuLJpvFwxEDQzYiH,payload=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,params=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,headers=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,cookies=dIgPAXqneCWjrycuLJpvFwxEDQzYKk)
    dIgPAXqneCWjrycuLJpvFwxEDQzYmb=json.loads(dIgPAXqneCWjrycuLJpvFwxEDQzYiT.text)
    for dIgPAXqneCWjrycuLJpvFwxEDQzYmV in dIgPAXqneCWjrycuLJpvFwxEDQzYmb:
     dIgPAXqneCWjrycuLJpvFwxEDQzYml={'reagueName':dIgPAXqneCWjrycuLJpvFwxEDQzYak,'gameTypeId':dIgPAXqneCWjrycuLJpvFwxEDQzYaH,'seasonName':dIgPAXqneCWjrycuLJpvFwxEDQzYKT(dIgPAXqneCWjrycuLJpvFwxEDQzYmV),'seasonId':dIgPAXqneCWjrycuLJpvFwxEDQzYKT(dIgPAXqneCWjrycuLJpvFwxEDQzYmV)}
     dIgPAXqneCWjrycuLJpvFwxEDQzYmT.append(dIgPAXqneCWjrycuLJpvFwxEDQzYml)
   except dIgPAXqneCWjrycuLJpvFwxEDQzYKs as exception:
    dIgPAXqneCWjrycuLJpvFwxEDQzYbi(exception)
    return[]
  else:
   try:
    dIgPAXqneCWjrycuLJpvFwxEDQzYiH=dIgPAXqneCWjrycuLJpvFwxEDQzYia.API_DOMAIN+'/api/v3/season/'+leagueId
    dIgPAXqneCWjrycuLJpvFwxEDQzYiT=dIgPAXqneCWjrycuLJpvFwxEDQzYia.callRequestCookies('Get',dIgPAXqneCWjrycuLJpvFwxEDQzYiH,payload=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,params=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,headers=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,cookies=dIgPAXqneCWjrycuLJpvFwxEDQzYKk)
    dIgPAXqneCWjrycuLJpvFwxEDQzYmb=json.loads(dIgPAXqneCWjrycuLJpvFwxEDQzYiT.text)
    for dIgPAXqneCWjrycuLJpvFwxEDQzYmV in dIgPAXqneCWjrycuLJpvFwxEDQzYmb:
     dIgPAXqneCWjrycuLJpvFwxEDQzYml={'reagueName':dIgPAXqneCWjrycuLJpvFwxEDQzYak,'gameTypeId':dIgPAXqneCWjrycuLJpvFwxEDQzYaH,'seasonName':dIgPAXqneCWjrycuLJpvFwxEDQzYmV['name'],'seasonId':dIgPAXqneCWjrycuLJpvFwxEDQzYKT(dIgPAXqneCWjrycuLJpvFwxEDQzYmV['id'])}
     dIgPAXqneCWjrycuLJpvFwxEDQzYmT.append(dIgPAXqneCWjrycuLJpvFwxEDQzYml)
   except dIgPAXqneCWjrycuLJpvFwxEDQzYKs as exception:
    dIgPAXqneCWjrycuLJpvFwxEDQzYbi(exception)
    return[]
  return dIgPAXqneCWjrycuLJpvFwxEDQzYmT
 def GetGameList(dIgPAXqneCWjrycuLJpvFwxEDQzYia,dIgPAXqneCWjrycuLJpvFwxEDQzYaH,leagueId,seasonId,page_int,hidescore=dIgPAXqneCWjrycuLJpvFwxEDQzYKV):
  dIgPAXqneCWjrycuLJpvFwxEDQzYmT=[]
  dIgPAXqneCWjrycuLJpvFwxEDQzYat=dIgPAXqneCWjrycuLJpvFwxEDQzYKH
  try:
   dIgPAXqneCWjrycuLJpvFwxEDQzYiH=dIgPAXqneCWjrycuLJpvFwxEDQzYia.API_DOMAIN+'/api/v3/vod/league/detail'
   dIgPAXqneCWjrycuLJpvFwxEDQzYaU={'gameType':dIgPAXqneCWjrycuLJpvFwxEDQzYaH,'leagueId':leagueId,'seasonId':seasonId if dIgPAXqneCWjrycuLJpvFwxEDQzYaH not in['2','5','6','8']else '','teamId':'','roundId':'','year':'' if dIgPAXqneCWjrycuLJpvFwxEDQzYaH not in['2','5','6','8']else seasonId,'pageNo':dIgPAXqneCWjrycuLJpvFwxEDQzYKT(page_int)}
   dIgPAXqneCWjrycuLJpvFwxEDQzYiT=dIgPAXqneCWjrycuLJpvFwxEDQzYia.callRequestCookies('Get',dIgPAXqneCWjrycuLJpvFwxEDQzYiH,payload=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,params=dIgPAXqneCWjrycuLJpvFwxEDQzYaU,headers=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,cookies=dIgPAXqneCWjrycuLJpvFwxEDQzYKk)
   dIgPAXqneCWjrycuLJpvFwxEDQzYmb=json.loads(dIgPAXqneCWjrycuLJpvFwxEDQzYiT.text)
   dIgPAXqneCWjrycuLJpvFwxEDQzYST=dIgPAXqneCWjrycuLJpvFwxEDQzYmb['list']
   for dIgPAXqneCWjrycuLJpvFwxEDQzYaT in dIgPAXqneCWjrycuLJpvFwxEDQzYST:
    for dIgPAXqneCWjrycuLJpvFwxEDQzYmV in dIgPAXqneCWjrycuLJpvFwxEDQzYaT['list']:
     if dIgPAXqneCWjrycuLJpvFwxEDQzYmV['gameDesc']['title']==dIgPAXqneCWjrycuLJpvFwxEDQzYKk or dIgPAXqneCWjrycuLJpvFwxEDQzYmV['gameDesc']['title']=='':
      dIgPAXqneCWjrycuLJpvFwxEDQzYSN ='%s vs %s'%(dIgPAXqneCWjrycuLJpvFwxEDQzYmV['gameDesc']['homeNameShort'],dIgPAXqneCWjrycuLJpvFwxEDQzYmV['gameDesc']['awayNameShort'])
     else:
      dIgPAXqneCWjrycuLJpvFwxEDQzYSN =dIgPAXqneCWjrycuLJpvFwxEDQzYmV['gameDesc']['title']
     dIgPAXqneCWjrycuLJpvFwxEDQzYaN =dIgPAXqneCWjrycuLJpvFwxEDQzYmV['gameDesc']['beginDate']
     dIgPAXqneCWjrycuLJpvFwxEDQzYaV =dIgPAXqneCWjrycuLJpvFwxEDQzYmV['gameDesc']['id']
     dIgPAXqneCWjrycuLJpvFwxEDQzYal =dIgPAXqneCWjrycuLJpvFwxEDQzYmV['gameDesc']['leagueNameFull']
     dIgPAXqneCWjrycuLJpvFwxEDQzYas =dIgPAXqneCWjrycuLJpvFwxEDQzYmV['gameDesc']['seasonName']
     dIgPAXqneCWjrycuLJpvFwxEDQzYKi =dIgPAXqneCWjrycuLJpvFwxEDQzYmV['gameDesc']['roundName']
     dIgPAXqneCWjrycuLJpvFwxEDQzYKm =dIgPAXqneCWjrycuLJpvFwxEDQzYmV['gameDesc']['homeName']
     dIgPAXqneCWjrycuLJpvFwxEDQzYKS =dIgPAXqneCWjrycuLJpvFwxEDQzYmV['gameDesc']['awayName']
     dIgPAXqneCWjrycuLJpvFwxEDQzYKa =dIgPAXqneCWjrycuLJpvFwxEDQzYmV['gameDesc']['homeScore']
     dIgPAXqneCWjrycuLJpvFwxEDQzYKb =dIgPAXqneCWjrycuLJpvFwxEDQzYmV['gameDesc']['awayScore']
     if hidescore==dIgPAXqneCWjrycuLJpvFwxEDQzYKV:
      dIgPAXqneCWjrycuLJpvFwxEDQzYKM ='%s\n - %s (%s)\n - %s\n\nhome : %s\n\naway : %s'%(dIgPAXqneCWjrycuLJpvFwxEDQzYal,dIgPAXqneCWjrycuLJpvFwxEDQzYas,dIgPAXqneCWjrycuLJpvFwxEDQzYKi,dIgPAXqneCWjrycuLJpvFwxEDQzYaN,dIgPAXqneCWjrycuLJpvFwxEDQzYKm,dIgPAXqneCWjrycuLJpvFwxEDQzYKS)
     else:
      dIgPAXqneCWjrycuLJpvFwxEDQzYKM ='%s\n - %s (%s)\n - %s\n\nhome : %s (Score %s)\n\naway : %s (Score %s)'%(dIgPAXqneCWjrycuLJpvFwxEDQzYal,dIgPAXqneCWjrycuLJpvFwxEDQzYas,dIgPAXqneCWjrycuLJpvFwxEDQzYKi,dIgPAXqneCWjrycuLJpvFwxEDQzYaN,dIgPAXqneCWjrycuLJpvFwxEDQzYKm,dIgPAXqneCWjrycuLJpvFwxEDQzYKa,dIgPAXqneCWjrycuLJpvFwxEDQzYKS,dIgPAXqneCWjrycuLJpvFwxEDQzYKb)
     dIgPAXqneCWjrycuLJpvFwxEDQzYKO=dIgPAXqneCWjrycuLJpvFwxEDQzYKM
     dIgPAXqneCWjrycuLJpvFwxEDQzYKf =dIgPAXqneCWjrycuLJpvFwxEDQzYmV['replayVod']['count']
     dIgPAXqneCWjrycuLJpvFwxEDQzYKG=dIgPAXqneCWjrycuLJpvFwxEDQzYmV['highlightVod']['count']
     dIgPAXqneCWjrycuLJpvFwxEDQzYKR =dIgPAXqneCWjrycuLJpvFwxEDQzYmV['vods']['count']
     dIgPAXqneCWjrycuLJpvFwxEDQzYah='' 
     dIgPAXqneCWjrycuLJpvFwxEDQzYKo=dIgPAXqneCWjrycuLJpvFwxEDQzYKf+dIgPAXqneCWjrycuLJpvFwxEDQzYKG+dIgPAXqneCWjrycuLJpvFwxEDQzYKR
     if dIgPAXqneCWjrycuLJpvFwxEDQzYKo==0:
      if dIgPAXqneCWjrycuLJpvFwxEDQzYaH=='2':
       dIgPAXqneCWjrycuLJpvFwxEDQzYSN='----- %s -----'%(dIgPAXqneCWjrycuLJpvFwxEDQzYas)
       dIgPAXqneCWjrycuLJpvFwxEDQzYaN=''
      else:
       dIgPAXqneCWjrycuLJpvFwxEDQzYSN+=' - 관련영상 없음'
       dIgPAXqneCWjrycuLJpvFwxEDQzYKO+='\n\n ** 관련영상 없음 **'
     else:
      if dIgPAXqneCWjrycuLJpvFwxEDQzYKf!=0:
       dIgPAXqneCWjrycuLJpvFwxEDQzYah =dIgPAXqneCWjrycuLJpvFwxEDQzYmV['replayVod']['list'][0]['imgUrl']
      elif dIgPAXqneCWjrycuLJpvFwxEDQzYKG!=0:
       dIgPAXqneCWjrycuLJpvFwxEDQzYah =dIgPAXqneCWjrycuLJpvFwxEDQzYmV['highlightVod']['list'][0]['imgUrl']
      else:
       dIgPAXqneCWjrycuLJpvFwxEDQzYah =dIgPAXqneCWjrycuLJpvFwxEDQzYmV['vods']['list'][0]['imgUrl']
     dIgPAXqneCWjrycuLJpvFwxEDQzYml={'gameTitle':dIgPAXqneCWjrycuLJpvFwxEDQzYSN,'gameId':dIgPAXqneCWjrycuLJpvFwxEDQzYaV,'beginDate':dIgPAXqneCWjrycuLJpvFwxEDQzYaN[:11],'thumbnail':dIgPAXqneCWjrycuLJpvFwxEDQzYah,'info_plot':dIgPAXqneCWjrycuLJpvFwxEDQzYKO,'leaguenm':dIgPAXqneCWjrycuLJpvFwxEDQzYal,'seasonnm':dIgPAXqneCWjrycuLJpvFwxEDQzYas,'roundnm':dIgPAXqneCWjrycuLJpvFwxEDQzYKi,'totVodCnt':dIgPAXqneCWjrycuLJpvFwxEDQzYKo}
     dIgPAXqneCWjrycuLJpvFwxEDQzYmT.append(dIgPAXqneCWjrycuLJpvFwxEDQzYml)
  except dIgPAXqneCWjrycuLJpvFwxEDQzYKs as exception:
   dIgPAXqneCWjrycuLJpvFwxEDQzYbi(exception)
  if dIgPAXqneCWjrycuLJpvFwxEDQzYmb['count']>page_int*dIgPAXqneCWjrycuLJpvFwxEDQzYia.GAMELIST_LIMIT:dIgPAXqneCWjrycuLJpvFwxEDQzYat=dIgPAXqneCWjrycuLJpvFwxEDQzYKV
  return dIgPAXqneCWjrycuLJpvFwxEDQzYmT,dIgPAXqneCWjrycuLJpvFwxEDQzYat
 def GetGameVodList(dIgPAXqneCWjrycuLJpvFwxEDQzYia,dIgPAXqneCWjrycuLJpvFwxEDQzYaV,vodCount=1000):
  dIgPAXqneCWjrycuLJpvFwxEDQzYmT=[]
  dIgPAXqneCWjrycuLJpvFwxEDQzYKh=''
  try:
   dIgPAXqneCWjrycuLJpvFwxEDQzYiH=dIgPAXqneCWjrycuLJpvFwxEDQzYia.API_DOMAIN+'/api/v3/vod/game'
   dIgPAXqneCWjrycuLJpvFwxEDQzYaU={'gameId':dIgPAXqneCWjrycuLJpvFwxEDQzYaV,'pageItem':dIgPAXqneCWjrycuLJpvFwxEDQzYKT(vodCount)}
   dIgPAXqneCWjrycuLJpvFwxEDQzYiT=dIgPAXqneCWjrycuLJpvFwxEDQzYia.callRequestCookies('Get',dIgPAXqneCWjrycuLJpvFwxEDQzYiH,payload=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,params=dIgPAXqneCWjrycuLJpvFwxEDQzYaU,headers=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,cookies=dIgPAXqneCWjrycuLJpvFwxEDQzYKk)
   dIgPAXqneCWjrycuLJpvFwxEDQzYmb=json.loads(dIgPAXqneCWjrycuLJpvFwxEDQzYiT.text)
   dIgPAXqneCWjrycuLJpvFwxEDQzYaT=dIgPAXqneCWjrycuLJpvFwxEDQzYmb['list']
   for dIgPAXqneCWjrycuLJpvFwxEDQzYmV in dIgPAXqneCWjrycuLJpvFwxEDQzYaT:
    dIgPAXqneCWjrycuLJpvFwxEDQzYaG =dIgPAXqneCWjrycuLJpvFwxEDQzYmV['title']
    dIgPAXqneCWjrycuLJpvFwxEDQzYaR =dIgPAXqneCWjrycuLJpvFwxEDQzYmV['id']
    dIgPAXqneCWjrycuLJpvFwxEDQzYao =dIgPAXqneCWjrycuLJpvFwxEDQzYmV['vtype']
    dIgPAXqneCWjrycuLJpvFwxEDQzYah =dIgPAXqneCWjrycuLJpvFwxEDQzYmV['imgUrl']
    dIgPAXqneCWjrycuLJpvFwxEDQzYaB =dIgPAXqneCWjrycuLJpvFwxEDQzYmV['vtypeId']
    dIgPAXqneCWjrycuLJpvFwxEDQzYKB =dIgPAXqneCWjrycuLJpvFwxEDQzYmV['isFree']
    dIgPAXqneCWjrycuLJpvFwxEDQzYml={'vodTitle':dIgPAXqneCWjrycuLJpvFwxEDQzYaG,'vodId':dIgPAXqneCWjrycuLJpvFwxEDQzYaR,'vodType':dIgPAXqneCWjrycuLJpvFwxEDQzYao,'thumbnail':dIgPAXqneCWjrycuLJpvFwxEDQzYah,'vtypeId':dIgPAXqneCWjrycuLJpvFwxEDQzYKT(dIgPAXqneCWjrycuLJpvFwxEDQzYaB),'duration':dIgPAXqneCWjrycuLJpvFwxEDQzYKl(dIgPAXqneCWjrycuLJpvFwxEDQzYmV['duration']/1000),'isFree':dIgPAXqneCWjrycuLJpvFwxEDQzYKB}
    dIgPAXqneCWjrycuLJpvFwxEDQzYmT.append(dIgPAXqneCWjrycuLJpvFwxEDQzYml)
  except dIgPAXqneCWjrycuLJpvFwxEDQzYKs as exception:
   dIgPAXqneCWjrycuLJpvFwxEDQzYbi(exception)
  return dIgPAXqneCWjrycuLJpvFwxEDQzYmT
 def GetReplay_UrlId(dIgPAXqneCWjrycuLJpvFwxEDQzYia,dIgPAXqneCWjrycuLJpvFwxEDQzYKh,dIgPAXqneCWjrycuLJpvFwxEDQzYaB):
  dIgPAXqneCWjrycuLJpvFwxEDQzYKt=''
  try:
   dIgPAXqneCWjrycuLJpvFwxEDQzYiH=dIgPAXqneCWjrycuLJpvFwxEDQzYia.API_DOMAIN+'/api/v3/vod/'+dIgPAXqneCWjrycuLJpvFwxEDQzYKh
   dIgPAXqneCWjrycuLJpvFwxEDQzYiT=dIgPAXqneCWjrycuLJpvFwxEDQzYia.callRequestCookies('Get',dIgPAXqneCWjrycuLJpvFwxEDQzYiH,payload=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,params=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,headers=dIgPAXqneCWjrycuLJpvFwxEDQzYKk,cookies=dIgPAXqneCWjrycuLJpvFwxEDQzYKk)
   dIgPAXqneCWjrycuLJpvFwxEDQzYmb=json.loads(dIgPAXqneCWjrycuLJpvFwxEDQzYiT.text)
   dIgPAXqneCWjrycuLJpvFwxEDQzYKt=dIgPAXqneCWjrycuLJpvFwxEDQzYmb['videoId']
  except dIgPAXqneCWjrycuLJpvFwxEDQzYKs as exception:
   dIgPAXqneCWjrycuLJpvFwxEDQzYbi(exception)
  return dIgPAXqneCWjrycuLJpvFwxEDQzYKt
# Created by pyminifier (https://github.com/liftoff/pyminifier)
