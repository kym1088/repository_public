__author__="NightRain"
vABSxhMgIqtWcfaCYiGLjXepbkKNPm=False
vABSxhMgIqtWcfaCYiGLjXepbkKNPU=object
vABSxhMgIqtWcfaCYiGLjXepbkKNPD=None
vABSxhMgIqtWcfaCYiGLjXepbkKNPs=print
vABSxhMgIqtWcfaCYiGLjXepbkKNPT=str
vABSxhMgIqtWcfaCYiGLjXepbkKNPr=True
vABSxhMgIqtWcfaCYiGLjXepbkKNPn=Exception
vABSxhMgIqtWcfaCYiGLjXepbkKNPQ=int
vABSxhMgIqtWcfaCYiGLjXepbkKNPE=len
vABSxhMgIqtWcfaCYiGLjXepbkKNPl=range
import urllib
import http.cookiejar 
import re
import json
import sys
import time
import requests
import datetime
import base64
vABSxhMgIqtWcfaCYiGLjXepbkKNdz={'stream50':1080,'stream40':720,'stream30':540}
vABSxhMgIqtWcfaCYiGLjXepbkKNdV=[{'name':'NOW','videoId':'ch_spotvnow1','epgtype':'spotvon','epgnm':'spotvon','free':vABSxhMgIqtWcfaCYiGLjXepbkKNPm,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/ccdb36ce757afc1ca15fc38357d498e4.png'},{'name':'NOW2','videoId':'ch_spotvnow2','epgtype':'spotvon','epgnm':'spotvon2','free':vABSxhMgIqtWcfaCYiGLjXepbkKNPm,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/8b6bdf6213a715eeba719b2cb9b2c747.png'},{'name':'NBA TV','videoId':'ch_nbatv','epgtype':'-','epgnm':'-','free':vABSxhMgIqtWcfaCYiGLjXepbkKNPm,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/5036e56d5c6594ea606f7159f59779fe.png'},{'name':'SPOTV','videoId':'ch_spotv','epgtype':'spotvnet','epgnm':'SPOTV','free':vABSxhMgIqtWcfaCYiGLjXepbkKNPm,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/56688c2e527c6e1b8d68e338057a7dfc.png'},{'name':'SPOTV2','videoId':'ch_spotv2','epgtype':'spotvnet','epgnm':'SPOTV2','free':vABSxhMgIqtWcfaCYiGLjXepbkKNPm,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20201209/ca6e7a213c84e629985e609ddcda6b17.png'},{'name':'SPOTV Golf & Health','videoId':'ch_spotvplus','epgtype':'spotvnet','epgnm':'SPOTVP','free':vABSxhMgIqtWcfaCYiGLjXepbkKNPm,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/7aa87953f1211313c3e110cace2628ff.png'},]
vABSxhMgIqtWcfaCYiGLjXepbkKNdP={'ch_spotvnow1':{'lv':'abf18bbf3b3f4a0db4a41dd2af7f75c6','rv':'__nn__=5981484117001&hdnea=st=1609407000~exp=1609410600~acl=/abf18bbf3b3f4a0db4a41dd2af7f75c6/ap-northeast-1/5764318566001/*~hmac=e28a244d1b6b77d4e0101010816d4cd6ca89d9d31fe6a5290039d2395d81bc03'},'ch_spotvnow2':{'lv':'3054522000fc4d60aabe23d6e5911275','rv':'__nn__=5981484117001&hdnea=st=1609408800~exp=1609412400~acl=/3054522000fc4d60aabe23d6e5911275/ap-northeast-1/5764318566001/*~hmac=323b2deea8e3455fa77405f37b19231c6f0b48a5690b7218df875171ac2d6be6'},'ch_nbatv':{'lv':'31f99a0a6067413ea1b390c41a5c12be','rv':'__nn__=5981484117001&hdnea=st=1609408800~exp=1609412400~acl=/31f99a0a6067413ea1b390c41a5c12be/ap-northeast-1/5764318566001/*~hmac=b7ac24bc4772e3ad2669000919058bba64a6f001c69c8846341c326b089c306c'},'ch_spotv':{'lv':'1f2651c2fea34be9850bfdedf8d9cfdb','rv':'__nn__=5981484117001&hdnea=st=1609408800~exp=1609412400~acl=/1f2651c2fea34be9850bfdedf8d9cfdb/ap-northeast-1/5764318566001/*~hmac=e1f6c44d1be5459cfc40af1e1b204ac9b513bb7405e070da2bff8f115f298133'},'ch_spotv2':{'lv':'7bf3fb8685854892b01e1fc897e7e9b0','rv':'__nn__=5981484117001&hdnea=st=1609408800~exp=1609412400~acl=/7bf3fb8685854892b01e1fc897e7e9b0/ap-northeast-1/5764318566001/*~hmac=e9bb30991cfab98b1976aacabafcd51b63769ede40148f7cc289ffed15398e81'},'ch_spotvplus':{'lv':'242b2b6c0c654f47a07f4e2420f9c184','rv':'__nn__=5981484117001&hdnea=st=1609408800~exp=1609412400~acl=/242b2b6c0c654f47a07f4e2420f9c184/ap-northeast-1/5764318566001/*~hmac=5e4ce0553e709eb60d880bf37bc2e99661767b0a38ecee037fb4d7dce757b922'},}
class vABSxhMgIqtWcfaCYiGLjXepbkKNdw(vABSxhMgIqtWcfaCYiGLjXepbkKNPU):
 def __init__(vABSxhMgIqtWcfaCYiGLjXepbkKNdF):
  vABSxhMgIqtWcfaCYiGLjXepbkKNdF.SPOTV_SESSIONID=''
  vABSxhMgIqtWcfaCYiGLjXepbkKNdF.SPOTV_SESSION =''
  vABSxhMgIqtWcfaCYiGLjXepbkKNdF.SPOTV_ACCOUNTID=''
  vABSxhMgIqtWcfaCYiGLjXepbkKNdF.SPOTV_POLICYKEY=''
  vABSxhMgIqtWcfaCYiGLjXepbkKNdF.SPOTV_SUBEND =''
  vABSxhMgIqtWcfaCYiGLjXepbkKNdF.SPOTV_PMCODE ='987'
  vABSxhMgIqtWcfaCYiGLjXepbkKNdF.SPOTV_PMSIZE =3
  vABSxhMgIqtWcfaCYiGLjXepbkKNdF.GAMELIST_LIMIT =10
  vABSxhMgIqtWcfaCYiGLjXepbkKNdF.API_DOMAIN ='https://www.spotvnow.co.kr'
  vABSxhMgIqtWcfaCYiGLjXepbkKNdF.BC_DOMAIN ='https://players.brightcove.net'
  vABSxhMgIqtWcfaCYiGLjXepbkKNdF.PLAYER_DOMAIN ='https://edge.api.brightcove.com'
  vABSxhMgIqtWcfaCYiGLjXepbkKNdF.STREAM_DOMAIN ='https://gtm-spotv.brightcovecdn.com'
  vABSxhMgIqtWcfaCYiGLjXepbkKNdF.STREAM_M3U8 ='ap-northeast-1/5764318566001/playlist_dvr'
  vABSxhMgIqtWcfaCYiGLjXepbkKNdF.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36'
  vABSxhMgIqtWcfaCYiGLjXepbkKNdF.DEFAULT_HEADER ={'user-agent':vABSxhMgIqtWcfaCYiGLjXepbkKNdF.USER_AGENT}
 def callRequestCookies(vABSxhMgIqtWcfaCYiGLjXepbkKNdF,jobtype,vABSxhMgIqtWcfaCYiGLjXepbkKNwR,payload=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,params=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,headers=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,cookies=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,redirects=vABSxhMgIqtWcfaCYiGLjXepbkKNPm):
  vABSxhMgIqtWcfaCYiGLjXepbkKNdJ=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.DEFAULT_HEADER
  if headers:vABSxhMgIqtWcfaCYiGLjXepbkKNdJ.update(headers)
  if jobtype=='Get':
   vABSxhMgIqtWcfaCYiGLjXepbkKNdy=requests.get(vABSxhMgIqtWcfaCYiGLjXepbkKNwR,params=params,headers=vABSxhMgIqtWcfaCYiGLjXepbkKNdJ,cookies=cookies,allow_redirects=redirects)
  else:
   vABSxhMgIqtWcfaCYiGLjXepbkKNdy=requests.post(vABSxhMgIqtWcfaCYiGLjXepbkKNwR,data=payload,params=params,headers=vABSxhMgIqtWcfaCYiGLjXepbkKNdJ,cookies=cookies,allow_redirects=redirects)
  return vABSxhMgIqtWcfaCYiGLjXepbkKNdy
 def makeDefaultCookies(vABSxhMgIqtWcfaCYiGLjXepbkKNdF):
  vABSxhMgIqtWcfaCYiGLjXepbkKNdR={'SESSION':vABSxhMgIqtWcfaCYiGLjXepbkKNdF.SPOTV_SESSION}
  return vABSxhMgIqtWcfaCYiGLjXepbkKNdR
 def xmlText(vABSxhMgIqtWcfaCYiGLjXepbkKNdF,in_text):
  vABSxhMgIqtWcfaCYiGLjXepbkKNdO=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;')
  return vABSxhMgIqtWcfaCYiGLjXepbkKNdO
 def GetCredential(vABSxhMgIqtWcfaCYiGLjXepbkKNdF,user_id,user_pw):
  vABSxhMgIqtWcfaCYiGLjXepbkKNdH=vABSxhMgIqtWcfaCYiGLjXepbkKNPm
  vABSxhMgIqtWcfaCYiGLjXepbkKNdo=vABSxhMgIqtWcfaCYiGLjXepbkKNdr=vABSxhMgIqtWcfaCYiGLjXepbkKNdE=vABSxhMgIqtWcfaCYiGLjXepbkKNdl=vABSxhMgIqtWcfaCYiGLjXepbkKNdQ=''
  try:
   vABSxhMgIqtWcfaCYiGLjXepbkKNdu=base64.standard_b64encode(user_id.encode("UTF-8")).decode('utf-8')
   vABSxhMgIqtWcfaCYiGLjXepbkKNdm=base64.standard_b64encode(user_pw.encode("UTF-8")).decode('utf-8')
   vABSxhMgIqtWcfaCYiGLjXepbkKNdU=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.API_DOMAIN+'/api/v2/login'
   vABSxhMgIqtWcfaCYiGLjXepbkKNdD={'username':vABSxhMgIqtWcfaCYiGLjXepbkKNdu,'password':vABSxhMgIqtWcfaCYiGLjXepbkKNdm}
   vABSxhMgIqtWcfaCYiGLjXepbkKNdD=json.dumps(vABSxhMgIqtWcfaCYiGLjXepbkKNdD)
   vABSxhMgIqtWcfaCYiGLjXepbkKNds=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.callRequestCookies('Post',vABSxhMgIqtWcfaCYiGLjXepbkKNdU,payload=vABSxhMgIqtWcfaCYiGLjXepbkKNdD,params=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,headers=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,cookies=vABSxhMgIqtWcfaCYiGLjXepbkKNPD)
   vABSxhMgIqtWcfaCYiGLjXepbkKNPs(vABSxhMgIqtWcfaCYiGLjXepbkKNds.status_code)
   for vABSxhMgIqtWcfaCYiGLjXepbkKNdT in vABSxhMgIqtWcfaCYiGLjXepbkKNds.cookies:
    if vABSxhMgIqtWcfaCYiGLjXepbkKNdT.name=='SESSION':
     vABSxhMgIqtWcfaCYiGLjXepbkKNdr=vABSxhMgIqtWcfaCYiGLjXepbkKNdT.value
     break
   if vABSxhMgIqtWcfaCYiGLjXepbkKNdr=='':return vABSxhMgIqtWcfaCYiGLjXepbkKNdH
   vABSxhMgIqtWcfaCYiGLjXepbkKNdn=json.loads(vABSxhMgIqtWcfaCYiGLjXepbkKNds.text)
   if not('userId' in vABSxhMgIqtWcfaCYiGLjXepbkKNdn):return vABSxhMgIqtWcfaCYiGLjXepbkKNdH
   vABSxhMgIqtWcfaCYiGLjXepbkKNdo=vABSxhMgIqtWcfaCYiGLjXepbkKNPT(vABSxhMgIqtWcfaCYiGLjXepbkKNdn['userId'])
   vABSxhMgIqtWcfaCYiGLjXepbkKNdQ =vABSxhMgIqtWcfaCYiGLjXepbkKNPT(vABSxhMgIqtWcfaCYiGLjXepbkKNdn['subEndTime'])
   vABSxhMgIqtWcfaCYiGLjXepbkKNdE,vABSxhMgIqtWcfaCYiGLjXepbkKNdl=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.GetPolicyKey()
   if vABSxhMgIqtWcfaCYiGLjXepbkKNdl=='':return vABSxhMgIqtWcfaCYiGLjXepbkKNdH
   vABSxhMgIqtWcfaCYiGLjXepbkKNdH=vABSxhMgIqtWcfaCYiGLjXepbkKNPr
  except vABSxhMgIqtWcfaCYiGLjXepbkKNPn as exception:
   vABSxhMgIqtWcfaCYiGLjXepbkKNdo=vABSxhMgIqtWcfaCYiGLjXepbkKNdr='' 
   vABSxhMgIqtWcfaCYiGLjXepbkKNPs(exception)
  vABSxhMgIqtWcfaCYiGLjXepbkKNwd={'spotv_sessionid':vABSxhMgIqtWcfaCYiGLjXepbkKNdo,'spotv_session':vABSxhMgIqtWcfaCYiGLjXepbkKNdr,'spotv_accountId':vABSxhMgIqtWcfaCYiGLjXepbkKNdE,'spotv_policyKey':vABSxhMgIqtWcfaCYiGLjXepbkKNdl,'spotv_subend':vABSxhMgIqtWcfaCYiGLjXepbkKNdQ}
  vABSxhMgIqtWcfaCYiGLjXepbkKNdF.SaveCredential(vABSxhMgIqtWcfaCYiGLjXepbkKNwd)
  return vABSxhMgIqtWcfaCYiGLjXepbkKNdH
 def SaveCredential(vABSxhMgIqtWcfaCYiGLjXepbkKNdF,vABSxhMgIqtWcfaCYiGLjXepbkKNwd):
  vABSxhMgIqtWcfaCYiGLjXepbkKNdF.SPOTV_SESSIONID=vABSxhMgIqtWcfaCYiGLjXepbkKNwd.get('spotv_sessionid')
  vABSxhMgIqtWcfaCYiGLjXepbkKNdF.SPOTV_SESSION =vABSxhMgIqtWcfaCYiGLjXepbkKNwd.get('spotv_session')
  vABSxhMgIqtWcfaCYiGLjXepbkKNdF.SPOTV_ACCOUNTID=vABSxhMgIqtWcfaCYiGLjXepbkKNwd.get('spotv_accountId')
  vABSxhMgIqtWcfaCYiGLjXepbkKNdF.SPOTV_POLICYKEY=vABSxhMgIqtWcfaCYiGLjXepbkKNwd.get('spotv_policyKey')
  vABSxhMgIqtWcfaCYiGLjXepbkKNdF.SPOTV_SUBEND =vABSxhMgIqtWcfaCYiGLjXepbkKNwd.get('spotv_subend')
 def LoadCredential(vABSxhMgIqtWcfaCYiGLjXepbkKNdF):
  vABSxhMgIqtWcfaCYiGLjXepbkKNwd={'spotv_sessionid':vABSxhMgIqtWcfaCYiGLjXepbkKNdF.SPOTV_SESSIONID,'spotv_session':vABSxhMgIqtWcfaCYiGLjXepbkKNdF.SPOTV_SESSION,'spotv_accountId':vABSxhMgIqtWcfaCYiGLjXepbkKNdF.SPOTV_ACCOUNTID,'spotv_policyKey':vABSxhMgIqtWcfaCYiGLjXepbkKNdF.SPOTV_POLICYKEY,'spotv_subend':vABSxhMgIqtWcfaCYiGLjXepbkKNdF.SPOTV_SUBEND}
  return vABSxhMgIqtWcfaCYiGLjXepbkKNwd
 def Get_Now_Datetime(vABSxhMgIqtWcfaCYiGLjXepbkKNdF):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_Streamurl_Make(vABSxhMgIqtWcfaCYiGLjXepbkKNdF,vABSxhMgIqtWcfaCYiGLjXepbkKNzy):
  vABSxhMgIqtWcfaCYiGLjXepbkKNwV='%s/%s/%s.m3u8?%s'%(vABSxhMgIqtWcfaCYiGLjXepbkKNdF.STREAM_DOMAIN,vABSxhMgIqtWcfaCYiGLjXepbkKNdP.get(vABSxhMgIqtWcfaCYiGLjXepbkKNzy).get('lv'),vABSxhMgIqtWcfaCYiGLjXepbkKNdF.STREAM_M3U8,vABSxhMgIqtWcfaCYiGLjXepbkKNdP.get(vABSxhMgIqtWcfaCYiGLjXepbkKNzy).get('rv'))
  return vABSxhMgIqtWcfaCYiGLjXepbkKNwV
 def GetLiveChannelList(vABSxhMgIqtWcfaCYiGLjXepbkKNdF):
  vABSxhMgIqtWcfaCYiGLjXepbkKNwP=[]
  vABSxhMgIqtWcfaCYiGLjXepbkKNwF ={}
  try:
   vABSxhMgIqtWcfaCYiGLjXepbkKNwF=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.GetEPGList_new()
   for vABSxhMgIqtWcfaCYiGLjXepbkKNwJ in vABSxhMgIqtWcfaCYiGLjXepbkKNdV:
    vABSxhMgIqtWcfaCYiGLjXepbkKNwy={'name':vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['name'],'logo':vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['logo'],'videoId':vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['videoId'],'free':vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['free'],'channelepg':vABSxhMgIqtWcfaCYiGLjXepbkKNwF.get(vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['videoId'])}
    vABSxhMgIqtWcfaCYiGLjXepbkKNwP.append(vABSxhMgIqtWcfaCYiGLjXepbkKNwy)
  except vABSxhMgIqtWcfaCYiGLjXepbkKNPn as exception:
   vABSxhMgIqtWcfaCYiGLjXepbkKNPs(exception)
  return vABSxhMgIqtWcfaCYiGLjXepbkKNwP
 def CheckLiveChannel(vABSxhMgIqtWcfaCYiGLjXepbkKNdF,vABSxhMgIqtWcfaCYiGLjXepbkKNwn):
  try:
   vABSxhMgIqtWcfaCYiGLjXepbkKNwR=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.API_DOMAIN+'/api/v2/channel'
   vABSxhMgIqtWcfaCYiGLjXepbkKNds=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.callRequestCookies('Get',vABSxhMgIqtWcfaCYiGLjXepbkKNwR,payload=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,params=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,headers=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,cookies=vABSxhMgIqtWcfaCYiGLjXepbkKNPD)
   vABSxhMgIqtWcfaCYiGLjXepbkKNdn=json.loads(vABSxhMgIqtWcfaCYiGLjXepbkKNds.text)
   for vABSxhMgIqtWcfaCYiGLjXepbkKNwJ in vABSxhMgIqtWcfaCYiGLjXepbkKNdn:
    if vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['videoId'].replace('ref:','')==vABSxhMgIqtWcfaCYiGLjXepbkKNwn:
     return vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['free']
  except vABSxhMgIqtWcfaCYiGLjXepbkKNPn as exception:
   vABSxhMgIqtWcfaCYiGLjXepbkKNPs(exception)
  return vABSxhMgIqtWcfaCYiGLjXepbkKNPm
 def GetEPGList(vABSxhMgIqtWcfaCYiGLjXepbkKNdF):
  vABSxhMgIqtWcfaCYiGLjXepbkKNwO={}
  vABSxhMgIqtWcfaCYiGLjXepbkKNwH=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.Get_Now_Datetime()
  vABSxhMgIqtWcfaCYiGLjXepbkKNwo=vABSxhMgIqtWcfaCYiGLjXepbkKNwH.strftime('%Y%m%d%H%M')
  vABSxhMgIqtWcfaCYiGLjXepbkKNwu='%s-%s-%s'%(vABSxhMgIqtWcfaCYiGLjXepbkKNwo[0:4],vABSxhMgIqtWcfaCYiGLjXepbkKNwo[4:6],vABSxhMgIqtWcfaCYiGLjXepbkKNwo[6:8])
  vABSxhMgIqtWcfaCYiGLjXepbkKNwm=(vABSxhMgIqtWcfaCYiGLjXepbkKNwH+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M')
  try:
   vABSxhMgIqtWcfaCYiGLjXepbkKNwR=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.API_DOMAIN+'/api/v2/program/'+vABSxhMgIqtWcfaCYiGLjXepbkKNwu
   vABSxhMgIqtWcfaCYiGLjXepbkKNds=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.callRequestCookies('Get',vABSxhMgIqtWcfaCYiGLjXepbkKNwR,payload=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,params=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,headers=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,cookies=vABSxhMgIqtWcfaCYiGLjXepbkKNPD)
   vABSxhMgIqtWcfaCYiGLjXepbkKNdn=json.loads(vABSxhMgIqtWcfaCYiGLjXepbkKNds.text)
   vABSxhMgIqtWcfaCYiGLjXepbkKNwU=-1 
   vABSxhMgIqtWcfaCYiGLjXepbkKNwD =''
   for vABSxhMgIqtWcfaCYiGLjXepbkKNwJ in vABSxhMgIqtWcfaCYiGLjXepbkKNdn:
    vABSxhMgIqtWcfaCYiGLjXepbkKNws=vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['channelId']
    vABSxhMgIqtWcfaCYiGLjXepbkKNwT =vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['startTime'].replace('-','').replace(' ','').replace(':','')
    vABSxhMgIqtWcfaCYiGLjXepbkKNwr =vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['endTime'].replace('-','').replace(' ','').replace(':','')
    if vABSxhMgIqtWcfaCYiGLjXepbkKNPQ(vABSxhMgIqtWcfaCYiGLjXepbkKNwo)>vABSxhMgIqtWcfaCYiGLjXepbkKNPQ(vABSxhMgIqtWcfaCYiGLjXepbkKNwr) :continue
    if vABSxhMgIqtWcfaCYiGLjXepbkKNPQ(vABSxhMgIqtWcfaCYiGLjXepbkKNwm)<vABSxhMgIqtWcfaCYiGLjXepbkKNPQ(vABSxhMgIqtWcfaCYiGLjXepbkKNwT):continue
    if vABSxhMgIqtWcfaCYiGLjXepbkKNwU!=vABSxhMgIqtWcfaCYiGLjXepbkKNws:
     if vABSxhMgIqtWcfaCYiGLjXepbkKNwD!='':vABSxhMgIqtWcfaCYiGLjXepbkKNwO[vABSxhMgIqtWcfaCYiGLjXepbkKNwU]=vABSxhMgIqtWcfaCYiGLjXepbkKNwD
     vABSxhMgIqtWcfaCYiGLjXepbkKNwU=vABSxhMgIqtWcfaCYiGLjXepbkKNws
     vABSxhMgIqtWcfaCYiGLjXepbkKNwD =''
    if vABSxhMgIqtWcfaCYiGLjXepbkKNwD:vABSxhMgIqtWcfaCYiGLjXepbkKNwD+='\n'
    vABSxhMgIqtWcfaCYiGLjXepbkKNwD+=vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['title']+'\n'
    vABSxhMgIqtWcfaCYiGLjXepbkKNwD+=' [%s ~ %s]'%(vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['startTime'][-5:],vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['endTime'][-5:])+'\n'
   if vABSxhMgIqtWcfaCYiGLjXepbkKNwD:vABSxhMgIqtWcfaCYiGLjXepbkKNwO[vABSxhMgIqtWcfaCYiGLjXepbkKNwU]=vABSxhMgIqtWcfaCYiGLjXepbkKNwD
  except vABSxhMgIqtWcfaCYiGLjXepbkKNPn as exception:
   vABSxhMgIqtWcfaCYiGLjXepbkKNPs(exception)
  return vABSxhMgIqtWcfaCYiGLjXepbkKNwO
 def GetEPGList_new(vABSxhMgIqtWcfaCYiGLjXepbkKNdF):
  vABSxhMgIqtWcfaCYiGLjXepbkKNwO={}
  vABSxhMgIqtWcfaCYiGLjXepbkKNwH=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.Get_Now_Datetime()
  vABSxhMgIqtWcfaCYiGLjXepbkKNwo=vABSxhMgIqtWcfaCYiGLjXepbkKNwH.strftime('%Y%m%d%H%M00')
  vABSxhMgIqtWcfaCYiGLjXepbkKNwu='%s%s%s'%(vABSxhMgIqtWcfaCYiGLjXepbkKNwo[0:4],vABSxhMgIqtWcfaCYiGLjXepbkKNwo[4:6],vABSxhMgIqtWcfaCYiGLjXepbkKNwo[6:8])
  vABSxhMgIqtWcfaCYiGLjXepbkKNwm=(vABSxhMgIqtWcfaCYiGLjXepbkKNwH+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M00')
  try:
   for vABSxhMgIqtWcfaCYiGLjXepbkKNwJ in vABSxhMgIqtWcfaCYiGLjXepbkKNdV:
    vABSxhMgIqtWcfaCYiGLjXepbkKNwn =vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['videoId']
    if vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['epgtype']=='spotvon':
     vABSxhMgIqtWcfaCYiGLjXepbkKNwD=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.Get_EpgInfo_Spotv_spotvon(vABSxhMgIqtWcfaCYiGLjXepbkKNwn,vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['epgnm'],vABSxhMgIqtWcfaCYiGLjXepbkKNwu)
     vABSxhMgIqtWcfaCYiGLjXepbkKNwO[vABSxhMgIqtWcfaCYiGLjXepbkKNwn]=vABSxhMgIqtWcfaCYiGLjXepbkKNwD
    if vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['epgtype']=='spotvnet':
     vABSxhMgIqtWcfaCYiGLjXepbkKNwD=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.Get_EpgInfo_Spotv_spotvnet(vABSxhMgIqtWcfaCYiGLjXepbkKNwn,vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['epgnm'],vABSxhMgIqtWcfaCYiGLjXepbkKNwu)
     vABSxhMgIqtWcfaCYiGLjXepbkKNwO[vABSxhMgIqtWcfaCYiGLjXepbkKNwn]=vABSxhMgIqtWcfaCYiGLjXepbkKNwD
   for vABSxhMgIqtWcfaCYiGLjXepbkKNwQ in vABSxhMgIqtWcfaCYiGLjXepbkKNwO.keys():
    if vABSxhMgIqtWcfaCYiGLjXepbkKNPE(vABSxhMgIqtWcfaCYiGLjXepbkKNwO.get(vABSxhMgIqtWcfaCYiGLjXepbkKNwQ))==0:continue
    vABSxhMgIqtWcfaCYiGLjXepbkKNwD =''
    vABSxhMgIqtWcfaCYiGLjXepbkKNwE=''
    for vABSxhMgIqtWcfaCYiGLjXepbkKNwl in vABSxhMgIqtWcfaCYiGLjXepbkKNwO.get(vABSxhMgIqtWcfaCYiGLjXepbkKNwQ):
     vABSxhMgIqtWcfaCYiGLjXepbkKNwT =vABSxhMgIqtWcfaCYiGLjXepbkKNwl['startTime']
     vABSxhMgIqtWcfaCYiGLjXepbkKNwr =vABSxhMgIqtWcfaCYiGLjXepbkKNwl['endTime']
     if vABSxhMgIqtWcfaCYiGLjXepbkKNPQ(vABSxhMgIqtWcfaCYiGLjXepbkKNwo)>vABSxhMgIqtWcfaCYiGLjXepbkKNPQ(vABSxhMgIqtWcfaCYiGLjXepbkKNwr) :continue
     if vABSxhMgIqtWcfaCYiGLjXepbkKNPQ(vABSxhMgIqtWcfaCYiGLjXepbkKNwm)<vABSxhMgIqtWcfaCYiGLjXepbkKNPQ(vABSxhMgIqtWcfaCYiGLjXepbkKNwT):continue
     if vABSxhMgIqtWcfaCYiGLjXepbkKNPQ(vABSxhMgIqtWcfaCYiGLjXepbkKNwo)>=vABSxhMgIqtWcfaCYiGLjXepbkKNPQ(vABSxhMgIqtWcfaCYiGLjXepbkKNwT)and vABSxhMgIqtWcfaCYiGLjXepbkKNPQ(vABSxhMgIqtWcfaCYiGLjXepbkKNwo)<vABSxhMgIqtWcfaCYiGLjXepbkKNPQ(vABSxhMgIqtWcfaCYiGLjXepbkKNwr):vABSxhMgIqtWcfaCYiGLjXepbkKNwE=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.xmlText(vABSxhMgIqtWcfaCYiGLjXepbkKNwl['title'])
     if vABSxhMgIqtWcfaCYiGLjXepbkKNwD:vABSxhMgIqtWcfaCYiGLjXepbkKNwD+='\n'
     vABSxhMgIqtWcfaCYiGLjXepbkKNwD+=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.xmlText(vABSxhMgIqtWcfaCYiGLjXepbkKNwl['title'])+'\n'
     vABSxhMgIqtWcfaCYiGLjXepbkKNwD+=' [%s:%s ~ %s:%s]'%(vABSxhMgIqtWcfaCYiGLjXepbkKNwl['startTime'][8:10],vABSxhMgIqtWcfaCYiGLjXepbkKNwl['startTime'][10:12],vABSxhMgIqtWcfaCYiGLjXepbkKNwl['endTime'][8:10],vABSxhMgIqtWcfaCYiGLjXepbkKNwl['endTime'][10:12])+'\n'
    vABSxhMgIqtWcfaCYiGLjXepbkKNwO[vABSxhMgIqtWcfaCYiGLjXepbkKNwQ]={'epg':vABSxhMgIqtWcfaCYiGLjXepbkKNwD,'title':vABSxhMgIqtWcfaCYiGLjXepbkKNwE}
  except vABSxhMgIqtWcfaCYiGLjXepbkKNPn as exception:
   vABSxhMgIqtWcfaCYiGLjXepbkKNPs(exception)
  return vABSxhMgIqtWcfaCYiGLjXepbkKNwO
 def Get_EpgInfo_Spotv_spotvon(vABSxhMgIqtWcfaCYiGLjXepbkKNdF,vABSxhMgIqtWcfaCYiGLjXepbkKNwn,epgnm,now_day):
  vABSxhMgIqtWcfaCYiGLjXepbkKNwO =[]
  try:
   vABSxhMgIqtWcfaCYiGLjXepbkKNwR='https://www.spotvon.co.kr/data/onAir/%s/Daily/D%s.asp'%(epgnm,now_day)
   vABSxhMgIqtWcfaCYiGLjXepbkKNds=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.callRequestCookies('Get',vABSxhMgIqtWcfaCYiGLjXepbkKNwR,payload=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,params=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,headers=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,cookies=vABSxhMgIqtWcfaCYiGLjXepbkKNPD)
   vABSxhMgIqtWcfaCYiGLjXepbkKNzd=json.loads(vABSxhMgIqtWcfaCYiGLjXepbkKNds.text)
   for vABSxhMgIqtWcfaCYiGLjXepbkKNwJ in vABSxhMgIqtWcfaCYiGLjXepbkKNzd:
    vABSxhMgIqtWcfaCYiGLjXepbkKNwy={'title':vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['title'],'startTime':vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['sch_date'].replace('-','')+vABSxhMgIqtWcfaCYiGLjXepbkKNPT(vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['sch_hour']).zfill(2)+vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['sch_min']+'00'}
    vABSxhMgIqtWcfaCYiGLjXepbkKNwO.append(vABSxhMgIqtWcfaCYiGLjXepbkKNwy)
   for i in vABSxhMgIqtWcfaCYiGLjXepbkKNPl(vABSxhMgIqtWcfaCYiGLjXepbkKNPE(vABSxhMgIqtWcfaCYiGLjXepbkKNwO)):
    if i>0:vABSxhMgIqtWcfaCYiGLjXepbkKNwO[i-1]['endTime']=vABSxhMgIqtWcfaCYiGLjXepbkKNwO[i]['startTime']
    if i==vABSxhMgIqtWcfaCYiGLjXepbkKNPE(vABSxhMgIqtWcfaCYiGLjXepbkKNwO)-1: vABSxhMgIqtWcfaCYiGLjXepbkKNwO[i]['endTime']=now_day+'240000'
  except vABSxhMgIqtWcfaCYiGLjXepbkKNPn as exception:
   vABSxhMgIqtWcfaCYiGLjXepbkKNPs(exception)
   return[]
  return vABSxhMgIqtWcfaCYiGLjXepbkKNwO
 def Get_EpgInfo_Spotv_spotvnet(vABSxhMgIqtWcfaCYiGLjXepbkKNdF,vABSxhMgIqtWcfaCYiGLjXepbkKNwn,epgnm,now_day):
  vABSxhMgIqtWcfaCYiGLjXepbkKNwO =[]
  try:
   vABSxhMgIqtWcfaCYiGLjXepbkKNwR='https://www.spotv.net/data/json/schedule/%s/Daily/D%s.json'%(epgnm,now_day)
   vABSxhMgIqtWcfaCYiGLjXepbkKNds=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.callRequestCookies('Get',vABSxhMgIqtWcfaCYiGLjXepbkKNwR,payload=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,params=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,headers=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,cookies=vABSxhMgIqtWcfaCYiGLjXepbkKNPD)
   vABSxhMgIqtWcfaCYiGLjXepbkKNzd=json.loads(vABSxhMgIqtWcfaCYiGLjXepbkKNds.text)
   for vABSxhMgIqtWcfaCYiGLjXepbkKNwJ in vABSxhMgIqtWcfaCYiGLjXepbkKNzd:
    vABSxhMgIqtWcfaCYiGLjXepbkKNwy={'title':vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['title'],'startTime':vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['sch_date'].replace('-','')+vABSxhMgIqtWcfaCYiGLjXepbkKNPT(vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['sch_hour']).zfill(2)+vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['sch_min']+'00'}
    vABSxhMgIqtWcfaCYiGLjXepbkKNwO.append(vABSxhMgIqtWcfaCYiGLjXepbkKNwy)
   for i in vABSxhMgIqtWcfaCYiGLjXepbkKNPl(vABSxhMgIqtWcfaCYiGLjXepbkKNPE(vABSxhMgIqtWcfaCYiGLjXepbkKNwO)):
    if i>0:vABSxhMgIqtWcfaCYiGLjXepbkKNwO[i-1]['endTime']=vABSxhMgIqtWcfaCYiGLjXepbkKNwO[i]['startTime']
    if i==vABSxhMgIqtWcfaCYiGLjXepbkKNPE(vABSxhMgIqtWcfaCYiGLjXepbkKNwO)-1: vABSxhMgIqtWcfaCYiGLjXepbkKNwO[i]['endTime']=now_day+'240000'
  except vABSxhMgIqtWcfaCYiGLjXepbkKNPn as exception:
   vABSxhMgIqtWcfaCYiGLjXepbkKNPs(exception)
   return[]
  return vABSxhMgIqtWcfaCYiGLjXepbkKNwO
 def GetEventLiveList(vABSxhMgIqtWcfaCYiGLjXepbkKNdF):
  vABSxhMgIqtWcfaCYiGLjXepbkKNwP=[]
  vABSxhMgIqtWcfaCYiGLjXepbkKNzw =0
  try:
   vABSxhMgIqtWcfaCYiGLjXepbkKNzV=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.Get_Now_Datetime()
   vABSxhMgIqtWcfaCYiGLjXepbkKNzP=vABSxhMgIqtWcfaCYiGLjXepbkKNzV.strftime('%Y-%m-%d')
  except vABSxhMgIqtWcfaCYiGLjXepbkKNPn as exception:
   vABSxhMgIqtWcfaCYiGLjXepbkKNPs(exception)
   return vABSxhMgIqtWcfaCYiGLjXepbkKNwP,vABSxhMgIqtWcfaCYiGLjXepbkKNzw
  try:
   vABSxhMgIqtWcfaCYiGLjXepbkKNwR=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.API_DOMAIN+'/api/v2/player/lives/'+vABSxhMgIqtWcfaCYiGLjXepbkKNzP 
   vABSxhMgIqtWcfaCYiGLjXepbkKNdR=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.makeDefaultCookies()
   vABSxhMgIqtWcfaCYiGLjXepbkKNds=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.callRequestCookies('Get',vABSxhMgIqtWcfaCYiGLjXepbkKNwR,payload=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,params=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,headers=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,cookies=vABSxhMgIqtWcfaCYiGLjXepbkKNdR)
   vABSxhMgIqtWcfaCYiGLjXepbkKNzw=vABSxhMgIqtWcfaCYiGLjXepbkKNds.status_code 
   vABSxhMgIqtWcfaCYiGLjXepbkKNdn=json.loads(vABSxhMgIqtWcfaCYiGLjXepbkKNds.text)
   for vABSxhMgIqtWcfaCYiGLjXepbkKNzF in vABSxhMgIqtWcfaCYiGLjXepbkKNdn:
    for vABSxhMgIqtWcfaCYiGLjXepbkKNwJ in vABSxhMgIqtWcfaCYiGLjXepbkKNzF['liveNowList']:
     if vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['gameDesc']['title']==vABSxhMgIqtWcfaCYiGLjXepbkKNPD or vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['gameDesc']['title']=='':
      vABSxhMgIqtWcfaCYiGLjXepbkKNzJ='%s ( %s : %s )'%(vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['leagueName'],vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['homeNameShort'],vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['awayNameShort'])
     else:
      vABSxhMgIqtWcfaCYiGLjXepbkKNzJ=vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['gameDesc']['title']
     vABSxhMgIqtWcfaCYiGLjXepbkKNwy={'liveId':vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['liveId'],'title':vABSxhMgIqtWcfaCYiGLjXepbkKNzJ,'logo':vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['gameDesc']['leagueLogo'],'free':vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['isFree'],'startTime':vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['startTime']}
     vABSxhMgIqtWcfaCYiGLjXepbkKNwP.append(vABSxhMgIqtWcfaCYiGLjXepbkKNwy)
  except vABSxhMgIqtWcfaCYiGLjXepbkKNPn as exception:
   vABSxhMgIqtWcfaCYiGLjXepbkKNPs(exception)
  return vABSxhMgIqtWcfaCYiGLjXepbkKNwP,vABSxhMgIqtWcfaCYiGLjXepbkKNzw
 def GetEventLive_videoId(vABSxhMgIqtWcfaCYiGLjXepbkKNdF,liveId):
  vABSxhMgIqtWcfaCYiGLjXepbkKNzy=''
  try:
   vABSxhMgIqtWcfaCYiGLjXepbkKNwR=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.API_DOMAIN+'/api/v2/live/'+liveId
   vABSxhMgIqtWcfaCYiGLjXepbkKNds=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.callRequestCookies('Get',vABSxhMgIqtWcfaCYiGLjXepbkKNwR,payload=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,params=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,headers=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,cookies=vABSxhMgIqtWcfaCYiGLjXepbkKNPD)
   vABSxhMgIqtWcfaCYiGLjXepbkKNdn=json.loads(vABSxhMgIqtWcfaCYiGLjXepbkKNds.text)
   vABSxhMgIqtWcfaCYiGLjXepbkKNzR=vABSxhMgIqtWcfaCYiGLjXepbkKNdn['videoId']
   vABSxhMgIqtWcfaCYiGLjXepbkKNzy=vABSxhMgIqtWcfaCYiGLjXepbkKNzR.replace('ref:','')
  except vABSxhMgIqtWcfaCYiGLjXepbkKNPn as exception:
   vABSxhMgIqtWcfaCYiGLjXepbkKNPs(exception)
  return vABSxhMgIqtWcfaCYiGLjXepbkKNzy
 def CheckMainEnd(vABSxhMgIqtWcfaCYiGLjXepbkKNdF):
  vABSxhMgIqtWcfaCYiGLjXepbkKNzO=base64.standard_b64encode((vABSxhMgIqtWcfaCYiGLjXepbkKNdF.SPOTV_PMCODE+vABSxhMgIqtWcfaCYiGLjXepbkKNdF.SPOTV_SESSIONID).encode()).decode('utf-8')
  if vABSxhMgIqtWcfaCYiGLjXepbkKNzO=='OTg3MTgzMzM0Ng==' or vABSxhMgIqtWcfaCYiGLjXepbkKNzO=='OTg3MTgzMzExNw==':return vABSxhMgIqtWcfaCYiGLjXepbkKNPr
  return vABSxhMgIqtWcfaCYiGLjXepbkKNPm
 def CheckSubEnd(vABSxhMgIqtWcfaCYiGLjXepbkKNdF):
  vABSxhMgIqtWcfaCYiGLjXepbkKNzH=vABSxhMgIqtWcfaCYiGLjXepbkKNPm
  try:
   if vABSxhMgIqtWcfaCYiGLjXepbkKNdF.CheckMainEnd():return vABSxhMgIqtWcfaCYiGLjXepbkKNPr 
   if vABSxhMgIqtWcfaCYiGLjXepbkKNdF.SPOTV_SUBEND=='0':return vABSxhMgIqtWcfaCYiGLjXepbkKNzH
   vABSxhMgIqtWcfaCYiGLjXepbkKNzo =vABSxhMgIqtWcfaCYiGLjXepbkKNPQ(vABSxhMgIqtWcfaCYiGLjXepbkKNdF.Get_Now_Datetime().strftime('%Y%m%d'))
   vABSxhMgIqtWcfaCYiGLjXepbkKNzu =vABSxhMgIqtWcfaCYiGLjXepbkKNPQ(vABSxhMgIqtWcfaCYiGLjXepbkKNdF.SPOTV_SUBEND)/1000
   vABSxhMgIqtWcfaCYiGLjXepbkKNzm =vABSxhMgIqtWcfaCYiGLjXepbkKNPQ(datetime.datetime.fromtimestamp(vABSxhMgIqtWcfaCYiGLjXepbkKNzu,datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul')).strftime('%Y%m%d'))
   if vABSxhMgIqtWcfaCYiGLjXepbkKNzo<=vABSxhMgIqtWcfaCYiGLjXepbkKNzm:vABSxhMgIqtWcfaCYiGLjXepbkKNzH=vABSxhMgIqtWcfaCYiGLjXepbkKNPr
  except vABSxhMgIqtWcfaCYiGLjXepbkKNPn as exception:
   vABSxhMgIqtWcfaCYiGLjXepbkKNPs(exception)
   return vABSxhMgIqtWcfaCYiGLjXepbkKNzH
  return vABSxhMgIqtWcfaCYiGLjXepbkKNzH
 def GetMainJspath(vABSxhMgIqtWcfaCYiGLjXepbkKNdF):
  vABSxhMgIqtWcfaCYiGLjXepbkKNzU=''
  try:
   vABSxhMgIqtWcfaCYiGLjXepbkKNwR=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.API_DOMAIN
   vABSxhMgIqtWcfaCYiGLjXepbkKNds=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.callRequestCookies('Get',vABSxhMgIqtWcfaCYiGLjXepbkKNwR,payload=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,params=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,headers=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,cookies=vABSxhMgIqtWcfaCYiGLjXepbkKNPD)
   vABSxhMgIqtWcfaCYiGLjXepbkKNzD=vABSxhMgIqtWcfaCYiGLjXepbkKNds.text
   vABSxhMgIqtWcfaCYiGLjXepbkKNzs =re.findall('https://cdn.spotvnow.co.kr/dist/js/.{20}\.js',vABSxhMgIqtWcfaCYiGLjXepbkKNzD)[0]
   vABSxhMgIqtWcfaCYiGLjXepbkKNzU=vABSxhMgIqtWcfaCYiGLjXepbkKNzs
  except vABSxhMgIqtWcfaCYiGLjXepbkKNPn as exception:
   vABSxhMgIqtWcfaCYiGLjXepbkKNPs(exception)
  return vABSxhMgIqtWcfaCYiGLjXepbkKNzU
 def GetBcPlayerUrl(vABSxhMgIqtWcfaCYiGLjXepbkKNdF):
  vABSxhMgIqtWcfaCYiGLjXepbkKNzT=''
  try:
   vABSxhMgIqtWcfaCYiGLjXepbkKNwR=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.GetMainJspath()
   if vABSxhMgIqtWcfaCYiGLjXepbkKNwR=='':return vABSxhMgIqtWcfaCYiGLjXepbkKNzT
   vABSxhMgIqtWcfaCYiGLjXepbkKNds=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.callRequestCookies('Get',vABSxhMgIqtWcfaCYiGLjXepbkKNwR,payload=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,params=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,headers=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,cookies=vABSxhMgIqtWcfaCYiGLjXepbkKNPD)
   vABSxhMgIqtWcfaCYiGLjXepbkKNzD=vABSxhMgIqtWcfaCYiGLjXepbkKNds.text
   vABSxhMgIqtWcfaCYiGLjXepbkKNzr =re.findall('bc:\s*\"\d{13}\",\s*player:\s*\".{9}\"',vABSxhMgIqtWcfaCYiGLjXepbkKNzD)[0]
   vABSxhMgIqtWcfaCYiGLjXepbkKNzr =vABSxhMgIqtWcfaCYiGLjXepbkKNzr.replace('bc','"bc"')
   vABSxhMgIqtWcfaCYiGLjXepbkKNzr =vABSxhMgIqtWcfaCYiGLjXepbkKNzr.replace('player','"player"')
   vABSxhMgIqtWcfaCYiGLjXepbkKNzr ='{'+vABSxhMgIqtWcfaCYiGLjXepbkKNzr+'}'
   vABSxhMgIqtWcfaCYiGLjXepbkKNzr =json.loads(vABSxhMgIqtWcfaCYiGLjXepbkKNzr)
   bc =vABSxhMgIqtWcfaCYiGLjXepbkKNzr['bc']
   vABSxhMgIqtWcfaCYiGLjXepbkKNzn =vABSxhMgIqtWcfaCYiGLjXepbkKNzr['player']
   vABSxhMgIqtWcfaCYiGLjXepbkKNzT="%s/%s/%s_default/index.min.js"%(vABSxhMgIqtWcfaCYiGLjXepbkKNdF.BC_DOMAIN,bc,vABSxhMgIqtWcfaCYiGLjXepbkKNzn)
  except vABSxhMgIqtWcfaCYiGLjXepbkKNPn as exception:
   vABSxhMgIqtWcfaCYiGLjXepbkKNPs(exception)
  return vABSxhMgIqtWcfaCYiGLjXepbkKNzT
 def GetPolicyKey(vABSxhMgIqtWcfaCYiGLjXepbkKNdF):
  vABSxhMgIqtWcfaCYiGLjXepbkKNzQ=policykey=''
  try:
   vABSxhMgIqtWcfaCYiGLjXepbkKNwR=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.GetBcPlayerUrl()
   if vABSxhMgIqtWcfaCYiGLjXepbkKNwR=='':return vABSxhMgIqtWcfaCYiGLjXepbkKNzQ,vABSxhMgIqtWcfaCYiGLjXepbkKNzl
   vABSxhMgIqtWcfaCYiGLjXepbkKNds=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.callRequestCookies('Get',vABSxhMgIqtWcfaCYiGLjXepbkKNwR,payload=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,params=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,headers=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,cookies=vABSxhMgIqtWcfaCYiGLjXepbkKNPD)
   vABSxhMgIqtWcfaCYiGLjXepbkKNzD=vABSxhMgIqtWcfaCYiGLjXepbkKNds.text
   vABSxhMgIqtWcfaCYiGLjXepbkKNzs =re.findall('accountId:\s*\"\d{13}\",\s*policyKey:\s*\".[^(){}]{100,300}\"',vABSxhMgIqtWcfaCYiGLjXepbkKNzD)[0]
   vABSxhMgIqtWcfaCYiGLjXepbkKNzs =vABSxhMgIqtWcfaCYiGLjXepbkKNzs.replace('accountId','"accountId"')
   vABSxhMgIqtWcfaCYiGLjXepbkKNzs =vABSxhMgIqtWcfaCYiGLjXepbkKNzs.replace('policyKey','"policyKey"')
   vABSxhMgIqtWcfaCYiGLjXepbkKNzs ='{'+vABSxhMgIqtWcfaCYiGLjXepbkKNzs+'}'
   vABSxhMgIqtWcfaCYiGLjXepbkKNzE=json.loads(vABSxhMgIqtWcfaCYiGLjXepbkKNzs)
   vABSxhMgIqtWcfaCYiGLjXepbkKNzQ =vABSxhMgIqtWcfaCYiGLjXepbkKNzE['accountId']
   vABSxhMgIqtWcfaCYiGLjXepbkKNzl =vABSxhMgIqtWcfaCYiGLjXepbkKNzE['policyKey']
  except vABSxhMgIqtWcfaCYiGLjXepbkKNPn as exception:
   vABSxhMgIqtWcfaCYiGLjXepbkKNPs(exception)
  return vABSxhMgIqtWcfaCYiGLjXepbkKNzQ,vABSxhMgIqtWcfaCYiGLjXepbkKNzl
 def GetBroadURL(vABSxhMgIqtWcfaCYiGLjXepbkKNdF,vABSxhMgIqtWcfaCYiGLjXepbkKNzy,mediatype,vABSxhMgIqtWcfaCYiGLjXepbkKNVo):
  vABSxhMgIqtWcfaCYiGLjXepbkKNVd=''
  try:
   if mediatype=='live':
    vABSxhMgIqtWcfaCYiGLjXepbkKNzy='ref%3A'+vABSxhMgIqtWcfaCYiGLjXepbkKNzy
   else:
    vABSxhMgIqtWcfaCYiGLjXepbkKNzy=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.GetReplay_UrlId(vABSxhMgIqtWcfaCYiGLjXepbkKNzy,vABSxhMgIqtWcfaCYiGLjXepbkKNVo)
    if vABSxhMgIqtWcfaCYiGLjXepbkKNzy=='':return vABSxhMgIqtWcfaCYiGLjXepbkKNVd
   vABSxhMgIqtWcfaCYiGLjXepbkKNwR=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.PLAYER_DOMAIN+'/playback/v1/accounts/'+vABSxhMgIqtWcfaCYiGLjXepbkKNdF.SPOTV_ACCOUNTID+'/videos/'+vABSxhMgIqtWcfaCYiGLjXepbkKNzy
   vABSxhMgIqtWcfaCYiGLjXepbkKNVw={'accept':'application/json;pk='+vABSxhMgIqtWcfaCYiGLjXepbkKNdF.SPOTV_POLICYKEY}
   vABSxhMgIqtWcfaCYiGLjXepbkKNds=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.callRequestCookies('Get',vABSxhMgIqtWcfaCYiGLjXepbkKNwR,payload=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,params=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,headers=vABSxhMgIqtWcfaCYiGLjXepbkKNVw,cookies=vABSxhMgIqtWcfaCYiGLjXepbkKNPD)
   vABSxhMgIqtWcfaCYiGLjXepbkKNzd=json.loads(vABSxhMgIqtWcfaCYiGLjXepbkKNds.text)
   vABSxhMgIqtWcfaCYiGLjXepbkKNVd=vABSxhMgIqtWcfaCYiGLjXepbkKNzd['sources'][0]['src']
   if mediatype=='live':
    vABSxhMgIqtWcfaCYiGLjXepbkKNVd=vABSxhMgIqtWcfaCYiGLjXepbkKNVd.replace('playlist.m3u8','playlist_dvr.m3u8')
   vABSxhMgIqtWcfaCYiGLjXepbkKNVd=vABSxhMgIqtWcfaCYiGLjXepbkKNVd.replace('http://','https://')
  except vABSxhMgIqtWcfaCYiGLjXepbkKNPn as exception:
   vABSxhMgIqtWcfaCYiGLjXepbkKNPs(exception)
  return vABSxhMgIqtWcfaCYiGLjXepbkKNVd
 def GetTitleGroupList(vABSxhMgIqtWcfaCYiGLjXepbkKNdF):
  vABSxhMgIqtWcfaCYiGLjXepbkKNwP=[]
  vABSxhMgIqtWcfaCYiGLjXepbkKNVz=vABSxhMgIqtWcfaCYiGLjXepbkKNPm
  try:
   vABSxhMgIqtWcfaCYiGLjXepbkKNwR=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.API_DOMAIN+'/api/v2/home/web'
   vABSxhMgIqtWcfaCYiGLjXepbkKNds=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.callRequestCookies('Get',vABSxhMgIqtWcfaCYiGLjXepbkKNwR,payload=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,params=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,headers=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,cookies=vABSxhMgIqtWcfaCYiGLjXepbkKNPD)
   vABSxhMgIqtWcfaCYiGLjXepbkKNdn=json.loads(vABSxhMgIqtWcfaCYiGLjXepbkKNds.text)
   for vABSxhMgIqtWcfaCYiGLjXepbkKNwJ in vABSxhMgIqtWcfaCYiGLjXepbkKNdn:
    if vABSxhMgIqtWcfaCYiGLjXepbkKNPT(vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['type'])=='3':
     vABSxhMgIqtWcfaCYiGLjXepbkKNVP=''
     for vABSxhMgIqtWcfaCYiGLjXepbkKNVF in vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['data']['list']:
      vABSxhMgIqtWcfaCYiGLjXepbkKNVJ='[%s] %s vs %s\n<%s>\n\n'%(vABSxhMgIqtWcfaCYiGLjXepbkKNVF['gameDesc']['roundName'],vABSxhMgIqtWcfaCYiGLjXepbkKNVF['gameDesc']['homeNameShort'],vABSxhMgIqtWcfaCYiGLjXepbkKNVF['gameDesc']['awayNameShort'],vABSxhMgIqtWcfaCYiGLjXepbkKNVF['gameDesc']['beginDate'])
      vABSxhMgIqtWcfaCYiGLjXepbkKNVP+=vABSxhMgIqtWcfaCYiGLjXepbkKNVJ
     vABSxhMgIqtWcfaCYiGLjXepbkKNwy={'title':vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['title'],'logo':vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['logo'],'reagueId':vABSxhMgIqtWcfaCYiGLjXepbkKNPT(vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['destId']),'subGame':vABSxhMgIqtWcfaCYiGLjXepbkKNVP}
     vABSxhMgIqtWcfaCYiGLjXepbkKNwP.append(vABSxhMgIqtWcfaCYiGLjXepbkKNwy)
     if vABSxhMgIqtWcfaCYiGLjXepbkKNPT(vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['destId'])=='13':vABSxhMgIqtWcfaCYiGLjXepbkKNVz=vABSxhMgIqtWcfaCYiGLjXepbkKNPr
   if vABSxhMgIqtWcfaCYiGLjXepbkKNVz==vABSxhMgIqtWcfaCYiGLjXepbkKNPm:
    vABSxhMgIqtWcfaCYiGLjXepbkKNwy={'title':'UFC','logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200928/a643c7cf1c285fb0b4469c07d4c09c28.png','reagueId':'13','subGame':''}
    vABSxhMgIqtWcfaCYiGLjXepbkKNwP.append(vABSxhMgIqtWcfaCYiGLjXepbkKNwy)
  except vABSxhMgIqtWcfaCYiGLjXepbkKNPn as exception:
   vABSxhMgIqtWcfaCYiGLjXepbkKNPs(exception)
  return vABSxhMgIqtWcfaCYiGLjXepbkKNwP
 def GetPopularGroupList(vABSxhMgIqtWcfaCYiGLjXepbkKNdF):
  vABSxhMgIqtWcfaCYiGLjXepbkKNwP=[]
  try:
   vABSxhMgIqtWcfaCYiGLjXepbkKNwR=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.API_DOMAIN+'/api/v2/home/web'
   vABSxhMgIqtWcfaCYiGLjXepbkKNds=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.callRequestCookies('Get',vABSxhMgIqtWcfaCYiGLjXepbkKNwR,payload=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,params=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,headers=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,cookies=vABSxhMgIqtWcfaCYiGLjXepbkKNPD)
   vABSxhMgIqtWcfaCYiGLjXepbkKNdn=json.loads(vABSxhMgIqtWcfaCYiGLjXepbkKNds.text)
   for vABSxhMgIqtWcfaCYiGLjXepbkKNwJ in vABSxhMgIqtWcfaCYiGLjXepbkKNdn:
    if vABSxhMgIqtWcfaCYiGLjXepbkKNPT(vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['type'])=='1' and vABSxhMgIqtWcfaCYiGLjXepbkKNPT(vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['destId'])=='4':
     for vABSxhMgIqtWcfaCYiGLjXepbkKNVF in vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['data']['list']:
      vABSxhMgIqtWcfaCYiGLjXepbkKNVy =vABSxhMgIqtWcfaCYiGLjXepbkKNVF['title']
      vABSxhMgIqtWcfaCYiGLjXepbkKNVR =vABSxhMgIqtWcfaCYiGLjXepbkKNVF['id']
      vABSxhMgIqtWcfaCYiGLjXepbkKNVO =vABSxhMgIqtWcfaCYiGLjXepbkKNVF['vtype']
      vABSxhMgIqtWcfaCYiGLjXepbkKNVH =vABSxhMgIqtWcfaCYiGLjXepbkKNVF['imgUrl']
      vABSxhMgIqtWcfaCYiGLjXepbkKNVo =vABSxhMgIqtWcfaCYiGLjXepbkKNVF['vtypeId']
      vABSxhMgIqtWcfaCYiGLjXepbkKNwy={'vodTitle':vABSxhMgIqtWcfaCYiGLjXepbkKNVy,'vodId':vABSxhMgIqtWcfaCYiGLjXepbkKNVR,'vodType':vABSxhMgIqtWcfaCYiGLjXepbkKNVO,'thumbnail':vABSxhMgIqtWcfaCYiGLjXepbkKNVH,'vtypeId':vABSxhMgIqtWcfaCYiGLjXepbkKNPT(vABSxhMgIqtWcfaCYiGLjXepbkKNVo),'duration':vABSxhMgIqtWcfaCYiGLjXepbkKNPQ(vABSxhMgIqtWcfaCYiGLjXepbkKNVF['duration']/1000)}
      vABSxhMgIqtWcfaCYiGLjXepbkKNwP.append(vABSxhMgIqtWcfaCYiGLjXepbkKNwy)
  except vABSxhMgIqtWcfaCYiGLjXepbkKNPn as exception:
   vABSxhMgIqtWcfaCYiGLjXepbkKNPs(exception)
  return vABSxhMgIqtWcfaCYiGLjXepbkKNwP
 def GetSeasonList(vABSxhMgIqtWcfaCYiGLjXepbkKNdF,leagueId):
  vABSxhMgIqtWcfaCYiGLjXepbkKNwP=[]
  vABSxhMgIqtWcfaCYiGLjXepbkKNVu=vABSxhMgIqtWcfaCYiGLjXepbkKNVm=''
  try:
   vABSxhMgIqtWcfaCYiGLjXepbkKNwR=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.API_DOMAIN+'/api/v2/game/league/'+leagueId
   vABSxhMgIqtWcfaCYiGLjXepbkKNds=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.callRequestCookies('Get',vABSxhMgIqtWcfaCYiGLjXepbkKNwR,payload=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,params=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,headers=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,cookies=vABSxhMgIqtWcfaCYiGLjXepbkKNPD)
   vABSxhMgIqtWcfaCYiGLjXepbkKNdn=json.loads(vABSxhMgIqtWcfaCYiGLjXepbkKNds.text)
   vABSxhMgIqtWcfaCYiGLjXepbkKNVu=vABSxhMgIqtWcfaCYiGLjXepbkKNdn['name']
   vABSxhMgIqtWcfaCYiGLjXepbkKNVm=vABSxhMgIqtWcfaCYiGLjXepbkKNPT(vABSxhMgIqtWcfaCYiGLjXepbkKNdn['gameTypeId'])
  except vABSxhMgIqtWcfaCYiGLjXepbkKNPn as exception:
   vABSxhMgIqtWcfaCYiGLjXepbkKNPs(exception)
   return vABSxhMgIqtWcfaCYiGLjXepbkKNwP
  if vABSxhMgIqtWcfaCYiGLjXepbkKNVm=='2':
   try:
    vABSxhMgIqtWcfaCYiGLjXepbkKNwR=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.API_DOMAIN+'/api/v2/year/'+leagueId
    vABSxhMgIqtWcfaCYiGLjXepbkKNds=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.callRequestCookies('Get',vABSxhMgIqtWcfaCYiGLjXepbkKNwR,payload=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,params=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,headers=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,cookies=vABSxhMgIqtWcfaCYiGLjXepbkKNPD)
    vABSxhMgIqtWcfaCYiGLjXepbkKNdn=json.loads(vABSxhMgIqtWcfaCYiGLjXepbkKNds.text)
    for vABSxhMgIqtWcfaCYiGLjXepbkKNwJ in vABSxhMgIqtWcfaCYiGLjXepbkKNdn:
     vABSxhMgIqtWcfaCYiGLjXepbkKNwy={'reagueName':vABSxhMgIqtWcfaCYiGLjXepbkKNVu,'gameTypeId':vABSxhMgIqtWcfaCYiGLjXepbkKNVm,'seasonName':vABSxhMgIqtWcfaCYiGLjXepbkKNPT(vABSxhMgIqtWcfaCYiGLjXepbkKNwJ),'seasonId':vABSxhMgIqtWcfaCYiGLjXepbkKNPT(vABSxhMgIqtWcfaCYiGLjXepbkKNwJ)}
     vABSxhMgIqtWcfaCYiGLjXepbkKNwP.append(vABSxhMgIqtWcfaCYiGLjXepbkKNwy)
   except vABSxhMgIqtWcfaCYiGLjXepbkKNPn as exception:
    vABSxhMgIqtWcfaCYiGLjXepbkKNPs(exception)
    return[]
  else:
   try:
    vABSxhMgIqtWcfaCYiGLjXepbkKNwR=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.API_DOMAIN+'/api/v2/season/'+leagueId
    vABSxhMgIqtWcfaCYiGLjXepbkKNds=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.callRequestCookies('Get',vABSxhMgIqtWcfaCYiGLjXepbkKNwR,payload=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,params=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,headers=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,cookies=vABSxhMgIqtWcfaCYiGLjXepbkKNPD)
    vABSxhMgIqtWcfaCYiGLjXepbkKNdn=json.loads(vABSxhMgIqtWcfaCYiGLjXepbkKNds.text)
    for vABSxhMgIqtWcfaCYiGLjXepbkKNwJ in vABSxhMgIqtWcfaCYiGLjXepbkKNdn:
     vABSxhMgIqtWcfaCYiGLjXepbkKNwy={'reagueName':vABSxhMgIqtWcfaCYiGLjXepbkKNVu,'gameTypeId':vABSxhMgIqtWcfaCYiGLjXepbkKNVm,'seasonName':vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['name'],'seasonId':vABSxhMgIqtWcfaCYiGLjXepbkKNPT(vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['id'])}
     vABSxhMgIqtWcfaCYiGLjXepbkKNwP.append(vABSxhMgIqtWcfaCYiGLjXepbkKNwy)
   except vABSxhMgIqtWcfaCYiGLjXepbkKNPn as exception:
    vABSxhMgIqtWcfaCYiGLjXepbkKNPs(exception)
    return[]
  return vABSxhMgIqtWcfaCYiGLjXepbkKNwP
 def GetGameList(vABSxhMgIqtWcfaCYiGLjXepbkKNdF,vABSxhMgIqtWcfaCYiGLjXepbkKNVm,leagueId,seasonId,page_int,hidescore=vABSxhMgIqtWcfaCYiGLjXepbkKNPr):
  vABSxhMgIqtWcfaCYiGLjXepbkKNwP=[]
  vABSxhMgIqtWcfaCYiGLjXepbkKNVU=vABSxhMgIqtWcfaCYiGLjXepbkKNPm
  try:
   vABSxhMgIqtWcfaCYiGLjXepbkKNwR=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.API_DOMAIN+'/api/v2/vod/league/detail'
   vABSxhMgIqtWcfaCYiGLjXepbkKNVD={'gameType':vABSxhMgIqtWcfaCYiGLjXepbkKNVm,'leagueId':leagueId,'seasonId':seasonId if vABSxhMgIqtWcfaCYiGLjXepbkKNVm!='2' else '','teamId':'','roundId':'','year':'' if vABSxhMgIqtWcfaCYiGLjXepbkKNVm!='2' else seasonId,'pageNo':vABSxhMgIqtWcfaCYiGLjXepbkKNPT(page_int)}
   vABSxhMgIqtWcfaCYiGLjXepbkKNds=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.callRequestCookies('Get',vABSxhMgIqtWcfaCYiGLjXepbkKNwR,payload=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,params=vABSxhMgIqtWcfaCYiGLjXepbkKNVD,headers=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,cookies=vABSxhMgIqtWcfaCYiGLjXepbkKNPD)
   vABSxhMgIqtWcfaCYiGLjXepbkKNdn=json.loads(vABSxhMgIqtWcfaCYiGLjXepbkKNds.text)
   vABSxhMgIqtWcfaCYiGLjXepbkKNzF=vABSxhMgIqtWcfaCYiGLjXepbkKNdn['list']
   for vABSxhMgIqtWcfaCYiGLjXepbkKNVs in vABSxhMgIqtWcfaCYiGLjXepbkKNzF:
    for vABSxhMgIqtWcfaCYiGLjXepbkKNwJ in vABSxhMgIqtWcfaCYiGLjXepbkKNVs['list']:
     if vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['gameDesc']['title']==vABSxhMgIqtWcfaCYiGLjXepbkKNPD or vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['gameDesc']['title']=='':
      vABSxhMgIqtWcfaCYiGLjXepbkKNzJ ='%s vs %s'%(vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['gameDesc']['homeNameShort'],vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['gameDesc']['awayNameShort'])
     else:
      vABSxhMgIqtWcfaCYiGLjXepbkKNzJ =vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['gameDesc']['title']
     vABSxhMgIqtWcfaCYiGLjXepbkKNVT =vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['gameDesc']['beginDate']
     vABSxhMgIqtWcfaCYiGLjXepbkKNVr =vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['gameDesc']['id']
     vABSxhMgIqtWcfaCYiGLjXepbkKNVn =vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['gameDesc']['leagueNameFull']
     vABSxhMgIqtWcfaCYiGLjXepbkKNVQ =vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['gameDesc']['seasonName']
     vABSxhMgIqtWcfaCYiGLjXepbkKNVE =vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['gameDesc']['roundName']
     vABSxhMgIqtWcfaCYiGLjXepbkKNVl =vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['gameDesc']['homeName']
     vABSxhMgIqtWcfaCYiGLjXepbkKNPd =vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['gameDesc']['awayName']
     vABSxhMgIqtWcfaCYiGLjXepbkKNPw =vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['gameDesc']['homeScore']
     vABSxhMgIqtWcfaCYiGLjXepbkKNPz =vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['gameDesc']['awayScore']
     if hidescore==vABSxhMgIqtWcfaCYiGLjXepbkKNPr:
      vABSxhMgIqtWcfaCYiGLjXepbkKNPV ='%s\n - %s (%s)\n - %s\n\nhome : %s\n\naway : %s'%(vABSxhMgIqtWcfaCYiGLjXepbkKNVn,vABSxhMgIqtWcfaCYiGLjXepbkKNVQ,vABSxhMgIqtWcfaCYiGLjXepbkKNVE,vABSxhMgIqtWcfaCYiGLjXepbkKNVT,vABSxhMgIqtWcfaCYiGLjXepbkKNVl,vABSxhMgIqtWcfaCYiGLjXepbkKNPd)
     else:
      vABSxhMgIqtWcfaCYiGLjXepbkKNPV ='%s\n - %s (%s)\n - %s\n\nhome : %s (Score %s)\n\naway : %s (Score %s)'%(vABSxhMgIqtWcfaCYiGLjXepbkKNVn,vABSxhMgIqtWcfaCYiGLjXepbkKNVQ,vABSxhMgIqtWcfaCYiGLjXepbkKNVE,vABSxhMgIqtWcfaCYiGLjXepbkKNVT,vABSxhMgIqtWcfaCYiGLjXepbkKNVl,vABSxhMgIqtWcfaCYiGLjXepbkKNPw,vABSxhMgIqtWcfaCYiGLjXepbkKNPd,vABSxhMgIqtWcfaCYiGLjXepbkKNPz)
     vABSxhMgIqtWcfaCYiGLjXepbkKNPF=vABSxhMgIqtWcfaCYiGLjXepbkKNPV
     vABSxhMgIqtWcfaCYiGLjXepbkKNPJ =vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['replayVod']['count']
     vABSxhMgIqtWcfaCYiGLjXepbkKNPy=vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['highlightVod']['count']
     vABSxhMgIqtWcfaCYiGLjXepbkKNPR =vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['vods']['count']
     vABSxhMgIqtWcfaCYiGLjXepbkKNVH='' 
     vABSxhMgIqtWcfaCYiGLjXepbkKNPO=vABSxhMgIqtWcfaCYiGLjXepbkKNPJ+vABSxhMgIqtWcfaCYiGLjXepbkKNPy+vABSxhMgIqtWcfaCYiGLjXepbkKNPR
     if vABSxhMgIqtWcfaCYiGLjXepbkKNPO==0:
      if vABSxhMgIqtWcfaCYiGLjXepbkKNVm=='2':
       vABSxhMgIqtWcfaCYiGLjXepbkKNzJ='----- %s -----'%(vABSxhMgIqtWcfaCYiGLjXepbkKNVQ)
       vABSxhMgIqtWcfaCYiGLjXepbkKNVT=''
      else:
       vABSxhMgIqtWcfaCYiGLjXepbkKNzJ+=' - 관련영상 없음'
       vABSxhMgIqtWcfaCYiGLjXepbkKNPF+='\n\n ** 관련영상 없음 **'
     else:
      if vABSxhMgIqtWcfaCYiGLjXepbkKNPJ!=0:
       vABSxhMgIqtWcfaCYiGLjXepbkKNVH =vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['replayVod']['list'][0]['imgUrl']
      elif vABSxhMgIqtWcfaCYiGLjXepbkKNPy!=0:
       vABSxhMgIqtWcfaCYiGLjXepbkKNVH =vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['highlightVod']['list'][0]['imgUrl']
      else:
       vABSxhMgIqtWcfaCYiGLjXepbkKNVH =vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['vods']['list'][0]['imgUrl']
     vABSxhMgIqtWcfaCYiGLjXepbkKNwy={'gameTitle':vABSxhMgIqtWcfaCYiGLjXepbkKNzJ,'gameId':vABSxhMgIqtWcfaCYiGLjXepbkKNVr,'beginDate':vABSxhMgIqtWcfaCYiGLjXepbkKNVT[:11],'thumbnail':vABSxhMgIqtWcfaCYiGLjXepbkKNVH,'info_plot':vABSxhMgIqtWcfaCYiGLjXepbkKNPF,'leaguenm':vABSxhMgIqtWcfaCYiGLjXepbkKNVn,'seasonnm':vABSxhMgIqtWcfaCYiGLjXepbkKNVQ,'roundnm':vABSxhMgIqtWcfaCYiGLjXepbkKNVE,'totVodCnt':vABSxhMgIqtWcfaCYiGLjXepbkKNPO}
     vABSxhMgIqtWcfaCYiGLjXepbkKNwP.append(vABSxhMgIqtWcfaCYiGLjXepbkKNwy)
   if vABSxhMgIqtWcfaCYiGLjXepbkKNVm=='2':
    if vABSxhMgIqtWcfaCYiGLjXepbkKNdn['count']>page_int*vABSxhMgIqtWcfaCYiGLjXepbkKNdF.GAMELIST_LIMIT:vABSxhMgIqtWcfaCYiGLjXepbkKNVU=vABSxhMgIqtWcfaCYiGLjXepbkKNPr
   else:
    if vABSxhMgIqtWcfaCYiGLjXepbkKNdn['list'][0]['count']>page_int*vABSxhMgIqtWcfaCYiGLjXepbkKNdF.GAMELIST_LIMIT:vABSxhMgIqtWcfaCYiGLjXepbkKNVU=vABSxhMgIqtWcfaCYiGLjXepbkKNPr
  except vABSxhMgIqtWcfaCYiGLjXepbkKNPn as exception:
   vABSxhMgIqtWcfaCYiGLjXepbkKNPs(exception)
  return vABSxhMgIqtWcfaCYiGLjXepbkKNwP,vABSxhMgIqtWcfaCYiGLjXepbkKNVU
 def GetGameVodList(vABSxhMgIqtWcfaCYiGLjXepbkKNdF,vABSxhMgIqtWcfaCYiGLjXepbkKNVr):
  vABSxhMgIqtWcfaCYiGLjXepbkKNwP=[]
  vABSxhMgIqtWcfaCYiGLjXepbkKNPH=''
  try:
   vABSxhMgIqtWcfaCYiGLjXepbkKNwR=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.API_DOMAIN+'/api/v2/vod/game'
   vABSxhMgIqtWcfaCYiGLjXepbkKNVD={'gameId':vABSxhMgIqtWcfaCYiGLjXepbkKNVr,'pageItem':'1000'}
   vABSxhMgIqtWcfaCYiGLjXepbkKNds=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.callRequestCookies('Get',vABSxhMgIqtWcfaCYiGLjXepbkKNwR,payload=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,params=vABSxhMgIqtWcfaCYiGLjXepbkKNVD,headers=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,cookies=vABSxhMgIqtWcfaCYiGLjXepbkKNPD)
   vABSxhMgIqtWcfaCYiGLjXepbkKNdn=json.loads(vABSxhMgIqtWcfaCYiGLjXepbkKNds.text)
   vABSxhMgIqtWcfaCYiGLjXepbkKNVs=vABSxhMgIqtWcfaCYiGLjXepbkKNdn['list']
   for vABSxhMgIqtWcfaCYiGLjXepbkKNwJ in vABSxhMgIqtWcfaCYiGLjXepbkKNVs:
    vABSxhMgIqtWcfaCYiGLjXepbkKNVy =vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['title']
    vABSxhMgIqtWcfaCYiGLjXepbkKNVR =vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['id']
    vABSxhMgIqtWcfaCYiGLjXepbkKNVO =vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['vtype']
    vABSxhMgIqtWcfaCYiGLjXepbkKNVH =vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['imgUrl']
    vABSxhMgIqtWcfaCYiGLjXepbkKNVo =vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['vtypeId']
    vABSxhMgIqtWcfaCYiGLjXepbkKNwy={'vodTitle':vABSxhMgIqtWcfaCYiGLjXepbkKNVy,'vodId':vABSxhMgIqtWcfaCYiGLjXepbkKNVR,'vodType':vABSxhMgIqtWcfaCYiGLjXepbkKNVO,'thumbnail':vABSxhMgIqtWcfaCYiGLjXepbkKNVH,'vtypeId':vABSxhMgIqtWcfaCYiGLjXepbkKNPT(vABSxhMgIqtWcfaCYiGLjXepbkKNVo),'duration':vABSxhMgIqtWcfaCYiGLjXepbkKNPQ(vABSxhMgIqtWcfaCYiGLjXepbkKNwJ['duration']/1000)}
    vABSxhMgIqtWcfaCYiGLjXepbkKNwP.append(vABSxhMgIqtWcfaCYiGLjXepbkKNwy)
  except vABSxhMgIqtWcfaCYiGLjXepbkKNPn as exception:
   vABSxhMgIqtWcfaCYiGLjXepbkKNPs(exception)
  return vABSxhMgIqtWcfaCYiGLjXepbkKNwP
 def GetReplay_UrlId(vABSxhMgIqtWcfaCYiGLjXepbkKNdF,vABSxhMgIqtWcfaCYiGLjXepbkKNPH,vABSxhMgIqtWcfaCYiGLjXepbkKNVo):
  vABSxhMgIqtWcfaCYiGLjXepbkKNPo=vABSxhMgIqtWcfaCYiGLjXepbkKNzy=''
  vABSxhMgIqtWcfaCYiGLjXepbkKNPu=''
  try:
   vABSxhMgIqtWcfaCYiGLjXepbkKNwR=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.API_DOMAIN+'/api/v2/vod/'+vABSxhMgIqtWcfaCYiGLjXepbkKNPH
   vABSxhMgIqtWcfaCYiGLjXepbkKNds=vABSxhMgIqtWcfaCYiGLjXepbkKNdF.callRequestCookies('Get',vABSxhMgIqtWcfaCYiGLjXepbkKNwR,payload=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,params=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,headers=vABSxhMgIqtWcfaCYiGLjXepbkKNPD,cookies=vABSxhMgIqtWcfaCYiGLjXepbkKNPD)
   vABSxhMgIqtWcfaCYiGLjXepbkKNdn=json.loads(vABSxhMgIqtWcfaCYiGLjXepbkKNds.text)
   vABSxhMgIqtWcfaCYiGLjXepbkKNPo =vABSxhMgIqtWcfaCYiGLjXepbkKNdn['clipId']
   vABSxhMgIqtWcfaCYiGLjXepbkKNzy=vABSxhMgIqtWcfaCYiGLjXepbkKNdn['videoId']
   vABSxhMgIqtWcfaCYiGLjXepbkKNPu=vABSxhMgIqtWcfaCYiGLjXepbkKNPo
   if vABSxhMgIqtWcfaCYiGLjXepbkKNdF.CheckSubEnd()or vABSxhMgIqtWcfaCYiGLjXepbkKNVo!='1':vABSxhMgIqtWcfaCYiGLjXepbkKNPu=vABSxhMgIqtWcfaCYiGLjXepbkKNzy 
  except vABSxhMgIqtWcfaCYiGLjXepbkKNPn as exception:
   vABSxhMgIqtWcfaCYiGLjXepbkKNPs(exception)
  return vABSxhMgIqtWcfaCYiGLjXepbkKNPu
# Created by pyminifier (https://github.com/liftoff/pyminifier)
