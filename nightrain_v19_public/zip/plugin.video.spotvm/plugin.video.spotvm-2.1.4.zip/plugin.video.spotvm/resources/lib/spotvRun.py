__author__="NightRain"
icfOCslbhXLGrIpAzgQEqWwyotBjdD=object
icfOCslbhXLGrIpAzgQEqWwyotBjda=None
icfOCslbhXLGrIpAzgQEqWwyotBjdN=False
icfOCslbhXLGrIpAzgQEqWwyotBjdx=True
icfOCslbhXLGrIpAzgQEqWwyotBjdU=int
icfOCslbhXLGrIpAzgQEqWwyotBjdv=len
icfOCslbhXLGrIpAzgQEqWwyotBjdP=str
icfOCslbhXLGrIpAzgQEqWwyotBjdY=open
icfOCslbhXLGrIpAzgQEqWwyotBjdF=Exception
icfOCslbhXLGrIpAzgQEqWwyotBjdm=print
icfOCslbhXLGrIpAzgQEqWwyotBjdK=dict
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
icfOCslbhXLGrIpAzgQEqWwyotBjnM=[{'title':'TV 채널 (유료사용자만 지원)','mode':'LIVE_GROUP'},{'title':'Live중계 (독점,현지)','mode':'ELIVE_GROUP'},{'title':'-----------------','mode':'XXX'},{'title':'인기영상5','mode':'POP_GROUP'},{'title':'VOD 영상','mode':'VOD_GROUP'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH'}]
icfOCslbhXLGrIpAzgQEqWwyotBjnu=xbmcvfs.translatePath(os.path.join(__profile__,'spotv_cookies.json'))
from spotvCore import*
class icfOCslbhXLGrIpAzgQEqWwyotBjnJ(icfOCslbhXLGrIpAzgQEqWwyotBjdD):
 def __init__(icfOCslbhXLGrIpAzgQEqWwyotBjnd,icfOCslbhXLGrIpAzgQEqWwyotBjnH,icfOCslbhXLGrIpAzgQEqWwyotBjnR,icfOCslbhXLGrIpAzgQEqWwyotBjnT):
  icfOCslbhXLGrIpAzgQEqWwyotBjnd._addon_url =icfOCslbhXLGrIpAzgQEqWwyotBjnH
  icfOCslbhXLGrIpAzgQEqWwyotBjnd._addon_handle=icfOCslbhXLGrIpAzgQEqWwyotBjnR
  icfOCslbhXLGrIpAzgQEqWwyotBjnd.main_params =icfOCslbhXLGrIpAzgQEqWwyotBjnT
  icfOCslbhXLGrIpAzgQEqWwyotBjnd.SpotvObj =vABSxhMgIqtWcfaCYiGLjXepbkKNdw() 
 def addon_noti(icfOCslbhXLGrIpAzgQEqWwyotBjnd,sting):
  try:
   icfOCslbhXLGrIpAzgQEqWwyotBjna=xbmcgui.Dialog()
   icfOCslbhXLGrIpAzgQEqWwyotBjna.notification(__addonname__,sting)
  except:
   icfOCslbhXLGrIpAzgQEqWwyotBjda
 def addon_log(icfOCslbhXLGrIpAzgQEqWwyotBjnd,string):
  try:
   icfOCslbhXLGrIpAzgQEqWwyotBjnN=string.encode('utf-8','ignore')
  except:
   icfOCslbhXLGrIpAzgQEqWwyotBjnN='addonException: addon_log'
  icfOCslbhXLGrIpAzgQEqWwyotBjnx=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,icfOCslbhXLGrIpAzgQEqWwyotBjnN),level=icfOCslbhXLGrIpAzgQEqWwyotBjnx)
 def get_keyboard_input(icfOCslbhXLGrIpAzgQEqWwyotBjnd,icfOCslbhXLGrIpAzgQEqWwyotBjnk):
  icfOCslbhXLGrIpAzgQEqWwyotBjnU=icfOCslbhXLGrIpAzgQEqWwyotBjda
  kb=xbmc.Keyboard()
  kb.setHeading(icfOCslbhXLGrIpAzgQEqWwyotBjnk)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   icfOCslbhXLGrIpAzgQEqWwyotBjnU=kb.getText()
  return icfOCslbhXLGrIpAzgQEqWwyotBjnU
 def get_settings_login_info(icfOCslbhXLGrIpAzgQEqWwyotBjnd):
  icfOCslbhXLGrIpAzgQEqWwyotBjnv =__addon__.getSetting('id')
  icfOCslbhXLGrIpAzgQEqWwyotBjnP =__addon__.getSetting('pw')
  return(icfOCslbhXLGrIpAzgQEqWwyotBjnv,icfOCslbhXLGrIpAzgQEqWwyotBjnP)
 def get_settings_hidescoreyn(icfOCslbhXLGrIpAzgQEqWwyotBjnd):
  icfOCslbhXLGrIpAzgQEqWwyotBjnY =__addon__.getSetting('hidescore')
  if icfOCslbhXLGrIpAzgQEqWwyotBjnY=='false':
   return icfOCslbhXLGrIpAzgQEqWwyotBjdN
  else:
   return icfOCslbhXLGrIpAzgQEqWwyotBjdx
 def set_winCredential(icfOCslbhXLGrIpAzgQEqWwyotBjnd,credential):
  icfOCslbhXLGrIpAzgQEqWwyotBjnF=xbmcgui.Window(10000)
  icfOCslbhXLGrIpAzgQEqWwyotBjnF.setProperty('SPOTV_M_SESSIONID',credential.get('spotv_sessionid'))
  icfOCslbhXLGrIpAzgQEqWwyotBjnF.setProperty('SPOTV_M_SESSION',credential.get('spotv_session'))
  icfOCslbhXLGrIpAzgQEqWwyotBjnF.setProperty('SPOTV_M_ACCOUNTID',credential.get('spotv_accountId'))
  icfOCslbhXLGrIpAzgQEqWwyotBjnF.setProperty('SPOTV_M_POLICYKEY',credential.get('spotv_policyKey'))
  icfOCslbhXLGrIpAzgQEqWwyotBjnF.setProperty('SPOTV_M_SUBEND',credential.get('spotv_subend'))
  icfOCslbhXLGrIpAzgQEqWwyotBjnF.setProperty('SPOTV_M_LOGINTIME',icfOCslbhXLGrIpAzgQEqWwyotBjnd.SpotvObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(icfOCslbhXLGrIpAzgQEqWwyotBjnd):
  icfOCslbhXLGrIpAzgQEqWwyotBjnF=xbmcgui.Window(10000)
  icfOCslbhXLGrIpAzgQEqWwyotBjnm={'spotv_sessionid':icfOCslbhXLGrIpAzgQEqWwyotBjnF.getProperty('SPOTV_M_SESSIONID'),'spotv_session':icfOCslbhXLGrIpAzgQEqWwyotBjnF.getProperty('SPOTV_M_SESSION'),'spotv_accountId':icfOCslbhXLGrIpAzgQEqWwyotBjnF.getProperty('SPOTV_M_ACCOUNTID'),'spotv_policyKey':icfOCslbhXLGrIpAzgQEqWwyotBjnF.getProperty('SPOTV_M_POLICYKEY'),'spotv_subend':icfOCslbhXLGrIpAzgQEqWwyotBjnF.getProperty('SPOTV_M_SUBEND')}
  return icfOCslbhXLGrIpAzgQEqWwyotBjnm
 def add_dir(icfOCslbhXLGrIpAzgQEqWwyotBjnd,label,sublabel='',img='',infoLabels=icfOCslbhXLGrIpAzgQEqWwyotBjda,isFolder=icfOCslbhXLGrIpAzgQEqWwyotBjdx,params=''):
  icfOCslbhXLGrIpAzgQEqWwyotBjnK='%s?%s'%(icfOCslbhXLGrIpAzgQEqWwyotBjnd._addon_url,urllib.parse.urlencode(params))
  if sublabel:icfOCslbhXLGrIpAzgQEqWwyotBjnk='%s < %s >'%(label,sublabel)
  else: icfOCslbhXLGrIpAzgQEqWwyotBjnk=label
  if not img:img='DefaultFolder.png'
  icfOCslbhXLGrIpAzgQEqWwyotBjnS=xbmcgui.ListItem(icfOCslbhXLGrIpAzgQEqWwyotBjnk)
  icfOCslbhXLGrIpAzgQEqWwyotBjnS.setArt({'thumb':img,'icon':img,'poster':img})
  if infoLabels:icfOCslbhXLGrIpAzgQEqWwyotBjnS.setInfo(type="Video",infoLabels=infoLabels)
  if not isFolder:icfOCslbhXLGrIpAzgQEqWwyotBjnS.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(icfOCslbhXLGrIpAzgQEqWwyotBjnd._addon_handle,icfOCslbhXLGrIpAzgQEqWwyotBjnK,icfOCslbhXLGrIpAzgQEqWwyotBjnS,isFolder)
 def get_selQuality(icfOCslbhXLGrIpAzgQEqWwyotBjnd,etype):
  try:
   icfOCslbhXLGrIpAzgQEqWwyotBjnV='selected_quality'
   icfOCslbhXLGrIpAzgQEqWwyotBjne=[1080,720,540]
   icfOCslbhXLGrIpAzgQEqWwyotBjJn=icfOCslbhXLGrIpAzgQEqWwyotBjdU(__addon__.getSetting(icfOCslbhXLGrIpAzgQEqWwyotBjnV))
   return icfOCslbhXLGrIpAzgQEqWwyotBjne[icfOCslbhXLGrIpAzgQEqWwyotBjJn]
  except:
   icfOCslbhXLGrIpAzgQEqWwyotBjda
  return 1080 
 def dp_Main_List(icfOCslbhXLGrIpAzgQEqWwyotBjnd):
  for icfOCslbhXLGrIpAzgQEqWwyotBjJM in icfOCslbhXLGrIpAzgQEqWwyotBjnM:
   icfOCslbhXLGrIpAzgQEqWwyotBjnk=icfOCslbhXLGrIpAzgQEqWwyotBjJM.get('title')
   icfOCslbhXLGrIpAzgQEqWwyotBjJu={'mode':icfOCslbhXLGrIpAzgQEqWwyotBjJM.get('mode')}
   if icfOCslbhXLGrIpAzgQEqWwyotBjJM.get('mode')=='XXX':
    icfOCslbhXLGrIpAzgQEqWwyotBjJd=icfOCslbhXLGrIpAzgQEqWwyotBjdN
   else:
    icfOCslbhXLGrIpAzgQEqWwyotBjJd=icfOCslbhXLGrIpAzgQEqWwyotBjdx
   icfOCslbhXLGrIpAzgQEqWwyotBjnd.add_dir(icfOCslbhXLGrIpAzgQEqWwyotBjnk,sublabel='',img='',infoLabels=icfOCslbhXLGrIpAzgQEqWwyotBjda,isFolder=icfOCslbhXLGrIpAzgQEqWwyotBjJd,params=icfOCslbhXLGrIpAzgQEqWwyotBjJu)
  if icfOCslbhXLGrIpAzgQEqWwyotBjdv(icfOCslbhXLGrIpAzgQEqWwyotBjnM)>0:xbmcplugin.endOfDirectory(icfOCslbhXLGrIpAzgQEqWwyotBjnd._addon_handle)
 def dp_MainLeague_List(icfOCslbhXLGrIpAzgQEqWwyotBjnd,args):
  icfOCslbhXLGrIpAzgQEqWwyotBjnd.SpotvObj.SaveCredential(icfOCslbhXLGrIpAzgQEqWwyotBjnd.get_winCredential())
  icfOCslbhXLGrIpAzgQEqWwyotBjJR=icfOCslbhXLGrIpAzgQEqWwyotBjnd.SpotvObj.GetTitleGroupList()
  for icfOCslbhXLGrIpAzgQEqWwyotBjJT in icfOCslbhXLGrIpAzgQEqWwyotBjJR:
   icfOCslbhXLGrIpAzgQEqWwyotBjnk =icfOCslbhXLGrIpAzgQEqWwyotBjJT.get('title')
   icfOCslbhXLGrIpAzgQEqWwyotBjJD =icfOCslbhXLGrIpAzgQEqWwyotBjJT.get('logo')
   icfOCslbhXLGrIpAzgQEqWwyotBjJa =icfOCslbhXLGrIpAzgQEqWwyotBjJT.get('reagueId')
   icfOCslbhXLGrIpAzgQEqWwyotBjJN =icfOCslbhXLGrIpAzgQEqWwyotBjJT.get('subGame')
   icfOCslbhXLGrIpAzgQEqWwyotBjJx={'mediatype':'episode','plot':'%s\n\n%s'%(icfOCslbhXLGrIpAzgQEqWwyotBjnk,icfOCslbhXLGrIpAzgQEqWwyotBjJN)}
   icfOCslbhXLGrIpAzgQEqWwyotBjJu={'mode':'LEAGUE_GROUP','reagueId':icfOCslbhXLGrIpAzgQEqWwyotBjJa}
   icfOCslbhXLGrIpAzgQEqWwyotBjnd.add_dir(icfOCslbhXLGrIpAzgQEqWwyotBjnk,sublabel=icfOCslbhXLGrIpAzgQEqWwyotBjda,img=icfOCslbhXLGrIpAzgQEqWwyotBjJD,infoLabels=icfOCslbhXLGrIpAzgQEqWwyotBjJx,isFolder=icfOCslbhXLGrIpAzgQEqWwyotBjdx,params=icfOCslbhXLGrIpAzgQEqWwyotBjJu)
  if icfOCslbhXLGrIpAzgQEqWwyotBjdv(icfOCslbhXLGrIpAzgQEqWwyotBjJR)>0:xbmcplugin.endOfDirectory(icfOCslbhXLGrIpAzgQEqWwyotBjnd._addon_handle,cacheToDisc=icfOCslbhXLGrIpAzgQEqWwyotBjdN)
 def dp_PopVod_GroupList(icfOCslbhXLGrIpAzgQEqWwyotBjnd,args):
  icfOCslbhXLGrIpAzgQEqWwyotBjnd.SpotvObj.SaveCredential(icfOCslbhXLGrIpAzgQEqWwyotBjnd.get_winCredential())
  icfOCslbhXLGrIpAzgQEqWwyotBjJR=icfOCslbhXLGrIpAzgQEqWwyotBjnd.SpotvObj.GetPopularGroupList()
  for icfOCslbhXLGrIpAzgQEqWwyotBjJT in icfOCslbhXLGrIpAzgQEqWwyotBjJR:
   icfOCslbhXLGrIpAzgQEqWwyotBjJU =icfOCslbhXLGrIpAzgQEqWwyotBjJT.get('vodTitle')
   icfOCslbhXLGrIpAzgQEqWwyotBjJv =icfOCslbhXLGrIpAzgQEqWwyotBjJT.get('vodId')
   icfOCslbhXLGrIpAzgQEqWwyotBjJP =icfOCslbhXLGrIpAzgQEqWwyotBjJT.get('vodType')
   icfOCslbhXLGrIpAzgQEqWwyotBjJD=icfOCslbhXLGrIpAzgQEqWwyotBjJT.get('thumbnail')
   icfOCslbhXLGrIpAzgQEqWwyotBjJY =icfOCslbhXLGrIpAzgQEqWwyotBjJT.get('vtypeId')
   icfOCslbhXLGrIpAzgQEqWwyotBjJF =icfOCslbhXLGrIpAzgQEqWwyotBjJT.get('duration')
   icfOCslbhXLGrIpAzgQEqWwyotBjJx={'mediatype':'video','duration':icfOCslbhXLGrIpAzgQEqWwyotBjJF,'plot':icfOCslbhXLGrIpAzgQEqWwyotBjJU}
   icfOCslbhXLGrIpAzgQEqWwyotBjJu={'mode':'POP_VOD','mediacode':icfOCslbhXLGrIpAzgQEqWwyotBjJv,'mediatype':'vod','vtypeId':icfOCslbhXLGrIpAzgQEqWwyotBjJY}
   icfOCslbhXLGrIpAzgQEqWwyotBjnd.add_dir(icfOCslbhXLGrIpAzgQEqWwyotBjJU,sublabel=icfOCslbhXLGrIpAzgQEqWwyotBjJP,img=icfOCslbhXLGrIpAzgQEqWwyotBjJD,infoLabels=icfOCslbhXLGrIpAzgQEqWwyotBjJx,isFolder=icfOCslbhXLGrIpAzgQEqWwyotBjdN,params=icfOCslbhXLGrIpAzgQEqWwyotBjJu)
  if icfOCslbhXLGrIpAzgQEqWwyotBjdv(icfOCslbhXLGrIpAzgQEqWwyotBjJR)>0:xbmcplugin.endOfDirectory(icfOCslbhXLGrIpAzgQEqWwyotBjnd._addon_handle,cacheToDisc=icfOCslbhXLGrIpAzgQEqWwyotBjdN)
 def dp_Season_List(icfOCslbhXLGrIpAzgQEqWwyotBjnd,args):
  icfOCslbhXLGrIpAzgQEqWwyotBjnd.SpotvObj.SaveCredential(icfOCslbhXLGrIpAzgQEqWwyotBjnd.get_winCredential())
  icfOCslbhXLGrIpAzgQEqWwyotBjJa=args.get('reagueId')
  icfOCslbhXLGrIpAzgQEqWwyotBjJR=icfOCslbhXLGrIpAzgQEqWwyotBjnd.SpotvObj.GetSeasonList(icfOCslbhXLGrIpAzgQEqWwyotBjJa)
  for icfOCslbhXLGrIpAzgQEqWwyotBjJT in icfOCslbhXLGrIpAzgQEqWwyotBjJR:
   icfOCslbhXLGrIpAzgQEqWwyotBjJm =icfOCslbhXLGrIpAzgQEqWwyotBjJT.get('reagueName')
   icfOCslbhXLGrIpAzgQEqWwyotBjJK =icfOCslbhXLGrIpAzgQEqWwyotBjJT.get('gameTypeId')
   icfOCslbhXLGrIpAzgQEqWwyotBjJk =icfOCslbhXLGrIpAzgQEqWwyotBjJT.get('seasonName')
   icfOCslbhXLGrIpAzgQEqWwyotBjJS =icfOCslbhXLGrIpAzgQEqWwyotBjJT.get('seasonId')
   icfOCslbhXLGrIpAzgQEqWwyotBjJx={'mediatype':'episode','plot':'%s - %s'%(icfOCslbhXLGrIpAzgQEqWwyotBjJm,icfOCslbhXLGrIpAzgQEqWwyotBjJk)}
   icfOCslbhXLGrIpAzgQEqWwyotBjJu={'mode':'SEASON_GROUP','reagueId':icfOCslbhXLGrIpAzgQEqWwyotBjJa,'seasonId':icfOCslbhXLGrIpAzgQEqWwyotBjJS,'gameTypeId':icfOCslbhXLGrIpAzgQEqWwyotBjJK,'page':'1'}
   icfOCslbhXLGrIpAzgQEqWwyotBjnd.add_dir(icfOCslbhXLGrIpAzgQEqWwyotBjJm,sublabel=icfOCslbhXLGrIpAzgQEqWwyotBjJk,img='',infoLabels=icfOCslbhXLGrIpAzgQEqWwyotBjJx,isFolder=icfOCslbhXLGrIpAzgQEqWwyotBjdx,params=icfOCslbhXLGrIpAzgQEqWwyotBjJu)
  if icfOCslbhXLGrIpAzgQEqWwyotBjdv(icfOCslbhXLGrIpAzgQEqWwyotBjJR)>0:xbmcplugin.endOfDirectory(icfOCslbhXLGrIpAzgQEqWwyotBjnd._addon_handle,cacheToDisc=icfOCslbhXLGrIpAzgQEqWwyotBjdx)
 def dp_Game_List(icfOCslbhXLGrIpAzgQEqWwyotBjnd,args):
  icfOCslbhXLGrIpAzgQEqWwyotBjnd.SpotvObj.SaveCredential(icfOCslbhXLGrIpAzgQEqWwyotBjnd.get_winCredential())
  icfOCslbhXLGrIpAzgQEqWwyotBjJK=args.get('gameTypeId')
  icfOCslbhXLGrIpAzgQEqWwyotBjJa =args.get('reagueId')
  icfOCslbhXLGrIpAzgQEqWwyotBjJS =args.get('seasonId')
  icfOCslbhXLGrIpAzgQEqWwyotBjJV =icfOCslbhXLGrIpAzgQEqWwyotBjdU(args.get('page'))
  icfOCslbhXLGrIpAzgQEqWwyotBjJR,icfOCslbhXLGrIpAzgQEqWwyotBjJe=icfOCslbhXLGrIpAzgQEqWwyotBjnd.SpotvObj.GetGameList(icfOCslbhXLGrIpAzgQEqWwyotBjJK,icfOCslbhXLGrIpAzgQEqWwyotBjJa,icfOCslbhXLGrIpAzgQEqWwyotBjJS,icfOCslbhXLGrIpAzgQEqWwyotBjJV,hidescore=icfOCslbhXLGrIpAzgQEqWwyotBjnd.get_settings_hidescoreyn())
  for icfOCslbhXLGrIpAzgQEqWwyotBjJT in icfOCslbhXLGrIpAzgQEqWwyotBjJR:
   icfOCslbhXLGrIpAzgQEqWwyotBjMn =icfOCslbhXLGrIpAzgQEqWwyotBjJT.get('gameTitle')
   icfOCslbhXLGrIpAzgQEqWwyotBjMJ =icfOCslbhXLGrIpAzgQEqWwyotBjJT.get('beginDate')
   icfOCslbhXLGrIpAzgQEqWwyotBjJD =icfOCslbhXLGrIpAzgQEqWwyotBjJT.get('thumbnail')
   icfOCslbhXLGrIpAzgQEqWwyotBjMu =icfOCslbhXLGrIpAzgQEqWwyotBjJT.get('gameId')
   icfOCslbhXLGrIpAzgQEqWwyotBjMd =icfOCslbhXLGrIpAzgQEqWwyotBjJT.get('totVodCnt')
   icfOCslbhXLGrIpAzgQEqWwyotBjMH =icfOCslbhXLGrIpAzgQEqWwyotBjJT.get('leaguenm')
   icfOCslbhXLGrIpAzgQEqWwyotBjMR =icfOCslbhXLGrIpAzgQEqWwyotBjJT.get('seasonnm')
   icfOCslbhXLGrIpAzgQEqWwyotBjMT =icfOCslbhXLGrIpAzgQEqWwyotBjJT.get('roundnm')
   icfOCslbhXLGrIpAzgQEqWwyotBjMD =icfOCslbhXLGrIpAzgQEqWwyotBjJT.get('info_plot')
   icfOCslbhXLGrIpAzgQEqWwyotBjMa ='%s < %s >'%(icfOCslbhXLGrIpAzgQEqWwyotBjMn,icfOCslbhXLGrIpAzgQEqWwyotBjMJ)
   icfOCslbhXLGrIpAzgQEqWwyotBjJx={'mediatype':'video','plot':icfOCslbhXLGrIpAzgQEqWwyotBjMD}
   icfOCslbhXLGrIpAzgQEqWwyotBjJu={'mode':'GAME_VOD_GROUP' if icfOCslbhXLGrIpAzgQEqWwyotBjMd!=0 else 'XXX','saveTitle':icfOCslbhXLGrIpAzgQEqWwyotBjMa,'saveImg':icfOCslbhXLGrIpAzgQEqWwyotBjJD,'saveInfo':icfOCslbhXLGrIpAzgQEqWwyotBjJx['plot'],'gameid':icfOCslbhXLGrIpAzgQEqWwyotBjMu}
   icfOCslbhXLGrIpAzgQEqWwyotBjnd.add_dir(icfOCslbhXLGrIpAzgQEqWwyotBjMn,sublabel=icfOCslbhXLGrIpAzgQEqWwyotBjMJ,img=icfOCslbhXLGrIpAzgQEqWwyotBjJD,infoLabels=icfOCslbhXLGrIpAzgQEqWwyotBjJx,isFolder=icfOCslbhXLGrIpAzgQEqWwyotBjdx,params=icfOCslbhXLGrIpAzgQEqWwyotBjJu)
  if icfOCslbhXLGrIpAzgQEqWwyotBjJe:
   icfOCslbhXLGrIpAzgQEqWwyotBjJu['mode'] ='SEASON_GROUP' 
   icfOCslbhXLGrIpAzgQEqWwyotBjJu['reagueId'] =icfOCslbhXLGrIpAzgQEqWwyotBjJa
   icfOCslbhXLGrIpAzgQEqWwyotBjJu['seasonId'] =icfOCslbhXLGrIpAzgQEqWwyotBjJS
   icfOCslbhXLGrIpAzgQEqWwyotBjJu['gameTypeId']=icfOCslbhXLGrIpAzgQEqWwyotBjJK
   icfOCslbhXLGrIpAzgQEqWwyotBjJu['page'] =icfOCslbhXLGrIpAzgQEqWwyotBjdP(icfOCslbhXLGrIpAzgQEqWwyotBjJV+1)
   icfOCslbhXLGrIpAzgQEqWwyotBjnk='[B]%s >>[/B]'%'다음 페이지'
   icfOCslbhXLGrIpAzgQEqWwyotBjMN=icfOCslbhXLGrIpAzgQEqWwyotBjdP(icfOCslbhXLGrIpAzgQEqWwyotBjJV+1)
   icfOCslbhXLGrIpAzgQEqWwyotBjnd.add_dir(icfOCslbhXLGrIpAzgQEqWwyotBjnk,sublabel=icfOCslbhXLGrIpAzgQEqWwyotBjMN,img='',infoLabels=icfOCslbhXLGrIpAzgQEqWwyotBjda,isFolder=icfOCslbhXLGrIpAzgQEqWwyotBjdx,params=icfOCslbhXLGrIpAzgQEqWwyotBjJu)
  if icfOCslbhXLGrIpAzgQEqWwyotBjdv(icfOCslbhXLGrIpAzgQEqWwyotBjJR)>0:xbmcplugin.endOfDirectory(icfOCslbhXLGrIpAzgQEqWwyotBjnd._addon_handle,cacheToDisc=icfOCslbhXLGrIpAzgQEqWwyotBjdN)
 def dp_GameVod_List(icfOCslbhXLGrIpAzgQEqWwyotBjnd,args):
  icfOCslbhXLGrIpAzgQEqWwyotBjnd.SpotvObj.SaveCredential(icfOCslbhXLGrIpAzgQEqWwyotBjnd.get_winCredential())
  icfOCslbhXLGrIpAzgQEqWwyotBjMx =args.get('gameid')
  icfOCslbhXLGrIpAzgQEqWwyotBjMa=args.get('saveTitle')
  icfOCslbhXLGrIpAzgQEqWwyotBjMU =args.get('saveImg')
  icfOCslbhXLGrIpAzgQEqWwyotBjMv =args.get('saveInfo')
  icfOCslbhXLGrIpAzgQEqWwyotBjJR=icfOCslbhXLGrIpAzgQEqWwyotBjnd.SpotvObj.GetGameVodList(icfOCslbhXLGrIpAzgQEqWwyotBjMx)
  for icfOCslbhXLGrIpAzgQEqWwyotBjJT in icfOCslbhXLGrIpAzgQEqWwyotBjJR:
   icfOCslbhXLGrIpAzgQEqWwyotBjJU =icfOCslbhXLGrIpAzgQEqWwyotBjJT.get('vodTitle')
   icfOCslbhXLGrIpAzgQEqWwyotBjJv =icfOCslbhXLGrIpAzgQEqWwyotBjJT.get('vodId')
   icfOCslbhXLGrIpAzgQEqWwyotBjJP =icfOCslbhXLGrIpAzgQEqWwyotBjJT.get('vodType')
   icfOCslbhXLGrIpAzgQEqWwyotBjJD=icfOCslbhXLGrIpAzgQEqWwyotBjJT.get('thumbnail')
   icfOCslbhXLGrIpAzgQEqWwyotBjJY =icfOCslbhXLGrIpAzgQEqWwyotBjJT.get('vtypeId')
   icfOCslbhXLGrIpAzgQEqWwyotBjJF =icfOCslbhXLGrIpAzgQEqWwyotBjJT.get('duration')
   icfOCslbhXLGrIpAzgQEqWwyotBjJx={'mediatype':'video','duration':icfOCslbhXLGrIpAzgQEqWwyotBjJF,'plot':'%s \n\n %s'%(icfOCslbhXLGrIpAzgQEqWwyotBjJU,icfOCslbhXLGrIpAzgQEqWwyotBjMv)}
   icfOCslbhXLGrIpAzgQEqWwyotBjJu={'mode':'GAME_VOD','saveTitle':icfOCslbhXLGrIpAzgQEqWwyotBjMa,'saveImg':icfOCslbhXLGrIpAzgQEqWwyotBjMU,'saveId':icfOCslbhXLGrIpAzgQEqWwyotBjMx,'saveInfo':icfOCslbhXLGrIpAzgQEqWwyotBjMv,'mediacode':icfOCslbhXLGrIpAzgQEqWwyotBjJv,'mediatype':'vod','vtypeId':icfOCslbhXLGrIpAzgQEqWwyotBjJY}
   icfOCslbhXLGrIpAzgQEqWwyotBjnd.add_dir(icfOCslbhXLGrIpAzgQEqWwyotBjJU,sublabel=icfOCslbhXLGrIpAzgQEqWwyotBjJP,img=icfOCslbhXLGrIpAzgQEqWwyotBjJD,infoLabels=icfOCslbhXLGrIpAzgQEqWwyotBjJx,isFolder=icfOCslbhXLGrIpAzgQEqWwyotBjdN,params=icfOCslbhXLGrIpAzgQEqWwyotBjJu)
  if icfOCslbhXLGrIpAzgQEqWwyotBjdv(icfOCslbhXLGrIpAzgQEqWwyotBjJR)>0:xbmcplugin.endOfDirectory(icfOCslbhXLGrIpAzgQEqWwyotBjnd._addon_handle,cacheToDisc=icfOCslbhXLGrIpAzgQEqWwyotBjdN)
 def login_main(icfOCslbhXLGrIpAzgQEqWwyotBjnd):
  (icfOCslbhXLGrIpAzgQEqWwyotBjMP,icfOCslbhXLGrIpAzgQEqWwyotBjMY)=icfOCslbhXLGrIpAzgQEqWwyotBjnd.get_settings_login_info()
  if not(icfOCslbhXLGrIpAzgQEqWwyotBjMP and icfOCslbhXLGrIpAzgQEqWwyotBjMY):
   icfOCslbhXLGrIpAzgQEqWwyotBjna=xbmcgui.Dialog()
   icfOCslbhXLGrIpAzgQEqWwyotBjMF=icfOCslbhXLGrIpAzgQEqWwyotBjna.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if icfOCslbhXLGrIpAzgQEqWwyotBjMF==icfOCslbhXLGrIpAzgQEqWwyotBjdx:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if icfOCslbhXLGrIpAzgQEqWwyotBjnd.cookiefile_check():return
  icfOCslbhXLGrIpAzgQEqWwyotBjMm =icfOCslbhXLGrIpAzgQEqWwyotBjdU(icfOCslbhXLGrIpAzgQEqWwyotBjnd.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))
  icfOCslbhXLGrIpAzgQEqWwyotBjMK=xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINTIME')
  if icfOCslbhXLGrIpAzgQEqWwyotBjMK==icfOCslbhXLGrIpAzgQEqWwyotBjda or icfOCslbhXLGrIpAzgQEqWwyotBjMK=='':
   icfOCslbhXLGrIpAzgQEqWwyotBjMK=icfOCslbhXLGrIpAzgQEqWwyotBjdU('19000101')
  else:
   icfOCslbhXLGrIpAzgQEqWwyotBjMK=icfOCslbhXLGrIpAzgQEqWwyotBjdU(re.sub('-','',icfOCslbhXLGrIpAzgQEqWwyotBjMK))
  if xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINWAIT')=='TRUE':
   icfOCslbhXLGrIpAzgQEqWwyotBjMk=0
   while icfOCslbhXLGrIpAzgQEqWwyotBjdx:
    icfOCslbhXLGrIpAzgQEqWwyotBjMk+=1
    time.sleep(0.05)
    if icfOCslbhXLGrIpAzgQEqWwyotBjMK>=icfOCslbhXLGrIpAzgQEqWwyotBjMm:return
    if icfOCslbhXLGrIpAzgQEqWwyotBjMk>600:return
  else:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','TRUE')
  if icfOCslbhXLGrIpAzgQEqWwyotBjMK>=icfOCslbhXLGrIpAzgQEqWwyotBjMm:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
   return
  if not icfOCslbhXLGrIpAzgQEqWwyotBjnd.SpotvObj.GetCredential(icfOCslbhXLGrIpAzgQEqWwyotBjMP,icfOCslbhXLGrIpAzgQEqWwyotBjMY):
   icfOCslbhXLGrIpAzgQEqWwyotBjnd.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
   sys.exit()
  icfOCslbhXLGrIpAzgQEqWwyotBjnd.set_winCredential(icfOCslbhXLGrIpAzgQEqWwyotBjnd.SpotvObj.LoadCredential())
  icfOCslbhXLGrIpAzgQEqWwyotBjnd.cookiefile_save()
  xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
 def dp_LiveChannel_List(icfOCslbhXLGrIpAzgQEqWwyotBjnd,args):
  icfOCslbhXLGrIpAzgQEqWwyotBjnd.SpotvObj.SaveCredential(icfOCslbhXLGrIpAzgQEqWwyotBjnd.get_winCredential())
  icfOCslbhXLGrIpAzgQEqWwyotBjMS=icfOCslbhXLGrIpAzgQEqWwyotBjnd.SpotvObj.GetLiveChannelList()
  for icfOCslbhXLGrIpAzgQEqWwyotBjMV in icfOCslbhXLGrIpAzgQEqWwyotBjMS:
   icfOCslbhXLGrIpAzgQEqWwyotBjnk =icfOCslbhXLGrIpAzgQEqWwyotBjMV.get('name')
   icfOCslbhXLGrIpAzgQEqWwyotBjJD =icfOCslbhXLGrIpAzgQEqWwyotBjMV.get('logo')
   icfOCslbhXLGrIpAzgQEqWwyotBjMe=icfOCslbhXLGrIpAzgQEqWwyotBjMV.get('channelepg')
   icfOCslbhXLGrIpAzgQEqWwyotBjun =icfOCslbhXLGrIpAzgQEqWwyotBjMV.get('free')
   if icfOCslbhXLGrIpAzgQEqWwyotBjMe:
    icfOCslbhXLGrIpAzgQEqWwyotBjuJ =icfOCslbhXLGrIpAzgQEqWwyotBjMe['epg']
    icfOCslbhXLGrIpAzgQEqWwyotBjuM=icfOCslbhXLGrIpAzgQEqWwyotBjMe['title']
   else:
    icfOCslbhXLGrIpAzgQEqWwyotBjuJ =''
    icfOCslbhXLGrIpAzgQEqWwyotBjuM=''
   icfOCslbhXLGrIpAzgQEqWwyotBjJx={'plot':'%s\n\n%s'%(icfOCslbhXLGrIpAzgQEqWwyotBjnk,icfOCslbhXLGrIpAzgQEqWwyotBjuJ),'mediatype':'video'}
   icfOCslbhXLGrIpAzgQEqWwyotBjJu={'mode':'LIVE','mediacode':icfOCslbhXLGrIpAzgQEqWwyotBjMV.get('videoId'),'free':icfOCslbhXLGrIpAzgQEqWwyotBjun,'mediatype':'live'}
   if icfOCslbhXLGrIpAzgQEqWwyotBjun:icfOCslbhXLGrIpAzgQEqWwyotBjnk+=' [free]'
   icfOCslbhXLGrIpAzgQEqWwyotBjnd.add_dir(icfOCslbhXLGrIpAzgQEqWwyotBjnk,sublabel=icfOCslbhXLGrIpAzgQEqWwyotBjuM,img=icfOCslbhXLGrIpAzgQEqWwyotBjJD,infoLabels=icfOCslbhXLGrIpAzgQEqWwyotBjJx,isFolder=icfOCslbhXLGrIpAzgQEqWwyotBjdN,params=icfOCslbhXLGrIpAzgQEqWwyotBjJu)
  if icfOCslbhXLGrIpAzgQEqWwyotBjdv(icfOCslbhXLGrIpAzgQEqWwyotBjMS)>0:xbmcplugin.endOfDirectory(icfOCslbhXLGrIpAzgQEqWwyotBjnd._addon_handle,cacheToDisc=icfOCslbhXLGrIpAzgQEqWwyotBjdN)
 def dp_EventLiveChannel_List(icfOCslbhXLGrIpAzgQEqWwyotBjnd,args):
  icfOCslbhXLGrIpAzgQEqWwyotBjnd.SpotvObj.SaveCredential(icfOCslbhXLGrIpAzgQEqWwyotBjnd.get_winCredential())
  icfOCslbhXLGrIpAzgQEqWwyotBjMS,icfOCslbhXLGrIpAzgQEqWwyotBjud=icfOCslbhXLGrIpAzgQEqWwyotBjnd.SpotvObj.GetEventLiveList()
  if icfOCslbhXLGrIpAzgQEqWwyotBjud!=401 and icfOCslbhXLGrIpAzgQEqWwyotBjdv(icfOCslbhXLGrIpAzgQEqWwyotBjMS)==0:
   icfOCslbhXLGrIpAzgQEqWwyotBjnd.addon_noti(__language__(30907).encode('utf8'))
  for icfOCslbhXLGrIpAzgQEqWwyotBjMV in icfOCslbhXLGrIpAzgQEqWwyotBjMS:
   icfOCslbhXLGrIpAzgQEqWwyotBjnk =icfOCslbhXLGrIpAzgQEqWwyotBjMV.get('title')
   icfOCslbhXLGrIpAzgQEqWwyotBjJH =icfOCslbhXLGrIpAzgQEqWwyotBjMV.get('startTime')
   icfOCslbhXLGrIpAzgQEqWwyotBjJD =icfOCslbhXLGrIpAzgQEqWwyotBjMV.get('logo')
   icfOCslbhXLGrIpAzgQEqWwyotBjun =icfOCslbhXLGrIpAzgQEqWwyotBjMV.get('free')
   icfOCslbhXLGrIpAzgQEqWwyotBjJx={'mediatype':'video','plot':'%s\n\n%s'%(icfOCslbhXLGrIpAzgQEqWwyotBjnk,icfOCslbhXLGrIpAzgQEqWwyotBjJH)}
   icfOCslbhXLGrIpAzgQEqWwyotBjJu={'mode':'ELIVE','mediaid':icfOCslbhXLGrIpAzgQEqWwyotBjMV.get('liveId'),'mediacode':'','free':icfOCslbhXLGrIpAzgQEqWwyotBjun,'mediatype':'live'}
   if icfOCslbhXLGrIpAzgQEqWwyotBjun:icfOCslbhXLGrIpAzgQEqWwyotBjnk+=' [free]'
   icfOCslbhXLGrIpAzgQEqWwyotBjnd.add_dir(icfOCslbhXLGrIpAzgQEqWwyotBjnk,sublabel=icfOCslbhXLGrIpAzgQEqWwyotBjJH,img=icfOCslbhXLGrIpAzgQEqWwyotBjJD,infoLabels=icfOCslbhXLGrIpAzgQEqWwyotBjJx,isFolder=icfOCslbhXLGrIpAzgQEqWwyotBjdN,params=icfOCslbhXLGrIpAzgQEqWwyotBjJu)
  if icfOCslbhXLGrIpAzgQEqWwyotBjdv(icfOCslbhXLGrIpAzgQEqWwyotBjMS)>0:xbmcplugin.endOfDirectory(icfOCslbhXLGrIpAzgQEqWwyotBjnd._addon_handle,cacheToDisc=icfOCslbhXLGrIpAzgQEqWwyotBjdx)
  return icfOCslbhXLGrIpAzgQEqWwyotBjud
 def play_VIDEO(icfOCslbhXLGrIpAzgQEqWwyotBjnd,args):
  icfOCslbhXLGrIpAzgQEqWwyotBjnd.SpotvObj.SaveCredential(icfOCslbhXLGrIpAzgQEqWwyotBjnd.get_winCredential())
  icfOCslbhXLGrIpAzgQEqWwyotBjuH =args.get('mode')
  icfOCslbhXLGrIpAzgQEqWwyotBjuR =args.get('mediacode')
  icfOCslbhXLGrIpAzgQEqWwyotBjuT =args.get('mediatype')
  icfOCslbhXLGrIpAzgQEqWwyotBjJY =args.get('vtypeId')
  if icfOCslbhXLGrIpAzgQEqWwyotBjuH=='LIVE':
   if args.get('free')=='False':
    if icfOCslbhXLGrIpAzgQEqWwyotBjnd.SpotvObj.CheckSubEnd()==icfOCslbhXLGrIpAzgQEqWwyotBjdN:
     icfOCslbhXLGrIpAzgQEqWwyotBjnd.addon_noti(__language__(30908).encode('utf8'))
     return
  elif icfOCslbhXLGrIpAzgQEqWwyotBjuH=='ELIVE':
   if args.get('free')=='False':
    if icfOCslbhXLGrIpAzgQEqWwyotBjnd.SpotvObj.CheckSubEnd()==icfOCslbhXLGrIpAzgQEqWwyotBjdN:
     icfOCslbhXLGrIpAzgQEqWwyotBjnd.addon_noti(__language__(30908).encode('utf8'))
     return
   icfOCslbhXLGrIpAzgQEqWwyotBjuR=icfOCslbhXLGrIpAzgQEqWwyotBjnd.SpotvObj.GetEventLive_videoId(args.get('mediaid'))
  if icfOCslbhXLGrIpAzgQEqWwyotBjuR=='' or icfOCslbhXLGrIpAzgQEqWwyotBjuR==icfOCslbhXLGrIpAzgQEqWwyotBjda:
   icfOCslbhXLGrIpAzgQEqWwyotBjnd.addon_noti(__language__(30907).encode('utf8'))
   return
  if icfOCslbhXLGrIpAzgQEqWwyotBjuH=='LIVE':
   icfOCslbhXLGrIpAzgQEqWwyotBjuD=icfOCslbhXLGrIpAzgQEqWwyotBjnd.SpotvObj.Get_Streamurl_Make(args.get('mediacode'))
  else:
   icfOCslbhXLGrIpAzgQEqWwyotBjuD=icfOCslbhXLGrIpAzgQEqWwyotBjnd.SpotvObj.GetBroadURL(icfOCslbhXLGrIpAzgQEqWwyotBjuR,icfOCslbhXLGrIpAzgQEqWwyotBjuT,icfOCslbhXLGrIpAzgQEqWwyotBjJY)
  if icfOCslbhXLGrIpAzgQEqWwyotBjuD=='':
   icfOCslbhXLGrIpAzgQEqWwyotBjnd.addon_noti(__language__(30908).encode('utf8'))
   return
  icfOCslbhXLGrIpAzgQEqWwyotBjua=icfOCslbhXLGrIpAzgQEqWwyotBjuD
  icfOCslbhXLGrIpAzgQEqWwyotBjnd.addon_log(icfOCslbhXLGrIpAzgQEqWwyotBjua)
  icfOCslbhXLGrIpAzgQEqWwyotBjuN=xbmcgui.ListItem(path=icfOCslbhXLGrIpAzgQEqWwyotBjua)
  xbmcplugin.setResolvedUrl(icfOCslbhXLGrIpAzgQEqWwyotBjnd._addon_handle,icfOCslbhXLGrIpAzgQEqWwyotBjdx,icfOCslbhXLGrIpAzgQEqWwyotBjuN)
  try:
   if icfOCslbhXLGrIpAzgQEqWwyotBjuT=='vod' and icfOCslbhXLGrIpAzgQEqWwyotBjuH!='POP_VOD':
    icfOCslbhXLGrIpAzgQEqWwyotBjJu={'code':args.get('saveId'),'img':args.get('saveImg'),'title':args.get('saveTitle'),'info':args.get('saveInfo')}
    icfOCslbhXLGrIpAzgQEqWwyotBjnd.Save_Watched_List(icfOCslbhXLGrIpAzgQEqWwyotBjuT,icfOCslbhXLGrIpAzgQEqWwyotBjJu)
  except:
   icfOCslbhXLGrIpAzgQEqWwyotBjda
 def logout(icfOCslbhXLGrIpAzgQEqWwyotBjnd):
  icfOCslbhXLGrIpAzgQEqWwyotBjna=xbmcgui.Dialog()
  icfOCslbhXLGrIpAzgQEqWwyotBjMF=icfOCslbhXLGrIpAzgQEqWwyotBjna.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if icfOCslbhXLGrIpAzgQEqWwyotBjMF==icfOCslbhXLGrIpAzgQEqWwyotBjdN:sys.exit()
  icfOCslbhXLGrIpAzgQEqWwyotBjnd.wininfo_clear()
  if os.path.isfile(icfOCslbhXLGrIpAzgQEqWwyotBjnu):os.remove(icfOCslbhXLGrIpAzgQEqWwyotBjnu)
  icfOCslbhXLGrIpAzgQEqWwyotBjnd.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(icfOCslbhXLGrIpAzgQEqWwyotBjnd):
  icfOCslbhXLGrIpAzgQEqWwyotBjnF=xbmcgui.Window(10000)
  icfOCslbhXLGrIpAzgQEqWwyotBjnF.setProperty('SPOTV_M_SESSIONID','')
  icfOCslbhXLGrIpAzgQEqWwyotBjnF.setProperty('SPOTV_M_SESSION','')
  icfOCslbhXLGrIpAzgQEqWwyotBjnF.setProperty('SPOTV_M_ACCOUNTID','')
  icfOCslbhXLGrIpAzgQEqWwyotBjnF.setProperty('SPOTV_M_POLICYKEY','')
  icfOCslbhXLGrIpAzgQEqWwyotBjnF.setProperty('SPOTV_M_SUBEND','')
  icfOCslbhXLGrIpAzgQEqWwyotBjnF.setProperty('SPOTV_M_LOGINTIME','')
 def cookiefile_save(icfOCslbhXLGrIpAzgQEqWwyotBjnd):
  icfOCslbhXLGrIpAzgQEqWwyotBjux =icfOCslbhXLGrIpAzgQEqWwyotBjnd.SpotvObj.Get_Now_Datetime()
  icfOCslbhXLGrIpAzgQEqWwyotBjuU=icfOCslbhXLGrIpAzgQEqWwyotBjux+datetime.timedelta(days=icfOCslbhXLGrIpAzgQEqWwyotBjdU(__addon__.getSetting('cache_ttl')))
  icfOCslbhXLGrIpAzgQEqWwyotBjnF=xbmcgui.Window(10000)
  icfOCslbhXLGrIpAzgQEqWwyotBjuv={'spotv_sessionid':icfOCslbhXLGrIpAzgQEqWwyotBjnF.getProperty('SPOTV_M_SESSIONID'),'spotv_session':icfOCslbhXLGrIpAzgQEqWwyotBjnF.getProperty('SPOTV_M_SESSION'),'spotv_accountId':icfOCslbhXLGrIpAzgQEqWwyotBjnF.getProperty('SPOTV_M_ACCOUNTID'),'spotv_policyKey':base64.standard_b64encode(icfOCslbhXLGrIpAzgQEqWwyotBjnF.getProperty('SPOTV_M_POLICYKEY').encode()).decode('utf-8'),'spotv_subend':base64.standard_b64encode((icfOCslbhXLGrIpAzgQEqWwyotBjnd.SpotvObj.SPOTV_PMCODE+icfOCslbhXLGrIpAzgQEqWwyotBjnF.getProperty('SPOTV_M_SUBEND')).encode()).decode('utf-8'),'spotv_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'spotv_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'spotv_limitdate':icfOCslbhXLGrIpAzgQEqWwyotBjuU.strftime('%Y-%m-%d')}
  try: 
   fp=icfOCslbhXLGrIpAzgQEqWwyotBjdY(icfOCslbhXLGrIpAzgQEqWwyotBjnu,'w',-1,'utf-8')
   json.dump(icfOCslbhXLGrIpAzgQEqWwyotBjuv,fp)
   fp.close()
  except icfOCslbhXLGrIpAzgQEqWwyotBjdF as exception:
   icfOCslbhXLGrIpAzgQEqWwyotBjdm(exception)
 def cookiefile_check(icfOCslbhXLGrIpAzgQEqWwyotBjnd):
  icfOCslbhXLGrIpAzgQEqWwyotBjuv={}
  try: 
   fp=icfOCslbhXLGrIpAzgQEqWwyotBjdY(icfOCslbhXLGrIpAzgQEqWwyotBjnu,'r',-1,'utf-8')
   icfOCslbhXLGrIpAzgQEqWwyotBjuv= json.load(fp)
   fp.close()
  except icfOCslbhXLGrIpAzgQEqWwyotBjdF as exception:
   icfOCslbhXLGrIpAzgQEqWwyotBjnd.wininfo_clear()
   return icfOCslbhXLGrIpAzgQEqWwyotBjdN
  icfOCslbhXLGrIpAzgQEqWwyotBjMP =__addon__.getSetting('id')
  icfOCslbhXLGrIpAzgQEqWwyotBjMY =__addon__.getSetting('pw')
  icfOCslbhXLGrIpAzgQEqWwyotBjuv['spotv_id'] =base64.standard_b64decode(icfOCslbhXLGrIpAzgQEqWwyotBjuv['spotv_id']).decode('utf-8')
  icfOCslbhXLGrIpAzgQEqWwyotBjuv['spotv_pw'] =base64.standard_b64decode(icfOCslbhXLGrIpAzgQEqWwyotBjuv['spotv_pw']).decode('utf-8')
  icfOCslbhXLGrIpAzgQEqWwyotBjuv['spotv_policyKey']=base64.standard_b64decode(icfOCslbhXLGrIpAzgQEqWwyotBjuv['spotv_policyKey']).decode('utf-8')
  icfOCslbhXLGrIpAzgQEqWwyotBjuv['spotv_subend']=base64.standard_b64decode(icfOCslbhXLGrIpAzgQEqWwyotBjuv['spotv_subend']).decode('utf-8')[icfOCslbhXLGrIpAzgQEqWwyotBjnd.SpotvObj.SPOTV_PMSIZE:]
  if icfOCslbhXLGrIpAzgQEqWwyotBjMP!=icfOCslbhXLGrIpAzgQEqWwyotBjuv['spotv_id']or icfOCslbhXLGrIpAzgQEqWwyotBjMY!=icfOCslbhXLGrIpAzgQEqWwyotBjuv['spotv_pw']:
   icfOCslbhXLGrIpAzgQEqWwyotBjnd.wininfo_clear()
   return icfOCslbhXLGrIpAzgQEqWwyotBjdN
  icfOCslbhXLGrIpAzgQEqWwyotBjMm =icfOCslbhXLGrIpAzgQEqWwyotBjdU(icfOCslbhXLGrIpAzgQEqWwyotBjnd.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))
  icfOCslbhXLGrIpAzgQEqWwyotBjuP=icfOCslbhXLGrIpAzgQEqWwyotBjuv['spotv_limitdate']
  icfOCslbhXLGrIpAzgQEqWwyotBjMK =icfOCslbhXLGrIpAzgQEqWwyotBjdU(re.sub('-','',icfOCslbhXLGrIpAzgQEqWwyotBjuP))
  if icfOCslbhXLGrIpAzgQEqWwyotBjMK<icfOCslbhXLGrIpAzgQEqWwyotBjMm:
   icfOCslbhXLGrIpAzgQEqWwyotBjnd.wininfo_clear()
   return icfOCslbhXLGrIpAzgQEqWwyotBjdN
  icfOCslbhXLGrIpAzgQEqWwyotBjnF=xbmcgui.Window(10000)
  icfOCslbhXLGrIpAzgQEqWwyotBjnF.setProperty('SPOTV_M_SESSIONID',icfOCslbhXLGrIpAzgQEqWwyotBjuv['spotv_sessionid'])
  icfOCslbhXLGrIpAzgQEqWwyotBjnF.setProperty('SPOTV_M_SESSION',icfOCslbhXLGrIpAzgQEqWwyotBjuv['spotv_session'])
  icfOCslbhXLGrIpAzgQEqWwyotBjnF.setProperty('SPOTV_M_ACCOUNTID',icfOCslbhXLGrIpAzgQEqWwyotBjuv['spotv_accountId'])
  icfOCslbhXLGrIpAzgQEqWwyotBjnF.setProperty('SPOTV_M_POLICYKEY',icfOCslbhXLGrIpAzgQEqWwyotBjuv['spotv_policyKey'])
  icfOCslbhXLGrIpAzgQEqWwyotBjnF.setProperty('SPOTV_M_SUBEND',icfOCslbhXLGrIpAzgQEqWwyotBjuv['spotv_subend'])
  icfOCslbhXLGrIpAzgQEqWwyotBjnF.setProperty('SPOTV_M_LOGINTIME',icfOCslbhXLGrIpAzgQEqWwyotBjuP)
  return icfOCslbhXLGrIpAzgQEqWwyotBjdx
 def dp_WatchList_Delete(icfOCslbhXLGrIpAzgQEqWwyotBjnd,args):
  icfOCslbhXLGrIpAzgQEqWwyotBjuT=args.get('mediatype')
  icfOCslbhXLGrIpAzgQEqWwyotBjna=xbmcgui.Dialog()
  icfOCslbhXLGrIpAzgQEqWwyotBjMF=icfOCslbhXLGrIpAzgQEqWwyotBjna.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if icfOCslbhXLGrIpAzgQEqWwyotBjMF==icfOCslbhXLGrIpAzgQEqWwyotBjdN:sys.exit()
  icfOCslbhXLGrIpAzgQEqWwyotBjnd.Delete_Watched_List(icfOCslbhXLGrIpAzgQEqWwyotBjuT)
  xbmc.executebuiltin("Container.Refresh")
 def Delete_Watched_List(icfOCslbhXLGrIpAzgQEqWwyotBjnd,icfOCslbhXLGrIpAzgQEqWwyotBjuT):
  try:
   icfOCslbhXLGrIpAzgQEqWwyotBjuY=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%icfOCslbhXLGrIpAzgQEqWwyotBjuT))
   fp=icfOCslbhXLGrIpAzgQEqWwyotBjdY(icfOCslbhXLGrIpAzgQEqWwyotBjuY,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   icfOCslbhXLGrIpAzgQEqWwyotBjda
 def Load_Watched_List(icfOCslbhXLGrIpAzgQEqWwyotBjnd,icfOCslbhXLGrIpAzgQEqWwyotBjuT):
  try:
   icfOCslbhXLGrIpAzgQEqWwyotBjuY=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%icfOCslbhXLGrIpAzgQEqWwyotBjuT))
   fp=icfOCslbhXLGrIpAzgQEqWwyotBjdY(icfOCslbhXLGrIpAzgQEqWwyotBjuY,'r',-1,'utf-8')
   icfOCslbhXLGrIpAzgQEqWwyotBjuF=fp.readlines()
   fp.close()
  except:
   icfOCslbhXLGrIpAzgQEqWwyotBjuF=[]
  return icfOCslbhXLGrIpAzgQEqWwyotBjuF
 def Save_Watched_List(icfOCslbhXLGrIpAzgQEqWwyotBjnd,stype,icfOCslbhXLGrIpAzgQEqWwyotBjnT):
  try:
   icfOCslbhXLGrIpAzgQEqWwyotBjuY=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   icfOCslbhXLGrIpAzgQEqWwyotBjum=icfOCslbhXLGrIpAzgQEqWwyotBjnd.Load_Watched_List(stype) 
   fp=icfOCslbhXLGrIpAzgQEqWwyotBjdY(icfOCslbhXLGrIpAzgQEqWwyotBjuY,'w',-1,'utf-8')
   icfOCslbhXLGrIpAzgQEqWwyotBjuK=urllib.parse.urlencode(icfOCslbhXLGrIpAzgQEqWwyotBjnT)
   icfOCslbhXLGrIpAzgQEqWwyotBjuK=icfOCslbhXLGrIpAzgQEqWwyotBjuK+'\n'
   fp.write(icfOCslbhXLGrIpAzgQEqWwyotBjuK)
   icfOCslbhXLGrIpAzgQEqWwyotBjuk=0
   for icfOCslbhXLGrIpAzgQEqWwyotBjuS in icfOCslbhXLGrIpAzgQEqWwyotBjum:
    icfOCslbhXLGrIpAzgQEqWwyotBjuV=icfOCslbhXLGrIpAzgQEqWwyotBjdK(urllib.parse.parse_qsl(icfOCslbhXLGrIpAzgQEqWwyotBjuS))
    icfOCslbhXLGrIpAzgQEqWwyotBjue=icfOCslbhXLGrIpAzgQEqWwyotBjnT.get('code')
    icfOCslbhXLGrIpAzgQEqWwyotBjdn=icfOCslbhXLGrIpAzgQEqWwyotBjuV.get('code')
    if icfOCslbhXLGrIpAzgQEqWwyotBjue!=icfOCslbhXLGrIpAzgQEqWwyotBjdn:
     fp.write(icfOCslbhXLGrIpAzgQEqWwyotBjuS)
     icfOCslbhXLGrIpAzgQEqWwyotBjuk+=1
     if icfOCslbhXLGrIpAzgQEqWwyotBjuk>=50:break
   fp.close()
  except:
   icfOCslbhXLGrIpAzgQEqWwyotBjda
 def dp_Watch_List(icfOCslbhXLGrIpAzgQEqWwyotBjnd,args):
  icfOCslbhXLGrIpAzgQEqWwyotBjuT ='vod'
  if icfOCslbhXLGrIpAzgQEqWwyotBjuT=='vod':
   icfOCslbhXLGrIpAzgQEqWwyotBjdJ=icfOCslbhXLGrIpAzgQEqWwyotBjnd.Load_Watched_List(icfOCslbhXLGrIpAzgQEqWwyotBjuT)
   for icfOCslbhXLGrIpAzgQEqWwyotBjdM in icfOCslbhXLGrIpAzgQEqWwyotBjdJ:
    icfOCslbhXLGrIpAzgQEqWwyotBjdu=icfOCslbhXLGrIpAzgQEqWwyotBjdK(urllib.parse.parse_qsl(icfOCslbhXLGrIpAzgQEqWwyotBjdM))
    icfOCslbhXLGrIpAzgQEqWwyotBjnk =icfOCslbhXLGrIpAzgQEqWwyotBjdu.get('title')
    icfOCslbhXLGrIpAzgQEqWwyotBjJD=icfOCslbhXLGrIpAzgQEqWwyotBjdu.get('img')
    icfOCslbhXLGrIpAzgQEqWwyotBjuR=icfOCslbhXLGrIpAzgQEqWwyotBjdu.get('code')
    icfOCslbhXLGrIpAzgQEqWwyotBjdH =icfOCslbhXLGrIpAzgQEqWwyotBjdu.get('info')
    icfOCslbhXLGrIpAzgQEqWwyotBjJx={}
    icfOCslbhXLGrIpAzgQEqWwyotBjJx['plot']=icfOCslbhXLGrIpAzgQEqWwyotBjdH
    icfOCslbhXLGrIpAzgQEqWwyotBjJu={'mode':'GAME_VOD_GROUP','gameid':icfOCslbhXLGrIpAzgQEqWwyotBjuR,'saveTitle':icfOCslbhXLGrIpAzgQEqWwyotBjnk,'saveImg':icfOCslbhXLGrIpAzgQEqWwyotBjJD,'saveInfo':icfOCslbhXLGrIpAzgQEqWwyotBjdH,'mediatype':icfOCslbhXLGrIpAzgQEqWwyotBjuT}
    icfOCslbhXLGrIpAzgQEqWwyotBjnd.add_dir(icfOCslbhXLGrIpAzgQEqWwyotBjnk,sublabel='',img=icfOCslbhXLGrIpAzgQEqWwyotBjJD,infoLabels=icfOCslbhXLGrIpAzgQEqWwyotBjJx,isFolder=icfOCslbhXLGrIpAzgQEqWwyotBjdx,params=icfOCslbhXLGrIpAzgQEqWwyotBjJu)
   icfOCslbhXLGrIpAzgQEqWwyotBjJx={'plot':'시청목록을 삭제합니다.'}
   icfOCslbhXLGrIpAzgQEqWwyotBjnk='*** 시청목록 삭제 ***'
   icfOCslbhXLGrIpAzgQEqWwyotBjJu={'mode':'MYVIEW_REMOVE','mediatype':icfOCslbhXLGrIpAzgQEqWwyotBjuT}
   icfOCslbhXLGrIpAzgQEqWwyotBjnd.add_dir(icfOCslbhXLGrIpAzgQEqWwyotBjnk,sublabel='',img='',infoLabels=icfOCslbhXLGrIpAzgQEqWwyotBjJx,isFolder=icfOCslbhXLGrIpAzgQEqWwyotBjdN,params=icfOCslbhXLGrIpAzgQEqWwyotBjJu)
   xbmcplugin.endOfDirectory(icfOCslbhXLGrIpAzgQEqWwyotBjnd._addon_handle,cacheToDisc=icfOCslbhXLGrIpAzgQEqWwyotBjdN)
 def spotv_main(icfOCslbhXLGrIpAzgQEqWwyotBjnd):
  icfOCslbhXLGrIpAzgQEqWwyotBjdT=icfOCslbhXLGrIpAzgQEqWwyotBjnd.main_params.get('mode',icfOCslbhXLGrIpAzgQEqWwyotBjda)
  if icfOCslbhXLGrIpAzgQEqWwyotBjdT=='LOGOUT':
   icfOCslbhXLGrIpAzgQEqWwyotBjnd.logout()
   return
  icfOCslbhXLGrIpAzgQEqWwyotBjnd.login_main()
  if icfOCslbhXLGrIpAzgQEqWwyotBjdT is icfOCslbhXLGrIpAzgQEqWwyotBjda:
   icfOCslbhXLGrIpAzgQEqWwyotBjnd.dp_Main_List()
  elif icfOCslbhXLGrIpAzgQEqWwyotBjdT=='LIVE_GROUP':
   icfOCslbhXLGrIpAzgQEqWwyotBjnd.dp_LiveChannel_List(icfOCslbhXLGrIpAzgQEqWwyotBjnd.main_params)
  elif icfOCslbhXLGrIpAzgQEqWwyotBjdT=='ELIVE_GROUP':
   icfOCslbhXLGrIpAzgQEqWwyotBjud=icfOCslbhXLGrIpAzgQEqWwyotBjnd.dp_EventLiveChannel_List(icfOCslbhXLGrIpAzgQEqWwyotBjnd.main_params)
   if icfOCslbhXLGrIpAzgQEqWwyotBjud==401:
    if os.path.isfile(icfOCslbhXLGrIpAzgQEqWwyotBjnu):os.remove(icfOCslbhXLGrIpAzgQEqWwyotBjnu)
    icfOCslbhXLGrIpAzgQEqWwyotBjnd.login_main()
    icfOCslbhXLGrIpAzgQEqWwyotBjnd.dp_EventLiveChannel_List(icfOCslbhXLGrIpAzgQEqWwyotBjnd.main_params)
  elif icfOCslbhXLGrIpAzgQEqWwyotBjdT in['LIVE','GAME_VOD','POP_VOD','ELIVE']:
   icfOCslbhXLGrIpAzgQEqWwyotBjnd.play_VIDEO(icfOCslbhXLGrIpAzgQEqWwyotBjnd.main_params)
  elif icfOCslbhXLGrIpAzgQEqWwyotBjdT=='VOD_GROUP':
   icfOCslbhXLGrIpAzgQEqWwyotBjnd.dp_MainLeague_List(icfOCslbhXLGrIpAzgQEqWwyotBjnd.main_params)
  elif icfOCslbhXLGrIpAzgQEqWwyotBjdT=='POP_GROUP':
   icfOCslbhXLGrIpAzgQEqWwyotBjnd.dp_PopVod_GroupList(icfOCslbhXLGrIpAzgQEqWwyotBjnd.main_params)
  elif icfOCslbhXLGrIpAzgQEqWwyotBjdT=='LEAGUE_GROUP':
   icfOCslbhXLGrIpAzgQEqWwyotBjnd.dp_Season_List(icfOCslbhXLGrIpAzgQEqWwyotBjnd.main_params)
  elif icfOCslbhXLGrIpAzgQEqWwyotBjdT=='SEASON_GROUP':
   icfOCslbhXLGrIpAzgQEqWwyotBjnd.dp_Game_List(icfOCslbhXLGrIpAzgQEqWwyotBjnd.main_params)
  elif icfOCslbhXLGrIpAzgQEqWwyotBjdT=='GAME_VOD_GROUP':
   icfOCslbhXLGrIpAzgQEqWwyotBjnd.dp_GameVod_List(icfOCslbhXLGrIpAzgQEqWwyotBjnd.main_params)
  elif icfOCslbhXLGrIpAzgQEqWwyotBjdT=='WATCH':
   icfOCslbhXLGrIpAzgQEqWwyotBjnd.dp_Watch_List(icfOCslbhXLGrIpAzgQEqWwyotBjnd.main_params)
  elif icfOCslbhXLGrIpAzgQEqWwyotBjdT=='MYVIEW_REMOVE':
   icfOCslbhXLGrIpAzgQEqWwyotBjnd.dp_WatchList_Delete(icfOCslbhXLGrIpAzgQEqWwyotBjnd.main_params)
  else:
   icfOCslbhXLGrIpAzgQEqWwyotBjda
# Created by pyminifier (https://github.com/liftoff/pyminifier)
