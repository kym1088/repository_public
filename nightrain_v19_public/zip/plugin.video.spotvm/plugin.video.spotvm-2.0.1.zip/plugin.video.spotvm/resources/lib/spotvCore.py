__author__="NightRain"
ibacumsXHBdERyOSCDAGWtLeQrhkNJ=object
ibacumsXHBdERyOSCDAGWtLeQrhkNl=None
ibacumsXHBdERyOSCDAGWtLeQrhkNK=False
ibacumsXHBdERyOSCDAGWtLeQrhkNg=print
ibacumsXHBdERyOSCDAGWtLeQrhkNj=str
ibacumsXHBdERyOSCDAGWtLeQrhkNx=True
ibacumsXHBdERyOSCDAGWtLeQrhkNU=Exception
ibacumsXHBdERyOSCDAGWtLeQrhkNY=int
import urllib
import http.cookiejar 
import re
import json
import sys
import time
import requests
import datetime
import base64
ibacumsXHBdERyOSCDAGWtLeQrhkwN ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36'
ibacumsXHBdERyOSCDAGWtLeQrhkwo={'stream50':1080,'stream40':720,'stream30':540}
class ibacumsXHBdERyOSCDAGWtLeQrhkwv(ibacumsXHBdERyOSCDAGWtLeQrhkNJ):
 def __init__(ibacumsXHBdERyOSCDAGWtLeQrhkwf):
  ibacumsXHBdERyOSCDAGWtLeQrhkwf.SPOTV_SESSIONID=''
  ibacumsXHBdERyOSCDAGWtLeQrhkwf.SPOTV_SESSION =''
  ibacumsXHBdERyOSCDAGWtLeQrhkwf.SPOTV_ACCOUNTID=''
  ibacumsXHBdERyOSCDAGWtLeQrhkwf.SPOTV_POLICYKEY=''
  ibacumsXHBdERyOSCDAGWtLeQrhkwf.SPOTV_SUBEND =''
  ibacumsXHBdERyOSCDAGWtLeQrhkwf.SPOTV_PMCODE ='987'
  ibacumsXHBdERyOSCDAGWtLeQrhkwf.SPOTV_PMSIZE =3
  ibacumsXHBdERyOSCDAGWtLeQrhkwf.API_DOMAIN ='https://www.spotvnow.co.kr'
  ibacumsXHBdERyOSCDAGWtLeQrhkwf.BC_DOMAIN ='https://players.brightcove.net'
  ibacumsXHBdERyOSCDAGWtLeQrhkwf.PLAYER_DOMAIN ='https://edge.api.brightcove.com'
  ibacumsXHBdERyOSCDAGWtLeQrhkwf.DEFAULT_HEADER ={'user-agent':ibacumsXHBdERyOSCDAGWtLeQrhkwN}
 def callRequestCookies(ibacumsXHBdERyOSCDAGWtLeQrhkwf,jobtype,ibacumsXHBdERyOSCDAGWtLeQrhkvo,payload=ibacumsXHBdERyOSCDAGWtLeQrhkNl,params=ibacumsXHBdERyOSCDAGWtLeQrhkNl,headers=ibacumsXHBdERyOSCDAGWtLeQrhkNl,cookies=ibacumsXHBdERyOSCDAGWtLeQrhkNl,redirects=ibacumsXHBdERyOSCDAGWtLeQrhkNK):
  ibacumsXHBdERyOSCDAGWtLeQrhkwn=ibacumsXHBdERyOSCDAGWtLeQrhkwf.DEFAULT_HEADER
  if headers:ibacumsXHBdERyOSCDAGWtLeQrhkwn.update(headers)
  if jobtype=='Get':
   ibacumsXHBdERyOSCDAGWtLeQrhkwV=requests.get(ibacumsXHBdERyOSCDAGWtLeQrhkvo,params=params,headers=ibacumsXHBdERyOSCDAGWtLeQrhkwn,cookies=cookies,allow_redirects=redirects)
  else:
   ibacumsXHBdERyOSCDAGWtLeQrhkwV=requests.post(ibacumsXHBdERyOSCDAGWtLeQrhkvo,data=payload,params=params,headers=ibacumsXHBdERyOSCDAGWtLeQrhkwn,cookies=cookies,allow_redirects=redirects)
  return ibacumsXHBdERyOSCDAGWtLeQrhkwV
 def makeDefaultCookies(ibacumsXHBdERyOSCDAGWtLeQrhkwf):
  ibacumsXHBdERyOSCDAGWtLeQrhkwz={'SESSION':ibacumsXHBdERyOSCDAGWtLeQrhkwf.SPOTV_SESSION}
  return ibacumsXHBdERyOSCDAGWtLeQrhkwz
 def GetCredential(ibacumsXHBdERyOSCDAGWtLeQrhkwf,user_id,user_pw):
  ibacumsXHBdERyOSCDAGWtLeQrhkwP=ibacumsXHBdERyOSCDAGWtLeQrhkNK
  ibacumsXHBdERyOSCDAGWtLeQrhkwJ=ibacumsXHBdERyOSCDAGWtLeQrhkwY=ibacumsXHBdERyOSCDAGWtLeQrhkwT=ibacumsXHBdERyOSCDAGWtLeQrhkwF=ibacumsXHBdERyOSCDAGWtLeQrhkwM=''
  try:
   ibacumsXHBdERyOSCDAGWtLeQrhkwl=base64.standard_b64encode(user_id.encode("UTF-8")).decode('utf-8')
   ibacumsXHBdERyOSCDAGWtLeQrhkwK=base64.standard_b64encode(user_pw.encode("UTF-8")).decode('utf-8')
   ibacumsXHBdERyOSCDAGWtLeQrhkwg=ibacumsXHBdERyOSCDAGWtLeQrhkwf.API_DOMAIN+'/api/v2/login'
   ibacumsXHBdERyOSCDAGWtLeQrhkwj={'username':ibacumsXHBdERyOSCDAGWtLeQrhkwl,'password':ibacumsXHBdERyOSCDAGWtLeQrhkwK}
   ibacumsXHBdERyOSCDAGWtLeQrhkwj=json.dumps(ibacumsXHBdERyOSCDAGWtLeQrhkwj)
   ibacumsXHBdERyOSCDAGWtLeQrhkwx=ibacumsXHBdERyOSCDAGWtLeQrhkwf.callRequestCookies('Post',ibacumsXHBdERyOSCDAGWtLeQrhkwg,payload=ibacumsXHBdERyOSCDAGWtLeQrhkwj,params=ibacumsXHBdERyOSCDAGWtLeQrhkNl,headers=ibacumsXHBdERyOSCDAGWtLeQrhkNl,cookies=ibacumsXHBdERyOSCDAGWtLeQrhkNl)
   ibacumsXHBdERyOSCDAGWtLeQrhkNg(ibacumsXHBdERyOSCDAGWtLeQrhkwx.status_code)
   for ibacumsXHBdERyOSCDAGWtLeQrhkwU in ibacumsXHBdERyOSCDAGWtLeQrhkwx.cookies:
    if ibacumsXHBdERyOSCDAGWtLeQrhkwU.name=='SESSION':
     ibacumsXHBdERyOSCDAGWtLeQrhkwY=ibacumsXHBdERyOSCDAGWtLeQrhkwU.value
     break
   if ibacumsXHBdERyOSCDAGWtLeQrhkwY=='':return ibacumsXHBdERyOSCDAGWtLeQrhkwP
   ibacumsXHBdERyOSCDAGWtLeQrhkwI=json.loads(ibacumsXHBdERyOSCDAGWtLeQrhkwx.text)
   if not('userId' in ibacumsXHBdERyOSCDAGWtLeQrhkwI):return ibacumsXHBdERyOSCDAGWtLeQrhkwP
   ibacumsXHBdERyOSCDAGWtLeQrhkwJ=ibacumsXHBdERyOSCDAGWtLeQrhkNj(ibacumsXHBdERyOSCDAGWtLeQrhkwI['userId'])
   ibacumsXHBdERyOSCDAGWtLeQrhkwM =ibacumsXHBdERyOSCDAGWtLeQrhkNj(ibacumsXHBdERyOSCDAGWtLeQrhkwI['subEndTime'])
   ibacumsXHBdERyOSCDAGWtLeQrhkwT,ibacumsXHBdERyOSCDAGWtLeQrhkwF=ibacumsXHBdERyOSCDAGWtLeQrhkwf.GetPolicyKey()
   if ibacumsXHBdERyOSCDAGWtLeQrhkwF=='':return ibacumsXHBdERyOSCDAGWtLeQrhkwP
   ibacumsXHBdERyOSCDAGWtLeQrhkwP=ibacumsXHBdERyOSCDAGWtLeQrhkNx
  except ibacumsXHBdERyOSCDAGWtLeQrhkNU as exception:
   ibacumsXHBdERyOSCDAGWtLeQrhkwJ=ibacumsXHBdERyOSCDAGWtLeQrhkwY='' 
   ibacumsXHBdERyOSCDAGWtLeQrhkNg(exception)
  ibacumsXHBdERyOSCDAGWtLeQrhkwp={'spotv_sessionid':ibacumsXHBdERyOSCDAGWtLeQrhkwJ,'spotv_session':ibacumsXHBdERyOSCDAGWtLeQrhkwY,'spotv_accountId':ibacumsXHBdERyOSCDAGWtLeQrhkwT,'spotv_policyKey':ibacumsXHBdERyOSCDAGWtLeQrhkwF,'spotv_subend':ibacumsXHBdERyOSCDAGWtLeQrhkwM}
  ibacumsXHBdERyOSCDAGWtLeQrhkwf.SaveCredential(ibacumsXHBdERyOSCDAGWtLeQrhkwp)
  return ibacumsXHBdERyOSCDAGWtLeQrhkwP
 def SaveCredential(ibacumsXHBdERyOSCDAGWtLeQrhkwf,ibacumsXHBdERyOSCDAGWtLeQrhkwp):
  ibacumsXHBdERyOSCDAGWtLeQrhkwf.SPOTV_SESSIONID=ibacumsXHBdERyOSCDAGWtLeQrhkwp.get('spotv_sessionid')
  ibacumsXHBdERyOSCDAGWtLeQrhkwf.SPOTV_SESSION =ibacumsXHBdERyOSCDAGWtLeQrhkwp.get('spotv_session')
  ibacumsXHBdERyOSCDAGWtLeQrhkwf.SPOTV_ACCOUNTID=ibacumsXHBdERyOSCDAGWtLeQrhkwp.get('spotv_accountId')
  ibacumsXHBdERyOSCDAGWtLeQrhkwf.SPOTV_POLICYKEY=ibacumsXHBdERyOSCDAGWtLeQrhkwp.get('spotv_policyKey')
  ibacumsXHBdERyOSCDAGWtLeQrhkwf.SPOTV_SUBEND =ibacumsXHBdERyOSCDAGWtLeQrhkwp.get('spotv_subend')
 def LoadCredential(ibacumsXHBdERyOSCDAGWtLeQrhkwf):
  ibacumsXHBdERyOSCDAGWtLeQrhkwp={'spotv_sessionid':ibacumsXHBdERyOSCDAGWtLeQrhkwf.SPOTV_SESSIONID,'spotv_session':ibacumsXHBdERyOSCDAGWtLeQrhkwf.SPOTV_SESSION,'spotv_accountId':ibacumsXHBdERyOSCDAGWtLeQrhkwf.SPOTV_ACCOUNTID,'spotv_policyKey':ibacumsXHBdERyOSCDAGWtLeQrhkwf.SPOTV_POLICYKEY,'spotv_subend':ibacumsXHBdERyOSCDAGWtLeQrhkwf.SPOTV_SUBEND}
  return ibacumsXHBdERyOSCDAGWtLeQrhkwp
 def Get_Now_Datetime(ibacumsXHBdERyOSCDAGWtLeQrhkwf):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetLiveChannelList(ibacumsXHBdERyOSCDAGWtLeQrhkwf):
  ibacumsXHBdERyOSCDAGWtLeQrhkvw=[]
  ibacumsXHBdERyOSCDAGWtLeQrhkvN ={}
  try:
   ibacumsXHBdERyOSCDAGWtLeQrhkvo=ibacumsXHBdERyOSCDAGWtLeQrhkwf.API_DOMAIN+'/api/v2/channel'
   ibacumsXHBdERyOSCDAGWtLeQrhkwz=ibacumsXHBdERyOSCDAGWtLeQrhkwf.makeDefaultCookies()
   ibacumsXHBdERyOSCDAGWtLeQrhkwx=ibacumsXHBdERyOSCDAGWtLeQrhkwf.callRequestCookies('Get',ibacumsXHBdERyOSCDAGWtLeQrhkvo,payload=ibacumsXHBdERyOSCDAGWtLeQrhkNl,params=ibacumsXHBdERyOSCDAGWtLeQrhkNl,headers=ibacumsXHBdERyOSCDAGWtLeQrhkNl,cookies=ibacumsXHBdERyOSCDAGWtLeQrhkwz)
   ibacumsXHBdERyOSCDAGWtLeQrhkwI=json.loads(ibacumsXHBdERyOSCDAGWtLeQrhkwx.text)
   ibacumsXHBdERyOSCDAGWtLeQrhkvN=ibacumsXHBdERyOSCDAGWtLeQrhkwf.GetEPGList()
   for ibacumsXHBdERyOSCDAGWtLeQrhkvf in ibacumsXHBdERyOSCDAGWtLeQrhkwI:
    ibacumsXHBdERyOSCDAGWtLeQrhkvn={}
    ibacumsXHBdERyOSCDAGWtLeQrhkvn['mediatype']='video'
    ibacumsXHBdERyOSCDAGWtLeQrhkvn['title'] =ibacumsXHBdERyOSCDAGWtLeQrhkvf['programName']
    ibacumsXHBdERyOSCDAGWtLeQrhkvn['studio'] =ibacumsXHBdERyOSCDAGWtLeQrhkvf['name']
    ibacumsXHBdERyOSCDAGWtLeQrhkvV={'id':ibacumsXHBdERyOSCDAGWtLeQrhkvf['id'],'name':ibacumsXHBdERyOSCDAGWtLeQrhkvf['name'],'logo':ibacumsXHBdERyOSCDAGWtLeQrhkvf['logo'],'videoId':ibacumsXHBdERyOSCDAGWtLeQrhkvf['videoId'].replace('ref:',''),'free':ibacumsXHBdERyOSCDAGWtLeQrhkvf['free'],'programName':ibacumsXHBdERyOSCDAGWtLeQrhkvf['programName'],'channelepg':ibacumsXHBdERyOSCDAGWtLeQrhkvN.get(ibacumsXHBdERyOSCDAGWtLeQrhkvf['id']),'info':ibacumsXHBdERyOSCDAGWtLeQrhkvn}
    ibacumsXHBdERyOSCDAGWtLeQrhkvw.append(ibacumsXHBdERyOSCDAGWtLeQrhkvV)
  except ibacumsXHBdERyOSCDAGWtLeQrhkNU as exception:
   ibacumsXHBdERyOSCDAGWtLeQrhkNg(exception)
  return ibacumsXHBdERyOSCDAGWtLeQrhkvw
 def GetEPGList(ibacumsXHBdERyOSCDAGWtLeQrhkwf):
  ibacumsXHBdERyOSCDAGWtLeQrhkvz={}
  ibacumsXHBdERyOSCDAGWtLeQrhkvP=ibacumsXHBdERyOSCDAGWtLeQrhkwf.Get_Now_Datetime()
  ibacumsXHBdERyOSCDAGWtLeQrhkvJ=ibacumsXHBdERyOSCDAGWtLeQrhkvP.strftime('%Y%m%d%H%M')
  ibacumsXHBdERyOSCDAGWtLeQrhkvl='%s-%s-%s'%(ibacumsXHBdERyOSCDAGWtLeQrhkvJ[0:4],ibacumsXHBdERyOSCDAGWtLeQrhkvJ[4:6],ibacumsXHBdERyOSCDAGWtLeQrhkvJ[6:8])
  ibacumsXHBdERyOSCDAGWtLeQrhkvK=(ibacumsXHBdERyOSCDAGWtLeQrhkvP+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M')
  try:
   ibacumsXHBdERyOSCDAGWtLeQrhkvo=ibacumsXHBdERyOSCDAGWtLeQrhkwf.API_DOMAIN+'/api/v2/program/'+ibacumsXHBdERyOSCDAGWtLeQrhkvl
   ibacumsXHBdERyOSCDAGWtLeQrhkwz=ibacumsXHBdERyOSCDAGWtLeQrhkwf.makeDefaultCookies()
   ibacumsXHBdERyOSCDAGWtLeQrhkwx=ibacumsXHBdERyOSCDAGWtLeQrhkwf.callRequestCookies('Get',ibacumsXHBdERyOSCDAGWtLeQrhkvo,payload=ibacumsXHBdERyOSCDAGWtLeQrhkNl,params=ibacumsXHBdERyOSCDAGWtLeQrhkNl,headers=ibacumsXHBdERyOSCDAGWtLeQrhkNl,cookies=ibacumsXHBdERyOSCDAGWtLeQrhkwz)
   ibacumsXHBdERyOSCDAGWtLeQrhkwI=json.loads(ibacumsXHBdERyOSCDAGWtLeQrhkwx.text)
   ibacumsXHBdERyOSCDAGWtLeQrhkvg=-1 
   ibacumsXHBdERyOSCDAGWtLeQrhkvj =''
   for ibacumsXHBdERyOSCDAGWtLeQrhkvf in ibacumsXHBdERyOSCDAGWtLeQrhkwI:
    ibacumsXHBdERyOSCDAGWtLeQrhkvx=ibacumsXHBdERyOSCDAGWtLeQrhkvf['channelId']
    ibacumsXHBdERyOSCDAGWtLeQrhkvU =ibacumsXHBdERyOSCDAGWtLeQrhkvf['startTime'].replace('-','').replace(' ','').replace(':','')
    ibacumsXHBdERyOSCDAGWtLeQrhkvY =ibacumsXHBdERyOSCDAGWtLeQrhkvf['endTime'].replace('-','').replace(' ','').replace(':','')
    if ibacumsXHBdERyOSCDAGWtLeQrhkNY(ibacumsXHBdERyOSCDAGWtLeQrhkvJ)>ibacumsXHBdERyOSCDAGWtLeQrhkNY(ibacumsXHBdERyOSCDAGWtLeQrhkvY) :continue
    if ibacumsXHBdERyOSCDAGWtLeQrhkNY(ibacumsXHBdERyOSCDAGWtLeQrhkvK)<ibacumsXHBdERyOSCDAGWtLeQrhkNY(ibacumsXHBdERyOSCDAGWtLeQrhkvU):continue
    if ibacumsXHBdERyOSCDAGWtLeQrhkvg!=ibacumsXHBdERyOSCDAGWtLeQrhkvx:
     if ibacumsXHBdERyOSCDAGWtLeQrhkvj!='':ibacumsXHBdERyOSCDAGWtLeQrhkvz[ibacumsXHBdERyOSCDAGWtLeQrhkvg]=ibacumsXHBdERyOSCDAGWtLeQrhkvj
     ibacumsXHBdERyOSCDAGWtLeQrhkvg=ibacumsXHBdERyOSCDAGWtLeQrhkvx
     ibacumsXHBdERyOSCDAGWtLeQrhkvj =''
    if ibacumsXHBdERyOSCDAGWtLeQrhkvj:ibacumsXHBdERyOSCDAGWtLeQrhkvj+='\n'
    ibacumsXHBdERyOSCDAGWtLeQrhkvj+=ibacumsXHBdERyOSCDAGWtLeQrhkvf['title']+'\n'
    ibacumsXHBdERyOSCDAGWtLeQrhkvj+=' [%s ~ %s]'%(ibacumsXHBdERyOSCDAGWtLeQrhkvf['startTime'][-5:],ibacumsXHBdERyOSCDAGWtLeQrhkvf['endTime'][-5:])+'\n'
   if ibacumsXHBdERyOSCDAGWtLeQrhkvj:ibacumsXHBdERyOSCDAGWtLeQrhkvz[ibacumsXHBdERyOSCDAGWtLeQrhkvg]=ibacumsXHBdERyOSCDAGWtLeQrhkvj
  except ibacumsXHBdERyOSCDAGWtLeQrhkNU as exception:
   ibacumsXHBdERyOSCDAGWtLeQrhkNg(exception)
  return ibacumsXHBdERyOSCDAGWtLeQrhkvz
 def CheckMainEnd(ibacumsXHBdERyOSCDAGWtLeQrhkwf):
  ibacumsXHBdERyOSCDAGWtLeQrhkvI=base64.standard_b64encode((ibacumsXHBdERyOSCDAGWtLeQrhkwf.SPOTV_PMCODE+ibacumsXHBdERyOSCDAGWtLeQrhkwf.SPOTV_SESSIONID).encode()).decode('utf-8')
  if ibacumsXHBdERyOSCDAGWtLeQrhkvI=='OTg3MTgzMzM0Ng==' or ibacumsXHBdERyOSCDAGWtLeQrhkvI=='OTg3MTgzMzExNw==':return ibacumsXHBdERyOSCDAGWtLeQrhkNx
  return ibacumsXHBdERyOSCDAGWtLeQrhkNK
 def CheckSubEnd(ibacumsXHBdERyOSCDAGWtLeQrhkwf):
  ibacumsXHBdERyOSCDAGWtLeQrhkvM=ibacumsXHBdERyOSCDAGWtLeQrhkNK
  try:
   if ibacumsXHBdERyOSCDAGWtLeQrhkwf.CheckMainEnd():return ibacumsXHBdERyOSCDAGWtLeQrhkNx 
   if ibacumsXHBdERyOSCDAGWtLeQrhkwf.SPOTV_SUBEND=='0':return ibacumsXHBdERyOSCDAGWtLeQrhkvM
  except:
   return ibacumsXHBdERyOSCDAGWtLeQrhkvM
  return ibacumsXHBdERyOSCDAGWtLeQrhkvM
 def GetMainJspath(ibacumsXHBdERyOSCDAGWtLeQrhkwf):
  ibacumsXHBdERyOSCDAGWtLeQrhkvT=''
  try:
   ibacumsXHBdERyOSCDAGWtLeQrhkvo=ibacumsXHBdERyOSCDAGWtLeQrhkwf.API_DOMAIN
   ibacumsXHBdERyOSCDAGWtLeQrhkwx=ibacumsXHBdERyOSCDAGWtLeQrhkwf.callRequestCookies('Get',ibacumsXHBdERyOSCDAGWtLeQrhkvo,payload=ibacumsXHBdERyOSCDAGWtLeQrhkNl,params=ibacumsXHBdERyOSCDAGWtLeQrhkNl,headers=ibacumsXHBdERyOSCDAGWtLeQrhkNl,cookies=ibacumsXHBdERyOSCDAGWtLeQrhkNl)
   ibacumsXHBdERyOSCDAGWtLeQrhkvF=ibacumsXHBdERyOSCDAGWtLeQrhkwx.text
   ibacumsXHBdERyOSCDAGWtLeQrhkvp =re.findall('https://cdn.spotvnow.co.kr/dist/js/.{20}\.js',ibacumsXHBdERyOSCDAGWtLeQrhkvF)[0]
   ibacumsXHBdERyOSCDAGWtLeQrhkvT=ibacumsXHBdERyOSCDAGWtLeQrhkvp
  except ibacumsXHBdERyOSCDAGWtLeQrhkNU as exception:
   ibacumsXHBdERyOSCDAGWtLeQrhkNg(exception)
  return ibacumsXHBdERyOSCDAGWtLeQrhkvT
 def GetBcPlayerUrl(ibacumsXHBdERyOSCDAGWtLeQrhkwf):
  ibacumsXHBdERyOSCDAGWtLeQrhkvq=''
  try:
   ibacumsXHBdERyOSCDAGWtLeQrhkvo=ibacumsXHBdERyOSCDAGWtLeQrhkwf.GetMainJspath()
   if ibacumsXHBdERyOSCDAGWtLeQrhkvo=='':return ibacumsXHBdERyOSCDAGWtLeQrhkvq
   ibacumsXHBdERyOSCDAGWtLeQrhkwx=ibacumsXHBdERyOSCDAGWtLeQrhkwf.callRequestCookies('Get',ibacumsXHBdERyOSCDAGWtLeQrhkvo,payload=ibacumsXHBdERyOSCDAGWtLeQrhkNl,params=ibacumsXHBdERyOSCDAGWtLeQrhkNl,headers=ibacumsXHBdERyOSCDAGWtLeQrhkNl,cookies=ibacumsXHBdERyOSCDAGWtLeQrhkNl)
   ibacumsXHBdERyOSCDAGWtLeQrhkvF=ibacumsXHBdERyOSCDAGWtLeQrhkwx.text
   ibacumsXHBdERyOSCDAGWtLeQrhkNw =re.findall('bc:\s*\"\d{13}\",\s*player:\s*\".{9}\"',ibacumsXHBdERyOSCDAGWtLeQrhkvF)[0]
   ibacumsXHBdERyOSCDAGWtLeQrhkNw =ibacumsXHBdERyOSCDAGWtLeQrhkNw.replace('bc','"bc"')
   ibacumsXHBdERyOSCDAGWtLeQrhkNw =ibacumsXHBdERyOSCDAGWtLeQrhkNw.replace('player','"player"')
   ibacumsXHBdERyOSCDAGWtLeQrhkNw ='{'+ibacumsXHBdERyOSCDAGWtLeQrhkNw+'}'
   ibacumsXHBdERyOSCDAGWtLeQrhkNw =json.loads(ibacumsXHBdERyOSCDAGWtLeQrhkNw)
   bc =ibacumsXHBdERyOSCDAGWtLeQrhkNw['bc']
   ibacumsXHBdERyOSCDAGWtLeQrhkNv =ibacumsXHBdERyOSCDAGWtLeQrhkNw['player']
   ibacumsXHBdERyOSCDAGWtLeQrhkvq="%s/%s/%s_default/index.min.js"%(ibacumsXHBdERyOSCDAGWtLeQrhkwf.BC_DOMAIN,bc,ibacumsXHBdERyOSCDAGWtLeQrhkNv)
  except ibacumsXHBdERyOSCDAGWtLeQrhkNU as exception:
   ibacumsXHBdERyOSCDAGWtLeQrhkNg(exception)
  return ibacumsXHBdERyOSCDAGWtLeQrhkvq
 def GetPolicyKey(ibacumsXHBdERyOSCDAGWtLeQrhkwf):
  ibacumsXHBdERyOSCDAGWtLeQrhkNo=policykey=''
  try:
   ibacumsXHBdERyOSCDAGWtLeQrhkvo=ibacumsXHBdERyOSCDAGWtLeQrhkwf.GetBcPlayerUrl()
   if ibacumsXHBdERyOSCDAGWtLeQrhkvo=='':return ibacumsXHBdERyOSCDAGWtLeQrhkNo,ibacumsXHBdERyOSCDAGWtLeQrhkNn
   ibacumsXHBdERyOSCDAGWtLeQrhkwx=ibacumsXHBdERyOSCDAGWtLeQrhkwf.callRequestCookies('Get',ibacumsXHBdERyOSCDAGWtLeQrhkvo,payload=ibacumsXHBdERyOSCDAGWtLeQrhkNl,params=ibacumsXHBdERyOSCDAGWtLeQrhkNl,headers=ibacumsXHBdERyOSCDAGWtLeQrhkNl,cookies=ibacumsXHBdERyOSCDAGWtLeQrhkNl)
   ibacumsXHBdERyOSCDAGWtLeQrhkvF=ibacumsXHBdERyOSCDAGWtLeQrhkwx.text
   ibacumsXHBdERyOSCDAGWtLeQrhkvp =re.findall('accountId:\s*\"\d{13}\",\s*policyKey:\s*\".[^(){}]{100,300}\"',ibacumsXHBdERyOSCDAGWtLeQrhkvF)[0]
   ibacumsXHBdERyOSCDAGWtLeQrhkvp =ibacumsXHBdERyOSCDAGWtLeQrhkvp.replace('accountId','"accountId"')
   ibacumsXHBdERyOSCDAGWtLeQrhkvp =ibacumsXHBdERyOSCDAGWtLeQrhkvp.replace('policyKey','"policyKey"')
   ibacumsXHBdERyOSCDAGWtLeQrhkvp ='{'+ibacumsXHBdERyOSCDAGWtLeQrhkvp+'}'
   ibacumsXHBdERyOSCDAGWtLeQrhkNf=json.loads(ibacumsXHBdERyOSCDAGWtLeQrhkvp)
   ibacumsXHBdERyOSCDAGWtLeQrhkNo =ibacumsXHBdERyOSCDAGWtLeQrhkNf['accountId']
   ibacumsXHBdERyOSCDAGWtLeQrhkNn =ibacumsXHBdERyOSCDAGWtLeQrhkNf['policyKey']
  except ibacumsXHBdERyOSCDAGWtLeQrhkNU as exception:
   ibacumsXHBdERyOSCDAGWtLeQrhkNg(exception)
  return ibacumsXHBdERyOSCDAGWtLeQrhkNo,ibacumsXHBdERyOSCDAGWtLeQrhkNn
 def GetBroadURL(ibacumsXHBdERyOSCDAGWtLeQrhkwf,videoId):
  ibacumsXHBdERyOSCDAGWtLeQrhkNV=''
  try:
   ibacumsXHBdERyOSCDAGWtLeQrhkvo=ibacumsXHBdERyOSCDAGWtLeQrhkwf.PLAYER_DOMAIN+'/playback/v1/accounts/'+ibacumsXHBdERyOSCDAGWtLeQrhkwf.SPOTV_ACCOUNTID+'/videos/ref%3A'+videoId
   ibacumsXHBdERyOSCDAGWtLeQrhkNz={'accept':'application/json;pk='+ibacumsXHBdERyOSCDAGWtLeQrhkwf.SPOTV_POLICYKEY}
   ibacumsXHBdERyOSCDAGWtLeQrhkwx=ibacumsXHBdERyOSCDAGWtLeQrhkwf.callRequestCookies('Get',ibacumsXHBdERyOSCDAGWtLeQrhkvo,payload=ibacumsXHBdERyOSCDAGWtLeQrhkNl,params=ibacumsXHBdERyOSCDAGWtLeQrhkNl,headers=ibacumsXHBdERyOSCDAGWtLeQrhkNz,cookies=ibacumsXHBdERyOSCDAGWtLeQrhkNl)
   ibacumsXHBdERyOSCDAGWtLeQrhkNP=json.loads(ibacumsXHBdERyOSCDAGWtLeQrhkwx.text)
   ibacumsXHBdERyOSCDAGWtLeQrhkNV=ibacumsXHBdERyOSCDAGWtLeQrhkNP['sources'][0]['src']
   ibacumsXHBdERyOSCDAGWtLeQrhkNV=ibacumsXHBdERyOSCDAGWtLeQrhkNV.replace('playlist.m3u8','playlist_dvr.m3u8')
  except ibacumsXHBdERyOSCDAGWtLeQrhkNU as exception:
   ibacumsXHBdERyOSCDAGWtLeQrhkNg(exception)
  return ibacumsXHBdERyOSCDAGWtLeQrhkNV
# Created by pyminifier (https://github.com/liftoff/pyminifier)
