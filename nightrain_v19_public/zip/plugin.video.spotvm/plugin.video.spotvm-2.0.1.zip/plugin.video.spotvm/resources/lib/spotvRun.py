__author__="NightRain"
NiuvEsbJdqYROarkBFGpycefQnLITz=object
NiuvEsbJdqYROarkBFGpycefQnLITj=None
NiuvEsbJdqYROarkBFGpycefQnLITU=False
NiuvEsbJdqYROarkBFGpycefQnLITm=True
NiuvEsbJdqYROarkBFGpycefQnLITD=int
NiuvEsbJdqYROarkBFGpycefQnLITP=len
NiuvEsbJdqYROarkBFGpycefQnLITS=open
NiuvEsbJdqYROarkBFGpycefQnLITM=Exception
NiuvEsbJdqYROarkBFGpycefQnLITH=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmc.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
NiuvEsbJdqYROarkBFGpycefQnLIxT=[{'title':'LIVE 채널','mode':'CHANNEL'}]
NiuvEsbJdqYROarkBFGpycefQnLIxh ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36'
NiuvEsbJdqYROarkBFGpycefQnLIxC=xbmc.translatePath(os.path.join(__profile__,'spotv_cookies.json'))
from spotvCore import*
class NiuvEsbJdqYROarkBFGpycefQnLIxK(NiuvEsbJdqYROarkBFGpycefQnLITz):
 def __init__(NiuvEsbJdqYROarkBFGpycefQnLIxz,NiuvEsbJdqYROarkBFGpycefQnLIxj,NiuvEsbJdqYROarkBFGpycefQnLIxU,NiuvEsbJdqYROarkBFGpycefQnLIxm):
  NiuvEsbJdqYROarkBFGpycefQnLIxz._addon_url =NiuvEsbJdqYROarkBFGpycefQnLIxj
  NiuvEsbJdqYROarkBFGpycefQnLIxz._addon_handle=NiuvEsbJdqYROarkBFGpycefQnLIxU
  NiuvEsbJdqYROarkBFGpycefQnLIxz.main_params =NiuvEsbJdqYROarkBFGpycefQnLIxm
  NiuvEsbJdqYROarkBFGpycefQnLIxz.SpotvObj =ibacumsXHBdERyOSCDAGWtLeQrhkwv() 
 def addon_noti(NiuvEsbJdqYROarkBFGpycefQnLIxz,sting):
  try:
   NiuvEsbJdqYROarkBFGpycefQnLIxP=xbmcgui.Dialog()
   NiuvEsbJdqYROarkBFGpycefQnLIxP.notification(__addonname__,sting)
  except:
   NiuvEsbJdqYROarkBFGpycefQnLITj
 def addon_log(NiuvEsbJdqYROarkBFGpycefQnLIxz,string,isDebug=NiuvEsbJdqYROarkBFGpycefQnLITU):
  try:
   NiuvEsbJdqYROarkBFGpycefQnLIxS=string.encode('utf-8','ignore')
  except:
   NiuvEsbJdqYROarkBFGpycefQnLIxS='addonException: addon_log'
  if isDebug:NiuvEsbJdqYROarkBFGpycefQnLIxM=xbmc.LOGDEBUG
  else:NiuvEsbJdqYROarkBFGpycefQnLIxM=xbmc.LOGNOTICE
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,NiuvEsbJdqYROarkBFGpycefQnLIxS),level=NiuvEsbJdqYROarkBFGpycefQnLIxM)
 def get_keyboard_input(NiuvEsbJdqYROarkBFGpycefQnLIxz,NiuvEsbJdqYROarkBFGpycefQnLIxl):
  NiuvEsbJdqYROarkBFGpycefQnLIxH=NiuvEsbJdqYROarkBFGpycefQnLITj
  kb=xbmc.Keyboard()
  kb.setHeading(NiuvEsbJdqYROarkBFGpycefQnLIxl)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   NiuvEsbJdqYROarkBFGpycefQnLIxH=kb.getText()
  return NiuvEsbJdqYROarkBFGpycefQnLIxH
 def get_settings_login_info(NiuvEsbJdqYROarkBFGpycefQnLIxz):
  NiuvEsbJdqYROarkBFGpycefQnLIxA =__addon__.getSetting('id')
  NiuvEsbJdqYROarkBFGpycefQnLIxw =__addon__.getSetting('pw')
  return(NiuvEsbJdqYROarkBFGpycefQnLIxA,NiuvEsbJdqYROarkBFGpycefQnLIxw)
 def set_winCredential(NiuvEsbJdqYROarkBFGpycefQnLIxz,credential):
  NiuvEsbJdqYROarkBFGpycefQnLIxt=xbmcgui.Window(10000)
  NiuvEsbJdqYROarkBFGpycefQnLIxt.setProperty('SPOTV_M_SESSIONID',credential.get('spotv_sessionid'))
  NiuvEsbJdqYROarkBFGpycefQnLIxt.setProperty('SPOTV_M_SESSION',credential.get('spotv_session'))
  NiuvEsbJdqYROarkBFGpycefQnLIxt.setProperty('SPOTV_M_ACCOUNTID',credential.get('spotv_accountId'))
  NiuvEsbJdqYROarkBFGpycefQnLIxt.setProperty('SPOTV_M_POLICYKEY',credential.get('spotv_policyKey'))
  NiuvEsbJdqYROarkBFGpycefQnLIxt.setProperty('SPOTV_M_SUBEND',credential.get('spotv_subend'))
  NiuvEsbJdqYROarkBFGpycefQnLIxt.setProperty('SPOTV_M_LOGINTIME',NiuvEsbJdqYROarkBFGpycefQnLIxz.SpotvObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(NiuvEsbJdqYROarkBFGpycefQnLIxz):
  NiuvEsbJdqYROarkBFGpycefQnLIxt=xbmcgui.Window(10000)
  NiuvEsbJdqYROarkBFGpycefQnLIxX={'spotv_sessionid':NiuvEsbJdqYROarkBFGpycefQnLIxt.getProperty('SPOTV_M_SESSIONID'),'spotv_session':NiuvEsbJdqYROarkBFGpycefQnLIxt.getProperty('SPOTV_M_SESSION'),'spotv_accountId':NiuvEsbJdqYROarkBFGpycefQnLIxt.getProperty('SPOTV_M_ACCOUNTID'),'spotv_policyKey':NiuvEsbJdqYROarkBFGpycefQnLIxt.getProperty('SPOTV_M_POLICYKEY'),'spotv_subend':NiuvEsbJdqYROarkBFGpycefQnLIxt.getProperty('SPOTV_M_SUBEND')}
  return NiuvEsbJdqYROarkBFGpycefQnLIxX
 def add_dir(NiuvEsbJdqYROarkBFGpycefQnLIxz,label,sublabel='',img='',infoLabels=NiuvEsbJdqYROarkBFGpycefQnLITj,isFolder=NiuvEsbJdqYROarkBFGpycefQnLITm,params=''):
  NiuvEsbJdqYROarkBFGpycefQnLIxW='%s?%s'%(NiuvEsbJdqYROarkBFGpycefQnLIxz._addon_url,urllib.parse.urlencode(params))
  if sublabel:NiuvEsbJdqYROarkBFGpycefQnLIxl='%s < %s >'%(label,sublabel)
  else: NiuvEsbJdqYROarkBFGpycefQnLIxl=label
  if not img:img='DefaultFolder.png'
  NiuvEsbJdqYROarkBFGpycefQnLIxo=xbmcgui.ListItem(NiuvEsbJdqYROarkBFGpycefQnLIxl)
  NiuvEsbJdqYROarkBFGpycefQnLIxo.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:NiuvEsbJdqYROarkBFGpycefQnLIxo.setInfo(type="Video",infoLabels=infoLabels)
  if not isFolder:NiuvEsbJdqYROarkBFGpycefQnLIxo.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(NiuvEsbJdqYROarkBFGpycefQnLIxz._addon_handle,NiuvEsbJdqYROarkBFGpycefQnLIxW,NiuvEsbJdqYROarkBFGpycefQnLIxo,isFolder)
 def get_selQuality(NiuvEsbJdqYROarkBFGpycefQnLIxz,etype):
  try:
   NiuvEsbJdqYROarkBFGpycefQnLIxV='selected_quality'
   NiuvEsbJdqYROarkBFGpycefQnLIxg=[1080,720,540]
   NiuvEsbJdqYROarkBFGpycefQnLIKx=NiuvEsbJdqYROarkBFGpycefQnLITD(__addon__.getSetting(NiuvEsbJdqYROarkBFGpycefQnLIxV))
   return NiuvEsbJdqYROarkBFGpycefQnLIxg[NiuvEsbJdqYROarkBFGpycefQnLIKx]
  except:
   NiuvEsbJdqYROarkBFGpycefQnLITj
  return 1080 
 def dp_Main_List(NiuvEsbJdqYROarkBFGpycefQnLIxz):
  for NiuvEsbJdqYROarkBFGpycefQnLIKT in NiuvEsbJdqYROarkBFGpycefQnLIxT:
   NiuvEsbJdqYROarkBFGpycefQnLIxl=NiuvEsbJdqYROarkBFGpycefQnLIKT.get('title')
   NiuvEsbJdqYROarkBFGpycefQnLIKh={'mode':NiuvEsbJdqYROarkBFGpycefQnLIKT.get('mode')}
   if NiuvEsbJdqYROarkBFGpycefQnLIKT.get('mode')=='XXX':
    NiuvEsbJdqYROarkBFGpycefQnLIKh['mode']='XXX'
    NiuvEsbJdqYROarkBFGpycefQnLIKC=NiuvEsbJdqYROarkBFGpycefQnLITU
   else:
    NiuvEsbJdqYROarkBFGpycefQnLIKC=NiuvEsbJdqYROarkBFGpycefQnLITm
   NiuvEsbJdqYROarkBFGpycefQnLIxz.add_dir(NiuvEsbJdqYROarkBFGpycefQnLIxl,sublabel='',img='',infoLabels=NiuvEsbJdqYROarkBFGpycefQnLITj,isFolder=NiuvEsbJdqYROarkBFGpycefQnLIKC,params=NiuvEsbJdqYROarkBFGpycefQnLIKh)
  if NiuvEsbJdqYROarkBFGpycefQnLITP(NiuvEsbJdqYROarkBFGpycefQnLIxT)>0:xbmcplugin.endOfDirectory(NiuvEsbJdqYROarkBFGpycefQnLIxz._addon_handle)
 def login_main(NiuvEsbJdqYROarkBFGpycefQnLIxz):
  (NiuvEsbJdqYROarkBFGpycefQnLIKj,NiuvEsbJdqYROarkBFGpycefQnLIKU)=NiuvEsbJdqYROarkBFGpycefQnLIxz.get_settings_login_info()
  if not(NiuvEsbJdqYROarkBFGpycefQnLIKj and NiuvEsbJdqYROarkBFGpycefQnLIKU):
   NiuvEsbJdqYROarkBFGpycefQnLIxP=xbmcgui.Dialog()
   NiuvEsbJdqYROarkBFGpycefQnLIKm=NiuvEsbJdqYROarkBFGpycefQnLIxP.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if NiuvEsbJdqYROarkBFGpycefQnLIKm==NiuvEsbJdqYROarkBFGpycefQnLITm:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if NiuvEsbJdqYROarkBFGpycefQnLIxz.cookiefile_check():return
  NiuvEsbJdqYROarkBFGpycefQnLIKD =NiuvEsbJdqYROarkBFGpycefQnLITD(NiuvEsbJdqYROarkBFGpycefQnLIxz.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))
  NiuvEsbJdqYROarkBFGpycefQnLIKP=xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINTIME')
  if NiuvEsbJdqYROarkBFGpycefQnLIKP==NiuvEsbJdqYROarkBFGpycefQnLITj or NiuvEsbJdqYROarkBFGpycefQnLIKP=='':NiuvEsbJdqYROarkBFGpycefQnLIKP=NiuvEsbJdqYROarkBFGpycefQnLITD('19000101')
  if xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINWAIT')=='TRUE':
   NiuvEsbJdqYROarkBFGpycefQnLIKS=0
   while NiuvEsbJdqYROarkBFGpycefQnLITm:
    NiuvEsbJdqYROarkBFGpycefQnLIKS+=1
    time.sleep(0.05)
    if NiuvEsbJdqYROarkBFGpycefQnLIKP>=NiuvEsbJdqYROarkBFGpycefQnLIKD:return
    if NiuvEsbJdqYROarkBFGpycefQnLIKS>600:return
  else:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','TRUE')
  if NiuvEsbJdqYROarkBFGpycefQnLIKP>=NiuvEsbJdqYROarkBFGpycefQnLIKD:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
   return
  if not NiuvEsbJdqYROarkBFGpycefQnLIxz.SpotvObj.GetCredential(NiuvEsbJdqYROarkBFGpycefQnLIKj,NiuvEsbJdqYROarkBFGpycefQnLIKU):
   NiuvEsbJdqYROarkBFGpycefQnLIxz.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
   sys.exit()
  NiuvEsbJdqYROarkBFGpycefQnLIxz.set_winCredential(NiuvEsbJdqYROarkBFGpycefQnLIxz.SpotvObj.LoadCredential())
  NiuvEsbJdqYROarkBFGpycefQnLIxz.cookiefile_save()
  xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
 def dp_LiveChannel_List(NiuvEsbJdqYROarkBFGpycefQnLIxz,args):
  NiuvEsbJdqYROarkBFGpycefQnLIxz.SpotvObj.SaveCredential(NiuvEsbJdqYROarkBFGpycefQnLIxz.get_winCredential())
  NiuvEsbJdqYROarkBFGpycefQnLIKM=NiuvEsbJdqYROarkBFGpycefQnLIxz.SpotvObj.GetLiveChannelList()
  for NiuvEsbJdqYROarkBFGpycefQnLIKH in NiuvEsbJdqYROarkBFGpycefQnLIKM:
   NiuvEsbJdqYROarkBFGpycefQnLIxl =NiuvEsbJdqYROarkBFGpycefQnLIKH.get('name')
   NiuvEsbJdqYROarkBFGpycefQnLIKz =NiuvEsbJdqYROarkBFGpycefQnLIKH.get('programName')
   NiuvEsbJdqYROarkBFGpycefQnLIKA =NiuvEsbJdqYROarkBFGpycefQnLIKH.get('logo')
   NiuvEsbJdqYROarkBFGpycefQnLIKw=NiuvEsbJdqYROarkBFGpycefQnLIKH.get('channelepg')
   NiuvEsbJdqYROarkBFGpycefQnLIKt =NiuvEsbJdqYROarkBFGpycefQnLIKH.get('free')
   NiuvEsbJdqYROarkBFGpycefQnLIKX=NiuvEsbJdqYROarkBFGpycefQnLIKH.get('info')
   NiuvEsbJdqYROarkBFGpycefQnLIKX['plot']='%s'%(NiuvEsbJdqYROarkBFGpycefQnLIKw)
   NiuvEsbJdqYROarkBFGpycefQnLIKh={'mode':'LIVE','mediaid':NiuvEsbJdqYROarkBFGpycefQnLIKH.get('id'),'mediacode':NiuvEsbJdqYROarkBFGpycefQnLIKH.get('videoId'),'free':NiuvEsbJdqYROarkBFGpycefQnLIKt}
   if NiuvEsbJdqYROarkBFGpycefQnLIKt:NiuvEsbJdqYROarkBFGpycefQnLIxl+=' [free]'
   NiuvEsbJdqYROarkBFGpycefQnLIxz.add_dir(NiuvEsbJdqYROarkBFGpycefQnLIxl,sublabel=NiuvEsbJdqYROarkBFGpycefQnLIKz,img=NiuvEsbJdqYROarkBFGpycefQnLIKA,infoLabels=NiuvEsbJdqYROarkBFGpycefQnLIKX,isFolder=NiuvEsbJdqYROarkBFGpycefQnLITU,params=NiuvEsbJdqYROarkBFGpycefQnLIKh)
  if NiuvEsbJdqYROarkBFGpycefQnLITP(NiuvEsbJdqYROarkBFGpycefQnLIKM)>0:xbmcplugin.endOfDirectory(NiuvEsbJdqYROarkBFGpycefQnLIxz._addon_handle,cacheToDisc=NiuvEsbJdqYROarkBFGpycefQnLITU)
 def play_VIDEO(NiuvEsbJdqYROarkBFGpycefQnLIxz,args):
  NiuvEsbJdqYROarkBFGpycefQnLIxz.SpotvObj.SaveCredential(NiuvEsbJdqYROarkBFGpycefQnLIxz.get_winCredential())
  if args.get('free')=='False':
   if NiuvEsbJdqYROarkBFGpycefQnLIxz.SpotvObj.CheckSubEnd()==NiuvEsbJdqYROarkBFGpycefQnLITU:
    NiuvEsbJdqYROarkBFGpycefQnLIxz.addon_noti(__language__(30908).encode('utf8'))
    return
  NiuvEsbJdqYROarkBFGpycefQnLIKW =args.get('mediacode')
  NiuvEsbJdqYROarkBFGpycefQnLIKl=NiuvEsbJdqYROarkBFGpycefQnLIxz.SpotvObj.GetBroadURL(NiuvEsbJdqYROarkBFGpycefQnLIKW)
  if NiuvEsbJdqYROarkBFGpycefQnLIKl=='':
   NiuvEsbJdqYROarkBFGpycefQnLIxz.addon_noti(__language__(30908).encode('utf8'))
   return
  NiuvEsbJdqYROarkBFGpycefQnLIKo=NiuvEsbJdqYROarkBFGpycefQnLIKl
  NiuvEsbJdqYROarkBFGpycefQnLIxz.addon_log(NiuvEsbJdqYROarkBFGpycefQnLIKo,NiuvEsbJdqYROarkBFGpycefQnLITU)
  NiuvEsbJdqYROarkBFGpycefQnLIKV=xbmcgui.ListItem(path=NiuvEsbJdqYROarkBFGpycefQnLIKo)
  xbmcplugin.setResolvedUrl(NiuvEsbJdqYROarkBFGpycefQnLIxz._addon_handle,NiuvEsbJdqYROarkBFGpycefQnLITm,NiuvEsbJdqYROarkBFGpycefQnLIKV)
 def logout(NiuvEsbJdqYROarkBFGpycefQnLIxz):
  NiuvEsbJdqYROarkBFGpycefQnLIxP=xbmcgui.Dialog()
  NiuvEsbJdqYROarkBFGpycefQnLIKm=NiuvEsbJdqYROarkBFGpycefQnLIxP.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if NiuvEsbJdqYROarkBFGpycefQnLIKm==NiuvEsbJdqYROarkBFGpycefQnLITU:sys.exit()
  NiuvEsbJdqYROarkBFGpycefQnLIxz.wininfo_clear()
  if os.path.isfile(NiuvEsbJdqYROarkBFGpycefQnLIxC):os.remove(NiuvEsbJdqYROarkBFGpycefQnLIxC)
  NiuvEsbJdqYROarkBFGpycefQnLIxz.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(NiuvEsbJdqYROarkBFGpycefQnLIxz):
  NiuvEsbJdqYROarkBFGpycefQnLIxt=xbmcgui.Window(10000)
  NiuvEsbJdqYROarkBFGpycefQnLIxt.setProperty('SPOTV_M_SESSIONID','')
  NiuvEsbJdqYROarkBFGpycefQnLIxt.setProperty('SPOTV_M_SESSION','')
  NiuvEsbJdqYROarkBFGpycefQnLIxt.setProperty('SPOTV_M_ACCOUNTID','')
  NiuvEsbJdqYROarkBFGpycefQnLIxt.setProperty('SPOTV_M_POLICYKEY','')
  NiuvEsbJdqYROarkBFGpycefQnLIxt.setProperty('SPOTV_M_SUBEND','')
  NiuvEsbJdqYROarkBFGpycefQnLIxt.setProperty('SPOTV_M_LOGINTIME','')
 def cookiefile_save(NiuvEsbJdqYROarkBFGpycefQnLIxz):
  NiuvEsbJdqYROarkBFGpycefQnLIKg =NiuvEsbJdqYROarkBFGpycefQnLIxz.SpotvObj.Get_Now_Datetime()
  NiuvEsbJdqYROarkBFGpycefQnLITx=NiuvEsbJdqYROarkBFGpycefQnLIKg+datetime.timedelta(days=NiuvEsbJdqYROarkBFGpycefQnLITD(__addon__.getSetting('cache_ttl')))
  NiuvEsbJdqYROarkBFGpycefQnLIxt=xbmcgui.Window(10000)
  NiuvEsbJdqYROarkBFGpycefQnLITK={'spotv_sessionid':NiuvEsbJdqYROarkBFGpycefQnLIxt.getProperty('SPOTV_M_SESSIONID'),'spotv_session':NiuvEsbJdqYROarkBFGpycefQnLIxt.getProperty('SPOTV_M_SESSION'),'spotv_accountId':NiuvEsbJdqYROarkBFGpycefQnLIxt.getProperty('SPOTV_M_ACCOUNTID'),'spotv_policyKey':base64.standard_b64encode(NiuvEsbJdqYROarkBFGpycefQnLIxt.getProperty('SPOTV_M_POLICYKEY').encode()).decode('utf-8'),'spotv_subend':base64.standard_b64encode((NiuvEsbJdqYROarkBFGpycefQnLIxz.SpotvObj.SPOTV_PMCODE+NiuvEsbJdqYROarkBFGpycefQnLIxt.getProperty('SPOTV_M_SUBEND')).encode()).decode('utf-8'),'spotv_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'spotv_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'spotv_limitdate':NiuvEsbJdqYROarkBFGpycefQnLITx.strftime('%Y-%m-%d')}
  try: 
   fp=NiuvEsbJdqYROarkBFGpycefQnLITS(NiuvEsbJdqYROarkBFGpycefQnLIxC,'w',-1,'utf-8')
   json.dump(NiuvEsbJdqYROarkBFGpycefQnLITK,fp)
   fp.close()
  except NiuvEsbJdqYROarkBFGpycefQnLITM as exception:
   NiuvEsbJdqYROarkBFGpycefQnLITH(exception)
 def cookiefile_check(NiuvEsbJdqYROarkBFGpycefQnLIxz):
  NiuvEsbJdqYROarkBFGpycefQnLITK={}
  try: 
   fp=NiuvEsbJdqYROarkBFGpycefQnLITS(NiuvEsbJdqYROarkBFGpycefQnLIxC,'r',-1,'utf-8')
   NiuvEsbJdqYROarkBFGpycefQnLITK= json.load(fp)
   fp.close()
  except NiuvEsbJdqYROarkBFGpycefQnLITM as exception:
   NiuvEsbJdqYROarkBFGpycefQnLIxz.wininfo_clear()
   return NiuvEsbJdqYROarkBFGpycefQnLITU
  NiuvEsbJdqYROarkBFGpycefQnLIKj =__addon__.getSetting('id')
  NiuvEsbJdqYROarkBFGpycefQnLIKU =__addon__.getSetting('pw')
  NiuvEsbJdqYROarkBFGpycefQnLITK['spotv_id'] =base64.standard_b64decode(NiuvEsbJdqYROarkBFGpycefQnLITK['spotv_id']).decode('utf-8')
  NiuvEsbJdqYROarkBFGpycefQnLITK['spotv_pw'] =base64.standard_b64decode(NiuvEsbJdqYROarkBFGpycefQnLITK['spotv_pw']).decode('utf-8')
  NiuvEsbJdqYROarkBFGpycefQnLITK['spotv_policyKey']=base64.standard_b64decode(NiuvEsbJdqYROarkBFGpycefQnLITK['spotv_policyKey']).decode('utf-8')
  NiuvEsbJdqYROarkBFGpycefQnLITK['spotv_subend']=base64.standard_b64decode(NiuvEsbJdqYROarkBFGpycefQnLITK['spotv_subend']).decode('utf-8')[NiuvEsbJdqYROarkBFGpycefQnLIxz.SpotvObj.SPOTV_PMSIZE:]
  if NiuvEsbJdqYROarkBFGpycefQnLIKj!=NiuvEsbJdqYROarkBFGpycefQnLITK['spotv_id']or NiuvEsbJdqYROarkBFGpycefQnLIKU!=NiuvEsbJdqYROarkBFGpycefQnLITK['spotv_pw']:
   NiuvEsbJdqYROarkBFGpycefQnLIxz.wininfo_clear()
   return NiuvEsbJdqYROarkBFGpycefQnLITU
  NiuvEsbJdqYROarkBFGpycefQnLIKD =NiuvEsbJdqYROarkBFGpycefQnLITD(NiuvEsbJdqYROarkBFGpycefQnLIxz.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))
  NiuvEsbJdqYROarkBFGpycefQnLITh=NiuvEsbJdqYROarkBFGpycefQnLITK['spotv_limitdate']
  NiuvEsbJdqYROarkBFGpycefQnLIKP =NiuvEsbJdqYROarkBFGpycefQnLITD(re.sub('-','',NiuvEsbJdqYROarkBFGpycefQnLITh))
  if NiuvEsbJdqYROarkBFGpycefQnLIKP<NiuvEsbJdqYROarkBFGpycefQnLIKD:
   NiuvEsbJdqYROarkBFGpycefQnLIxz.wininfo_clear()
   return NiuvEsbJdqYROarkBFGpycefQnLITU
  NiuvEsbJdqYROarkBFGpycefQnLIxt=xbmcgui.Window(10000)
  NiuvEsbJdqYROarkBFGpycefQnLIxt.setProperty('SPOTV_M_SESSIONID',NiuvEsbJdqYROarkBFGpycefQnLITK['spotv_sessionid'])
  NiuvEsbJdqYROarkBFGpycefQnLIxt.setProperty('SPOTV_M_SESSION',NiuvEsbJdqYROarkBFGpycefQnLITK['spotv_session'])
  NiuvEsbJdqYROarkBFGpycefQnLIxt.setProperty('SPOTV_M_ACCOUNTID',NiuvEsbJdqYROarkBFGpycefQnLITK['spotv_accountId'])
  NiuvEsbJdqYROarkBFGpycefQnLIxt.setProperty('SPOTV_M_POLICYKEY',NiuvEsbJdqYROarkBFGpycefQnLITK['spotv_policyKey'])
  NiuvEsbJdqYROarkBFGpycefQnLIxt.setProperty('SPOTV_M_SUBEND',NiuvEsbJdqYROarkBFGpycefQnLITK['spotv_subend'])
  NiuvEsbJdqYROarkBFGpycefQnLIxt.setProperty('SPOTV_M_LOGINTIME',NiuvEsbJdqYROarkBFGpycefQnLITh)
  return NiuvEsbJdqYROarkBFGpycefQnLITm
 def spotv_main(NiuvEsbJdqYROarkBFGpycefQnLIxz):
  NiuvEsbJdqYROarkBFGpycefQnLITC=NiuvEsbJdqYROarkBFGpycefQnLIxz.main_params.get('mode',NiuvEsbJdqYROarkBFGpycefQnLITj)
  if NiuvEsbJdqYROarkBFGpycefQnLITC=='LOGOUT':
   NiuvEsbJdqYROarkBFGpycefQnLIxz.logout()
   return
  NiuvEsbJdqYROarkBFGpycefQnLIxz.login_main()
  if NiuvEsbJdqYROarkBFGpycefQnLITC is NiuvEsbJdqYROarkBFGpycefQnLITj:
   NiuvEsbJdqYROarkBFGpycefQnLIxz.dp_Main_List()
  elif NiuvEsbJdqYROarkBFGpycefQnLITC=='CHANNEL':
   NiuvEsbJdqYROarkBFGpycefQnLIxz.dp_LiveChannel_List(NiuvEsbJdqYROarkBFGpycefQnLIxz.main_params)
  elif NiuvEsbJdqYROarkBFGpycefQnLITC in['LIVE']:
   NiuvEsbJdqYROarkBFGpycefQnLIxz.play_VIDEO(NiuvEsbJdqYROarkBFGpycefQnLIxz.main_params)
  elif NiuvEsbJdqYROarkBFGpycefQnLITC=='LOGOUT':
   NiuvEsbJdqYROarkBFGpycefQnLIxz.logout()
  else:
   NiuvEsbJdqYROarkBFGpycefQnLITj
# Created by pyminifier (https://github.com/liftoff/pyminifier)
