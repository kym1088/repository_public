__author__="NightRain"
pxBPeuESizswFlYNCdfyJHMKgqXWjn=object
pxBPeuESizswFlYNCdfyJHMKgqXWjv=None
pxBPeuESizswFlYNCdfyJHMKgqXWjU=False
pxBPeuESizswFlYNCdfyJHMKgqXWjI=True
pxBPeuESizswFlYNCdfyJHMKgqXWjm=int
pxBPeuESizswFlYNCdfyJHMKgqXWjA=len
pxBPeuESizswFlYNCdfyJHMKgqXWjD=str
pxBPeuESizswFlYNCdfyJHMKgqXWjh=open
pxBPeuESizswFlYNCdfyJHMKgqXWjL=Exception
pxBPeuESizswFlYNCdfyJHMKgqXWjT=print
pxBPeuESizswFlYNCdfyJHMKgqXWjo=dict
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
pxBPeuESizswFlYNCdfyJHMKgqXWkR=[{'title':'Live중계 (경기중에만 재생)','mode':'ELIVE_GROUP','icon':'live.png'},{'title':'-----------------','mode':'XXX'},{'title':'오늘의 추천 VOD','mode':'NOW_GROUP'},{'title':'인기영상 5','mode':'POP_GROUP'},{'title':'-----------------','mode':'XXX'},{'title':'VOD (리그, 경기별)','mode':'VOD_GROUP'},{'title':'Watched (시청목록)','mode':'WATCH','icon':'history.png'},]
pxBPeuESizswFlYNCdfyJHMKgqXWkr=xbmcvfs.translatePath(os.path.join(__profile__,'spotv_cookies.json'))
from spotvCore import*
class pxBPeuESizswFlYNCdfyJHMKgqXWkb(pxBPeuESizswFlYNCdfyJHMKgqXWjn):
 def __init__(pxBPeuESizswFlYNCdfyJHMKgqXWkj,pxBPeuESizswFlYNCdfyJHMKgqXWkc,pxBPeuESizswFlYNCdfyJHMKgqXWkt,pxBPeuESizswFlYNCdfyJHMKgqXWkV):
  pxBPeuESizswFlYNCdfyJHMKgqXWkj._addon_url =pxBPeuESizswFlYNCdfyJHMKgqXWkc
  pxBPeuESizswFlYNCdfyJHMKgqXWkj._addon_handle=pxBPeuESizswFlYNCdfyJHMKgqXWkt
  pxBPeuESizswFlYNCdfyJHMKgqXWkj.main_params =pxBPeuESizswFlYNCdfyJHMKgqXWkV
  pxBPeuESizswFlYNCdfyJHMKgqXWkj.SpotvObj =XiHChLvzSrbwDcIyRUAlupKeQGmWYT() 
 def addon_noti(pxBPeuESizswFlYNCdfyJHMKgqXWkj,sting):
  try:
   pxBPeuESizswFlYNCdfyJHMKgqXWkG=xbmcgui.Dialog()
   pxBPeuESizswFlYNCdfyJHMKgqXWkG.notification(__addonname__,sting)
  except:
   pxBPeuESizswFlYNCdfyJHMKgqXWjv
 def addon_log(pxBPeuESizswFlYNCdfyJHMKgqXWkj,string):
  try:
   pxBPeuESizswFlYNCdfyJHMKgqXWkn=string.encode('utf-8','ignore')
  except:
   pxBPeuESizswFlYNCdfyJHMKgqXWkn='addonException: addon_log'
  pxBPeuESizswFlYNCdfyJHMKgqXWkv=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,pxBPeuESizswFlYNCdfyJHMKgqXWkn),level=pxBPeuESizswFlYNCdfyJHMKgqXWkv)
 def get_keyboard_input(pxBPeuESizswFlYNCdfyJHMKgqXWkj,pxBPeuESizswFlYNCdfyJHMKgqXWkT):
  pxBPeuESizswFlYNCdfyJHMKgqXWkU=pxBPeuESizswFlYNCdfyJHMKgqXWjv
  kb=xbmc.Keyboard()
  kb.setHeading(pxBPeuESizswFlYNCdfyJHMKgqXWkT)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   pxBPeuESizswFlYNCdfyJHMKgqXWkU=kb.getText()
  return pxBPeuESizswFlYNCdfyJHMKgqXWkU
 def get_settings_login_info(pxBPeuESizswFlYNCdfyJHMKgqXWkj):
  pxBPeuESizswFlYNCdfyJHMKgqXWkI =__addon__.getSetting('id')
  pxBPeuESizswFlYNCdfyJHMKgqXWkm =__addon__.getSetting('pw')
  return(pxBPeuESizswFlYNCdfyJHMKgqXWkI,pxBPeuESizswFlYNCdfyJHMKgqXWkm)
 def get_settings_hidescoreyn(pxBPeuESizswFlYNCdfyJHMKgqXWkj):
  pxBPeuESizswFlYNCdfyJHMKgqXWkA =__addon__.getSetting('hidescore')
  if pxBPeuESizswFlYNCdfyJHMKgqXWkA=='false':
   return pxBPeuESizswFlYNCdfyJHMKgqXWjU
  else:
   return pxBPeuESizswFlYNCdfyJHMKgqXWjI
 def set_winCredential(pxBPeuESizswFlYNCdfyJHMKgqXWkj,credential):
  pxBPeuESizswFlYNCdfyJHMKgqXWkD=xbmcgui.Window(10000)
  pxBPeuESizswFlYNCdfyJHMKgqXWkD.setProperty('SPOTV_M_SESSIONID',credential.get('spotv_sessionid'))
  pxBPeuESizswFlYNCdfyJHMKgqXWkD.setProperty('SPOTV_M_SESSION',credential.get('spotv_session'))
  pxBPeuESizswFlYNCdfyJHMKgqXWkD.setProperty('SPOTV_M_ACCOUNTID',credential.get('spotv_accountId'))
  pxBPeuESizswFlYNCdfyJHMKgqXWkD.setProperty('SPOTV_M_POLICYKEY',credential.get('spotv_policyKey'))
  pxBPeuESizswFlYNCdfyJHMKgqXWkD.setProperty('SPOTV_M_SUBEND',credential.get('spotv_subend'))
  pxBPeuESizswFlYNCdfyJHMKgqXWkD.setProperty('SPOTV_M_LOGINTIME',pxBPeuESizswFlYNCdfyJHMKgqXWkj.SpotvObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(pxBPeuESizswFlYNCdfyJHMKgqXWkj):
  pxBPeuESizswFlYNCdfyJHMKgqXWkD=xbmcgui.Window(10000)
  pxBPeuESizswFlYNCdfyJHMKgqXWkh={'spotv_sessionid':pxBPeuESizswFlYNCdfyJHMKgqXWkD.getProperty('SPOTV_M_SESSIONID'),'spotv_session':pxBPeuESizswFlYNCdfyJHMKgqXWkD.getProperty('SPOTV_M_SESSION'),'spotv_accountId':pxBPeuESizswFlYNCdfyJHMKgqXWkD.getProperty('SPOTV_M_ACCOUNTID'),'spotv_policyKey':pxBPeuESizswFlYNCdfyJHMKgqXWkD.getProperty('SPOTV_M_POLICYKEY'),'spotv_subend':pxBPeuESizswFlYNCdfyJHMKgqXWkD.getProperty('SPOTV_M_SUBEND')}
  return pxBPeuESizswFlYNCdfyJHMKgqXWkh
 def add_dir(pxBPeuESizswFlYNCdfyJHMKgqXWkj,label,sublabel='',img='',infoLabels=pxBPeuESizswFlYNCdfyJHMKgqXWjv,isFolder=pxBPeuESizswFlYNCdfyJHMKgqXWjI,params='',isLink=pxBPeuESizswFlYNCdfyJHMKgqXWjU,ContextMenu=pxBPeuESizswFlYNCdfyJHMKgqXWjv):
  pxBPeuESizswFlYNCdfyJHMKgqXWkL='%s?%s'%(pxBPeuESizswFlYNCdfyJHMKgqXWkj._addon_url,urllib.parse.urlencode(params))
  if sublabel:pxBPeuESizswFlYNCdfyJHMKgqXWkT='%s < %s >'%(label,sublabel)
  else: pxBPeuESizswFlYNCdfyJHMKgqXWkT=label
  if not img:img='DefaultFolder.png'
  pxBPeuESizswFlYNCdfyJHMKgqXWko=xbmcgui.ListItem(pxBPeuESizswFlYNCdfyJHMKgqXWkT)
  pxBPeuESizswFlYNCdfyJHMKgqXWko.setArt({'thumb':img,'icon':img,'poster':img})
  if infoLabels:pxBPeuESizswFlYNCdfyJHMKgqXWko.setInfo(type="Video",infoLabels=infoLabels)
  if not isFolder and not isLink:
   pxBPeuESizswFlYNCdfyJHMKgqXWko.setProperty('IsPlayable','true')
  if ContextMenu:pxBPeuESizswFlYNCdfyJHMKgqXWko.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(pxBPeuESizswFlYNCdfyJHMKgqXWkj._addon_handle,pxBPeuESizswFlYNCdfyJHMKgqXWkL,pxBPeuESizswFlYNCdfyJHMKgqXWko,isFolder)
 def get_selQuality(pxBPeuESizswFlYNCdfyJHMKgqXWkj,etype):
  try:
   pxBPeuESizswFlYNCdfyJHMKgqXWkQ='selected_quality'
   pxBPeuESizswFlYNCdfyJHMKgqXWkO=[1080,720,540]
   pxBPeuESizswFlYNCdfyJHMKgqXWbk=pxBPeuESizswFlYNCdfyJHMKgqXWjm(__addon__.getSetting(pxBPeuESizswFlYNCdfyJHMKgqXWkQ))
   return pxBPeuESizswFlYNCdfyJHMKgqXWkO[pxBPeuESizswFlYNCdfyJHMKgqXWbk]
  except:
   pxBPeuESizswFlYNCdfyJHMKgqXWjv
  return 1080 
 def dp_Main_List(pxBPeuESizswFlYNCdfyJHMKgqXWkj):
  for pxBPeuESizswFlYNCdfyJHMKgqXWbR in pxBPeuESizswFlYNCdfyJHMKgqXWkR:
   pxBPeuESizswFlYNCdfyJHMKgqXWkT=pxBPeuESizswFlYNCdfyJHMKgqXWbR.get('title')
   pxBPeuESizswFlYNCdfyJHMKgqXWbr=''
   pxBPeuESizswFlYNCdfyJHMKgqXWbj={'mode':pxBPeuESizswFlYNCdfyJHMKgqXWbR.get('mode'),'page':'1'}
   if pxBPeuESizswFlYNCdfyJHMKgqXWbR.get('mode')=='XXX':
    pxBPeuESizswFlYNCdfyJHMKgqXWbc=pxBPeuESizswFlYNCdfyJHMKgqXWjU
    pxBPeuESizswFlYNCdfyJHMKgqXWbt =pxBPeuESizswFlYNCdfyJHMKgqXWjI
   else:
    pxBPeuESizswFlYNCdfyJHMKgqXWbc=pxBPeuESizswFlYNCdfyJHMKgqXWjI
    pxBPeuESizswFlYNCdfyJHMKgqXWbt =pxBPeuESizswFlYNCdfyJHMKgqXWjU
   if 'icon' in pxBPeuESizswFlYNCdfyJHMKgqXWbR:pxBPeuESizswFlYNCdfyJHMKgqXWbr=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',pxBPeuESizswFlYNCdfyJHMKgqXWbR.get('icon')) 
   pxBPeuESizswFlYNCdfyJHMKgqXWkj.add_dir(pxBPeuESizswFlYNCdfyJHMKgqXWkT,sublabel='',img=pxBPeuESizswFlYNCdfyJHMKgqXWbr,infoLabels=pxBPeuESizswFlYNCdfyJHMKgqXWjv,isFolder=pxBPeuESizswFlYNCdfyJHMKgqXWbc,params=pxBPeuESizswFlYNCdfyJHMKgqXWbj,isLink=pxBPeuESizswFlYNCdfyJHMKgqXWbt)
  if pxBPeuESizswFlYNCdfyJHMKgqXWjA(pxBPeuESizswFlYNCdfyJHMKgqXWkR)>0:xbmcplugin.endOfDirectory(pxBPeuESizswFlYNCdfyJHMKgqXWkj._addon_handle)
 def dp_MainLeague_List(pxBPeuESizswFlYNCdfyJHMKgqXWkj,args):
  pxBPeuESizswFlYNCdfyJHMKgqXWkj.SpotvObj.SaveCredential(pxBPeuESizswFlYNCdfyJHMKgqXWkj.get_winCredential())
  pxBPeuESizswFlYNCdfyJHMKgqXWba=pxBPeuESizswFlYNCdfyJHMKgqXWkj.SpotvObj.GetTitleGroupList()
  for pxBPeuESizswFlYNCdfyJHMKgqXWbG in pxBPeuESizswFlYNCdfyJHMKgqXWba:
   pxBPeuESizswFlYNCdfyJHMKgqXWkT =pxBPeuESizswFlYNCdfyJHMKgqXWbG.get('title')
   pxBPeuESizswFlYNCdfyJHMKgqXWbn =pxBPeuESizswFlYNCdfyJHMKgqXWbG.get('logo')
   pxBPeuESizswFlYNCdfyJHMKgqXWbv =pxBPeuESizswFlYNCdfyJHMKgqXWbG.get('reagueId')
   pxBPeuESizswFlYNCdfyJHMKgqXWbU =pxBPeuESizswFlYNCdfyJHMKgqXWbG.get('subGame')
   pxBPeuESizswFlYNCdfyJHMKgqXWbI={'mediatype':'episode','plot':'%s\n\n%s'%(pxBPeuESizswFlYNCdfyJHMKgqXWkT,pxBPeuESizswFlYNCdfyJHMKgqXWbU)}
   pxBPeuESizswFlYNCdfyJHMKgqXWbj={'mode':'LEAGUE_GROUP','reagueId':pxBPeuESizswFlYNCdfyJHMKgqXWbv}
   pxBPeuESizswFlYNCdfyJHMKgqXWkj.add_dir(pxBPeuESizswFlYNCdfyJHMKgqXWkT,sublabel=pxBPeuESizswFlYNCdfyJHMKgqXWjv,img=pxBPeuESizswFlYNCdfyJHMKgqXWbn,infoLabels=pxBPeuESizswFlYNCdfyJHMKgqXWbI,isFolder=pxBPeuESizswFlYNCdfyJHMKgqXWjI,params=pxBPeuESizswFlYNCdfyJHMKgqXWbj)
  if pxBPeuESizswFlYNCdfyJHMKgqXWjA(pxBPeuESizswFlYNCdfyJHMKgqXWba)>0:xbmcplugin.endOfDirectory(pxBPeuESizswFlYNCdfyJHMKgqXWkj._addon_handle,cacheToDisc=pxBPeuESizswFlYNCdfyJHMKgqXWjU)
 def dp_NowVod_GroupList(pxBPeuESizswFlYNCdfyJHMKgqXWkj,args):
  pxBPeuESizswFlYNCdfyJHMKgqXWkj.SpotvObj.SaveCredential(pxBPeuESizswFlYNCdfyJHMKgqXWkj.get_winCredential())
  pxBPeuESizswFlYNCdfyJHMKgqXWbm=pxBPeuESizswFlYNCdfyJHMKgqXWjm(args.get('page'))
  pxBPeuESizswFlYNCdfyJHMKgqXWba,pxBPeuESizswFlYNCdfyJHMKgqXWbA=pxBPeuESizswFlYNCdfyJHMKgqXWkj.SpotvObj.Get_NowVod_GroupList(pxBPeuESizswFlYNCdfyJHMKgqXWbm)
  for pxBPeuESizswFlYNCdfyJHMKgqXWbG in pxBPeuESizswFlYNCdfyJHMKgqXWba:
   pxBPeuESizswFlYNCdfyJHMKgqXWbD =pxBPeuESizswFlYNCdfyJHMKgqXWbG.get('vodTitle')
   pxBPeuESizswFlYNCdfyJHMKgqXWbh =pxBPeuESizswFlYNCdfyJHMKgqXWbG.get('vodId')
   pxBPeuESizswFlYNCdfyJHMKgqXWbL =pxBPeuESizswFlYNCdfyJHMKgqXWbG.get('vodType')
   pxBPeuESizswFlYNCdfyJHMKgqXWbn=pxBPeuESizswFlYNCdfyJHMKgqXWbG.get('thumbnail')
   pxBPeuESizswFlYNCdfyJHMKgqXWbT =pxBPeuESizswFlYNCdfyJHMKgqXWbG.get('vtypeId')
   pxBPeuESizswFlYNCdfyJHMKgqXWbo =pxBPeuESizswFlYNCdfyJHMKgqXWbG.get('duration')
   pxBPeuESizswFlYNCdfyJHMKgqXWbI={'mediatype':'video','duration':pxBPeuESizswFlYNCdfyJHMKgqXWbo,'plot':pxBPeuESizswFlYNCdfyJHMKgqXWbD}
   pxBPeuESizswFlYNCdfyJHMKgqXWbj={'mode':'NOW_VOD','mediacode':pxBPeuESizswFlYNCdfyJHMKgqXWbh,'mediatype':'vod','vtypeId':pxBPeuESizswFlYNCdfyJHMKgqXWbT}
   pxBPeuESizswFlYNCdfyJHMKgqXWkj.add_dir(pxBPeuESizswFlYNCdfyJHMKgqXWbD,sublabel=pxBPeuESizswFlYNCdfyJHMKgqXWbL,img=pxBPeuESizswFlYNCdfyJHMKgqXWbn,infoLabels=pxBPeuESizswFlYNCdfyJHMKgqXWbI,isFolder=pxBPeuESizswFlYNCdfyJHMKgqXWjU,params=pxBPeuESizswFlYNCdfyJHMKgqXWbj)
  if pxBPeuESizswFlYNCdfyJHMKgqXWbA:
   pxBPeuESizswFlYNCdfyJHMKgqXWbj['mode'] ='NOW_GROUP' 
   pxBPeuESizswFlYNCdfyJHMKgqXWbj['page'] =pxBPeuESizswFlYNCdfyJHMKgqXWjD(pxBPeuESizswFlYNCdfyJHMKgqXWbm+1)
   pxBPeuESizswFlYNCdfyJHMKgqXWkT='[B]%s >>[/B]'%'다음 페이지'
   pxBPeuESizswFlYNCdfyJHMKgqXWbQ=pxBPeuESizswFlYNCdfyJHMKgqXWjD(pxBPeuESizswFlYNCdfyJHMKgqXWbm+1)
   pxBPeuESizswFlYNCdfyJHMKgqXWbr=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   pxBPeuESizswFlYNCdfyJHMKgqXWkj.add_dir(pxBPeuESizswFlYNCdfyJHMKgqXWkT,sublabel=pxBPeuESizswFlYNCdfyJHMKgqXWbQ,img=pxBPeuESizswFlYNCdfyJHMKgqXWbr,infoLabels=pxBPeuESizswFlYNCdfyJHMKgqXWjv,isFolder=pxBPeuESizswFlYNCdfyJHMKgqXWjI,params=pxBPeuESizswFlYNCdfyJHMKgqXWbj)
  if pxBPeuESizswFlYNCdfyJHMKgqXWjA(pxBPeuESizswFlYNCdfyJHMKgqXWba)>0:xbmcplugin.endOfDirectory(pxBPeuESizswFlYNCdfyJHMKgqXWkj._addon_handle,cacheToDisc=pxBPeuESizswFlYNCdfyJHMKgqXWjU)
 def dp_PopVod_GroupList(pxBPeuESizswFlYNCdfyJHMKgqXWkj,args):
  pxBPeuESizswFlYNCdfyJHMKgqXWkj.SpotvObj.SaveCredential(pxBPeuESizswFlYNCdfyJHMKgqXWkj.get_winCredential())
  pxBPeuESizswFlYNCdfyJHMKgqXWba=pxBPeuESizswFlYNCdfyJHMKgqXWkj.SpotvObj.GetPopularGroupList()
  for pxBPeuESizswFlYNCdfyJHMKgqXWbG in pxBPeuESizswFlYNCdfyJHMKgqXWba:
   pxBPeuESizswFlYNCdfyJHMKgqXWbD =pxBPeuESizswFlYNCdfyJHMKgqXWbG.get('vodTitle')
   pxBPeuESizswFlYNCdfyJHMKgqXWbh =pxBPeuESizswFlYNCdfyJHMKgqXWbG.get('vodId')
   pxBPeuESizswFlYNCdfyJHMKgqXWbL =pxBPeuESizswFlYNCdfyJHMKgqXWbG.get('vodType')
   pxBPeuESizswFlYNCdfyJHMKgqXWbn=pxBPeuESizswFlYNCdfyJHMKgqXWbG.get('thumbnail')
   pxBPeuESizswFlYNCdfyJHMKgqXWbT =pxBPeuESizswFlYNCdfyJHMKgqXWbG.get('vtypeId')
   pxBPeuESizswFlYNCdfyJHMKgqXWbo =pxBPeuESizswFlYNCdfyJHMKgqXWbG.get('duration')
   pxBPeuESizswFlYNCdfyJHMKgqXWbI={'mediatype':'video','duration':pxBPeuESizswFlYNCdfyJHMKgqXWbo,'plot':pxBPeuESizswFlYNCdfyJHMKgqXWbD}
   pxBPeuESizswFlYNCdfyJHMKgqXWbj={'mode':'POP_VOD','mediacode':pxBPeuESizswFlYNCdfyJHMKgqXWbh,'mediatype':'vod','vtypeId':pxBPeuESizswFlYNCdfyJHMKgqXWbT}
   pxBPeuESizswFlYNCdfyJHMKgqXWkj.add_dir(pxBPeuESizswFlYNCdfyJHMKgqXWbD,sublabel=pxBPeuESizswFlYNCdfyJHMKgqXWbL,img=pxBPeuESizswFlYNCdfyJHMKgqXWbn,infoLabels=pxBPeuESizswFlYNCdfyJHMKgqXWbI,isFolder=pxBPeuESizswFlYNCdfyJHMKgqXWjU,params=pxBPeuESizswFlYNCdfyJHMKgqXWbj)
  if pxBPeuESizswFlYNCdfyJHMKgqXWjA(pxBPeuESizswFlYNCdfyJHMKgqXWba)>0:xbmcplugin.endOfDirectory(pxBPeuESizswFlYNCdfyJHMKgqXWkj._addon_handle,cacheToDisc=pxBPeuESizswFlYNCdfyJHMKgqXWjU)
 def dp_Season_List(pxBPeuESizswFlYNCdfyJHMKgqXWkj,args):
  pxBPeuESizswFlYNCdfyJHMKgqXWkj.SpotvObj.SaveCredential(pxBPeuESizswFlYNCdfyJHMKgqXWkj.get_winCredential())
  pxBPeuESizswFlYNCdfyJHMKgqXWbv=args.get('reagueId')
  pxBPeuESizswFlYNCdfyJHMKgqXWba=pxBPeuESizswFlYNCdfyJHMKgqXWkj.SpotvObj.GetSeasonList(pxBPeuESizswFlYNCdfyJHMKgqXWbv)
  for pxBPeuESizswFlYNCdfyJHMKgqXWbG in pxBPeuESizswFlYNCdfyJHMKgqXWba:
   pxBPeuESizswFlYNCdfyJHMKgqXWbO =pxBPeuESizswFlYNCdfyJHMKgqXWbG.get('reagueName')
   pxBPeuESizswFlYNCdfyJHMKgqXWRk =pxBPeuESizswFlYNCdfyJHMKgqXWbG.get('gameTypeId')
   pxBPeuESizswFlYNCdfyJHMKgqXWRb =pxBPeuESizswFlYNCdfyJHMKgqXWbG.get('seasonName')
   pxBPeuESizswFlYNCdfyJHMKgqXWRr =pxBPeuESizswFlYNCdfyJHMKgqXWbG.get('seasonId')
   pxBPeuESizswFlYNCdfyJHMKgqXWbI={'mediatype':'episode','plot':'%s - %s'%(pxBPeuESizswFlYNCdfyJHMKgqXWbO,pxBPeuESizswFlYNCdfyJHMKgqXWRb)}
   pxBPeuESizswFlYNCdfyJHMKgqXWbj={'mode':'SEASON_GROUP','reagueId':pxBPeuESizswFlYNCdfyJHMKgqXWbv,'seasonId':pxBPeuESizswFlYNCdfyJHMKgqXWRr,'gameTypeId':pxBPeuESizswFlYNCdfyJHMKgqXWRk,'page':'1'}
   pxBPeuESizswFlYNCdfyJHMKgqXWkj.add_dir(pxBPeuESizswFlYNCdfyJHMKgqXWbO,sublabel=pxBPeuESizswFlYNCdfyJHMKgqXWRb,img='',infoLabels=pxBPeuESizswFlYNCdfyJHMKgqXWbI,isFolder=pxBPeuESizswFlYNCdfyJHMKgqXWjI,params=pxBPeuESizswFlYNCdfyJHMKgqXWbj)
  if pxBPeuESizswFlYNCdfyJHMKgqXWjA(pxBPeuESizswFlYNCdfyJHMKgqXWba)>0:xbmcplugin.endOfDirectory(pxBPeuESizswFlYNCdfyJHMKgqXWkj._addon_handle,cacheToDisc=pxBPeuESizswFlYNCdfyJHMKgqXWjI)
 def dp_Game_List(pxBPeuESizswFlYNCdfyJHMKgqXWkj,args):
  pxBPeuESizswFlYNCdfyJHMKgqXWkj.SpotvObj.SaveCredential(pxBPeuESizswFlYNCdfyJHMKgqXWkj.get_winCredential())
  pxBPeuESizswFlYNCdfyJHMKgqXWRk=args.get('gameTypeId')
  pxBPeuESizswFlYNCdfyJHMKgqXWbv =args.get('reagueId')
  pxBPeuESizswFlYNCdfyJHMKgqXWRr =args.get('seasonId')
  pxBPeuESizswFlYNCdfyJHMKgqXWbm =pxBPeuESizswFlYNCdfyJHMKgqXWjm(args.get('page'))
  pxBPeuESizswFlYNCdfyJHMKgqXWba,pxBPeuESizswFlYNCdfyJHMKgqXWbA=pxBPeuESizswFlYNCdfyJHMKgqXWkj.SpotvObj.GetGameList(pxBPeuESizswFlYNCdfyJHMKgqXWRk,pxBPeuESizswFlYNCdfyJHMKgqXWbv,pxBPeuESizswFlYNCdfyJHMKgqXWRr,pxBPeuESizswFlYNCdfyJHMKgqXWbm,hidescore=pxBPeuESizswFlYNCdfyJHMKgqXWkj.get_settings_hidescoreyn())
  for pxBPeuESizswFlYNCdfyJHMKgqXWbG in pxBPeuESizswFlYNCdfyJHMKgqXWba:
   pxBPeuESizswFlYNCdfyJHMKgqXWRj =pxBPeuESizswFlYNCdfyJHMKgqXWbG.get('gameTitle')
   pxBPeuESizswFlYNCdfyJHMKgqXWRc =pxBPeuESizswFlYNCdfyJHMKgqXWbG.get('beginDate')
   pxBPeuESizswFlYNCdfyJHMKgqXWbn =pxBPeuESizswFlYNCdfyJHMKgqXWbG.get('thumbnail')
   pxBPeuESizswFlYNCdfyJHMKgqXWRt =pxBPeuESizswFlYNCdfyJHMKgqXWbG.get('gameId')
   pxBPeuESizswFlYNCdfyJHMKgqXWRV =pxBPeuESizswFlYNCdfyJHMKgqXWbG.get('totVodCnt')
   pxBPeuESizswFlYNCdfyJHMKgqXWRa =pxBPeuESizswFlYNCdfyJHMKgqXWbG.get('leaguenm')
   pxBPeuESizswFlYNCdfyJHMKgqXWRG =pxBPeuESizswFlYNCdfyJHMKgqXWbG.get('seasonnm')
   pxBPeuESizswFlYNCdfyJHMKgqXWRn =pxBPeuESizswFlYNCdfyJHMKgqXWbG.get('roundnm')
   pxBPeuESizswFlYNCdfyJHMKgqXWRv =pxBPeuESizswFlYNCdfyJHMKgqXWbG.get('info_plot')
   pxBPeuESizswFlYNCdfyJHMKgqXWRU ='%s < %s >'%(pxBPeuESizswFlYNCdfyJHMKgqXWRj,pxBPeuESizswFlYNCdfyJHMKgqXWRc)
   pxBPeuESizswFlYNCdfyJHMKgqXWbI={'mediatype':'video','plot':pxBPeuESizswFlYNCdfyJHMKgqXWRv}
   pxBPeuESizswFlYNCdfyJHMKgqXWbj={'mode':'GAME_VOD_GROUP' if pxBPeuESizswFlYNCdfyJHMKgqXWRV!=0 else 'XXX','saveTitle':pxBPeuESizswFlYNCdfyJHMKgqXWRU,'saveImg':pxBPeuESizswFlYNCdfyJHMKgqXWbn,'saveInfo':pxBPeuESizswFlYNCdfyJHMKgqXWbI['plot'],'gameid':pxBPeuESizswFlYNCdfyJHMKgqXWRt}
   pxBPeuESizswFlYNCdfyJHMKgqXWkj.add_dir(pxBPeuESizswFlYNCdfyJHMKgqXWRj,sublabel=pxBPeuESizswFlYNCdfyJHMKgqXWRc,img=pxBPeuESizswFlYNCdfyJHMKgqXWbn,infoLabels=pxBPeuESizswFlYNCdfyJHMKgqXWbI,isFolder=pxBPeuESizswFlYNCdfyJHMKgqXWjI,params=pxBPeuESizswFlYNCdfyJHMKgqXWbj)
  if pxBPeuESizswFlYNCdfyJHMKgqXWbA:
   pxBPeuESizswFlYNCdfyJHMKgqXWbj['mode'] ='SEASON_GROUP' 
   pxBPeuESizswFlYNCdfyJHMKgqXWbj['reagueId'] =pxBPeuESizswFlYNCdfyJHMKgqXWbv
   pxBPeuESizswFlYNCdfyJHMKgqXWbj['seasonId'] =pxBPeuESizswFlYNCdfyJHMKgqXWRr
   pxBPeuESizswFlYNCdfyJHMKgqXWbj['gameTypeId']=pxBPeuESizswFlYNCdfyJHMKgqXWRk
   pxBPeuESizswFlYNCdfyJHMKgqXWbj['page'] =pxBPeuESizswFlYNCdfyJHMKgqXWjD(pxBPeuESizswFlYNCdfyJHMKgqXWbm+1)
   pxBPeuESizswFlYNCdfyJHMKgqXWkT='[B]%s >>[/B]'%'다음 페이지'
   pxBPeuESizswFlYNCdfyJHMKgqXWbQ=pxBPeuESizswFlYNCdfyJHMKgqXWjD(pxBPeuESizswFlYNCdfyJHMKgqXWbm+1)
   pxBPeuESizswFlYNCdfyJHMKgqXWbr=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   pxBPeuESizswFlYNCdfyJHMKgqXWkj.add_dir(pxBPeuESizswFlYNCdfyJHMKgqXWkT,sublabel=pxBPeuESizswFlYNCdfyJHMKgqXWbQ,img=pxBPeuESizswFlYNCdfyJHMKgqXWbr,infoLabels=pxBPeuESizswFlYNCdfyJHMKgqXWjv,isFolder=pxBPeuESizswFlYNCdfyJHMKgqXWjI,params=pxBPeuESizswFlYNCdfyJHMKgqXWbj)
  if pxBPeuESizswFlYNCdfyJHMKgqXWjA(pxBPeuESizswFlYNCdfyJHMKgqXWba)>0:xbmcplugin.endOfDirectory(pxBPeuESizswFlYNCdfyJHMKgqXWkj._addon_handle,cacheToDisc=pxBPeuESizswFlYNCdfyJHMKgqXWjU)
 def dp_GameVod_List(pxBPeuESizswFlYNCdfyJHMKgqXWkj,args):
  pxBPeuESizswFlYNCdfyJHMKgqXWkj.SpotvObj.SaveCredential(pxBPeuESizswFlYNCdfyJHMKgqXWkj.get_winCredential())
  pxBPeuESizswFlYNCdfyJHMKgqXWRI =args.get('gameid')
  pxBPeuESizswFlYNCdfyJHMKgqXWRU=args.get('saveTitle')
  pxBPeuESizswFlYNCdfyJHMKgqXWRm =args.get('saveImg')
  pxBPeuESizswFlYNCdfyJHMKgqXWRA =args.get('saveInfo')
  pxBPeuESizswFlYNCdfyJHMKgqXWba=pxBPeuESizswFlYNCdfyJHMKgqXWkj.SpotvObj.GetGameVodList(pxBPeuESizswFlYNCdfyJHMKgqXWRI)
  for pxBPeuESizswFlYNCdfyJHMKgqXWbG in pxBPeuESizswFlYNCdfyJHMKgqXWba:
   pxBPeuESizswFlYNCdfyJHMKgqXWbD =pxBPeuESizswFlYNCdfyJHMKgqXWbG.get('vodTitle')
   pxBPeuESizswFlYNCdfyJHMKgqXWbh =pxBPeuESizswFlYNCdfyJHMKgqXWbG.get('vodId')
   pxBPeuESizswFlYNCdfyJHMKgqXWbL =pxBPeuESizswFlYNCdfyJHMKgqXWbG.get('vodType')
   pxBPeuESizswFlYNCdfyJHMKgqXWbn=pxBPeuESizswFlYNCdfyJHMKgqXWbG.get('thumbnail')
   pxBPeuESizswFlYNCdfyJHMKgqXWbT =pxBPeuESizswFlYNCdfyJHMKgqXWbG.get('vtypeId')
   pxBPeuESizswFlYNCdfyJHMKgqXWbo =pxBPeuESizswFlYNCdfyJHMKgqXWbG.get('duration')
   pxBPeuESizswFlYNCdfyJHMKgqXWbI={'mediatype':'video','duration':pxBPeuESizswFlYNCdfyJHMKgqXWbo,'plot':'%s \n\n %s'%(pxBPeuESizswFlYNCdfyJHMKgqXWbD,pxBPeuESizswFlYNCdfyJHMKgqXWRA)}
   pxBPeuESizswFlYNCdfyJHMKgqXWbj={'mode':'GAME_VOD','saveTitle':pxBPeuESizswFlYNCdfyJHMKgqXWRU,'saveImg':pxBPeuESizswFlYNCdfyJHMKgqXWRm,'saveId':pxBPeuESizswFlYNCdfyJHMKgqXWRI,'saveInfo':pxBPeuESizswFlYNCdfyJHMKgqXWRA,'mediacode':pxBPeuESizswFlYNCdfyJHMKgqXWbh,'mediatype':'vod','vtypeId':pxBPeuESizswFlYNCdfyJHMKgqXWbT}
   pxBPeuESizswFlYNCdfyJHMKgqXWkj.add_dir(pxBPeuESizswFlYNCdfyJHMKgqXWbD,sublabel=pxBPeuESizswFlYNCdfyJHMKgqXWbL,img=pxBPeuESizswFlYNCdfyJHMKgqXWbn,infoLabels=pxBPeuESizswFlYNCdfyJHMKgqXWbI,isFolder=pxBPeuESizswFlYNCdfyJHMKgqXWjU,params=pxBPeuESizswFlYNCdfyJHMKgqXWbj)
  if pxBPeuESizswFlYNCdfyJHMKgqXWjA(pxBPeuESizswFlYNCdfyJHMKgqXWba)>0:xbmcplugin.endOfDirectory(pxBPeuESizswFlYNCdfyJHMKgqXWkj._addon_handle,cacheToDisc=pxBPeuESizswFlYNCdfyJHMKgqXWjU)
 def login_main(pxBPeuESizswFlYNCdfyJHMKgqXWkj):
  (pxBPeuESizswFlYNCdfyJHMKgqXWRD,pxBPeuESizswFlYNCdfyJHMKgqXWRh)=pxBPeuESizswFlYNCdfyJHMKgqXWkj.get_settings_login_info()
  if not(pxBPeuESizswFlYNCdfyJHMKgqXWRD and pxBPeuESizswFlYNCdfyJHMKgqXWRh):
   pxBPeuESizswFlYNCdfyJHMKgqXWkG=xbmcgui.Dialog()
   pxBPeuESizswFlYNCdfyJHMKgqXWRL=pxBPeuESizswFlYNCdfyJHMKgqXWkG.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if pxBPeuESizswFlYNCdfyJHMKgqXWRL==pxBPeuESizswFlYNCdfyJHMKgqXWjI:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if pxBPeuESizswFlYNCdfyJHMKgqXWkj.cookiefile_check():return
  pxBPeuESizswFlYNCdfyJHMKgqXWRT =pxBPeuESizswFlYNCdfyJHMKgqXWjm(pxBPeuESizswFlYNCdfyJHMKgqXWkj.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))
  pxBPeuESizswFlYNCdfyJHMKgqXWRo=xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINTIME')
  if pxBPeuESizswFlYNCdfyJHMKgqXWRo==pxBPeuESizswFlYNCdfyJHMKgqXWjv or pxBPeuESizswFlYNCdfyJHMKgqXWRo=='':
   pxBPeuESizswFlYNCdfyJHMKgqXWRo=pxBPeuESizswFlYNCdfyJHMKgqXWjm('19000101')
  else:
   pxBPeuESizswFlYNCdfyJHMKgqXWRo=pxBPeuESizswFlYNCdfyJHMKgqXWjm(re.sub('-','',pxBPeuESizswFlYNCdfyJHMKgqXWRo))
  if xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINWAIT')=='TRUE':
   pxBPeuESizswFlYNCdfyJHMKgqXWRQ=0
   while pxBPeuESizswFlYNCdfyJHMKgqXWjI:
    pxBPeuESizswFlYNCdfyJHMKgqXWRQ+=1
    time.sleep(0.05)
    if pxBPeuESizswFlYNCdfyJHMKgqXWRo>=pxBPeuESizswFlYNCdfyJHMKgqXWRT:return
    if pxBPeuESizswFlYNCdfyJHMKgqXWRQ>600:return
  else:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','TRUE')
  if pxBPeuESizswFlYNCdfyJHMKgqXWRo>=pxBPeuESizswFlYNCdfyJHMKgqXWRT:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
   return
  if not pxBPeuESizswFlYNCdfyJHMKgqXWkj.SpotvObj.GetCredential(pxBPeuESizswFlYNCdfyJHMKgqXWRD,pxBPeuESizswFlYNCdfyJHMKgqXWRh):
   pxBPeuESizswFlYNCdfyJHMKgqXWkj.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
   sys.exit()
  pxBPeuESizswFlYNCdfyJHMKgqXWkj.set_winCredential(pxBPeuESizswFlYNCdfyJHMKgqXWkj.SpotvObj.LoadCredential())
  pxBPeuESizswFlYNCdfyJHMKgqXWkj.cookiefile_save()
  xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
 def dp_LiveChannel_List(pxBPeuESizswFlYNCdfyJHMKgqXWkj,args):
  pxBPeuESizswFlYNCdfyJHMKgqXWkj.SpotvObj.SaveCredential(pxBPeuESizswFlYNCdfyJHMKgqXWkj.get_winCredential())
  pxBPeuESizswFlYNCdfyJHMKgqXWRO=pxBPeuESizswFlYNCdfyJHMKgqXWkj.SpotvObj.GetLiveChannelList()
  for pxBPeuESizswFlYNCdfyJHMKgqXWrk in pxBPeuESizswFlYNCdfyJHMKgqXWRO:
   pxBPeuESizswFlYNCdfyJHMKgqXWkT =pxBPeuESizswFlYNCdfyJHMKgqXWrk.get('name')
   pxBPeuESizswFlYNCdfyJHMKgqXWbn =pxBPeuESizswFlYNCdfyJHMKgqXWrk.get('logo')
   pxBPeuESizswFlYNCdfyJHMKgqXWrb=pxBPeuESizswFlYNCdfyJHMKgqXWrk.get('channelepg')
   pxBPeuESizswFlYNCdfyJHMKgqXWrR =pxBPeuESizswFlYNCdfyJHMKgqXWrk.get('free')
   if pxBPeuESizswFlYNCdfyJHMKgqXWrb:
    pxBPeuESizswFlYNCdfyJHMKgqXWrj =pxBPeuESizswFlYNCdfyJHMKgqXWrb['epg']
    pxBPeuESizswFlYNCdfyJHMKgqXWrc=pxBPeuESizswFlYNCdfyJHMKgqXWrb['title']
   else:
    pxBPeuESizswFlYNCdfyJHMKgqXWrj =''
    pxBPeuESizswFlYNCdfyJHMKgqXWrc=''
   pxBPeuESizswFlYNCdfyJHMKgqXWbI={'plot':'%s\n\n%s'%(pxBPeuESizswFlYNCdfyJHMKgqXWkT,pxBPeuESizswFlYNCdfyJHMKgqXWrj),'mediatype':'video'}
   pxBPeuESizswFlYNCdfyJHMKgqXWbj={'mode':'LIVE','mediacode':pxBPeuESizswFlYNCdfyJHMKgqXWrk.get('videoId'),'free':pxBPeuESizswFlYNCdfyJHMKgqXWrR,'mediatype':'live'}
   if pxBPeuESizswFlYNCdfyJHMKgqXWrR:pxBPeuESizswFlYNCdfyJHMKgqXWkT+=' [free]'
   pxBPeuESizswFlYNCdfyJHMKgqXWkj.add_dir(pxBPeuESizswFlYNCdfyJHMKgqXWkT,sublabel=pxBPeuESizswFlYNCdfyJHMKgqXWrc,img=pxBPeuESizswFlYNCdfyJHMKgqXWbn,infoLabels=pxBPeuESizswFlYNCdfyJHMKgqXWbI,isFolder=pxBPeuESizswFlYNCdfyJHMKgqXWjU,params=pxBPeuESizswFlYNCdfyJHMKgqXWbj)
  if pxBPeuESizswFlYNCdfyJHMKgqXWjA(pxBPeuESizswFlYNCdfyJHMKgqXWRO)>0:xbmcplugin.endOfDirectory(pxBPeuESizswFlYNCdfyJHMKgqXWkj._addon_handle,cacheToDisc=pxBPeuESizswFlYNCdfyJHMKgqXWjU)
 def dp_EventLiveChannel_List(pxBPeuESizswFlYNCdfyJHMKgqXWkj,args):
  pxBPeuESizswFlYNCdfyJHMKgqXWkj.SpotvObj.SaveCredential(pxBPeuESizswFlYNCdfyJHMKgqXWkj.get_winCredential())
  pxBPeuESizswFlYNCdfyJHMKgqXWRO,pxBPeuESizswFlYNCdfyJHMKgqXWrt=pxBPeuESizswFlYNCdfyJHMKgqXWkj.SpotvObj.GetEventLiveList()
  if pxBPeuESizswFlYNCdfyJHMKgqXWrt!=401 and pxBPeuESizswFlYNCdfyJHMKgqXWjA(pxBPeuESizswFlYNCdfyJHMKgqXWRO)==0:
   pxBPeuESizswFlYNCdfyJHMKgqXWkj.addon_noti(__language__(30907).encode('utf8'))
  for pxBPeuESizswFlYNCdfyJHMKgqXWrk in pxBPeuESizswFlYNCdfyJHMKgqXWRO:
   pxBPeuESizswFlYNCdfyJHMKgqXWkT =pxBPeuESizswFlYNCdfyJHMKgqXWrk.get('title')
   pxBPeuESizswFlYNCdfyJHMKgqXWbV =pxBPeuESizswFlYNCdfyJHMKgqXWrk.get('startTime')
   pxBPeuESizswFlYNCdfyJHMKgqXWbn =pxBPeuESizswFlYNCdfyJHMKgqXWrk.get('logo')
   pxBPeuESizswFlYNCdfyJHMKgqXWrR =pxBPeuESizswFlYNCdfyJHMKgqXWrk.get('free')
   pxBPeuESizswFlYNCdfyJHMKgqXWbI={'mediatype':'video','plot':'%s\n\n%s'%(pxBPeuESizswFlYNCdfyJHMKgqXWkT,pxBPeuESizswFlYNCdfyJHMKgqXWbV)}
   pxBPeuESizswFlYNCdfyJHMKgqXWbj={'mode':'ELIVE','mediacode':pxBPeuESizswFlYNCdfyJHMKgqXWrk.get('liveId'),'free':pxBPeuESizswFlYNCdfyJHMKgqXWrR,'mediatype':'live'}
   if pxBPeuESizswFlYNCdfyJHMKgqXWrR:pxBPeuESizswFlYNCdfyJHMKgqXWkT+=' [free]'
   pxBPeuESizswFlYNCdfyJHMKgqXWkj.add_dir(pxBPeuESizswFlYNCdfyJHMKgqXWkT,sublabel=pxBPeuESizswFlYNCdfyJHMKgqXWbV,img=pxBPeuESizswFlYNCdfyJHMKgqXWbn,infoLabels=pxBPeuESizswFlYNCdfyJHMKgqXWbI,isFolder=pxBPeuESizswFlYNCdfyJHMKgqXWjU,params=pxBPeuESizswFlYNCdfyJHMKgqXWbj)
  if pxBPeuESizswFlYNCdfyJHMKgqXWjA(pxBPeuESizswFlYNCdfyJHMKgqXWRO)>0:xbmcplugin.endOfDirectory(pxBPeuESizswFlYNCdfyJHMKgqXWkj._addon_handle,cacheToDisc=pxBPeuESizswFlYNCdfyJHMKgqXWjI)
  return pxBPeuESizswFlYNCdfyJHMKgqXWrt
 def play_VIDEO(pxBPeuESizswFlYNCdfyJHMKgqXWkj,args):
  pxBPeuESizswFlYNCdfyJHMKgqXWkj.SpotvObj.SaveCredential(pxBPeuESizswFlYNCdfyJHMKgqXWkj.get_winCredential())
  pxBPeuESizswFlYNCdfyJHMKgqXWrV =args.get('mode')
  pxBPeuESizswFlYNCdfyJHMKgqXWra =args.get('mediacode')
  pxBPeuESizswFlYNCdfyJHMKgqXWrG =args.get('mediatype')
  pxBPeuESizswFlYNCdfyJHMKgqXWbT =args.get('vtypeId')
  if pxBPeuESizswFlYNCdfyJHMKgqXWrV=='LIVE':
   if args.get('free')=='False':
    if pxBPeuESizswFlYNCdfyJHMKgqXWkj.SpotvObj.CheckSubEnd()==pxBPeuESizswFlYNCdfyJHMKgqXWjU:
     pxBPeuESizswFlYNCdfyJHMKgqXWkj.addon_noti(__language__(30908).encode('utf8'))
     return
  elif pxBPeuESizswFlYNCdfyJHMKgqXWrV=='ELIVE':
   if args.get('free')=='False':
    if pxBPeuESizswFlYNCdfyJHMKgqXWkj.SpotvObj.CheckSubEnd()==pxBPeuESizswFlYNCdfyJHMKgqXWjU:
     pxBPeuESizswFlYNCdfyJHMKgqXWkj.addon_noti(__language__(30908).encode('utf8'))
     return
  if pxBPeuESizswFlYNCdfyJHMKgqXWra=='' or pxBPeuESizswFlYNCdfyJHMKgqXWra==pxBPeuESizswFlYNCdfyJHMKgqXWjv:
   pxBPeuESizswFlYNCdfyJHMKgqXWkj.addon_noti(__language__(30907).encode('utf8'))
   return
  if pxBPeuESizswFlYNCdfyJHMKgqXWrV=='LIVE':
   pxBPeuESizswFlYNCdfyJHMKgqXWrn=pxBPeuESizswFlYNCdfyJHMKgqXWkj.SpotvObj.Get_Streamurl_Make(args.get('mediacode'))
  else:
   pxBPeuESizswFlYNCdfyJHMKgqXWrn=pxBPeuESizswFlYNCdfyJHMKgqXWkj.SpotvObj.GetBroadURL(pxBPeuESizswFlYNCdfyJHMKgqXWra,pxBPeuESizswFlYNCdfyJHMKgqXWrG,pxBPeuESizswFlYNCdfyJHMKgqXWbT)
  if pxBPeuESizswFlYNCdfyJHMKgqXWrn=='':
   pxBPeuESizswFlYNCdfyJHMKgqXWkj.addon_noti(__language__(30908).encode('utf8'))
   return
  pxBPeuESizswFlYNCdfyJHMKgqXWrv=pxBPeuESizswFlYNCdfyJHMKgqXWrn
  try:
   pxBPeuESizswFlYNCdfyJHMKgqXWkj.addon_log('mainMode  = '+pxBPeuESizswFlYNCdfyJHMKgqXWrV)
  except:
   pxBPeuESizswFlYNCdfyJHMKgqXWjv
  pxBPeuESizswFlYNCdfyJHMKgqXWkj.addon_log(pxBPeuESizswFlYNCdfyJHMKgqXWrv)
  pxBPeuESizswFlYNCdfyJHMKgqXWrU=xbmcgui.ListItem(path=pxBPeuESizswFlYNCdfyJHMKgqXWrv)
  xbmcplugin.setResolvedUrl(pxBPeuESizswFlYNCdfyJHMKgqXWkj._addon_handle,pxBPeuESizswFlYNCdfyJHMKgqXWjI,pxBPeuESizswFlYNCdfyJHMKgqXWrU)
  try:
   if pxBPeuESizswFlYNCdfyJHMKgqXWrG=='vod' and pxBPeuESizswFlYNCdfyJHMKgqXWrV not in['POP_VOD','NOW_VOD']:
    pxBPeuESizswFlYNCdfyJHMKgqXWbj={'code':args.get('saveId'),'img':args.get('saveImg'),'title':args.get('saveTitle'),'info':args.get('saveInfo')}
    pxBPeuESizswFlYNCdfyJHMKgqXWkj.Save_Watched_List(pxBPeuESizswFlYNCdfyJHMKgqXWrG,pxBPeuESizswFlYNCdfyJHMKgqXWbj)
  except:
   pxBPeuESizswFlYNCdfyJHMKgqXWjv
 def logout(pxBPeuESizswFlYNCdfyJHMKgqXWkj):
  pxBPeuESizswFlYNCdfyJHMKgqXWkG=xbmcgui.Dialog()
  pxBPeuESizswFlYNCdfyJHMKgqXWRL=pxBPeuESizswFlYNCdfyJHMKgqXWkG.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if pxBPeuESizswFlYNCdfyJHMKgqXWRL==pxBPeuESizswFlYNCdfyJHMKgqXWjU:sys.exit()
  pxBPeuESizswFlYNCdfyJHMKgqXWkj.wininfo_clear()
  if os.path.isfile(pxBPeuESizswFlYNCdfyJHMKgqXWkr):os.remove(pxBPeuESizswFlYNCdfyJHMKgqXWkr)
  pxBPeuESizswFlYNCdfyJHMKgqXWkj.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(pxBPeuESizswFlYNCdfyJHMKgqXWkj):
  pxBPeuESizswFlYNCdfyJHMKgqXWkD=xbmcgui.Window(10000)
  pxBPeuESizswFlYNCdfyJHMKgqXWkD.setProperty('SPOTV_M_SESSIONID','')
  pxBPeuESizswFlYNCdfyJHMKgqXWkD.setProperty('SPOTV_M_SESSION','')
  pxBPeuESizswFlYNCdfyJHMKgqXWkD.setProperty('SPOTV_M_ACCOUNTID','')
  pxBPeuESizswFlYNCdfyJHMKgqXWkD.setProperty('SPOTV_M_POLICYKEY','')
  pxBPeuESizswFlYNCdfyJHMKgqXWkD.setProperty('SPOTV_M_SUBEND','')
  pxBPeuESizswFlYNCdfyJHMKgqXWkD.setProperty('SPOTV_M_LOGINTIME','')
 def cookiefile_save(pxBPeuESizswFlYNCdfyJHMKgqXWkj):
  pxBPeuESizswFlYNCdfyJHMKgqXWrI =pxBPeuESizswFlYNCdfyJHMKgqXWkj.SpotvObj.Get_Now_Datetime()
  pxBPeuESizswFlYNCdfyJHMKgqXWrm=pxBPeuESizswFlYNCdfyJHMKgqXWrI+datetime.timedelta(days=pxBPeuESizswFlYNCdfyJHMKgqXWjm(__addon__.getSetting('cache_ttl')))
  pxBPeuESizswFlYNCdfyJHMKgqXWkD=xbmcgui.Window(10000)
  pxBPeuESizswFlYNCdfyJHMKgqXWrA={'spotv_sessionid':pxBPeuESizswFlYNCdfyJHMKgqXWkD.getProperty('SPOTV_M_SESSIONID'),'spotv_session':pxBPeuESizswFlYNCdfyJHMKgqXWkD.getProperty('SPOTV_M_SESSION'),'spotv_accountId':pxBPeuESizswFlYNCdfyJHMKgqXWkD.getProperty('SPOTV_M_ACCOUNTID'),'spotv_policyKey':base64.standard_b64encode(pxBPeuESizswFlYNCdfyJHMKgqXWkD.getProperty('SPOTV_M_POLICYKEY').encode()).decode('utf-8'),'spotv_subend':base64.standard_b64encode((pxBPeuESizswFlYNCdfyJHMKgqXWkj.SpotvObj.SPOTV_PMCODE+pxBPeuESizswFlYNCdfyJHMKgqXWkD.getProperty('SPOTV_M_SUBEND')).encode()).decode('utf-8'),'spotv_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'spotv_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'spotv_limitdate':pxBPeuESizswFlYNCdfyJHMKgqXWrm.strftime('%Y-%m-%d')}
  try: 
   fp=pxBPeuESizswFlYNCdfyJHMKgqXWjh(pxBPeuESizswFlYNCdfyJHMKgqXWkr,'w',-1,'utf-8')
   json.dump(pxBPeuESizswFlYNCdfyJHMKgqXWrA,fp)
   fp.close()
  except pxBPeuESizswFlYNCdfyJHMKgqXWjL as exception:
   pxBPeuESizswFlYNCdfyJHMKgqXWjT(exception)
 def cookiefile_check(pxBPeuESizswFlYNCdfyJHMKgqXWkj):
  pxBPeuESizswFlYNCdfyJHMKgqXWrA={}
  try: 
   fp=pxBPeuESizswFlYNCdfyJHMKgqXWjh(pxBPeuESizswFlYNCdfyJHMKgqXWkr,'r',-1,'utf-8')
   pxBPeuESizswFlYNCdfyJHMKgqXWrA= json.load(fp)
   fp.close()
  except pxBPeuESizswFlYNCdfyJHMKgqXWjL as exception:
   pxBPeuESizswFlYNCdfyJHMKgqXWkj.wininfo_clear()
   return pxBPeuESizswFlYNCdfyJHMKgqXWjU
  pxBPeuESizswFlYNCdfyJHMKgqXWRD =__addon__.getSetting('id')
  pxBPeuESizswFlYNCdfyJHMKgqXWRh =__addon__.getSetting('pw')
  pxBPeuESizswFlYNCdfyJHMKgqXWrA['spotv_id'] =base64.standard_b64decode(pxBPeuESizswFlYNCdfyJHMKgqXWrA['spotv_id']).decode('utf-8')
  pxBPeuESizswFlYNCdfyJHMKgqXWrA['spotv_pw'] =base64.standard_b64decode(pxBPeuESizswFlYNCdfyJHMKgqXWrA['spotv_pw']).decode('utf-8')
  pxBPeuESizswFlYNCdfyJHMKgqXWrA['spotv_policyKey']=base64.standard_b64decode(pxBPeuESizswFlYNCdfyJHMKgqXWrA['spotv_policyKey']).decode('utf-8')
  pxBPeuESizswFlYNCdfyJHMKgqXWrA['spotv_subend']=base64.standard_b64decode(pxBPeuESizswFlYNCdfyJHMKgqXWrA['spotv_subend']).decode('utf-8')[pxBPeuESizswFlYNCdfyJHMKgqXWkj.SpotvObj.SPOTV_PMSIZE:]
  if pxBPeuESizswFlYNCdfyJHMKgqXWRD!=pxBPeuESizswFlYNCdfyJHMKgqXWrA['spotv_id']or pxBPeuESizswFlYNCdfyJHMKgqXWRh!=pxBPeuESizswFlYNCdfyJHMKgqXWrA['spotv_pw']:
   pxBPeuESizswFlYNCdfyJHMKgqXWkj.wininfo_clear()
   return pxBPeuESizswFlYNCdfyJHMKgqXWjU
  pxBPeuESizswFlYNCdfyJHMKgqXWRT =pxBPeuESizswFlYNCdfyJHMKgqXWjm(pxBPeuESizswFlYNCdfyJHMKgqXWkj.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))
  pxBPeuESizswFlYNCdfyJHMKgqXWrD=pxBPeuESizswFlYNCdfyJHMKgqXWrA['spotv_limitdate']
  pxBPeuESizswFlYNCdfyJHMKgqXWRo =pxBPeuESizswFlYNCdfyJHMKgqXWjm(re.sub('-','',pxBPeuESizswFlYNCdfyJHMKgqXWrD))
  if pxBPeuESizswFlYNCdfyJHMKgqXWRo<pxBPeuESizswFlYNCdfyJHMKgqXWRT:
   pxBPeuESizswFlYNCdfyJHMKgqXWkj.wininfo_clear()
   return pxBPeuESizswFlYNCdfyJHMKgqXWjU
  pxBPeuESizswFlYNCdfyJHMKgqXWkD=xbmcgui.Window(10000)
  pxBPeuESizswFlYNCdfyJHMKgqXWkD.setProperty('SPOTV_M_SESSIONID',pxBPeuESizswFlYNCdfyJHMKgqXWrA['spotv_sessionid'])
  pxBPeuESizswFlYNCdfyJHMKgqXWkD.setProperty('SPOTV_M_SESSION',pxBPeuESizswFlYNCdfyJHMKgqXWrA['spotv_session'])
  pxBPeuESizswFlYNCdfyJHMKgqXWkD.setProperty('SPOTV_M_ACCOUNTID',pxBPeuESizswFlYNCdfyJHMKgqXWrA['spotv_accountId'])
  pxBPeuESizswFlYNCdfyJHMKgqXWkD.setProperty('SPOTV_M_POLICYKEY',pxBPeuESizswFlYNCdfyJHMKgqXWrA['spotv_policyKey'])
  pxBPeuESizswFlYNCdfyJHMKgqXWkD.setProperty('SPOTV_M_SUBEND',pxBPeuESizswFlYNCdfyJHMKgqXWrA['spotv_subend'])
  pxBPeuESizswFlYNCdfyJHMKgqXWkD.setProperty('SPOTV_M_LOGINTIME',pxBPeuESizswFlYNCdfyJHMKgqXWrD)
  return pxBPeuESizswFlYNCdfyJHMKgqXWjI
 def dp_WatchList_Delete(pxBPeuESizswFlYNCdfyJHMKgqXWkj,args):
  pxBPeuESizswFlYNCdfyJHMKgqXWrG=args.get('mediatype')
  pxBPeuESizswFlYNCdfyJHMKgqXWkG=xbmcgui.Dialog()
  pxBPeuESizswFlYNCdfyJHMKgqXWRL=pxBPeuESizswFlYNCdfyJHMKgqXWkG.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if pxBPeuESizswFlYNCdfyJHMKgqXWRL==pxBPeuESizswFlYNCdfyJHMKgqXWjU:sys.exit()
  pxBPeuESizswFlYNCdfyJHMKgqXWkj.Delete_Watched_List(pxBPeuESizswFlYNCdfyJHMKgqXWrG)
  xbmc.executebuiltin("Container.Refresh")
 def Delete_Watched_List(pxBPeuESizswFlYNCdfyJHMKgqXWkj,pxBPeuESizswFlYNCdfyJHMKgqXWrG):
  try:
   pxBPeuESizswFlYNCdfyJHMKgqXWrh=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%pxBPeuESizswFlYNCdfyJHMKgqXWrG))
   fp=pxBPeuESizswFlYNCdfyJHMKgqXWjh(pxBPeuESizswFlYNCdfyJHMKgqXWrh,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   pxBPeuESizswFlYNCdfyJHMKgqXWjv
 def Load_Watched_List(pxBPeuESizswFlYNCdfyJHMKgqXWkj,pxBPeuESizswFlYNCdfyJHMKgqXWrG):
  try:
   pxBPeuESizswFlYNCdfyJHMKgqXWrh=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%pxBPeuESizswFlYNCdfyJHMKgqXWrG))
   fp=pxBPeuESizswFlYNCdfyJHMKgqXWjh(pxBPeuESizswFlYNCdfyJHMKgqXWrh,'r',-1,'utf-8')
   pxBPeuESizswFlYNCdfyJHMKgqXWrL=fp.readlines()
   fp.close()
  except:
   pxBPeuESizswFlYNCdfyJHMKgqXWrL=[]
  return pxBPeuESizswFlYNCdfyJHMKgqXWrL
 def Save_Watched_List(pxBPeuESizswFlYNCdfyJHMKgqXWkj,stype,pxBPeuESizswFlYNCdfyJHMKgqXWkV):
  try:
   pxBPeuESizswFlYNCdfyJHMKgqXWrh=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   pxBPeuESizswFlYNCdfyJHMKgqXWrT=pxBPeuESizswFlYNCdfyJHMKgqXWkj.Load_Watched_List(stype) 
   fp=pxBPeuESizswFlYNCdfyJHMKgqXWjh(pxBPeuESizswFlYNCdfyJHMKgqXWrh,'w',-1,'utf-8')
   pxBPeuESizswFlYNCdfyJHMKgqXWro=urllib.parse.urlencode(pxBPeuESizswFlYNCdfyJHMKgqXWkV)
   pxBPeuESizswFlYNCdfyJHMKgqXWro=pxBPeuESizswFlYNCdfyJHMKgqXWro+'\n'
   fp.write(pxBPeuESizswFlYNCdfyJHMKgqXWro)
   pxBPeuESizswFlYNCdfyJHMKgqXWrQ=0
   for pxBPeuESizswFlYNCdfyJHMKgqXWrO in pxBPeuESizswFlYNCdfyJHMKgqXWrT:
    pxBPeuESizswFlYNCdfyJHMKgqXWjk=pxBPeuESizswFlYNCdfyJHMKgqXWjo(urllib.parse.parse_qsl(pxBPeuESizswFlYNCdfyJHMKgqXWrO))
    pxBPeuESizswFlYNCdfyJHMKgqXWjb=pxBPeuESizswFlYNCdfyJHMKgqXWkV.get('code')
    pxBPeuESizswFlYNCdfyJHMKgqXWjR=pxBPeuESizswFlYNCdfyJHMKgqXWjk.get('code')
    if pxBPeuESizswFlYNCdfyJHMKgqXWjb!=pxBPeuESizswFlYNCdfyJHMKgqXWjR:
     fp.write(pxBPeuESizswFlYNCdfyJHMKgqXWrO)
     pxBPeuESizswFlYNCdfyJHMKgqXWrQ+=1
     if pxBPeuESizswFlYNCdfyJHMKgqXWrQ>=50:break
   fp.close()
  except:
   pxBPeuESizswFlYNCdfyJHMKgqXWjv
 def dp_Watch_List(pxBPeuESizswFlYNCdfyJHMKgqXWkj,args):
  pxBPeuESizswFlYNCdfyJHMKgqXWrG ='vod'
  if pxBPeuESizswFlYNCdfyJHMKgqXWrG=='vod':
   pxBPeuESizswFlYNCdfyJHMKgqXWjr=pxBPeuESizswFlYNCdfyJHMKgqXWkj.Load_Watched_List(pxBPeuESizswFlYNCdfyJHMKgqXWrG)
   for pxBPeuESizswFlYNCdfyJHMKgqXWjc in pxBPeuESizswFlYNCdfyJHMKgqXWjr:
    pxBPeuESizswFlYNCdfyJHMKgqXWjt=pxBPeuESizswFlYNCdfyJHMKgqXWjo(urllib.parse.parse_qsl(pxBPeuESizswFlYNCdfyJHMKgqXWjc))
    pxBPeuESizswFlYNCdfyJHMKgqXWkT =pxBPeuESizswFlYNCdfyJHMKgqXWjt.get('title')
    pxBPeuESizswFlYNCdfyJHMKgqXWbn=pxBPeuESizswFlYNCdfyJHMKgqXWjt.get('img')
    pxBPeuESizswFlYNCdfyJHMKgqXWra=pxBPeuESizswFlYNCdfyJHMKgqXWjt.get('code')
    pxBPeuESizswFlYNCdfyJHMKgqXWjV =pxBPeuESizswFlYNCdfyJHMKgqXWjt.get('info')
    pxBPeuESizswFlYNCdfyJHMKgqXWbI={}
    pxBPeuESizswFlYNCdfyJHMKgqXWbI['plot']=pxBPeuESizswFlYNCdfyJHMKgqXWjV
    pxBPeuESizswFlYNCdfyJHMKgqXWbj={'mode':'GAME_VOD_GROUP','gameid':pxBPeuESizswFlYNCdfyJHMKgqXWra,'saveTitle':pxBPeuESizswFlYNCdfyJHMKgqXWkT,'saveImg':pxBPeuESizswFlYNCdfyJHMKgqXWbn,'saveInfo':pxBPeuESizswFlYNCdfyJHMKgqXWjV,'mediatype':pxBPeuESizswFlYNCdfyJHMKgqXWrG}
    pxBPeuESizswFlYNCdfyJHMKgqXWkj.add_dir(pxBPeuESizswFlYNCdfyJHMKgqXWkT,sublabel='',img=pxBPeuESizswFlYNCdfyJHMKgqXWbn,infoLabels=pxBPeuESizswFlYNCdfyJHMKgqXWbI,isFolder=pxBPeuESizswFlYNCdfyJHMKgqXWjI,params=pxBPeuESizswFlYNCdfyJHMKgqXWbj)
   pxBPeuESizswFlYNCdfyJHMKgqXWbI={'plot':'시청목록을 삭제합니다.'}
   pxBPeuESizswFlYNCdfyJHMKgqXWkT='*** 시청목록 삭제 ***'
   pxBPeuESizswFlYNCdfyJHMKgqXWbj={'mode':'MYVIEW_REMOVE','mediatype':pxBPeuESizswFlYNCdfyJHMKgqXWrG}
   pxBPeuESizswFlYNCdfyJHMKgqXWbr=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   pxBPeuESizswFlYNCdfyJHMKgqXWkj.add_dir(pxBPeuESizswFlYNCdfyJHMKgqXWkT,sublabel='',img=pxBPeuESizswFlYNCdfyJHMKgqXWbr,infoLabels=pxBPeuESizswFlYNCdfyJHMKgqXWbI,isFolder=pxBPeuESizswFlYNCdfyJHMKgqXWjU,params=pxBPeuESizswFlYNCdfyJHMKgqXWbj,isLink=pxBPeuESizswFlYNCdfyJHMKgqXWjI)
   xbmcplugin.endOfDirectory(pxBPeuESizswFlYNCdfyJHMKgqXWkj._addon_handle,cacheToDisc=pxBPeuESizswFlYNCdfyJHMKgqXWjU)
 def spotv_main(pxBPeuESizswFlYNCdfyJHMKgqXWkj):
  pxBPeuESizswFlYNCdfyJHMKgqXWjG=pxBPeuESizswFlYNCdfyJHMKgqXWkj.main_params.get('mode',pxBPeuESizswFlYNCdfyJHMKgqXWjv)
  if pxBPeuESizswFlYNCdfyJHMKgqXWjG=='LOGOUT':
   pxBPeuESizswFlYNCdfyJHMKgqXWkj.logout()
   return
  pxBPeuESizswFlYNCdfyJHMKgqXWkj.login_main()
  if pxBPeuESizswFlYNCdfyJHMKgqXWjG is pxBPeuESizswFlYNCdfyJHMKgqXWjv:
   pxBPeuESizswFlYNCdfyJHMKgqXWkj.dp_Main_List()
  elif pxBPeuESizswFlYNCdfyJHMKgqXWjG=='LIVE_GROUP':
   pxBPeuESizswFlYNCdfyJHMKgqXWkj.dp_LiveChannel_List(pxBPeuESizswFlYNCdfyJHMKgqXWkj.main_params)
  elif pxBPeuESizswFlYNCdfyJHMKgqXWjG=='ELIVE_GROUP':
   pxBPeuESizswFlYNCdfyJHMKgqXWrt=pxBPeuESizswFlYNCdfyJHMKgqXWkj.dp_EventLiveChannel_List(pxBPeuESizswFlYNCdfyJHMKgqXWkj.main_params)
   if pxBPeuESizswFlYNCdfyJHMKgqXWrt==401:
    if os.path.isfile(pxBPeuESizswFlYNCdfyJHMKgqXWkr):os.remove(pxBPeuESizswFlYNCdfyJHMKgqXWkr)
    pxBPeuESizswFlYNCdfyJHMKgqXWkj.login_main()
    pxBPeuESizswFlYNCdfyJHMKgqXWkj.dp_EventLiveChannel_List(pxBPeuESizswFlYNCdfyJHMKgqXWkj.main_params)
  elif pxBPeuESizswFlYNCdfyJHMKgqXWjG in['LIVE','GAME_VOD','POP_VOD','NOW_VOD','ELIVE']:
   pxBPeuESizswFlYNCdfyJHMKgqXWkj.play_VIDEO(pxBPeuESizswFlYNCdfyJHMKgqXWkj.main_params)
  elif pxBPeuESizswFlYNCdfyJHMKgqXWjG=='VOD_GROUP':
   pxBPeuESizswFlYNCdfyJHMKgqXWkj.dp_MainLeague_List(pxBPeuESizswFlYNCdfyJHMKgqXWkj.main_params)
  elif pxBPeuESizswFlYNCdfyJHMKgqXWjG=='NOW_GROUP':
   pxBPeuESizswFlYNCdfyJHMKgqXWkj.dp_NowVod_GroupList(pxBPeuESizswFlYNCdfyJHMKgqXWkj.main_params)
  elif pxBPeuESizswFlYNCdfyJHMKgqXWjG=='POP_GROUP':
   pxBPeuESizswFlYNCdfyJHMKgqXWkj.dp_PopVod_GroupList(pxBPeuESizswFlYNCdfyJHMKgqXWkj.main_params)
  elif pxBPeuESizswFlYNCdfyJHMKgqXWjG=='LEAGUE_GROUP':
   pxBPeuESizswFlYNCdfyJHMKgqXWkj.dp_Season_List(pxBPeuESizswFlYNCdfyJHMKgqXWkj.main_params)
  elif pxBPeuESizswFlYNCdfyJHMKgqXWjG=='SEASON_GROUP':
   pxBPeuESizswFlYNCdfyJHMKgqXWkj.dp_Game_List(pxBPeuESizswFlYNCdfyJHMKgqXWkj.main_params)
  elif pxBPeuESizswFlYNCdfyJHMKgqXWjG=='GAME_VOD_GROUP':
   pxBPeuESizswFlYNCdfyJHMKgqXWkj.dp_GameVod_List(pxBPeuESizswFlYNCdfyJHMKgqXWkj.main_params)
  elif pxBPeuESizswFlYNCdfyJHMKgqXWjG=='WATCH':
   pxBPeuESizswFlYNCdfyJHMKgqXWkj.dp_Watch_List(pxBPeuESizswFlYNCdfyJHMKgqXWkj.main_params)
  elif pxBPeuESizswFlYNCdfyJHMKgqXWjG=='MYVIEW_REMOVE':
   pxBPeuESizswFlYNCdfyJHMKgqXWkj.dp_WatchList_Delete(pxBPeuESizswFlYNCdfyJHMKgqXWkj.main_params)
  else:
   pxBPeuESizswFlYNCdfyJHMKgqXWjv
# Created by pyminifier (https://github.com/liftoff/pyminifier)
