__author__="NightRain"
XiHChLvzSrbwDcIyRUAlupKeQGmWOn=False
XiHChLvzSrbwDcIyRUAlupKeQGmWOs=object
XiHChLvzSrbwDcIyRUAlupKeQGmWOV=None
XiHChLvzSrbwDcIyRUAlupKeQGmWOd=print
XiHChLvzSrbwDcIyRUAlupKeQGmWOt=str
XiHChLvzSrbwDcIyRUAlupKeQGmWJY=True
XiHChLvzSrbwDcIyRUAlupKeQGmWJT=Exception
XiHChLvzSrbwDcIyRUAlupKeQGmWJN=int
XiHChLvzSrbwDcIyRUAlupKeQGmWJM=len
XiHChLvzSrbwDcIyRUAlupKeQGmWJO=range
import urllib
import re
import json
import sys
import time
import requests
import datetime
import base64
XiHChLvzSrbwDcIyRUAlupKeQGmWYN={'stream50':1080,'stream40':720,'stream30':540}
XiHChLvzSrbwDcIyRUAlupKeQGmWYM=[{'name':'NOW','videoId':'ch_spotvnow1','epgtype':'spotvon','epgnm':'spotvon','free':XiHChLvzSrbwDcIyRUAlupKeQGmWOn,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/ccdb36ce757afc1ca15fc38357d498e4.png'},{'name':'NOW2','videoId':'ch_spotvnow2','epgtype':'spotvon','epgnm':'spotvon2','free':XiHChLvzSrbwDcIyRUAlupKeQGmWOn,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/8b6bdf6213a715eeba719b2cb9b2c747.png'},{'name':'NBA TV','videoId':'ch_nbatv','epgtype':'-','epgnm':'-','free':XiHChLvzSrbwDcIyRUAlupKeQGmWOn,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/5036e56d5c6594ea606f7159f59779fe.png'},{'name':'SPOTV','videoId':'ch_spotv','epgtype':'spotvnet','epgnm':'SPOTV','free':XiHChLvzSrbwDcIyRUAlupKeQGmWOn,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/56688c2e527c6e1b8d68e338057a7dfc.png'},{'name':'SPOTV2','videoId':'ch_spotv2','epgtype':'spotvnet','epgnm':'SPOTV2','free':XiHChLvzSrbwDcIyRUAlupKeQGmWOn,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20201209/ca6e7a213c84e629985e609ddcda6b17.png'},{'name':'SPOTV Golf & Health','videoId':'ch_spotvplus','epgtype':'spotvnet','epgnm':'SPOTVP','free':XiHChLvzSrbwDcIyRUAlupKeQGmWOn,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/7aa87953f1211313c3e110cace2628ff.png'},]
XiHChLvzSrbwDcIyRUAlupKeQGmWYO={'ch_spotvnow1':{'lv':'abf18bbf3b3f4a0db4a41dd2af7f75c6','rv':'__nn__=5981484117001&hdnea=st=1609407000~exp=1609410600~acl=/abf18bbf3b3f4a0db4a41dd2af7f75c6/ap-northeast-1/5764318566001/*~hmac=e28a244d1b6b77d4e0101010816d4cd6ca89d9d31fe6a5290039d2395d81bc03'},'ch_spotvnow2':{'lv':'3054522000fc4d60aabe23d6e5911275','rv':'__nn__=5981484117001&hdnea=st=1609408800~exp=1609412400~acl=/3054522000fc4d60aabe23d6e5911275/ap-northeast-1/5764318566001/*~hmac=323b2deea8e3455fa77405f37b19231c6f0b48a5690b7218df875171ac2d6be6'},'ch_nbatv':{'lv':'31f99a0a6067413ea1b390c41a5c12be','rv':'__nn__=5981484117001&hdnea=st=1609408800~exp=1609412400~acl=/31f99a0a6067413ea1b390c41a5c12be/ap-northeast-1/5764318566001/*~hmac=b7ac24bc4772e3ad2669000919058bba64a6f001c69c8846341c326b089c306c'},'ch_spotv':{'lv':'1f2651c2fea34be9850bfdedf8d9cfdb','rv':'__nn__=5981484117001&hdnea=st=1609408800~exp=1609412400~acl=/1f2651c2fea34be9850bfdedf8d9cfdb/ap-northeast-1/5764318566001/*~hmac=e1f6c44d1be5459cfc40af1e1b204ac9b513bb7405e070da2bff8f115f298133'},'ch_spotv2':{'lv':'7bf3fb8685854892b01e1fc897e7e9b0','rv':'__nn__=5981484117001&hdnea=st=1609408800~exp=1609412400~acl=/7bf3fb8685854892b01e1fc897e7e9b0/ap-northeast-1/5764318566001/*~hmac=e9bb30991cfab98b1976aacabafcd51b63769ede40148f7cc289ffed15398e81'},'ch_spotvplus':{'lv':'242b2b6c0c654f47a07f4e2420f9c184','rv':'__nn__=5981484117001&hdnea=st=1609408800~exp=1609412400~acl=/242b2b6c0c654f47a07f4e2420f9c184/ap-northeast-1/5764318566001/*~hmac=5e4ce0553e709eb60d880bf37bc2e99661767b0a38ecee037fb4d7dce757b922'},}
class XiHChLvzSrbwDcIyRUAlupKeQGmWYT(XiHChLvzSrbwDcIyRUAlupKeQGmWOs):
 def __init__(XiHChLvzSrbwDcIyRUAlupKeQGmWYJ):
  XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.SPOTV_SESSIONID=''
  XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.SPOTV_SESSION =''
  XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.SPOTV_ACCOUNTID=''
  XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.SPOTV_POLICYKEY=''
  XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.SPOTV_SUBEND =''
  XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.SPOTV_PMCODE ='987'
  XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.SPOTV_PMSIZE =3
  XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.GAMELIST_LIMIT =10
  XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.API_DOMAIN ='https://www.spotvnow.co.kr'
  XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.BC_DOMAIN ='https://players.brightcove.net'
  XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.PLAYER_DOMAIN ='https://edge.api.brightcove.com'
  XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.STREAM_DOMAIN ='https://gtm-spotv.brightcovecdn.com'
  XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.STREAM_M3U8 ='ap-northeast-1/5764318566001/playlist_dvr'
  XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36'
  XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.DEFAULT_HEADER ={'user-agent':XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.USER_AGENT}
 def callRequestCookies(XiHChLvzSrbwDcIyRUAlupKeQGmWYJ,jobtype,XiHChLvzSrbwDcIyRUAlupKeQGmWTj,payload=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,params=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,headers=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,cookies=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,redirects=XiHChLvzSrbwDcIyRUAlupKeQGmWOn):
  XiHChLvzSrbwDcIyRUAlupKeQGmWYg=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.DEFAULT_HEADER
  if headers:XiHChLvzSrbwDcIyRUAlupKeQGmWYg.update(headers)
  if jobtype=='Get':
   XiHChLvzSrbwDcIyRUAlupKeQGmWYa=requests.get(XiHChLvzSrbwDcIyRUAlupKeQGmWTj,params=params,headers=XiHChLvzSrbwDcIyRUAlupKeQGmWYg,cookies=cookies,allow_redirects=redirects)
  else:
   XiHChLvzSrbwDcIyRUAlupKeQGmWYa=requests.post(XiHChLvzSrbwDcIyRUAlupKeQGmWTj,data=payload,params=params,headers=XiHChLvzSrbwDcIyRUAlupKeQGmWYg,cookies=cookies,allow_redirects=redirects)
  return XiHChLvzSrbwDcIyRUAlupKeQGmWYa
 def makeDefaultCookies(XiHChLvzSrbwDcIyRUAlupKeQGmWYJ):
  XiHChLvzSrbwDcIyRUAlupKeQGmWYj={'SESSION':XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.SPOTV_SESSION}
  return XiHChLvzSrbwDcIyRUAlupKeQGmWYj
 def xmlText(XiHChLvzSrbwDcIyRUAlupKeQGmWYJ,in_text):
  XiHChLvzSrbwDcIyRUAlupKeQGmWYB=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;')
  return XiHChLvzSrbwDcIyRUAlupKeQGmWYB
 def GetCredential(XiHChLvzSrbwDcIyRUAlupKeQGmWYJ,user_id,user_pw):
  XiHChLvzSrbwDcIyRUAlupKeQGmWYq=XiHChLvzSrbwDcIyRUAlupKeQGmWOn
  XiHChLvzSrbwDcIyRUAlupKeQGmWYx=XiHChLvzSrbwDcIyRUAlupKeQGmWYn=XiHChLvzSrbwDcIyRUAlupKeQGmWYd=XiHChLvzSrbwDcIyRUAlupKeQGmWYt=XiHChLvzSrbwDcIyRUAlupKeQGmWYV=''
  try:
   XiHChLvzSrbwDcIyRUAlupKeQGmWYF=base64.standard_b64encode(user_id.encode("UTF-8")).decode('utf-8')
   XiHChLvzSrbwDcIyRUAlupKeQGmWYE=base64.standard_b64encode(user_pw.encode("UTF-8")).decode('utf-8')
   XiHChLvzSrbwDcIyRUAlupKeQGmWYo=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.API_DOMAIN+'/api/v2/login'
   XiHChLvzSrbwDcIyRUAlupKeQGmWYf={'username':XiHChLvzSrbwDcIyRUAlupKeQGmWYF,'password':XiHChLvzSrbwDcIyRUAlupKeQGmWYE}
   XiHChLvzSrbwDcIyRUAlupKeQGmWYf=json.dumps(XiHChLvzSrbwDcIyRUAlupKeQGmWYf)
   XiHChLvzSrbwDcIyRUAlupKeQGmWYP=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.callRequestCookies('Post',XiHChLvzSrbwDcIyRUAlupKeQGmWYo,payload=XiHChLvzSrbwDcIyRUAlupKeQGmWYf,params=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,headers=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,cookies=XiHChLvzSrbwDcIyRUAlupKeQGmWOV)
   XiHChLvzSrbwDcIyRUAlupKeQGmWOd(XiHChLvzSrbwDcIyRUAlupKeQGmWYP.status_code)
   for XiHChLvzSrbwDcIyRUAlupKeQGmWYk in XiHChLvzSrbwDcIyRUAlupKeQGmWYP.cookies:
    if XiHChLvzSrbwDcIyRUAlupKeQGmWYk.name=='SESSION':
     XiHChLvzSrbwDcIyRUAlupKeQGmWYn=XiHChLvzSrbwDcIyRUAlupKeQGmWYk.value
     break
   if XiHChLvzSrbwDcIyRUAlupKeQGmWYn=='':return XiHChLvzSrbwDcIyRUAlupKeQGmWYq
   XiHChLvzSrbwDcIyRUAlupKeQGmWYs=json.loads(XiHChLvzSrbwDcIyRUAlupKeQGmWYP.text)
   if not('userId' in XiHChLvzSrbwDcIyRUAlupKeQGmWYs):return XiHChLvzSrbwDcIyRUAlupKeQGmWYq
   XiHChLvzSrbwDcIyRUAlupKeQGmWYx=XiHChLvzSrbwDcIyRUAlupKeQGmWOt(XiHChLvzSrbwDcIyRUAlupKeQGmWYs['userId'])
   XiHChLvzSrbwDcIyRUAlupKeQGmWYV =XiHChLvzSrbwDcIyRUAlupKeQGmWOt(XiHChLvzSrbwDcIyRUAlupKeQGmWYs['subEndTime'])
   XiHChLvzSrbwDcIyRUAlupKeQGmWYd,XiHChLvzSrbwDcIyRUAlupKeQGmWYt=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.GetPolicyKey()
   if XiHChLvzSrbwDcIyRUAlupKeQGmWYt=='':return XiHChLvzSrbwDcIyRUAlupKeQGmWYq
   XiHChLvzSrbwDcIyRUAlupKeQGmWYq=XiHChLvzSrbwDcIyRUAlupKeQGmWJY
  except XiHChLvzSrbwDcIyRUAlupKeQGmWJT as exception:
   XiHChLvzSrbwDcIyRUAlupKeQGmWYx=XiHChLvzSrbwDcIyRUAlupKeQGmWYn='' 
   XiHChLvzSrbwDcIyRUAlupKeQGmWOd(exception)
  XiHChLvzSrbwDcIyRUAlupKeQGmWTY={'spotv_sessionid':XiHChLvzSrbwDcIyRUAlupKeQGmWYx,'spotv_session':XiHChLvzSrbwDcIyRUAlupKeQGmWYn,'spotv_accountId':XiHChLvzSrbwDcIyRUAlupKeQGmWYd,'spotv_policyKey':XiHChLvzSrbwDcIyRUAlupKeQGmWYt,'spotv_subend':XiHChLvzSrbwDcIyRUAlupKeQGmWYV}
  XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.SaveCredential(XiHChLvzSrbwDcIyRUAlupKeQGmWTY)
  return XiHChLvzSrbwDcIyRUAlupKeQGmWYq
 def SaveCredential(XiHChLvzSrbwDcIyRUAlupKeQGmWYJ,XiHChLvzSrbwDcIyRUAlupKeQGmWTY):
  XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.SPOTV_SESSIONID=XiHChLvzSrbwDcIyRUAlupKeQGmWTY.get('spotv_sessionid')
  XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.SPOTV_SESSION =XiHChLvzSrbwDcIyRUAlupKeQGmWTY.get('spotv_session')
  XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.SPOTV_ACCOUNTID=XiHChLvzSrbwDcIyRUAlupKeQGmWTY.get('spotv_accountId')
  XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.SPOTV_POLICYKEY=XiHChLvzSrbwDcIyRUAlupKeQGmWTY.get('spotv_policyKey')
  XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.SPOTV_SUBEND =XiHChLvzSrbwDcIyRUAlupKeQGmWTY.get('spotv_subend')
 def LoadCredential(XiHChLvzSrbwDcIyRUAlupKeQGmWYJ):
  XiHChLvzSrbwDcIyRUAlupKeQGmWTY={'spotv_sessionid':XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.SPOTV_SESSIONID,'spotv_session':XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.SPOTV_SESSION,'spotv_accountId':XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.SPOTV_ACCOUNTID,'spotv_policyKey':XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.SPOTV_POLICYKEY,'spotv_subend':XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.SPOTV_SUBEND}
  return XiHChLvzSrbwDcIyRUAlupKeQGmWTY
 def Get_Now_Datetime(XiHChLvzSrbwDcIyRUAlupKeQGmWYJ):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_Streamurl_Make(XiHChLvzSrbwDcIyRUAlupKeQGmWYJ,XiHChLvzSrbwDcIyRUAlupKeQGmWNa):
  XiHChLvzSrbwDcIyRUAlupKeQGmWTM='%s/%s/%s.m3u8?%s'%(XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.STREAM_DOMAIN,XiHChLvzSrbwDcIyRUAlupKeQGmWYO.get(XiHChLvzSrbwDcIyRUAlupKeQGmWNa).get('lv'),XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.STREAM_M3U8,XiHChLvzSrbwDcIyRUAlupKeQGmWYO.get(XiHChLvzSrbwDcIyRUAlupKeQGmWNa).get('rv'))
  return XiHChLvzSrbwDcIyRUAlupKeQGmWTM
 def GetLiveChannelList(XiHChLvzSrbwDcIyRUAlupKeQGmWYJ):
  XiHChLvzSrbwDcIyRUAlupKeQGmWTO=[]
  XiHChLvzSrbwDcIyRUAlupKeQGmWTJ ={}
  try:
   XiHChLvzSrbwDcIyRUAlupKeQGmWTJ=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.GetEPGList_new()
   for XiHChLvzSrbwDcIyRUAlupKeQGmWTg in XiHChLvzSrbwDcIyRUAlupKeQGmWYM:
    XiHChLvzSrbwDcIyRUAlupKeQGmWTa={'name':XiHChLvzSrbwDcIyRUAlupKeQGmWTg['name'],'logo':XiHChLvzSrbwDcIyRUAlupKeQGmWTg['logo'],'videoId':XiHChLvzSrbwDcIyRUAlupKeQGmWTg['videoId'],'free':XiHChLvzSrbwDcIyRUAlupKeQGmWTg['free'],'channelepg':XiHChLvzSrbwDcIyRUAlupKeQGmWTJ.get(XiHChLvzSrbwDcIyRUAlupKeQGmWTg['videoId'])}
    XiHChLvzSrbwDcIyRUAlupKeQGmWTO.append(XiHChLvzSrbwDcIyRUAlupKeQGmWTa)
  except XiHChLvzSrbwDcIyRUAlupKeQGmWJT as exception:
   XiHChLvzSrbwDcIyRUAlupKeQGmWOd(exception)
  return XiHChLvzSrbwDcIyRUAlupKeQGmWTO
 def CheckLiveChannel(XiHChLvzSrbwDcIyRUAlupKeQGmWYJ,XiHChLvzSrbwDcIyRUAlupKeQGmWTs):
  try:
   XiHChLvzSrbwDcIyRUAlupKeQGmWTj=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.API_DOMAIN+'/api/v2/channel'
   XiHChLvzSrbwDcIyRUAlupKeQGmWYP=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.callRequestCookies('Get',XiHChLvzSrbwDcIyRUAlupKeQGmWTj,payload=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,params=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,headers=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,cookies=XiHChLvzSrbwDcIyRUAlupKeQGmWOV)
   XiHChLvzSrbwDcIyRUAlupKeQGmWYs=json.loads(XiHChLvzSrbwDcIyRUAlupKeQGmWYP.text)
   for XiHChLvzSrbwDcIyRUAlupKeQGmWTg in XiHChLvzSrbwDcIyRUAlupKeQGmWYs:
    if XiHChLvzSrbwDcIyRUAlupKeQGmWTg['videoId'].replace('ref:','')==XiHChLvzSrbwDcIyRUAlupKeQGmWTs:
     return XiHChLvzSrbwDcIyRUAlupKeQGmWTg['free']
  except XiHChLvzSrbwDcIyRUAlupKeQGmWJT as exception:
   XiHChLvzSrbwDcIyRUAlupKeQGmWOd(exception)
  return XiHChLvzSrbwDcIyRUAlupKeQGmWOn
 def GetEPGList(XiHChLvzSrbwDcIyRUAlupKeQGmWYJ):
  XiHChLvzSrbwDcIyRUAlupKeQGmWTB={}
  XiHChLvzSrbwDcIyRUAlupKeQGmWTq=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.Get_Now_Datetime()
  XiHChLvzSrbwDcIyRUAlupKeQGmWTx=XiHChLvzSrbwDcIyRUAlupKeQGmWTq.strftime('%Y%m%d%H%M')
  XiHChLvzSrbwDcIyRUAlupKeQGmWTF='%s-%s-%s'%(XiHChLvzSrbwDcIyRUAlupKeQGmWTx[0:4],XiHChLvzSrbwDcIyRUAlupKeQGmWTx[4:6],XiHChLvzSrbwDcIyRUAlupKeQGmWTx[6:8])
  XiHChLvzSrbwDcIyRUAlupKeQGmWTE=(XiHChLvzSrbwDcIyRUAlupKeQGmWTq+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M')
  try:
   XiHChLvzSrbwDcIyRUAlupKeQGmWTj=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.API_DOMAIN+'/api/v2/program/'+XiHChLvzSrbwDcIyRUAlupKeQGmWTF
   XiHChLvzSrbwDcIyRUAlupKeQGmWYP=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.callRequestCookies('Get',XiHChLvzSrbwDcIyRUAlupKeQGmWTj,payload=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,params=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,headers=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,cookies=XiHChLvzSrbwDcIyRUAlupKeQGmWOV)
   XiHChLvzSrbwDcIyRUAlupKeQGmWYs=json.loads(XiHChLvzSrbwDcIyRUAlupKeQGmWYP.text)
   XiHChLvzSrbwDcIyRUAlupKeQGmWTo=-1 
   XiHChLvzSrbwDcIyRUAlupKeQGmWTf =''
   for XiHChLvzSrbwDcIyRUAlupKeQGmWTg in XiHChLvzSrbwDcIyRUAlupKeQGmWYs:
    XiHChLvzSrbwDcIyRUAlupKeQGmWTP=XiHChLvzSrbwDcIyRUAlupKeQGmWTg['channelId']
    XiHChLvzSrbwDcIyRUAlupKeQGmWTk =XiHChLvzSrbwDcIyRUAlupKeQGmWTg['startTime'].replace('-','').replace(' ','').replace(':','')
    XiHChLvzSrbwDcIyRUAlupKeQGmWTn =XiHChLvzSrbwDcIyRUAlupKeQGmWTg['endTime'].replace('-','').replace(' ','').replace(':','')
    if XiHChLvzSrbwDcIyRUAlupKeQGmWJN(XiHChLvzSrbwDcIyRUAlupKeQGmWTx)>XiHChLvzSrbwDcIyRUAlupKeQGmWJN(XiHChLvzSrbwDcIyRUAlupKeQGmWTn) :continue
    if XiHChLvzSrbwDcIyRUAlupKeQGmWJN(XiHChLvzSrbwDcIyRUAlupKeQGmWTE)<XiHChLvzSrbwDcIyRUAlupKeQGmWJN(XiHChLvzSrbwDcIyRUAlupKeQGmWTk):continue
    if XiHChLvzSrbwDcIyRUAlupKeQGmWTo!=XiHChLvzSrbwDcIyRUAlupKeQGmWTP:
     if XiHChLvzSrbwDcIyRUAlupKeQGmWTf!='':XiHChLvzSrbwDcIyRUAlupKeQGmWTB[XiHChLvzSrbwDcIyRUAlupKeQGmWTo]=XiHChLvzSrbwDcIyRUAlupKeQGmWTf
     XiHChLvzSrbwDcIyRUAlupKeQGmWTo=XiHChLvzSrbwDcIyRUAlupKeQGmWTP
     XiHChLvzSrbwDcIyRUAlupKeQGmWTf =''
    if XiHChLvzSrbwDcIyRUAlupKeQGmWTf:XiHChLvzSrbwDcIyRUAlupKeQGmWTf+='\n'
    XiHChLvzSrbwDcIyRUAlupKeQGmWTf+=XiHChLvzSrbwDcIyRUAlupKeQGmWTg['title']+'\n'
    XiHChLvzSrbwDcIyRUAlupKeQGmWTf+=' [%s ~ %s]'%(XiHChLvzSrbwDcIyRUAlupKeQGmWTg['startTime'][-5:],XiHChLvzSrbwDcIyRUAlupKeQGmWTg['endTime'][-5:])+'\n'
   if XiHChLvzSrbwDcIyRUAlupKeQGmWTf:XiHChLvzSrbwDcIyRUAlupKeQGmWTB[XiHChLvzSrbwDcIyRUAlupKeQGmWTo]=XiHChLvzSrbwDcIyRUAlupKeQGmWTf
  except XiHChLvzSrbwDcIyRUAlupKeQGmWJT as exception:
   XiHChLvzSrbwDcIyRUAlupKeQGmWOd(exception)
  return XiHChLvzSrbwDcIyRUAlupKeQGmWTB
 def GetEPGList_new(XiHChLvzSrbwDcIyRUAlupKeQGmWYJ):
  XiHChLvzSrbwDcIyRUAlupKeQGmWTB={}
  XiHChLvzSrbwDcIyRUAlupKeQGmWTq=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.Get_Now_Datetime()
  XiHChLvzSrbwDcIyRUAlupKeQGmWTx=XiHChLvzSrbwDcIyRUAlupKeQGmWTq.strftime('%Y%m%d%H%M00')
  XiHChLvzSrbwDcIyRUAlupKeQGmWTF='%s%s%s'%(XiHChLvzSrbwDcIyRUAlupKeQGmWTx[0:4],XiHChLvzSrbwDcIyRUAlupKeQGmWTx[4:6],XiHChLvzSrbwDcIyRUAlupKeQGmWTx[6:8])
  XiHChLvzSrbwDcIyRUAlupKeQGmWTE=(XiHChLvzSrbwDcIyRUAlupKeQGmWTq+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M00')
  try:
   for XiHChLvzSrbwDcIyRUAlupKeQGmWTg in XiHChLvzSrbwDcIyRUAlupKeQGmWYM:
    XiHChLvzSrbwDcIyRUAlupKeQGmWTs =XiHChLvzSrbwDcIyRUAlupKeQGmWTg['videoId']
    if XiHChLvzSrbwDcIyRUAlupKeQGmWTg['epgtype']=='spotvon':
     XiHChLvzSrbwDcIyRUAlupKeQGmWTf=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.Get_EpgInfo_Spotv_spotvon(XiHChLvzSrbwDcIyRUAlupKeQGmWTs,XiHChLvzSrbwDcIyRUAlupKeQGmWTg['epgnm'],XiHChLvzSrbwDcIyRUAlupKeQGmWTF)
     XiHChLvzSrbwDcIyRUAlupKeQGmWTB[XiHChLvzSrbwDcIyRUAlupKeQGmWTs]=XiHChLvzSrbwDcIyRUAlupKeQGmWTf
    if XiHChLvzSrbwDcIyRUAlupKeQGmWTg['epgtype']=='spotvnet':
     XiHChLvzSrbwDcIyRUAlupKeQGmWTf=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.Get_EpgInfo_Spotv_spotvnet(XiHChLvzSrbwDcIyRUAlupKeQGmWTs,XiHChLvzSrbwDcIyRUAlupKeQGmWTg['epgnm'],XiHChLvzSrbwDcIyRUAlupKeQGmWTF)
     XiHChLvzSrbwDcIyRUAlupKeQGmWTB[XiHChLvzSrbwDcIyRUAlupKeQGmWTs]=XiHChLvzSrbwDcIyRUAlupKeQGmWTf
   for XiHChLvzSrbwDcIyRUAlupKeQGmWTV in XiHChLvzSrbwDcIyRUAlupKeQGmWTB.keys():
    if XiHChLvzSrbwDcIyRUAlupKeQGmWJM(XiHChLvzSrbwDcIyRUAlupKeQGmWTB.get(XiHChLvzSrbwDcIyRUAlupKeQGmWTV))==0:continue
    XiHChLvzSrbwDcIyRUAlupKeQGmWTf =''
    XiHChLvzSrbwDcIyRUAlupKeQGmWTd=''
    for XiHChLvzSrbwDcIyRUAlupKeQGmWTt in XiHChLvzSrbwDcIyRUAlupKeQGmWTB.get(XiHChLvzSrbwDcIyRUAlupKeQGmWTV):
     XiHChLvzSrbwDcIyRUAlupKeQGmWTk =XiHChLvzSrbwDcIyRUAlupKeQGmWTt['startTime']
     XiHChLvzSrbwDcIyRUAlupKeQGmWTn =XiHChLvzSrbwDcIyRUAlupKeQGmWTt['endTime']
     if XiHChLvzSrbwDcIyRUAlupKeQGmWJN(XiHChLvzSrbwDcIyRUAlupKeQGmWTx)>XiHChLvzSrbwDcIyRUAlupKeQGmWJN(XiHChLvzSrbwDcIyRUAlupKeQGmWTn) :continue
     if XiHChLvzSrbwDcIyRUAlupKeQGmWJN(XiHChLvzSrbwDcIyRUAlupKeQGmWTE)<XiHChLvzSrbwDcIyRUAlupKeQGmWJN(XiHChLvzSrbwDcIyRUAlupKeQGmWTk):continue
     if XiHChLvzSrbwDcIyRUAlupKeQGmWJN(XiHChLvzSrbwDcIyRUAlupKeQGmWTx)>=XiHChLvzSrbwDcIyRUAlupKeQGmWJN(XiHChLvzSrbwDcIyRUAlupKeQGmWTk)and XiHChLvzSrbwDcIyRUAlupKeQGmWJN(XiHChLvzSrbwDcIyRUAlupKeQGmWTx)<XiHChLvzSrbwDcIyRUAlupKeQGmWJN(XiHChLvzSrbwDcIyRUAlupKeQGmWTn):XiHChLvzSrbwDcIyRUAlupKeQGmWTd=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.xmlText(XiHChLvzSrbwDcIyRUAlupKeQGmWTt['title'])
     if XiHChLvzSrbwDcIyRUAlupKeQGmWTf:XiHChLvzSrbwDcIyRUAlupKeQGmWTf+='\n'
     XiHChLvzSrbwDcIyRUAlupKeQGmWTf+=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.xmlText(XiHChLvzSrbwDcIyRUAlupKeQGmWTt['title'])+'\n'
     XiHChLvzSrbwDcIyRUAlupKeQGmWTf+=' [%s:%s ~ %s:%s]'%(XiHChLvzSrbwDcIyRUAlupKeQGmWTt['startTime'][8:10],XiHChLvzSrbwDcIyRUAlupKeQGmWTt['startTime'][10:12],XiHChLvzSrbwDcIyRUAlupKeQGmWTt['endTime'][8:10],XiHChLvzSrbwDcIyRUAlupKeQGmWTt['endTime'][10:12])+'\n'
    XiHChLvzSrbwDcIyRUAlupKeQGmWTB[XiHChLvzSrbwDcIyRUAlupKeQGmWTV]={'epg':XiHChLvzSrbwDcIyRUAlupKeQGmWTf,'title':XiHChLvzSrbwDcIyRUAlupKeQGmWTd}
  except XiHChLvzSrbwDcIyRUAlupKeQGmWJT as exception:
   XiHChLvzSrbwDcIyRUAlupKeQGmWOd(exception)
  return XiHChLvzSrbwDcIyRUAlupKeQGmWTB
 def Get_EpgInfo_Spotv_spotvon(XiHChLvzSrbwDcIyRUAlupKeQGmWYJ,XiHChLvzSrbwDcIyRUAlupKeQGmWTs,epgnm,now_day):
  XiHChLvzSrbwDcIyRUAlupKeQGmWTB =[]
  try:
   XiHChLvzSrbwDcIyRUAlupKeQGmWTj='https://www.spotvon.co.kr/data/onAir/%s/Daily/D%s.asp'%(epgnm,now_day)
   XiHChLvzSrbwDcIyRUAlupKeQGmWYP=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.callRequestCookies('Get',XiHChLvzSrbwDcIyRUAlupKeQGmWTj,payload=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,params=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,headers=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,cookies=XiHChLvzSrbwDcIyRUAlupKeQGmWOV)
   XiHChLvzSrbwDcIyRUAlupKeQGmWNY=json.loads(XiHChLvzSrbwDcIyRUAlupKeQGmWYP.text)
   for XiHChLvzSrbwDcIyRUAlupKeQGmWTg in XiHChLvzSrbwDcIyRUAlupKeQGmWNY:
    XiHChLvzSrbwDcIyRUAlupKeQGmWTa={'title':XiHChLvzSrbwDcIyRUAlupKeQGmWTg['title'],'startTime':XiHChLvzSrbwDcIyRUAlupKeQGmWTg['sch_date'].replace('-','')+XiHChLvzSrbwDcIyRUAlupKeQGmWOt(XiHChLvzSrbwDcIyRUAlupKeQGmWTg['sch_hour']).zfill(2)+XiHChLvzSrbwDcIyRUAlupKeQGmWTg['sch_min']+'00'}
    XiHChLvzSrbwDcIyRUAlupKeQGmWTB.append(XiHChLvzSrbwDcIyRUAlupKeQGmWTa)
   for i in XiHChLvzSrbwDcIyRUAlupKeQGmWJO(XiHChLvzSrbwDcIyRUAlupKeQGmWJM(XiHChLvzSrbwDcIyRUAlupKeQGmWTB)):
    if i>0:XiHChLvzSrbwDcIyRUAlupKeQGmWTB[i-1]['endTime']=XiHChLvzSrbwDcIyRUAlupKeQGmWTB[i]['startTime']
    if i==XiHChLvzSrbwDcIyRUAlupKeQGmWJM(XiHChLvzSrbwDcIyRUAlupKeQGmWTB)-1: XiHChLvzSrbwDcIyRUAlupKeQGmWTB[i]['endTime']=now_day+'240000'
  except XiHChLvzSrbwDcIyRUAlupKeQGmWJT as exception:
   XiHChLvzSrbwDcIyRUAlupKeQGmWOd(exception)
   return[]
  return XiHChLvzSrbwDcIyRUAlupKeQGmWTB
 def Get_EpgInfo_Spotv_spotvnet(XiHChLvzSrbwDcIyRUAlupKeQGmWYJ,XiHChLvzSrbwDcIyRUAlupKeQGmWTs,epgnm,now_day):
  XiHChLvzSrbwDcIyRUAlupKeQGmWTB =[]
  try:
   XiHChLvzSrbwDcIyRUAlupKeQGmWTj='https://www.spotv.net/data/json/schedule/%s/Daily/D%s.json'%(epgnm,now_day)
   XiHChLvzSrbwDcIyRUAlupKeQGmWYP=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.callRequestCookies('Get',XiHChLvzSrbwDcIyRUAlupKeQGmWTj,payload=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,params=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,headers=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,cookies=XiHChLvzSrbwDcIyRUAlupKeQGmWOV)
   XiHChLvzSrbwDcIyRUAlupKeQGmWNY=json.loads(XiHChLvzSrbwDcIyRUAlupKeQGmWYP.text)
   for XiHChLvzSrbwDcIyRUAlupKeQGmWTg in XiHChLvzSrbwDcIyRUAlupKeQGmWNY:
    XiHChLvzSrbwDcIyRUAlupKeQGmWTa={'title':XiHChLvzSrbwDcIyRUAlupKeQGmWTg['title'],'startTime':XiHChLvzSrbwDcIyRUAlupKeQGmWTg['sch_date'].replace('-','')+XiHChLvzSrbwDcIyRUAlupKeQGmWOt(XiHChLvzSrbwDcIyRUAlupKeQGmWTg['sch_hour']).zfill(2)+XiHChLvzSrbwDcIyRUAlupKeQGmWTg['sch_min']+'00'}
    XiHChLvzSrbwDcIyRUAlupKeQGmWTB.append(XiHChLvzSrbwDcIyRUAlupKeQGmWTa)
   for i in XiHChLvzSrbwDcIyRUAlupKeQGmWJO(XiHChLvzSrbwDcIyRUAlupKeQGmWJM(XiHChLvzSrbwDcIyRUAlupKeQGmWTB)):
    if i>0:XiHChLvzSrbwDcIyRUAlupKeQGmWTB[i-1]['endTime']=XiHChLvzSrbwDcIyRUAlupKeQGmWTB[i]['startTime']
    if i==XiHChLvzSrbwDcIyRUAlupKeQGmWJM(XiHChLvzSrbwDcIyRUAlupKeQGmWTB)-1: XiHChLvzSrbwDcIyRUAlupKeQGmWTB[i]['endTime']=now_day+'240000'
  except XiHChLvzSrbwDcIyRUAlupKeQGmWJT as exception:
   XiHChLvzSrbwDcIyRUAlupKeQGmWOd(exception)
   return[]
  return XiHChLvzSrbwDcIyRUAlupKeQGmWTB
 def GetEventLiveList(XiHChLvzSrbwDcIyRUAlupKeQGmWYJ):
  XiHChLvzSrbwDcIyRUAlupKeQGmWTO=[]
  XiHChLvzSrbwDcIyRUAlupKeQGmWNT =0
  try:
   XiHChLvzSrbwDcIyRUAlupKeQGmWNM=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.Get_Now_Datetime()
   XiHChLvzSrbwDcIyRUAlupKeQGmWNO=XiHChLvzSrbwDcIyRUAlupKeQGmWNM.strftime('%Y-%m-%d')
  except XiHChLvzSrbwDcIyRUAlupKeQGmWJT as exception:
   XiHChLvzSrbwDcIyRUAlupKeQGmWOd(exception)
   return XiHChLvzSrbwDcIyRUAlupKeQGmWTO,XiHChLvzSrbwDcIyRUAlupKeQGmWNT
  try:
   XiHChLvzSrbwDcIyRUAlupKeQGmWTj=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.API_DOMAIN+'/api/v2/player/lives/'+XiHChLvzSrbwDcIyRUAlupKeQGmWNO 
   XiHChLvzSrbwDcIyRUAlupKeQGmWYj=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.makeDefaultCookies()
   XiHChLvzSrbwDcIyRUAlupKeQGmWYP=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.callRequestCookies('Get',XiHChLvzSrbwDcIyRUAlupKeQGmWTj,payload=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,params=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,headers=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,cookies=XiHChLvzSrbwDcIyRUAlupKeQGmWYj)
   XiHChLvzSrbwDcIyRUAlupKeQGmWNT=XiHChLvzSrbwDcIyRUAlupKeQGmWYP.status_code 
   XiHChLvzSrbwDcIyRUAlupKeQGmWYs=json.loads(XiHChLvzSrbwDcIyRUAlupKeQGmWYP.text)
   for XiHChLvzSrbwDcIyRUAlupKeQGmWNJ in XiHChLvzSrbwDcIyRUAlupKeQGmWYs:
    for XiHChLvzSrbwDcIyRUAlupKeQGmWTg in XiHChLvzSrbwDcIyRUAlupKeQGmWNJ['liveNowList']:
     if XiHChLvzSrbwDcIyRUAlupKeQGmWTg['gameDesc']['title']==XiHChLvzSrbwDcIyRUAlupKeQGmWOV or XiHChLvzSrbwDcIyRUAlupKeQGmWTg['gameDesc']['title']=='':
      XiHChLvzSrbwDcIyRUAlupKeQGmWNg='%s ( %s : %s )'%(XiHChLvzSrbwDcIyRUAlupKeQGmWTg['leagueName'],XiHChLvzSrbwDcIyRUAlupKeQGmWTg['homeNameShort'],XiHChLvzSrbwDcIyRUAlupKeQGmWTg['awayNameShort'])
     else:
      XiHChLvzSrbwDcIyRUAlupKeQGmWNg=XiHChLvzSrbwDcIyRUAlupKeQGmWTg['gameDesc']['title']
     XiHChLvzSrbwDcIyRUAlupKeQGmWTa={'liveId':XiHChLvzSrbwDcIyRUAlupKeQGmWTg['liveId'],'title':XiHChLvzSrbwDcIyRUAlupKeQGmWNg,'logo':XiHChLvzSrbwDcIyRUAlupKeQGmWTg['gameDesc']['leagueLogo'],'free':XiHChLvzSrbwDcIyRUAlupKeQGmWTg['isFree'],'startTime':XiHChLvzSrbwDcIyRUAlupKeQGmWTg['startTime']}
     XiHChLvzSrbwDcIyRUAlupKeQGmWTO.append(XiHChLvzSrbwDcIyRUAlupKeQGmWTa)
  except XiHChLvzSrbwDcIyRUAlupKeQGmWJT as exception:
   XiHChLvzSrbwDcIyRUAlupKeQGmWOd(exception)
  return XiHChLvzSrbwDcIyRUAlupKeQGmWTO,XiHChLvzSrbwDcIyRUAlupKeQGmWNT
 def GetEventLive_videoId(XiHChLvzSrbwDcIyRUAlupKeQGmWYJ,liveId):
  XiHChLvzSrbwDcIyRUAlupKeQGmWNa=''
  try:
   XiHChLvzSrbwDcIyRUAlupKeQGmWTj=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.API_DOMAIN+'/api/v2/live/'+liveId
   XiHChLvzSrbwDcIyRUAlupKeQGmWYP=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.callRequestCookies('Get',XiHChLvzSrbwDcIyRUAlupKeQGmWTj,payload=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,params=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,headers=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,cookies=XiHChLvzSrbwDcIyRUAlupKeQGmWOV)
   XiHChLvzSrbwDcIyRUAlupKeQGmWYs=json.loads(XiHChLvzSrbwDcIyRUAlupKeQGmWYP.text)
   XiHChLvzSrbwDcIyRUAlupKeQGmWNj=XiHChLvzSrbwDcIyRUAlupKeQGmWYs['videoId']
   XiHChLvzSrbwDcIyRUAlupKeQGmWNa=XiHChLvzSrbwDcIyRUAlupKeQGmWNj.replace('ref:','')
  except XiHChLvzSrbwDcIyRUAlupKeQGmWJT as exception:
   XiHChLvzSrbwDcIyRUAlupKeQGmWOd(exception)
  return XiHChLvzSrbwDcIyRUAlupKeQGmWNa
 def CheckMainEnd(XiHChLvzSrbwDcIyRUAlupKeQGmWYJ):
  XiHChLvzSrbwDcIyRUAlupKeQGmWNB=base64.standard_b64encode((XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.SPOTV_PMCODE+XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.SPOTV_SESSIONID).encode()).decode('utf-8')
  if XiHChLvzSrbwDcIyRUAlupKeQGmWNB=='OTg3MTgzMzM0Ng==' or XiHChLvzSrbwDcIyRUAlupKeQGmWNB=='OTg3MTgzMzExNw==':return XiHChLvzSrbwDcIyRUAlupKeQGmWJY
  return XiHChLvzSrbwDcIyRUAlupKeQGmWOn
 def CheckSubEnd(XiHChLvzSrbwDcIyRUAlupKeQGmWYJ):
  XiHChLvzSrbwDcIyRUAlupKeQGmWNq=XiHChLvzSrbwDcIyRUAlupKeQGmWOn
  try:
   if XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.CheckMainEnd():return XiHChLvzSrbwDcIyRUAlupKeQGmWJY 
   if XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.SPOTV_SUBEND=='0':return XiHChLvzSrbwDcIyRUAlupKeQGmWNq
   XiHChLvzSrbwDcIyRUAlupKeQGmWNx =XiHChLvzSrbwDcIyRUAlupKeQGmWJN(XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.Get_Now_Datetime().strftime('%Y%m%d'))
   XiHChLvzSrbwDcIyRUAlupKeQGmWNF =XiHChLvzSrbwDcIyRUAlupKeQGmWJN(XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.SPOTV_SUBEND)/1000
   XiHChLvzSrbwDcIyRUAlupKeQGmWNE =XiHChLvzSrbwDcIyRUAlupKeQGmWJN(datetime.datetime.fromtimestamp(XiHChLvzSrbwDcIyRUAlupKeQGmWNF,datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul')).strftime('%Y%m%d'))
   if XiHChLvzSrbwDcIyRUAlupKeQGmWNx<=XiHChLvzSrbwDcIyRUAlupKeQGmWNE:XiHChLvzSrbwDcIyRUAlupKeQGmWNq=XiHChLvzSrbwDcIyRUAlupKeQGmWJY
  except XiHChLvzSrbwDcIyRUAlupKeQGmWJT as exception:
   XiHChLvzSrbwDcIyRUAlupKeQGmWOd(exception)
   return XiHChLvzSrbwDcIyRUAlupKeQGmWNq
  return XiHChLvzSrbwDcIyRUAlupKeQGmWNq
 def GetMainJspath(XiHChLvzSrbwDcIyRUAlupKeQGmWYJ):
  XiHChLvzSrbwDcIyRUAlupKeQGmWNo=''
  try:
   XiHChLvzSrbwDcIyRUAlupKeQGmWTj=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.API_DOMAIN
   XiHChLvzSrbwDcIyRUAlupKeQGmWYP=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.callRequestCookies('Get',XiHChLvzSrbwDcIyRUAlupKeQGmWTj,payload=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,params=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,headers=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,cookies=XiHChLvzSrbwDcIyRUAlupKeQGmWOV)
   XiHChLvzSrbwDcIyRUAlupKeQGmWNf=XiHChLvzSrbwDcIyRUAlupKeQGmWYP.text
   XiHChLvzSrbwDcIyRUAlupKeQGmWNP =re.findall('https://cdn.spotvnow.co.kr/dist/js/.{20}\.js',XiHChLvzSrbwDcIyRUAlupKeQGmWNf)[0]
   XiHChLvzSrbwDcIyRUAlupKeQGmWNo=XiHChLvzSrbwDcIyRUAlupKeQGmWNP
  except XiHChLvzSrbwDcIyRUAlupKeQGmWJT as exception:
   XiHChLvzSrbwDcIyRUAlupKeQGmWOd(exception)
  return XiHChLvzSrbwDcIyRUAlupKeQGmWNo
 def GetBcPlayerUrl(XiHChLvzSrbwDcIyRUAlupKeQGmWYJ):
  XiHChLvzSrbwDcIyRUAlupKeQGmWNk=''
  try:
   XiHChLvzSrbwDcIyRUAlupKeQGmWTj=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.GetMainJspath()
   if XiHChLvzSrbwDcIyRUAlupKeQGmWTj=='':return XiHChLvzSrbwDcIyRUAlupKeQGmWNk
   XiHChLvzSrbwDcIyRUAlupKeQGmWYP=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.callRequestCookies('Get',XiHChLvzSrbwDcIyRUAlupKeQGmWTj,payload=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,params=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,headers=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,cookies=XiHChLvzSrbwDcIyRUAlupKeQGmWOV)
   XiHChLvzSrbwDcIyRUAlupKeQGmWNf=XiHChLvzSrbwDcIyRUAlupKeQGmWYP.text
   XiHChLvzSrbwDcIyRUAlupKeQGmWNf=XiHChLvzSrbwDcIyRUAlupKeQGmWYP.text
   XiHChLvzSrbwDcIyRUAlupKeQGmWNn =r'default:{(.*?)}'
   XiHChLvzSrbwDcIyRUAlupKeQGmWNs =re.compile(XiHChLvzSrbwDcIyRUAlupKeQGmWNn).findall(XiHChLvzSrbwDcIyRUAlupKeQGmWNf)[0]
   XiHChLvzSrbwDcIyRUAlupKeQGmWNV=r'bc:"(.*?)"'
   XiHChLvzSrbwDcIyRUAlupKeQGmWNd=re.compile(XiHChLvzSrbwDcIyRUAlupKeQGmWNV).findall(XiHChLvzSrbwDcIyRUAlupKeQGmWNs)[0]
   XiHChLvzSrbwDcIyRUAlupKeQGmWNt=r'":"(.*?)"'
   XiHChLvzSrbwDcIyRUAlupKeQGmWMY=re.compile(XiHChLvzSrbwDcIyRUAlupKeQGmWNt).findall(XiHChLvzSrbwDcIyRUAlupKeQGmWNs)[0]
   bc =XiHChLvzSrbwDcIyRUAlupKeQGmWNd 
   XiHChLvzSrbwDcIyRUAlupKeQGmWMT=XiHChLvzSrbwDcIyRUAlupKeQGmWMY 
   XiHChLvzSrbwDcIyRUAlupKeQGmWNk="%s/%s/%s_default/index.min.js"%(XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.BC_DOMAIN,bc,XiHChLvzSrbwDcIyRUAlupKeQGmWMT)
  except XiHChLvzSrbwDcIyRUAlupKeQGmWJT as exception:
   XiHChLvzSrbwDcIyRUAlupKeQGmWOd(exception)
  return XiHChLvzSrbwDcIyRUAlupKeQGmWNk
 def GetPolicyKey(XiHChLvzSrbwDcIyRUAlupKeQGmWYJ):
  XiHChLvzSrbwDcIyRUAlupKeQGmWMN=policykey=''
  try:
   XiHChLvzSrbwDcIyRUAlupKeQGmWTj=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.GetBcPlayerUrl()
   if XiHChLvzSrbwDcIyRUAlupKeQGmWTj=='':return XiHChLvzSrbwDcIyRUAlupKeQGmWMN,policykey
   XiHChLvzSrbwDcIyRUAlupKeQGmWYP=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.callRequestCookies('Get',XiHChLvzSrbwDcIyRUAlupKeQGmWTj,payload=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,params=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,headers=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,cookies=XiHChLvzSrbwDcIyRUAlupKeQGmWOV)
   XiHChLvzSrbwDcIyRUAlupKeQGmWNf=XiHChLvzSrbwDcIyRUAlupKeQGmWYP.text
   XiHChLvzSrbwDcIyRUAlupKeQGmWNP =re.findall('accountId:\s*\"\d{13}\",\s*policyKey:\s*\".[^(){}]{100,300}\"',XiHChLvzSrbwDcIyRUAlupKeQGmWNf)[0]
   XiHChLvzSrbwDcIyRUAlupKeQGmWNP =XiHChLvzSrbwDcIyRUAlupKeQGmWNP.replace('accountId','"accountId"')
   XiHChLvzSrbwDcIyRUAlupKeQGmWNP =XiHChLvzSrbwDcIyRUAlupKeQGmWNP.replace('policyKey','"policyKey"')
   XiHChLvzSrbwDcIyRUAlupKeQGmWNP ='{'+XiHChLvzSrbwDcIyRUAlupKeQGmWNP+'}'
   XiHChLvzSrbwDcIyRUAlupKeQGmWMO=json.loads(XiHChLvzSrbwDcIyRUAlupKeQGmWNP)
   XiHChLvzSrbwDcIyRUAlupKeQGmWMN =XiHChLvzSrbwDcIyRUAlupKeQGmWMO['accountId']
   XiHChLvzSrbwDcIyRUAlupKeQGmWMJ =XiHChLvzSrbwDcIyRUAlupKeQGmWMO['policyKey']
  except XiHChLvzSrbwDcIyRUAlupKeQGmWJT as exception:
   XiHChLvzSrbwDcIyRUAlupKeQGmWOd(exception)
  return XiHChLvzSrbwDcIyRUAlupKeQGmWMN,XiHChLvzSrbwDcIyRUAlupKeQGmWMJ
 def GetBroadURL(XiHChLvzSrbwDcIyRUAlupKeQGmWYJ,XiHChLvzSrbwDcIyRUAlupKeQGmWNa,mediatype,XiHChLvzSrbwDcIyRUAlupKeQGmWMP):
  XiHChLvzSrbwDcIyRUAlupKeQGmWMg=''
  try:
   if mediatype=='live':
    XiHChLvzSrbwDcIyRUAlupKeQGmWTj=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.API_DOMAIN+'/api/v2/live/'+XiHChLvzSrbwDcIyRUAlupKeQGmWNa
   else:
    XiHChLvzSrbwDcIyRUAlupKeQGmWNa=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.GetReplay_UrlId(XiHChLvzSrbwDcIyRUAlupKeQGmWNa,XiHChLvzSrbwDcIyRUAlupKeQGmWMP)
    if XiHChLvzSrbwDcIyRUAlupKeQGmWNa=='':return XiHChLvzSrbwDcIyRUAlupKeQGmWMg
    XiHChLvzSrbwDcIyRUAlupKeQGmWTj=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.PLAYER_DOMAIN+'/playback/v1/accounts/'+XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.SPOTV_ACCOUNTID+'/videos/'+XiHChLvzSrbwDcIyRUAlupKeQGmWNa
   XiHChLvzSrbwDcIyRUAlupKeQGmWMa={'accept':'application/json;pk='+XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.SPOTV_POLICYKEY}
   XiHChLvzSrbwDcIyRUAlupKeQGmWYP=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.callRequestCookies('Get',XiHChLvzSrbwDcIyRUAlupKeQGmWTj,payload=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,params=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,headers=XiHChLvzSrbwDcIyRUAlupKeQGmWMa,cookies=XiHChLvzSrbwDcIyRUAlupKeQGmWOV)
   XiHChLvzSrbwDcIyRUAlupKeQGmWNY=json.loads(XiHChLvzSrbwDcIyRUAlupKeQGmWYP.text)
   if mediatype=='live':
    XiHChLvzSrbwDcIyRUAlupKeQGmWMg=XiHChLvzSrbwDcIyRUAlupKeQGmWNY['hlsUrl2']
   else:
    XiHChLvzSrbwDcIyRUAlupKeQGmWMg=XiHChLvzSrbwDcIyRUAlupKeQGmWNY['sources'][0]['src']
   XiHChLvzSrbwDcIyRUAlupKeQGmWMg=XiHChLvzSrbwDcIyRUAlupKeQGmWMg.replace('http://','https://')
  except XiHChLvzSrbwDcIyRUAlupKeQGmWJT as exception:
   XiHChLvzSrbwDcIyRUAlupKeQGmWOd(exception)
  return XiHChLvzSrbwDcIyRUAlupKeQGmWMg
 def GetTitleGroupList(XiHChLvzSrbwDcIyRUAlupKeQGmWYJ):
  XiHChLvzSrbwDcIyRUAlupKeQGmWTO=[]
  XiHChLvzSrbwDcIyRUAlupKeQGmWMj=XiHChLvzSrbwDcIyRUAlupKeQGmWOn
  try:
   XiHChLvzSrbwDcIyRUAlupKeQGmWTj=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.API_DOMAIN+'/api/v2/home/web'
   XiHChLvzSrbwDcIyRUAlupKeQGmWYP=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.callRequestCookies('Get',XiHChLvzSrbwDcIyRUAlupKeQGmWTj,payload=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,params=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,headers=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,cookies=XiHChLvzSrbwDcIyRUAlupKeQGmWOV)
   XiHChLvzSrbwDcIyRUAlupKeQGmWYs=json.loads(XiHChLvzSrbwDcIyRUAlupKeQGmWYP.text)
   for XiHChLvzSrbwDcIyRUAlupKeQGmWTg in XiHChLvzSrbwDcIyRUAlupKeQGmWYs:
    if XiHChLvzSrbwDcIyRUAlupKeQGmWOt(XiHChLvzSrbwDcIyRUAlupKeQGmWTg['type'])=='3':
     XiHChLvzSrbwDcIyRUAlupKeQGmWMB=''
     for XiHChLvzSrbwDcIyRUAlupKeQGmWMq in XiHChLvzSrbwDcIyRUAlupKeQGmWTg['data']['list']:
      XiHChLvzSrbwDcIyRUAlupKeQGmWMx='[%s] %s vs %s\n<%s>\n\n'%(XiHChLvzSrbwDcIyRUAlupKeQGmWMq['gameDesc']['roundName'],XiHChLvzSrbwDcIyRUAlupKeQGmWMq['gameDesc']['homeNameShort'],XiHChLvzSrbwDcIyRUAlupKeQGmWMq['gameDesc']['awayNameShort'],XiHChLvzSrbwDcIyRUAlupKeQGmWMq['gameDesc']['beginDate'])
      XiHChLvzSrbwDcIyRUAlupKeQGmWMB+=XiHChLvzSrbwDcIyRUAlupKeQGmWMx
     XiHChLvzSrbwDcIyRUAlupKeQGmWTa={'title':XiHChLvzSrbwDcIyRUAlupKeQGmWTg['title'],'logo':XiHChLvzSrbwDcIyRUAlupKeQGmWTg['logo'],'reagueId':XiHChLvzSrbwDcIyRUAlupKeQGmWOt(XiHChLvzSrbwDcIyRUAlupKeQGmWTg['destId']),'subGame':XiHChLvzSrbwDcIyRUAlupKeQGmWMB}
     XiHChLvzSrbwDcIyRUAlupKeQGmWTO.append(XiHChLvzSrbwDcIyRUAlupKeQGmWTa)
     if XiHChLvzSrbwDcIyRUAlupKeQGmWOt(XiHChLvzSrbwDcIyRUAlupKeQGmWTg['destId'])=='13':XiHChLvzSrbwDcIyRUAlupKeQGmWMj=XiHChLvzSrbwDcIyRUAlupKeQGmWJY
   if XiHChLvzSrbwDcIyRUAlupKeQGmWMj==XiHChLvzSrbwDcIyRUAlupKeQGmWOn:
    XiHChLvzSrbwDcIyRUAlupKeQGmWTa={'title':'UFC','logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200928/a643c7cf1c285fb0b4469c07d4c09c28.png','reagueId':'13','subGame':''}
    XiHChLvzSrbwDcIyRUAlupKeQGmWTO.append(XiHChLvzSrbwDcIyRUAlupKeQGmWTa)
  except XiHChLvzSrbwDcIyRUAlupKeQGmWJT as exception:
   XiHChLvzSrbwDcIyRUAlupKeQGmWOd(exception)
  return XiHChLvzSrbwDcIyRUAlupKeQGmWTO
 def GetPopularGroupList(XiHChLvzSrbwDcIyRUAlupKeQGmWYJ):
  XiHChLvzSrbwDcIyRUAlupKeQGmWTO=[]
  try:
   XiHChLvzSrbwDcIyRUAlupKeQGmWTj=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.API_DOMAIN+'/api/v2/home/web'
   XiHChLvzSrbwDcIyRUAlupKeQGmWYP=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.callRequestCookies('Get',XiHChLvzSrbwDcIyRUAlupKeQGmWTj,payload=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,params=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,headers=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,cookies=XiHChLvzSrbwDcIyRUAlupKeQGmWOV)
   XiHChLvzSrbwDcIyRUAlupKeQGmWYs=json.loads(XiHChLvzSrbwDcIyRUAlupKeQGmWYP.text)
   for XiHChLvzSrbwDcIyRUAlupKeQGmWTg in XiHChLvzSrbwDcIyRUAlupKeQGmWYs:
    if XiHChLvzSrbwDcIyRUAlupKeQGmWOt(XiHChLvzSrbwDcIyRUAlupKeQGmWTg['type'])=='1' and XiHChLvzSrbwDcIyRUAlupKeQGmWOt(XiHChLvzSrbwDcIyRUAlupKeQGmWTg['destId'])=='4':
     for XiHChLvzSrbwDcIyRUAlupKeQGmWMq in XiHChLvzSrbwDcIyRUAlupKeQGmWTg['data']['list']:
      XiHChLvzSrbwDcIyRUAlupKeQGmWMF =XiHChLvzSrbwDcIyRUAlupKeQGmWMq['title']
      XiHChLvzSrbwDcIyRUAlupKeQGmWME =XiHChLvzSrbwDcIyRUAlupKeQGmWMq['id']
      XiHChLvzSrbwDcIyRUAlupKeQGmWMo =XiHChLvzSrbwDcIyRUAlupKeQGmWMq['vtype']
      XiHChLvzSrbwDcIyRUAlupKeQGmWMf =XiHChLvzSrbwDcIyRUAlupKeQGmWMq['imgUrl']
      XiHChLvzSrbwDcIyRUAlupKeQGmWMP =XiHChLvzSrbwDcIyRUAlupKeQGmWMq['vtypeId']
      XiHChLvzSrbwDcIyRUAlupKeQGmWTa={'vodTitle':XiHChLvzSrbwDcIyRUAlupKeQGmWMF,'vodId':XiHChLvzSrbwDcIyRUAlupKeQGmWME,'vodType':XiHChLvzSrbwDcIyRUAlupKeQGmWMo,'thumbnail':XiHChLvzSrbwDcIyRUAlupKeQGmWMf,'vtypeId':XiHChLvzSrbwDcIyRUAlupKeQGmWOt(XiHChLvzSrbwDcIyRUAlupKeQGmWMP),'duration':XiHChLvzSrbwDcIyRUAlupKeQGmWJN(XiHChLvzSrbwDcIyRUAlupKeQGmWMq['duration']/1000)}
      XiHChLvzSrbwDcIyRUAlupKeQGmWTO.append(XiHChLvzSrbwDcIyRUAlupKeQGmWTa)
  except XiHChLvzSrbwDcIyRUAlupKeQGmWJT as exception:
   XiHChLvzSrbwDcIyRUAlupKeQGmWOd(exception)
  return XiHChLvzSrbwDcIyRUAlupKeQGmWTO
 def Get_NowVod_GroupList(XiHChLvzSrbwDcIyRUAlupKeQGmWYJ,page_int):
  XiHChLvzSrbwDcIyRUAlupKeQGmWTO=[]
  XiHChLvzSrbwDcIyRUAlupKeQGmWMk=XiHChLvzSrbwDcIyRUAlupKeQGmWOn
  try:
   XiHChLvzSrbwDcIyRUAlupKeQGmWTj=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.API_DOMAIN+'/api/v2/theme/14/list'
   XiHChLvzSrbwDcIyRUAlupKeQGmWMn={'pageItem':'10','pageNo':XiHChLvzSrbwDcIyRUAlupKeQGmWOt(page_int)}
   XiHChLvzSrbwDcIyRUAlupKeQGmWYP=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.callRequestCookies('Get',XiHChLvzSrbwDcIyRUAlupKeQGmWTj,payload=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,params=XiHChLvzSrbwDcIyRUAlupKeQGmWMn,headers=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,cookies=XiHChLvzSrbwDcIyRUAlupKeQGmWOV)
   XiHChLvzSrbwDcIyRUAlupKeQGmWYs=json.loads(XiHChLvzSrbwDcIyRUAlupKeQGmWYP.text)
   for XiHChLvzSrbwDcIyRUAlupKeQGmWTg in XiHChLvzSrbwDcIyRUAlupKeQGmWYs['list']:
    XiHChLvzSrbwDcIyRUAlupKeQGmWMF =XiHChLvzSrbwDcIyRUAlupKeQGmWTg['title']
    XiHChLvzSrbwDcIyRUAlupKeQGmWME =XiHChLvzSrbwDcIyRUAlupKeQGmWTg['id']
    XiHChLvzSrbwDcIyRUAlupKeQGmWMo =XiHChLvzSrbwDcIyRUAlupKeQGmWTg['vtype']
    XiHChLvzSrbwDcIyRUAlupKeQGmWMf =XiHChLvzSrbwDcIyRUAlupKeQGmWTg['imgUrl']
    XiHChLvzSrbwDcIyRUAlupKeQGmWMP =XiHChLvzSrbwDcIyRUAlupKeQGmWTg['vtypeId']
    XiHChLvzSrbwDcIyRUAlupKeQGmWTa={'vodTitle':XiHChLvzSrbwDcIyRUAlupKeQGmWMF,'vodId':XiHChLvzSrbwDcIyRUAlupKeQGmWME,'vodType':XiHChLvzSrbwDcIyRUAlupKeQGmWMo,'thumbnail':XiHChLvzSrbwDcIyRUAlupKeQGmWMf,'vtypeId':XiHChLvzSrbwDcIyRUAlupKeQGmWOt(XiHChLvzSrbwDcIyRUAlupKeQGmWMP),'duration':XiHChLvzSrbwDcIyRUAlupKeQGmWJN(XiHChLvzSrbwDcIyRUAlupKeQGmWTg['duration']/1000),}
    XiHChLvzSrbwDcIyRUAlupKeQGmWTO.append(XiHChLvzSrbwDcIyRUAlupKeQGmWTa)
    if XiHChLvzSrbwDcIyRUAlupKeQGmWYs['count']>page_int*XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.GAMELIST_LIMIT:XiHChLvzSrbwDcIyRUAlupKeQGmWMk=XiHChLvzSrbwDcIyRUAlupKeQGmWJY
  except XiHChLvzSrbwDcIyRUAlupKeQGmWJT as exception:
   XiHChLvzSrbwDcIyRUAlupKeQGmWOd(exception)
  return XiHChLvzSrbwDcIyRUAlupKeQGmWTO,XiHChLvzSrbwDcIyRUAlupKeQGmWMk
 def GetSeasonList(XiHChLvzSrbwDcIyRUAlupKeQGmWYJ,leagueId):
  XiHChLvzSrbwDcIyRUAlupKeQGmWTO=[]
  XiHChLvzSrbwDcIyRUAlupKeQGmWMs=XiHChLvzSrbwDcIyRUAlupKeQGmWMV=''
  try:
   XiHChLvzSrbwDcIyRUAlupKeQGmWTj=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.API_DOMAIN+'/api/v2/game/league/'+leagueId
   XiHChLvzSrbwDcIyRUAlupKeQGmWYP=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.callRequestCookies('Get',XiHChLvzSrbwDcIyRUAlupKeQGmWTj,payload=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,params=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,headers=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,cookies=XiHChLvzSrbwDcIyRUAlupKeQGmWOV)
   XiHChLvzSrbwDcIyRUAlupKeQGmWYs=json.loads(XiHChLvzSrbwDcIyRUAlupKeQGmWYP.text)
   XiHChLvzSrbwDcIyRUAlupKeQGmWMs=XiHChLvzSrbwDcIyRUAlupKeQGmWYs['name']
   XiHChLvzSrbwDcIyRUAlupKeQGmWMV=XiHChLvzSrbwDcIyRUAlupKeQGmWOt(XiHChLvzSrbwDcIyRUAlupKeQGmWYs['gameTypeId'])
  except XiHChLvzSrbwDcIyRUAlupKeQGmWJT as exception:
   XiHChLvzSrbwDcIyRUAlupKeQGmWOd(exception)
   return XiHChLvzSrbwDcIyRUAlupKeQGmWTO
  if XiHChLvzSrbwDcIyRUAlupKeQGmWMV=='2':
   try:
    XiHChLvzSrbwDcIyRUAlupKeQGmWTj=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.API_DOMAIN+'/api/v2/year/'+leagueId
    XiHChLvzSrbwDcIyRUAlupKeQGmWYP=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.callRequestCookies('Get',XiHChLvzSrbwDcIyRUAlupKeQGmWTj,payload=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,params=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,headers=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,cookies=XiHChLvzSrbwDcIyRUAlupKeQGmWOV)
    XiHChLvzSrbwDcIyRUAlupKeQGmWYs=json.loads(XiHChLvzSrbwDcIyRUAlupKeQGmWYP.text)
    for XiHChLvzSrbwDcIyRUAlupKeQGmWTg in XiHChLvzSrbwDcIyRUAlupKeQGmWYs:
     XiHChLvzSrbwDcIyRUAlupKeQGmWTa={'reagueName':XiHChLvzSrbwDcIyRUAlupKeQGmWMs,'gameTypeId':XiHChLvzSrbwDcIyRUAlupKeQGmWMV,'seasonName':XiHChLvzSrbwDcIyRUAlupKeQGmWOt(XiHChLvzSrbwDcIyRUAlupKeQGmWTg),'seasonId':XiHChLvzSrbwDcIyRUAlupKeQGmWOt(XiHChLvzSrbwDcIyRUAlupKeQGmWTg)}
     XiHChLvzSrbwDcIyRUAlupKeQGmWTO.append(XiHChLvzSrbwDcIyRUAlupKeQGmWTa)
   except XiHChLvzSrbwDcIyRUAlupKeQGmWJT as exception:
    XiHChLvzSrbwDcIyRUAlupKeQGmWOd(exception)
    return[]
  else:
   try:
    XiHChLvzSrbwDcIyRUAlupKeQGmWTj=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.API_DOMAIN+'/api/v2/season/'+leagueId
    XiHChLvzSrbwDcIyRUAlupKeQGmWYP=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.callRequestCookies('Get',XiHChLvzSrbwDcIyRUAlupKeQGmWTj,payload=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,params=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,headers=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,cookies=XiHChLvzSrbwDcIyRUAlupKeQGmWOV)
    XiHChLvzSrbwDcIyRUAlupKeQGmWYs=json.loads(XiHChLvzSrbwDcIyRUAlupKeQGmWYP.text)
    for XiHChLvzSrbwDcIyRUAlupKeQGmWTg in XiHChLvzSrbwDcIyRUAlupKeQGmWYs:
     XiHChLvzSrbwDcIyRUAlupKeQGmWTa={'reagueName':XiHChLvzSrbwDcIyRUAlupKeQGmWMs,'gameTypeId':XiHChLvzSrbwDcIyRUAlupKeQGmWMV,'seasonName':XiHChLvzSrbwDcIyRUAlupKeQGmWTg['name'],'seasonId':XiHChLvzSrbwDcIyRUAlupKeQGmWOt(XiHChLvzSrbwDcIyRUAlupKeQGmWTg['id'])}
     XiHChLvzSrbwDcIyRUAlupKeQGmWTO.append(XiHChLvzSrbwDcIyRUAlupKeQGmWTa)
   except XiHChLvzSrbwDcIyRUAlupKeQGmWJT as exception:
    XiHChLvzSrbwDcIyRUAlupKeQGmWOd(exception)
    return[]
  return XiHChLvzSrbwDcIyRUAlupKeQGmWTO
 def GetGameList(XiHChLvzSrbwDcIyRUAlupKeQGmWYJ,XiHChLvzSrbwDcIyRUAlupKeQGmWMV,leagueId,seasonId,page_int,hidescore=XiHChLvzSrbwDcIyRUAlupKeQGmWJY):
  XiHChLvzSrbwDcIyRUAlupKeQGmWTO=[]
  XiHChLvzSrbwDcIyRUAlupKeQGmWMk=XiHChLvzSrbwDcIyRUAlupKeQGmWOn
  try:
   XiHChLvzSrbwDcIyRUAlupKeQGmWTj=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.API_DOMAIN+'/api/v2/vod/league/detail'
   XiHChLvzSrbwDcIyRUAlupKeQGmWMn={'gameType':XiHChLvzSrbwDcIyRUAlupKeQGmWMV,'leagueId':leagueId,'seasonId':seasonId if XiHChLvzSrbwDcIyRUAlupKeQGmWMV!='2' else '','teamId':'','roundId':'','year':'' if XiHChLvzSrbwDcIyRUAlupKeQGmWMV!='2' else seasonId,'pageNo':XiHChLvzSrbwDcIyRUAlupKeQGmWOt(page_int)}
   XiHChLvzSrbwDcIyRUAlupKeQGmWYP=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.callRequestCookies('Get',XiHChLvzSrbwDcIyRUAlupKeQGmWTj,payload=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,params=XiHChLvzSrbwDcIyRUAlupKeQGmWMn,headers=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,cookies=XiHChLvzSrbwDcIyRUAlupKeQGmWOV)
   XiHChLvzSrbwDcIyRUAlupKeQGmWYs=json.loads(XiHChLvzSrbwDcIyRUAlupKeQGmWYP.text)
   XiHChLvzSrbwDcIyRUAlupKeQGmWNJ=XiHChLvzSrbwDcIyRUAlupKeQGmWYs['list']
   for XiHChLvzSrbwDcIyRUAlupKeQGmWMd in XiHChLvzSrbwDcIyRUAlupKeQGmWNJ:
    for XiHChLvzSrbwDcIyRUAlupKeQGmWTg in XiHChLvzSrbwDcIyRUAlupKeQGmWMd['list']:
     if XiHChLvzSrbwDcIyRUAlupKeQGmWTg['gameDesc']['title']==XiHChLvzSrbwDcIyRUAlupKeQGmWOV or XiHChLvzSrbwDcIyRUAlupKeQGmWTg['gameDesc']['title']=='':
      XiHChLvzSrbwDcIyRUAlupKeQGmWNg ='%s vs %s'%(XiHChLvzSrbwDcIyRUAlupKeQGmWTg['gameDesc']['homeNameShort'],XiHChLvzSrbwDcIyRUAlupKeQGmWTg['gameDesc']['awayNameShort'])
     else:
      XiHChLvzSrbwDcIyRUAlupKeQGmWNg =XiHChLvzSrbwDcIyRUAlupKeQGmWTg['gameDesc']['title']
     XiHChLvzSrbwDcIyRUAlupKeQGmWMt =XiHChLvzSrbwDcIyRUAlupKeQGmWTg['gameDesc']['beginDate']
     XiHChLvzSrbwDcIyRUAlupKeQGmWOY =XiHChLvzSrbwDcIyRUAlupKeQGmWTg['gameDesc']['id']
     XiHChLvzSrbwDcIyRUAlupKeQGmWOT =XiHChLvzSrbwDcIyRUAlupKeQGmWTg['gameDesc']['leagueNameFull']
     XiHChLvzSrbwDcIyRUAlupKeQGmWON =XiHChLvzSrbwDcIyRUAlupKeQGmWTg['gameDesc']['seasonName']
     XiHChLvzSrbwDcIyRUAlupKeQGmWOM =XiHChLvzSrbwDcIyRUAlupKeQGmWTg['gameDesc']['roundName']
     XiHChLvzSrbwDcIyRUAlupKeQGmWOJ =XiHChLvzSrbwDcIyRUAlupKeQGmWTg['gameDesc']['homeName']
     XiHChLvzSrbwDcIyRUAlupKeQGmWOg =XiHChLvzSrbwDcIyRUAlupKeQGmWTg['gameDesc']['awayName']
     XiHChLvzSrbwDcIyRUAlupKeQGmWOa =XiHChLvzSrbwDcIyRUAlupKeQGmWTg['gameDesc']['homeScore']
     XiHChLvzSrbwDcIyRUAlupKeQGmWOj =XiHChLvzSrbwDcIyRUAlupKeQGmWTg['gameDesc']['awayScore']
     if hidescore==XiHChLvzSrbwDcIyRUAlupKeQGmWJY:
      XiHChLvzSrbwDcIyRUAlupKeQGmWOB ='%s\n - %s (%s)\n - %s\n\nhome : %s\n\naway : %s'%(XiHChLvzSrbwDcIyRUAlupKeQGmWOT,XiHChLvzSrbwDcIyRUAlupKeQGmWON,XiHChLvzSrbwDcIyRUAlupKeQGmWOM,XiHChLvzSrbwDcIyRUAlupKeQGmWMt,XiHChLvzSrbwDcIyRUAlupKeQGmWOJ,XiHChLvzSrbwDcIyRUAlupKeQGmWOg)
     else:
      XiHChLvzSrbwDcIyRUAlupKeQGmWOB ='%s\n - %s (%s)\n - %s\n\nhome : %s (Score %s)\n\naway : %s (Score %s)'%(XiHChLvzSrbwDcIyRUAlupKeQGmWOT,XiHChLvzSrbwDcIyRUAlupKeQGmWON,XiHChLvzSrbwDcIyRUAlupKeQGmWOM,XiHChLvzSrbwDcIyRUAlupKeQGmWMt,XiHChLvzSrbwDcIyRUAlupKeQGmWOJ,XiHChLvzSrbwDcIyRUAlupKeQGmWOa,XiHChLvzSrbwDcIyRUAlupKeQGmWOg,XiHChLvzSrbwDcIyRUAlupKeQGmWOj)
     XiHChLvzSrbwDcIyRUAlupKeQGmWOq=XiHChLvzSrbwDcIyRUAlupKeQGmWOB
     XiHChLvzSrbwDcIyRUAlupKeQGmWOx =XiHChLvzSrbwDcIyRUAlupKeQGmWTg['replayVod']['count']
     XiHChLvzSrbwDcIyRUAlupKeQGmWOF=XiHChLvzSrbwDcIyRUAlupKeQGmWTg['highlightVod']['count']
     XiHChLvzSrbwDcIyRUAlupKeQGmWOE =XiHChLvzSrbwDcIyRUAlupKeQGmWTg['vods']['count']
     XiHChLvzSrbwDcIyRUAlupKeQGmWMf='' 
     XiHChLvzSrbwDcIyRUAlupKeQGmWOo=XiHChLvzSrbwDcIyRUAlupKeQGmWOx+XiHChLvzSrbwDcIyRUAlupKeQGmWOF+XiHChLvzSrbwDcIyRUAlupKeQGmWOE
     if XiHChLvzSrbwDcIyRUAlupKeQGmWOo==0:
      if XiHChLvzSrbwDcIyRUAlupKeQGmWMV=='2':
       XiHChLvzSrbwDcIyRUAlupKeQGmWNg='----- %s -----'%(XiHChLvzSrbwDcIyRUAlupKeQGmWON)
       XiHChLvzSrbwDcIyRUAlupKeQGmWMt=''
      else:
       XiHChLvzSrbwDcIyRUAlupKeQGmWNg+=' - 관련영상 없음'
       XiHChLvzSrbwDcIyRUAlupKeQGmWOq+='\n\n ** 관련영상 없음 **'
     else:
      if XiHChLvzSrbwDcIyRUAlupKeQGmWOx!=0:
       XiHChLvzSrbwDcIyRUAlupKeQGmWMf =XiHChLvzSrbwDcIyRUAlupKeQGmWTg['replayVod']['list'][0]['imgUrl']
      elif XiHChLvzSrbwDcIyRUAlupKeQGmWOF!=0:
       XiHChLvzSrbwDcIyRUAlupKeQGmWMf =XiHChLvzSrbwDcIyRUAlupKeQGmWTg['highlightVod']['list'][0]['imgUrl']
      else:
       XiHChLvzSrbwDcIyRUAlupKeQGmWMf =XiHChLvzSrbwDcIyRUAlupKeQGmWTg['vods']['list'][0]['imgUrl']
     XiHChLvzSrbwDcIyRUAlupKeQGmWTa={'gameTitle':XiHChLvzSrbwDcIyRUAlupKeQGmWNg,'gameId':XiHChLvzSrbwDcIyRUAlupKeQGmWOY,'beginDate':XiHChLvzSrbwDcIyRUAlupKeQGmWMt[:11],'thumbnail':XiHChLvzSrbwDcIyRUAlupKeQGmWMf,'info_plot':XiHChLvzSrbwDcIyRUAlupKeQGmWOq,'leaguenm':XiHChLvzSrbwDcIyRUAlupKeQGmWOT,'seasonnm':XiHChLvzSrbwDcIyRUAlupKeQGmWON,'roundnm':XiHChLvzSrbwDcIyRUAlupKeQGmWOM,'totVodCnt':XiHChLvzSrbwDcIyRUAlupKeQGmWOo}
     XiHChLvzSrbwDcIyRUAlupKeQGmWTO.append(XiHChLvzSrbwDcIyRUAlupKeQGmWTa)
  except XiHChLvzSrbwDcIyRUAlupKeQGmWJT as exception:
   XiHChLvzSrbwDcIyRUAlupKeQGmWOd(exception)
  try:
   if XiHChLvzSrbwDcIyRUAlupKeQGmWMV=='2':
    if XiHChLvzSrbwDcIyRUAlupKeQGmWYs['count']>page_int*XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.GAMELIST_LIMIT:XiHChLvzSrbwDcIyRUAlupKeQGmWMk=XiHChLvzSrbwDcIyRUAlupKeQGmWJY
   else:
    if XiHChLvzSrbwDcIyRUAlupKeQGmWYs['count']>page_int*XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.GAMELIST_LIMIT:XiHChLvzSrbwDcIyRUAlupKeQGmWMk=XiHChLvzSrbwDcIyRUAlupKeQGmWJY
  except:
   XiHChLvzSrbwDcIyRUAlupKeQGmWOd(exception)
  return XiHChLvzSrbwDcIyRUAlupKeQGmWTO,XiHChLvzSrbwDcIyRUAlupKeQGmWMk
 def GetGameVodList(XiHChLvzSrbwDcIyRUAlupKeQGmWYJ,XiHChLvzSrbwDcIyRUAlupKeQGmWOY):
  XiHChLvzSrbwDcIyRUAlupKeQGmWTO=[]
  XiHChLvzSrbwDcIyRUAlupKeQGmWOf=''
  try:
   XiHChLvzSrbwDcIyRUAlupKeQGmWTj=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.API_DOMAIN+'/api/v2/vod/game'
   XiHChLvzSrbwDcIyRUAlupKeQGmWMn={'gameId':XiHChLvzSrbwDcIyRUAlupKeQGmWOY,'pageItem':'1000'}
   XiHChLvzSrbwDcIyRUAlupKeQGmWYP=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.callRequestCookies('Get',XiHChLvzSrbwDcIyRUAlupKeQGmWTj,payload=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,params=XiHChLvzSrbwDcIyRUAlupKeQGmWMn,headers=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,cookies=XiHChLvzSrbwDcIyRUAlupKeQGmWOV)
   XiHChLvzSrbwDcIyRUAlupKeQGmWYs=json.loads(XiHChLvzSrbwDcIyRUAlupKeQGmWYP.text)
   XiHChLvzSrbwDcIyRUAlupKeQGmWMd=XiHChLvzSrbwDcIyRUAlupKeQGmWYs['list']
   for XiHChLvzSrbwDcIyRUAlupKeQGmWTg in XiHChLvzSrbwDcIyRUAlupKeQGmWMd:
    XiHChLvzSrbwDcIyRUAlupKeQGmWMF =XiHChLvzSrbwDcIyRUAlupKeQGmWTg['title']
    XiHChLvzSrbwDcIyRUAlupKeQGmWME =XiHChLvzSrbwDcIyRUAlupKeQGmWTg['id']
    XiHChLvzSrbwDcIyRUAlupKeQGmWMo =XiHChLvzSrbwDcIyRUAlupKeQGmWTg['vtype']
    XiHChLvzSrbwDcIyRUAlupKeQGmWMf =XiHChLvzSrbwDcIyRUAlupKeQGmWTg['imgUrl']
    XiHChLvzSrbwDcIyRUAlupKeQGmWMP =XiHChLvzSrbwDcIyRUAlupKeQGmWTg['vtypeId']
    XiHChLvzSrbwDcIyRUAlupKeQGmWTa={'vodTitle':XiHChLvzSrbwDcIyRUAlupKeQGmWMF,'vodId':XiHChLvzSrbwDcIyRUAlupKeQGmWME,'vodType':XiHChLvzSrbwDcIyRUAlupKeQGmWMo,'thumbnail':XiHChLvzSrbwDcIyRUAlupKeQGmWMf,'vtypeId':XiHChLvzSrbwDcIyRUAlupKeQGmWOt(XiHChLvzSrbwDcIyRUAlupKeQGmWMP),'duration':XiHChLvzSrbwDcIyRUAlupKeQGmWJN(XiHChLvzSrbwDcIyRUAlupKeQGmWTg['duration']/1000)}
    XiHChLvzSrbwDcIyRUAlupKeQGmWTO.append(XiHChLvzSrbwDcIyRUAlupKeQGmWTa)
  except XiHChLvzSrbwDcIyRUAlupKeQGmWJT as exception:
   XiHChLvzSrbwDcIyRUAlupKeQGmWOd(exception)
  return XiHChLvzSrbwDcIyRUAlupKeQGmWTO
 def GetReplay_UrlId(XiHChLvzSrbwDcIyRUAlupKeQGmWYJ,XiHChLvzSrbwDcIyRUAlupKeQGmWOf,XiHChLvzSrbwDcIyRUAlupKeQGmWMP):
  XiHChLvzSrbwDcIyRUAlupKeQGmWOP=XiHChLvzSrbwDcIyRUAlupKeQGmWNa=''
  XiHChLvzSrbwDcIyRUAlupKeQGmWOk=''
  try:
   XiHChLvzSrbwDcIyRUAlupKeQGmWTj=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.API_DOMAIN+'/api/v2/vod/'+XiHChLvzSrbwDcIyRUAlupKeQGmWOf
   XiHChLvzSrbwDcIyRUAlupKeQGmWYP=XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.callRequestCookies('Get',XiHChLvzSrbwDcIyRUAlupKeQGmWTj,payload=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,params=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,headers=XiHChLvzSrbwDcIyRUAlupKeQGmWOV,cookies=XiHChLvzSrbwDcIyRUAlupKeQGmWOV)
   XiHChLvzSrbwDcIyRUAlupKeQGmWYs=json.loads(XiHChLvzSrbwDcIyRUAlupKeQGmWYP.text)
   XiHChLvzSrbwDcIyRUAlupKeQGmWOP =XiHChLvzSrbwDcIyRUAlupKeQGmWYs['clipId']
   XiHChLvzSrbwDcIyRUAlupKeQGmWNa=XiHChLvzSrbwDcIyRUAlupKeQGmWYs['videoId']
   XiHChLvzSrbwDcIyRUAlupKeQGmWOk=XiHChLvzSrbwDcIyRUAlupKeQGmWOP
   if XiHChLvzSrbwDcIyRUAlupKeQGmWYJ.CheckSubEnd()or XiHChLvzSrbwDcIyRUAlupKeQGmWMP!='1':XiHChLvzSrbwDcIyRUAlupKeQGmWOk=XiHChLvzSrbwDcIyRUAlupKeQGmWNa 
  except XiHChLvzSrbwDcIyRUAlupKeQGmWJT as exception:
   XiHChLvzSrbwDcIyRUAlupKeQGmWOd(exception)
  return XiHChLvzSrbwDcIyRUAlupKeQGmWOk
# Created by pyminifier (https://github.com/liftoff/pyminifier)
