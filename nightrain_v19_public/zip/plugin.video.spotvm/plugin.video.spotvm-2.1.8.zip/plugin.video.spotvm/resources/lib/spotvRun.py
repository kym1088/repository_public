__author__="NightRain"
YJrITwqevtVzaEHdmNSQWLPUKhRjDs=object
YJrITwqevtVzaEHdmNSQWLPUKhRjDi=None
YJrITwqevtVzaEHdmNSQWLPUKhRjDc=False
YJrITwqevtVzaEHdmNSQWLPUKhRjDx=True
YJrITwqevtVzaEHdmNSQWLPUKhRjDB=int
YJrITwqevtVzaEHdmNSQWLPUKhRjDb=len
YJrITwqevtVzaEHdmNSQWLPUKhRjDo=str
YJrITwqevtVzaEHdmNSQWLPUKhRjDC=open
YJrITwqevtVzaEHdmNSQWLPUKhRjDX=Exception
YJrITwqevtVzaEHdmNSQWLPUKhRjDn=print
YJrITwqevtVzaEHdmNSQWLPUKhRjDF=dict
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
YJrITwqevtVzaEHdmNSQWLPUKhRjMf=[{'title':'Live중계 (경기중에만 재생)','mode':'ELIVE_GROUP','icon':'live.png'},{'title':'-----------------','mode':'XXX'},{'title':'오늘의 추천 VOD','mode':'NOW_GROUP'},{'title':'인기영상 5','mode':'POP_GROUP'},{'title':'-----------------','mode':'XXX'},{'title':'VOD (리그, 경기별)','mode':'VOD_GROUP'},{'title':'Watched (시청목록)','mode':'WATCH','icon':'history.png'},]
YJrITwqevtVzaEHdmNSQWLPUKhRjMO=xbmcvfs.translatePath(os.path.join(__profile__,'spotv_cookies.json'))
from spotvCore import*
class YJrITwqevtVzaEHdmNSQWLPUKhRjMG(YJrITwqevtVzaEHdmNSQWLPUKhRjDs):
 def __init__(YJrITwqevtVzaEHdmNSQWLPUKhRjMD,YJrITwqevtVzaEHdmNSQWLPUKhRjMA,YJrITwqevtVzaEHdmNSQWLPUKhRjMg,YJrITwqevtVzaEHdmNSQWLPUKhRjMl):
  YJrITwqevtVzaEHdmNSQWLPUKhRjMD._addon_url =YJrITwqevtVzaEHdmNSQWLPUKhRjMA
  YJrITwqevtVzaEHdmNSQWLPUKhRjMD._addon_handle=YJrITwqevtVzaEHdmNSQWLPUKhRjMg
  YJrITwqevtVzaEHdmNSQWLPUKhRjMD.main_params =YJrITwqevtVzaEHdmNSQWLPUKhRjMl
  YJrITwqevtVzaEHdmNSQWLPUKhRjMD.SpotvObj =XnBoeHAbidaflSMtQYGsOvUumgcJDC() 
 def addon_noti(YJrITwqevtVzaEHdmNSQWLPUKhRjMD,sting):
  try:
   YJrITwqevtVzaEHdmNSQWLPUKhRjMp=xbmcgui.Dialog()
   YJrITwqevtVzaEHdmNSQWLPUKhRjMp.notification(__addonname__,sting)
  except:
   YJrITwqevtVzaEHdmNSQWLPUKhRjDi
 def addon_log(YJrITwqevtVzaEHdmNSQWLPUKhRjMD,string):
  try:
   YJrITwqevtVzaEHdmNSQWLPUKhRjMs=string.encode('utf-8','ignore')
  except:
   YJrITwqevtVzaEHdmNSQWLPUKhRjMs='addonException: addon_log'
  YJrITwqevtVzaEHdmNSQWLPUKhRjMi=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,YJrITwqevtVzaEHdmNSQWLPUKhRjMs),level=YJrITwqevtVzaEHdmNSQWLPUKhRjMi)
 def get_keyboard_input(YJrITwqevtVzaEHdmNSQWLPUKhRjMD,YJrITwqevtVzaEHdmNSQWLPUKhRjMn):
  YJrITwqevtVzaEHdmNSQWLPUKhRjMc=YJrITwqevtVzaEHdmNSQWLPUKhRjDi
  kb=xbmc.Keyboard()
  kb.setHeading(YJrITwqevtVzaEHdmNSQWLPUKhRjMn)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   YJrITwqevtVzaEHdmNSQWLPUKhRjMc=kb.getText()
  return YJrITwqevtVzaEHdmNSQWLPUKhRjMc
 def get_settings_login_info(YJrITwqevtVzaEHdmNSQWLPUKhRjMD):
  YJrITwqevtVzaEHdmNSQWLPUKhRjMx =__addon__.getSetting('id')
  YJrITwqevtVzaEHdmNSQWLPUKhRjMB =__addon__.getSetting('pw')
  return(YJrITwqevtVzaEHdmNSQWLPUKhRjMx,YJrITwqevtVzaEHdmNSQWLPUKhRjMB)
 def get_settings_hidescoreyn(YJrITwqevtVzaEHdmNSQWLPUKhRjMD):
  YJrITwqevtVzaEHdmNSQWLPUKhRjMb =__addon__.getSetting('hidescore')
  if YJrITwqevtVzaEHdmNSQWLPUKhRjMb=='false':
   return YJrITwqevtVzaEHdmNSQWLPUKhRjDc
  else:
   return YJrITwqevtVzaEHdmNSQWLPUKhRjDx
 def set_winCredential(YJrITwqevtVzaEHdmNSQWLPUKhRjMD,credential):
  YJrITwqevtVzaEHdmNSQWLPUKhRjMo=xbmcgui.Window(10000)
  YJrITwqevtVzaEHdmNSQWLPUKhRjMo.setProperty('SPOTV_M_SESSIONID',credential.get('spotv_sessionid'))
  YJrITwqevtVzaEHdmNSQWLPUKhRjMo.setProperty('SPOTV_M_SESSION',credential.get('spotv_session'))
  YJrITwqevtVzaEHdmNSQWLPUKhRjMo.setProperty('SPOTV_M_ACCOUNTID',credential.get('spotv_accountId'))
  YJrITwqevtVzaEHdmNSQWLPUKhRjMo.setProperty('SPOTV_M_POLICYKEY',credential.get('spotv_policyKey'))
  YJrITwqevtVzaEHdmNSQWLPUKhRjMo.setProperty('SPOTV_M_SUBEND',credential.get('spotv_subend'))
  YJrITwqevtVzaEHdmNSQWLPUKhRjMo.setProperty('SPOTV_M_LOGINTIME',YJrITwqevtVzaEHdmNSQWLPUKhRjMD.SpotvObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(YJrITwqevtVzaEHdmNSQWLPUKhRjMD):
  YJrITwqevtVzaEHdmNSQWLPUKhRjMo=xbmcgui.Window(10000)
  YJrITwqevtVzaEHdmNSQWLPUKhRjMC={'spotv_sessionid':YJrITwqevtVzaEHdmNSQWLPUKhRjMo.getProperty('SPOTV_M_SESSIONID'),'spotv_session':YJrITwqevtVzaEHdmNSQWLPUKhRjMo.getProperty('SPOTV_M_SESSION'),'spotv_accountId':YJrITwqevtVzaEHdmNSQWLPUKhRjMo.getProperty('SPOTV_M_ACCOUNTID'),'spotv_policyKey':YJrITwqevtVzaEHdmNSQWLPUKhRjMo.getProperty('SPOTV_M_POLICYKEY'),'spotv_subend':YJrITwqevtVzaEHdmNSQWLPUKhRjMo.getProperty('SPOTV_M_SUBEND')}
  return YJrITwqevtVzaEHdmNSQWLPUKhRjMC
 def add_dir(YJrITwqevtVzaEHdmNSQWLPUKhRjMD,label,sublabel='',img='',infoLabels=YJrITwqevtVzaEHdmNSQWLPUKhRjDi,isFolder=YJrITwqevtVzaEHdmNSQWLPUKhRjDx,params='',isLink=YJrITwqevtVzaEHdmNSQWLPUKhRjDc,ContextMenu=YJrITwqevtVzaEHdmNSQWLPUKhRjDi):
  YJrITwqevtVzaEHdmNSQWLPUKhRjMX='%s?%s'%(YJrITwqevtVzaEHdmNSQWLPUKhRjMD._addon_url,urllib.parse.urlencode(params))
  if sublabel:YJrITwqevtVzaEHdmNSQWLPUKhRjMn='%s < %s >'%(label,sublabel)
  else: YJrITwqevtVzaEHdmNSQWLPUKhRjMn=label
  if not img:img='DefaultFolder.png'
  YJrITwqevtVzaEHdmNSQWLPUKhRjMF=xbmcgui.ListItem(YJrITwqevtVzaEHdmNSQWLPUKhRjMn)
  YJrITwqevtVzaEHdmNSQWLPUKhRjMF.setArt({'thumb':img,'icon':img,'poster':img})
  if infoLabels:YJrITwqevtVzaEHdmNSQWLPUKhRjMF.setInfo(type="Video",infoLabels=infoLabels)
  if not isFolder and not isLink:
   YJrITwqevtVzaEHdmNSQWLPUKhRjMF.setProperty('IsPlayable','true')
  if ContextMenu:YJrITwqevtVzaEHdmNSQWLPUKhRjMF.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(YJrITwqevtVzaEHdmNSQWLPUKhRjMD._addon_handle,YJrITwqevtVzaEHdmNSQWLPUKhRjMX,YJrITwqevtVzaEHdmNSQWLPUKhRjMF,isFolder)
 def get_selQuality(YJrITwqevtVzaEHdmNSQWLPUKhRjMD,etype):
  try:
   YJrITwqevtVzaEHdmNSQWLPUKhRjMk='selected_quality'
   YJrITwqevtVzaEHdmNSQWLPUKhRjMu=[1080,720,540]
   YJrITwqevtVzaEHdmNSQWLPUKhRjGM=YJrITwqevtVzaEHdmNSQWLPUKhRjDB(__addon__.getSetting(YJrITwqevtVzaEHdmNSQWLPUKhRjMk))
   return YJrITwqevtVzaEHdmNSQWLPUKhRjMu[YJrITwqevtVzaEHdmNSQWLPUKhRjGM]
  except:
   YJrITwqevtVzaEHdmNSQWLPUKhRjDi
  return 1080 
 def dp_Main_List(YJrITwqevtVzaEHdmNSQWLPUKhRjMD):
  for YJrITwqevtVzaEHdmNSQWLPUKhRjGf in YJrITwqevtVzaEHdmNSQWLPUKhRjMf:
   YJrITwqevtVzaEHdmNSQWLPUKhRjMn=YJrITwqevtVzaEHdmNSQWLPUKhRjGf.get('title')
   YJrITwqevtVzaEHdmNSQWLPUKhRjGO=''
   YJrITwqevtVzaEHdmNSQWLPUKhRjGD={'mode':YJrITwqevtVzaEHdmNSQWLPUKhRjGf.get('mode'),'page':'1'}
   if YJrITwqevtVzaEHdmNSQWLPUKhRjGf.get('mode')=='XXX':
    YJrITwqevtVzaEHdmNSQWLPUKhRjGA=YJrITwqevtVzaEHdmNSQWLPUKhRjDc
    YJrITwqevtVzaEHdmNSQWLPUKhRjGg =YJrITwqevtVzaEHdmNSQWLPUKhRjDx
   else:
    YJrITwqevtVzaEHdmNSQWLPUKhRjGA=YJrITwqevtVzaEHdmNSQWLPUKhRjDx
    YJrITwqevtVzaEHdmNSQWLPUKhRjGg =YJrITwqevtVzaEHdmNSQWLPUKhRjDc
   if 'icon' in YJrITwqevtVzaEHdmNSQWLPUKhRjGf:YJrITwqevtVzaEHdmNSQWLPUKhRjGO=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',YJrITwqevtVzaEHdmNSQWLPUKhRjGf.get('icon')) 
   YJrITwqevtVzaEHdmNSQWLPUKhRjMD.add_dir(YJrITwqevtVzaEHdmNSQWLPUKhRjMn,sublabel='',img=YJrITwqevtVzaEHdmNSQWLPUKhRjGO,infoLabels=YJrITwqevtVzaEHdmNSQWLPUKhRjDi,isFolder=YJrITwqevtVzaEHdmNSQWLPUKhRjGA,params=YJrITwqevtVzaEHdmNSQWLPUKhRjGD,isLink=YJrITwqevtVzaEHdmNSQWLPUKhRjGg)
  if YJrITwqevtVzaEHdmNSQWLPUKhRjDb(YJrITwqevtVzaEHdmNSQWLPUKhRjMf)>0:xbmcplugin.endOfDirectory(YJrITwqevtVzaEHdmNSQWLPUKhRjMD._addon_handle)
 def dp_MainLeague_List(YJrITwqevtVzaEHdmNSQWLPUKhRjMD,args):
  YJrITwqevtVzaEHdmNSQWLPUKhRjMD.SpotvObj.SaveCredential(YJrITwqevtVzaEHdmNSQWLPUKhRjMD.get_winCredential())
  YJrITwqevtVzaEHdmNSQWLPUKhRjGy=YJrITwqevtVzaEHdmNSQWLPUKhRjMD.SpotvObj.GetTitleGroupList()
  for YJrITwqevtVzaEHdmNSQWLPUKhRjGp in YJrITwqevtVzaEHdmNSQWLPUKhRjGy:
   YJrITwqevtVzaEHdmNSQWLPUKhRjMn =YJrITwqevtVzaEHdmNSQWLPUKhRjGp.get('title')
   YJrITwqevtVzaEHdmNSQWLPUKhRjGs =YJrITwqevtVzaEHdmNSQWLPUKhRjGp.get('logo')
   YJrITwqevtVzaEHdmNSQWLPUKhRjGi =YJrITwqevtVzaEHdmNSQWLPUKhRjGp.get('reagueId')
   YJrITwqevtVzaEHdmNSQWLPUKhRjGc =YJrITwqevtVzaEHdmNSQWLPUKhRjGp.get('subGame')
   YJrITwqevtVzaEHdmNSQWLPUKhRjGx={'mediatype':'episode','plot':'%s\n\n%s'%(YJrITwqevtVzaEHdmNSQWLPUKhRjMn,YJrITwqevtVzaEHdmNSQWLPUKhRjGc)}
   YJrITwqevtVzaEHdmNSQWLPUKhRjGD={'mode':'LEAGUE_GROUP','reagueId':YJrITwqevtVzaEHdmNSQWLPUKhRjGi}
   YJrITwqevtVzaEHdmNSQWLPUKhRjMD.add_dir(YJrITwqevtVzaEHdmNSQWLPUKhRjMn,sublabel=YJrITwqevtVzaEHdmNSQWLPUKhRjDi,img=YJrITwqevtVzaEHdmNSQWLPUKhRjGs,infoLabels=YJrITwqevtVzaEHdmNSQWLPUKhRjGx,isFolder=YJrITwqevtVzaEHdmNSQWLPUKhRjDx,params=YJrITwqevtVzaEHdmNSQWLPUKhRjGD)
  if YJrITwqevtVzaEHdmNSQWLPUKhRjDb(YJrITwqevtVzaEHdmNSQWLPUKhRjGy)>0:xbmcplugin.endOfDirectory(YJrITwqevtVzaEHdmNSQWLPUKhRjMD._addon_handle,cacheToDisc=YJrITwqevtVzaEHdmNSQWLPUKhRjDc)
 def dp_NowVod_GroupList(YJrITwqevtVzaEHdmNSQWLPUKhRjMD,args):
  YJrITwqevtVzaEHdmNSQWLPUKhRjMD.SpotvObj.SaveCredential(YJrITwqevtVzaEHdmNSQWLPUKhRjMD.get_winCredential())
  YJrITwqevtVzaEHdmNSQWLPUKhRjGB=YJrITwqevtVzaEHdmNSQWLPUKhRjDB(args.get('page'))
  YJrITwqevtVzaEHdmNSQWLPUKhRjGy,YJrITwqevtVzaEHdmNSQWLPUKhRjGb=YJrITwqevtVzaEHdmNSQWLPUKhRjMD.SpotvObj.Get_NowVod_GroupList(YJrITwqevtVzaEHdmNSQWLPUKhRjGB)
  for YJrITwqevtVzaEHdmNSQWLPUKhRjGp in YJrITwqevtVzaEHdmNSQWLPUKhRjGy:
   YJrITwqevtVzaEHdmNSQWLPUKhRjGo =YJrITwqevtVzaEHdmNSQWLPUKhRjGp.get('vodTitle')
   YJrITwqevtVzaEHdmNSQWLPUKhRjGC =YJrITwqevtVzaEHdmNSQWLPUKhRjGp.get('vodId')
   YJrITwqevtVzaEHdmNSQWLPUKhRjGX =YJrITwqevtVzaEHdmNSQWLPUKhRjGp.get('vodType')
   YJrITwqevtVzaEHdmNSQWLPUKhRjGs=YJrITwqevtVzaEHdmNSQWLPUKhRjGp.get('thumbnail')
   YJrITwqevtVzaEHdmNSQWLPUKhRjGn =YJrITwqevtVzaEHdmNSQWLPUKhRjGp.get('vtypeId')
   YJrITwqevtVzaEHdmNSQWLPUKhRjGF =YJrITwqevtVzaEHdmNSQWLPUKhRjGp.get('duration')
   YJrITwqevtVzaEHdmNSQWLPUKhRjGx={'mediatype':'video','duration':YJrITwqevtVzaEHdmNSQWLPUKhRjGF,'plot':YJrITwqevtVzaEHdmNSQWLPUKhRjGo}
   YJrITwqevtVzaEHdmNSQWLPUKhRjGD={'mode':'NOW_VOD','mediacode':YJrITwqevtVzaEHdmNSQWLPUKhRjGC,'mediatype':'vod','vtypeId':YJrITwqevtVzaEHdmNSQWLPUKhRjGn}
   YJrITwqevtVzaEHdmNSQWLPUKhRjMD.add_dir(YJrITwqevtVzaEHdmNSQWLPUKhRjGo,sublabel=YJrITwqevtVzaEHdmNSQWLPUKhRjGX,img=YJrITwqevtVzaEHdmNSQWLPUKhRjGs,infoLabels=YJrITwqevtVzaEHdmNSQWLPUKhRjGx,isFolder=YJrITwqevtVzaEHdmNSQWLPUKhRjDc,params=YJrITwqevtVzaEHdmNSQWLPUKhRjGD)
  if YJrITwqevtVzaEHdmNSQWLPUKhRjGb:
   YJrITwqevtVzaEHdmNSQWLPUKhRjGD['mode'] ='NOW_GROUP' 
   YJrITwqevtVzaEHdmNSQWLPUKhRjGD['page'] =YJrITwqevtVzaEHdmNSQWLPUKhRjDo(YJrITwqevtVzaEHdmNSQWLPUKhRjGB+1)
   YJrITwqevtVzaEHdmNSQWLPUKhRjMn='[B]%s >>[/B]'%'다음 페이지'
   YJrITwqevtVzaEHdmNSQWLPUKhRjGk=YJrITwqevtVzaEHdmNSQWLPUKhRjDo(YJrITwqevtVzaEHdmNSQWLPUKhRjGB+1)
   YJrITwqevtVzaEHdmNSQWLPUKhRjGO=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   YJrITwqevtVzaEHdmNSQWLPUKhRjMD.add_dir(YJrITwqevtVzaEHdmNSQWLPUKhRjMn,sublabel=YJrITwqevtVzaEHdmNSQWLPUKhRjGk,img=YJrITwqevtVzaEHdmNSQWLPUKhRjGO,infoLabels=YJrITwqevtVzaEHdmNSQWLPUKhRjDi,isFolder=YJrITwqevtVzaEHdmNSQWLPUKhRjDx,params=YJrITwqevtVzaEHdmNSQWLPUKhRjGD)
  if YJrITwqevtVzaEHdmNSQWLPUKhRjDb(YJrITwqevtVzaEHdmNSQWLPUKhRjGy)>0:xbmcplugin.endOfDirectory(YJrITwqevtVzaEHdmNSQWLPUKhRjMD._addon_handle,cacheToDisc=YJrITwqevtVzaEHdmNSQWLPUKhRjDc)
 def dp_PopVod_GroupList(YJrITwqevtVzaEHdmNSQWLPUKhRjMD,args):
  YJrITwqevtVzaEHdmNSQWLPUKhRjMD.SpotvObj.SaveCredential(YJrITwqevtVzaEHdmNSQWLPUKhRjMD.get_winCredential())
  YJrITwqevtVzaEHdmNSQWLPUKhRjGy=YJrITwqevtVzaEHdmNSQWLPUKhRjMD.SpotvObj.GetPopularGroupList()
  for YJrITwqevtVzaEHdmNSQWLPUKhRjGp in YJrITwqevtVzaEHdmNSQWLPUKhRjGy:
   YJrITwqevtVzaEHdmNSQWLPUKhRjGo =YJrITwqevtVzaEHdmNSQWLPUKhRjGp.get('vodTitle')
   YJrITwqevtVzaEHdmNSQWLPUKhRjGC =YJrITwqevtVzaEHdmNSQWLPUKhRjGp.get('vodId')
   YJrITwqevtVzaEHdmNSQWLPUKhRjGX =YJrITwqevtVzaEHdmNSQWLPUKhRjGp.get('vodType')
   YJrITwqevtVzaEHdmNSQWLPUKhRjGs=YJrITwqevtVzaEHdmNSQWLPUKhRjGp.get('thumbnail')
   YJrITwqevtVzaEHdmNSQWLPUKhRjGn =YJrITwqevtVzaEHdmNSQWLPUKhRjGp.get('vtypeId')
   YJrITwqevtVzaEHdmNSQWLPUKhRjGF =YJrITwqevtVzaEHdmNSQWLPUKhRjGp.get('duration')
   YJrITwqevtVzaEHdmNSQWLPUKhRjGx={'mediatype':'video','duration':YJrITwqevtVzaEHdmNSQWLPUKhRjGF,'plot':YJrITwqevtVzaEHdmNSQWLPUKhRjGo}
   YJrITwqevtVzaEHdmNSQWLPUKhRjGD={'mode':'POP_VOD','mediacode':YJrITwqevtVzaEHdmNSQWLPUKhRjGC,'mediatype':'vod','vtypeId':YJrITwqevtVzaEHdmNSQWLPUKhRjGn}
   YJrITwqevtVzaEHdmNSQWLPUKhRjMD.add_dir(YJrITwqevtVzaEHdmNSQWLPUKhRjGo,sublabel=YJrITwqevtVzaEHdmNSQWLPUKhRjGX,img=YJrITwqevtVzaEHdmNSQWLPUKhRjGs,infoLabels=YJrITwqevtVzaEHdmNSQWLPUKhRjGx,isFolder=YJrITwqevtVzaEHdmNSQWLPUKhRjDc,params=YJrITwqevtVzaEHdmNSQWLPUKhRjGD)
  if YJrITwqevtVzaEHdmNSQWLPUKhRjDb(YJrITwqevtVzaEHdmNSQWLPUKhRjGy)>0:xbmcplugin.endOfDirectory(YJrITwqevtVzaEHdmNSQWLPUKhRjMD._addon_handle,cacheToDisc=YJrITwqevtVzaEHdmNSQWLPUKhRjDc)
 def dp_Season_List(YJrITwqevtVzaEHdmNSQWLPUKhRjMD,args):
  YJrITwqevtVzaEHdmNSQWLPUKhRjMD.SpotvObj.SaveCredential(YJrITwqevtVzaEHdmNSQWLPUKhRjMD.get_winCredential())
  YJrITwqevtVzaEHdmNSQWLPUKhRjGi=args.get('reagueId')
  YJrITwqevtVzaEHdmNSQWLPUKhRjGy=YJrITwqevtVzaEHdmNSQWLPUKhRjMD.SpotvObj.GetSeasonList(YJrITwqevtVzaEHdmNSQWLPUKhRjGi)
  for YJrITwqevtVzaEHdmNSQWLPUKhRjGp in YJrITwqevtVzaEHdmNSQWLPUKhRjGy:
   YJrITwqevtVzaEHdmNSQWLPUKhRjGu =YJrITwqevtVzaEHdmNSQWLPUKhRjGp.get('reagueName')
   YJrITwqevtVzaEHdmNSQWLPUKhRjfM =YJrITwqevtVzaEHdmNSQWLPUKhRjGp.get('gameTypeId')
   YJrITwqevtVzaEHdmNSQWLPUKhRjfG =YJrITwqevtVzaEHdmNSQWLPUKhRjGp.get('seasonName')
   YJrITwqevtVzaEHdmNSQWLPUKhRjfO =YJrITwqevtVzaEHdmNSQWLPUKhRjGp.get('seasonId')
   YJrITwqevtVzaEHdmNSQWLPUKhRjGx={'mediatype':'episode','plot':'%s - %s'%(YJrITwqevtVzaEHdmNSQWLPUKhRjGu,YJrITwqevtVzaEHdmNSQWLPUKhRjfG)}
   YJrITwqevtVzaEHdmNSQWLPUKhRjGD={'mode':'SEASON_GROUP','reagueId':YJrITwqevtVzaEHdmNSQWLPUKhRjGi,'seasonId':YJrITwqevtVzaEHdmNSQWLPUKhRjfO,'gameTypeId':YJrITwqevtVzaEHdmNSQWLPUKhRjfM,'page':'1'}
   YJrITwqevtVzaEHdmNSQWLPUKhRjMD.add_dir(YJrITwqevtVzaEHdmNSQWLPUKhRjGu,sublabel=YJrITwqevtVzaEHdmNSQWLPUKhRjfG,img='',infoLabels=YJrITwqevtVzaEHdmNSQWLPUKhRjGx,isFolder=YJrITwqevtVzaEHdmNSQWLPUKhRjDx,params=YJrITwqevtVzaEHdmNSQWLPUKhRjGD)
  if YJrITwqevtVzaEHdmNSQWLPUKhRjDb(YJrITwqevtVzaEHdmNSQWLPUKhRjGy)>0:xbmcplugin.endOfDirectory(YJrITwqevtVzaEHdmNSQWLPUKhRjMD._addon_handle,cacheToDisc=YJrITwqevtVzaEHdmNSQWLPUKhRjDx)
 def dp_Game_List(YJrITwqevtVzaEHdmNSQWLPUKhRjMD,args):
  YJrITwqevtVzaEHdmNSQWLPUKhRjMD.SpotvObj.SaveCredential(YJrITwqevtVzaEHdmNSQWLPUKhRjMD.get_winCredential())
  YJrITwqevtVzaEHdmNSQWLPUKhRjfM=args.get('gameTypeId')
  YJrITwqevtVzaEHdmNSQWLPUKhRjGi =args.get('reagueId')
  YJrITwqevtVzaEHdmNSQWLPUKhRjfO =args.get('seasonId')
  YJrITwqevtVzaEHdmNSQWLPUKhRjGB =YJrITwqevtVzaEHdmNSQWLPUKhRjDB(args.get('page'))
  YJrITwqevtVzaEHdmNSQWLPUKhRjGy,YJrITwqevtVzaEHdmNSQWLPUKhRjGb=YJrITwqevtVzaEHdmNSQWLPUKhRjMD.SpotvObj.GetGameList(YJrITwqevtVzaEHdmNSQWLPUKhRjfM,YJrITwqevtVzaEHdmNSQWLPUKhRjGi,YJrITwqevtVzaEHdmNSQWLPUKhRjfO,YJrITwqevtVzaEHdmNSQWLPUKhRjGB,hidescore=YJrITwqevtVzaEHdmNSQWLPUKhRjMD.get_settings_hidescoreyn())
  for YJrITwqevtVzaEHdmNSQWLPUKhRjGp in YJrITwqevtVzaEHdmNSQWLPUKhRjGy:
   YJrITwqevtVzaEHdmNSQWLPUKhRjfD =YJrITwqevtVzaEHdmNSQWLPUKhRjGp.get('gameTitle')
   YJrITwqevtVzaEHdmNSQWLPUKhRjfA =YJrITwqevtVzaEHdmNSQWLPUKhRjGp.get('beginDate')
   YJrITwqevtVzaEHdmNSQWLPUKhRjGs =YJrITwqevtVzaEHdmNSQWLPUKhRjGp.get('thumbnail')
   YJrITwqevtVzaEHdmNSQWLPUKhRjfg =YJrITwqevtVzaEHdmNSQWLPUKhRjGp.get('gameId')
   YJrITwqevtVzaEHdmNSQWLPUKhRjfl =YJrITwqevtVzaEHdmNSQWLPUKhRjGp.get('totVodCnt')
   YJrITwqevtVzaEHdmNSQWLPUKhRjfy =YJrITwqevtVzaEHdmNSQWLPUKhRjGp.get('leaguenm')
   YJrITwqevtVzaEHdmNSQWLPUKhRjfp =YJrITwqevtVzaEHdmNSQWLPUKhRjGp.get('seasonnm')
   YJrITwqevtVzaEHdmNSQWLPUKhRjfs =YJrITwqevtVzaEHdmNSQWLPUKhRjGp.get('roundnm')
   YJrITwqevtVzaEHdmNSQWLPUKhRjfi =YJrITwqevtVzaEHdmNSQWLPUKhRjGp.get('info_plot')
   YJrITwqevtVzaEHdmNSQWLPUKhRjfc ='%s < %s >'%(YJrITwqevtVzaEHdmNSQWLPUKhRjfD,YJrITwqevtVzaEHdmNSQWLPUKhRjfA)
   YJrITwqevtVzaEHdmNSQWLPUKhRjGx={'mediatype':'video','plot':YJrITwqevtVzaEHdmNSQWLPUKhRjfi}
   YJrITwqevtVzaEHdmNSQWLPUKhRjGD={'mode':'GAME_VOD_GROUP' if YJrITwqevtVzaEHdmNSQWLPUKhRjfl!=0 else 'XXX','saveTitle':YJrITwqevtVzaEHdmNSQWLPUKhRjfc,'saveImg':YJrITwqevtVzaEHdmNSQWLPUKhRjGs,'saveInfo':YJrITwqevtVzaEHdmNSQWLPUKhRjGx['plot'],'gameid':YJrITwqevtVzaEHdmNSQWLPUKhRjfg}
   YJrITwqevtVzaEHdmNSQWLPUKhRjMD.add_dir(YJrITwqevtVzaEHdmNSQWLPUKhRjfD,sublabel=YJrITwqevtVzaEHdmNSQWLPUKhRjfA,img=YJrITwqevtVzaEHdmNSQWLPUKhRjGs,infoLabels=YJrITwqevtVzaEHdmNSQWLPUKhRjGx,isFolder=YJrITwqevtVzaEHdmNSQWLPUKhRjDx,params=YJrITwqevtVzaEHdmNSQWLPUKhRjGD)
  if YJrITwqevtVzaEHdmNSQWLPUKhRjGb:
   YJrITwqevtVzaEHdmNSQWLPUKhRjGD['mode'] ='SEASON_GROUP' 
   YJrITwqevtVzaEHdmNSQWLPUKhRjGD['reagueId'] =YJrITwqevtVzaEHdmNSQWLPUKhRjGi
   YJrITwqevtVzaEHdmNSQWLPUKhRjGD['seasonId'] =YJrITwqevtVzaEHdmNSQWLPUKhRjfO
   YJrITwqevtVzaEHdmNSQWLPUKhRjGD['gameTypeId']=YJrITwqevtVzaEHdmNSQWLPUKhRjfM
   YJrITwqevtVzaEHdmNSQWLPUKhRjGD['page'] =YJrITwqevtVzaEHdmNSQWLPUKhRjDo(YJrITwqevtVzaEHdmNSQWLPUKhRjGB+1)
   YJrITwqevtVzaEHdmNSQWLPUKhRjMn='[B]%s >>[/B]'%'다음 페이지'
   YJrITwqevtVzaEHdmNSQWLPUKhRjGk=YJrITwqevtVzaEHdmNSQWLPUKhRjDo(YJrITwqevtVzaEHdmNSQWLPUKhRjGB+1)
   YJrITwqevtVzaEHdmNSQWLPUKhRjGO=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   YJrITwqevtVzaEHdmNSQWLPUKhRjMD.add_dir(YJrITwqevtVzaEHdmNSQWLPUKhRjMn,sublabel=YJrITwqevtVzaEHdmNSQWLPUKhRjGk,img=YJrITwqevtVzaEHdmNSQWLPUKhRjGO,infoLabels=YJrITwqevtVzaEHdmNSQWLPUKhRjDi,isFolder=YJrITwqevtVzaEHdmNSQWLPUKhRjDx,params=YJrITwqevtVzaEHdmNSQWLPUKhRjGD)
  if YJrITwqevtVzaEHdmNSQWLPUKhRjDb(YJrITwqevtVzaEHdmNSQWLPUKhRjGy)>0:xbmcplugin.endOfDirectory(YJrITwqevtVzaEHdmNSQWLPUKhRjMD._addon_handle,cacheToDisc=YJrITwqevtVzaEHdmNSQWLPUKhRjDc)
 def dp_GameVod_List(YJrITwqevtVzaEHdmNSQWLPUKhRjMD,args):
  YJrITwqevtVzaEHdmNSQWLPUKhRjMD.SpotvObj.SaveCredential(YJrITwqevtVzaEHdmNSQWLPUKhRjMD.get_winCredential())
  YJrITwqevtVzaEHdmNSQWLPUKhRjfx =args.get('gameid')
  YJrITwqevtVzaEHdmNSQWLPUKhRjfc=args.get('saveTitle')
  YJrITwqevtVzaEHdmNSQWLPUKhRjfB =args.get('saveImg')
  YJrITwqevtVzaEHdmNSQWLPUKhRjfb =args.get('saveInfo')
  YJrITwqevtVzaEHdmNSQWLPUKhRjGy=YJrITwqevtVzaEHdmNSQWLPUKhRjMD.SpotvObj.GetGameVodList(YJrITwqevtVzaEHdmNSQWLPUKhRjfx)
  for YJrITwqevtVzaEHdmNSQWLPUKhRjGp in YJrITwqevtVzaEHdmNSQWLPUKhRjGy:
   YJrITwqevtVzaEHdmNSQWLPUKhRjGo =YJrITwqevtVzaEHdmNSQWLPUKhRjGp.get('vodTitle')
   YJrITwqevtVzaEHdmNSQWLPUKhRjGC =YJrITwqevtVzaEHdmNSQWLPUKhRjGp.get('vodId')
   YJrITwqevtVzaEHdmNSQWLPUKhRjGX =YJrITwqevtVzaEHdmNSQWLPUKhRjGp.get('vodType')
   YJrITwqevtVzaEHdmNSQWLPUKhRjGs=YJrITwqevtVzaEHdmNSQWLPUKhRjGp.get('thumbnail')
   YJrITwqevtVzaEHdmNSQWLPUKhRjGn =YJrITwqevtVzaEHdmNSQWLPUKhRjGp.get('vtypeId')
   YJrITwqevtVzaEHdmNSQWLPUKhRjGF =YJrITwqevtVzaEHdmNSQWLPUKhRjGp.get('duration')
   YJrITwqevtVzaEHdmNSQWLPUKhRjGx={'mediatype':'video','duration':YJrITwqevtVzaEHdmNSQWLPUKhRjGF,'plot':'%s \n\n %s'%(YJrITwqevtVzaEHdmNSQWLPUKhRjGo,YJrITwqevtVzaEHdmNSQWLPUKhRjfb)}
   YJrITwqevtVzaEHdmNSQWLPUKhRjGD={'mode':'GAME_VOD','saveTitle':YJrITwqevtVzaEHdmNSQWLPUKhRjfc,'saveImg':YJrITwqevtVzaEHdmNSQWLPUKhRjfB,'saveId':YJrITwqevtVzaEHdmNSQWLPUKhRjfx,'saveInfo':YJrITwqevtVzaEHdmNSQWLPUKhRjfb,'mediacode':YJrITwqevtVzaEHdmNSQWLPUKhRjGC,'mediatype':'vod','vtypeId':YJrITwqevtVzaEHdmNSQWLPUKhRjGn}
   YJrITwqevtVzaEHdmNSQWLPUKhRjMD.add_dir(YJrITwqevtVzaEHdmNSQWLPUKhRjGo,sublabel=YJrITwqevtVzaEHdmNSQWLPUKhRjGX,img=YJrITwqevtVzaEHdmNSQWLPUKhRjGs,infoLabels=YJrITwqevtVzaEHdmNSQWLPUKhRjGx,isFolder=YJrITwqevtVzaEHdmNSQWLPUKhRjDc,params=YJrITwqevtVzaEHdmNSQWLPUKhRjGD)
  if YJrITwqevtVzaEHdmNSQWLPUKhRjDb(YJrITwqevtVzaEHdmNSQWLPUKhRjGy)>0:xbmcplugin.endOfDirectory(YJrITwqevtVzaEHdmNSQWLPUKhRjMD._addon_handle,cacheToDisc=YJrITwqevtVzaEHdmNSQWLPUKhRjDc)
 def login_main(YJrITwqevtVzaEHdmNSQWLPUKhRjMD):
  (YJrITwqevtVzaEHdmNSQWLPUKhRjfo,YJrITwqevtVzaEHdmNSQWLPUKhRjfC)=YJrITwqevtVzaEHdmNSQWLPUKhRjMD.get_settings_login_info()
  if not(YJrITwqevtVzaEHdmNSQWLPUKhRjfo and YJrITwqevtVzaEHdmNSQWLPUKhRjfC):
   YJrITwqevtVzaEHdmNSQWLPUKhRjMp=xbmcgui.Dialog()
   YJrITwqevtVzaEHdmNSQWLPUKhRjfX=YJrITwqevtVzaEHdmNSQWLPUKhRjMp.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if YJrITwqevtVzaEHdmNSQWLPUKhRjfX==YJrITwqevtVzaEHdmNSQWLPUKhRjDx:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if YJrITwqevtVzaEHdmNSQWLPUKhRjMD.cookiefile_check():return
  YJrITwqevtVzaEHdmNSQWLPUKhRjfn =YJrITwqevtVzaEHdmNSQWLPUKhRjDB(YJrITwqevtVzaEHdmNSQWLPUKhRjMD.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))
  YJrITwqevtVzaEHdmNSQWLPUKhRjfF=xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINTIME')
  if YJrITwqevtVzaEHdmNSQWLPUKhRjfF==YJrITwqevtVzaEHdmNSQWLPUKhRjDi or YJrITwqevtVzaEHdmNSQWLPUKhRjfF=='':
   YJrITwqevtVzaEHdmNSQWLPUKhRjfF=YJrITwqevtVzaEHdmNSQWLPUKhRjDB('19000101')
  else:
   YJrITwqevtVzaEHdmNSQWLPUKhRjfF=YJrITwqevtVzaEHdmNSQWLPUKhRjDB(re.sub('-','',YJrITwqevtVzaEHdmNSQWLPUKhRjfF))
  if xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINWAIT')=='TRUE':
   YJrITwqevtVzaEHdmNSQWLPUKhRjfk=0
   while YJrITwqevtVzaEHdmNSQWLPUKhRjDx:
    YJrITwqevtVzaEHdmNSQWLPUKhRjfk+=1
    time.sleep(0.05)
    if YJrITwqevtVzaEHdmNSQWLPUKhRjfF>=YJrITwqevtVzaEHdmNSQWLPUKhRjfn:return
    if YJrITwqevtVzaEHdmNSQWLPUKhRjfk>600:return
  else:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','TRUE')
  if YJrITwqevtVzaEHdmNSQWLPUKhRjfF>=YJrITwqevtVzaEHdmNSQWLPUKhRjfn:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
   return
  if not YJrITwqevtVzaEHdmNSQWLPUKhRjMD.SpotvObj.GetCredential(YJrITwqevtVzaEHdmNSQWLPUKhRjfo,YJrITwqevtVzaEHdmNSQWLPUKhRjfC):
   YJrITwqevtVzaEHdmNSQWLPUKhRjMD.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
   sys.exit()
  YJrITwqevtVzaEHdmNSQWLPUKhRjMD.set_winCredential(YJrITwqevtVzaEHdmNSQWLPUKhRjMD.SpotvObj.LoadCredential())
  YJrITwqevtVzaEHdmNSQWLPUKhRjMD.cookiefile_save()
  xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
 def dp_LiveChannel_List(YJrITwqevtVzaEHdmNSQWLPUKhRjMD,args):
  YJrITwqevtVzaEHdmNSQWLPUKhRjMD.SpotvObj.SaveCredential(YJrITwqevtVzaEHdmNSQWLPUKhRjMD.get_winCredential())
  YJrITwqevtVzaEHdmNSQWLPUKhRjfu=YJrITwqevtVzaEHdmNSQWLPUKhRjMD.SpotvObj.GetLiveChannelList()
  for YJrITwqevtVzaEHdmNSQWLPUKhRjOM in YJrITwqevtVzaEHdmNSQWLPUKhRjfu:
   YJrITwqevtVzaEHdmNSQWLPUKhRjMn =YJrITwqevtVzaEHdmNSQWLPUKhRjOM.get('name')
   YJrITwqevtVzaEHdmNSQWLPUKhRjGs =YJrITwqevtVzaEHdmNSQWLPUKhRjOM.get('logo')
   YJrITwqevtVzaEHdmNSQWLPUKhRjOG=YJrITwqevtVzaEHdmNSQWLPUKhRjOM.get('channelepg')
   YJrITwqevtVzaEHdmNSQWLPUKhRjOf =YJrITwqevtVzaEHdmNSQWLPUKhRjOM.get('free')
   if YJrITwqevtVzaEHdmNSQWLPUKhRjOG:
    YJrITwqevtVzaEHdmNSQWLPUKhRjOD =YJrITwqevtVzaEHdmNSQWLPUKhRjOG['epg']
    YJrITwqevtVzaEHdmNSQWLPUKhRjOA=YJrITwqevtVzaEHdmNSQWLPUKhRjOG['title']
   else:
    YJrITwqevtVzaEHdmNSQWLPUKhRjOD =''
    YJrITwqevtVzaEHdmNSQWLPUKhRjOA=''
   YJrITwqevtVzaEHdmNSQWLPUKhRjGx={'plot':'%s\n\n%s'%(YJrITwqevtVzaEHdmNSQWLPUKhRjMn,YJrITwqevtVzaEHdmNSQWLPUKhRjOD),'mediatype':'video'}
   YJrITwqevtVzaEHdmNSQWLPUKhRjGD={'mode':'LIVE','mediacode':YJrITwqevtVzaEHdmNSQWLPUKhRjOM.get('videoId'),'free':YJrITwqevtVzaEHdmNSQWLPUKhRjOf,'mediatype':'live'}
   if YJrITwqevtVzaEHdmNSQWLPUKhRjOf:YJrITwqevtVzaEHdmNSQWLPUKhRjMn+=' [free]'
   YJrITwqevtVzaEHdmNSQWLPUKhRjMD.add_dir(YJrITwqevtVzaEHdmNSQWLPUKhRjMn,sublabel=YJrITwqevtVzaEHdmNSQWLPUKhRjOA,img=YJrITwqevtVzaEHdmNSQWLPUKhRjGs,infoLabels=YJrITwqevtVzaEHdmNSQWLPUKhRjGx,isFolder=YJrITwqevtVzaEHdmNSQWLPUKhRjDc,params=YJrITwqevtVzaEHdmNSQWLPUKhRjGD)
  if YJrITwqevtVzaEHdmNSQWLPUKhRjDb(YJrITwqevtVzaEHdmNSQWLPUKhRjfu)>0:xbmcplugin.endOfDirectory(YJrITwqevtVzaEHdmNSQWLPUKhRjMD._addon_handle,cacheToDisc=YJrITwqevtVzaEHdmNSQWLPUKhRjDc)
 def dp_EventLiveChannel_List(YJrITwqevtVzaEHdmNSQWLPUKhRjMD,args):
  YJrITwqevtVzaEHdmNSQWLPUKhRjMD.SpotvObj.SaveCredential(YJrITwqevtVzaEHdmNSQWLPUKhRjMD.get_winCredential())
  YJrITwqevtVzaEHdmNSQWLPUKhRjfu,YJrITwqevtVzaEHdmNSQWLPUKhRjOg=YJrITwqevtVzaEHdmNSQWLPUKhRjMD.SpotvObj.GetEventLiveList()
  if YJrITwqevtVzaEHdmNSQWLPUKhRjOg!=401 and YJrITwqevtVzaEHdmNSQWLPUKhRjDb(YJrITwqevtVzaEHdmNSQWLPUKhRjfu)==0:
   YJrITwqevtVzaEHdmNSQWLPUKhRjMD.addon_noti(__language__(30907).encode('utf8'))
  for YJrITwqevtVzaEHdmNSQWLPUKhRjOM in YJrITwqevtVzaEHdmNSQWLPUKhRjfu:
   YJrITwqevtVzaEHdmNSQWLPUKhRjMn =YJrITwqevtVzaEHdmNSQWLPUKhRjOM.get('title')
   YJrITwqevtVzaEHdmNSQWLPUKhRjGl =YJrITwqevtVzaEHdmNSQWLPUKhRjOM.get('startTime')
   YJrITwqevtVzaEHdmNSQWLPUKhRjGs =YJrITwqevtVzaEHdmNSQWLPUKhRjOM.get('logo')
   YJrITwqevtVzaEHdmNSQWLPUKhRjOf =YJrITwqevtVzaEHdmNSQWLPUKhRjOM.get('free')
   YJrITwqevtVzaEHdmNSQWLPUKhRjGx={'mediatype':'video','plot':'%s\n\n%s'%(YJrITwqevtVzaEHdmNSQWLPUKhRjMn,YJrITwqevtVzaEHdmNSQWLPUKhRjGl)}
   YJrITwqevtVzaEHdmNSQWLPUKhRjGD={'mode':'ELIVE','mediaid':YJrITwqevtVzaEHdmNSQWLPUKhRjOM.get('liveId'),'mediacode':'','free':YJrITwqevtVzaEHdmNSQWLPUKhRjOf,'mediatype':'live'}
   if YJrITwqevtVzaEHdmNSQWLPUKhRjOf:YJrITwqevtVzaEHdmNSQWLPUKhRjMn+=' [free]'
   YJrITwqevtVzaEHdmNSQWLPUKhRjMD.add_dir(YJrITwqevtVzaEHdmNSQWLPUKhRjMn,sublabel=YJrITwqevtVzaEHdmNSQWLPUKhRjGl,img=YJrITwqevtVzaEHdmNSQWLPUKhRjGs,infoLabels=YJrITwqevtVzaEHdmNSQWLPUKhRjGx,isFolder=YJrITwqevtVzaEHdmNSQWLPUKhRjDc,params=YJrITwqevtVzaEHdmNSQWLPUKhRjGD)
  if YJrITwqevtVzaEHdmNSQWLPUKhRjDb(YJrITwqevtVzaEHdmNSQWLPUKhRjfu)>0:xbmcplugin.endOfDirectory(YJrITwqevtVzaEHdmNSQWLPUKhRjMD._addon_handle,cacheToDisc=YJrITwqevtVzaEHdmNSQWLPUKhRjDx)
  return YJrITwqevtVzaEHdmNSQWLPUKhRjOg
 def play_VIDEO(YJrITwqevtVzaEHdmNSQWLPUKhRjMD,args):
  YJrITwqevtVzaEHdmNSQWLPUKhRjMD.SpotvObj.SaveCredential(YJrITwqevtVzaEHdmNSQWLPUKhRjMD.get_winCredential())
  YJrITwqevtVzaEHdmNSQWLPUKhRjOl =args.get('mode')
  YJrITwqevtVzaEHdmNSQWLPUKhRjOy =args.get('mediacode')
  YJrITwqevtVzaEHdmNSQWLPUKhRjOp =args.get('mediatype')
  YJrITwqevtVzaEHdmNSQWLPUKhRjGn =args.get('vtypeId')
  if YJrITwqevtVzaEHdmNSQWLPUKhRjOl=='LIVE':
   if args.get('free')=='False':
    if YJrITwqevtVzaEHdmNSQWLPUKhRjMD.SpotvObj.CheckSubEnd()==YJrITwqevtVzaEHdmNSQWLPUKhRjDc:
     YJrITwqevtVzaEHdmNSQWLPUKhRjMD.addon_noti(__language__(30908).encode('utf8'))
     return
  elif YJrITwqevtVzaEHdmNSQWLPUKhRjOl=='ELIVE':
   if args.get('free')=='False':
    if YJrITwqevtVzaEHdmNSQWLPUKhRjMD.SpotvObj.CheckSubEnd()==YJrITwqevtVzaEHdmNSQWLPUKhRjDc:
     YJrITwqevtVzaEHdmNSQWLPUKhRjMD.addon_noti(__language__(30908).encode('utf8'))
     return
   YJrITwqevtVzaEHdmNSQWLPUKhRjOy=YJrITwqevtVzaEHdmNSQWLPUKhRjMD.SpotvObj.GetEventLive_videoId(args.get('mediaid'))
  if YJrITwqevtVzaEHdmNSQWLPUKhRjOy=='' or YJrITwqevtVzaEHdmNSQWLPUKhRjOy==YJrITwqevtVzaEHdmNSQWLPUKhRjDi:
   YJrITwqevtVzaEHdmNSQWLPUKhRjMD.addon_noti(__language__(30907).encode('utf8'))
   return
  if YJrITwqevtVzaEHdmNSQWLPUKhRjOl=='LIVE':
   YJrITwqevtVzaEHdmNSQWLPUKhRjOs=YJrITwqevtVzaEHdmNSQWLPUKhRjMD.SpotvObj.Get_Streamurl_Make(args.get('mediacode'))
  else:
   YJrITwqevtVzaEHdmNSQWLPUKhRjOs=YJrITwqevtVzaEHdmNSQWLPUKhRjMD.SpotvObj.GetBroadURL(YJrITwqevtVzaEHdmNSQWLPUKhRjOy,YJrITwqevtVzaEHdmNSQWLPUKhRjOp,YJrITwqevtVzaEHdmNSQWLPUKhRjGn)
  if YJrITwqevtVzaEHdmNSQWLPUKhRjOs=='':
   YJrITwqevtVzaEHdmNSQWLPUKhRjMD.addon_noti(__language__(30908).encode('utf8'))
   return
  YJrITwqevtVzaEHdmNSQWLPUKhRjOi=YJrITwqevtVzaEHdmNSQWLPUKhRjOs
  YJrITwqevtVzaEHdmNSQWLPUKhRjMD.addon_log(YJrITwqevtVzaEHdmNSQWLPUKhRjOi)
  YJrITwqevtVzaEHdmNSQWLPUKhRjOc=xbmcgui.ListItem(path=YJrITwqevtVzaEHdmNSQWLPUKhRjOi)
  xbmcplugin.setResolvedUrl(YJrITwqevtVzaEHdmNSQWLPUKhRjMD._addon_handle,YJrITwqevtVzaEHdmNSQWLPUKhRjDx,YJrITwqevtVzaEHdmNSQWLPUKhRjOc)
  try:
   if YJrITwqevtVzaEHdmNSQWLPUKhRjOp=='vod' and YJrITwqevtVzaEHdmNSQWLPUKhRjOl not in['POP_VOD','NOW_VOD']:
    YJrITwqevtVzaEHdmNSQWLPUKhRjGD={'code':args.get('saveId'),'img':args.get('saveImg'),'title':args.get('saveTitle'),'info':args.get('saveInfo')}
    YJrITwqevtVzaEHdmNSQWLPUKhRjMD.Save_Watched_List(YJrITwqevtVzaEHdmNSQWLPUKhRjOp,YJrITwqevtVzaEHdmNSQWLPUKhRjGD)
  except:
   YJrITwqevtVzaEHdmNSQWLPUKhRjDi
 def logout(YJrITwqevtVzaEHdmNSQWLPUKhRjMD):
  YJrITwqevtVzaEHdmNSQWLPUKhRjMp=xbmcgui.Dialog()
  YJrITwqevtVzaEHdmNSQWLPUKhRjfX=YJrITwqevtVzaEHdmNSQWLPUKhRjMp.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if YJrITwqevtVzaEHdmNSQWLPUKhRjfX==YJrITwqevtVzaEHdmNSQWLPUKhRjDc:sys.exit()
  YJrITwqevtVzaEHdmNSQWLPUKhRjMD.wininfo_clear()
  if os.path.isfile(YJrITwqevtVzaEHdmNSQWLPUKhRjMO):os.remove(YJrITwqevtVzaEHdmNSQWLPUKhRjMO)
  YJrITwqevtVzaEHdmNSQWLPUKhRjMD.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(YJrITwqevtVzaEHdmNSQWLPUKhRjMD):
  YJrITwqevtVzaEHdmNSQWLPUKhRjMo=xbmcgui.Window(10000)
  YJrITwqevtVzaEHdmNSQWLPUKhRjMo.setProperty('SPOTV_M_SESSIONID','')
  YJrITwqevtVzaEHdmNSQWLPUKhRjMo.setProperty('SPOTV_M_SESSION','')
  YJrITwqevtVzaEHdmNSQWLPUKhRjMo.setProperty('SPOTV_M_ACCOUNTID','')
  YJrITwqevtVzaEHdmNSQWLPUKhRjMo.setProperty('SPOTV_M_POLICYKEY','')
  YJrITwqevtVzaEHdmNSQWLPUKhRjMo.setProperty('SPOTV_M_SUBEND','')
  YJrITwqevtVzaEHdmNSQWLPUKhRjMo.setProperty('SPOTV_M_LOGINTIME','')
 def cookiefile_save(YJrITwqevtVzaEHdmNSQWLPUKhRjMD):
  YJrITwqevtVzaEHdmNSQWLPUKhRjOx =YJrITwqevtVzaEHdmNSQWLPUKhRjMD.SpotvObj.Get_Now_Datetime()
  YJrITwqevtVzaEHdmNSQWLPUKhRjOB=YJrITwqevtVzaEHdmNSQWLPUKhRjOx+datetime.timedelta(days=YJrITwqevtVzaEHdmNSQWLPUKhRjDB(__addon__.getSetting('cache_ttl')))
  YJrITwqevtVzaEHdmNSQWLPUKhRjMo=xbmcgui.Window(10000)
  YJrITwqevtVzaEHdmNSQWLPUKhRjOb={'spotv_sessionid':YJrITwqevtVzaEHdmNSQWLPUKhRjMo.getProperty('SPOTV_M_SESSIONID'),'spotv_session':YJrITwqevtVzaEHdmNSQWLPUKhRjMo.getProperty('SPOTV_M_SESSION'),'spotv_accountId':YJrITwqevtVzaEHdmNSQWLPUKhRjMo.getProperty('SPOTV_M_ACCOUNTID'),'spotv_policyKey':base64.standard_b64encode(YJrITwqevtVzaEHdmNSQWLPUKhRjMo.getProperty('SPOTV_M_POLICYKEY').encode()).decode('utf-8'),'spotv_subend':base64.standard_b64encode((YJrITwqevtVzaEHdmNSQWLPUKhRjMD.SpotvObj.SPOTV_PMCODE+YJrITwqevtVzaEHdmNSQWLPUKhRjMo.getProperty('SPOTV_M_SUBEND')).encode()).decode('utf-8'),'spotv_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'spotv_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'spotv_limitdate':YJrITwqevtVzaEHdmNSQWLPUKhRjOB.strftime('%Y-%m-%d')}
  try: 
   fp=YJrITwqevtVzaEHdmNSQWLPUKhRjDC(YJrITwqevtVzaEHdmNSQWLPUKhRjMO,'w',-1,'utf-8')
   json.dump(YJrITwqevtVzaEHdmNSQWLPUKhRjOb,fp)
   fp.close()
  except YJrITwqevtVzaEHdmNSQWLPUKhRjDX as exception:
   YJrITwqevtVzaEHdmNSQWLPUKhRjDn(exception)
 def cookiefile_check(YJrITwqevtVzaEHdmNSQWLPUKhRjMD):
  YJrITwqevtVzaEHdmNSQWLPUKhRjOb={}
  try: 
   fp=YJrITwqevtVzaEHdmNSQWLPUKhRjDC(YJrITwqevtVzaEHdmNSQWLPUKhRjMO,'r',-1,'utf-8')
   YJrITwqevtVzaEHdmNSQWLPUKhRjOb= json.load(fp)
   fp.close()
  except YJrITwqevtVzaEHdmNSQWLPUKhRjDX as exception:
   YJrITwqevtVzaEHdmNSQWLPUKhRjMD.wininfo_clear()
   return YJrITwqevtVzaEHdmNSQWLPUKhRjDc
  YJrITwqevtVzaEHdmNSQWLPUKhRjfo =__addon__.getSetting('id')
  YJrITwqevtVzaEHdmNSQWLPUKhRjfC =__addon__.getSetting('pw')
  YJrITwqevtVzaEHdmNSQWLPUKhRjOb['spotv_id'] =base64.standard_b64decode(YJrITwqevtVzaEHdmNSQWLPUKhRjOb['spotv_id']).decode('utf-8')
  YJrITwqevtVzaEHdmNSQWLPUKhRjOb['spotv_pw'] =base64.standard_b64decode(YJrITwqevtVzaEHdmNSQWLPUKhRjOb['spotv_pw']).decode('utf-8')
  YJrITwqevtVzaEHdmNSQWLPUKhRjOb['spotv_policyKey']=base64.standard_b64decode(YJrITwqevtVzaEHdmNSQWLPUKhRjOb['spotv_policyKey']).decode('utf-8')
  YJrITwqevtVzaEHdmNSQWLPUKhRjOb['spotv_subend']=base64.standard_b64decode(YJrITwqevtVzaEHdmNSQWLPUKhRjOb['spotv_subend']).decode('utf-8')[YJrITwqevtVzaEHdmNSQWLPUKhRjMD.SpotvObj.SPOTV_PMSIZE:]
  if YJrITwqevtVzaEHdmNSQWLPUKhRjfo!=YJrITwqevtVzaEHdmNSQWLPUKhRjOb['spotv_id']or YJrITwqevtVzaEHdmNSQWLPUKhRjfC!=YJrITwqevtVzaEHdmNSQWLPUKhRjOb['spotv_pw']:
   YJrITwqevtVzaEHdmNSQWLPUKhRjMD.wininfo_clear()
   return YJrITwqevtVzaEHdmNSQWLPUKhRjDc
  YJrITwqevtVzaEHdmNSQWLPUKhRjfn =YJrITwqevtVzaEHdmNSQWLPUKhRjDB(YJrITwqevtVzaEHdmNSQWLPUKhRjMD.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))
  YJrITwqevtVzaEHdmNSQWLPUKhRjOo=YJrITwqevtVzaEHdmNSQWLPUKhRjOb['spotv_limitdate']
  YJrITwqevtVzaEHdmNSQWLPUKhRjfF =YJrITwqevtVzaEHdmNSQWLPUKhRjDB(re.sub('-','',YJrITwqevtVzaEHdmNSQWLPUKhRjOo))
  if YJrITwqevtVzaEHdmNSQWLPUKhRjfF<YJrITwqevtVzaEHdmNSQWLPUKhRjfn:
   YJrITwqevtVzaEHdmNSQWLPUKhRjMD.wininfo_clear()
   return YJrITwqevtVzaEHdmNSQWLPUKhRjDc
  YJrITwqevtVzaEHdmNSQWLPUKhRjMo=xbmcgui.Window(10000)
  YJrITwqevtVzaEHdmNSQWLPUKhRjMo.setProperty('SPOTV_M_SESSIONID',YJrITwqevtVzaEHdmNSQWLPUKhRjOb['spotv_sessionid'])
  YJrITwqevtVzaEHdmNSQWLPUKhRjMo.setProperty('SPOTV_M_SESSION',YJrITwqevtVzaEHdmNSQWLPUKhRjOb['spotv_session'])
  YJrITwqevtVzaEHdmNSQWLPUKhRjMo.setProperty('SPOTV_M_ACCOUNTID',YJrITwqevtVzaEHdmNSQWLPUKhRjOb['spotv_accountId'])
  YJrITwqevtVzaEHdmNSQWLPUKhRjMo.setProperty('SPOTV_M_POLICYKEY',YJrITwqevtVzaEHdmNSQWLPUKhRjOb['spotv_policyKey'])
  YJrITwqevtVzaEHdmNSQWLPUKhRjMo.setProperty('SPOTV_M_SUBEND',YJrITwqevtVzaEHdmNSQWLPUKhRjOb['spotv_subend'])
  YJrITwqevtVzaEHdmNSQWLPUKhRjMo.setProperty('SPOTV_M_LOGINTIME',YJrITwqevtVzaEHdmNSQWLPUKhRjOo)
  return YJrITwqevtVzaEHdmNSQWLPUKhRjDx
 def dp_WatchList_Delete(YJrITwqevtVzaEHdmNSQWLPUKhRjMD,args):
  YJrITwqevtVzaEHdmNSQWLPUKhRjOp=args.get('mediatype')
  YJrITwqevtVzaEHdmNSQWLPUKhRjMp=xbmcgui.Dialog()
  YJrITwqevtVzaEHdmNSQWLPUKhRjfX=YJrITwqevtVzaEHdmNSQWLPUKhRjMp.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if YJrITwqevtVzaEHdmNSQWLPUKhRjfX==YJrITwqevtVzaEHdmNSQWLPUKhRjDc:sys.exit()
  YJrITwqevtVzaEHdmNSQWLPUKhRjMD.Delete_Watched_List(YJrITwqevtVzaEHdmNSQWLPUKhRjOp)
  xbmc.executebuiltin("Container.Refresh")
 def Delete_Watched_List(YJrITwqevtVzaEHdmNSQWLPUKhRjMD,YJrITwqevtVzaEHdmNSQWLPUKhRjOp):
  try:
   YJrITwqevtVzaEHdmNSQWLPUKhRjOC=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%YJrITwqevtVzaEHdmNSQWLPUKhRjOp))
   fp=YJrITwqevtVzaEHdmNSQWLPUKhRjDC(YJrITwqevtVzaEHdmNSQWLPUKhRjOC,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   YJrITwqevtVzaEHdmNSQWLPUKhRjDi
 def Load_Watched_List(YJrITwqevtVzaEHdmNSQWLPUKhRjMD,YJrITwqevtVzaEHdmNSQWLPUKhRjOp):
  try:
   YJrITwqevtVzaEHdmNSQWLPUKhRjOC=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%YJrITwqevtVzaEHdmNSQWLPUKhRjOp))
   fp=YJrITwqevtVzaEHdmNSQWLPUKhRjDC(YJrITwqevtVzaEHdmNSQWLPUKhRjOC,'r',-1,'utf-8')
   YJrITwqevtVzaEHdmNSQWLPUKhRjOX=fp.readlines()
   fp.close()
  except:
   YJrITwqevtVzaEHdmNSQWLPUKhRjOX=[]
  return YJrITwqevtVzaEHdmNSQWLPUKhRjOX
 def Save_Watched_List(YJrITwqevtVzaEHdmNSQWLPUKhRjMD,stype,YJrITwqevtVzaEHdmNSQWLPUKhRjMl):
  try:
   YJrITwqevtVzaEHdmNSQWLPUKhRjOC=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   YJrITwqevtVzaEHdmNSQWLPUKhRjOn=YJrITwqevtVzaEHdmNSQWLPUKhRjMD.Load_Watched_List(stype) 
   fp=YJrITwqevtVzaEHdmNSQWLPUKhRjDC(YJrITwqevtVzaEHdmNSQWLPUKhRjOC,'w',-1,'utf-8')
   YJrITwqevtVzaEHdmNSQWLPUKhRjOF=urllib.parse.urlencode(YJrITwqevtVzaEHdmNSQWLPUKhRjMl)
   YJrITwqevtVzaEHdmNSQWLPUKhRjOF=YJrITwqevtVzaEHdmNSQWLPUKhRjOF+'\n'
   fp.write(YJrITwqevtVzaEHdmNSQWLPUKhRjOF)
   YJrITwqevtVzaEHdmNSQWLPUKhRjOk=0
   for YJrITwqevtVzaEHdmNSQWLPUKhRjOu in YJrITwqevtVzaEHdmNSQWLPUKhRjOn:
    YJrITwqevtVzaEHdmNSQWLPUKhRjDM=YJrITwqevtVzaEHdmNSQWLPUKhRjDF(urllib.parse.parse_qsl(YJrITwqevtVzaEHdmNSQWLPUKhRjOu))
    YJrITwqevtVzaEHdmNSQWLPUKhRjDG=YJrITwqevtVzaEHdmNSQWLPUKhRjMl.get('code')
    YJrITwqevtVzaEHdmNSQWLPUKhRjDf=YJrITwqevtVzaEHdmNSQWLPUKhRjDM.get('code')
    if YJrITwqevtVzaEHdmNSQWLPUKhRjDG!=YJrITwqevtVzaEHdmNSQWLPUKhRjDf:
     fp.write(YJrITwqevtVzaEHdmNSQWLPUKhRjOu)
     YJrITwqevtVzaEHdmNSQWLPUKhRjOk+=1
     if YJrITwqevtVzaEHdmNSQWLPUKhRjOk>=50:break
   fp.close()
  except:
   YJrITwqevtVzaEHdmNSQWLPUKhRjDi
 def dp_Watch_List(YJrITwqevtVzaEHdmNSQWLPUKhRjMD,args):
  YJrITwqevtVzaEHdmNSQWLPUKhRjOp ='vod'
  if YJrITwqevtVzaEHdmNSQWLPUKhRjOp=='vod':
   YJrITwqevtVzaEHdmNSQWLPUKhRjDO=YJrITwqevtVzaEHdmNSQWLPUKhRjMD.Load_Watched_List(YJrITwqevtVzaEHdmNSQWLPUKhRjOp)
   for YJrITwqevtVzaEHdmNSQWLPUKhRjDA in YJrITwqevtVzaEHdmNSQWLPUKhRjDO:
    YJrITwqevtVzaEHdmNSQWLPUKhRjDg=YJrITwqevtVzaEHdmNSQWLPUKhRjDF(urllib.parse.parse_qsl(YJrITwqevtVzaEHdmNSQWLPUKhRjDA))
    YJrITwqevtVzaEHdmNSQWLPUKhRjMn =YJrITwqevtVzaEHdmNSQWLPUKhRjDg.get('title')
    YJrITwqevtVzaEHdmNSQWLPUKhRjGs=YJrITwqevtVzaEHdmNSQWLPUKhRjDg.get('img')
    YJrITwqevtVzaEHdmNSQWLPUKhRjOy=YJrITwqevtVzaEHdmNSQWLPUKhRjDg.get('code')
    YJrITwqevtVzaEHdmNSQWLPUKhRjDl =YJrITwqevtVzaEHdmNSQWLPUKhRjDg.get('info')
    YJrITwqevtVzaEHdmNSQWLPUKhRjGx={}
    YJrITwqevtVzaEHdmNSQWLPUKhRjGx['plot']=YJrITwqevtVzaEHdmNSQWLPUKhRjDl
    YJrITwqevtVzaEHdmNSQWLPUKhRjGD={'mode':'GAME_VOD_GROUP','gameid':YJrITwqevtVzaEHdmNSQWLPUKhRjOy,'saveTitle':YJrITwqevtVzaEHdmNSQWLPUKhRjMn,'saveImg':YJrITwqevtVzaEHdmNSQWLPUKhRjGs,'saveInfo':YJrITwqevtVzaEHdmNSQWLPUKhRjDl,'mediatype':YJrITwqevtVzaEHdmNSQWLPUKhRjOp}
    YJrITwqevtVzaEHdmNSQWLPUKhRjMD.add_dir(YJrITwqevtVzaEHdmNSQWLPUKhRjMn,sublabel='',img=YJrITwqevtVzaEHdmNSQWLPUKhRjGs,infoLabels=YJrITwqevtVzaEHdmNSQWLPUKhRjGx,isFolder=YJrITwqevtVzaEHdmNSQWLPUKhRjDx,params=YJrITwqevtVzaEHdmNSQWLPUKhRjGD)
   YJrITwqevtVzaEHdmNSQWLPUKhRjGx={'plot':'시청목록을 삭제합니다.'}
   YJrITwqevtVzaEHdmNSQWLPUKhRjMn='*** 시청목록 삭제 ***'
   YJrITwqevtVzaEHdmNSQWLPUKhRjGD={'mode':'MYVIEW_REMOVE','mediatype':YJrITwqevtVzaEHdmNSQWLPUKhRjOp}
   YJrITwqevtVzaEHdmNSQWLPUKhRjGO=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   YJrITwqevtVzaEHdmNSQWLPUKhRjMD.add_dir(YJrITwqevtVzaEHdmNSQWLPUKhRjMn,sublabel='',img=YJrITwqevtVzaEHdmNSQWLPUKhRjGO,infoLabels=YJrITwqevtVzaEHdmNSQWLPUKhRjGx,isFolder=YJrITwqevtVzaEHdmNSQWLPUKhRjDc,params=YJrITwqevtVzaEHdmNSQWLPUKhRjGD,isLink=YJrITwqevtVzaEHdmNSQWLPUKhRjDx)
   xbmcplugin.endOfDirectory(YJrITwqevtVzaEHdmNSQWLPUKhRjMD._addon_handle,cacheToDisc=YJrITwqevtVzaEHdmNSQWLPUKhRjDc)
 def spotv_main(YJrITwqevtVzaEHdmNSQWLPUKhRjMD):
  YJrITwqevtVzaEHdmNSQWLPUKhRjDp=YJrITwqevtVzaEHdmNSQWLPUKhRjMD.main_params.get('mode',YJrITwqevtVzaEHdmNSQWLPUKhRjDi)
  if YJrITwqevtVzaEHdmNSQWLPUKhRjDp=='LOGOUT':
   YJrITwqevtVzaEHdmNSQWLPUKhRjMD.logout()
   return
  YJrITwqevtVzaEHdmNSQWLPUKhRjMD.login_main()
  if YJrITwqevtVzaEHdmNSQWLPUKhRjDp is YJrITwqevtVzaEHdmNSQWLPUKhRjDi:
   YJrITwqevtVzaEHdmNSQWLPUKhRjMD.dp_Main_List()
  elif YJrITwqevtVzaEHdmNSQWLPUKhRjDp=='LIVE_GROUP':
   YJrITwqevtVzaEHdmNSQWLPUKhRjMD.dp_LiveChannel_List(YJrITwqevtVzaEHdmNSQWLPUKhRjMD.main_params)
  elif YJrITwqevtVzaEHdmNSQWLPUKhRjDp=='ELIVE_GROUP':
   YJrITwqevtVzaEHdmNSQWLPUKhRjOg=YJrITwqevtVzaEHdmNSQWLPUKhRjMD.dp_EventLiveChannel_List(YJrITwqevtVzaEHdmNSQWLPUKhRjMD.main_params)
   if YJrITwqevtVzaEHdmNSQWLPUKhRjOg==401:
    if os.path.isfile(YJrITwqevtVzaEHdmNSQWLPUKhRjMO):os.remove(YJrITwqevtVzaEHdmNSQWLPUKhRjMO)
    YJrITwqevtVzaEHdmNSQWLPUKhRjMD.login_main()
    YJrITwqevtVzaEHdmNSQWLPUKhRjMD.dp_EventLiveChannel_List(YJrITwqevtVzaEHdmNSQWLPUKhRjMD.main_params)
  elif YJrITwqevtVzaEHdmNSQWLPUKhRjDp in['LIVE','GAME_VOD','POP_VOD','NOW_VOD','ELIVE']:
   YJrITwqevtVzaEHdmNSQWLPUKhRjMD.play_VIDEO(YJrITwqevtVzaEHdmNSQWLPUKhRjMD.main_params)
  elif YJrITwqevtVzaEHdmNSQWLPUKhRjDp=='VOD_GROUP':
   YJrITwqevtVzaEHdmNSQWLPUKhRjMD.dp_MainLeague_List(YJrITwqevtVzaEHdmNSQWLPUKhRjMD.main_params)
  elif YJrITwqevtVzaEHdmNSQWLPUKhRjDp=='NOW_GROUP':
   YJrITwqevtVzaEHdmNSQWLPUKhRjMD.dp_NowVod_GroupList(YJrITwqevtVzaEHdmNSQWLPUKhRjMD.main_params)
  elif YJrITwqevtVzaEHdmNSQWLPUKhRjDp=='POP_GROUP':
   YJrITwqevtVzaEHdmNSQWLPUKhRjMD.dp_PopVod_GroupList(YJrITwqevtVzaEHdmNSQWLPUKhRjMD.main_params)
  elif YJrITwqevtVzaEHdmNSQWLPUKhRjDp=='LEAGUE_GROUP':
   YJrITwqevtVzaEHdmNSQWLPUKhRjMD.dp_Season_List(YJrITwqevtVzaEHdmNSQWLPUKhRjMD.main_params)
  elif YJrITwqevtVzaEHdmNSQWLPUKhRjDp=='SEASON_GROUP':
   YJrITwqevtVzaEHdmNSQWLPUKhRjMD.dp_Game_List(YJrITwqevtVzaEHdmNSQWLPUKhRjMD.main_params)
  elif YJrITwqevtVzaEHdmNSQWLPUKhRjDp=='GAME_VOD_GROUP':
   YJrITwqevtVzaEHdmNSQWLPUKhRjMD.dp_GameVod_List(YJrITwqevtVzaEHdmNSQWLPUKhRjMD.main_params)
  elif YJrITwqevtVzaEHdmNSQWLPUKhRjDp=='WATCH':
   YJrITwqevtVzaEHdmNSQWLPUKhRjMD.dp_Watch_List(YJrITwqevtVzaEHdmNSQWLPUKhRjMD.main_params)
  elif YJrITwqevtVzaEHdmNSQWLPUKhRjDp=='MYVIEW_REMOVE':
   YJrITwqevtVzaEHdmNSQWLPUKhRjMD.dp_WatchList_Delete(YJrITwqevtVzaEHdmNSQWLPUKhRjMD.main_params)
  else:
   YJrITwqevtVzaEHdmNSQWLPUKhRjDi
# Created by pyminifier (https://github.com/liftoff/pyminifier)
