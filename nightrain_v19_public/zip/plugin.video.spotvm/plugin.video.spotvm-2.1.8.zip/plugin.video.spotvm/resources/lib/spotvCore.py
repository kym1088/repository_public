__author__="NightRain"
XnBoeHAbidaflSMtQYGsOvUumgcJFj=False
XnBoeHAbidaflSMtQYGsOvUumgcJFP=object
XnBoeHAbidaflSMtQYGsOvUumgcJFw=None
XnBoeHAbidaflSMtQYGsOvUumgcJFR=print
XnBoeHAbidaflSMtQYGsOvUumgcJFE=str
XnBoeHAbidaflSMtQYGsOvUumgcJWD=True
XnBoeHAbidaflSMtQYGsOvUumgcJWC=Exception
XnBoeHAbidaflSMtQYGsOvUumgcJWT=int
XnBoeHAbidaflSMtQYGsOvUumgcJWK=len
XnBoeHAbidaflSMtQYGsOvUumgcJWF=range
import urllib
import re
import json
import sys
import time
import requests
import datetime
import base64
XnBoeHAbidaflSMtQYGsOvUumgcJDT={'stream50':1080,'stream40':720,'stream30':540}
XnBoeHAbidaflSMtQYGsOvUumgcJDK=[{'name':'NOW','videoId':'ch_spotvnow1','epgtype':'spotvon','epgnm':'spotvon','free':XnBoeHAbidaflSMtQYGsOvUumgcJFj,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/ccdb36ce757afc1ca15fc38357d498e4.png'},{'name':'NOW2','videoId':'ch_spotvnow2','epgtype':'spotvon','epgnm':'spotvon2','free':XnBoeHAbidaflSMtQYGsOvUumgcJFj,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/8b6bdf6213a715eeba719b2cb9b2c747.png'},{'name':'NBA TV','videoId':'ch_nbatv','epgtype':'-','epgnm':'-','free':XnBoeHAbidaflSMtQYGsOvUumgcJFj,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/5036e56d5c6594ea606f7159f59779fe.png'},{'name':'SPOTV','videoId':'ch_spotv','epgtype':'spotvnet','epgnm':'SPOTV','free':XnBoeHAbidaflSMtQYGsOvUumgcJFj,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/56688c2e527c6e1b8d68e338057a7dfc.png'},{'name':'SPOTV2','videoId':'ch_spotv2','epgtype':'spotvnet','epgnm':'SPOTV2','free':XnBoeHAbidaflSMtQYGsOvUumgcJFj,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20201209/ca6e7a213c84e629985e609ddcda6b17.png'},{'name':'SPOTV Golf & Health','videoId':'ch_spotvplus','epgtype':'spotvnet','epgnm':'SPOTVP','free':XnBoeHAbidaflSMtQYGsOvUumgcJFj,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/7aa87953f1211313c3e110cace2628ff.png'},]
XnBoeHAbidaflSMtQYGsOvUumgcJDF={'ch_spotvnow1':{'lv':'abf18bbf3b3f4a0db4a41dd2af7f75c6','rv':'__nn__=5981484117001&hdnea=st=1609407000~exp=1609410600~acl=/abf18bbf3b3f4a0db4a41dd2af7f75c6/ap-northeast-1/5764318566001/*~hmac=e28a244d1b6b77d4e0101010816d4cd6ca89d9d31fe6a5290039d2395d81bc03'},'ch_spotvnow2':{'lv':'3054522000fc4d60aabe23d6e5911275','rv':'__nn__=5981484117001&hdnea=st=1609408800~exp=1609412400~acl=/3054522000fc4d60aabe23d6e5911275/ap-northeast-1/5764318566001/*~hmac=323b2deea8e3455fa77405f37b19231c6f0b48a5690b7218df875171ac2d6be6'},'ch_nbatv':{'lv':'31f99a0a6067413ea1b390c41a5c12be','rv':'__nn__=5981484117001&hdnea=st=1609408800~exp=1609412400~acl=/31f99a0a6067413ea1b390c41a5c12be/ap-northeast-1/5764318566001/*~hmac=b7ac24bc4772e3ad2669000919058bba64a6f001c69c8846341c326b089c306c'},'ch_spotv':{'lv':'1f2651c2fea34be9850bfdedf8d9cfdb','rv':'__nn__=5981484117001&hdnea=st=1609408800~exp=1609412400~acl=/1f2651c2fea34be9850bfdedf8d9cfdb/ap-northeast-1/5764318566001/*~hmac=e1f6c44d1be5459cfc40af1e1b204ac9b513bb7405e070da2bff8f115f298133'},'ch_spotv2':{'lv':'7bf3fb8685854892b01e1fc897e7e9b0','rv':'__nn__=5981484117001&hdnea=st=1609408800~exp=1609412400~acl=/7bf3fb8685854892b01e1fc897e7e9b0/ap-northeast-1/5764318566001/*~hmac=e9bb30991cfab98b1976aacabafcd51b63769ede40148f7cc289ffed15398e81'},'ch_spotvplus':{'lv':'242b2b6c0c654f47a07f4e2420f9c184','rv':'__nn__=5981484117001&hdnea=st=1609408800~exp=1609412400~acl=/242b2b6c0c654f47a07f4e2420f9c184/ap-northeast-1/5764318566001/*~hmac=5e4ce0553e709eb60d880bf37bc2e99661767b0a38ecee037fb4d7dce757b922'},}
class XnBoeHAbidaflSMtQYGsOvUumgcJDC(XnBoeHAbidaflSMtQYGsOvUumgcJFP):
 def __init__(XnBoeHAbidaflSMtQYGsOvUumgcJDW):
  XnBoeHAbidaflSMtQYGsOvUumgcJDW.SPOTV_SESSIONID=''
  XnBoeHAbidaflSMtQYGsOvUumgcJDW.SPOTV_SESSION =''
  XnBoeHAbidaflSMtQYGsOvUumgcJDW.SPOTV_ACCOUNTID=''
  XnBoeHAbidaflSMtQYGsOvUumgcJDW.SPOTV_POLICYKEY=''
  XnBoeHAbidaflSMtQYGsOvUumgcJDW.SPOTV_SUBEND =''
  XnBoeHAbidaflSMtQYGsOvUumgcJDW.SPOTV_PMCODE ='987'
  XnBoeHAbidaflSMtQYGsOvUumgcJDW.SPOTV_PMSIZE =3
  XnBoeHAbidaflSMtQYGsOvUumgcJDW.GAMELIST_LIMIT =10
  XnBoeHAbidaflSMtQYGsOvUumgcJDW.API_DOMAIN ='https://www.spotvnow.co.kr'
  XnBoeHAbidaflSMtQYGsOvUumgcJDW.BC_DOMAIN ='https://players.brightcove.net'
  XnBoeHAbidaflSMtQYGsOvUumgcJDW.PLAYER_DOMAIN ='https://edge.api.brightcove.com'
  XnBoeHAbidaflSMtQYGsOvUumgcJDW.STREAM_DOMAIN ='https://gtm-spotv.brightcovecdn.com'
  XnBoeHAbidaflSMtQYGsOvUumgcJDW.STREAM_M3U8 ='ap-northeast-1/5764318566001/playlist_dvr'
  XnBoeHAbidaflSMtQYGsOvUumgcJDW.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36'
  XnBoeHAbidaflSMtQYGsOvUumgcJDW.DEFAULT_HEADER ={'user-agent':XnBoeHAbidaflSMtQYGsOvUumgcJDW.USER_AGENT}
 def callRequestCookies(XnBoeHAbidaflSMtQYGsOvUumgcJDW,jobtype,XnBoeHAbidaflSMtQYGsOvUumgcJCp,payload=XnBoeHAbidaflSMtQYGsOvUumgcJFw,params=XnBoeHAbidaflSMtQYGsOvUumgcJFw,headers=XnBoeHAbidaflSMtQYGsOvUumgcJFw,cookies=XnBoeHAbidaflSMtQYGsOvUumgcJFw,redirects=XnBoeHAbidaflSMtQYGsOvUumgcJFj):
  XnBoeHAbidaflSMtQYGsOvUumgcJDq=XnBoeHAbidaflSMtQYGsOvUumgcJDW.DEFAULT_HEADER
  if headers:XnBoeHAbidaflSMtQYGsOvUumgcJDq.update(headers)
  if jobtype=='Get':
   XnBoeHAbidaflSMtQYGsOvUumgcJDV=requests.get(XnBoeHAbidaflSMtQYGsOvUumgcJCp,params=params,headers=XnBoeHAbidaflSMtQYGsOvUumgcJDq,cookies=cookies,allow_redirects=redirects)
  else:
   XnBoeHAbidaflSMtQYGsOvUumgcJDV=requests.post(XnBoeHAbidaflSMtQYGsOvUumgcJCp,data=payload,params=params,headers=XnBoeHAbidaflSMtQYGsOvUumgcJDq,cookies=cookies,allow_redirects=redirects)
  return XnBoeHAbidaflSMtQYGsOvUumgcJDV
 def makeDefaultCookies(XnBoeHAbidaflSMtQYGsOvUumgcJDW):
  XnBoeHAbidaflSMtQYGsOvUumgcJDp={'SESSION':XnBoeHAbidaflSMtQYGsOvUumgcJDW.SPOTV_SESSION}
  return XnBoeHAbidaflSMtQYGsOvUumgcJDp
 def xmlText(XnBoeHAbidaflSMtQYGsOvUumgcJDW,in_text):
  XnBoeHAbidaflSMtQYGsOvUumgcJDz=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;')
  return XnBoeHAbidaflSMtQYGsOvUumgcJDz
 def GetCredential(XnBoeHAbidaflSMtQYGsOvUumgcJDW,user_id,user_pw):
  XnBoeHAbidaflSMtQYGsOvUumgcJDy=XnBoeHAbidaflSMtQYGsOvUumgcJFj
  XnBoeHAbidaflSMtQYGsOvUumgcJDx=XnBoeHAbidaflSMtQYGsOvUumgcJDj=XnBoeHAbidaflSMtQYGsOvUumgcJDR=XnBoeHAbidaflSMtQYGsOvUumgcJDE=XnBoeHAbidaflSMtQYGsOvUumgcJDw=''
  try:
   XnBoeHAbidaflSMtQYGsOvUumgcJDL=base64.standard_b64encode(user_id.encode("UTF-8")).decode('utf-8')
   XnBoeHAbidaflSMtQYGsOvUumgcJDN=base64.standard_b64encode(user_pw.encode("UTF-8")).decode('utf-8')
   XnBoeHAbidaflSMtQYGsOvUumgcJDI=XnBoeHAbidaflSMtQYGsOvUumgcJDW.API_DOMAIN+'/api/v2/login'
   XnBoeHAbidaflSMtQYGsOvUumgcJDk={'username':XnBoeHAbidaflSMtQYGsOvUumgcJDL,'password':XnBoeHAbidaflSMtQYGsOvUumgcJDN}
   XnBoeHAbidaflSMtQYGsOvUumgcJDk=json.dumps(XnBoeHAbidaflSMtQYGsOvUumgcJDk)
   XnBoeHAbidaflSMtQYGsOvUumgcJDr=XnBoeHAbidaflSMtQYGsOvUumgcJDW.callRequestCookies('Post',XnBoeHAbidaflSMtQYGsOvUumgcJDI,payload=XnBoeHAbidaflSMtQYGsOvUumgcJDk,params=XnBoeHAbidaflSMtQYGsOvUumgcJFw,headers=XnBoeHAbidaflSMtQYGsOvUumgcJFw,cookies=XnBoeHAbidaflSMtQYGsOvUumgcJFw)
   XnBoeHAbidaflSMtQYGsOvUumgcJFR(XnBoeHAbidaflSMtQYGsOvUumgcJDr.status_code)
   for XnBoeHAbidaflSMtQYGsOvUumgcJDh in XnBoeHAbidaflSMtQYGsOvUumgcJDr.cookies:
    if XnBoeHAbidaflSMtQYGsOvUumgcJDh.name=='SESSION':
     XnBoeHAbidaflSMtQYGsOvUumgcJDj=XnBoeHAbidaflSMtQYGsOvUumgcJDh.value
     break
   if XnBoeHAbidaflSMtQYGsOvUumgcJDj=='':return XnBoeHAbidaflSMtQYGsOvUumgcJDy
   XnBoeHAbidaflSMtQYGsOvUumgcJDP=json.loads(XnBoeHAbidaflSMtQYGsOvUumgcJDr.text)
   if not('userId' in XnBoeHAbidaflSMtQYGsOvUumgcJDP):return XnBoeHAbidaflSMtQYGsOvUumgcJDy
   XnBoeHAbidaflSMtQYGsOvUumgcJDx=XnBoeHAbidaflSMtQYGsOvUumgcJFE(XnBoeHAbidaflSMtQYGsOvUumgcJDP['userId'])
   XnBoeHAbidaflSMtQYGsOvUumgcJDw =XnBoeHAbidaflSMtQYGsOvUumgcJFE(XnBoeHAbidaflSMtQYGsOvUumgcJDP['subEndTime'])
   XnBoeHAbidaflSMtQYGsOvUumgcJDR,XnBoeHAbidaflSMtQYGsOvUumgcJDE=XnBoeHAbidaflSMtQYGsOvUumgcJDW.GetPolicyKey()
   if XnBoeHAbidaflSMtQYGsOvUumgcJDE=='':return XnBoeHAbidaflSMtQYGsOvUumgcJDy
   XnBoeHAbidaflSMtQYGsOvUumgcJDy=XnBoeHAbidaflSMtQYGsOvUumgcJWD
  except XnBoeHAbidaflSMtQYGsOvUumgcJWC as exception:
   XnBoeHAbidaflSMtQYGsOvUumgcJDx=XnBoeHAbidaflSMtQYGsOvUumgcJDj='' 
   XnBoeHAbidaflSMtQYGsOvUumgcJFR(exception)
  XnBoeHAbidaflSMtQYGsOvUumgcJCD={'spotv_sessionid':XnBoeHAbidaflSMtQYGsOvUumgcJDx,'spotv_session':XnBoeHAbidaflSMtQYGsOvUumgcJDj,'spotv_accountId':XnBoeHAbidaflSMtQYGsOvUumgcJDR,'spotv_policyKey':XnBoeHAbidaflSMtQYGsOvUumgcJDE,'spotv_subend':XnBoeHAbidaflSMtQYGsOvUumgcJDw}
  XnBoeHAbidaflSMtQYGsOvUumgcJDW.SaveCredential(XnBoeHAbidaflSMtQYGsOvUumgcJCD)
  return XnBoeHAbidaflSMtQYGsOvUumgcJDy
 def SaveCredential(XnBoeHAbidaflSMtQYGsOvUumgcJDW,XnBoeHAbidaflSMtQYGsOvUumgcJCD):
  XnBoeHAbidaflSMtQYGsOvUumgcJDW.SPOTV_SESSIONID=XnBoeHAbidaflSMtQYGsOvUumgcJCD.get('spotv_sessionid')
  XnBoeHAbidaflSMtQYGsOvUumgcJDW.SPOTV_SESSION =XnBoeHAbidaflSMtQYGsOvUumgcJCD.get('spotv_session')
  XnBoeHAbidaflSMtQYGsOvUumgcJDW.SPOTV_ACCOUNTID=XnBoeHAbidaflSMtQYGsOvUumgcJCD.get('spotv_accountId')
  XnBoeHAbidaflSMtQYGsOvUumgcJDW.SPOTV_POLICYKEY=XnBoeHAbidaflSMtQYGsOvUumgcJCD.get('spotv_policyKey')
  XnBoeHAbidaflSMtQYGsOvUumgcJDW.SPOTV_SUBEND =XnBoeHAbidaflSMtQYGsOvUumgcJCD.get('spotv_subend')
 def LoadCredential(XnBoeHAbidaflSMtQYGsOvUumgcJDW):
  XnBoeHAbidaflSMtQYGsOvUumgcJCD={'spotv_sessionid':XnBoeHAbidaflSMtQYGsOvUumgcJDW.SPOTV_SESSIONID,'spotv_session':XnBoeHAbidaflSMtQYGsOvUumgcJDW.SPOTV_SESSION,'spotv_accountId':XnBoeHAbidaflSMtQYGsOvUumgcJDW.SPOTV_ACCOUNTID,'spotv_policyKey':XnBoeHAbidaflSMtQYGsOvUumgcJDW.SPOTV_POLICYKEY,'spotv_subend':XnBoeHAbidaflSMtQYGsOvUumgcJDW.SPOTV_SUBEND}
  return XnBoeHAbidaflSMtQYGsOvUumgcJCD
 def Get_Now_Datetime(XnBoeHAbidaflSMtQYGsOvUumgcJDW):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_Streamurl_Make(XnBoeHAbidaflSMtQYGsOvUumgcJDW,XnBoeHAbidaflSMtQYGsOvUumgcJTV):
  XnBoeHAbidaflSMtQYGsOvUumgcJCK='%s/%s/%s.m3u8?%s'%(XnBoeHAbidaflSMtQYGsOvUumgcJDW.STREAM_DOMAIN,XnBoeHAbidaflSMtQYGsOvUumgcJDF.get(XnBoeHAbidaflSMtQYGsOvUumgcJTV).get('lv'),XnBoeHAbidaflSMtQYGsOvUumgcJDW.STREAM_M3U8,XnBoeHAbidaflSMtQYGsOvUumgcJDF.get(XnBoeHAbidaflSMtQYGsOvUumgcJTV).get('rv'))
  return XnBoeHAbidaflSMtQYGsOvUumgcJCK
 def GetLiveChannelList(XnBoeHAbidaflSMtQYGsOvUumgcJDW):
  XnBoeHAbidaflSMtQYGsOvUumgcJCF=[]
  XnBoeHAbidaflSMtQYGsOvUumgcJCW ={}
  try:
   XnBoeHAbidaflSMtQYGsOvUumgcJCW=XnBoeHAbidaflSMtQYGsOvUumgcJDW.GetEPGList_new()
   for XnBoeHAbidaflSMtQYGsOvUumgcJCq in XnBoeHAbidaflSMtQYGsOvUumgcJDK:
    XnBoeHAbidaflSMtQYGsOvUumgcJCV={'name':XnBoeHAbidaflSMtQYGsOvUumgcJCq['name'],'logo':XnBoeHAbidaflSMtQYGsOvUumgcJCq['logo'],'videoId':XnBoeHAbidaflSMtQYGsOvUumgcJCq['videoId'],'free':XnBoeHAbidaflSMtQYGsOvUumgcJCq['free'],'channelepg':XnBoeHAbidaflSMtQYGsOvUumgcJCW.get(XnBoeHAbidaflSMtQYGsOvUumgcJCq['videoId'])}
    XnBoeHAbidaflSMtQYGsOvUumgcJCF.append(XnBoeHAbidaflSMtQYGsOvUumgcJCV)
  except XnBoeHAbidaflSMtQYGsOvUumgcJWC as exception:
   XnBoeHAbidaflSMtQYGsOvUumgcJFR(exception)
  return XnBoeHAbidaflSMtQYGsOvUumgcJCF
 def CheckLiveChannel(XnBoeHAbidaflSMtQYGsOvUumgcJDW,XnBoeHAbidaflSMtQYGsOvUumgcJCP):
  try:
   XnBoeHAbidaflSMtQYGsOvUumgcJCp=XnBoeHAbidaflSMtQYGsOvUumgcJDW.API_DOMAIN+'/api/v2/channel'
   XnBoeHAbidaflSMtQYGsOvUumgcJDr=XnBoeHAbidaflSMtQYGsOvUumgcJDW.callRequestCookies('Get',XnBoeHAbidaflSMtQYGsOvUumgcJCp,payload=XnBoeHAbidaflSMtQYGsOvUumgcJFw,params=XnBoeHAbidaflSMtQYGsOvUumgcJFw,headers=XnBoeHAbidaflSMtQYGsOvUumgcJFw,cookies=XnBoeHAbidaflSMtQYGsOvUumgcJFw)
   XnBoeHAbidaflSMtQYGsOvUumgcJDP=json.loads(XnBoeHAbidaflSMtQYGsOvUumgcJDr.text)
   for XnBoeHAbidaflSMtQYGsOvUumgcJCq in XnBoeHAbidaflSMtQYGsOvUumgcJDP:
    if XnBoeHAbidaflSMtQYGsOvUumgcJCq['videoId'].replace('ref:','')==XnBoeHAbidaflSMtQYGsOvUumgcJCP:
     return XnBoeHAbidaflSMtQYGsOvUumgcJCq['free']
  except XnBoeHAbidaflSMtQYGsOvUumgcJWC as exception:
   XnBoeHAbidaflSMtQYGsOvUumgcJFR(exception)
  return XnBoeHAbidaflSMtQYGsOvUumgcJFj
 def GetEPGList(XnBoeHAbidaflSMtQYGsOvUumgcJDW):
  XnBoeHAbidaflSMtQYGsOvUumgcJCz={}
  XnBoeHAbidaflSMtQYGsOvUumgcJCy=XnBoeHAbidaflSMtQYGsOvUumgcJDW.Get_Now_Datetime()
  XnBoeHAbidaflSMtQYGsOvUumgcJCx=XnBoeHAbidaflSMtQYGsOvUumgcJCy.strftime('%Y%m%d%H%M')
  XnBoeHAbidaflSMtQYGsOvUumgcJCL='%s-%s-%s'%(XnBoeHAbidaflSMtQYGsOvUumgcJCx[0:4],XnBoeHAbidaflSMtQYGsOvUumgcJCx[4:6],XnBoeHAbidaflSMtQYGsOvUumgcJCx[6:8])
  XnBoeHAbidaflSMtQYGsOvUumgcJCN=(XnBoeHAbidaflSMtQYGsOvUumgcJCy+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M')
  try:
   XnBoeHAbidaflSMtQYGsOvUumgcJCp=XnBoeHAbidaflSMtQYGsOvUumgcJDW.API_DOMAIN+'/api/v2/program/'+XnBoeHAbidaflSMtQYGsOvUumgcJCL
   XnBoeHAbidaflSMtQYGsOvUumgcJDr=XnBoeHAbidaflSMtQYGsOvUumgcJDW.callRequestCookies('Get',XnBoeHAbidaflSMtQYGsOvUumgcJCp,payload=XnBoeHAbidaflSMtQYGsOvUumgcJFw,params=XnBoeHAbidaflSMtQYGsOvUumgcJFw,headers=XnBoeHAbidaflSMtQYGsOvUumgcJFw,cookies=XnBoeHAbidaflSMtQYGsOvUumgcJFw)
   XnBoeHAbidaflSMtQYGsOvUumgcJDP=json.loads(XnBoeHAbidaflSMtQYGsOvUumgcJDr.text)
   XnBoeHAbidaflSMtQYGsOvUumgcJCI=-1 
   XnBoeHAbidaflSMtQYGsOvUumgcJCk =''
   for XnBoeHAbidaflSMtQYGsOvUumgcJCq in XnBoeHAbidaflSMtQYGsOvUumgcJDP:
    XnBoeHAbidaflSMtQYGsOvUumgcJCr=XnBoeHAbidaflSMtQYGsOvUumgcJCq['channelId']
    XnBoeHAbidaflSMtQYGsOvUumgcJCh =XnBoeHAbidaflSMtQYGsOvUumgcJCq['startTime'].replace('-','').replace(' ','').replace(':','')
    XnBoeHAbidaflSMtQYGsOvUumgcJCj =XnBoeHAbidaflSMtQYGsOvUumgcJCq['endTime'].replace('-','').replace(' ','').replace(':','')
    if XnBoeHAbidaflSMtQYGsOvUumgcJWT(XnBoeHAbidaflSMtQYGsOvUumgcJCx)>XnBoeHAbidaflSMtQYGsOvUumgcJWT(XnBoeHAbidaflSMtQYGsOvUumgcJCj) :continue
    if XnBoeHAbidaflSMtQYGsOvUumgcJWT(XnBoeHAbidaflSMtQYGsOvUumgcJCN)<XnBoeHAbidaflSMtQYGsOvUumgcJWT(XnBoeHAbidaflSMtQYGsOvUumgcJCh):continue
    if XnBoeHAbidaflSMtQYGsOvUumgcJCI!=XnBoeHAbidaflSMtQYGsOvUumgcJCr:
     if XnBoeHAbidaflSMtQYGsOvUumgcJCk!='':XnBoeHAbidaflSMtQYGsOvUumgcJCz[XnBoeHAbidaflSMtQYGsOvUumgcJCI]=XnBoeHAbidaflSMtQYGsOvUumgcJCk
     XnBoeHAbidaflSMtQYGsOvUumgcJCI=XnBoeHAbidaflSMtQYGsOvUumgcJCr
     XnBoeHAbidaflSMtQYGsOvUumgcJCk =''
    if XnBoeHAbidaflSMtQYGsOvUumgcJCk:XnBoeHAbidaflSMtQYGsOvUumgcJCk+='\n'
    XnBoeHAbidaflSMtQYGsOvUumgcJCk+=XnBoeHAbidaflSMtQYGsOvUumgcJCq['title']+'\n'
    XnBoeHAbidaflSMtQYGsOvUumgcJCk+=' [%s ~ %s]'%(XnBoeHAbidaflSMtQYGsOvUumgcJCq['startTime'][-5:],XnBoeHAbidaflSMtQYGsOvUumgcJCq['endTime'][-5:])+'\n'
   if XnBoeHAbidaflSMtQYGsOvUumgcJCk:XnBoeHAbidaflSMtQYGsOvUumgcJCz[XnBoeHAbidaflSMtQYGsOvUumgcJCI]=XnBoeHAbidaflSMtQYGsOvUumgcJCk
  except XnBoeHAbidaflSMtQYGsOvUumgcJWC as exception:
   XnBoeHAbidaflSMtQYGsOvUumgcJFR(exception)
  return XnBoeHAbidaflSMtQYGsOvUumgcJCz
 def GetEPGList_new(XnBoeHAbidaflSMtQYGsOvUumgcJDW):
  XnBoeHAbidaflSMtQYGsOvUumgcJCz={}
  XnBoeHAbidaflSMtQYGsOvUumgcJCy=XnBoeHAbidaflSMtQYGsOvUumgcJDW.Get_Now_Datetime()
  XnBoeHAbidaflSMtQYGsOvUumgcJCx=XnBoeHAbidaflSMtQYGsOvUumgcJCy.strftime('%Y%m%d%H%M00')
  XnBoeHAbidaflSMtQYGsOvUumgcJCL='%s%s%s'%(XnBoeHAbidaflSMtQYGsOvUumgcJCx[0:4],XnBoeHAbidaflSMtQYGsOvUumgcJCx[4:6],XnBoeHAbidaflSMtQYGsOvUumgcJCx[6:8])
  XnBoeHAbidaflSMtQYGsOvUumgcJCN=(XnBoeHAbidaflSMtQYGsOvUumgcJCy+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M00')
  try:
   for XnBoeHAbidaflSMtQYGsOvUumgcJCq in XnBoeHAbidaflSMtQYGsOvUumgcJDK:
    XnBoeHAbidaflSMtQYGsOvUumgcJCP =XnBoeHAbidaflSMtQYGsOvUumgcJCq['videoId']
    if XnBoeHAbidaflSMtQYGsOvUumgcJCq['epgtype']=='spotvon':
     XnBoeHAbidaflSMtQYGsOvUumgcJCk=XnBoeHAbidaflSMtQYGsOvUumgcJDW.Get_EpgInfo_Spotv_spotvon(XnBoeHAbidaflSMtQYGsOvUumgcJCP,XnBoeHAbidaflSMtQYGsOvUumgcJCq['epgnm'],XnBoeHAbidaflSMtQYGsOvUumgcJCL)
     XnBoeHAbidaflSMtQYGsOvUumgcJCz[XnBoeHAbidaflSMtQYGsOvUumgcJCP]=XnBoeHAbidaflSMtQYGsOvUumgcJCk
    if XnBoeHAbidaflSMtQYGsOvUumgcJCq['epgtype']=='spotvnet':
     XnBoeHAbidaflSMtQYGsOvUumgcJCk=XnBoeHAbidaflSMtQYGsOvUumgcJDW.Get_EpgInfo_Spotv_spotvnet(XnBoeHAbidaflSMtQYGsOvUumgcJCP,XnBoeHAbidaflSMtQYGsOvUumgcJCq['epgnm'],XnBoeHAbidaflSMtQYGsOvUumgcJCL)
     XnBoeHAbidaflSMtQYGsOvUumgcJCz[XnBoeHAbidaflSMtQYGsOvUumgcJCP]=XnBoeHAbidaflSMtQYGsOvUumgcJCk
   for XnBoeHAbidaflSMtQYGsOvUumgcJCw in XnBoeHAbidaflSMtQYGsOvUumgcJCz.keys():
    if XnBoeHAbidaflSMtQYGsOvUumgcJWK(XnBoeHAbidaflSMtQYGsOvUumgcJCz.get(XnBoeHAbidaflSMtQYGsOvUumgcJCw))==0:continue
    XnBoeHAbidaflSMtQYGsOvUumgcJCk =''
    XnBoeHAbidaflSMtQYGsOvUumgcJCR=''
    for XnBoeHAbidaflSMtQYGsOvUumgcJCE in XnBoeHAbidaflSMtQYGsOvUumgcJCz.get(XnBoeHAbidaflSMtQYGsOvUumgcJCw):
     XnBoeHAbidaflSMtQYGsOvUumgcJCh =XnBoeHAbidaflSMtQYGsOvUumgcJCE['startTime']
     XnBoeHAbidaflSMtQYGsOvUumgcJCj =XnBoeHAbidaflSMtQYGsOvUumgcJCE['endTime']
     if XnBoeHAbidaflSMtQYGsOvUumgcJWT(XnBoeHAbidaflSMtQYGsOvUumgcJCx)>XnBoeHAbidaflSMtQYGsOvUumgcJWT(XnBoeHAbidaflSMtQYGsOvUumgcJCj) :continue
     if XnBoeHAbidaflSMtQYGsOvUumgcJWT(XnBoeHAbidaflSMtQYGsOvUumgcJCN)<XnBoeHAbidaflSMtQYGsOvUumgcJWT(XnBoeHAbidaflSMtQYGsOvUumgcJCh):continue
     if XnBoeHAbidaflSMtQYGsOvUumgcJWT(XnBoeHAbidaflSMtQYGsOvUumgcJCx)>=XnBoeHAbidaflSMtQYGsOvUumgcJWT(XnBoeHAbidaflSMtQYGsOvUumgcJCh)and XnBoeHAbidaflSMtQYGsOvUumgcJWT(XnBoeHAbidaflSMtQYGsOvUumgcJCx)<XnBoeHAbidaflSMtQYGsOvUumgcJWT(XnBoeHAbidaflSMtQYGsOvUumgcJCj):XnBoeHAbidaflSMtQYGsOvUumgcJCR=XnBoeHAbidaflSMtQYGsOvUumgcJDW.xmlText(XnBoeHAbidaflSMtQYGsOvUumgcJCE['title'])
     if XnBoeHAbidaflSMtQYGsOvUumgcJCk:XnBoeHAbidaflSMtQYGsOvUumgcJCk+='\n'
     XnBoeHAbidaflSMtQYGsOvUumgcJCk+=XnBoeHAbidaflSMtQYGsOvUumgcJDW.xmlText(XnBoeHAbidaflSMtQYGsOvUumgcJCE['title'])+'\n'
     XnBoeHAbidaflSMtQYGsOvUumgcJCk+=' [%s:%s ~ %s:%s]'%(XnBoeHAbidaflSMtQYGsOvUumgcJCE['startTime'][8:10],XnBoeHAbidaflSMtQYGsOvUumgcJCE['startTime'][10:12],XnBoeHAbidaflSMtQYGsOvUumgcJCE['endTime'][8:10],XnBoeHAbidaflSMtQYGsOvUumgcJCE['endTime'][10:12])+'\n'
    XnBoeHAbidaflSMtQYGsOvUumgcJCz[XnBoeHAbidaflSMtQYGsOvUumgcJCw]={'epg':XnBoeHAbidaflSMtQYGsOvUumgcJCk,'title':XnBoeHAbidaflSMtQYGsOvUumgcJCR}
  except XnBoeHAbidaflSMtQYGsOvUumgcJWC as exception:
   XnBoeHAbidaflSMtQYGsOvUumgcJFR(exception)
  return XnBoeHAbidaflSMtQYGsOvUumgcJCz
 def Get_EpgInfo_Spotv_spotvon(XnBoeHAbidaflSMtQYGsOvUumgcJDW,XnBoeHAbidaflSMtQYGsOvUumgcJCP,epgnm,now_day):
  XnBoeHAbidaflSMtQYGsOvUumgcJCz =[]
  try:
   XnBoeHAbidaflSMtQYGsOvUumgcJCp='https://www.spotvon.co.kr/data/onAir/%s/Daily/D%s.asp'%(epgnm,now_day)
   XnBoeHAbidaflSMtQYGsOvUumgcJDr=XnBoeHAbidaflSMtQYGsOvUumgcJDW.callRequestCookies('Get',XnBoeHAbidaflSMtQYGsOvUumgcJCp,payload=XnBoeHAbidaflSMtQYGsOvUumgcJFw,params=XnBoeHAbidaflSMtQYGsOvUumgcJFw,headers=XnBoeHAbidaflSMtQYGsOvUumgcJFw,cookies=XnBoeHAbidaflSMtQYGsOvUumgcJFw)
   XnBoeHAbidaflSMtQYGsOvUumgcJTD=json.loads(XnBoeHAbidaflSMtQYGsOvUumgcJDr.text)
   for XnBoeHAbidaflSMtQYGsOvUumgcJCq in XnBoeHAbidaflSMtQYGsOvUumgcJTD:
    XnBoeHAbidaflSMtQYGsOvUumgcJCV={'title':XnBoeHAbidaflSMtQYGsOvUumgcJCq['title'],'startTime':XnBoeHAbidaflSMtQYGsOvUumgcJCq['sch_date'].replace('-','')+XnBoeHAbidaflSMtQYGsOvUumgcJFE(XnBoeHAbidaflSMtQYGsOvUumgcJCq['sch_hour']).zfill(2)+XnBoeHAbidaflSMtQYGsOvUumgcJCq['sch_min']+'00'}
    XnBoeHAbidaflSMtQYGsOvUumgcJCz.append(XnBoeHAbidaflSMtQYGsOvUumgcJCV)
   for i in XnBoeHAbidaflSMtQYGsOvUumgcJWF(XnBoeHAbidaflSMtQYGsOvUumgcJWK(XnBoeHAbidaflSMtQYGsOvUumgcJCz)):
    if i>0:XnBoeHAbidaflSMtQYGsOvUumgcJCz[i-1]['endTime']=XnBoeHAbidaflSMtQYGsOvUumgcJCz[i]['startTime']
    if i==XnBoeHAbidaflSMtQYGsOvUumgcJWK(XnBoeHAbidaflSMtQYGsOvUumgcJCz)-1: XnBoeHAbidaflSMtQYGsOvUumgcJCz[i]['endTime']=now_day+'240000'
  except XnBoeHAbidaflSMtQYGsOvUumgcJWC as exception:
   XnBoeHAbidaflSMtQYGsOvUumgcJFR(exception)
   return[]
  return XnBoeHAbidaflSMtQYGsOvUumgcJCz
 def Get_EpgInfo_Spotv_spotvnet(XnBoeHAbidaflSMtQYGsOvUumgcJDW,XnBoeHAbidaflSMtQYGsOvUumgcJCP,epgnm,now_day):
  XnBoeHAbidaflSMtQYGsOvUumgcJCz =[]
  try:
   XnBoeHAbidaflSMtQYGsOvUumgcJCp='https://www.spotv.net/data/json/schedule/%s/Daily/D%s.json'%(epgnm,now_day)
   XnBoeHAbidaflSMtQYGsOvUumgcJDr=XnBoeHAbidaflSMtQYGsOvUumgcJDW.callRequestCookies('Get',XnBoeHAbidaflSMtQYGsOvUumgcJCp,payload=XnBoeHAbidaflSMtQYGsOvUumgcJFw,params=XnBoeHAbidaflSMtQYGsOvUumgcJFw,headers=XnBoeHAbidaflSMtQYGsOvUumgcJFw,cookies=XnBoeHAbidaflSMtQYGsOvUumgcJFw)
   XnBoeHAbidaflSMtQYGsOvUumgcJTD=json.loads(XnBoeHAbidaflSMtQYGsOvUumgcJDr.text)
   for XnBoeHAbidaflSMtQYGsOvUumgcJCq in XnBoeHAbidaflSMtQYGsOvUumgcJTD:
    XnBoeHAbidaflSMtQYGsOvUumgcJCV={'title':XnBoeHAbidaflSMtQYGsOvUumgcJCq['title'],'startTime':XnBoeHAbidaflSMtQYGsOvUumgcJCq['sch_date'].replace('-','')+XnBoeHAbidaflSMtQYGsOvUumgcJFE(XnBoeHAbidaflSMtQYGsOvUumgcJCq['sch_hour']).zfill(2)+XnBoeHAbidaflSMtQYGsOvUumgcJCq['sch_min']+'00'}
    XnBoeHAbidaflSMtQYGsOvUumgcJCz.append(XnBoeHAbidaflSMtQYGsOvUumgcJCV)
   for i in XnBoeHAbidaflSMtQYGsOvUumgcJWF(XnBoeHAbidaflSMtQYGsOvUumgcJWK(XnBoeHAbidaflSMtQYGsOvUumgcJCz)):
    if i>0:XnBoeHAbidaflSMtQYGsOvUumgcJCz[i-1]['endTime']=XnBoeHAbidaflSMtQYGsOvUumgcJCz[i]['startTime']
    if i==XnBoeHAbidaflSMtQYGsOvUumgcJWK(XnBoeHAbidaflSMtQYGsOvUumgcJCz)-1: XnBoeHAbidaflSMtQYGsOvUumgcJCz[i]['endTime']=now_day+'240000'
  except XnBoeHAbidaflSMtQYGsOvUumgcJWC as exception:
   XnBoeHAbidaflSMtQYGsOvUumgcJFR(exception)
   return[]
  return XnBoeHAbidaflSMtQYGsOvUumgcJCz
 def GetEventLiveList(XnBoeHAbidaflSMtQYGsOvUumgcJDW):
  XnBoeHAbidaflSMtQYGsOvUumgcJCF=[]
  XnBoeHAbidaflSMtQYGsOvUumgcJTC =0
  try:
   XnBoeHAbidaflSMtQYGsOvUumgcJTK=XnBoeHAbidaflSMtQYGsOvUumgcJDW.Get_Now_Datetime()
   XnBoeHAbidaflSMtQYGsOvUumgcJTF=XnBoeHAbidaflSMtQYGsOvUumgcJTK.strftime('%Y-%m-%d')
  except XnBoeHAbidaflSMtQYGsOvUumgcJWC as exception:
   XnBoeHAbidaflSMtQYGsOvUumgcJFR(exception)
   return XnBoeHAbidaflSMtQYGsOvUumgcJCF,XnBoeHAbidaflSMtQYGsOvUumgcJTC
  try:
   XnBoeHAbidaflSMtQYGsOvUumgcJCp=XnBoeHAbidaflSMtQYGsOvUumgcJDW.API_DOMAIN+'/api/v2/player/lives/'+XnBoeHAbidaflSMtQYGsOvUumgcJTF 
   XnBoeHAbidaflSMtQYGsOvUumgcJDp=XnBoeHAbidaflSMtQYGsOvUumgcJDW.makeDefaultCookies()
   XnBoeHAbidaflSMtQYGsOvUumgcJDr=XnBoeHAbidaflSMtQYGsOvUumgcJDW.callRequestCookies('Get',XnBoeHAbidaflSMtQYGsOvUumgcJCp,payload=XnBoeHAbidaflSMtQYGsOvUumgcJFw,params=XnBoeHAbidaflSMtQYGsOvUumgcJFw,headers=XnBoeHAbidaflSMtQYGsOvUumgcJFw,cookies=XnBoeHAbidaflSMtQYGsOvUumgcJDp)
   XnBoeHAbidaflSMtQYGsOvUumgcJTC=XnBoeHAbidaflSMtQYGsOvUumgcJDr.status_code 
   XnBoeHAbidaflSMtQYGsOvUumgcJDP=json.loads(XnBoeHAbidaflSMtQYGsOvUumgcJDr.text)
   for XnBoeHAbidaflSMtQYGsOvUumgcJTW in XnBoeHAbidaflSMtQYGsOvUumgcJDP:
    for XnBoeHAbidaflSMtQYGsOvUumgcJCq in XnBoeHAbidaflSMtQYGsOvUumgcJTW['liveNowList']:
     if XnBoeHAbidaflSMtQYGsOvUumgcJCq['gameDesc']['title']==XnBoeHAbidaflSMtQYGsOvUumgcJFw or XnBoeHAbidaflSMtQYGsOvUumgcJCq['gameDesc']['title']=='':
      XnBoeHAbidaflSMtQYGsOvUumgcJTq='%s ( %s : %s )'%(XnBoeHAbidaflSMtQYGsOvUumgcJCq['leagueName'],XnBoeHAbidaflSMtQYGsOvUumgcJCq['homeNameShort'],XnBoeHAbidaflSMtQYGsOvUumgcJCq['awayNameShort'])
     else:
      XnBoeHAbidaflSMtQYGsOvUumgcJTq=XnBoeHAbidaflSMtQYGsOvUumgcJCq['gameDesc']['title']
     XnBoeHAbidaflSMtQYGsOvUumgcJCV={'liveId':XnBoeHAbidaflSMtQYGsOvUumgcJCq['liveId'],'title':XnBoeHAbidaflSMtQYGsOvUumgcJTq,'logo':XnBoeHAbidaflSMtQYGsOvUumgcJCq['gameDesc']['leagueLogo'],'free':XnBoeHAbidaflSMtQYGsOvUumgcJCq['isFree'],'startTime':XnBoeHAbidaflSMtQYGsOvUumgcJCq['startTime']}
     XnBoeHAbidaflSMtQYGsOvUumgcJCF.append(XnBoeHAbidaflSMtQYGsOvUumgcJCV)
  except XnBoeHAbidaflSMtQYGsOvUumgcJWC as exception:
   XnBoeHAbidaflSMtQYGsOvUumgcJFR(exception)
  return XnBoeHAbidaflSMtQYGsOvUumgcJCF,XnBoeHAbidaflSMtQYGsOvUumgcJTC
 def GetEventLive_videoId(XnBoeHAbidaflSMtQYGsOvUumgcJDW,liveId):
  XnBoeHAbidaflSMtQYGsOvUumgcJTV=''
  try:
   XnBoeHAbidaflSMtQYGsOvUumgcJCp=XnBoeHAbidaflSMtQYGsOvUumgcJDW.API_DOMAIN+'/api/v2/live/'+liveId
   XnBoeHAbidaflSMtQYGsOvUumgcJDr=XnBoeHAbidaflSMtQYGsOvUumgcJDW.callRequestCookies('Get',XnBoeHAbidaflSMtQYGsOvUumgcJCp,payload=XnBoeHAbidaflSMtQYGsOvUumgcJFw,params=XnBoeHAbidaflSMtQYGsOvUumgcJFw,headers=XnBoeHAbidaflSMtQYGsOvUumgcJFw,cookies=XnBoeHAbidaflSMtQYGsOvUumgcJFw)
   XnBoeHAbidaflSMtQYGsOvUumgcJDP=json.loads(XnBoeHAbidaflSMtQYGsOvUumgcJDr.text)
   XnBoeHAbidaflSMtQYGsOvUumgcJTp=XnBoeHAbidaflSMtQYGsOvUumgcJDP['videoId']
   XnBoeHAbidaflSMtQYGsOvUumgcJTV=XnBoeHAbidaflSMtQYGsOvUumgcJTp.replace('ref:','')
  except XnBoeHAbidaflSMtQYGsOvUumgcJWC as exception:
   XnBoeHAbidaflSMtQYGsOvUumgcJFR(exception)
  return XnBoeHAbidaflSMtQYGsOvUumgcJTV
 def CheckMainEnd(XnBoeHAbidaflSMtQYGsOvUumgcJDW):
  XnBoeHAbidaflSMtQYGsOvUumgcJTz=base64.standard_b64encode((XnBoeHAbidaflSMtQYGsOvUumgcJDW.SPOTV_PMCODE+XnBoeHAbidaflSMtQYGsOvUumgcJDW.SPOTV_SESSIONID).encode()).decode('utf-8')
  if XnBoeHAbidaflSMtQYGsOvUumgcJTz=='OTg3MTgzMzM0Ng==' or XnBoeHAbidaflSMtQYGsOvUumgcJTz=='OTg3MTgzMzExNw==':return XnBoeHAbidaflSMtQYGsOvUumgcJWD
  return XnBoeHAbidaflSMtQYGsOvUumgcJFj
 def CheckSubEnd(XnBoeHAbidaflSMtQYGsOvUumgcJDW):
  XnBoeHAbidaflSMtQYGsOvUumgcJTy=XnBoeHAbidaflSMtQYGsOvUumgcJFj
  try:
   if XnBoeHAbidaflSMtQYGsOvUumgcJDW.CheckMainEnd():return XnBoeHAbidaflSMtQYGsOvUumgcJWD 
   if XnBoeHAbidaflSMtQYGsOvUumgcJDW.SPOTV_SUBEND=='0':return XnBoeHAbidaflSMtQYGsOvUumgcJTy
   XnBoeHAbidaflSMtQYGsOvUumgcJTx =XnBoeHAbidaflSMtQYGsOvUumgcJWT(XnBoeHAbidaflSMtQYGsOvUumgcJDW.Get_Now_Datetime().strftime('%Y%m%d'))
   XnBoeHAbidaflSMtQYGsOvUumgcJTL =XnBoeHAbidaflSMtQYGsOvUumgcJWT(XnBoeHAbidaflSMtQYGsOvUumgcJDW.SPOTV_SUBEND)/1000
   XnBoeHAbidaflSMtQYGsOvUumgcJTN =XnBoeHAbidaflSMtQYGsOvUumgcJWT(datetime.datetime.fromtimestamp(XnBoeHAbidaflSMtQYGsOvUumgcJTL,datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul')).strftime('%Y%m%d'))
   if XnBoeHAbidaflSMtQYGsOvUumgcJTx<=XnBoeHAbidaflSMtQYGsOvUumgcJTN:XnBoeHAbidaflSMtQYGsOvUumgcJTy=XnBoeHAbidaflSMtQYGsOvUumgcJWD
  except XnBoeHAbidaflSMtQYGsOvUumgcJWC as exception:
   XnBoeHAbidaflSMtQYGsOvUumgcJFR(exception)
   return XnBoeHAbidaflSMtQYGsOvUumgcJTy
  return XnBoeHAbidaflSMtQYGsOvUumgcJTy
 def GetMainJspath(XnBoeHAbidaflSMtQYGsOvUumgcJDW):
  XnBoeHAbidaflSMtQYGsOvUumgcJTI=''
  try:
   XnBoeHAbidaflSMtQYGsOvUumgcJCp=XnBoeHAbidaflSMtQYGsOvUumgcJDW.API_DOMAIN
   XnBoeHAbidaflSMtQYGsOvUumgcJDr=XnBoeHAbidaflSMtQYGsOvUumgcJDW.callRequestCookies('Get',XnBoeHAbidaflSMtQYGsOvUumgcJCp,payload=XnBoeHAbidaflSMtQYGsOvUumgcJFw,params=XnBoeHAbidaflSMtQYGsOvUumgcJFw,headers=XnBoeHAbidaflSMtQYGsOvUumgcJFw,cookies=XnBoeHAbidaflSMtQYGsOvUumgcJFw)
   XnBoeHAbidaflSMtQYGsOvUumgcJTk=XnBoeHAbidaflSMtQYGsOvUumgcJDr.text
   XnBoeHAbidaflSMtQYGsOvUumgcJTr =re.findall('https://cdn.spotvnow.co.kr/dist/js/.{20}\.js',XnBoeHAbidaflSMtQYGsOvUumgcJTk)[0]
   XnBoeHAbidaflSMtQYGsOvUumgcJTI=XnBoeHAbidaflSMtQYGsOvUumgcJTr
  except XnBoeHAbidaflSMtQYGsOvUumgcJWC as exception:
   XnBoeHAbidaflSMtQYGsOvUumgcJFR(exception)
  return XnBoeHAbidaflSMtQYGsOvUumgcJTI
 def GetBcPlayerUrl(XnBoeHAbidaflSMtQYGsOvUumgcJDW):
  XnBoeHAbidaflSMtQYGsOvUumgcJTh=''
  try:
   XnBoeHAbidaflSMtQYGsOvUumgcJCp=XnBoeHAbidaflSMtQYGsOvUumgcJDW.GetMainJspath()
   if XnBoeHAbidaflSMtQYGsOvUumgcJCp=='':return XnBoeHAbidaflSMtQYGsOvUumgcJTh
   XnBoeHAbidaflSMtQYGsOvUumgcJDr=XnBoeHAbidaflSMtQYGsOvUumgcJDW.callRequestCookies('Get',XnBoeHAbidaflSMtQYGsOvUumgcJCp,payload=XnBoeHAbidaflSMtQYGsOvUumgcJFw,params=XnBoeHAbidaflSMtQYGsOvUumgcJFw,headers=XnBoeHAbidaflSMtQYGsOvUumgcJFw,cookies=XnBoeHAbidaflSMtQYGsOvUumgcJFw)
   XnBoeHAbidaflSMtQYGsOvUumgcJTk=XnBoeHAbidaflSMtQYGsOvUumgcJDr.text
   XnBoeHAbidaflSMtQYGsOvUumgcJTk=XnBoeHAbidaflSMtQYGsOvUumgcJDr.text
   XnBoeHAbidaflSMtQYGsOvUumgcJTj =r'default:{(.*?)}'
   XnBoeHAbidaflSMtQYGsOvUumgcJTP =re.compile(XnBoeHAbidaflSMtQYGsOvUumgcJTj).findall(XnBoeHAbidaflSMtQYGsOvUumgcJTk)[0]
   XnBoeHAbidaflSMtQYGsOvUumgcJTw=r'bc:"(.*?)"'
   XnBoeHAbidaflSMtQYGsOvUumgcJTR=re.compile(XnBoeHAbidaflSMtQYGsOvUumgcJTw).findall(XnBoeHAbidaflSMtQYGsOvUumgcJTP)[0]
   XnBoeHAbidaflSMtQYGsOvUumgcJTE=r'":"(.*?)"'
   XnBoeHAbidaflSMtQYGsOvUumgcJKD=re.compile(XnBoeHAbidaflSMtQYGsOvUumgcJTE).findall(XnBoeHAbidaflSMtQYGsOvUumgcJTP)[0]
   bc =XnBoeHAbidaflSMtQYGsOvUumgcJTR 
   XnBoeHAbidaflSMtQYGsOvUumgcJKC=XnBoeHAbidaflSMtQYGsOvUumgcJKD 
   XnBoeHAbidaflSMtQYGsOvUumgcJTh="%s/%s/%s_default/index.min.js"%(XnBoeHAbidaflSMtQYGsOvUumgcJDW.BC_DOMAIN,bc,XnBoeHAbidaflSMtQYGsOvUumgcJKC)
  except XnBoeHAbidaflSMtQYGsOvUumgcJWC as exception:
   XnBoeHAbidaflSMtQYGsOvUumgcJFR(exception)
  return XnBoeHAbidaflSMtQYGsOvUumgcJTh
 def GetPolicyKey(XnBoeHAbidaflSMtQYGsOvUumgcJDW):
  XnBoeHAbidaflSMtQYGsOvUumgcJKT=policykey=''
  try:
   XnBoeHAbidaflSMtQYGsOvUumgcJCp=XnBoeHAbidaflSMtQYGsOvUumgcJDW.GetBcPlayerUrl()
   if XnBoeHAbidaflSMtQYGsOvUumgcJCp=='':return XnBoeHAbidaflSMtQYGsOvUumgcJKT,policykey
   XnBoeHAbidaflSMtQYGsOvUumgcJDr=XnBoeHAbidaflSMtQYGsOvUumgcJDW.callRequestCookies('Get',XnBoeHAbidaflSMtQYGsOvUumgcJCp,payload=XnBoeHAbidaflSMtQYGsOvUumgcJFw,params=XnBoeHAbidaflSMtQYGsOvUumgcJFw,headers=XnBoeHAbidaflSMtQYGsOvUumgcJFw,cookies=XnBoeHAbidaflSMtQYGsOvUumgcJFw)
   XnBoeHAbidaflSMtQYGsOvUumgcJTk=XnBoeHAbidaflSMtQYGsOvUumgcJDr.text
   XnBoeHAbidaflSMtQYGsOvUumgcJTr =re.findall('accountId:\s*\"\d{13}\",\s*policyKey:\s*\".[^(){}]{100,300}\"',XnBoeHAbidaflSMtQYGsOvUumgcJTk)[0]
   XnBoeHAbidaflSMtQYGsOvUumgcJTr =XnBoeHAbidaflSMtQYGsOvUumgcJTr.replace('accountId','"accountId"')
   XnBoeHAbidaflSMtQYGsOvUumgcJTr =XnBoeHAbidaflSMtQYGsOvUumgcJTr.replace('policyKey','"policyKey"')
   XnBoeHAbidaflSMtQYGsOvUumgcJTr ='{'+XnBoeHAbidaflSMtQYGsOvUumgcJTr+'}'
   XnBoeHAbidaflSMtQYGsOvUumgcJKF=json.loads(XnBoeHAbidaflSMtQYGsOvUumgcJTr)
   XnBoeHAbidaflSMtQYGsOvUumgcJKT =XnBoeHAbidaflSMtQYGsOvUumgcJKF['accountId']
   XnBoeHAbidaflSMtQYGsOvUumgcJKW =XnBoeHAbidaflSMtQYGsOvUumgcJKF['policyKey']
  except XnBoeHAbidaflSMtQYGsOvUumgcJWC as exception:
   XnBoeHAbidaflSMtQYGsOvUumgcJFR(exception)
  return XnBoeHAbidaflSMtQYGsOvUumgcJKT,XnBoeHAbidaflSMtQYGsOvUumgcJKW
 def GetBroadURL(XnBoeHAbidaflSMtQYGsOvUumgcJDW,XnBoeHAbidaflSMtQYGsOvUumgcJTV,mediatype,XnBoeHAbidaflSMtQYGsOvUumgcJKr):
  XnBoeHAbidaflSMtQYGsOvUumgcJKq=''
  try:
   if mediatype=='live':
    XnBoeHAbidaflSMtQYGsOvUumgcJTV='ref%3A'+XnBoeHAbidaflSMtQYGsOvUumgcJTV
   else:
    XnBoeHAbidaflSMtQYGsOvUumgcJTV=XnBoeHAbidaflSMtQYGsOvUumgcJDW.GetReplay_UrlId(XnBoeHAbidaflSMtQYGsOvUumgcJTV,XnBoeHAbidaflSMtQYGsOvUumgcJKr)
    if XnBoeHAbidaflSMtQYGsOvUumgcJTV=='':return XnBoeHAbidaflSMtQYGsOvUumgcJKq
   XnBoeHAbidaflSMtQYGsOvUumgcJCp=XnBoeHAbidaflSMtQYGsOvUumgcJDW.PLAYER_DOMAIN+'/playback/v1/accounts/'+XnBoeHAbidaflSMtQYGsOvUumgcJDW.SPOTV_ACCOUNTID+'/videos/'+XnBoeHAbidaflSMtQYGsOvUumgcJTV
   XnBoeHAbidaflSMtQYGsOvUumgcJKV={'accept':'application/json;pk='+XnBoeHAbidaflSMtQYGsOvUumgcJDW.SPOTV_POLICYKEY}
   XnBoeHAbidaflSMtQYGsOvUumgcJDr=XnBoeHAbidaflSMtQYGsOvUumgcJDW.callRequestCookies('Get',XnBoeHAbidaflSMtQYGsOvUumgcJCp,payload=XnBoeHAbidaflSMtQYGsOvUumgcJFw,params=XnBoeHAbidaflSMtQYGsOvUumgcJFw,headers=XnBoeHAbidaflSMtQYGsOvUumgcJKV,cookies=XnBoeHAbidaflSMtQYGsOvUumgcJFw)
   XnBoeHAbidaflSMtQYGsOvUumgcJTD=json.loads(XnBoeHAbidaflSMtQYGsOvUumgcJDr.text)
   XnBoeHAbidaflSMtQYGsOvUumgcJKq=XnBoeHAbidaflSMtQYGsOvUumgcJTD['sources'][0]['src']
   if mediatype=='live':
    XnBoeHAbidaflSMtQYGsOvUumgcJKq=XnBoeHAbidaflSMtQYGsOvUumgcJKq.replace('playlist.m3u8','playlist_dvr.m3u8')
   XnBoeHAbidaflSMtQYGsOvUumgcJKq=XnBoeHAbidaflSMtQYGsOvUumgcJKq.replace('http://','https://')
  except XnBoeHAbidaflSMtQYGsOvUumgcJWC as exception:
   XnBoeHAbidaflSMtQYGsOvUumgcJFR(exception)
  return XnBoeHAbidaflSMtQYGsOvUumgcJKq
 def GetTitleGroupList(XnBoeHAbidaflSMtQYGsOvUumgcJDW):
  XnBoeHAbidaflSMtQYGsOvUumgcJCF=[]
  XnBoeHAbidaflSMtQYGsOvUumgcJKp=XnBoeHAbidaflSMtQYGsOvUumgcJFj
  try:
   XnBoeHAbidaflSMtQYGsOvUumgcJCp=XnBoeHAbidaflSMtQYGsOvUumgcJDW.API_DOMAIN+'/api/v2/home/web'
   XnBoeHAbidaflSMtQYGsOvUumgcJDr=XnBoeHAbidaflSMtQYGsOvUumgcJDW.callRequestCookies('Get',XnBoeHAbidaflSMtQYGsOvUumgcJCp,payload=XnBoeHAbidaflSMtQYGsOvUumgcJFw,params=XnBoeHAbidaflSMtQYGsOvUumgcJFw,headers=XnBoeHAbidaflSMtQYGsOvUumgcJFw,cookies=XnBoeHAbidaflSMtQYGsOvUumgcJFw)
   XnBoeHAbidaflSMtQYGsOvUumgcJDP=json.loads(XnBoeHAbidaflSMtQYGsOvUumgcJDr.text)
   for XnBoeHAbidaflSMtQYGsOvUumgcJCq in XnBoeHAbidaflSMtQYGsOvUumgcJDP:
    if XnBoeHAbidaflSMtQYGsOvUumgcJFE(XnBoeHAbidaflSMtQYGsOvUumgcJCq['type'])=='3':
     XnBoeHAbidaflSMtQYGsOvUumgcJKz=''
     for XnBoeHAbidaflSMtQYGsOvUumgcJKy in XnBoeHAbidaflSMtQYGsOvUumgcJCq['data']['list']:
      XnBoeHAbidaflSMtQYGsOvUumgcJKx='[%s] %s vs %s\n<%s>\n\n'%(XnBoeHAbidaflSMtQYGsOvUumgcJKy['gameDesc']['roundName'],XnBoeHAbidaflSMtQYGsOvUumgcJKy['gameDesc']['homeNameShort'],XnBoeHAbidaflSMtQYGsOvUumgcJKy['gameDesc']['awayNameShort'],XnBoeHAbidaflSMtQYGsOvUumgcJKy['gameDesc']['beginDate'])
      XnBoeHAbidaflSMtQYGsOvUumgcJKz+=XnBoeHAbidaflSMtQYGsOvUumgcJKx
     XnBoeHAbidaflSMtQYGsOvUumgcJCV={'title':XnBoeHAbidaflSMtQYGsOvUumgcJCq['title'],'logo':XnBoeHAbidaflSMtQYGsOvUumgcJCq['logo'],'reagueId':XnBoeHAbidaflSMtQYGsOvUumgcJFE(XnBoeHAbidaflSMtQYGsOvUumgcJCq['destId']),'subGame':XnBoeHAbidaflSMtQYGsOvUumgcJKz}
     XnBoeHAbidaflSMtQYGsOvUumgcJCF.append(XnBoeHAbidaflSMtQYGsOvUumgcJCV)
     if XnBoeHAbidaflSMtQYGsOvUumgcJFE(XnBoeHAbidaflSMtQYGsOvUumgcJCq['destId'])=='13':XnBoeHAbidaflSMtQYGsOvUumgcJKp=XnBoeHAbidaflSMtQYGsOvUumgcJWD
   if XnBoeHAbidaflSMtQYGsOvUumgcJKp==XnBoeHAbidaflSMtQYGsOvUumgcJFj:
    XnBoeHAbidaflSMtQYGsOvUumgcJCV={'title':'UFC','logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200928/a643c7cf1c285fb0b4469c07d4c09c28.png','reagueId':'13','subGame':''}
    XnBoeHAbidaflSMtQYGsOvUumgcJCF.append(XnBoeHAbidaflSMtQYGsOvUumgcJCV)
  except XnBoeHAbidaflSMtQYGsOvUumgcJWC as exception:
   XnBoeHAbidaflSMtQYGsOvUumgcJFR(exception)
  return XnBoeHAbidaflSMtQYGsOvUumgcJCF
 def GetPopularGroupList(XnBoeHAbidaflSMtQYGsOvUumgcJDW):
  XnBoeHAbidaflSMtQYGsOvUumgcJCF=[]
  try:
   XnBoeHAbidaflSMtQYGsOvUumgcJCp=XnBoeHAbidaflSMtQYGsOvUumgcJDW.API_DOMAIN+'/api/v2/home/web'
   XnBoeHAbidaflSMtQYGsOvUumgcJDr=XnBoeHAbidaflSMtQYGsOvUumgcJDW.callRequestCookies('Get',XnBoeHAbidaflSMtQYGsOvUumgcJCp,payload=XnBoeHAbidaflSMtQYGsOvUumgcJFw,params=XnBoeHAbidaflSMtQYGsOvUumgcJFw,headers=XnBoeHAbidaflSMtQYGsOvUumgcJFw,cookies=XnBoeHAbidaflSMtQYGsOvUumgcJFw)
   XnBoeHAbidaflSMtQYGsOvUumgcJDP=json.loads(XnBoeHAbidaflSMtQYGsOvUumgcJDr.text)
   for XnBoeHAbidaflSMtQYGsOvUumgcJCq in XnBoeHAbidaflSMtQYGsOvUumgcJDP:
    if XnBoeHAbidaflSMtQYGsOvUumgcJFE(XnBoeHAbidaflSMtQYGsOvUumgcJCq['type'])=='1' and XnBoeHAbidaflSMtQYGsOvUumgcJFE(XnBoeHAbidaflSMtQYGsOvUumgcJCq['destId'])=='4':
     for XnBoeHAbidaflSMtQYGsOvUumgcJKy in XnBoeHAbidaflSMtQYGsOvUumgcJCq['data']['list']:
      XnBoeHAbidaflSMtQYGsOvUumgcJKL =XnBoeHAbidaflSMtQYGsOvUumgcJKy['title']
      XnBoeHAbidaflSMtQYGsOvUumgcJKN =XnBoeHAbidaflSMtQYGsOvUumgcJKy['id']
      XnBoeHAbidaflSMtQYGsOvUumgcJKI =XnBoeHAbidaflSMtQYGsOvUumgcJKy['vtype']
      XnBoeHAbidaflSMtQYGsOvUumgcJKk =XnBoeHAbidaflSMtQYGsOvUumgcJKy['imgUrl']
      XnBoeHAbidaflSMtQYGsOvUumgcJKr =XnBoeHAbidaflSMtQYGsOvUumgcJKy['vtypeId']
      XnBoeHAbidaflSMtQYGsOvUumgcJCV={'vodTitle':XnBoeHAbidaflSMtQYGsOvUumgcJKL,'vodId':XnBoeHAbidaflSMtQYGsOvUumgcJKN,'vodType':XnBoeHAbidaflSMtQYGsOvUumgcJKI,'thumbnail':XnBoeHAbidaflSMtQYGsOvUumgcJKk,'vtypeId':XnBoeHAbidaflSMtQYGsOvUumgcJFE(XnBoeHAbidaflSMtQYGsOvUumgcJKr),'duration':XnBoeHAbidaflSMtQYGsOvUumgcJWT(XnBoeHAbidaflSMtQYGsOvUumgcJKy['duration']/1000)}
      XnBoeHAbidaflSMtQYGsOvUumgcJCF.append(XnBoeHAbidaflSMtQYGsOvUumgcJCV)
  except XnBoeHAbidaflSMtQYGsOvUumgcJWC as exception:
   XnBoeHAbidaflSMtQYGsOvUumgcJFR(exception)
  return XnBoeHAbidaflSMtQYGsOvUumgcJCF
 def Get_NowVod_GroupList(XnBoeHAbidaflSMtQYGsOvUumgcJDW,page_int):
  XnBoeHAbidaflSMtQYGsOvUumgcJCF=[]
  XnBoeHAbidaflSMtQYGsOvUumgcJKh=XnBoeHAbidaflSMtQYGsOvUumgcJFj
  try:
   XnBoeHAbidaflSMtQYGsOvUumgcJCp=XnBoeHAbidaflSMtQYGsOvUumgcJDW.API_DOMAIN+'/api/v2/theme/14/list'
   XnBoeHAbidaflSMtQYGsOvUumgcJKj={'pageItem':'10','pageNo':XnBoeHAbidaflSMtQYGsOvUumgcJFE(page_int)}
   XnBoeHAbidaflSMtQYGsOvUumgcJDr=XnBoeHAbidaflSMtQYGsOvUumgcJDW.callRequestCookies('Get',XnBoeHAbidaflSMtQYGsOvUumgcJCp,payload=XnBoeHAbidaflSMtQYGsOvUumgcJFw,params=XnBoeHAbidaflSMtQYGsOvUumgcJKj,headers=XnBoeHAbidaflSMtQYGsOvUumgcJFw,cookies=XnBoeHAbidaflSMtQYGsOvUumgcJFw)
   XnBoeHAbidaflSMtQYGsOvUumgcJDP=json.loads(XnBoeHAbidaflSMtQYGsOvUumgcJDr.text)
   for XnBoeHAbidaflSMtQYGsOvUumgcJCq in XnBoeHAbidaflSMtQYGsOvUumgcJDP['list']:
    XnBoeHAbidaflSMtQYGsOvUumgcJKL =XnBoeHAbidaflSMtQYGsOvUumgcJCq['title']
    XnBoeHAbidaflSMtQYGsOvUumgcJKN =XnBoeHAbidaflSMtQYGsOvUumgcJCq['id']
    XnBoeHAbidaflSMtQYGsOvUumgcJKI =XnBoeHAbidaflSMtQYGsOvUumgcJCq['vtype']
    XnBoeHAbidaflSMtQYGsOvUumgcJKk =XnBoeHAbidaflSMtQYGsOvUumgcJCq['imgUrl']
    XnBoeHAbidaflSMtQYGsOvUumgcJKr =XnBoeHAbidaflSMtQYGsOvUumgcJCq['vtypeId']
    XnBoeHAbidaflSMtQYGsOvUumgcJCV={'vodTitle':XnBoeHAbidaflSMtQYGsOvUumgcJKL,'vodId':XnBoeHAbidaflSMtQYGsOvUumgcJKN,'vodType':XnBoeHAbidaflSMtQYGsOvUumgcJKI,'thumbnail':XnBoeHAbidaflSMtQYGsOvUumgcJKk,'vtypeId':XnBoeHAbidaflSMtQYGsOvUumgcJFE(XnBoeHAbidaflSMtQYGsOvUumgcJKr),'duration':XnBoeHAbidaflSMtQYGsOvUumgcJWT(XnBoeHAbidaflSMtQYGsOvUumgcJCq['duration']/1000),}
    XnBoeHAbidaflSMtQYGsOvUumgcJCF.append(XnBoeHAbidaflSMtQYGsOvUumgcJCV)
    if XnBoeHAbidaflSMtQYGsOvUumgcJDP['count']>page_int*XnBoeHAbidaflSMtQYGsOvUumgcJDW.GAMELIST_LIMIT:XnBoeHAbidaflSMtQYGsOvUumgcJKh=XnBoeHAbidaflSMtQYGsOvUumgcJWD
  except XnBoeHAbidaflSMtQYGsOvUumgcJWC as exception:
   XnBoeHAbidaflSMtQYGsOvUumgcJFR(exception)
  return XnBoeHAbidaflSMtQYGsOvUumgcJCF,XnBoeHAbidaflSMtQYGsOvUumgcJKh
 def GetSeasonList(XnBoeHAbidaflSMtQYGsOvUumgcJDW,leagueId):
  XnBoeHAbidaflSMtQYGsOvUumgcJCF=[]
  XnBoeHAbidaflSMtQYGsOvUumgcJKP=XnBoeHAbidaflSMtQYGsOvUumgcJKw=''
  try:
   XnBoeHAbidaflSMtQYGsOvUumgcJCp=XnBoeHAbidaflSMtQYGsOvUumgcJDW.API_DOMAIN+'/api/v2/game/league/'+leagueId
   XnBoeHAbidaflSMtQYGsOvUumgcJDr=XnBoeHAbidaflSMtQYGsOvUumgcJDW.callRequestCookies('Get',XnBoeHAbidaflSMtQYGsOvUumgcJCp,payload=XnBoeHAbidaflSMtQYGsOvUumgcJFw,params=XnBoeHAbidaflSMtQYGsOvUumgcJFw,headers=XnBoeHAbidaflSMtQYGsOvUumgcJFw,cookies=XnBoeHAbidaflSMtQYGsOvUumgcJFw)
   XnBoeHAbidaflSMtQYGsOvUumgcJDP=json.loads(XnBoeHAbidaflSMtQYGsOvUumgcJDr.text)
   XnBoeHAbidaflSMtQYGsOvUumgcJKP=XnBoeHAbidaflSMtQYGsOvUumgcJDP['name']
   XnBoeHAbidaflSMtQYGsOvUumgcJKw=XnBoeHAbidaflSMtQYGsOvUumgcJFE(XnBoeHAbidaflSMtQYGsOvUumgcJDP['gameTypeId'])
  except XnBoeHAbidaflSMtQYGsOvUumgcJWC as exception:
   XnBoeHAbidaflSMtQYGsOvUumgcJFR(exception)
   return XnBoeHAbidaflSMtQYGsOvUumgcJCF
  if XnBoeHAbidaflSMtQYGsOvUumgcJKw=='2':
   try:
    XnBoeHAbidaflSMtQYGsOvUumgcJCp=XnBoeHAbidaflSMtQYGsOvUumgcJDW.API_DOMAIN+'/api/v2/year/'+leagueId
    XnBoeHAbidaflSMtQYGsOvUumgcJDr=XnBoeHAbidaflSMtQYGsOvUumgcJDW.callRequestCookies('Get',XnBoeHAbidaflSMtQYGsOvUumgcJCp,payload=XnBoeHAbidaflSMtQYGsOvUumgcJFw,params=XnBoeHAbidaflSMtQYGsOvUumgcJFw,headers=XnBoeHAbidaflSMtQYGsOvUumgcJFw,cookies=XnBoeHAbidaflSMtQYGsOvUumgcJFw)
    XnBoeHAbidaflSMtQYGsOvUumgcJDP=json.loads(XnBoeHAbidaflSMtQYGsOvUumgcJDr.text)
    for XnBoeHAbidaflSMtQYGsOvUumgcJCq in XnBoeHAbidaflSMtQYGsOvUumgcJDP:
     XnBoeHAbidaflSMtQYGsOvUumgcJCV={'reagueName':XnBoeHAbidaflSMtQYGsOvUumgcJKP,'gameTypeId':XnBoeHAbidaflSMtQYGsOvUumgcJKw,'seasonName':XnBoeHAbidaflSMtQYGsOvUumgcJFE(XnBoeHAbidaflSMtQYGsOvUumgcJCq),'seasonId':XnBoeHAbidaflSMtQYGsOvUumgcJFE(XnBoeHAbidaflSMtQYGsOvUumgcJCq)}
     XnBoeHAbidaflSMtQYGsOvUumgcJCF.append(XnBoeHAbidaflSMtQYGsOvUumgcJCV)
   except XnBoeHAbidaflSMtQYGsOvUumgcJWC as exception:
    XnBoeHAbidaflSMtQYGsOvUumgcJFR(exception)
    return[]
  else:
   try:
    XnBoeHAbidaflSMtQYGsOvUumgcJCp=XnBoeHAbidaflSMtQYGsOvUumgcJDW.API_DOMAIN+'/api/v2/season/'+leagueId
    XnBoeHAbidaflSMtQYGsOvUumgcJDr=XnBoeHAbidaflSMtQYGsOvUumgcJDW.callRequestCookies('Get',XnBoeHAbidaflSMtQYGsOvUumgcJCp,payload=XnBoeHAbidaflSMtQYGsOvUumgcJFw,params=XnBoeHAbidaflSMtQYGsOvUumgcJFw,headers=XnBoeHAbidaflSMtQYGsOvUumgcJFw,cookies=XnBoeHAbidaflSMtQYGsOvUumgcJFw)
    XnBoeHAbidaflSMtQYGsOvUumgcJDP=json.loads(XnBoeHAbidaflSMtQYGsOvUumgcJDr.text)
    for XnBoeHAbidaflSMtQYGsOvUumgcJCq in XnBoeHAbidaflSMtQYGsOvUumgcJDP:
     XnBoeHAbidaflSMtQYGsOvUumgcJCV={'reagueName':XnBoeHAbidaflSMtQYGsOvUumgcJKP,'gameTypeId':XnBoeHAbidaflSMtQYGsOvUumgcJKw,'seasonName':XnBoeHAbidaflSMtQYGsOvUumgcJCq['name'],'seasonId':XnBoeHAbidaflSMtQYGsOvUumgcJFE(XnBoeHAbidaflSMtQYGsOvUumgcJCq['id'])}
     XnBoeHAbidaflSMtQYGsOvUumgcJCF.append(XnBoeHAbidaflSMtQYGsOvUumgcJCV)
   except XnBoeHAbidaflSMtQYGsOvUumgcJWC as exception:
    XnBoeHAbidaflSMtQYGsOvUumgcJFR(exception)
    return[]
  return XnBoeHAbidaflSMtQYGsOvUumgcJCF
 def GetGameList(XnBoeHAbidaflSMtQYGsOvUumgcJDW,XnBoeHAbidaflSMtQYGsOvUumgcJKw,leagueId,seasonId,page_int,hidescore=XnBoeHAbidaflSMtQYGsOvUumgcJWD):
  XnBoeHAbidaflSMtQYGsOvUumgcJCF=[]
  XnBoeHAbidaflSMtQYGsOvUumgcJKh=XnBoeHAbidaflSMtQYGsOvUumgcJFj
  try:
   XnBoeHAbidaflSMtQYGsOvUumgcJCp=XnBoeHAbidaflSMtQYGsOvUumgcJDW.API_DOMAIN+'/api/v2/vod/league/detail'
   XnBoeHAbidaflSMtQYGsOvUumgcJKj={'gameType':XnBoeHAbidaflSMtQYGsOvUumgcJKw,'leagueId':leagueId,'seasonId':seasonId if XnBoeHAbidaflSMtQYGsOvUumgcJKw!='2' else '','teamId':'','roundId':'','year':'' if XnBoeHAbidaflSMtQYGsOvUumgcJKw!='2' else seasonId,'pageNo':XnBoeHAbidaflSMtQYGsOvUumgcJFE(page_int)}
   XnBoeHAbidaflSMtQYGsOvUumgcJDr=XnBoeHAbidaflSMtQYGsOvUumgcJDW.callRequestCookies('Get',XnBoeHAbidaflSMtQYGsOvUumgcJCp,payload=XnBoeHAbidaflSMtQYGsOvUumgcJFw,params=XnBoeHAbidaflSMtQYGsOvUumgcJKj,headers=XnBoeHAbidaflSMtQYGsOvUumgcJFw,cookies=XnBoeHAbidaflSMtQYGsOvUumgcJFw)
   XnBoeHAbidaflSMtQYGsOvUumgcJDP=json.loads(XnBoeHAbidaflSMtQYGsOvUumgcJDr.text)
   XnBoeHAbidaflSMtQYGsOvUumgcJTW=XnBoeHAbidaflSMtQYGsOvUumgcJDP['list']
   for XnBoeHAbidaflSMtQYGsOvUumgcJKR in XnBoeHAbidaflSMtQYGsOvUumgcJTW:
    for XnBoeHAbidaflSMtQYGsOvUumgcJCq in XnBoeHAbidaflSMtQYGsOvUumgcJKR['list']:
     if XnBoeHAbidaflSMtQYGsOvUumgcJCq['gameDesc']['title']==XnBoeHAbidaflSMtQYGsOvUumgcJFw or XnBoeHAbidaflSMtQYGsOvUumgcJCq['gameDesc']['title']=='':
      XnBoeHAbidaflSMtQYGsOvUumgcJTq ='%s vs %s'%(XnBoeHAbidaflSMtQYGsOvUumgcJCq['gameDesc']['homeNameShort'],XnBoeHAbidaflSMtQYGsOvUumgcJCq['gameDesc']['awayNameShort'])
     else:
      XnBoeHAbidaflSMtQYGsOvUumgcJTq =XnBoeHAbidaflSMtQYGsOvUumgcJCq['gameDesc']['title']
     XnBoeHAbidaflSMtQYGsOvUumgcJKE =XnBoeHAbidaflSMtQYGsOvUumgcJCq['gameDesc']['beginDate']
     XnBoeHAbidaflSMtQYGsOvUumgcJFD =XnBoeHAbidaflSMtQYGsOvUumgcJCq['gameDesc']['id']
     XnBoeHAbidaflSMtQYGsOvUumgcJFC =XnBoeHAbidaflSMtQYGsOvUumgcJCq['gameDesc']['leagueNameFull']
     XnBoeHAbidaflSMtQYGsOvUumgcJFT =XnBoeHAbidaflSMtQYGsOvUumgcJCq['gameDesc']['seasonName']
     XnBoeHAbidaflSMtQYGsOvUumgcJFK =XnBoeHAbidaflSMtQYGsOvUumgcJCq['gameDesc']['roundName']
     XnBoeHAbidaflSMtQYGsOvUumgcJFW =XnBoeHAbidaflSMtQYGsOvUumgcJCq['gameDesc']['homeName']
     XnBoeHAbidaflSMtQYGsOvUumgcJFq =XnBoeHAbidaflSMtQYGsOvUumgcJCq['gameDesc']['awayName']
     XnBoeHAbidaflSMtQYGsOvUumgcJFV =XnBoeHAbidaflSMtQYGsOvUumgcJCq['gameDesc']['homeScore']
     XnBoeHAbidaflSMtQYGsOvUumgcJFp =XnBoeHAbidaflSMtQYGsOvUumgcJCq['gameDesc']['awayScore']
     if hidescore==XnBoeHAbidaflSMtQYGsOvUumgcJWD:
      XnBoeHAbidaflSMtQYGsOvUumgcJFz ='%s\n - %s (%s)\n - %s\n\nhome : %s\n\naway : %s'%(XnBoeHAbidaflSMtQYGsOvUumgcJFC,XnBoeHAbidaflSMtQYGsOvUumgcJFT,XnBoeHAbidaflSMtQYGsOvUumgcJFK,XnBoeHAbidaflSMtQYGsOvUumgcJKE,XnBoeHAbidaflSMtQYGsOvUumgcJFW,XnBoeHAbidaflSMtQYGsOvUumgcJFq)
     else:
      XnBoeHAbidaflSMtQYGsOvUumgcJFz ='%s\n - %s (%s)\n - %s\n\nhome : %s (Score %s)\n\naway : %s (Score %s)'%(XnBoeHAbidaflSMtQYGsOvUumgcJFC,XnBoeHAbidaflSMtQYGsOvUumgcJFT,XnBoeHAbidaflSMtQYGsOvUumgcJFK,XnBoeHAbidaflSMtQYGsOvUumgcJKE,XnBoeHAbidaflSMtQYGsOvUumgcJFW,XnBoeHAbidaflSMtQYGsOvUumgcJFV,XnBoeHAbidaflSMtQYGsOvUumgcJFq,XnBoeHAbidaflSMtQYGsOvUumgcJFp)
     XnBoeHAbidaflSMtQYGsOvUumgcJFy=XnBoeHAbidaflSMtQYGsOvUumgcJFz
     XnBoeHAbidaflSMtQYGsOvUumgcJFx =XnBoeHAbidaflSMtQYGsOvUumgcJCq['replayVod']['count']
     XnBoeHAbidaflSMtQYGsOvUumgcJFL=XnBoeHAbidaflSMtQYGsOvUumgcJCq['highlightVod']['count']
     XnBoeHAbidaflSMtQYGsOvUumgcJFN =XnBoeHAbidaflSMtQYGsOvUumgcJCq['vods']['count']
     XnBoeHAbidaflSMtQYGsOvUumgcJKk='' 
     XnBoeHAbidaflSMtQYGsOvUumgcJFI=XnBoeHAbidaflSMtQYGsOvUumgcJFx+XnBoeHAbidaflSMtQYGsOvUumgcJFL+XnBoeHAbidaflSMtQYGsOvUumgcJFN
     if XnBoeHAbidaflSMtQYGsOvUumgcJFI==0:
      if XnBoeHAbidaflSMtQYGsOvUumgcJKw=='2':
       XnBoeHAbidaflSMtQYGsOvUumgcJTq='----- %s -----'%(XnBoeHAbidaflSMtQYGsOvUumgcJFT)
       XnBoeHAbidaflSMtQYGsOvUumgcJKE=''
      else:
       XnBoeHAbidaflSMtQYGsOvUumgcJTq+=' - 관련영상 없음'
       XnBoeHAbidaflSMtQYGsOvUumgcJFy+='\n\n ** 관련영상 없음 **'
     else:
      if XnBoeHAbidaflSMtQYGsOvUumgcJFx!=0:
       XnBoeHAbidaflSMtQYGsOvUumgcJKk =XnBoeHAbidaflSMtQYGsOvUumgcJCq['replayVod']['list'][0]['imgUrl']
      elif XnBoeHAbidaflSMtQYGsOvUumgcJFL!=0:
       XnBoeHAbidaflSMtQYGsOvUumgcJKk =XnBoeHAbidaflSMtQYGsOvUumgcJCq['highlightVod']['list'][0]['imgUrl']
      else:
       XnBoeHAbidaflSMtQYGsOvUumgcJKk =XnBoeHAbidaflSMtQYGsOvUumgcJCq['vods']['list'][0]['imgUrl']
     XnBoeHAbidaflSMtQYGsOvUumgcJCV={'gameTitle':XnBoeHAbidaflSMtQYGsOvUumgcJTq,'gameId':XnBoeHAbidaflSMtQYGsOvUumgcJFD,'beginDate':XnBoeHAbidaflSMtQYGsOvUumgcJKE[:11],'thumbnail':XnBoeHAbidaflSMtQYGsOvUumgcJKk,'info_plot':XnBoeHAbidaflSMtQYGsOvUumgcJFy,'leaguenm':XnBoeHAbidaflSMtQYGsOvUumgcJFC,'seasonnm':XnBoeHAbidaflSMtQYGsOvUumgcJFT,'roundnm':XnBoeHAbidaflSMtQYGsOvUumgcJFK,'totVodCnt':XnBoeHAbidaflSMtQYGsOvUumgcJFI}
     XnBoeHAbidaflSMtQYGsOvUumgcJCF.append(XnBoeHAbidaflSMtQYGsOvUumgcJCV)
  except XnBoeHAbidaflSMtQYGsOvUumgcJWC as exception:
   XnBoeHAbidaflSMtQYGsOvUumgcJFR(exception)
  try:
   if XnBoeHAbidaflSMtQYGsOvUumgcJKw=='2':
    if XnBoeHAbidaflSMtQYGsOvUumgcJDP['count']>page_int*XnBoeHAbidaflSMtQYGsOvUumgcJDW.GAMELIST_LIMIT:XnBoeHAbidaflSMtQYGsOvUumgcJKh=XnBoeHAbidaflSMtQYGsOvUumgcJWD
   else:
    if XnBoeHAbidaflSMtQYGsOvUumgcJDP['count']>page_int*XnBoeHAbidaflSMtQYGsOvUumgcJDW.GAMELIST_LIMIT:XnBoeHAbidaflSMtQYGsOvUumgcJKh=XnBoeHAbidaflSMtQYGsOvUumgcJWD
  except:
   XnBoeHAbidaflSMtQYGsOvUumgcJFR(exception)
  return XnBoeHAbidaflSMtQYGsOvUumgcJCF,XnBoeHAbidaflSMtQYGsOvUumgcJKh
 def GetGameVodList(XnBoeHAbidaflSMtQYGsOvUumgcJDW,XnBoeHAbidaflSMtQYGsOvUumgcJFD):
  XnBoeHAbidaflSMtQYGsOvUumgcJCF=[]
  XnBoeHAbidaflSMtQYGsOvUumgcJFk=''
  try:
   XnBoeHAbidaflSMtQYGsOvUumgcJCp=XnBoeHAbidaflSMtQYGsOvUumgcJDW.API_DOMAIN+'/api/v2/vod/game'
   XnBoeHAbidaflSMtQYGsOvUumgcJKj={'gameId':XnBoeHAbidaflSMtQYGsOvUumgcJFD,'pageItem':'1000'}
   XnBoeHAbidaflSMtQYGsOvUumgcJDr=XnBoeHAbidaflSMtQYGsOvUumgcJDW.callRequestCookies('Get',XnBoeHAbidaflSMtQYGsOvUumgcJCp,payload=XnBoeHAbidaflSMtQYGsOvUumgcJFw,params=XnBoeHAbidaflSMtQYGsOvUumgcJKj,headers=XnBoeHAbidaflSMtQYGsOvUumgcJFw,cookies=XnBoeHAbidaflSMtQYGsOvUumgcJFw)
   XnBoeHAbidaflSMtQYGsOvUumgcJDP=json.loads(XnBoeHAbidaflSMtQYGsOvUumgcJDr.text)
   XnBoeHAbidaflSMtQYGsOvUumgcJKR=XnBoeHAbidaflSMtQYGsOvUumgcJDP['list']
   for XnBoeHAbidaflSMtQYGsOvUumgcJCq in XnBoeHAbidaflSMtQYGsOvUumgcJKR:
    XnBoeHAbidaflSMtQYGsOvUumgcJKL =XnBoeHAbidaflSMtQYGsOvUumgcJCq['title']
    XnBoeHAbidaflSMtQYGsOvUumgcJKN =XnBoeHAbidaflSMtQYGsOvUumgcJCq['id']
    XnBoeHAbidaflSMtQYGsOvUumgcJKI =XnBoeHAbidaflSMtQYGsOvUumgcJCq['vtype']
    XnBoeHAbidaflSMtQYGsOvUumgcJKk =XnBoeHAbidaflSMtQYGsOvUumgcJCq['imgUrl']
    XnBoeHAbidaflSMtQYGsOvUumgcJKr =XnBoeHAbidaflSMtQYGsOvUumgcJCq['vtypeId']
    XnBoeHAbidaflSMtQYGsOvUumgcJCV={'vodTitle':XnBoeHAbidaflSMtQYGsOvUumgcJKL,'vodId':XnBoeHAbidaflSMtQYGsOvUumgcJKN,'vodType':XnBoeHAbidaflSMtQYGsOvUumgcJKI,'thumbnail':XnBoeHAbidaflSMtQYGsOvUumgcJKk,'vtypeId':XnBoeHAbidaflSMtQYGsOvUumgcJFE(XnBoeHAbidaflSMtQYGsOvUumgcJKr),'duration':XnBoeHAbidaflSMtQYGsOvUumgcJWT(XnBoeHAbidaflSMtQYGsOvUumgcJCq['duration']/1000)}
    XnBoeHAbidaflSMtQYGsOvUumgcJCF.append(XnBoeHAbidaflSMtQYGsOvUumgcJCV)
  except XnBoeHAbidaflSMtQYGsOvUumgcJWC as exception:
   XnBoeHAbidaflSMtQYGsOvUumgcJFR(exception)
  return XnBoeHAbidaflSMtQYGsOvUumgcJCF
 def GetReplay_UrlId(XnBoeHAbidaflSMtQYGsOvUumgcJDW,XnBoeHAbidaflSMtQYGsOvUumgcJFk,XnBoeHAbidaflSMtQYGsOvUumgcJKr):
  XnBoeHAbidaflSMtQYGsOvUumgcJFr=XnBoeHAbidaflSMtQYGsOvUumgcJTV=''
  XnBoeHAbidaflSMtQYGsOvUumgcJFh=''
  try:
   XnBoeHAbidaflSMtQYGsOvUumgcJCp=XnBoeHAbidaflSMtQYGsOvUumgcJDW.API_DOMAIN+'/api/v2/vod/'+XnBoeHAbidaflSMtQYGsOvUumgcJFk
   XnBoeHAbidaflSMtQYGsOvUumgcJDr=XnBoeHAbidaflSMtQYGsOvUumgcJDW.callRequestCookies('Get',XnBoeHAbidaflSMtQYGsOvUumgcJCp,payload=XnBoeHAbidaflSMtQYGsOvUumgcJFw,params=XnBoeHAbidaflSMtQYGsOvUumgcJFw,headers=XnBoeHAbidaflSMtQYGsOvUumgcJFw,cookies=XnBoeHAbidaflSMtQYGsOvUumgcJFw)
   XnBoeHAbidaflSMtQYGsOvUumgcJDP=json.loads(XnBoeHAbidaflSMtQYGsOvUumgcJDr.text)
   XnBoeHAbidaflSMtQYGsOvUumgcJFr =XnBoeHAbidaflSMtQYGsOvUumgcJDP['clipId']
   XnBoeHAbidaflSMtQYGsOvUumgcJTV=XnBoeHAbidaflSMtQYGsOvUumgcJDP['videoId']
   XnBoeHAbidaflSMtQYGsOvUumgcJFh=XnBoeHAbidaflSMtQYGsOvUumgcJFr
   if XnBoeHAbidaflSMtQYGsOvUumgcJDW.CheckSubEnd()or XnBoeHAbidaflSMtQYGsOvUumgcJKr!='1':XnBoeHAbidaflSMtQYGsOvUumgcJFh=XnBoeHAbidaflSMtQYGsOvUumgcJTV 
  except XnBoeHAbidaflSMtQYGsOvUumgcJWC as exception:
   XnBoeHAbidaflSMtQYGsOvUumgcJFR(exception)
  return XnBoeHAbidaflSMtQYGsOvUumgcJFh
# Created by pyminifier (https://github.com/liftoff/pyminifier)
