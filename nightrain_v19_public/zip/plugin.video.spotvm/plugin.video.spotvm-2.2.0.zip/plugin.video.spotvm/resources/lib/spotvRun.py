__author__="NightRain"
KzkaSxMoOXgDUYtVNnqdJeHRrTfcQl=object
KzkaSxMoOXgDUYtVNnqdJeHRrTfcQP=None
KzkaSxMoOXgDUYtVNnqdJeHRrTfcQE=False
KzkaSxMoOXgDUYtVNnqdJeHRrTfcQG=True
KzkaSxMoOXgDUYtVNnqdJeHRrTfcQC=int
KzkaSxMoOXgDUYtVNnqdJeHRrTfcQw=len
KzkaSxMoOXgDUYtVNnqdJeHRrTfcQm=str
KzkaSxMoOXgDUYtVNnqdJeHRrTfcWp=id
KzkaSxMoOXgDUYtVNnqdJeHRrTfcWL=open
KzkaSxMoOXgDUYtVNnqdJeHRrTfcWI=dict
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
KzkaSxMoOXgDUYtVNnqdJeHRrTfcpI=[{'title':'TV 채널 (유료사용자만 지원)','mode':'LIVE_GROUP','icon':'live.png'},{'title':'Live중계 (경기중에만 재생)','mode':'ELIVE_GROUP','icon':'live.png'},{'title':'-----------------','mode':'XXX'},{'title':'오늘의 추천 VOD','mode':'NOW_GROUP'},{'title':'인기영상 5','mode':'POP_GROUP'},{'title':'-----------------','mode':'XXX'},{'title':'VOD (리그, 경기별)','mode':'VOD_GROUP'},{'title':'Watched (시청목록)','mode':'WATCH','icon':'history.png'},]
KzkaSxMoOXgDUYtVNnqdJeHRrTfcpB=xbmcvfs.translatePath(os.path.join(__profile__,'spotv_cookies.json'))
from spotvCore import*
class KzkaSxMoOXgDUYtVNnqdJeHRrTfcpL(KzkaSxMoOXgDUYtVNnqdJeHRrTfcQl):
 def __init__(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ,KzkaSxMoOXgDUYtVNnqdJeHRrTfcpW,KzkaSxMoOXgDUYtVNnqdJeHRrTfcpb,KzkaSxMoOXgDUYtVNnqdJeHRrTfcps):
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ._addon_url =KzkaSxMoOXgDUYtVNnqdJeHRrTfcpW
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ._addon_handle=KzkaSxMoOXgDUYtVNnqdJeHRrTfcpb
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.main_params =KzkaSxMoOXgDUYtVNnqdJeHRrTfcps
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.SpotvObj =JjpElDexdKWctgfYFnoubAOXMhRkTH() 
 def addon_noti(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ,sting):
  try:
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpy=xbmcgui.Dialog()
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpy.notification(__addonname__,sting)
  except:
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcQP
 def addon_log(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ,string):
  try:
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpA=string.encode('utf-8','ignore')
  except:
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpA='addonException: addon_log'
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcpu=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,KzkaSxMoOXgDUYtVNnqdJeHRrTfcpA),level=KzkaSxMoOXgDUYtVNnqdJeHRrTfcpu)
 def get_keyboard_input(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ,KzkaSxMoOXgDUYtVNnqdJeHRrTfcpP):
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcpv=KzkaSxMoOXgDUYtVNnqdJeHRrTfcQP
  kb=xbmc.Keyboard()
  kb.setHeading(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpP)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpv=kb.getText()
  return KzkaSxMoOXgDUYtVNnqdJeHRrTfcpv
 def get_settings_account(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ):
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcpi =__addon__.getSetting('id')
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcpj =__addon__.getSetting('pw')
  return(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpi,KzkaSxMoOXgDUYtVNnqdJeHRrTfcpj)
 def get_settings_hidescoreyn(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ):
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcph =__addon__.getSetting('hidescore')
  if KzkaSxMoOXgDUYtVNnqdJeHRrTfcph=='false':
   return KzkaSxMoOXgDUYtVNnqdJeHRrTfcQE
  else:
   return KzkaSxMoOXgDUYtVNnqdJeHRrTfcQG
 def add_dir(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ,label,sublabel='',img='',infoLabels=KzkaSxMoOXgDUYtVNnqdJeHRrTfcQP,isFolder=KzkaSxMoOXgDUYtVNnqdJeHRrTfcQG,params='',isLink=KzkaSxMoOXgDUYtVNnqdJeHRrTfcQE,ContextMenu=KzkaSxMoOXgDUYtVNnqdJeHRrTfcQP):
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcpl='%s?%s'%(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ._addon_url,urllib.parse.urlencode(params))
  if sublabel:KzkaSxMoOXgDUYtVNnqdJeHRrTfcpP='%s < %s >'%(label,sublabel)
  else: KzkaSxMoOXgDUYtVNnqdJeHRrTfcpP=label
  if not img:img='DefaultFolder.png'
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcpE=xbmcgui.ListItem(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpP)
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcpE.setArt({'thumb':img,'icon':img,'poster':img})
  if infoLabels:KzkaSxMoOXgDUYtVNnqdJeHRrTfcpE.setInfo(type="Video",infoLabels=infoLabels)
  if not isFolder and not isLink:
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpE.setProperty('IsPlayable','true')
  if ContextMenu:KzkaSxMoOXgDUYtVNnqdJeHRrTfcpE.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ._addon_handle,KzkaSxMoOXgDUYtVNnqdJeHRrTfcpl,KzkaSxMoOXgDUYtVNnqdJeHRrTfcpE,isFolder)
 def get_selQuality(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ,etype):
  try:
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpG='selected_quality'
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpC=[1080,720,540]
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpw=KzkaSxMoOXgDUYtVNnqdJeHRrTfcQC(__addon__.getSetting(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpG))
   return KzkaSxMoOXgDUYtVNnqdJeHRrTfcpC[KzkaSxMoOXgDUYtVNnqdJeHRrTfcpw]
  except:
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcQP
  return 1080 
 def dp_Main_List(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ):
  for KzkaSxMoOXgDUYtVNnqdJeHRrTfcpm in KzkaSxMoOXgDUYtVNnqdJeHRrTfcpI:
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpP=KzkaSxMoOXgDUYtVNnqdJeHRrTfcpm.get('title')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLp=''
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLI={'mode':KzkaSxMoOXgDUYtVNnqdJeHRrTfcpm.get('mode'),'page':'1'}
   if KzkaSxMoOXgDUYtVNnqdJeHRrTfcpm.get('mode')=='XXX':
    KzkaSxMoOXgDUYtVNnqdJeHRrTfcLB=KzkaSxMoOXgDUYtVNnqdJeHRrTfcQE
    KzkaSxMoOXgDUYtVNnqdJeHRrTfcLQ =KzkaSxMoOXgDUYtVNnqdJeHRrTfcQG
   else:
    KzkaSxMoOXgDUYtVNnqdJeHRrTfcLB=KzkaSxMoOXgDUYtVNnqdJeHRrTfcQG
    KzkaSxMoOXgDUYtVNnqdJeHRrTfcLQ =KzkaSxMoOXgDUYtVNnqdJeHRrTfcQE
   if 'icon' in KzkaSxMoOXgDUYtVNnqdJeHRrTfcpm:KzkaSxMoOXgDUYtVNnqdJeHRrTfcLp=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',KzkaSxMoOXgDUYtVNnqdJeHRrTfcpm.get('icon')) 
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.add_dir(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpP,sublabel='',img=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLp,infoLabels=KzkaSxMoOXgDUYtVNnqdJeHRrTfcQP,isFolder=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLB,params=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLI,isLink=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLQ)
  if KzkaSxMoOXgDUYtVNnqdJeHRrTfcQw(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpI)>0:xbmcplugin.endOfDirectory(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ._addon_handle)
 def dp_MainLeague_List(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ,args):
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcLb=KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.SpotvObj.GetTitleGroupList()
  for KzkaSxMoOXgDUYtVNnqdJeHRrTfcLs in KzkaSxMoOXgDUYtVNnqdJeHRrTfcLb:
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpP =KzkaSxMoOXgDUYtVNnqdJeHRrTfcLs.get('title')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLF =KzkaSxMoOXgDUYtVNnqdJeHRrTfcLs.get('logo')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLy =KzkaSxMoOXgDUYtVNnqdJeHRrTfcLs.get('reagueId')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLA =KzkaSxMoOXgDUYtVNnqdJeHRrTfcLs.get('subGame')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLu={'mediatype':'episode','plot':'%s\n\n%s'%(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpP,KzkaSxMoOXgDUYtVNnqdJeHRrTfcLA)}
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLI={'mode':'LEAGUE_GROUP','reagueId':KzkaSxMoOXgDUYtVNnqdJeHRrTfcLy}
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.add_dir(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpP,sublabel=KzkaSxMoOXgDUYtVNnqdJeHRrTfcQP,img=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLF,infoLabels=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLu,isFolder=KzkaSxMoOXgDUYtVNnqdJeHRrTfcQG,params=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLI)
  if KzkaSxMoOXgDUYtVNnqdJeHRrTfcQw(KzkaSxMoOXgDUYtVNnqdJeHRrTfcLb)>0:xbmcplugin.endOfDirectory(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ._addon_handle,cacheToDisc=KzkaSxMoOXgDUYtVNnqdJeHRrTfcQE)
 def dp_NowVod_GroupList(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ,args):
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcLv=KzkaSxMoOXgDUYtVNnqdJeHRrTfcQC(args.get('page'))
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcLb,KzkaSxMoOXgDUYtVNnqdJeHRrTfcLi=KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.SpotvObj.Get_NowVod_GroupList(KzkaSxMoOXgDUYtVNnqdJeHRrTfcLv)
  for KzkaSxMoOXgDUYtVNnqdJeHRrTfcLs in KzkaSxMoOXgDUYtVNnqdJeHRrTfcLb:
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLj =KzkaSxMoOXgDUYtVNnqdJeHRrTfcLs.get('vodTitle')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLh =KzkaSxMoOXgDUYtVNnqdJeHRrTfcLs.get('vodId')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLl =KzkaSxMoOXgDUYtVNnqdJeHRrTfcLs.get('vodType')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLF=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLs.get('thumbnail')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLP =KzkaSxMoOXgDUYtVNnqdJeHRrTfcLs.get('vtypeId')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLE =KzkaSxMoOXgDUYtVNnqdJeHRrTfcLs.get('duration')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLu={'mediatype':'video','duration':KzkaSxMoOXgDUYtVNnqdJeHRrTfcLE,'plot':KzkaSxMoOXgDUYtVNnqdJeHRrTfcLj}
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLI={'mode':'NOW_VOD','mediacode':KzkaSxMoOXgDUYtVNnqdJeHRrTfcLh,'mediatype':'vod','vtypeId':KzkaSxMoOXgDUYtVNnqdJeHRrTfcLP}
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.add_dir(KzkaSxMoOXgDUYtVNnqdJeHRrTfcLj,sublabel=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLl,img=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLF,infoLabels=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLu,isFolder=KzkaSxMoOXgDUYtVNnqdJeHRrTfcQE,params=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLI)
  if KzkaSxMoOXgDUYtVNnqdJeHRrTfcLi:
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLI['mode'] ='NOW_GROUP' 
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLI['page'] =KzkaSxMoOXgDUYtVNnqdJeHRrTfcQm(KzkaSxMoOXgDUYtVNnqdJeHRrTfcLv+1)
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpP='[B]%s >>[/B]'%'다음 페이지'
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLG=KzkaSxMoOXgDUYtVNnqdJeHRrTfcQm(KzkaSxMoOXgDUYtVNnqdJeHRrTfcLv+1)
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLp=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.add_dir(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpP,sublabel=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLG,img=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLp,infoLabels=KzkaSxMoOXgDUYtVNnqdJeHRrTfcQP,isFolder=KzkaSxMoOXgDUYtVNnqdJeHRrTfcQG,params=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLI)
  xbmcplugin.setContent(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ._addon_handle,cacheToDisc=KzkaSxMoOXgDUYtVNnqdJeHRrTfcQE)
 def dp_PopVod_GroupList(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ,args):
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcLb=KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.SpotvObj.GetPopularGroupList()
  for KzkaSxMoOXgDUYtVNnqdJeHRrTfcLs in KzkaSxMoOXgDUYtVNnqdJeHRrTfcLb:
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLj =KzkaSxMoOXgDUYtVNnqdJeHRrTfcLs.get('vodTitle')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLh =KzkaSxMoOXgDUYtVNnqdJeHRrTfcLs.get('vodId')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLl =KzkaSxMoOXgDUYtVNnqdJeHRrTfcLs.get('vodType')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLF=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLs.get('thumbnail')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLP =KzkaSxMoOXgDUYtVNnqdJeHRrTfcLs.get('vtypeId')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLE =KzkaSxMoOXgDUYtVNnqdJeHRrTfcLs.get('duration')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLu={'mediatype':'video','duration':KzkaSxMoOXgDUYtVNnqdJeHRrTfcLE,'plot':KzkaSxMoOXgDUYtVNnqdJeHRrTfcLj}
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLI={'mode':'POP_VOD','mediacode':KzkaSxMoOXgDUYtVNnqdJeHRrTfcLh,'mediatype':'vod','vtypeId':KzkaSxMoOXgDUYtVNnqdJeHRrTfcLP}
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.add_dir(KzkaSxMoOXgDUYtVNnqdJeHRrTfcLj,sublabel=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLl,img=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLF,infoLabels=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLu,isFolder=KzkaSxMoOXgDUYtVNnqdJeHRrTfcQE,params=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLI)
  xbmcplugin.setContent(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ._addon_handle,cacheToDisc=KzkaSxMoOXgDUYtVNnqdJeHRrTfcQE)
 def dp_Season_List(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ,args):
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcLy=args.get('reagueId')
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcLb=KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.SpotvObj.GetSeasonList(KzkaSxMoOXgDUYtVNnqdJeHRrTfcLy)
  for KzkaSxMoOXgDUYtVNnqdJeHRrTfcLs in KzkaSxMoOXgDUYtVNnqdJeHRrTfcLb:
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLw =KzkaSxMoOXgDUYtVNnqdJeHRrTfcLs.get('reagueName')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLm =KzkaSxMoOXgDUYtVNnqdJeHRrTfcLs.get('gameTypeId')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcIp =KzkaSxMoOXgDUYtVNnqdJeHRrTfcLs.get('seasonName')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcIL =KzkaSxMoOXgDUYtVNnqdJeHRrTfcLs.get('seasonId')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLu={'mediatype':'episode','plot':'%s - %s'%(KzkaSxMoOXgDUYtVNnqdJeHRrTfcLw,KzkaSxMoOXgDUYtVNnqdJeHRrTfcIp)}
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLI={'mode':'SEASON_GROUP','reagueId':KzkaSxMoOXgDUYtVNnqdJeHRrTfcLy,'seasonId':KzkaSxMoOXgDUYtVNnqdJeHRrTfcIL,'gameTypeId':KzkaSxMoOXgDUYtVNnqdJeHRrTfcLm,'page':'1'}
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.add_dir(KzkaSxMoOXgDUYtVNnqdJeHRrTfcLw,sublabel=KzkaSxMoOXgDUYtVNnqdJeHRrTfcIp,img='',infoLabels=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLu,isFolder=KzkaSxMoOXgDUYtVNnqdJeHRrTfcQG,params=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLI)
  if KzkaSxMoOXgDUYtVNnqdJeHRrTfcQw(KzkaSxMoOXgDUYtVNnqdJeHRrTfcLb)>0:xbmcplugin.endOfDirectory(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ._addon_handle,cacheToDisc=KzkaSxMoOXgDUYtVNnqdJeHRrTfcQG)
 def dp_Game_List(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ,args):
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcLm=args.get('gameTypeId')
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcLy =args.get('reagueId')
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcIL =args.get('seasonId')
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcLv =KzkaSxMoOXgDUYtVNnqdJeHRrTfcQC(args.get('page'))
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcLb,KzkaSxMoOXgDUYtVNnqdJeHRrTfcLi=KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.SpotvObj.GetGameList(KzkaSxMoOXgDUYtVNnqdJeHRrTfcLm,KzkaSxMoOXgDUYtVNnqdJeHRrTfcLy,KzkaSxMoOXgDUYtVNnqdJeHRrTfcIL,KzkaSxMoOXgDUYtVNnqdJeHRrTfcLv,hidescore=KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.get_settings_hidescoreyn())
  for KzkaSxMoOXgDUYtVNnqdJeHRrTfcLs in KzkaSxMoOXgDUYtVNnqdJeHRrTfcLb:
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcIB =KzkaSxMoOXgDUYtVNnqdJeHRrTfcLs.get('gameTitle')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcIQ =KzkaSxMoOXgDUYtVNnqdJeHRrTfcLs.get('beginDate')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLF =KzkaSxMoOXgDUYtVNnqdJeHRrTfcLs.get('thumbnail')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcIW =KzkaSxMoOXgDUYtVNnqdJeHRrTfcLs.get('gameId')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcIb =KzkaSxMoOXgDUYtVNnqdJeHRrTfcLs.get('totVodCnt')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcIs =KzkaSxMoOXgDUYtVNnqdJeHRrTfcLs.get('leaguenm')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcIF =KzkaSxMoOXgDUYtVNnqdJeHRrTfcLs.get('seasonnm')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcIy =KzkaSxMoOXgDUYtVNnqdJeHRrTfcLs.get('roundnm')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcIA =KzkaSxMoOXgDUYtVNnqdJeHRrTfcLs.get('info_plot')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcIu ='%s < %s >'%(KzkaSxMoOXgDUYtVNnqdJeHRrTfcIB,KzkaSxMoOXgDUYtVNnqdJeHRrTfcIQ)
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLu={'mediatype':'video','plot':KzkaSxMoOXgDUYtVNnqdJeHRrTfcIA}
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLI={'mode':'GAME_VOD_GROUP' if KzkaSxMoOXgDUYtVNnqdJeHRrTfcIb!=0 else 'XXX','saveTitle':KzkaSxMoOXgDUYtVNnqdJeHRrTfcIu,'saveImg':KzkaSxMoOXgDUYtVNnqdJeHRrTfcLF,'saveInfo':KzkaSxMoOXgDUYtVNnqdJeHRrTfcLu['plot'],'gameid':KzkaSxMoOXgDUYtVNnqdJeHRrTfcIW,'totVodCnt':KzkaSxMoOXgDUYtVNnqdJeHRrTfcIb,}
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.add_dir(KzkaSxMoOXgDUYtVNnqdJeHRrTfcIB,sublabel=KzkaSxMoOXgDUYtVNnqdJeHRrTfcIQ,img=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLF,infoLabels=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLu,isFolder=KzkaSxMoOXgDUYtVNnqdJeHRrTfcQG,params=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLI)
  if KzkaSxMoOXgDUYtVNnqdJeHRrTfcLi:
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLI['mode'] ='SEASON_GROUP' 
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLI['reagueId'] =KzkaSxMoOXgDUYtVNnqdJeHRrTfcLy
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLI['seasonId'] =KzkaSxMoOXgDUYtVNnqdJeHRrTfcIL
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLI['gameTypeId']=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLm
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLI['page'] =KzkaSxMoOXgDUYtVNnqdJeHRrTfcQm(KzkaSxMoOXgDUYtVNnqdJeHRrTfcLv+1)
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpP='[B]%s >>[/B]'%'다음 페이지'
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLG=KzkaSxMoOXgDUYtVNnqdJeHRrTfcQm(KzkaSxMoOXgDUYtVNnqdJeHRrTfcLv+1)
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLp=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.add_dir(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpP,sublabel=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLG,img=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLp,infoLabels=KzkaSxMoOXgDUYtVNnqdJeHRrTfcQP,isFolder=KzkaSxMoOXgDUYtVNnqdJeHRrTfcQG,params=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLI)
  if KzkaSxMoOXgDUYtVNnqdJeHRrTfcQw(KzkaSxMoOXgDUYtVNnqdJeHRrTfcLb)>0:xbmcplugin.endOfDirectory(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ._addon_handle,cacheToDisc=KzkaSxMoOXgDUYtVNnqdJeHRrTfcQE)
 def dp_GameVod_List(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ,args):
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcIv =args.get('gameid')
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcIu=args.get('saveTitle')
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcIi =args.get('saveImg')
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcIj =args.get('saveInfo')
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcLb=KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.SpotvObj.GetGameVodList(KzkaSxMoOXgDUYtVNnqdJeHRrTfcIv)
  for KzkaSxMoOXgDUYtVNnqdJeHRrTfcLs in KzkaSxMoOXgDUYtVNnqdJeHRrTfcLb:
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLj =KzkaSxMoOXgDUYtVNnqdJeHRrTfcLs.get('vodTitle')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLh =KzkaSxMoOXgDUYtVNnqdJeHRrTfcLs.get('vodId')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLl =KzkaSxMoOXgDUYtVNnqdJeHRrTfcLs.get('vodType')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLF=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLs.get('thumbnail')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLP =KzkaSxMoOXgDUYtVNnqdJeHRrTfcLs.get('vtypeId')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLE =KzkaSxMoOXgDUYtVNnqdJeHRrTfcLs.get('duration')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLu={'mediatype':'video','duration':KzkaSxMoOXgDUYtVNnqdJeHRrTfcLE,'plot':'%s \n\n %s'%(KzkaSxMoOXgDUYtVNnqdJeHRrTfcLj,KzkaSxMoOXgDUYtVNnqdJeHRrTfcIj)}
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLI={'mode':'GAME_VOD','saveTitle':KzkaSxMoOXgDUYtVNnqdJeHRrTfcIu,'saveImg':KzkaSxMoOXgDUYtVNnqdJeHRrTfcIi,'saveId':KzkaSxMoOXgDUYtVNnqdJeHRrTfcIv,'saveInfo':KzkaSxMoOXgDUYtVNnqdJeHRrTfcIj,'mediacode':KzkaSxMoOXgDUYtVNnqdJeHRrTfcLh,'mediatype':'vod','vtypeId':KzkaSxMoOXgDUYtVNnqdJeHRrTfcLP}
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.add_dir(KzkaSxMoOXgDUYtVNnqdJeHRrTfcLj,sublabel=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLl,img=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLF,infoLabels=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLu,isFolder=KzkaSxMoOXgDUYtVNnqdJeHRrTfcQE,params=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLI)
  xbmcplugin.setContent(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ._addon_handle,cacheToDisc=KzkaSxMoOXgDUYtVNnqdJeHRrTfcQE)
 def login_main(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ):
  (KzkaSxMoOXgDUYtVNnqdJeHRrTfcIh,KzkaSxMoOXgDUYtVNnqdJeHRrTfcIl)=KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.get_settings_account()
  if not(KzkaSxMoOXgDUYtVNnqdJeHRrTfcIh and KzkaSxMoOXgDUYtVNnqdJeHRrTfcIl):
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpy=xbmcgui.Dialog()
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcIP=KzkaSxMoOXgDUYtVNnqdJeHRrTfcpy.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if KzkaSxMoOXgDUYtVNnqdJeHRrTfcIP==KzkaSxMoOXgDUYtVNnqdJeHRrTfcQG:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.cookiefile_check():return
  if xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINWAIT')=='TRUE':
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcIE=0
   while KzkaSxMoOXgDUYtVNnqdJeHRrTfcQG:
    KzkaSxMoOXgDUYtVNnqdJeHRrTfcIE+=1
    time.sleep(0.05)
    if KzkaSxMoOXgDUYtVNnqdJeHRrTfcIE>600:return
  else:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','TRUE')
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcIG=KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.SpotvObj.GetCredential(KzkaSxMoOXgDUYtVNnqdJeHRrTfcIh,KzkaSxMoOXgDUYtVNnqdJeHRrTfcIl)
  if KzkaSxMoOXgDUYtVNnqdJeHRrTfcIG:KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.cookiefile_save()
  xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
  if KzkaSxMoOXgDUYtVNnqdJeHRrTfcIG==KzkaSxMoOXgDUYtVNnqdJeHRrTfcQE:
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_LiveChannel_List(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ,args):
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcIC=KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.SpotvObj.GetLiveChannelList()
  for KzkaSxMoOXgDUYtVNnqdJeHRrTfcIw in KzkaSxMoOXgDUYtVNnqdJeHRrTfcIC:
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcWp =KzkaSxMoOXgDUYtVNnqdJeHRrTfcIw.get('id')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpP =KzkaSxMoOXgDUYtVNnqdJeHRrTfcIw.get('name')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLW =KzkaSxMoOXgDUYtVNnqdJeHRrTfcIw.get('programName')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLF =KzkaSxMoOXgDUYtVNnqdJeHRrTfcIw.get('logo')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcIm=KzkaSxMoOXgDUYtVNnqdJeHRrTfcIw.get('channelepg')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcBp =KzkaSxMoOXgDUYtVNnqdJeHRrTfcIw.get('free')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcBL =KzkaSxMoOXgDUYtVNnqdJeHRrTfcIw.get('hlsUrl')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLu={'plot':'%s\n\n%s'%(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpP,KzkaSxMoOXgDUYtVNnqdJeHRrTfcIm)}
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLI={'mode':'LIVE','mediacode':KzkaSxMoOXgDUYtVNnqdJeHRrTfcWp,'hlsUrl':KzkaSxMoOXgDUYtVNnqdJeHRrTfcBL,'free':KzkaSxMoOXgDUYtVNnqdJeHRrTfcBp,'mediatype':'live'}
   if KzkaSxMoOXgDUYtVNnqdJeHRrTfcBp:KzkaSxMoOXgDUYtVNnqdJeHRrTfcpP+=' [free]'
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.add_dir(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpP,sublabel=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLW,img=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLF,infoLabels=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLu,isFolder=KzkaSxMoOXgDUYtVNnqdJeHRrTfcQE,params=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLI)
  if KzkaSxMoOXgDUYtVNnqdJeHRrTfcQw(KzkaSxMoOXgDUYtVNnqdJeHRrTfcIC)>0:xbmcplugin.endOfDirectory(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ._addon_handle,cacheToDisc=KzkaSxMoOXgDUYtVNnqdJeHRrTfcQE)
 def dp_EventLiveChannel_List(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ,args):
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcIC,KzkaSxMoOXgDUYtVNnqdJeHRrTfcBI=KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.SpotvObj.GetEventLiveList()
  if KzkaSxMoOXgDUYtVNnqdJeHRrTfcBI!=401 and KzkaSxMoOXgDUYtVNnqdJeHRrTfcQw(KzkaSxMoOXgDUYtVNnqdJeHRrTfcIC)==0:
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.addon_noti(__language__(30907).encode('utf8'))
  for KzkaSxMoOXgDUYtVNnqdJeHRrTfcIw in KzkaSxMoOXgDUYtVNnqdJeHRrTfcIC:
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpP =KzkaSxMoOXgDUYtVNnqdJeHRrTfcIw.get('title')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLW =KzkaSxMoOXgDUYtVNnqdJeHRrTfcIw.get('startTime')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLF =KzkaSxMoOXgDUYtVNnqdJeHRrTfcIw.get('logo')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcBp =KzkaSxMoOXgDUYtVNnqdJeHRrTfcIw.get('free')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLu={'mediatype':'video','plot':'%s\n\n%s'%(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpP,KzkaSxMoOXgDUYtVNnqdJeHRrTfcLW)}
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLI={'mode':'ELIVE','mediacode':KzkaSxMoOXgDUYtVNnqdJeHRrTfcIw.get('liveId'),'free':KzkaSxMoOXgDUYtVNnqdJeHRrTfcBp,'mediatype':'live'}
   if KzkaSxMoOXgDUYtVNnqdJeHRrTfcBp:KzkaSxMoOXgDUYtVNnqdJeHRrTfcpP+=' [free]'
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.add_dir(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpP,sublabel=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLW,img=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLF,infoLabels=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLu,isFolder=KzkaSxMoOXgDUYtVNnqdJeHRrTfcQE,params=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLI)
  if KzkaSxMoOXgDUYtVNnqdJeHRrTfcQw(KzkaSxMoOXgDUYtVNnqdJeHRrTfcIC)>0:xbmcplugin.endOfDirectory(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ._addon_handle,cacheToDisc=KzkaSxMoOXgDUYtVNnqdJeHRrTfcQG)
  return KzkaSxMoOXgDUYtVNnqdJeHRrTfcBI
 def play_VIDEO(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ,args):
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcBQ =args.get('mode')
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcBW =args.get('mediacode')
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcBb =args.get('mediatype')
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcLP =args.get('vtypeId')
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcBL =args.get('hlsUrl')
  if KzkaSxMoOXgDUYtVNnqdJeHRrTfcBQ=='LIVE':
   if args.get('free')=='False':
    if KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.SpotvObj.CheckSubEnd()==KzkaSxMoOXgDUYtVNnqdJeHRrTfcQE:
     KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.addon_noti(__language__(30908).encode('utf8'))
     return
  elif KzkaSxMoOXgDUYtVNnqdJeHRrTfcBQ=='ELIVE':
   if args.get('free')=='False':
    if KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.SpotvObj.CheckSubEnd()==KzkaSxMoOXgDUYtVNnqdJeHRrTfcQE:
     KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.addon_noti(__language__(30908).encode('utf8'))
     return
  if KzkaSxMoOXgDUYtVNnqdJeHRrTfcBW=='' or KzkaSxMoOXgDUYtVNnqdJeHRrTfcBW==KzkaSxMoOXgDUYtVNnqdJeHRrTfcQP:
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.addon_noti(__language__(30907).encode('utf8'))
   return
  if KzkaSxMoOXgDUYtVNnqdJeHRrTfcBQ=='LIVE':
   if KzkaSxMoOXgDUYtVNnqdJeHRrTfcBL:
    KzkaSxMoOXgDUYtVNnqdJeHRrTfcBs=KzkaSxMoOXgDUYtVNnqdJeHRrTfcBL
   else:
    KzkaSxMoOXgDUYtVNnqdJeHRrTfcBs=KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.SpotvObj.GetHlsUrl(KzkaSxMoOXgDUYtVNnqdJeHRrTfcBW)
  else:
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcBs=KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.SpotvObj.GetBroadURL(KzkaSxMoOXgDUYtVNnqdJeHRrTfcBW,KzkaSxMoOXgDUYtVNnqdJeHRrTfcBb,KzkaSxMoOXgDUYtVNnqdJeHRrTfcLP)
  if KzkaSxMoOXgDUYtVNnqdJeHRrTfcBs=='':
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.addon_noti(__language__(30908).encode('utf8'))
   return
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcBF=KzkaSxMoOXgDUYtVNnqdJeHRrTfcBs
  try:
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.addon_log('mainMode  = '+KzkaSxMoOXgDUYtVNnqdJeHRrTfcBQ)
  except:
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcQP
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.addon_log(KzkaSxMoOXgDUYtVNnqdJeHRrTfcBF)
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcBy=xbmcgui.ListItem(path=KzkaSxMoOXgDUYtVNnqdJeHRrTfcBF)
  xbmcplugin.setResolvedUrl(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ._addon_handle,KzkaSxMoOXgDUYtVNnqdJeHRrTfcQG,KzkaSxMoOXgDUYtVNnqdJeHRrTfcBy)
  try:
   if KzkaSxMoOXgDUYtVNnqdJeHRrTfcBb=='vod' and KzkaSxMoOXgDUYtVNnqdJeHRrTfcBQ not in['POP_VOD','NOW_VOD']:
    KzkaSxMoOXgDUYtVNnqdJeHRrTfcLI={'code':args.get('saveId'),'img':args.get('saveImg'),'title':args.get('saveTitle'),'info':args.get('saveInfo')}
    KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.Save_Watched_List(KzkaSxMoOXgDUYtVNnqdJeHRrTfcBb,KzkaSxMoOXgDUYtVNnqdJeHRrTfcLI)
  except:
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcQP
 def logout(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ):
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcpy=xbmcgui.Dialog()
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcIP=KzkaSxMoOXgDUYtVNnqdJeHRrTfcpy.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if KzkaSxMoOXgDUYtVNnqdJeHRrTfcIP==KzkaSxMoOXgDUYtVNnqdJeHRrTfcQE:sys.exit()
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.SpotvObj.Init_ST_Total()
  if os.path.isfile(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpB):os.remove(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpB)
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ):
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcBA =KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.SpotvObj.Get_Now_Datetime()
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcBu=KzkaSxMoOXgDUYtVNnqdJeHRrTfcBA+datetime.timedelta(days=KzkaSxMoOXgDUYtVNnqdJeHRrTfcQC(__addon__.getSetting('cache_ttl')))
  (KzkaSxMoOXgDUYtVNnqdJeHRrTfcIh,KzkaSxMoOXgDUYtVNnqdJeHRrTfcIl)=KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.get_settings_account()
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.SpotvObj.Save_session_acount(KzkaSxMoOXgDUYtVNnqdJeHRrTfcIh,KzkaSxMoOXgDUYtVNnqdJeHRrTfcIl)
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.SpotvObj.ST['account']['token_limit']=KzkaSxMoOXgDUYtVNnqdJeHRrTfcBu.strftime('%Y%m%d')
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.SpotvObj.JsonFile_Save(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpB,KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.SpotvObj.ST)
 def cookiefile_check(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ):
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.SpotvObj.ST=KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.SpotvObj.JsonFile_Load(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpB)
  if 'account' not in KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.SpotvObj.ST:
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.SpotvObj.Init_ST_Total()
   return KzkaSxMoOXgDUYtVNnqdJeHRrTfcQE
  (KzkaSxMoOXgDUYtVNnqdJeHRrTfcBv,KzkaSxMoOXgDUYtVNnqdJeHRrTfcBi)=KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.get_settings_account()
  (KzkaSxMoOXgDUYtVNnqdJeHRrTfcBj,KzkaSxMoOXgDUYtVNnqdJeHRrTfcBh)=KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.SpotvObj.Load_session_acount()
  if KzkaSxMoOXgDUYtVNnqdJeHRrTfcBv!=KzkaSxMoOXgDUYtVNnqdJeHRrTfcBj or KzkaSxMoOXgDUYtVNnqdJeHRrTfcBi!=KzkaSxMoOXgDUYtVNnqdJeHRrTfcBh:
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.SpotvObj.Init_ST_Total()
   return KzkaSxMoOXgDUYtVNnqdJeHRrTfcQE
  if KzkaSxMoOXgDUYtVNnqdJeHRrTfcQC(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))>KzkaSxMoOXgDUYtVNnqdJeHRrTfcQC(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.SpotvObj.ST['account']['token_limit']):
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.SpotvObj.Init_ST_Total()
   return KzkaSxMoOXgDUYtVNnqdJeHRrTfcQE
  return KzkaSxMoOXgDUYtVNnqdJeHRrTfcQG
 def dp_History_Remove(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ,args):
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcBl=args.get('delType')
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcBP =args.get('sKey')
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcBE =args.get('vType')
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcpy=xbmcgui.Dialog()
  if KzkaSxMoOXgDUYtVNnqdJeHRrTfcBl=='WATCH_ALL':
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcIP=KzkaSxMoOXgDUYtVNnqdJeHRrTfcpy.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif KzkaSxMoOXgDUYtVNnqdJeHRrTfcBl=='WATCH_ONE':
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcIP=KzkaSxMoOXgDUYtVNnqdJeHRrTfcpy.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  if KzkaSxMoOXgDUYtVNnqdJeHRrTfcIP==KzkaSxMoOXgDUYtVNnqdJeHRrTfcQE:sys.exit()
  if KzkaSxMoOXgDUYtVNnqdJeHRrTfcBl=='WATCH_ALL':
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcBG=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%KzkaSxMoOXgDUYtVNnqdJeHRrTfcBE))
   if os.path.isfile(KzkaSxMoOXgDUYtVNnqdJeHRrTfcBG):os.remove(KzkaSxMoOXgDUYtVNnqdJeHRrTfcBG)
  elif KzkaSxMoOXgDUYtVNnqdJeHRrTfcBl=='WATCH_ONE':
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcBG=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%KzkaSxMoOXgDUYtVNnqdJeHRrTfcBE))
   try:
    KzkaSxMoOXgDUYtVNnqdJeHRrTfcBC=KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.Load_List_File(KzkaSxMoOXgDUYtVNnqdJeHRrTfcBE) 
    fp=KzkaSxMoOXgDUYtVNnqdJeHRrTfcWL(KzkaSxMoOXgDUYtVNnqdJeHRrTfcBG,'w',-1,'utf-8')
    for KzkaSxMoOXgDUYtVNnqdJeHRrTfcBw in KzkaSxMoOXgDUYtVNnqdJeHRrTfcBC:
     KzkaSxMoOXgDUYtVNnqdJeHRrTfcBm=KzkaSxMoOXgDUYtVNnqdJeHRrTfcWI(urllib.parse.parse_qsl(KzkaSxMoOXgDUYtVNnqdJeHRrTfcBw))
     KzkaSxMoOXgDUYtVNnqdJeHRrTfcQp=KzkaSxMoOXgDUYtVNnqdJeHRrTfcBm.get('code').strip()
     if KzkaSxMoOXgDUYtVNnqdJeHRrTfcBP!=KzkaSxMoOXgDUYtVNnqdJeHRrTfcQp:
      fp.write(KzkaSxMoOXgDUYtVNnqdJeHRrTfcBw)
    fp.close()
   except:
    KzkaSxMoOXgDUYtVNnqdJeHRrTfcQP
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ,KzkaSxMoOXgDUYtVNnqdJeHRrTfcBb):
  try:
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcQL=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%KzkaSxMoOXgDUYtVNnqdJeHRrTfcBb))
   fp=KzkaSxMoOXgDUYtVNnqdJeHRrTfcWL(KzkaSxMoOXgDUYtVNnqdJeHRrTfcQL,'r',-1,'utf-8')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcQI=fp.readlines()
   fp.close()
  except:
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcQI=[]
  return KzkaSxMoOXgDUYtVNnqdJeHRrTfcQI
 def Save_Watched_List(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ,stype,KzkaSxMoOXgDUYtVNnqdJeHRrTfcps):
  try:
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcQL=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcBC=KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.Load_List_File(stype) 
   fp=KzkaSxMoOXgDUYtVNnqdJeHRrTfcWL(KzkaSxMoOXgDUYtVNnqdJeHRrTfcQL,'w',-1,'utf-8')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcQB=urllib.parse.urlencode(KzkaSxMoOXgDUYtVNnqdJeHRrTfcps)
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcQB=KzkaSxMoOXgDUYtVNnqdJeHRrTfcQB+'\n'
   fp.write(KzkaSxMoOXgDUYtVNnqdJeHRrTfcQB)
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcQW=0
   for KzkaSxMoOXgDUYtVNnqdJeHRrTfcBw in KzkaSxMoOXgDUYtVNnqdJeHRrTfcBC:
    KzkaSxMoOXgDUYtVNnqdJeHRrTfcBm=KzkaSxMoOXgDUYtVNnqdJeHRrTfcWI(urllib.parse.parse_qsl(KzkaSxMoOXgDUYtVNnqdJeHRrTfcBw))
    KzkaSxMoOXgDUYtVNnqdJeHRrTfcQb=KzkaSxMoOXgDUYtVNnqdJeHRrTfcps.get('code')
    KzkaSxMoOXgDUYtVNnqdJeHRrTfcQs=KzkaSxMoOXgDUYtVNnqdJeHRrTfcBm.get('code')
    if KzkaSxMoOXgDUYtVNnqdJeHRrTfcQb!=KzkaSxMoOXgDUYtVNnqdJeHRrTfcQs:
     fp.write(KzkaSxMoOXgDUYtVNnqdJeHRrTfcBw)
     KzkaSxMoOXgDUYtVNnqdJeHRrTfcQW+=1
     if KzkaSxMoOXgDUYtVNnqdJeHRrTfcQW>=50:break
   fp.close()
  except:
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcQP
 def dp_Watch_List(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ,args):
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcBb ='vod'
  if KzkaSxMoOXgDUYtVNnqdJeHRrTfcBb=='vod':
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcQF=KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.Load_List_File(KzkaSxMoOXgDUYtVNnqdJeHRrTfcBb)
   for KzkaSxMoOXgDUYtVNnqdJeHRrTfcQy in KzkaSxMoOXgDUYtVNnqdJeHRrTfcQF:
    KzkaSxMoOXgDUYtVNnqdJeHRrTfcQA=KzkaSxMoOXgDUYtVNnqdJeHRrTfcWI(urllib.parse.parse_qsl(KzkaSxMoOXgDUYtVNnqdJeHRrTfcQy))
    KzkaSxMoOXgDUYtVNnqdJeHRrTfcpP =KzkaSxMoOXgDUYtVNnqdJeHRrTfcQA.get('title')
    KzkaSxMoOXgDUYtVNnqdJeHRrTfcLF=KzkaSxMoOXgDUYtVNnqdJeHRrTfcQA.get('img')
    KzkaSxMoOXgDUYtVNnqdJeHRrTfcBW=KzkaSxMoOXgDUYtVNnqdJeHRrTfcQA.get('code')
    KzkaSxMoOXgDUYtVNnqdJeHRrTfcQu =KzkaSxMoOXgDUYtVNnqdJeHRrTfcQA.get('info')
    KzkaSxMoOXgDUYtVNnqdJeHRrTfcLu={}
    KzkaSxMoOXgDUYtVNnqdJeHRrTfcLu['plot']=KzkaSxMoOXgDUYtVNnqdJeHRrTfcQu
    KzkaSxMoOXgDUYtVNnqdJeHRrTfcLI={'mode':'GAME_VOD_GROUP','gameid':KzkaSxMoOXgDUYtVNnqdJeHRrTfcBW,'saveTitle':KzkaSxMoOXgDUYtVNnqdJeHRrTfcpP,'saveImg':KzkaSxMoOXgDUYtVNnqdJeHRrTfcLF,'saveInfo':KzkaSxMoOXgDUYtVNnqdJeHRrTfcQu,'mediatype':KzkaSxMoOXgDUYtVNnqdJeHRrTfcBb}
    KzkaSxMoOXgDUYtVNnqdJeHRrTfcQv={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':KzkaSxMoOXgDUYtVNnqdJeHRrTfcBW,'vType':KzkaSxMoOXgDUYtVNnqdJeHRrTfcBb,}
    KzkaSxMoOXgDUYtVNnqdJeHRrTfcQi=urllib.parse.urlencode(KzkaSxMoOXgDUYtVNnqdJeHRrTfcQv)
    KzkaSxMoOXgDUYtVNnqdJeHRrTfcQj=[('선택된 시청이력 ( %s ) 삭제'%(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpP),'RunPlugin(plugin://plugin.video.spotvm/?%s)'%(KzkaSxMoOXgDUYtVNnqdJeHRrTfcQi))]
    KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.add_dir(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpP,sublabel='',img=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLF,infoLabels=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLu,isFolder=KzkaSxMoOXgDUYtVNnqdJeHRrTfcQG,params=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLI,ContextMenu=KzkaSxMoOXgDUYtVNnqdJeHRrTfcQj)
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLu={'plot':'시청목록을 삭제합니다.'}
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpP='*** 시청목록 삭제 ***'
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLI={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':KzkaSxMoOXgDUYtVNnqdJeHRrTfcBb,}
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcLp=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.add_dir(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpP,sublabel='',img=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLp,infoLabels=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLu,isFolder=KzkaSxMoOXgDUYtVNnqdJeHRrTfcQE,params=KzkaSxMoOXgDUYtVNnqdJeHRrTfcLI,isLink=KzkaSxMoOXgDUYtVNnqdJeHRrTfcQG)
   xbmcplugin.endOfDirectory(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ._addon_handle,cacheToDisc=KzkaSxMoOXgDUYtVNnqdJeHRrTfcQE)
 def spotv_main(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ):
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcQh=KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.main_params.get('mode',KzkaSxMoOXgDUYtVNnqdJeHRrTfcQP)
  if KzkaSxMoOXgDUYtVNnqdJeHRrTfcQh=='LOGOUT':
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.logout()
   return
  KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.login_main()
  if KzkaSxMoOXgDUYtVNnqdJeHRrTfcQh is KzkaSxMoOXgDUYtVNnqdJeHRrTfcQP:
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.dp_Main_List()
  elif KzkaSxMoOXgDUYtVNnqdJeHRrTfcQh=='LIVE_GROUP':
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.dp_LiveChannel_List(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.main_params)
  elif KzkaSxMoOXgDUYtVNnqdJeHRrTfcQh=='ELIVE_GROUP':
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcBI=KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.dp_EventLiveChannel_List(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.main_params)
   if KzkaSxMoOXgDUYtVNnqdJeHRrTfcBI==401:
    if os.path.isfile(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpB):os.remove(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpB)
    KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.login_main()
    KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.dp_EventLiveChannel_List(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.main_params)
  elif KzkaSxMoOXgDUYtVNnqdJeHRrTfcQh in['LIVE','GAME_VOD','POP_VOD','NOW_VOD','ELIVE']:
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.play_VIDEO(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.main_params)
  elif KzkaSxMoOXgDUYtVNnqdJeHRrTfcQh=='VOD_GROUP':
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.dp_MainLeague_List(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.main_params)
  elif KzkaSxMoOXgDUYtVNnqdJeHRrTfcQh=='NOW_GROUP':
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.dp_NowVod_GroupList(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.main_params)
  elif KzkaSxMoOXgDUYtVNnqdJeHRrTfcQh=='POP_GROUP':
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.dp_PopVod_GroupList(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.main_params)
  elif KzkaSxMoOXgDUYtVNnqdJeHRrTfcQh=='LEAGUE_GROUP':
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.dp_Season_List(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.main_params)
  elif KzkaSxMoOXgDUYtVNnqdJeHRrTfcQh=='SEASON_GROUP':
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.dp_Game_List(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.main_params)
  elif KzkaSxMoOXgDUYtVNnqdJeHRrTfcQh=='GAME_VOD_GROUP':
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.dp_GameVod_List(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.main_params)
  elif KzkaSxMoOXgDUYtVNnqdJeHRrTfcQh=='WATCH':
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.dp_Watch_List(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.main_params)
  elif KzkaSxMoOXgDUYtVNnqdJeHRrTfcQh=='MYVIEW_REMOVE':
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.dp_History_Remove(KzkaSxMoOXgDUYtVNnqdJeHRrTfcpQ.main_params)
  else:
   KzkaSxMoOXgDUYtVNnqdJeHRrTfcQP
# Created by pyminifier (https://github.com/liftoff/pyminifier)
