__author__="NightRain"
JjpElDexdKWctgfYFnoubAOXMhRkaP=object
JjpElDexdKWctgfYFnoubAOXMhRkaz=None
JjpElDexdKWctgfYFnoubAOXMhRkai=False
JjpElDexdKWctgfYFnoubAOXMhRkaU=open
JjpElDexdKWctgfYFnoubAOXMhRkaB=True
JjpElDexdKWctgfYFnoubAOXMhRkav=str
JjpElDexdKWctgfYFnoubAOXMhRkaL=Exception
JjpElDexdKWctgfYFnoubAOXMhRkaI=print
JjpElDexdKWctgfYFnoubAOXMhRkas=int
JjpElDexdKWctgfYFnoubAOXMhRkar=len
JjpElDexdKWctgfYFnoubAOXMhRkaw=range
import urllib
import re
import json
import sys
import time
import requests
import datetime
import base64
JjpElDexdKWctgfYFnoubAOXMhRkTm={'stream50':1080,'stream40':720,'stream30':540}
class JjpElDexdKWctgfYFnoubAOXMhRkTH(JjpElDexdKWctgfYFnoubAOXMhRkaP):
 def __init__(JjpElDexdKWctgfYFnoubAOXMhRkTq):
  JjpElDexdKWctgfYFnoubAOXMhRkTq.SPOTV_PMCODE ='987'
  JjpElDexdKWctgfYFnoubAOXMhRkTq.SPOTV_PMSIZE =3
  JjpElDexdKWctgfYFnoubAOXMhRkTq.GAMELIST_LIMIT =10
  JjpElDexdKWctgfYFnoubAOXMhRkTq.API_DOMAIN ='https://www.spotvnow.co.kr'
  JjpElDexdKWctgfYFnoubAOXMhRkTq.BC_DOMAIN ='https://players.brightcove.net'
  JjpElDexdKWctgfYFnoubAOXMhRkTq.PLAYER_DOMAIN ='https://edge.api.brightcove.com'
  JjpElDexdKWctgfYFnoubAOXMhRkTq.STREAM_DOMAIN ='https://gtm-spotv.brightcovecdn.com'
  JjpElDexdKWctgfYFnoubAOXMhRkTq.STREAM_M3U8 ='ap-northeast-1/5764318566001/playlist_dvr'
  JjpElDexdKWctgfYFnoubAOXMhRkTq.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36'
  JjpElDexdKWctgfYFnoubAOXMhRkTq.DEFAULT_HEADER ={'user-agent':JjpElDexdKWctgfYFnoubAOXMhRkTq.USER_AGENT}
  JjpElDexdKWctgfYFnoubAOXMhRkTq.ST ={}
  JjpElDexdKWctgfYFnoubAOXMhRkTq.Init_ST_Total()
 def Init_ST_Total(JjpElDexdKWctgfYFnoubAOXMhRkTq):
  JjpElDexdKWctgfYFnoubAOXMhRkTq.ST={'account':{},'cookies':{'spotv_sessionid':'','spotv_session':'','spotv_accountId':'','spotv_policyKey':'','spotv_subend':'',},}
 def callRequestCookies(JjpElDexdKWctgfYFnoubAOXMhRkTq,jobtype,JjpElDexdKWctgfYFnoubAOXMhRkTw,payload=JjpElDexdKWctgfYFnoubAOXMhRkaz,params=JjpElDexdKWctgfYFnoubAOXMhRkaz,headers=JjpElDexdKWctgfYFnoubAOXMhRkaz,cookies=JjpElDexdKWctgfYFnoubAOXMhRkaz,redirects=JjpElDexdKWctgfYFnoubAOXMhRkai):
  JjpElDexdKWctgfYFnoubAOXMhRkTa=JjpElDexdKWctgfYFnoubAOXMhRkTq.DEFAULT_HEADER
  if headers:JjpElDexdKWctgfYFnoubAOXMhRkTa.update(headers)
  if jobtype=='Get':
   JjpElDexdKWctgfYFnoubAOXMhRkTC=requests.get(JjpElDexdKWctgfYFnoubAOXMhRkTw,params=params,headers=JjpElDexdKWctgfYFnoubAOXMhRkTa,cookies=cookies,allow_redirects=redirects)
  else:
   JjpElDexdKWctgfYFnoubAOXMhRkTC=requests.post(JjpElDexdKWctgfYFnoubAOXMhRkTw,data=payload,params=params,headers=JjpElDexdKWctgfYFnoubAOXMhRkTa,cookies=cookies,allow_redirects=redirects)
  return JjpElDexdKWctgfYFnoubAOXMhRkTC
 def JsonFile_Save(JjpElDexdKWctgfYFnoubAOXMhRkTq,filename,JjpElDexdKWctgfYFnoubAOXMhRkTG):
  if filename=='':return JjpElDexdKWctgfYFnoubAOXMhRkai
  try:
   fp=JjpElDexdKWctgfYFnoubAOXMhRkaU(filename,'w',-1,'utf-8')
   json.dump(JjpElDexdKWctgfYFnoubAOXMhRkTG,fp,indent=4,ensure_ascii=JjpElDexdKWctgfYFnoubAOXMhRkai)
   fp.close()
  except:
   return JjpElDexdKWctgfYFnoubAOXMhRkai
  return JjpElDexdKWctgfYFnoubAOXMhRkaB
 def JsonFile_Load(JjpElDexdKWctgfYFnoubAOXMhRkTq,filename):
  if filename=='':return{}
  try:
   fp=JjpElDexdKWctgfYFnoubAOXMhRkaU(filename,'r',-1,'utf-8')
   JjpElDexdKWctgfYFnoubAOXMhRkTS=json.load(fp)
   fp.close()
  except:
   return{}
  return JjpElDexdKWctgfYFnoubAOXMhRkTS
 def Save_session_acount(JjpElDexdKWctgfYFnoubAOXMhRkTq,JjpElDexdKWctgfYFnoubAOXMhRkTV,JjpElDexdKWctgfYFnoubAOXMhRkTN):
  JjpElDexdKWctgfYFnoubAOXMhRkTq.ST['account']['stid'] =base64.standard_b64encode(JjpElDexdKWctgfYFnoubAOXMhRkTV.encode()).decode('utf-8')
  JjpElDexdKWctgfYFnoubAOXMhRkTq.ST['account']['stpw'] =base64.standard_b64encode(JjpElDexdKWctgfYFnoubAOXMhRkTN.encode()).decode('utf-8')
 def Load_session_acount(JjpElDexdKWctgfYFnoubAOXMhRkTq):
  try:
   JjpElDexdKWctgfYFnoubAOXMhRkTV =base64.standard_b64decode(JjpElDexdKWctgfYFnoubAOXMhRkTq.ST['account']['stid']).decode('utf-8')
   JjpElDexdKWctgfYFnoubAOXMhRkTN =base64.standard_b64decode(JjpElDexdKWctgfYFnoubAOXMhRkTq.ST['account']['stpw']).decode('utf-8')
  except:
   return '',''
  return JjpElDexdKWctgfYFnoubAOXMhRkTV,JjpElDexdKWctgfYFnoubAOXMhRkTN
 def makeDefaultCookies(JjpElDexdKWctgfYFnoubAOXMhRkTq):
  JjpElDexdKWctgfYFnoubAOXMhRkTQ={'SESSION':JjpElDexdKWctgfYFnoubAOXMhRkTq.ST['cookies']['spotv_session']}
  return JjpElDexdKWctgfYFnoubAOXMhRkTQ
 def makeDefaultHeaders(JjpElDexdKWctgfYFnoubAOXMhRkTq):
  JjpElDexdKWctgfYFnoubAOXMhRkTP={'accept':'application/json;pk={}'.format(JjpElDexdKWctgfYFnoubAOXMhRkTq.ST['cookies']['spotv_policyKey'])}
  return JjpElDexdKWctgfYFnoubAOXMhRkTP
 def xmlText(JjpElDexdKWctgfYFnoubAOXMhRkTq,in_text):
  JjpElDexdKWctgfYFnoubAOXMhRkTz=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;')
  return JjpElDexdKWctgfYFnoubAOXMhRkTz
 def GetCredential(JjpElDexdKWctgfYFnoubAOXMhRkTq,user_id,user_pw):
  try:
   JjpElDexdKWctgfYFnoubAOXMhRkTi=base64.standard_b64encode(user_id.encode('UTF-8')).decode('utf-8')
   JjpElDexdKWctgfYFnoubAOXMhRkTU=base64.standard_b64encode(user_pw.encode('UTF-8')).decode('utf-8')
   JjpElDexdKWctgfYFnoubAOXMhRkTB=JjpElDexdKWctgfYFnoubAOXMhRkTq.API_DOMAIN+'/api/v2/login'
   JjpElDexdKWctgfYFnoubAOXMhRkTv={'username':JjpElDexdKWctgfYFnoubAOXMhRkTi,'password':JjpElDexdKWctgfYFnoubAOXMhRkTU}
   JjpElDexdKWctgfYFnoubAOXMhRkTv=json.dumps(JjpElDexdKWctgfYFnoubAOXMhRkTv)
   JjpElDexdKWctgfYFnoubAOXMhRkTL=JjpElDexdKWctgfYFnoubAOXMhRkTq.callRequestCookies('Post',JjpElDexdKWctgfYFnoubAOXMhRkTB,payload=JjpElDexdKWctgfYFnoubAOXMhRkTv,params=JjpElDexdKWctgfYFnoubAOXMhRkaz,headers=JjpElDexdKWctgfYFnoubAOXMhRkaz,cookies=JjpElDexdKWctgfYFnoubAOXMhRkaz)
   JjpElDexdKWctgfYFnoubAOXMhRkTI=json.loads(JjpElDexdKWctgfYFnoubAOXMhRkTL.text)
   for JjpElDexdKWctgfYFnoubAOXMhRkTs in JjpElDexdKWctgfYFnoubAOXMhRkTL.cookies:
    if JjpElDexdKWctgfYFnoubAOXMhRkTs.name=='SESSION':
     JjpElDexdKWctgfYFnoubAOXMhRkTq.ST['cookies']['spotv_session']=JjpElDexdKWctgfYFnoubAOXMhRkTs.value
     break
   if JjpElDexdKWctgfYFnoubAOXMhRkTq.ST['cookies']['spotv_session']=='':
    JjpElDexdKWctgfYFnoubAOXMhRkTq.Init_ST_Total()
    return JjpElDexdKWctgfYFnoubAOXMhRkai
   JjpElDexdKWctgfYFnoubAOXMhRkTq.ST['cookies']['spotv_sessionid']=JjpElDexdKWctgfYFnoubAOXMhRkav(JjpElDexdKWctgfYFnoubAOXMhRkTI['userId'])
   JjpElDexdKWctgfYFnoubAOXMhRkTr=JjpElDexdKWctgfYFnoubAOXMhRkTq.SPOTV_PMCODE+JjpElDexdKWctgfYFnoubAOXMhRkav(JjpElDexdKWctgfYFnoubAOXMhRkTI['subEndTime'])
   JjpElDexdKWctgfYFnoubAOXMhRkTq.ST['cookies']['spotv_subend'] =base64.standard_b64encode(JjpElDexdKWctgfYFnoubAOXMhRkTr.encode()).decode('utf-8')
   if JjpElDexdKWctgfYFnoubAOXMhRkTq.GetPolicyKey()==JjpElDexdKWctgfYFnoubAOXMhRkai:
    JjpElDexdKWctgfYFnoubAOXMhRkTq.Init_ST_Total()
    return JjpElDexdKWctgfYFnoubAOXMhRkai
  except JjpElDexdKWctgfYFnoubAOXMhRkaL as exception:
   JjpElDexdKWctgfYFnoubAOXMhRkaI(exception)
   JjpElDexdKWctgfYFnoubAOXMhRkTq.Init_ST_Total()
   return JjpElDexdKWctgfYFnoubAOXMhRkai
  return JjpElDexdKWctgfYFnoubAOXMhRkaB
 def GetPolicyKey(JjpElDexdKWctgfYFnoubAOXMhRkTq):
  try:
   JjpElDexdKWctgfYFnoubAOXMhRkTw=JjpElDexdKWctgfYFnoubAOXMhRkTq.GetBcPlayerUrl()
   if JjpElDexdKWctgfYFnoubAOXMhRkTw=='':return JjpElDexdKWctgfYFnoubAOXMhRkai
   JjpElDexdKWctgfYFnoubAOXMhRkTL=JjpElDexdKWctgfYFnoubAOXMhRkTq.callRequestCookies('Get',JjpElDexdKWctgfYFnoubAOXMhRkTw,payload=JjpElDexdKWctgfYFnoubAOXMhRkaz,params=JjpElDexdKWctgfYFnoubAOXMhRkaz,headers=JjpElDexdKWctgfYFnoubAOXMhRkaz,cookies=JjpElDexdKWctgfYFnoubAOXMhRkaz)
   JjpElDexdKWctgfYFnoubAOXMhRkHT=JjpElDexdKWctgfYFnoubAOXMhRkTL.text
   JjpElDexdKWctgfYFnoubAOXMhRkHm =re.findall('accountId:\s*\"\d{13}\",\s*policyKey:\s*\".[^(){}]{100,300}\"',JjpElDexdKWctgfYFnoubAOXMhRkHT)[0]
   JjpElDexdKWctgfYFnoubAOXMhRkHm =JjpElDexdKWctgfYFnoubAOXMhRkHm.replace('accountId','"accountId"')
   JjpElDexdKWctgfYFnoubAOXMhRkHm =JjpElDexdKWctgfYFnoubAOXMhRkHm.replace('policyKey','"policyKey"')
   JjpElDexdKWctgfYFnoubAOXMhRkHm ='{'+JjpElDexdKWctgfYFnoubAOXMhRkHm+'}'
   JjpElDexdKWctgfYFnoubAOXMhRkHq=json.loads(JjpElDexdKWctgfYFnoubAOXMhRkHm)
   JjpElDexdKWctgfYFnoubAOXMhRkTq.ST['cookies']['spotv_accountId']=JjpElDexdKWctgfYFnoubAOXMhRkHq['accountId']
   JjpElDexdKWctgfYFnoubAOXMhRkTq.ST['cookies']['spotv_policyKey']=JjpElDexdKWctgfYFnoubAOXMhRkHq['policyKey']
  except JjpElDexdKWctgfYFnoubAOXMhRkaL as exception:
   JjpElDexdKWctgfYFnoubAOXMhRkaI(exception)
   return JjpElDexdKWctgfYFnoubAOXMhRkai
  return JjpElDexdKWctgfYFnoubAOXMhRkaB
 def GetBcPlayerUrl(JjpElDexdKWctgfYFnoubAOXMhRkTq):
  JjpElDexdKWctgfYFnoubAOXMhRkHa=''
  try:
   JjpElDexdKWctgfYFnoubAOXMhRkTw=JjpElDexdKWctgfYFnoubAOXMhRkTq.GetMainJspath()
   if JjpElDexdKWctgfYFnoubAOXMhRkTw=='':return JjpElDexdKWctgfYFnoubAOXMhRkHa
   JjpElDexdKWctgfYFnoubAOXMhRkTL=JjpElDexdKWctgfYFnoubAOXMhRkTq.callRequestCookies('Get',JjpElDexdKWctgfYFnoubAOXMhRkTw,payload=JjpElDexdKWctgfYFnoubAOXMhRkaz,params=JjpElDexdKWctgfYFnoubAOXMhRkaz,headers=JjpElDexdKWctgfYFnoubAOXMhRkaz,cookies=JjpElDexdKWctgfYFnoubAOXMhRkaz)
   JjpElDexdKWctgfYFnoubAOXMhRkHT=JjpElDexdKWctgfYFnoubAOXMhRkTL.text
   JjpElDexdKWctgfYFnoubAOXMhRkHC =r'default:{(.*?)}'
   JjpElDexdKWctgfYFnoubAOXMhRkHG =re.compile(JjpElDexdKWctgfYFnoubAOXMhRkHC).findall(JjpElDexdKWctgfYFnoubAOXMhRkHT)[0]
   JjpElDexdKWctgfYFnoubAOXMhRkHy=r'bc:"(.*?)"'
   JjpElDexdKWctgfYFnoubAOXMhRkHS=re.compile(JjpElDexdKWctgfYFnoubAOXMhRkHy).findall(JjpElDexdKWctgfYFnoubAOXMhRkHG)[0]
   JjpElDexdKWctgfYFnoubAOXMhRkHV=r'":"(.*?)"'
   JjpElDexdKWctgfYFnoubAOXMhRkHN=re.compile(JjpElDexdKWctgfYFnoubAOXMhRkHV).findall(JjpElDexdKWctgfYFnoubAOXMhRkHG)[0]
   JjpElDexdKWctgfYFnoubAOXMhRkHa="%s/%s/%s_default/index.min.js"%(JjpElDexdKWctgfYFnoubAOXMhRkTq.BC_DOMAIN,JjpElDexdKWctgfYFnoubAOXMhRkHS,JjpElDexdKWctgfYFnoubAOXMhRkHN)
  except JjpElDexdKWctgfYFnoubAOXMhRkaL as exception:
   JjpElDexdKWctgfYFnoubAOXMhRkaI(exception)
  return JjpElDexdKWctgfYFnoubAOXMhRkHa
 def GetMainJspath(JjpElDexdKWctgfYFnoubAOXMhRkTq):
  JjpElDexdKWctgfYFnoubAOXMhRkHQ=''
  try:
   JjpElDexdKWctgfYFnoubAOXMhRkTw=JjpElDexdKWctgfYFnoubAOXMhRkTq.API_DOMAIN
   JjpElDexdKWctgfYFnoubAOXMhRkTL=JjpElDexdKWctgfYFnoubAOXMhRkTq.callRequestCookies('Get',JjpElDexdKWctgfYFnoubAOXMhRkTw,payload=JjpElDexdKWctgfYFnoubAOXMhRkaz,params=JjpElDexdKWctgfYFnoubAOXMhRkaz,headers=JjpElDexdKWctgfYFnoubAOXMhRkaz,cookies=JjpElDexdKWctgfYFnoubAOXMhRkaz)
   JjpElDexdKWctgfYFnoubAOXMhRkHT=JjpElDexdKWctgfYFnoubAOXMhRkTL.text
   JjpElDexdKWctgfYFnoubAOXMhRkHm =re.findall('https://cdn.spotvnow.co.kr/dist/js/.{20}\.js',JjpElDexdKWctgfYFnoubAOXMhRkHT)[0]
   JjpElDexdKWctgfYFnoubAOXMhRkHQ=JjpElDexdKWctgfYFnoubAOXMhRkHm
  except JjpElDexdKWctgfYFnoubAOXMhRkaL as exception:
   JjpElDexdKWctgfYFnoubAOXMhRkaI(exception)
  return JjpElDexdKWctgfYFnoubAOXMhRkHQ
 def Get_Now_Datetime(JjpElDexdKWctgfYFnoubAOXMhRkTq):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetLiveChannelList(JjpElDexdKWctgfYFnoubAOXMhRkTq):
  JjpElDexdKWctgfYFnoubAOXMhRkHz=[]
  JjpElDexdKWctgfYFnoubAOXMhRkHi ={}
  try:
   JjpElDexdKWctgfYFnoubAOXMhRkTw=JjpElDexdKWctgfYFnoubAOXMhRkTq.API_DOMAIN+'/api/v2/channel'
   JjpElDexdKWctgfYFnoubAOXMhRkTL=JjpElDexdKWctgfYFnoubAOXMhRkTq.callRequestCookies('Get',JjpElDexdKWctgfYFnoubAOXMhRkTw,payload=JjpElDexdKWctgfYFnoubAOXMhRkaz,params=JjpElDexdKWctgfYFnoubAOXMhRkaz,headers=JjpElDexdKWctgfYFnoubAOXMhRkaz,cookies=JjpElDexdKWctgfYFnoubAOXMhRkaz)
   JjpElDexdKWctgfYFnoubAOXMhRkTI=json.loads(JjpElDexdKWctgfYFnoubAOXMhRkTL.text)
   JjpElDexdKWctgfYFnoubAOXMhRkHi=JjpElDexdKWctgfYFnoubAOXMhRkTq.GetEPGList()
   for JjpElDexdKWctgfYFnoubAOXMhRkHU in JjpElDexdKWctgfYFnoubAOXMhRkTI:
    JjpElDexdKWctgfYFnoubAOXMhRkHB={'id':JjpElDexdKWctgfYFnoubAOXMhRkHU['id'],'name':JjpElDexdKWctgfYFnoubAOXMhRkHU['name'],'logo':JjpElDexdKWctgfYFnoubAOXMhRkHU['logo'],'free':JjpElDexdKWctgfYFnoubAOXMhRkHU['free'],'programName':JjpElDexdKWctgfYFnoubAOXMhRkHU['programName'],'channelepg':JjpElDexdKWctgfYFnoubAOXMhRkHi.get(JjpElDexdKWctgfYFnoubAOXMhRkHU['id']),'hlsUrl':JjpElDexdKWctgfYFnoubAOXMhRkHU['hlsUrl'],}
    JjpElDexdKWctgfYFnoubAOXMhRkHz.append(JjpElDexdKWctgfYFnoubAOXMhRkHB)
  except JjpElDexdKWctgfYFnoubAOXMhRkaL as exception:
   JjpElDexdKWctgfYFnoubAOXMhRkaI(exception)
  return JjpElDexdKWctgfYFnoubAOXMhRkHz
 def GetHlsUrl(JjpElDexdKWctgfYFnoubAOXMhRkTq,mediacode):
  JjpElDexdKWctgfYFnoubAOXMhRkHv=''
  try:
   JjpElDexdKWctgfYFnoubAOXMhRkTw=JjpElDexdKWctgfYFnoubAOXMhRkTq.API_DOMAIN+'/api/v2/channel'
   JjpElDexdKWctgfYFnoubAOXMhRkTL=JjpElDexdKWctgfYFnoubAOXMhRkTq.callRequestCookies('Get',JjpElDexdKWctgfYFnoubAOXMhRkTw,payload=JjpElDexdKWctgfYFnoubAOXMhRkaz,params=JjpElDexdKWctgfYFnoubAOXMhRkaz,headers=JjpElDexdKWctgfYFnoubAOXMhRkaz,cookies=JjpElDexdKWctgfYFnoubAOXMhRkaz)
   JjpElDexdKWctgfYFnoubAOXMhRkTI=json.loads(JjpElDexdKWctgfYFnoubAOXMhRkTL.text)
   for JjpElDexdKWctgfYFnoubAOXMhRkHU in JjpElDexdKWctgfYFnoubAOXMhRkTI:
    if JjpElDexdKWctgfYFnoubAOXMhRkav(JjpElDexdKWctgfYFnoubAOXMhRkHU['id'])==JjpElDexdKWctgfYFnoubAOXMhRkav(mediacode):
     JjpElDexdKWctgfYFnoubAOXMhRkHv=JjpElDexdKWctgfYFnoubAOXMhRkHU['hlsUrl']
     break
  except JjpElDexdKWctgfYFnoubAOXMhRkaL as exception:
   JjpElDexdKWctgfYFnoubAOXMhRkaI(exception)
  return JjpElDexdKWctgfYFnoubAOXMhRkHv
 def GetEPGList(JjpElDexdKWctgfYFnoubAOXMhRkTq):
  JjpElDexdKWctgfYFnoubAOXMhRkHL={}
  JjpElDexdKWctgfYFnoubAOXMhRkHI=JjpElDexdKWctgfYFnoubAOXMhRkTq.Get_Now_Datetime()
  JjpElDexdKWctgfYFnoubAOXMhRkHs=JjpElDexdKWctgfYFnoubAOXMhRkHI.strftime('%Y%m%d%H%M')
  JjpElDexdKWctgfYFnoubAOXMhRkHr='%s-%s-%s'%(JjpElDexdKWctgfYFnoubAOXMhRkHs[0:4],JjpElDexdKWctgfYFnoubAOXMhRkHs[4:6],JjpElDexdKWctgfYFnoubAOXMhRkHs[6:8])
  JjpElDexdKWctgfYFnoubAOXMhRkHw=(JjpElDexdKWctgfYFnoubAOXMhRkHI+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M')
  try:
   JjpElDexdKWctgfYFnoubAOXMhRkTw=JjpElDexdKWctgfYFnoubAOXMhRkTq.API_DOMAIN+'/api/v2/program/'+JjpElDexdKWctgfYFnoubAOXMhRkHr
   JjpElDexdKWctgfYFnoubAOXMhRkTL=JjpElDexdKWctgfYFnoubAOXMhRkTq.callRequestCookies('Get',JjpElDexdKWctgfYFnoubAOXMhRkTw,payload=JjpElDexdKWctgfYFnoubAOXMhRkaz,params=JjpElDexdKWctgfYFnoubAOXMhRkaz,headers=JjpElDexdKWctgfYFnoubAOXMhRkaz,cookies=JjpElDexdKWctgfYFnoubAOXMhRkaz)
   JjpElDexdKWctgfYFnoubAOXMhRkTI=json.loads(JjpElDexdKWctgfYFnoubAOXMhRkTL.text)
   JjpElDexdKWctgfYFnoubAOXMhRkmT=-1 
   JjpElDexdKWctgfYFnoubAOXMhRkmH =''
   for JjpElDexdKWctgfYFnoubAOXMhRkHU in JjpElDexdKWctgfYFnoubAOXMhRkTI:
    JjpElDexdKWctgfYFnoubAOXMhRkmq=JjpElDexdKWctgfYFnoubAOXMhRkHU['channelId']
    JjpElDexdKWctgfYFnoubAOXMhRkma =JjpElDexdKWctgfYFnoubAOXMhRkHU['startTime'].replace('-','').replace(' ','').replace(':','')
    JjpElDexdKWctgfYFnoubAOXMhRkmC =JjpElDexdKWctgfYFnoubAOXMhRkHU['endTime'].replace('-','').replace(' ','').replace(':','')
    if JjpElDexdKWctgfYFnoubAOXMhRkas(JjpElDexdKWctgfYFnoubAOXMhRkHs)>JjpElDexdKWctgfYFnoubAOXMhRkas(JjpElDexdKWctgfYFnoubAOXMhRkmC) :continue
    if JjpElDexdKWctgfYFnoubAOXMhRkas(JjpElDexdKWctgfYFnoubAOXMhRkHw)<JjpElDexdKWctgfYFnoubAOXMhRkas(JjpElDexdKWctgfYFnoubAOXMhRkma):continue
    if JjpElDexdKWctgfYFnoubAOXMhRkmT!=JjpElDexdKWctgfYFnoubAOXMhRkmq:
     if JjpElDexdKWctgfYFnoubAOXMhRkmH!='':JjpElDexdKWctgfYFnoubAOXMhRkHL[JjpElDexdKWctgfYFnoubAOXMhRkmT]=JjpElDexdKWctgfYFnoubAOXMhRkmH
     JjpElDexdKWctgfYFnoubAOXMhRkmT=JjpElDexdKWctgfYFnoubAOXMhRkmq
     JjpElDexdKWctgfYFnoubAOXMhRkmH =''
    if JjpElDexdKWctgfYFnoubAOXMhRkmH:JjpElDexdKWctgfYFnoubAOXMhRkmH+='\n'
    JjpElDexdKWctgfYFnoubAOXMhRkmH+=JjpElDexdKWctgfYFnoubAOXMhRkHU['title']+'\n'
    JjpElDexdKWctgfYFnoubAOXMhRkmH+=' [%s ~ %s]'%(JjpElDexdKWctgfYFnoubAOXMhRkHU['startTime'][-5:],JjpElDexdKWctgfYFnoubAOXMhRkHU['endTime'][-5:])+'\n'
   if JjpElDexdKWctgfYFnoubAOXMhRkmH:JjpElDexdKWctgfYFnoubAOXMhRkHL[JjpElDexdKWctgfYFnoubAOXMhRkmT]=JjpElDexdKWctgfYFnoubAOXMhRkmH
  except JjpElDexdKWctgfYFnoubAOXMhRkaL as exception:
   JjpElDexdKWctgfYFnoubAOXMhRkaI(exception)
  return JjpElDexdKWctgfYFnoubAOXMhRkHL
 def GetEPGList_new(JjpElDexdKWctgfYFnoubAOXMhRkTq):
  JjpElDexdKWctgfYFnoubAOXMhRkHL={}
  JjpElDexdKWctgfYFnoubAOXMhRkHI=JjpElDexdKWctgfYFnoubAOXMhRkTq.Get_Now_Datetime()
  JjpElDexdKWctgfYFnoubAOXMhRkHs=JjpElDexdKWctgfYFnoubAOXMhRkHI.strftime('%Y%m%d%H%M00')
  JjpElDexdKWctgfYFnoubAOXMhRkHr='%s%s%s'%(JjpElDexdKWctgfYFnoubAOXMhRkHs[0:4],JjpElDexdKWctgfYFnoubAOXMhRkHs[4:6],JjpElDexdKWctgfYFnoubAOXMhRkHs[6:8])
  JjpElDexdKWctgfYFnoubAOXMhRkHw=(JjpElDexdKWctgfYFnoubAOXMhRkHI+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M00')
  try:
   for JjpElDexdKWctgfYFnoubAOXMhRkHU in LIVETV_LIST:
    JjpElDexdKWctgfYFnoubAOXMhRkmG =JjpElDexdKWctgfYFnoubAOXMhRkHU['videoId']
    if JjpElDexdKWctgfYFnoubAOXMhRkHU['epgtype']=='spotvon':
     JjpElDexdKWctgfYFnoubAOXMhRkmH=JjpElDexdKWctgfYFnoubAOXMhRkTq.Get_EpgInfo_Spotv_spotvon(JjpElDexdKWctgfYFnoubAOXMhRkmG,JjpElDexdKWctgfYFnoubAOXMhRkHU['epgnm'],JjpElDexdKWctgfYFnoubAOXMhRkHr)
     JjpElDexdKWctgfYFnoubAOXMhRkHL[JjpElDexdKWctgfYFnoubAOXMhRkmG]=JjpElDexdKWctgfYFnoubAOXMhRkmH
    if JjpElDexdKWctgfYFnoubAOXMhRkHU['epgtype']=='spotvnet':
     JjpElDexdKWctgfYFnoubAOXMhRkmH=JjpElDexdKWctgfYFnoubAOXMhRkTq.Get_EpgInfo_Spotv_spotvnet(JjpElDexdKWctgfYFnoubAOXMhRkmG,JjpElDexdKWctgfYFnoubAOXMhRkHU['epgnm'],JjpElDexdKWctgfYFnoubAOXMhRkHr)
     JjpElDexdKWctgfYFnoubAOXMhRkHL[JjpElDexdKWctgfYFnoubAOXMhRkmG]=JjpElDexdKWctgfYFnoubAOXMhRkmH
   for JjpElDexdKWctgfYFnoubAOXMhRkmy in JjpElDexdKWctgfYFnoubAOXMhRkHL.keys():
    if JjpElDexdKWctgfYFnoubAOXMhRkar(JjpElDexdKWctgfYFnoubAOXMhRkHL.get(JjpElDexdKWctgfYFnoubAOXMhRkmy))==0:continue
    JjpElDexdKWctgfYFnoubAOXMhRkmH =''
    JjpElDexdKWctgfYFnoubAOXMhRkmS=''
    for JjpElDexdKWctgfYFnoubAOXMhRkmV in JjpElDexdKWctgfYFnoubAOXMhRkHL.get(JjpElDexdKWctgfYFnoubAOXMhRkmy):
     JjpElDexdKWctgfYFnoubAOXMhRkma =JjpElDexdKWctgfYFnoubAOXMhRkmV['startTime']
     JjpElDexdKWctgfYFnoubAOXMhRkmC =JjpElDexdKWctgfYFnoubAOXMhRkmV['endTime']
     if JjpElDexdKWctgfYFnoubAOXMhRkas(JjpElDexdKWctgfYFnoubAOXMhRkHs)>JjpElDexdKWctgfYFnoubAOXMhRkas(JjpElDexdKWctgfYFnoubAOXMhRkmC) :continue
     if JjpElDexdKWctgfYFnoubAOXMhRkas(JjpElDexdKWctgfYFnoubAOXMhRkHw)<JjpElDexdKWctgfYFnoubAOXMhRkas(JjpElDexdKWctgfYFnoubAOXMhRkma):continue
     if JjpElDexdKWctgfYFnoubAOXMhRkas(JjpElDexdKWctgfYFnoubAOXMhRkHs)>=JjpElDexdKWctgfYFnoubAOXMhRkas(JjpElDexdKWctgfYFnoubAOXMhRkma)and JjpElDexdKWctgfYFnoubAOXMhRkas(JjpElDexdKWctgfYFnoubAOXMhRkHs)<JjpElDexdKWctgfYFnoubAOXMhRkas(JjpElDexdKWctgfYFnoubAOXMhRkmC):JjpElDexdKWctgfYFnoubAOXMhRkmS=JjpElDexdKWctgfYFnoubAOXMhRkTq.xmlText(JjpElDexdKWctgfYFnoubAOXMhRkmV['title'])
     if JjpElDexdKWctgfYFnoubAOXMhRkmH:JjpElDexdKWctgfYFnoubAOXMhRkmH+='\n'
     JjpElDexdKWctgfYFnoubAOXMhRkmH+=JjpElDexdKWctgfYFnoubAOXMhRkTq.xmlText(JjpElDexdKWctgfYFnoubAOXMhRkmV['title'])+'\n'
     JjpElDexdKWctgfYFnoubAOXMhRkmH+=' [%s:%s ~ %s:%s]'%(JjpElDexdKWctgfYFnoubAOXMhRkmV['startTime'][8:10],JjpElDexdKWctgfYFnoubAOXMhRkmV['startTime'][10:12],JjpElDexdKWctgfYFnoubAOXMhRkmV['endTime'][8:10],JjpElDexdKWctgfYFnoubAOXMhRkmV['endTime'][10:12])+'\n'
    JjpElDexdKWctgfYFnoubAOXMhRkHL[JjpElDexdKWctgfYFnoubAOXMhRkmy]={'epg':JjpElDexdKWctgfYFnoubAOXMhRkmH,'title':JjpElDexdKWctgfYFnoubAOXMhRkmS}
  except JjpElDexdKWctgfYFnoubAOXMhRkaL as exception:
   JjpElDexdKWctgfYFnoubAOXMhRkaI(exception)
  return JjpElDexdKWctgfYFnoubAOXMhRkHL
 def Get_EpgInfo_Spotv_spotvon(JjpElDexdKWctgfYFnoubAOXMhRkTq,JjpElDexdKWctgfYFnoubAOXMhRkmG,epgnm,now_day):
  JjpElDexdKWctgfYFnoubAOXMhRkHL =[]
  try:
   JjpElDexdKWctgfYFnoubAOXMhRkTw='https://www.spotvon.co.kr/data/onAir/%s/Daily/D%s.asp'%(epgnm,now_day)
   JjpElDexdKWctgfYFnoubAOXMhRkTL=JjpElDexdKWctgfYFnoubAOXMhRkTq.callRequestCookies('Get',JjpElDexdKWctgfYFnoubAOXMhRkTw,payload=JjpElDexdKWctgfYFnoubAOXMhRkaz,params=JjpElDexdKWctgfYFnoubAOXMhRkaz,headers=JjpElDexdKWctgfYFnoubAOXMhRkaz,cookies=JjpElDexdKWctgfYFnoubAOXMhRkaz)
   JjpElDexdKWctgfYFnoubAOXMhRkmN=json.loads(JjpElDexdKWctgfYFnoubAOXMhRkTL.text)
   for JjpElDexdKWctgfYFnoubAOXMhRkHU in JjpElDexdKWctgfYFnoubAOXMhRkmN:
    JjpElDexdKWctgfYFnoubAOXMhRkHB={'title':JjpElDexdKWctgfYFnoubAOXMhRkHU['title'],'startTime':JjpElDexdKWctgfYFnoubAOXMhRkHU['sch_date'].replace('-','')+JjpElDexdKWctgfYFnoubAOXMhRkav(JjpElDexdKWctgfYFnoubAOXMhRkHU['sch_hour']).zfill(2)+JjpElDexdKWctgfYFnoubAOXMhRkHU['sch_min']+'00'}
    JjpElDexdKWctgfYFnoubAOXMhRkHL.append(JjpElDexdKWctgfYFnoubAOXMhRkHB)
   for i in JjpElDexdKWctgfYFnoubAOXMhRkaw(JjpElDexdKWctgfYFnoubAOXMhRkar(JjpElDexdKWctgfYFnoubAOXMhRkHL)):
    if i>0:JjpElDexdKWctgfYFnoubAOXMhRkHL[i-1]['endTime']=JjpElDexdKWctgfYFnoubAOXMhRkHL[i]['startTime']
    if i==JjpElDexdKWctgfYFnoubAOXMhRkar(JjpElDexdKWctgfYFnoubAOXMhRkHL)-1: JjpElDexdKWctgfYFnoubAOXMhRkHL[i]['endTime']=now_day+'240000'
  except JjpElDexdKWctgfYFnoubAOXMhRkaL as exception:
   JjpElDexdKWctgfYFnoubAOXMhRkaI(exception)
   return[]
  return JjpElDexdKWctgfYFnoubAOXMhRkHL
 def Get_EpgInfo_Spotv_spotvnet(JjpElDexdKWctgfYFnoubAOXMhRkTq,JjpElDexdKWctgfYFnoubAOXMhRkmG,epgnm,now_day):
  JjpElDexdKWctgfYFnoubAOXMhRkHL =[]
  try:
   JjpElDexdKWctgfYFnoubAOXMhRkTw='https://www.spotv.net/data/json/schedule/%s/Daily/D%s.json'%(epgnm,now_day)
   JjpElDexdKWctgfYFnoubAOXMhRkTL=JjpElDexdKWctgfYFnoubAOXMhRkTq.callRequestCookies('Get',JjpElDexdKWctgfYFnoubAOXMhRkTw,payload=JjpElDexdKWctgfYFnoubAOXMhRkaz,params=JjpElDexdKWctgfYFnoubAOXMhRkaz,headers=JjpElDexdKWctgfYFnoubAOXMhRkaz,cookies=JjpElDexdKWctgfYFnoubAOXMhRkaz)
   JjpElDexdKWctgfYFnoubAOXMhRkmN=json.loads(JjpElDexdKWctgfYFnoubAOXMhRkTL.text)
   for JjpElDexdKWctgfYFnoubAOXMhRkHU in JjpElDexdKWctgfYFnoubAOXMhRkmN:
    JjpElDexdKWctgfYFnoubAOXMhRkHB={'title':JjpElDexdKWctgfYFnoubAOXMhRkHU['title'],'startTime':JjpElDexdKWctgfYFnoubAOXMhRkHU['sch_date'].replace('-','')+JjpElDexdKWctgfYFnoubAOXMhRkav(JjpElDexdKWctgfYFnoubAOXMhRkHU['sch_hour']).zfill(2)+JjpElDexdKWctgfYFnoubAOXMhRkHU['sch_min']+'00'}
    JjpElDexdKWctgfYFnoubAOXMhRkHL.append(JjpElDexdKWctgfYFnoubAOXMhRkHB)
   for i in JjpElDexdKWctgfYFnoubAOXMhRkaw(JjpElDexdKWctgfYFnoubAOXMhRkar(JjpElDexdKWctgfYFnoubAOXMhRkHL)):
    if i>0:JjpElDexdKWctgfYFnoubAOXMhRkHL[i-1]['endTime']=JjpElDexdKWctgfYFnoubAOXMhRkHL[i]['startTime']
    if i==JjpElDexdKWctgfYFnoubAOXMhRkar(JjpElDexdKWctgfYFnoubAOXMhRkHL)-1: JjpElDexdKWctgfYFnoubAOXMhRkHL[i]['endTime']=now_day+'240000'
  except JjpElDexdKWctgfYFnoubAOXMhRkaL as exception:
   JjpElDexdKWctgfYFnoubAOXMhRkaI(exception)
   return[]
  return JjpElDexdKWctgfYFnoubAOXMhRkHL
 def GetEventLiveList(JjpElDexdKWctgfYFnoubAOXMhRkTq):
  JjpElDexdKWctgfYFnoubAOXMhRkHz=[]
  JjpElDexdKWctgfYFnoubAOXMhRkmQ =0
  try:
   JjpElDexdKWctgfYFnoubAOXMhRkmP=JjpElDexdKWctgfYFnoubAOXMhRkTq.Get_Now_Datetime()
   JjpElDexdKWctgfYFnoubAOXMhRkmz=JjpElDexdKWctgfYFnoubAOXMhRkmP.strftime('%Y-%m-%d')
  except JjpElDexdKWctgfYFnoubAOXMhRkaL as exception:
   JjpElDexdKWctgfYFnoubAOXMhRkaI(exception)
   return JjpElDexdKWctgfYFnoubAOXMhRkHz,JjpElDexdKWctgfYFnoubAOXMhRkmQ
  try:
   JjpElDexdKWctgfYFnoubAOXMhRkTw=JjpElDexdKWctgfYFnoubAOXMhRkTq.API_DOMAIN+'/api/v2/player/lives/'+JjpElDexdKWctgfYFnoubAOXMhRkmz 
   JjpElDexdKWctgfYFnoubAOXMhRkTQ=JjpElDexdKWctgfYFnoubAOXMhRkTq.makeDefaultCookies()
   JjpElDexdKWctgfYFnoubAOXMhRkTL=JjpElDexdKWctgfYFnoubAOXMhRkTq.callRequestCookies('Get',JjpElDexdKWctgfYFnoubAOXMhRkTw,payload=JjpElDexdKWctgfYFnoubAOXMhRkaz,params=JjpElDexdKWctgfYFnoubAOXMhRkaz,headers=JjpElDexdKWctgfYFnoubAOXMhRkaz,cookies=JjpElDexdKWctgfYFnoubAOXMhRkTQ)
   JjpElDexdKWctgfYFnoubAOXMhRkmQ=JjpElDexdKWctgfYFnoubAOXMhRkTL.status_code 
   JjpElDexdKWctgfYFnoubAOXMhRkTI=json.loads(JjpElDexdKWctgfYFnoubAOXMhRkTL.text)
   for JjpElDexdKWctgfYFnoubAOXMhRkmi in JjpElDexdKWctgfYFnoubAOXMhRkTI:
    for JjpElDexdKWctgfYFnoubAOXMhRkHU in JjpElDexdKWctgfYFnoubAOXMhRkmi['liveNowList']:
     if JjpElDexdKWctgfYFnoubAOXMhRkHU['gameDesc']['title']==JjpElDexdKWctgfYFnoubAOXMhRkaz or JjpElDexdKWctgfYFnoubAOXMhRkHU['gameDesc']['title']=='':
      JjpElDexdKWctgfYFnoubAOXMhRkmU='%s ( %s : %s )'%(JjpElDexdKWctgfYFnoubAOXMhRkHU['leagueName'],JjpElDexdKWctgfYFnoubAOXMhRkHU['homeNameShort'],JjpElDexdKWctgfYFnoubAOXMhRkHU['awayNameShort'])
     else:
      JjpElDexdKWctgfYFnoubAOXMhRkmU=JjpElDexdKWctgfYFnoubAOXMhRkHU['gameDesc']['title']
     JjpElDexdKWctgfYFnoubAOXMhRkHB={'liveId':JjpElDexdKWctgfYFnoubAOXMhRkHU['liveId'],'title':JjpElDexdKWctgfYFnoubAOXMhRkmU,'logo':JjpElDexdKWctgfYFnoubAOXMhRkHU['gameDesc']['leagueLogo'],'free':JjpElDexdKWctgfYFnoubAOXMhRkHU['isFree'],'startTime':JjpElDexdKWctgfYFnoubAOXMhRkHU['startTime']}
     JjpElDexdKWctgfYFnoubAOXMhRkHz.append(JjpElDexdKWctgfYFnoubAOXMhRkHB)
  except JjpElDexdKWctgfYFnoubAOXMhRkaL as exception:
   JjpElDexdKWctgfYFnoubAOXMhRkaI(exception)
  return JjpElDexdKWctgfYFnoubAOXMhRkHz,JjpElDexdKWctgfYFnoubAOXMhRkmQ
 def GetEventLive_videoId(JjpElDexdKWctgfYFnoubAOXMhRkTq,liveId):
  JjpElDexdKWctgfYFnoubAOXMhRkmB=''
  try:
   JjpElDexdKWctgfYFnoubAOXMhRkTw=JjpElDexdKWctgfYFnoubAOXMhRkTq.API_DOMAIN+'/api/v2/live/'+liveId
   JjpElDexdKWctgfYFnoubAOXMhRkTL=JjpElDexdKWctgfYFnoubAOXMhRkTq.callRequestCookies('Get',JjpElDexdKWctgfYFnoubAOXMhRkTw,payload=JjpElDexdKWctgfYFnoubAOXMhRkaz,params=JjpElDexdKWctgfYFnoubAOXMhRkaz,headers=JjpElDexdKWctgfYFnoubAOXMhRkaz,cookies=JjpElDexdKWctgfYFnoubAOXMhRkaz)
   JjpElDexdKWctgfYFnoubAOXMhRkTI=json.loads(JjpElDexdKWctgfYFnoubAOXMhRkTL.text)
   JjpElDexdKWctgfYFnoubAOXMhRkmv=JjpElDexdKWctgfYFnoubAOXMhRkTI['videoId']
   JjpElDexdKWctgfYFnoubAOXMhRkmB=JjpElDexdKWctgfYFnoubAOXMhRkmv.replace('ref:','')
  except JjpElDexdKWctgfYFnoubAOXMhRkaL as exception:
   JjpElDexdKWctgfYFnoubAOXMhRkaI(exception)
  return JjpElDexdKWctgfYFnoubAOXMhRkmB
 def CheckMainEnd(JjpElDexdKWctgfYFnoubAOXMhRkTq):
  JjpElDexdKWctgfYFnoubAOXMhRkmL=JjpElDexdKWctgfYFnoubAOXMhRkTq.SPOTV_PMCODE+JjpElDexdKWctgfYFnoubAOXMhRkTq.ST['cookies']['spotv_sessionid']
  JjpElDexdKWctgfYFnoubAOXMhRkmL=base64.standard_b64encode(JjpElDexdKWctgfYFnoubAOXMhRkmL.encode()).decode('utf-8')
  if JjpElDexdKWctgfYFnoubAOXMhRkmL=='OTg3MTgzMzM0Ng==' or JjpElDexdKWctgfYFnoubAOXMhRkmL=='OTg3MTgzMzExNw==':return JjpElDexdKWctgfYFnoubAOXMhRkaB
  return JjpElDexdKWctgfYFnoubAOXMhRkai
 def CheckSubEnd(JjpElDexdKWctgfYFnoubAOXMhRkTq):
  JjpElDexdKWctgfYFnoubAOXMhRkTS=JjpElDexdKWctgfYFnoubAOXMhRkai
  try:
   if JjpElDexdKWctgfYFnoubAOXMhRkTq.CheckMainEnd():return JjpElDexdKWctgfYFnoubAOXMhRkaB 
   JjpElDexdKWctgfYFnoubAOXMhRkmI=base64.standard_b64decode(JjpElDexdKWctgfYFnoubAOXMhRkTq.ST['cookies']['spotv_subend']).decode('utf-8')[JjpElDexdKWctgfYFnoubAOXMhRkTq.SPOTV_PMSIZE:]
   if JjpElDexdKWctgfYFnoubAOXMhRkmI=='0':return JjpElDexdKWctgfYFnoubAOXMhRkTS
   JjpElDexdKWctgfYFnoubAOXMhRkms =JjpElDexdKWctgfYFnoubAOXMhRkas(JjpElDexdKWctgfYFnoubAOXMhRkTq.Get_Now_Datetime().strftime('%Y%m%d'))
   JjpElDexdKWctgfYFnoubAOXMhRkmr =JjpElDexdKWctgfYFnoubAOXMhRkas(JjpElDexdKWctgfYFnoubAOXMhRkmI)/1000
   JjpElDexdKWctgfYFnoubAOXMhRkmw =JjpElDexdKWctgfYFnoubAOXMhRkas(datetime.datetime.fromtimestamp(JjpElDexdKWctgfYFnoubAOXMhRkmr,datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul')).strftime('%Y%m%d'))
   if JjpElDexdKWctgfYFnoubAOXMhRkms<=JjpElDexdKWctgfYFnoubAOXMhRkmw:JjpElDexdKWctgfYFnoubAOXMhRkTS=JjpElDexdKWctgfYFnoubAOXMhRkaB
  except JjpElDexdKWctgfYFnoubAOXMhRkaL as exception:
   JjpElDexdKWctgfYFnoubAOXMhRkaI(exception)
   return JjpElDexdKWctgfYFnoubAOXMhRkTS
  return JjpElDexdKWctgfYFnoubAOXMhRkTS
 def GetBroadURL(JjpElDexdKWctgfYFnoubAOXMhRkTq,JjpElDexdKWctgfYFnoubAOXMhRkmB,mediatype,JjpElDexdKWctgfYFnoubAOXMhRkqN):
  JjpElDexdKWctgfYFnoubAOXMhRkqT=''
  try:
   if mediatype=='live':
    JjpElDexdKWctgfYFnoubAOXMhRkTw=JjpElDexdKWctgfYFnoubAOXMhRkTq.API_DOMAIN+'/api/v2/live/'+JjpElDexdKWctgfYFnoubAOXMhRkmB
   else:
    JjpElDexdKWctgfYFnoubAOXMhRkmB=JjpElDexdKWctgfYFnoubAOXMhRkTq.GetReplay_UrlId(JjpElDexdKWctgfYFnoubAOXMhRkmB,JjpElDexdKWctgfYFnoubAOXMhRkqN)
    if JjpElDexdKWctgfYFnoubAOXMhRkmB=='':return JjpElDexdKWctgfYFnoubAOXMhRkqT
    JjpElDexdKWctgfYFnoubAOXMhRkTw=JjpElDexdKWctgfYFnoubAOXMhRkTq.PLAYER_DOMAIN+'/playback/v1/accounts/'+JjpElDexdKWctgfYFnoubAOXMhRkTq.ST['cookies']['spotv_accountId']+'/videos/'+JjpElDexdKWctgfYFnoubAOXMhRkmB
   JjpElDexdKWctgfYFnoubAOXMhRkTP=JjpElDexdKWctgfYFnoubAOXMhRkTq.makeDefaultHeaders()
   JjpElDexdKWctgfYFnoubAOXMhRkTL=JjpElDexdKWctgfYFnoubAOXMhRkTq.callRequestCookies('Get',JjpElDexdKWctgfYFnoubAOXMhRkTw,payload=JjpElDexdKWctgfYFnoubAOXMhRkaz,params=JjpElDexdKWctgfYFnoubAOXMhRkaz,headers=JjpElDexdKWctgfYFnoubAOXMhRkTP,cookies=JjpElDexdKWctgfYFnoubAOXMhRkaz)
   JjpElDexdKWctgfYFnoubAOXMhRkmN=json.loads(JjpElDexdKWctgfYFnoubAOXMhRkTL.text)
   if mediatype=='live':
    JjpElDexdKWctgfYFnoubAOXMhRkqT=JjpElDexdKWctgfYFnoubAOXMhRkmN['hlsUrl2']
   else:
    JjpElDexdKWctgfYFnoubAOXMhRkqT=JjpElDexdKWctgfYFnoubAOXMhRkmN['sources'][0]['src']
   JjpElDexdKWctgfYFnoubAOXMhRkqT=JjpElDexdKWctgfYFnoubAOXMhRkqT.replace('http://','https://')
  except JjpElDexdKWctgfYFnoubAOXMhRkaL as exception:
   JjpElDexdKWctgfYFnoubAOXMhRkaI(exception)
  return JjpElDexdKWctgfYFnoubAOXMhRkqT
 def GetTitleGroupList(JjpElDexdKWctgfYFnoubAOXMhRkTq):
  JjpElDexdKWctgfYFnoubAOXMhRkHz=[]
  JjpElDexdKWctgfYFnoubAOXMhRkqH=JjpElDexdKWctgfYFnoubAOXMhRkai
  try:
   JjpElDexdKWctgfYFnoubAOXMhRkTw=JjpElDexdKWctgfYFnoubAOXMhRkTq.API_DOMAIN+'/api/v2/home/web'
   JjpElDexdKWctgfYFnoubAOXMhRkTL=JjpElDexdKWctgfYFnoubAOXMhRkTq.callRequestCookies('Get',JjpElDexdKWctgfYFnoubAOXMhRkTw,payload=JjpElDexdKWctgfYFnoubAOXMhRkaz,params=JjpElDexdKWctgfYFnoubAOXMhRkaz,headers=JjpElDexdKWctgfYFnoubAOXMhRkaz,cookies=JjpElDexdKWctgfYFnoubAOXMhRkaz)
   JjpElDexdKWctgfYFnoubAOXMhRkTI=json.loads(JjpElDexdKWctgfYFnoubAOXMhRkTL.text)
   for JjpElDexdKWctgfYFnoubAOXMhRkHU in JjpElDexdKWctgfYFnoubAOXMhRkTI:
    if JjpElDexdKWctgfYFnoubAOXMhRkav(JjpElDexdKWctgfYFnoubAOXMhRkHU['type'])=='3':
     JjpElDexdKWctgfYFnoubAOXMhRkqm=''
     for JjpElDexdKWctgfYFnoubAOXMhRkqa in JjpElDexdKWctgfYFnoubAOXMhRkHU['data']['list']:
      JjpElDexdKWctgfYFnoubAOXMhRkqC='[%s] %s vs %s\n<%s>\n\n'%(JjpElDexdKWctgfYFnoubAOXMhRkqa['gameDesc']['roundName'],JjpElDexdKWctgfYFnoubAOXMhRkqa['gameDesc']['homeNameShort'],JjpElDexdKWctgfYFnoubAOXMhRkqa['gameDesc']['awayNameShort'],JjpElDexdKWctgfYFnoubAOXMhRkqa['gameDesc']['beginDate'])
      JjpElDexdKWctgfYFnoubAOXMhRkqm+=JjpElDexdKWctgfYFnoubAOXMhRkqC
     JjpElDexdKWctgfYFnoubAOXMhRkHB={'title':JjpElDexdKWctgfYFnoubAOXMhRkHU['title'],'logo':JjpElDexdKWctgfYFnoubAOXMhRkHU['logo'],'reagueId':JjpElDexdKWctgfYFnoubAOXMhRkav(JjpElDexdKWctgfYFnoubAOXMhRkHU['destId']),'subGame':JjpElDexdKWctgfYFnoubAOXMhRkqm}
     JjpElDexdKWctgfYFnoubAOXMhRkHz.append(JjpElDexdKWctgfYFnoubAOXMhRkHB)
     if JjpElDexdKWctgfYFnoubAOXMhRkav(JjpElDexdKWctgfYFnoubAOXMhRkHU['destId'])=='13':JjpElDexdKWctgfYFnoubAOXMhRkqH=JjpElDexdKWctgfYFnoubAOXMhRkaB
   if JjpElDexdKWctgfYFnoubAOXMhRkqH==JjpElDexdKWctgfYFnoubAOXMhRkai:
    JjpElDexdKWctgfYFnoubAOXMhRkHB={'title':'UFC','logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200928/a643c7cf1c285fb0b4469c07d4c09c28.png','reagueId':'13','subGame':''}
    JjpElDexdKWctgfYFnoubAOXMhRkHz.append(JjpElDexdKWctgfYFnoubAOXMhRkHB)
  except JjpElDexdKWctgfYFnoubAOXMhRkaL as exception:
   JjpElDexdKWctgfYFnoubAOXMhRkaI(exception)
  return JjpElDexdKWctgfYFnoubAOXMhRkHz
 def GetPopularGroupList(JjpElDexdKWctgfYFnoubAOXMhRkTq):
  JjpElDexdKWctgfYFnoubAOXMhRkHz=[]
  try:
   JjpElDexdKWctgfYFnoubAOXMhRkTw=JjpElDexdKWctgfYFnoubAOXMhRkTq.API_DOMAIN+'/api/v2/home/web'
   JjpElDexdKWctgfYFnoubAOXMhRkTL=JjpElDexdKWctgfYFnoubAOXMhRkTq.callRequestCookies('Get',JjpElDexdKWctgfYFnoubAOXMhRkTw,payload=JjpElDexdKWctgfYFnoubAOXMhRkaz,params=JjpElDexdKWctgfYFnoubAOXMhRkaz,headers=JjpElDexdKWctgfYFnoubAOXMhRkaz,cookies=JjpElDexdKWctgfYFnoubAOXMhRkaz)
   JjpElDexdKWctgfYFnoubAOXMhRkTI=json.loads(JjpElDexdKWctgfYFnoubAOXMhRkTL.text)
   for JjpElDexdKWctgfYFnoubAOXMhRkHU in JjpElDexdKWctgfYFnoubAOXMhRkTI:
    if JjpElDexdKWctgfYFnoubAOXMhRkav(JjpElDexdKWctgfYFnoubAOXMhRkHU['type'])=='1' and JjpElDexdKWctgfYFnoubAOXMhRkav(JjpElDexdKWctgfYFnoubAOXMhRkHU['destId'])=='4':
     for JjpElDexdKWctgfYFnoubAOXMhRkqa in JjpElDexdKWctgfYFnoubAOXMhRkHU['data']['list']:
      JjpElDexdKWctgfYFnoubAOXMhRkqG =JjpElDexdKWctgfYFnoubAOXMhRkqa['title']
      JjpElDexdKWctgfYFnoubAOXMhRkqy =JjpElDexdKWctgfYFnoubAOXMhRkqa['id']
      JjpElDexdKWctgfYFnoubAOXMhRkqS =JjpElDexdKWctgfYFnoubAOXMhRkqa['vtype']
      JjpElDexdKWctgfYFnoubAOXMhRkqV =JjpElDexdKWctgfYFnoubAOXMhRkqa['imgUrl']
      JjpElDexdKWctgfYFnoubAOXMhRkqN =JjpElDexdKWctgfYFnoubAOXMhRkqa['vtypeId']
      JjpElDexdKWctgfYFnoubAOXMhRkHB={'vodTitle':JjpElDexdKWctgfYFnoubAOXMhRkqG,'vodId':JjpElDexdKWctgfYFnoubAOXMhRkqy,'vodType':JjpElDexdKWctgfYFnoubAOXMhRkqS,'thumbnail':JjpElDexdKWctgfYFnoubAOXMhRkqV,'vtypeId':JjpElDexdKWctgfYFnoubAOXMhRkav(JjpElDexdKWctgfYFnoubAOXMhRkqN),'duration':JjpElDexdKWctgfYFnoubAOXMhRkas(JjpElDexdKWctgfYFnoubAOXMhRkqa['duration']/1000)}
      JjpElDexdKWctgfYFnoubAOXMhRkHz.append(JjpElDexdKWctgfYFnoubAOXMhRkHB)
  except JjpElDexdKWctgfYFnoubAOXMhRkaL as exception:
   JjpElDexdKWctgfYFnoubAOXMhRkaI(exception)
  return JjpElDexdKWctgfYFnoubAOXMhRkHz
 def Get_NowVod_GroupList(JjpElDexdKWctgfYFnoubAOXMhRkTq,page_int):
  JjpElDexdKWctgfYFnoubAOXMhRkHz=[]
  JjpElDexdKWctgfYFnoubAOXMhRkqQ=JjpElDexdKWctgfYFnoubAOXMhRkai
  try:
   JjpElDexdKWctgfYFnoubAOXMhRkTw=JjpElDexdKWctgfYFnoubAOXMhRkTq.API_DOMAIN+'/api/v2/theme/14/list'
   JjpElDexdKWctgfYFnoubAOXMhRkqP={'pageItem':'10','pageNo':JjpElDexdKWctgfYFnoubAOXMhRkav(page_int)}
   JjpElDexdKWctgfYFnoubAOXMhRkTL=JjpElDexdKWctgfYFnoubAOXMhRkTq.callRequestCookies('Get',JjpElDexdKWctgfYFnoubAOXMhRkTw,payload=JjpElDexdKWctgfYFnoubAOXMhRkaz,params=JjpElDexdKWctgfYFnoubAOXMhRkqP,headers=JjpElDexdKWctgfYFnoubAOXMhRkaz,cookies=JjpElDexdKWctgfYFnoubAOXMhRkaz)
   JjpElDexdKWctgfYFnoubAOXMhRkTI=json.loads(JjpElDexdKWctgfYFnoubAOXMhRkTL.text)
   for JjpElDexdKWctgfYFnoubAOXMhRkHU in JjpElDexdKWctgfYFnoubAOXMhRkTI['list']:
    JjpElDexdKWctgfYFnoubAOXMhRkqG =JjpElDexdKWctgfYFnoubAOXMhRkHU['title']
    JjpElDexdKWctgfYFnoubAOXMhRkqy =JjpElDexdKWctgfYFnoubAOXMhRkHU['id']
    JjpElDexdKWctgfYFnoubAOXMhRkqS =JjpElDexdKWctgfYFnoubAOXMhRkHU['vtype']
    JjpElDexdKWctgfYFnoubAOXMhRkqV =JjpElDexdKWctgfYFnoubAOXMhRkHU['imgUrl']
    JjpElDexdKWctgfYFnoubAOXMhRkqN =JjpElDexdKWctgfYFnoubAOXMhRkHU['vtypeId']
    JjpElDexdKWctgfYFnoubAOXMhRkHB={'vodTitle':JjpElDexdKWctgfYFnoubAOXMhRkqG,'vodId':JjpElDexdKWctgfYFnoubAOXMhRkqy,'vodType':JjpElDexdKWctgfYFnoubAOXMhRkqS,'thumbnail':JjpElDexdKWctgfYFnoubAOXMhRkqV,'vtypeId':JjpElDexdKWctgfYFnoubAOXMhRkav(JjpElDexdKWctgfYFnoubAOXMhRkqN),'duration':JjpElDexdKWctgfYFnoubAOXMhRkas(JjpElDexdKWctgfYFnoubAOXMhRkHU['duration']/1000),}
    JjpElDexdKWctgfYFnoubAOXMhRkHz.append(JjpElDexdKWctgfYFnoubAOXMhRkHB)
    if JjpElDexdKWctgfYFnoubAOXMhRkTI['count']>page_int*JjpElDexdKWctgfYFnoubAOXMhRkTq.GAMELIST_LIMIT:JjpElDexdKWctgfYFnoubAOXMhRkqQ=JjpElDexdKWctgfYFnoubAOXMhRkaB
  except JjpElDexdKWctgfYFnoubAOXMhRkaL as exception:
   JjpElDexdKWctgfYFnoubAOXMhRkaI(exception)
  return JjpElDexdKWctgfYFnoubAOXMhRkHz,JjpElDexdKWctgfYFnoubAOXMhRkqQ
 def GetSeasonList(JjpElDexdKWctgfYFnoubAOXMhRkTq,leagueId):
  JjpElDexdKWctgfYFnoubAOXMhRkHz=[]
  JjpElDexdKWctgfYFnoubAOXMhRkqz=JjpElDexdKWctgfYFnoubAOXMhRkqi=''
  try:
   JjpElDexdKWctgfYFnoubAOXMhRkTw=JjpElDexdKWctgfYFnoubAOXMhRkTq.API_DOMAIN+'/api/v2/game/league/'+leagueId
   JjpElDexdKWctgfYFnoubAOXMhRkTL=JjpElDexdKWctgfYFnoubAOXMhRkTq.callRequestCookies('Get',JjpElDexdKWctgfYFnoubAOXMhRkTw,payload=JjpElDexdKWctgfYFnoubAOXMhRkaz,params=JjpElDexdKWctgfYFnoubAOXMhRkaz,headers=JjpElDexdKWctgfYFnoubAOXMhRkaz,cookies=JjpElDexdKWctgfYFnoubAOXMhRkaz)
   JjpElDexdKWctgfYFnoubAOXMhRkTI=json.loads(JjpElDexdKWctgfYFnoubAOXMhRkTL.text)
   JjpElDexdKWctgfYFnoubAOXMhRkqz=JjpElDexdKWctgfYFnoubAOXMhRkTI['name']
   JjpElDexdKWctgfYFnoubAOXMhRkqi=JjpElDexdKWctgfYFnoubAOXMhRkav(JjpElDexdKWctgfYFnoubAOXMhRkTI['gameTypeId'])
  except JjpElDexdKWctgfYFnoubAOXMhRkaL as exception:
   JjpElDexdKWctgfYFnoubAOXMhRkaI(exception)
   return JjpElDexdKWctgfYFnoubAOXMhRkHz
  if JjpElDexdKWctgfYFnoubAOXMhRkqi=='2':
   try:
    JjpElDexdKWctgfYFnoubAOXMhRkTw=JjpElDexdKWctgfYFnoubAOXMhRkTq.API_DOMAIN+'/api/v2/year/'+leagueId
    JjpElDexdKWctgfYFnoubAOXMhRkTL=JjpElDexdKWctgfYFnoubAOXMhRkTq.callRequestCookies('Get',JjpElDexdKWctgfYFnoubAOXMhRkTw,payload=JjpElDexdKWctgfYFnoubAOXMhRkaz,params=JjpElDexdKWctgfYFnoubAOXMhRkaz,headers=JjpElDexdKWctgfYFnoubAOXMhRkaz,cookies=JjpElDexdKWctgfYFnoubAOXMhRkaz)
    JjpElDexdKWctgfYFnoubAOXMhRkTI=json.loads(JjpElDexdKWctgfYFnoubAOXMhRkTL.text)
    for JjpElDexdKWctgfYFnoubAOXMhRkHU in JjpElDexdKWctgfYFnoubAOXMhRkTI:
     JjpElDexdKWctgfYFnoubAOXMhRkHB={'reagueName':JjpElDexdKWctgfYFnoubAOXMhRkqz,'gameTypeId':JjpElDexdKWctgfYFnoubAOXMhRkqi,'seasonName':JjpElDexdKWctgfYFnoubAOXMhRkav(JjpElDexdKWctgfYFnoubAOXMhRkHU),'seasonId':JjpElDexdKWctgfYFnoubAOXMhRkav(JjpElDexdKWctgfYFnoubAOXMhRkHU)}
     JjpElDexdKWctgfYFnoubAOXMhRkHz.append(JjpElDexdKWctgfYFnoubAOXMhRkHB)
   except JjpElDexdKWctgfYFnoubAOXMhRkaL as exception:
    JjpElDexdKWctgfYFnoubAOXMhRkaI(exception)
    return[]
  else:
   try:
    JjpElDexdKWctgfYFnoubAOXMhRkTw=JjpElDexdKWctgfYFnoubAOXMhRkTq.API_DOMAIN+'/api/v2/season/'+leagueId
    JjpElDexdKWctgfYFnoubAOXMhRkTL=JjpElDexdKWctgfYFnoubAOXMhRkTq.callRequestCookies('Get',JjpElDexdKWctgfYFnoubAOXMhRkTw,payload=JjpElDexdKWctgfYFnoubAOXMhRkaz,params=JjpElDexdKWctgfYFnoubAOXMhRkaz,headers=JjpElDexdKWctgfYFnoubAOXMhRkaz,cookies=JjpElDexdKWctgfYFnoubAOXMhRkaz)
    JjpElDexdKWctgfYFnoubAOXMhRkTI=json.loads(JjpElDexdKWctgfYFnoubAOXMhRkTL.text)
    for JjpElDexdKWctgfYFnoubAOXMhRkHU in JjpElDexdKWctgfYFnoubAOXMhRkTI:
     JjpElDexdKWctgfYFnoubAOXMhRkHB={'reagueName':JjpElDexdKWctgfYFnoubAOXMhRkqz,'gameTypeId':JjpElDexdKWctgfYFnoubAOXMhRkqi,'seasonName':JjpElDexdKWctgfYFnoubAOXMhRkHU['name'],'seasonId':JjpElDexdKWctgfYFnoubAOXMhRkav(JjpElDexdKWctgfYFnoubAOXMhRkHU['id'])}
     JjpElDexdKWctgfYFnoubAOXMhRkHz.append(JjpElDexdKWctgfYFnoubAOXMhRkHB)
   except JjpElDexdKWctgfYFnoubAOXMhRkaL as exception:
    JjpElDexdKWctgfYFnoubAOXMhRkaI(exception)
    return[]
  return JjpElDexdKWctgfYFnoubAOXMhRkHz
 def GetGameList(JjpElDexdKWctgfYFnoubAOXMhRkTq,JjpElDexdKWctgfYFnoubAOXMhRkqi,leagueId,seasonId,page_int,hidescore=JjpElDexdKWctgfYFnoubAOXMhRkaB):
  JjpElDexdKWctgfYFnoubAOXMhRkHz=[]
  JjpElDexdKWctgfYFnoubAOXMhRkqQ=JjpElDexdKWctgfYFnoubAOXMhRkai
  try:
   JjpElDexdKWctgfYFnoubAOXMhRkTw=JjpElDexdKWctgfYFnoubAOXMhRkTq.API_DOMAIN+'/api/v2/vod/league/detail'
   JjpElDexdKWctgfYFnoubAOXMhRkqP={'gameType':JjpElDexdKWctgfYFnoubAOXMhRkqi,'leagueId':leagueId,'seasonId':seasonId if JjpElDexdKWctgfYFnoubAOXMhRkqi!='2' else '','teamId':'','roundId':'','year':'' if JjpElDexdKWctgfYFnoubAOXMhRkqi!='2' else seasonId,'pageNo':JjpElDexdKWctgfYFnoubAOXMhRkav(page_int)}
   JjpElDexdKWctgfYFnoubAOXMhRkTL=JjpElDexdKWctgfYFnoubAOXMhRkTq.callRequestCookies('Get',JjpElDexdKWctgfYFnoubAOXMhRkTw,payload=JjpElDexdKWctgfYFnoubAOXMhRkaz,params=JjpElDexdKWctgfYFnoubAOXMhRkqP,headers=JjpElDexdKWctgfYFnoubAOXMhRkaz,cookies=JjpElDexdKWctgfYFnoubAOXMhRkaz)
   JjpElDexdKWctgfYFnoubAOXMhRkTI=json.loads(JjpElDexdKWctgfYFnoubAOXMhRkTL.text)
   JjpElDexdKWctgfYFnoubAOXMhRkmi=JjpElDexdKWctgfYFnoubAOXMhRkTI['list']
   for JjpElDexdKWctgfYFnoubAOXMhRkqU in JjpElDexdKWctgfYFnoubAOXMhRkmi:
    for JjpElDexdKWctgfYFnoubAOXMhRkHU in JjpElDexdKWctgfYFnoubAOXMhRkqU['list']:
     if JjpElDexdKWctgfYFnoubAOXMhRkHU['gameDesc']['title']==JjpElDexdKWctgfYFnoubAOXMhRkaz or JjpElDexdKWctgfYFnoubAOXMhRkHU['gameDesc']['title']=='':
      JjpElDexdKWctgfYFnoubAOXMhRkmU ='%s vs %s'%(JjpElDexdKWctgfYFnoubAOXMhRkHU['gameDesc']['homeNameShort'],JjpElDexdKWctgfYFnoubAOXMhRkHU['gameDesc']['awayNameShort'])
     else:
      JjpElDexdKWctgfYFnoubAOXMhRkmU =JjpElDexdKWctgfYFnoubAOXMhRkHU['gameDesc']['title']
     JjpElDexdKWctgfYFnoubAOXMhRkqB =JjpElDexdKWctgfYFnoubAOXMhRkHU['gameDesc']['beginDate']
     JjpElDexdKWctgfYFnoubAOXMhRkqv =JjpElDexdKWctgfYFnoubAOXMhRkHU['gameDesc']['id']
     JjpElDexdKWctgfYFnoubAOXMhRkqL =JjpElDexdKWctgfYFnoubAOXMhRkHU['gameDesc']['leagueNameFull']
     JjpElDexdKWctgfYFnoubAOXMhRkqI =JjpElDexdKWctgfYFnoubAOXMhRkHU['gameDesc']['seasonName']
     JjpElDexdKWctgfYFnoubAOXMhRkqs =JjpElDexdKWctgfYFnoubAOXMhRkHU['gameDesc']['roundName']
     JjpElDexdKWctgfYFnoubAOXMhRkqr =JjpElDexdKWctgfYFnoubAOXMhRkHU['gameDesc']['homeName']
     JjpElDexdKWctgfYFnoubAOXMhRkqw =JjpElDexdKWctgfYFnoubAOXMhRkHU['gameDesc']['awayName']
     JjpElDexdKWctgfYFnoubAOXMhRkaT =JjpElDexdKWctgfYFnoubAOXMhRkHU['gameDesc']['homeScore']
     JjpElDexdKWctgfYFnoubAOXMhRkaH =JjpElDexdKWctgfYFnoubAOXMhRkHU['gameDesc']['awayScore']
     if hidescore==JjpElDexdKWctgfYFnoubAOXMhRkaB:
      JjpElDexdKWctgfYFnoubAOXMhRkam ='%s\n - %s (%s)\n - %s\n\nhome : %s\n\naway : %s'%(JjpElDexdKWctgfYFnoubAOXMhRkqL,JjpElDexdKWctgfYFnoubAOXMhRkqI,JjpElDexdKWctgfYFnoubAOXMhRkqs,JjpElDexdKWctgfYFnoubAOXMhRkqB,JjpElDexdKWctgfYFnoubAOXMhRkqr,JjpElDexdKWctgfYFnoubAOXMhRkqw)
     else:
      JjpElDexdKWctgfYFnoubAOXMhRkam ='%s\n - %s (%s)\n - %s\n\nhome : %s (Score %s)\n\naway : %s (Score %s)'%(JjpElDexdKWctgfYFnoubAOXMhRkqL,JjpElDexdKWctgfYFnoubAOXMhRkqI,JjpElDexdKWctgfYFnoubAOXMhRkqs,JjpElDexdKWctgfYFnoubAOXMhRkqB,JjpElDexdKWctgfYFnoubAOXMhRkqr,JjpElDexdKWctgfYFnoubAOXMhRkaT,JjpElDexdKWctgfYFnoubAOXMhRkqw,JjpElDexdKWctgfYFnoubAOXMhRkaH)
     JjpElDexdKWctgfYFnoubAOXMhRkaq=JjpElDexdKWctgfYFnoubAOXMhRkam
     JjpElDexdKWctgfYFnoubAOXMhRkaC =JjpElDexdKWctgfYFnoubAOXMhRkHU['replayVod']['count']
     JjpElDexdKWctgfYFnoubAOXMhRkaG=JjpElDexdKWctgfYFnoubAOXMhRkHU['highlightVod']['count']
     JjpElDexdKWctgfYFnoubAOXMhRkay =JjpElDexdKWctgfYFnoubAOXMhRkHU['vods']['count']
     JjpElDexdKWctgfYFnoubAOXMhRkqV='' 
     JjpElDexdKWctgfYFnoubAOXMhRkaS=JjpElDexdKWctgfYFnoubAOXMhRkaC+JjpElDexdKWctgfYFnoubAOXMhRkaG+JjpElDexdKWctgfYFnoubAOXMhRkay
     if JjpElDexdKWctgfYFnoubAOXMhRkaS==0:
      if JjpElDexdKWctgfYFnoubAOXMhRkqi=='2':
       JjpElDexdKWctgfYFnoubAOXMhRkmU='----- %s -----'%(JjpElDexdKWctgfYFnoubAOXMhRkqI)
       JjpElDexdKWctgfYFnoubAOXMhRkqB=''
      else:
       JjpElDexdKWctgfYFnoubAOXMhRkmU+=' - 관련영상 없음'
       JjpElDexdKWctgfYFnoubAOXMhRkaq+='\n\n ** 관련영상 없음 **'
     else:
      if JjpElDexdKWctgfYFnoubAOXMhRkaC!=0:
       JjpElDexdKWctgfYFnoubAOXMhRkqV =JjpElDexdKWctgfYFnoubAOXMhRkHU['replayVod']['list'][0]['imgUrl']
      elif JjpElDexdKWctgfYFnoubAOXMhRkaG!=0:
       JjpElDexdKWctgfYFnoubAOXMhRkqV =JjpElDexdKWctgfYFnoubAOXMhRkHU['highlightVod']['list'][0]['imgUrl']
      else:
       JjpElDexdKWctgfYFnoubAOXMhRkqV =JjpElDexdKWctgfYFnoubAOXMhRkHU['vods']['list'][0]['imgUrl']
     JjpElDexdKWctgfYFnoubAOXMhRkHB={'gameTitle':JjpElDexdKWctgfYFnoubAOXMhRkmU,'gameId':JjpElDexdKWctgfYFnoubAOXMhRkqv,'beginDate':JjpElDexdKWctgfYFnoubAOXMhRkqB[:11],'thumbnail':JjpElDexdKWctgfYFnoubAOXMhRkqV,'info_plot':JjpElDexdKWctgfYFnoubAOXMhRkaq,'leaguenm':JjpElDexdKWctgfYFnoubAOXMhRkqL,'seasonnm':JjpElDexdKWctgfYFnoubAOXMhRkqI,'roundnm':JjpElDexdKWctgfYFnoubAOXMhRkqs,'totVodCnt':JjpElDexdKWctgfYFnoubAOXMhRkaS}
     JjpElDexdKWctgfYFnoubAOXMhRkHz.append(JjpElDexdKWctgfYFnoubAOXMhRkHB)
  except JjpElDexdKWctgfYFnoubAOXMhRkaL as exception:
   JjpElDexdKWctgfYFnoubAOXMhRkaI(exception)
  if JjpElDexdKWctgfYFnoubAOXMhRkTI['count']>page_int*JjpElDexdKWctgfYFnoubAOXMhRkTq.GAMELIST_LIMIT:JjpElDexdKWctgfYFnoubAOXMhRkqQ=JjpElDexdKWctgfYFnoubAOXMhRkaB
  return JjpElDexdKWctgfYFnoubAOXMhRkHz,JjpElDexdKWctgfYFnoubAOXMhRkqQ
 def GetGameVodList(JjpElDexdKWctgfYFnoubAOXMhRkTq,JjpElDexdKWctgfYFnoubAOXMhRkqv,vodCount=1000):
  JjpElDexdKWctgfYFnoubAOXMhRkHz=[]
  JjpElDexdKWctgfYFnoubAOXMhRkaV=''
  try:
   JjpElDexdKWctgfYFnoubAOXMhRkTw=JjpElDexdKWctgfYFnoubAOXMhRkTq.API_DOMAIN+'/api/v2/vod/game'
   JjpElDexdKWctgfYFnoubAOXMhRkqP={'gameId':JjpElDexdKWctgfYFnoubAOXMhRkqv,'pageItem':JjpElDexdKWctgfYFnoubAOXMhRkav(vodCount)}
   JjpElDexdKWctgfYFnoubAOXMhRkTL=JjpElDexdKWctgfYFnoubAOXMhRkTq.callRequestCookies('Get',JjpElDexdKWctgfYFnoubAOXMhRkTw,payload=JjpElDexdKWctgfYFnoubAOXMhRkaz,params=JjpElDexdKWctgfYFnoubAOXMhRkqP,headers=JjpElDexdKWctgfYFnoubAOXMhRkaz,cookies=JjpElDexdKWctgfYFnoubAOXMhRkaz)
   JjpElDexdKWctgfYFnoubAOXMhRkTI=json.loads(JjpElDexdKWctgfYFnoubAOXMhRkTL.text)
   JjpElDexdKWctgfYFnoubAOXMhRkqU=JjpElDexdKWctgfYFnoubAOXMhRkTI['list']
   for JjpElDexdKWctgfYFnoubAOXMhRkHU in JjpElDexdKWctgfYFnoubAOXMhRkqU:
    JjpElDexdKWctgfYFnoubAOXMhRkqG =JjpElDexdKWctgfYFnoubAOXMhRkHU['title']
    JjpElDexdKWctgfYFnoubAOXMhRkqy =JjpElDexdKWctgfYFnoubAOXMhRkHU['id']
    JjpElDexdKWctgfYFnoubAOXMhRkqS =JjpElDexdKWctgfYFnoubAOXMhRkHU['vtype']
    JjpElDexdKWctgfYFnoubAOXMhRkqV =JjpElDexdKWctgfYFnoubAOXMhRkHU['imgUrl']
    JjpElDexdKWctgfYFnoubAOXMhRkqN =JjpElDexdKWctgfYFnoubAOXMhRkHU['vtypeId']
    JjpElDexdKWctgfYFnoubAOXMhRkaN =JjpElDexdKWctgfYFnoubAOXMhRkHU['isFree']
    JjpElDexdKWctgfYFnoubAOXMhRkHB={'vodTitle':JjpElDexdKWctgfYFnoubAOXMhRkqG,'vodId':JjpElDexdKWctgfYFnoubAOXMhRkqy,'vodType':JjpElDexdKWctgfYFnoubAOXMhRkqS,'thumbnail':JjpElDexdKWctgfYFnoubAOXMhRkqV,'vtypeId':JjpElDexdKWctgfYFnoubAOXMhRkav(JjpElDexdKWctgfYFnoubAOXMhRkqN),'duration':JjpElDexdKWctgfYFnoubAOXMhRkas(JjpElDexdKWctgfYFnoubAOXMhRkHU['duration']/1000),'isFree':JjpElDexdKWctgfYFnoubAOXMhRkaN}
    JjpElDexdKWctgfYFnoubAOXMhRkHz.append(JjpElDexdKWctgfYFnoubAOXMhRkHB)
  except JjpElDexdKWctgfYFnoubAOXMhRkaL as exception:
   JjpElDexdKWctgfYFnoubAOXMhRkaI(exception)
  return JjpElDexdKWctgfYFnoubAOXMhRkHz
 def GetReplay_UrlId(JjpElDexdKWctgfYFnoubAOXMhRkTq,JjpElDexdKWctgfYFnoubAOXMhRkaV,JjpElDexdKWctgfYFnoubAOXMhRkqN):
  JjpElDexdKWctgfYFnoubAOXMhRkaQ=''
  try:
   JjpElDexdKWctgfYFnoubAOXMhRkTw=JjpElDexdKWctgfYFnoubAOXMhRkTq.API_DOMAIN+'/api/v2/vod/'+JjpElDexdKWctgfYFnoubAOXMhRkaV
   JjpElDexdKWctgfYFnoubAOXMhRkTL=JjpElDexdKWctgfYFnoubAOXMhRkTq.callRequestCookies('Get',JjpElDexdKWctgfYFnoubAOXMhRkTw,payload=JjpElDexdKWctgfYFnoubAOXMhRkaz,params=JjpElDexdKWctgfYFnoubAOXMhRkaz,headers=JjpElDexdKWctgfYFnoubAOXMhRkaz,cookies=JjpElDexdKWctgfYFnoubAOXMhRkaz)
   JjpElDexdKWctgfYFnoubAOXMhRkTI=json.loads(JjpElDexdKWctgfYFnoubAOXMhRkTL.text)
   JjpElDexdKWctgfYFnoubAOXMhRkaQ=JjpElDexdKWctgfYFnoubAOXMhRkTI['videoId']
  except JjpElDexdKWctgfYFnoubAOXMhRkaL as exception:
   JjpElDexdKWctgfYFnoubAOXMhRkaI(exception)
  return JjpElDexdKWctgfYFnoubAOXMhRkaQ
# Created by pyminifier (https://github.com/liftoff/pyminifier)
