__author__="NightRain"
UzrawRkWKYIsJcOhSinoCuDVmGExjl=False
UzrawRkWKYIsJcOhSinoCuDVmGExjM=True
UzrawRkWKYIsJcOhSinoCuDVmGExjy=int
import os
import sys
import xbmcaddon,xbmcvfs
import urllib
ADDON_PATH=xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path'))
LIB_PATH =os.path.join(ADDON_PATH,'resources','lib')
sys.path.append(LIB_PATH)
PKG_PATH =os.path.join(ADDON_PATH,'packages')
sys.path.append(PKG_PATH)
from disneyRun import*
def get_params():
 p=urllib.parse.parse_qs(sys.argv[2][1:])
 for i in p.keys():
  p[i]=p[i][0]
 return p
def get_resume():
 if sys.argv[3]=='resume:false':
  return UzrawRkWKYIsJcOhSinoCuDVmGExjl
 else:
  return UzrawRkWKYIsJcOhSinoCuDVmGExjM
runObj=zrpaIMoBDPjlyibCNKkHtvUGJScqRd(sys.argv[0],UzrawRkWKYIsJcOhSinoCuDVmGExjy(sys.argv[1]),get_params(),get_resume()) 
runObj.disney_main()
# Created by pyminifier (https://github.com/liftoff/pyminifier)
