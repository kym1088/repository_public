# -*- coding: utf-8 -*-
__author__ = "NightRain"

#import httpx
import pickle
import threading
import http.cookiejar
import os
import json

import requests


class BaseHttp( object ):
	def __init__( self ):
		self.USER_AGENT        = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36'
		#self.USER_AGENT        = 'BAMSDK/v6.1.0 (disney-svod-3d9324fc 1.16.0.0; v3.0/v6.1.0; android; tv)'
		self.HTTP_CLIENT       = None
		self.COOKIES_PICK_FILE = ''
		self.COOKIES_JSON_FILE = ''
		self.Init_Client()


	def Init_Client( self ):
		#self.HTTP_CLIENT = httpx.Client(http1=False, http2=True)  # httpx
		#self.HTTP_CLIENT.max_redirects = 10                       # httpx
		self.HTTP_CLIENT = requests.Session()                      # requests


	def Call_Request( self, url, payload=None, json=None, params=None, headers=None, cookies=None, redirects=True, method='-' ):
		baseHeader = { 'user-agent' : self.USER_AGENT }
		if headers: baseHeader.update( headers )

		if payload != None or json != None or method == 'POST' :
			#if payload != None:	payload = json.dumps(payload, separators=(',', ':')) ###
			#response = self.HTTP_CLIENT.post( url=url, data=payload, params=params, headers=baseHeader, cookies=cookies, allow_redirects=redirects )
			response = self.HTTP_CLIENT.post( url=url, data=payload, json=json, params=params, headers=baseHeader, cookies=cookies, allow_redirects=redirects )

		elif method == 'DELETE' :
			response = self.HTTP_CLIENT.delete( url=url, data=payload, json=json, params=params, headers=baseHeader, cookies=cookies, allow_redirects=redirects )

		else:
			response = self.HTTP_CLIENT.get( url=url, params=params, headers=baseHeader, cookies=cookies, allow_redirects=redirects )

		print( str(response.status_code) + ' - ' + str(response.url) )

		return response


	def Call_PostText( self, response ):
		req = response.request
		return '{}\r\n{}'.format(
			req.method,
			'\r\n'.join('{}: {}'.format(k, v) for k, v in req.headers.items()),
		)


	def Cookies_FileSave( self, in_filename='' ):
		ck_filename = in_filename  if in_filename != '' else self.COOKIES_PICK_FILE
		fp = open(ck_filename, 'wb', -1) 
		try:
			#pickleJar = self.HTTP_CLIENT.cookies.jar         # httpx
			#pickle.dump(PickleCookieJar.cast(pickleJar), fp) # httpx
			pickleJar = self.HTTP_CLIENT.cookies              # requests
			pickle.dump(pickleJar, fp)                        # requests
		except Exception as exception:
			print( exception )
		finally:
			fp.close()


	def Cookies_FileLoad( self, in_filename='' ):
		ck_filename = in_filename  if in_filename != '' else self.COOKIES_PICK_FILE
		fp = open(ck_filename, 'rb', -1) 
		try:
			pickleJar = pickle.loads( fp.read() )
			#self.HTTP_CLIENT.cookies.jar = pickleJar                           # httpx
			#self.HTTP_CLIENT.cookies.jar.__class__ = http.cookiejar.CookieJar  # httpx
			self.HTTP_CLIENT.cookies.update( pickleJar )                        # requests
		except Exception as exception:
			print( exception )
		finally:
			fp.close()


	def Cookies_Dictionary( self, domain_list=[], name_list=[] ):
		cookies = {}		
		#for i_cookie in self.HTTP_CLIENT.cookies.jar: # httpx
		for i_cookie in self.HTTP_CLIENT.cookies:      # requests
			domainNm = i_cookie.domain
			cookieNm = i_cookie.name

			if domain_list != [] and domainNm not in domain_list : continue
			if name_list   != [] and cookieNm not in name_list   : continue

			if domainNm not in cookies: cookies[domainNm] = {}
			cookies[domainNm][cookieNm] = i_cookie.value
		return cookies


	def Cookies_FileSave_Json( self, in_filename='', domain_list=[], name_list=[] ):
		ck_filename = in_filename  if in_filename != '' else self.COOKIES_JSON_FILE
		ck_json     = self.Cookies_Dictionary( domain_list=domain_list, name_list=name_list )
		try:
			fp = open(ck_filename, 'w', -1, 'utf-8')
			json.dump(ck_json, fp, indent=4, ensure_ascii=False)
		except:
			return {}
		finally:
			fp.close()


	def Cookies_Clear( self, domain=None, path=None, name=None ):
		#for i_cookie in self.HTTP_CLIENT.cookies.jar: # httpx
		for i_cookie in self.HTTP_CLIENT.cookies.jar:  # requests
			i_domain = i_cookie.domain
			i_path   = i_cookie.path
			i_name   = i_cookie.name

			if domain not in [None,''] and i_domain != domain : continue
			if path   not in [None,''] and i_path   != path   : continue
			if name   not in [None,''] and i_name   != name   : continue

			#self.HTTP_CLIENT.cookies.jar.clear( domain=i_domain, path=i_path, name=i_name ) # httpx	
			self.HTTP_CLIENT.cookies.clear( domain=i_domain, path=i_path, name=i_name )      # requests


	def Cookies_Delete_Pick( self, in_filename='' ):
		ck_filename = in_filename  if in_filename != '' else self.COOKIES_PICK_FILE
		if os.path.isfile(ck_filename): os.remove(ck_filename)

	def Cookies_Delete_Json( self, in_filename='' ):
		ck_filename = in_filename  if in_filename != '' else self.COOKIES_JSON_FILE
		if os.path.isfile(ck_filename): os.remove(ck_filename)


	def Set_Cookies_PickFileNm( self, in_filename ):
		self.COOKIES_PICK_FILE = in_filename

	def Set_Cookies_JsonFileNm( self, in_filename ):
		self.COOKIES_JSON_FILE = in_filename

	def Get_Cookies_PickFileNm( self ):
		return self.COOKIES_PICK_FILE

	def Get_Cookies_JsonFileNm( self ):
		return self.COOKIES_JSON_FILE


	def Selenium_Cookies_Save( self, in_cookies, in_filename ):
		fp = open(in_filename, 'wb', -1) 
		try:
			pickle.dump(in_cookies, fp)
		except Exception as exception:
			print( exception )
		finally:
			fp.close()

	def Selenium_Cookies_Load( self, in_filename ):
		fp = open(in_filename, 'rb', -1) 
		try:
			pickleJar = pickle.loads( fp.read() )

			if type(pickleJar) == list:
				for i_cookie in pickleJar:
					#self.HTTP_CLIENT.cookies.jar.set_cookie( self.To_Cookielib(i_cookie) ) # httpx
					self.HTTP_CLIENT.cookies.set_cookie( self.To_Cookielib(i_cookie) )      # requests
			else: # <class 'requests.cookies.RequestsCookieJar'>
				#self.HTTP_CLIENT.cookies.jar = pickleJar                           # httpx
				#self.HTTP_CLIENT.cookies.jar.__class__ = http.cookiejar.CookieJar  # httpx
				self.HTTP_CLIENT.cookies.update( pickleJar )                        # requests

		except Exception as exception:
			print( exception )
		finally:
			fp.close()


	def To_Cookielib( self, selenium_cookie ):
		return http.cookiejar.Cookie (
			version            = 0,
			name               = selenium_cookie['name'],
			value              = selenium_cookie['value'],
			port               = None,
			port_specified     = False,
			domain             = selenium_cookie['domain'],
			domain_specified   = True,
			domain_initial_dot = False,
			path               = selenium_cookie['path'],
			path_specified     = True,
			secure             = selenium_cookie['secure'],
			expires            = selenium_cookie['expiry'],
			discard            = False,
			comment            = None,
			comment_url        = None,
			rest               = { 'HttpOnly': selenium_cookie['httpOnly'] }, 
			rfc2109            = False,
		)


class PickleCookieJar(http.cookiejar.CookieJar):
	def __getstate__(self):
		state = self.__dict__.copy()
		del state['_cookies_lock']
		return state

	def __setstate__(self, state):
		self.__dict__ = state
		self._cookies_lock = threading.RLock()

	@classmethod
	def cast(cls, cookie_jar: http.cookiejar.CookieJar):
		cookie_jar.__class__ = cls
		return cookie_jar
