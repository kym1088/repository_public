# -*- coding: utf-8 -*-
__author__ = "NightRain"

import xbmcaddon, xbmcgui, xbmc, xbmcplugin, xbmcvfs
#import urllib

from baseFunc import *

INFO_CONVERT_KEY = {
	'title'       : { 'func' : 'setTitle', 'type' : 'string' },
	'plot'        : { 'func' : 'setPlot', 'type' : 'string' }, 
	'mpaa'        : { 'func' : 'setMpaa', 'type' : 'string' },
	'mediatype'   : { 'func' : 'setMediaType', 'type' : 'string' },
	'tvshowtitle' : { 'func' : 'setTvShowTitle', 'type' : 'string' },
	'premiered'   : { 'func' : 'setPremiered', 'type' : 'string' },
	'aired'       : { 'func' : 'setFirstAired', 'type' : 'string' },

    'year'        : { 'func' : 'setYear', 'type' : 'int' },
    'duration'    : { 'func' : 'setDuration', 'type' : 'int' },
	'episode'     : { 'func' : 'setEpisode', 'type' : 'int' },
	'season'      : { 'func' : 'setSeason', 'type' : 'int' },

	'studio'      : { 'func' : 'setStudios', 'type' : 'list' },
	'genre'       : { 'func' : 'setGenres', 'type' : 'list' },
	'country'     : { 'func' : 'setCountries', 'type' : 'list' },

	'cast'        : { 'func' : 'setCast', 'type' : 'actor' },
	'director'    : { 'func' : 'setDirectors', 'type' : 'list' },
}

class KodiFunc( object ):
	def __init__( self, in_addonurl, in_handle ):
		self.ADDON_URL    = in_addonurl
		self.ADDON_HANDLE = in_handle


	def Addon_Noti( self, sting ):
		try:
			dialog = xbmcgui.Dialog()
			dialog.notification( xbmcaddon.Addon().getAddonInfo('name'), sting )
		except:
			None


	def Addon_Log( self, string ):
		try:
			log_message = string.encode('utf-8', 'ignore')
		except:
			log_message = 'addonException: addon_log'
		level = xbmc.LOGINFO
		xbmc.log( "[%s-%s]: %s" %(xbmcaddon.Addon().getAddonInfo('id'), xbmcaddon.Addon().getAddonInfo('version'), log_message), level=level )



	def Get_Keyboard_Input( self, title ):
		input_text = None
		kb = xbmc.Keyboard()
		kb.setHeading( title )
		xbmc.sleep(1000)
		kb.doModal()
		if (kb.isConfirmed()):
			input_text = kb.getText()
		return input_text


	def Add_Dir( self, title, subTitle=None, img=None, infoLabels=None, isType='-', ContextMenu=None, params=None ):
		#url = '%s?%s' %(self.ADDON_URL, urllib.parse.urlencode(params))
		param_str = Params_JsonToStr(params)
		param_str = param_str.replace('+','%2B') # base64 url 전환시 특수문자(+,/) 오류
		url = '%s?params=%s' %( self.ADDON_URL, param_str )

		if subTitle : title = '%s < %s >' % (title, subTitle)
		if not img: img = 'DefaultFolder.png'

		listitem = xbmcgui.ListItem(title)
		#listitem.setLabel(label=title)

		if type(img) == dict:
		#if  'thumb' in img or 'poster' in img: #난독화시 오류때문에 #if type(img) == dict:
			listitem.setArt(img)
		else:
			listitem.setArt({'thumb':img, 'poster': img})

		# isType (playable/folder) FOLDER(False,True) / VOD(True/False) / LINK(False/False)
		if isType == 'VOD' : listitem.setProperty('IsPlayable', 'true')
		if isType == 'FOLDER':
			isFolder = True
		else:
			isFolder = False

		if int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0]) >= 20:
			if infoLabels: self.Set_InfoTag( listitem.getVideoInfoTag(), infoLabels )
		else:
			if infoLabels: listitem.setInfo('Video', infoLabels)

		#if isPlayable  : listitem.setProperty('IsPlayable', 'true')
		if ContextMenu : listitem.addContextMenuItems(ContextMenu)

		xbmcplugin.addDirectoryItem( self.ADDON_HANDLE, url, listitem, isFolder )


	def Set_InfoTag(self, video_InfoTag: xbmc.InfoTagVideo, infoLabels ):
		#tag_names = infoLabels.pop('tag', [])
		#video_InfoTag.setTagLine(' / '.join(tag_names))

		for key, value in infoLabels.items():
			#self.addon_log( key )

			if INFO_CONVERT_KEY[key]['type'] == 'string':
				getattr( video_InfoTag, INFO_CONVERT_KEY[key]['func'] )( value )

			elif INFO_CONVERT_KEY[key]['type'] == 'int':
				if type(value) == int:
					intValue = int( value )
				else:
					intValue = 0
				getattr( video_InfoTag, INFO_CONVERT_KEY[key]['func'] )( intValue )

			#elif INFO_CONVERT_KEY[key]['type'] == 'tuple':
			#	getattr( video_InfoTag, INFO_CONVERT_KEY[key]['func'] )( tuple(value) )

			elif INFO_CONVERT_KEY[key]['type'] == 'actor':
				if value != []:
					getattr( video_InfoTag, INFO_CONVERT_KEY[key]['func'] )( [xbmc.Actor(name) for name in value] )

			elif INFO_CONVERT_KEY[key]['type'] == 'list':
				if type(value) == list:
					getattr( video_InfoTag, INFO_CONVERT_KEY[key]['func'] )( value )
				else:
					getattr( video_InfoTag, INFO_CONVERT_KEY[key]['func'] )( [value] )



	def Get_Drm_Level( self ):
		drmLevel = { 'securityLevel' : None }
		import xbmcdrm
		UUID = 'edef8ba9-79d6-4ace-a3c8-27dcd51d21ed'
		crypto = xbmcdrm.CryptoSession( UUID, 'AES/CBC/NoPadding', 'HmacSHA256' )

		drmLevel['securityLevel'] = crypto.GetPropertyString('securityLevel').upper() # L1, None
		return drmLevel
