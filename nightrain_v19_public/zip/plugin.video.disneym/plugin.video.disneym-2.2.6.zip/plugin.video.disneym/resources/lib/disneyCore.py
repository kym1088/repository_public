__author__="NightRain"
ejcksExdBWOGwzKnrgIaypolFVRLfS=object
ejcksExdBWOGwzKnrgIaypolFVRLfm=False
ejcksExdBWOGwzKnrgIaypolFVRLfh=True
ejcksExdBWOGwzKnrgIaypolFVRLfb=None
ejcksExdBWOGwzKnrgIaypolFVRLfP=print
ejcksExdBWOGwzKnrgIaypolFVRLfT=Exception
ejcksExdBWOGwzKnrgIaypolFVRLfN=str
ejcksExdBWOGwzKnrgIaypolFVRLfA=int
ejcksExdBWOGwzKnrgIaypolFVRLfY=len
ejcksExdBWOGwzKnrgIaypolFVRLfD=divmod
ejcksExdBWOGwzKnrgIaypolFVRLfX=float
ejcksExdBWOGwzKnrgIaypolFVRLfC=open
import re
from baseHttp import*
from baseFunc import*
ATTRIBUTE_PATTERN =re.compile(r'''((?:[^,"']|"[^"]*"|'[^']*')+)''')
class ejcksExdBWOGwzKnrgIaypolFVRLfu(ejcksExdBWOGwzKnrgIaypolFVRLfS):
 def __init__(self):
  self.OS_ANDROID =ejcksExdBWOGwzKnrgIaypolFVRLfm 
  self.API_DOMAIN ='https://www.disneyplus.com'
  self.API_DOMAIN_NEW ='https://disney.api.edge.bamgrid.com/explore'
  self.API_VERSION_NEW ='v1.9'
  self.ONE_PAGE =15 
  self.COLLECTION_SIZE =30 
  self.HttpObj =BaseHttp()
  self.Init_DZ_Total()
  self.DZ_COOKIES_FILENAME =''
  self.DZ_SEARCHED_FILENAME =''
  self.DZ_WATCHED_MOVIE =''
  self.DZ_WATCHED_VOD =''
  self.DZ_GENRE_FILENAME =''
  self.DZ_VTT_FILENAME =''
  self.DZ_M3U8_FILENAME =''
  self.DZ_SESSION_COOKIES1 =''
  self.DZ_SESSION_COOKIES2 =''
  self.DZ_SESSION_COOKIES3 =''
  self.DZ_SESSION_COOKIES4 =''
  self.DZ_SESSION_FULLTEXT1 =''
  self.DZ_SESSION_FULLTEXT2 =''
  self.DZ_SESSION_FULLTEXT3 =''
  self.DZ_SESSION_FULLTEXT4 =''
  self.DZ_CONTEXTJSON_FILE1 =''
  self.DZ_CONTEXTJSON_FILE2 =''
  self.DZ_CONTEXTJSON_FILE3 =''
  self.DZ_CONTEXTJSON_FILE4 =''
  self.KodiVersion=20
 def Init_DZ_Total(self):
  self.DZ={'headers':{},'services':{},'account':{},}
 def Save_session_acount(self,dzid,dzpw,dzpf):
  self.DZ['account']['dzid']=Base64_Encode(dzid)
  self.DZ['account']['dzpw']=Base64_Encode(dzpw)
  self.DZ['account']['dzpf']=dzpf 
 def Load_session_acount(self):
  try:
   dzid=Base64_Decode(self.DZ['account']['dzid'])
   dzpw=Base64_Decode(self.DZ['account']['dzpw'])
   dzpf=self.DZ['account']['dzpf']
  except:
   return '','',0
  return dzid,dzpw,dzpf
 def Make_Headers(self,accessToken=ejcksExdBWOGwzKnrgIaypolFVRLfh,Bearer=ejcksExdBWOGwzKnrgIaypolFVRLfm):
  if accessToken:
   authorization=self.DZ['account']['accessToken']
  else:
   authorization=self.DZ['headers']['clientApiKey']
  if Bearer:
   authorization='Bearer {}'.format(authorization)
  headers={'authorization':authorization,'x-application-version':self.DZ['headers']['sdkAppVersion'],'x-bamsdk-client-id':self.DZ['headers']['clientId'],'x-bamsdk-platform':'windows','x-bamsdk-version':self.DZ['headers']['sdkVersion'],'x-dss-edge-accept':'vnd.dss.edge+json; version=2',}
  '''
  headers = {'authorization' : authorization, #### 'x-application-version' : 'google', # 1.1.2 'x-bamsdk-platform-id' : 'android-tv', # web not 'x-bamsdk-client-id' : self.DZ['headers']['clientId'], # disney-svod-3d9324fc 'x-bamsdk-platform' : 'android-tv', # 'windows', 'x-bamsdk-version' : '6.1.0', #self.DZ['headers']['sdkVersion'], # 7.0 / 12.0 #'x-dss-edge-accept' : 'vnd.dss.edge+json; version=2', }
  '''  
  return headers
 def Get_Prod_File(self):
  self.DZ['headers']['sdkVersion']='31.1' 
  prod_url='https://bam-sdk-configs.bamgrid.com/bam-sdk/v5.0/{}/browser/v{}/windows/chrome/prod.json'.format(self.DZ['headers']['clientId'],self.DZ['headers']['sdkVersion'])
  prod_json=self.HttpObj.Call_Request(prod_url,params=ejcksExdBWOGwzKnrgIaypolFVRLfb,headers=ejcksExdBWOGwzKnrgIaypolFVRLfb,method='GET',redirects=ejcksExdBWOGwzKnrgIaypolFVRLfm).json()
  JsonFile_Save(self.DZ_CONTEXTJSON_FILE1,prod_json)
  self.DZ['services']['orchestration']=prod_json.get('services').get('orchestration').get('client').get('endpoints')
  self.DZ['services']['content'] =prod_json.get('services').get('content').get('client').get('endpoints')
  self.DZ['services']['drm'] =prod_json.get('services').get('drm').get('client').get('endpoints')
  self.DZ['services']['media'] =prod_json.get('services').get('media').get('extras')
 def Get_Dictionary(self):
  url ='https://disney.content.edge.bamgrid.com/svc/search/v2/graphql/persisted/query/core/Dictionaries?variables='
  param=URL_StrEncode('{"preferredLanguage":"ko","dictionary":[{"resourceKey":"application","version":"421.1"}],"platform":"web"}')
  res_json=self.HttpObj.Call_Request(url+param,params=ejcksExdBWOGwzKnrgIaypolFVRLfb,headers=ejcksExdBWOGwzKnrgIaypolFVRLfb,method='GET',redirects=ejcksExdBWOGwzKnrgIaypolFVRLfm).json()
  res_json=res_json.get('data').get('Dictionaries')[0].get('entries_json')
  genre_list={}
  for(i_key,i_value)in res_json.items():
   if i_key.startswith('genre_'):
    genre_list['3'+i_key[7:]]=i_value.replace('⁠','')
  return genre_list
 def Check_ErrorMessage(self,message):
  try:
   if 'errors' in message:
    if 'description' in message['errors'][0]:
     ejcksExdBWOGwzKnrgIaypolFVRLfP(message['errors'][0]['description'])
    elif 'message' in message['errors'][0]:
     ejcksExdBWOGwzKnrgIaypolFVRLfP(message['errors'][0]['message'])
    else:
     ejcksExdBWOGwzKnrgIaypolFVRLfP('etc error')
    return ejcksExdBWOGwzKnrgIaypolFVRLfm 
  except ejcksExdBWOGwzKnrgIaypolFVRLfT as exception:
   ejcksExdBWOGwzKnrgIaypolFVRLfP(exception)
   return ejcksExdBWOGwzKnrgIaypolFVRLfm
  return ejcksExdBWOGwzKnrgIaypolFVRLfh
 def DZ_Login_Main(self,userid,userpw,userpf):
  if self.Get_DZ_InitValue()==ejcksExdBWOGwzKnrgIaypolFVRLfm:return ejcksExdBWOGwzKnrgIaypolFVRLfm
  if self.Get_DZ_GetInitToken()==ejcksExdBWOGwzKnrgIaypolFVRLfm:return ejcksExdBWOGwzKnrgIaypolFVRLfm
  if self.Get_DZ_Login(userid,userpw,userpf)==ejcksExdBWOGwzKnrgIaypolFVRLfm:return ejcksExdBWOGwzKnrgIaypolFVRLfm 
  JsonFile_Save(self.DZ_COOKIES_FILENAME,self.DZ)
  JsonFile_Save(self.DZ_GENRE_FILENAME,self.Get_Dictionary())
  return ejcksExdBWOGwzKnrgIaypolFVRLfh
 def DZ_Login_ReToken(self):
  if self.Get_DZ_GetReToken()==ejcksExdBWOGwzKnrgIaypolFVRLfm:return ejcksExdBWOGwzKnrgIaypolFVRLfm
  JsonFile_Save(self.DZ_COOKIES_FILENAME,self.DZ)
  return ejcksExdBWOGwzKnrgIaypolFVRLfh
 def Get_DZ_AccoutInfo(self):
  profile_Info={}
  try:
   url =self.DZ['services']['orchestration']['query']['href']
   headers=self.Make_Headers(accessToken=ejcksExdBWOGwzKnrgIaypolFVRLfh,Bearer=ejcksExdBWOGwzKnrgIaypolFVRLfm)
   payload={'query':'query EntitledGraphMeQuery { me { __typename account { __typename ...accountGraphFragment } activeSession { __typename ...sessionGraphFragment } } } fragment accountGraphFragment on Account { __typename id activeProfile { __typename id } profiles { __typename ...profileGraphFragment } parentalControls { __typename isProfileCreationProtected } flows { __typename star { __typename isOnboarded } } attributes { __typename email emailVerified userVerified locations { __typename manual { __typename country } purchase { __typename country } registration { __typename geoIp { __typename country } } } } } fragment profileGraphFragment on Profile { __typename id name maturityRating { __typename ratingSystem ratingSystemValues contentMaturityRating maxRatingSystemValue isMaxContentMaturityRating } isAge21Verified flows { __typename star { __typename eligibleForOnboarding isOnboarded } } attributes { __typename isDefault kidsModeEnabled groupWatch { __typename enabled } languagePreferences { __typename appLanguage playbackLanguage preferAudioDescription preferSDH subtitleLanguage subtitlesEnabled } parentalControls { __typename isPinProtected kidProofExitEnabled liveAndUnratedContent { __typename enabled } } playbackSettings { __typename autoplay backgroundVideo prefer133 preferImaxEnhancedVersion} avatar { __typename id userSelected } } } fragment sessionGraphFragment on Session { __typename sessionId device { __typename id } entitlements experiments { __typename featureId variantId version } homeLocation { __typename countryCode } inSupportedLocation isSubscriber location { __typename countryCode } portabilityLocation { __typename countryCode } preferredMaturityRating { __typename impliedMaturityRating ratingSystem } }','variables':{},'operationName':'EntitledGraphMeQuery',}
   response=self.HttpObj.Call_Request(url,json=payload,headers=headers,method='POST')
   if response.status_code not in[200,201]:return{}
   resJson=response.json()
   account =resJson['data']['me']['account']
   activeProfile=account['activeProfile']['id']
   for i_account in account['profiles']:
    if i_account['id']==activeProfile:
     profile_Info=i_account
     break
  except ejcksExdBWOGwzKnrgIaypolFVRLfT as exception:
   ejcksExdBWOGwzKnrgIaypolFVRLfP(exception)
   return{}
  return profile_Info
 def _set_Imax(self):
  try:
   url =self.DZ['services']['orchestration']['query']['href']
   headers=self.Make_Headers(accessToken=ejcksExdBWOGwzKnrgIaypolFVRLfh,Bearer=ejcksExdBWOGwzKnrgIaypolFVRLfm)
   payload={'query':'mutation updateProfileImaxEnhancedVersion($input: UpdateProfileImaxEnhancedVersionInput!) {updateProfileImaxEnhancedVersion(updateProfileImaxEnhancedVersion: $input) {accepted}}','variables':{'input':{'imaxEnhancedVersion':ejcksExdBWOGwzKnrgIaypolFVRLfh}},}
   response=self.HttpObj.Call_Request(url,json=payload,headers=headers,method='POST')
   if response.status_code not in[200,201]:return{}
   resJson=response.json()
   JsonFile_Save(self.DZ_SESSION_COOKIES4,resJson)
   self.DZ['account']['accessToken'] =resJson.get('extensions').get('sdk').get('token').get('accessToken')
   self.DZ['account']['accessTokenType']=resJson.get('extensions').get('sdk').get('token').get('accessTokenType')
   self.DZ['account']['refreshToken'] =resJson.get('extensions').get('sdk').get('token').get('refreshToken')
   self.DZ['account']['token_limit'] =Get_TimeStamp()+14400 
   self.DZ['account']['deviceId'] =resJson.get('extensions').get('sdk').get('session').get('device').get('id')
   self.DZ['account']['sessionId'] =resJson.get('extensions').get('sdk').get('session').get('sessionId')
  except ejcksExdBWOGwzKnrgIaypolFVRLfT as exception:
   ejcksExdBWOGwzKnrgIaypolFVRLfP(exception)
   return ejcksExdBWOGwzKnrgIaypolFVRLfm
  return ejcksExdBWOGwzKnrgIaypolFVRLfh
 def Set_DZ_Imax(self):
  try:
   profile_Info=self.Get_DZ_AccoutInfo()
   if profile_Info['attributes']['playbackSettings']['preferImaxEnhancedVersion']==ejcksExdBWOGwzKnrgIaypolFVRLfm:
    self._set_Imax()
    JsonFile_Save(self.DZ_COOKIES_FILENAME,self.DZ)
  except ejcksExdBWOGwzKnrgIaypolFVRLfT as exception:
   ejcksExdBWOGwzKnrgIaypolFVRLfP(exception)
 def Get_DZ_InitValue(self):
  try:
   url=self.API_DOMAIN 
   response=self.HttpObj.Call_Request(url,params=ejcksExdBWOGwzKnrgIaypolFVRLfb,headers=ejcksExdBWOGwzKnrgIaypolFVRLfb,method='GET',redirects=ejcksExdBWOGwzKnrgIaypolFVRLfm)
   JSON_REGEX=r'<script id="__NEXT_DATA__" type="application/json">\s*(.*?)\s*</script>'
   regex_Text=re.compile(JSON_REGEX,re.DOTALL).findall(response.text)[0]
   paths_json =json.loads(regex_Text)
   self.DZ['headers']['clientId'] =paths_json.get('props').get('pageProps').get('remoteConfig').get('path').get('sdk').get('clientId') 
   self.DZ['headers']['sdkAppVersion']=paths_json.get('props').get('pageProps').get('remoteConfig').get('path').get('sdk').get('application').get('version')
   self.DZ['headers']['clientApiKey']=paths_json.get('props').get('pageProps').get('remoteConfig').get('path').get('sdk').get('clientApiKey') 
   self.DZ['headers']['lang'] ='ko-kr' 
   self.DZ['headers']['regionCode'] ='KR' 
   self.Get_Prod_File() 
  except ejcksExdBWOGwzKnrgIaypolFVRLfT as exception:
   ejcksExdBWOGwzKnrgIaypolFVRLfP(exception)
   return ejcksExdBWOGwzKnrgIaypolFVRLfm
  return ejcksExdBWOGwzKnrgIaypolFVRLfh
 def Get_DZ_GetInitToken(self):
  try:
   url =self.DZ['services']['orchestration']['registerDevice']['href']
   headers=self.Make_Headers(accessToken=ejcksExdBWOGwzKnrgIaypolFVRLfm,Bearer=ejcksExdBWOGwzKnrgIaypolFVRLfm)
   payload={'query':'mutation registerDevice($input: RegisterDeviceInput!) {\n            registerDevice(registerDevice: $input) {\n                grant {\n                    grantType\n                    assertion\n                }\n            }\n        }','variables':{'input':{'applicationRuntime':'chrome','attributes':{'browserName':'chrome','browserVersion':'96.0.4664','manufacturer':'microsoft','model':ejcksExdBWOGwzKnrgIaypolFVRLfb,'operatingSystem':'windows','operatingSystemVersion':'10.0','osDeviceIds':[],},'deviceFamily':'browser','deviceLanguage':'ko-KR','deviceProfile':'windows',}}}
   '''
   payload = {'query': 'mutation ($registerDevice: RegisterDeviceInput!) {registerDevice(registerDevice: $registerDevice) {__typename}}', 'variables': {'registerDevice': {'applicationRuntime' : 'android', 'attributes': {'operatingSystem' : 'Android', 'operatingSystemVersion' : '8.1.0', }, 'deviceFamily' : 'android', 'deviceLanguage' : 'ko', 'deviceProfile' : 'tv', } }, }
   '''   
   response=self.HttpObj.Call_Request(url,json=payload,headers=headers,method='POST')
   if response.status_code not in[200,201]:return ejcksExdBWOGwzKnrgIaypolFVRLfm
   resJson=response.json()
   if self.Check_ErrorMessage(resJson)==ejcksExdBWOGwzKnrgIaypolFVRLfm:return ejcksExdBWOGwzKnrgIaypolFVRLfm
   self.DZ['account']['accessToken'] =resJson.get('extensions').get('sdk').get('token').get('accessToken')
   self.DZ['account']['accessTokenType']=resJson.get('extensions').get('sdk').get('token').get('accessTokenType')
   self.DZ['account']['refreshToken'] =resJson.get('extensions').get('sdk').get('token').get('refreshToken')
   self.DZ['account']['token_limit'] =Get_TimeStamp()+14400 
  except ejcksExdBWOGwzKnrgIaypolFVRLfT as exception:
   ejcksExdBWOGwzKnrgIaypolFVRLfP(exception)
   return ejcksExdBWOGwzKnrgIaypolFVRLfm
  return ejcksExdBWOGwzKnrgIaypolFVRLfh
 def Get_DZ_GetReToken(self):
  try:
   url =self.DZ['services']['orchestration']['refreshToken']['href']
   headers=self.Make_Headers(accessToken=ejcksExdBWOGwzKnrgIaypolFVRLfm,Bearer=ejcksExdBWOGwzKnrgIaypolFVRLfm)
   payload={'query':'mutation refreshToken($input: RefreshTokenInput!) {\n            refreshToken(refreshToken: $input) {\n                activeSession {\n                    sessionId\n                }\n            }\n        }','variables':{'input':{'refreshToken':self.DZ['account']['refreshToken'],}}}
   response=self.HttpObj.Call_Request(url,json=payload,headers=headers,method='POST')
   if response.status_code not in[200,201]:return ejcksExdBWOGwzKnrgIaypolFVRLfm
   resJson=response.json()
   if self.Check_ErrorMessage(resJson)==ejcksExdBWOGwzKnrgIaypolFVRLfm:return ejcksExdBWOGwzKnrgIaypolFVRLfm
   self.DZ['account']['accessToken'] =resJson.get('extensions').get('sdk').get('token').get('accessToken')
   self.DZ['account']['accessTokenType']=resJson.get('extensions').get('sdk').get('token').get('accessTokenType')
   self.DZ['account']['refreshToken'] =resJson.get('extensions').get('sdk').get('token').get('refreshToken')
   self.DZ['account']['token_limit'] =Get_TimeStamp()+14400 
   self.DZ['account']['deviceId'] =resJson.get('extensions').get('sdk').get('session').get('device').get('id')
   self.DZ['account']['sessionId'] =resJson.get('extensions').get('sdk').get('session').get('sessionId')
  except ejcksExdBWOGwzKnrgIaypolFVRLfT as exception:
   ejcksExdBWOGwzKnrgIaypolFVRLfP(exception)
   return ejcksExdBWOGwzKnrgIaypolFVRLfm
  return ejcksExdBWOGwzKnrgIaypolFVRLfh
 def Get_DZ_Login(self,userid,userpw,userpf):
  try:
   url =self.DZ['services']['orchestration']['query']['href']
   headers=self.Make_Headers(accessToken=ejcksExdBWOGwzKnrgIaypolFVRLfh,Bearer=ejcksExdBWOGwzKnrgIaypolFVRLfm)
   payload={'query':'\n    query Check($email: String!) {\n        check(email: $email) {\n            operations\n            nextOperation\n        }\n    }\n','variables':{'email':userid}}
   response=self.HttpObj.Call_Request(url,json=payload,headers=headers,method='POST')
   if response.status_code not in[200,201]:return ejcksExdBWOGwzKnrgIaypolFVRLfm
   resJson=response.json()
   if 'Login' not in resJson.get('data').get('check').get('operations'):return ejcksExdBWOGwzKnrgIaypolFVRLfm 
   url =self.DZ['services']['orchestration']['query']['href']
   headers=self.Make_Headers(accessToken=ejcksExdBWOGwzKnrgIaypolFVRLfh,Bearer=ejcksExdBWOGwzKnrgIaypolFVRLfm)
   payload={'query':'\n    mutation login($input: LoginInput!) {\n        login(login: $input) {\n            account {\n                ...account\n\n                profiles {\n                    ...profile\n                }\n            }\n            actionGrant\n        }\n    }\n\n    \nfragment account on Account {\n    id\n    attributes {\n        blocks {\n            expiry\n            reason\n        }\n        consentPreferences {\n            dataElements {\n                name\n                value\n            }\n            purposes {\n                consentDate\n                firstTransactionDate\n                id\n                lastTransactionCollectionPointId\n                lastTransactionCollectionPointVersion\n                lastTransactionDate\n                name\n                status\n                totalTransactionCount\n                version\n            }\n        }\n        dssIdentityCreatedAt\n        email\n        emailVerified\n        lastSecurityFlaggedAt\n        locations {\n            manual {\n                country\n            }\n            purchase {\n                country\n                source\n            }\n            registration {\n                geoIp {\n                    country\n                }\n            }\n        }\n        securityFlagged\n        tags\n        taxId\n        userVerified\n    }\n    parentalControls {\n        isProfileCreationProtected\n    }\n    flows {\n        star {\n            isOnboarded\n        }\n    }\n}\n\n    \nfragment profile on Profile {\n    id\n    name\n    isAge21Verified\n    attributes {\n        avatar {\n            id\n            userSelected\n        }\n        isDefault\n        kidsModeEnabled\n        languagePreferences {\n            appLanguage\n            playbackLanguage\n            preferAudioDescription\n            preferSDH\n            subtitleAppearance {\n                backgroundColor\n                backgroundOpacity\n                description\n                font\n                size\n                textColor\n            }\n            subtitleLanguage\n            subtitlesEnabled\n        }\n        groupWatch {\n            enabled\n        }\n        parentalControls {\n            kidProofExitEnabled\n            isPinProtected\n        }\n        playbackSettings {\n            autoplay\n            backgroundVideo\n            prefer133\n            preferImaxEnhancedVersion\n            previewAudioOnHome\n            previewVideoOnHome\n        }\n    }\n    maturityRating {\n        ...maturityRating\n    }\n    flows {\n        star {\n            eligibleForOnboarding\n            isOnboarded\n        }\n    }\n}\n\n\nfragment maturityRating on MaturityRating {\n    ratingSystem\n    ratingSystemValues\n    contentMaturityRating\n    maxRatingSystemValue\n    isMaxContentMaturityRating\n}\n\n\n','variables':{'input':{'email':userid,'password':userpw,}}}
   response=self.HttpObj.Call_Request(url,json=payload,headers=headers,method='POST')
   if response.status_code not in[200,201]:return ejcksExdBWOGwzKnrgIaypolFVRLfm
   resJson=response.json()
   if self.Check_ErrorMessage(resJson)==ejcksExdBWOGwzKnrgIaypolFVRLfm:return ejcksExdBWOGwzKnrgIaypolFVRLfm
   self.DZ['account']['accessToken'] =resJson.get('extensions').get('sdk').get('token').get('accessToken')
   self.DZ['account']['accessTokenType']=resJson.get('extensions').get('sdk').get('token').get('accessTokenType')
   self.DZ['account']['refreshToken'] =resJson.get('extensions').get('sdk').get('token').get('refreshToken')
   self.DZ['account']['token_limit'] =Get_TimeStamp()+14400 
   self.DZ['account']['profile'] =resJson.get('data').get('login').get('account').get('profiles')[userpf].get('id')
   url =self.DZ['services']['orchestration']['query']['href']
   headers=self.Make_Headers(accessToken=ejcksExdBWOGwzKnrgIaypolFVRLfh,Bearer=ejcksExdBWOGwzKnrgIaypolFVRLfm)
   payload={'query':'\n    mutation switchProfile($input: SwitchProfileInput!) {\n        switchProfile(switchProfile: $input) {\n            account {\n                ...account\n\n                activeProfile {\n                    ...profile\n                }\n            }\n        }\n    }\n\n    \nfragment account on Account {\n    id\n    attributes {\n        blocks {\n            expiry\n            reason\n        }\n        consentPreferences {\n            dataElements {\n                name\n                value\n            }\n            purposes {\n                consentDate\n                firstTransactionDate\n                id\n                lastTransactionCollectionPointId\n                lastTransactionCollectionPointVersion\n                lastTransactionDate\n                name\n                status\n                totalTransactionCount\n                version\n            }\n        }\n        dssIdentityCreatedAt\n        email\n        emailVerified\n        lastSecurityFlaggedAt\n        locations {\n            manual {\n                country\n            }\n            purchase {\n                country\n                source\n            }\n            registration {\n                geoIp {\n                    country\n                }\n            }\n        }\n        securityFlagged\n        tags\n        taxId\n        userVerified\n    }\n    parentalControls {\n        isProfileCreationProtected\n    }\n    flows {\n        star {\n            isOnboarded\n        }\n    }\n}\n\n    \nfragment profile on Profile {\n    id\n    name\n    isAge21Verified\n    attributes {\n        avatar {\n            id\n            userSelected\n        }\n        isDefault\n        kidsModeEnabled\n        languagePreferences {\n            appLanguage\n            playbackLanguage\n            preferAudioDescription\n            preferSDH\n            subtitleAppearance {\n                backgroundColor\n                backgroundOpacity\n                description\n                font\n                size\n                textColor\n            }\n            subtitleLanguage\n            subtitlesEnabled\n        }\n        groupWatch {\n            enabled\n        }\n        parentalControls {\n            kidProofExitEnabled\n            isPinProtected\n        }\n        playbackSettings {\n            autoplay\n            backgroundVideo\n            prefer133\n            preferImaxEnhancedVersion\n            previewAudioOnHome\n            previewVideoOnHome\n        }\n    }\n    maturityRating {\n        ...maturityRating\n    }\n    flows {\n        star {\n            eligibleForOnboarding\n            isOnboarded\n        }\n    }\n}\n\n\nfragment maturityRating on MaturityRating {\n    ratingSystem\n    ratingSystemValues\n    contentMaturityRating\n    maxRatingSystemValue\n    isMaxContentMaturityRating\n}\n\n\n','variables':{'input':{'profileId':self.DZ['account']['profile'],}}}
   response=self.HttpObj.Call_Request(url,json=payload,headers=headers,method='POST')
   if response.status_code not in[200,201]:return ejcksExdBWOGwzKnrgIaypolFVRLfm
   resJson=response.json()
   if self.Check_ErrorMessage(resJson)==ejcksExdBWOGwzKnrgIaypolFVRLfm:return ejcksExdBWOGwzKnrgIaypolFVRLfm
   self.DZ['account']['accessToken'] =resJson.get('extensions').get('sdk').get('token').get('accessToken')
   self.DZ['account']['accessTokenType']=resJson.get('extensions').get('sdk').get('token').get('accessTokenType')
   self.DZ['account']['refreshToken'] =resJson.get('extensions').get('sdk').get('token').get('refreshToken')
   self.DZ['account']['token_limit'] =Get_TimeStamp()+14400 
   self.DZ['account']['deviceId'] =resJson.get('extensions').get('sdk').get('session').get('device').get('id')
   self.DZ['account']['sessionId'] =resJson.get('extensions').get('sdk').get('session').get('sessionId')
   self.Save_session_acount(userid,userpw,userpf)
  except ejcksExdBWOGwzKnrgIaypolFVRLfT as exception:
   ejcksExdBWOGwzKnrgIaypolFVRLfP(exception)
   return ejcksExdBWOGwzKnrgIaypolFVRLfm
  return ejcksExdBWOGwzKnrgIaypolFVRLfh
 def Make_Endpoint(self,uMode,**kwargs):
  if uMode=='COLLECTION':
   href=self.DZ['services']['content']['getCollection']['href']
  elif uMode=='PROGRAM_LIST':
   href=self.DZ['services']['content']['getCuratedSet']['href']
  elif uMode=='SEASON_LIST':
   href=self.DZ['services']['content']['getDmcSeriesBundle']['href']
  elif uMode=='EPISODE_LIST':
   href=self.DZ['services']['content']['getDmcEpisodes']['href']
  elif uMode=='STREAMING_URL':
   href=self.DZ['services']['content']['getDmcVideo']['href']
  elif uMode=='SEARCH_LIST':
   href=self.DZ['services']['content']['getSearchResults']['href']
  elif uMode=='VIDEO_BUNDLE':
   href=self.DZ['services']['content']['getDmcVideoBundle']['href']
  elif uMode=='DELETE_WATCHLIST':
   href=self.DZ['services']['content']['deleteFromWatchlist']['href']
  elif uMode=='DELETE_WATCHLIST2':
   href=self.DZ['services']['content']['deleteItemFromWatchlist']['href']
  else:
   return ''
  _args={'apiVersion':'5.1','region':self.DZ['headers']['regionCode'],'kidsModeEnabled':'false','impliedMaturityRating':'1870','appLanguage':self.DZ['headers']['lang'][0:2],'partner':'disney','queryType':'ge',}
  _args.update(**kwargs)
  return href.format(**_args)
 def Get_Brand_List(self):
  brand_list=[]
  brand_name={'disney':'Disney (디즈니)','pixar':'Pixer (픽사)','marvel':'마블','star-wars':'스타워즈','national-geographic':'내셔널지오그래픽','brand-star':'Star',}
  try:
   url =self.Make_Endpoint('COLLECTION',collectionSubType='PersonalizedCollection',contentClass='home',slug='home')
   headers=self.Make_Headers(accessToken=ejcksExdBWOGwzKnrgIaypolFVRLfh,Bearer=ejcksExdBWOGwzKnrgIaypolFVRLfh)
   response=self.HttpObj.Call_Request(url,headers=headers,method='GET')
   if response.status_code not in[200,201]:return ejcksExdBWOGwzKnrgIaypolFVRLfm
   resJson=response.json()
   for i_collection in resJson.get('data').get('Collection').get('containers'):
    if i_collection.get('style')=='brandSix':
     for i_brand in i_collection.get('set').get('items'):
      contentClass='brand' 
      contentSlugs=i_brand.get('collectionGroup').get('slugs')[0].get('value')
      contentName =i_brand.get('text').get('title').get('full').get('collection').get('default').get('content')
      if contentSlugs in brand_name:
       contentName=brand_name.get(contentSlugs)
      thumb =i_brand.get('image').get('tile').get('1.78').get('default').get('default').get('url')
      poster=i_brand.get('image').get('hero_collection').get('0.71').get('default').get('default').get('url')
      temp_list={'contentClass':contentClass,'contentSlugs':contentSlugs,'contentName':contentName,'thumb':thumb,'poster':poster,}
      brand_list.append(temp_list)
     break
  except ejcksExdBWOGwzKnrgIaypolFVRLfT as exception:
   ejcksExdBWOGwzKnrgIaypolFVRLfP(exception)
   return[]
  return brand_list
 def Get_Collection_Group(self,contentClass,contentSlugs):
  collection_list=[]
  try:
   if contentClass=='home':
    collectionSubType='PersonalizedCollection'
   else:
    collectionSubType='StandardCollection'
   url =self.Make_Endpoint('COLLECTION',collectionSubType=collectionSubType,contentClass=contentClass,slug=contentSlugs)
   headers=self.Make_Headers(accessToken=ejcksExdBWOGwzKnrgIaypolFVRLfh,Bearer=ejcksExdBWOGwzKnrgIaypolFVRLfh)
   response=self.HttpObj.Call_Request(url,headers=headers,method='GET')
   if response.status_code not in[200,201]:return ejcksExdBWOGwzKnrgIaypolFVRLfm
   resJson=response.json()
   for i_collection in resJson.get('data').get('Collection').get('containers'):
    if i_collection['style']=='brandSix':continue
    refId =i_collection.get('set').get('refId')
    refType=i_collection.get('set').get('refType')
    if not i_collection.get('set').get('text')and i_collection['style']=='ContinueWatchingSet':
     title='시청중인 콘텐츠'
    elif not i_collection.get('set').get('text')or refType=='BecauseYouSet':
     title='None'
     title=self.Get_Group_Title(refId,refType)
     if '{title}' in title:continue 
    else:
     title =i_collection.get('set').get('text').get('title').get('full').get('set').get('default').get('content').strip()
    if title=='다시 보기' and refType=='RecommendationSet':continue 
    temp_list={'title':title,'refId':refId,'refType':refType,}
    collection_list.append(temp_list)
  except ejcksExdBWOGwzKnrgIaypolFVRLfT as exception:
   ejcksExdBWOGwzKnrgIaypolFVRLfP(exception)
   return[]
  return collection_list
 def Get_Group_Title(self,refId,refType):
  group_title='None'
  try:
   url =self.Make_Endpoint('PROGRAM_LIST',setId=refId,pageSize=ejcksExdBWOGwzKnrgIaypolFVRLfN(15),page=ejcksExdBWOGwzKnrgIaypolFVRLfN(1))
   headers=self.Make_Headers(accessToken=ejcksExdBWOGwzKnrgIaypolFVRLfh,Bearer=ejcksExdBWOGwzKnrgIaypolFVRLfh)
   if refType!='CuratedSet':
    url=url.replace('CuratedSet',refType)
   response=self.HttpObj.Call_Request(url,headers=headers,method='GET')
   if response.status_code not in[200,201]:group_title
   resJson=response.json().get('data').get(refType)
   group_title=resJson.get('text').get('title').get('full').get('set').get('default').get('content').strip()
  except ejcksExdBWOGwzKnrgIaypolFVRLfT as exception:
   ejcksExdBWOGwzKnrgIaypolFVRLfP(exception)
   return group_title
  return group_title
 def Get_refId(self,contentClass,contentSlugs):
  try:
   url =self.Make_Endpoint('COLLECTION',collectionSubType='StandardCollection',contentClass=contentClass,slug=contentSlugs)
   headers=self.Make_Headers(accessToken=ejcksExdBWOGwzKnrgIaypolFVRLfh,Bearer=ejcksExdBWOGwzKnrgIaypolFVRLfh)
   response=self.HttpObj.Call_Request(url,headers=headers,method='GET')
   if response.status_code not in[200,201]:return ejcksExdBWOGwzKnrgIaypolFVRLfm
   resJson=response.json()
   refId =resJson['data']['Collection']['containers'][0]['set']['refId']
   refType=resJson['data']['Collection']['containers'][0]['set']['refType']
  except ejcksExdBWOGwzKnrgIaypolFVRLfT as exception:
   ejcksExdBWOGwzKnrgIaypolFVRLfP(exception)
   return '',''
  return refId,refType
 def Get_Program_List(self,refId,refType,page_int,page_Size):
  program_list=[]
  more_page =ejcksExdBWOGwzKnrgIaypolFVRLfm
  try:
   url =self.Make_Endpoint('PROGRAM_LIST',setId=refId,pageSize=ejcksExdBWOGwzKnrgIaypolFVRLfN(page_Size),page=ejcksExdBWOGwzKnrgIaypolFVRLfN(page_int))
   headers=self.Make_Headers(accessToken=ejcksExdBWOGwzKnrgIaypolFVRLfh,Bearer=ejcksExdBWOGwzKnrgIaypolFVRLfh)
   if refType=='ContinueWatchingSet':
    url=url.replace('CuratedSet','ContinueWatching/Set')
    url=re.sub(pattern=r'/pageSize/\d+/page/\d+',repl='',string=url)
   elif refType!='CuratedSet':
    url=url.replace('CuratedSet',refType)
   response=self.HttpObj.Call_Request(url,headers=headers,method='GET')
   if response.status_code not in[200,201]:return[],ejcksExdBWOGwzKnrgIaypolFVRLfm
   resJson=response.json().get('data').get(refType)
   for i_item in resJson.get('items'):
    encodedId =ejcksExdBWOGwzKnrgIaypolFVRLfb 
    contentId =ejcksExdBWOGwzKnrgIaypolFVRLfb 
    contentClass=ejcksExdBWOGwzKnrgIaypolFVRLfb 
    contentSlugs=ejcksExdBWOGwzKnrgIaypolFVRLfb 
    temp_image=i_item.get('image')
    if i_item.get('type')=='DmcSeries' or(refType=='ContinueWatchingSet' and 'encodedSeriesId' in i_item) or(i_item.get('type')=='DmcVideo' and i_item.get('seasonId')!=ejcksExdBWOGwzKnrgIaypolFVRLfb) : 
     vType ='tvshow'
     title =i_item.get('text').get('title').get('full').get('series').get('default').get('content')
     ejcksExdBWOGwzKnrgIaypolFVRLfP(vType+' - '+title)
     poster=self.Get_imageurl_parser(temp_image,['tile'],['0.75','0.67'],'series')
     if 'hero_tile' in temp_image:
      thumb=self.Get_imageurl_parser(temp_image,['hero_tile'],['1.78'],'series')
     else:
      thumb=self.Get_imageurl_parser(temp_image,['hero_collection'],['1.78'],'series')
     if 'title_treatment_centered' in temp_image:
      clearlogo=self.Get_imageurl_parser(temp_image,['title_treatment_centered'],['1.78'],'series')
     else:
      clearlogo=self.Get_imageurl_parser(temp_image,['title_treatment'],['1.78','3.32'],'series')
     encodedId=i_item.get('encodedSeriesId')
    elif i_item.get('type')=='DmcVideo':
     vType ='movie'
     title =i_item.get('text').get('title').get('full').get('program').get('default').get('content')
     ejcksExdBWOGwzKnrgIaypolFVRLfP(vType+' - '+title)
     programType='series' if i_item.get('programType')=='episode' else 'program'
     poster=self.Get_imageurl_parser(temp_image,['tile'],['0.75','0.67'],programType)
     if 'hero_tile' in temp_image:
      thumb=self.Get_imageurl_parser(temp_image,['hero_tile'],['1.78'],programType)
     else:
      thumb=self.Get_imageurl_parser(temp_image,['hero_collection'],['1.78'],programType)
     if 'title_treatment_centered' in temp_image:
      clearlogo=self.Get_imageurl_parser(temp_image,['title_treatment_centered'],['1.78'],programType)
     else:
      clearlogo=self.Get_imageurl_parser(temp_image,['title_treatment'],['1.78','3.32'],programType)
     encodedId=i_item.get('family').get('encodedFamilyId')
     contentId=i_item.get('contentId') 
    elif i_item.get('type')=='StandardCollection':
     vType ='collection'
     title =i_item.get('text').get('title').get('full').get('collection').get('default').get('content')
     ejcksExdBWOGwzKnrgIaypolFVRLfP(vType+' - '+title)
     poster=self.Get_imageurl_parser(temp_image,['tile'],['0.71','0.67'],'default')
     if 'hero_tile' in temp_image:
      thumb=self.Get_imageurl_parser(temp_image,['hero_tile'],['1.78'],'default')
     else:
      thumb=self.Get_imageurl_parser(temp_image,['hero_collection'],['1.78'],'default')
     if 'title_treatment_centered' in temp_image:
      clearlogo=self.Get_imageurl_parser(temp_image,['title_treatment_centered'],['1.78'],'default')
     else:
      clearlogo=self.Get_imageurl_parser(temp_image,['title_treatment'],['1.78','3.32'],'default')
     contentClass=i_item.get('collectionGroup').get('contentClass')
     contentSlugs=i_item.get('collectionGroup').get('slugs')[0].get('value')
    else:
     return program_list,more_page
    year =i_item.get('releases')[0].get('releaseYear')if 'releases' in i_item else ''
    aired =i_item.get('releases')[0].get('releaseDate')if 'releases' in i_item else ''
    duration =ejcksExdBWOGwzKnrgIaypolFVRLfA(i_item.get('mediaMetadata').get('runtimeMillis')/1000) if i_item.get('type')=='DmcVideo' else 0
    temp_list={'title':title,'vType':vType,'encodedId':encodedId,'contentId':contentId,'contentClass':contentClass,'contentSlugs':contentSlugs,'year':year,'aired':aired,'duration':duration,'poster':poster+'/scale?width=400&aspectRatio=0.75','thumb':thumb+'/scale?width=800&aspectRatio=1.78','clearlogo':clearlogo+'/scale?width=200&aspectRatio=1.78',}
    program_list.append(temp_list)
   if resJson.get('meta').get('hits')>page_Size*(page_int):more_page=ejcksExdBWOGwzKnrgIaypolFVRLfh
  except ejcksExdBWOGwzKnrgIaypolFVRLfT as exception:
   ejcksExdBWOGwzKnrgIaypolFVRLfP(exception)
   return[],ejcksExdBWOGwzKnrgIaypolFVRLfm
  return program_list,more_page
 def Get_imageurl_parser(self,imageJson,imageType,imageSize,programType):
  result_URL =''
  try:
   for iType in imageType:
    tempImage=imageJson.get(iType)
    if tempImage!=ejcksExdBWOGwzKnrgIaypolFVRLfb:break
   for i_size in imageSize:
    if tempImage.get(i_size)==ejcksExdBWOGwzKnrgIaypolFVRLfb:continue
    if programType in tempImage.get(i_size):
     result_URL=tempImage.get(i_size).get(programType).get('default').get('url')
    if result_URL=='' and 'series' in tempImage.get(i_size):
     result_URL=tempImage.get(i_size).get('series').get('default').get('url')
    if result_URL=='' and 'program' in tempImage.get(i_size):
     result_URL=tempImage.get(i_size).get('program').get('default').get('url')
   if result_URL=='':
    for i_value in tempImage:
     if programType in tempImage.get(i_size):
      result_URL=tempImage.get(i_value).get(programType).get('default').get('url')
     if result_URL=='' and 'series' in tempImage.get(i_size):
      result_URL=tempImage.get(i_value).get('series').get('default').get('url')
     if result_URL=='' and 'program' in tempImage.get(i_size):
      result_URL=tempImage.get(i_value).get('program').get('default').get('url')
     break
  except ejcksExdBWOGwzKnrgIaypolFVRLfT as exception:
   ejcksExdBWOGwzKnrgIaypolFVRLfP(exception)
   return '' 
  return result_URL
 def Get_imageurl_parser2(self,imageJson,imageType,imageSize):
  result_URL =''
  try:
   for iType in imageType:
    tempImage=imageJson.get(iType)
    if tempImage!=ejcksExdBWOGwzKnrgIaypolFVRLfb:break
   for i_size in imageSize:
    if tempImage.get(i_size)==ejcksExdBWOGwzKnrgIaypolFVRLfb:continue
    result_URL=tempImage.get(i_size).get('imageId')
    break
   if result_URL=='':
    for i_value in tempImage:
     result_URL=tempImage.get(i_value).get('imageId')
     break
  except ejcksExdBWOGwzKnrgIaypolFVRLfT as exception:
   ejcksExdBWOGwzKnrgIaypolFVRLfP(exception)
   return '' 
  if result_URL!='':
   result_URL=self.Image_IdtoUrl(result_URL)
  return result_URL
 def Delete_Watch_List(self,refId,refType):
  try:
   url =self.Make_Endpoint('DELETE_WATCHLIST2',refIdType=refType,refId=refId)
   headers=self.Make_Headers(accessToken=ejcksExdBWOGwzKnrgIaypolFVRLfh,Bearer=ejcksExdBWOGwzKnrgIaypolFVRLfh)
   response=self.HttpObj.Call_Request(url,headers=headers,method='DELETE')
  except ejcksExdBWOGwzKnrgIaypolFVRLfT as exception:
   ejcksExdBWOGwzKnrgIaypolFVRLfP(exception)
   return ejcksExdBWOGwzKnrgIaypolFVRLfm
  return ejcksExdBWOGwzKnrgIaypolFVRLfh
 def Get_Search_List(self,search_key):
  search_list=[]
  try:
   url =self.Make_Endpoint('SEARCH_LIST',pageSize=ejcksExdBWOGwzKnrgIaypolFVRLfN(self.COLLECTION_SIZE),query=search_key)
   headers=self.Make_Headers(accessToken=ejcksExdBWOGwzKnrgIaypolFVRLfh,Bearer=ejcksExdBWOGwzKnrgIaypolFVRLfh)
   response=self.HttpObj.Call_Request(url,headers=headers,method='GET')
   if response.status_code not in[200,201]:return[]
   resJson=response.json().get('data').get('search')
   for i_item in resJson.get('hits'):
    i_item=i_item.get('hit')
    encodedId =ejcksExdBWOGwzKnrgIaypolFVRLfb 
    contentId =ejcksExdBWOGwzKnrgIaypolFVRLfb 
    contentClass=ejcksExdBWOGwzKnrgIaypolFVRLfb 
    contentSlugs=ejcksExdBWOGwzKnrgIaypolFVRLfb 
    temp_image=i_item.get('image')
    if i_item.get('type')=='DmcSeries': 
     vType ='tvshow'
     title =i_item.get('text').get('title').get('full').get('series').get('default').get('content')
     poster=self.Get_imageurl_parser(temp_image,['tile'],['0.75','0.67'],'series')
     if 'background_details' in temp_image:
      thumb=self.Get_imageurl_parser(temp_image,['background_details'],['1.78'],'series')
     else:
      thumb=self.Get_imageurl_parser(temp_image,['background'],['1.78'],'series')
     encodedId =i_item.get('encodedSeriesId')
    elif i_item.get('type')=='DmcVideo':
     vType ='movie'
     title =i_item.get('text').get('title').get('full').get('program').get('default').get('content')
     poster=self.Get_imageurl_parser(temp_image,['tile'],['0.75','0.67'],'video')
     if 'background_details' in temp_image:
      thumb=self.Get_imageurl_parser(temp_image,['background_details'],['1.78'],'video')
     else:
      thumb=self.Get_imageurl_parser(temp_image,['background'],['1.78'],'video')
     encodedId =i_item.get('family').get('encodedFamilyId')
     contentId =i_item.get('contentId') 
    elif i_item.get('type')=='StandardCollection':
     vType ='collection'
     title =i_item.get('text').get('title').get('full').get('collection').get('default').get('content')
     poster=self.Get_imageurl_parser(temp_image,['tile'],['0.71','0.67'],'default')
     if 'background_details' in temp_image:
      thumb=self.Get_imageurl_parser(temp_image,['background_details'],['1.78'],'default')
     else:
      thumb=self.Get_imageurl_parser(temp_image,['background'],['1.78'],'default')
     contentClass=i_item.get('collectionGroup').get('contentClass')
     contentSlugs=i_item.get('collectionGroup').get('slugs')[0].get('value')
    else:
     return search_list
    year =i_item.get('releases')[0].get('releaseYear')if 'releases' in i_item else ''
    aired =i_item.get('releases')[0].get('releaseDate')if 'releases' in i_item else ''
    duration =ejcksExdBWOGwzKnrgIaypolFVRLfA(i_item.get('mediaMetadata').get('runtimeMillis')/1000) if i_item.get('type')=='DmcVideo' else 0
    temp_list={'title':title,'vType':vType,'encodedId':encodedId,'contentId':contentId,'contentClass':contentClass,'contentSlugs':contentSlugs,'year':year,'aired':aired,'duration':duration,'poster':poster+'/scale?width=400&aspectRatio=0.75','thumb':thumb+'/scale?width=800&aspectRatio=1.78',}
    search_list.append(temp_list)
  except ejcksExdBWOGwzKnrgIaypolFVRLfT as exception:
   ejcksExdBWOGwzKnrgIaypolFVRLfP(exception)
   return[]
  return search_list
 def Get_Search_List2(self,search_key):
  search_list=[]
  try:
   url ='{}/{}/search'.format(self.API_DOMAIN_NEW,self.API_VERSION_NEW)
   headers=self.Make_Headers(accessToken=ejcksExdBWOGwzKnrgIaypolFVRLfh,Bearer=ejcksExdBWOGwzKnrgIaypolFVRLfh)
   params ={'query':search_key,}
   response=self.HttpObj.Call_Request(url,headers=headers,params=params,method='GET')
   if response.status_code not in[200,201]:return[]
   resJson=response.json().get('data').get('page').get('containers')
   for i_item in resJson[0]['items']:
    image=i_item['visuals']['artwork']['standard']
    fanart =self.Get_imageurl_parser2(image,['background_details','background'],['1.78','0.71'])
    thumb =self.Get_imageurl_parser2(image,['thumbnail','background_details','background'],['1.78','0.71'])
    poster =self.Get_imageurl_parser2(image,['tile'],['0.71','1.78'])
    clearlogo=self.Get_imageurl_parser2(image,['title_treatment'],['1.78','0.71'])
    temp_list={'title':i_item['visuals']['title'],'entityId':i_item['actions'][0]['pageId'],'vType':'movie' if 'durationMs' in i_item['visuals']else 'tvshow','duration':ejcksExdBWOGwzKnrgIaypolFVRLfA(i_item['visuals']['durationMs']/1000)if 'durationMs' in i_item['visuals']else 0,'desc':i_item['visuals']['description']['full'],'year':i_item['visuals']['metastringParts']['releaseYearRange']['startYear'],'poster':poster,'thumb':thumb,'clearlogo':clearlogo,'fanart':fanart,}
    search_list.append(temp_list)
  except ejcksExdBWOGwzKnrgIaypolFVRLfT as exception:
   ejcksExdBWOGwzKnrgIaypolFVRLfP(exception)
   return[]
  return search_list
 def Get_Season_List(self,programId):
  season_list=[]
  try:
   url =self.Make_Endpoint('SEASON_LIST',encodedSeriesId=programId)
   response=self.HttpObj.Call_Request(url,headers=ejcksExdBWOGwzKnrgIaypolFVRLfb,method='GET')
   if response.status_code not in[200,201]:return ejcksExdBWOGwzKnrgIaypolFVRLfm
   resJson=response.json().get('data').get('DmcSeriesBundle')
   desc =resJson['series']['text']['description']['full']['series']['default']['content']
   poster=resJson['series']['image']['tile']['0.71']['series']['default']['url']
   for i_item in resJson.get('seasons').get('seasons'):
    seasonId =i_item.get('seasonId')
    seasonNum =i_item.get('seasonSequenceNumber')
    year =i_item.get('releases')[0].get('releaseYear')if 'releases' in i_item else ''
    aired =i_item.get('releases')[0].get('releaseDate')if 'releases' in i_item else ''
    episodeCnt=i_item.get('episodes_meta').get('hits')
    temp_list={'seasonId':seasonId,'seasonNum':seasonNum,'episodeCnt':episodeCnt,'year':year,'aired':aired,'desc':desc,'poster':poster+'/scale?width=400&aspectRatio=0.75',}
    season_list.append(temp_list)
  except ejcksExdBWOGwzKnrgIaypolFVRLfT as exception:
   ejcksExdBWOGwzKnrgIaypolFVRLfP(exception)
   return[]
  return season_list
 def Get_Season_List2(self,entityId):
  season_list=[]
  try:
   url ='{}/{}/page/{}'.format(self.API_DOMAIN_NEW,self.API_VERSION_NEW,entityId)
   headers=self.Make_Headers(accessToken=ejcksExdBWOGwzKnrgIaypolFVRLfh,Bearer=ejcksExdBWOGwzKnrgIaypolFVRLfh)
   params ={'disableSmartFocus':ejcksExdBWOGwzKnrgIaypolFVRLfh,'enhancedContainersLimit':15,'limit':15,}
   response=self.HttpObj.Call_Request(url,headers=headers,params=params,method='GET')
   if response.status_code not in[200,201]:return[]
   resJson=response.json()['data']['page']
   for iContainer in resJson['containers']:
    if iContainer.get('type')=='episodes':
     seasonsJson=iContainer
   detailsJson=resJson['visuals']
   desc=detailsJson['description']['full']
   imageJson=detailsJson['artwork']['standard']
   poster =self.Get_imageurl_parser2(imageJson,['tile'],['0.75','0.71','0.67'])
   for iSeason in seasonsJson.get('seasons'):
    temp_list={'seasonId':iSeason['id'],'seasonNum':iSeason['visuals']['name'],'episodeCnt':iSeason['pagination']['totalCount'],'desc':desc,'poster':poster,}
    season_list.append(temp_list)
  except ejcksExdBWOGwzKnrgIaypolFVRLfT as exception:
   ejcksExdBWOGwzKnrgIaypolFVRLfP(exception)
   return[]
  return season_list
 def Get_Episode_List(self,seasonId,page_int):
  episode_list=[]
  more_page =ejcksExdBWOGwzKnrgIaypolFVRLfm
  try:
   url =self.Make_Endpoint('EPISODE_LIST',seasonId=seasonId,pageSize=ejcksExdBWOGwzKnrgIaypolFVRLfN(self.ONE_PAGE),page=ejcksExdBWOGwzKnrgIaypolFVRLfN(page_int))
   response=self.HttpObj.Call_Request(url,headers=ejcksExdBWOGwzKnrgIaypolFVRLfb,method='GET')
   if response.status_code not in[200,201]:return ejcksExdBWOGwzKnrgIaypolFVRLfm
   resJson=response.json().get('data').get('DmcEpisodes')
   for i_item in resJson.get('videos'):
    contentId =i_item.get('contentId')
    title =i_item.get('text').get('title').get('full').get('program').get('default').get('content')
    tvshowtitle=i_item.get('text').get('title').get('full').get('series').get('default').get('content')
    desc =i_item.get('text').get('description').get('full').get('program').get('default').get('content')
    duration =ejcksExdBWOGwzKnrgIaypolFVRLfA(i_item.get('mediaMetadata').get('runtimeMillis')/1000)
    year =i_item.get('releases')[0].get('releaseYear')if 'releases' in i_item else ''
    aired =i_item.get('releases')[0].get('releaseDate')if 'releases' in i_item else ''
    seasonNum =i_item.get('seasonSequenceNumber')
    episodeNum =i_item.get('episodeSequenceNumber')
    encodedId =i_item.get('encodedSeriesId')
    fanart =self.Get_imageurl_parser(i_item.get('image'),['background_details','background'],['1.78','0.71'],'series')
    thumb =self.Get_imageurl_parser(i_item.get('image'),['thumbnail','background_details','background'],['1.78','0.71'],'program')
    poster =self.Get_imageurl_parser(i_item.get('image'),['tile'],['0.71','1.78'],'series')
    clearlogo=self.Get_imageurl_parser(i_item.get('image'),['title_treatment'],['1.78','0.71'],'series')
    temp_list={'contentId':contentId,'title':title,'tvshowtitle':tvshowtitle,'desc':desc,'duration':duration,'year':year,'aired':aired,'seasonNum':seasonNum,'episodeNum':episodeNum,'encodedId':encodedId,'fanart':fanart+'/scale?width=800&aspectRatio=1.78','thumb':thumb+'/scale?width=800&aspectRatio=1.78','poster':poster+'/scale?width=400&aspectRatio=0.71','clearlogo':clearlogo+'/scale?width=200&aspectRatio=1.78',}
    episode_list.append(temp_list)
   if resJson.get('meta').get('hits')>self.ONE_PAGE*(page_int):more_page=ejcksExdBWOGwzKnrgIaypolFVRLfh
  except ejcksExdBWOGwzKnrgIaypolFVRLfT as exception:
   ejcksExdBWOGwzKnrgIaypolFVRLfP(exception)
   return[],ejcksExdBWOGwzKnrgIaypolFVRLfm
  return episode_list,more_page
 def Get_Episode_List2(self,seasonId,page_int):
  episode_list=[]
  more_page =ejcksExdBWOGwzKnrgIaypolFVRLfm
  try:
   url ='{}/{}/season/{}'.format(self.API_DOMAIN_NEW,self.API_VERSION_NEW,seasonId)
   headers=self.Make_Headers(accessToken=ejcksExdBWOGwzKnrgIaypolFVRLfh,Bearer=ejcksExdBWOGwzKnrgIaypolFVRLfh)
   params ={'limit':self.ONE_PAGE,'offset':(page_int-1)*self.ONE_PAGE,}
   response=self.HttpObj.Call_Request(url,headers=headers,params=params,method='GET')
   if response.status_code not in[200,201]:return[],ejcksExdBWOGwzKnrgIaypolFVRLfm
   resJson=response.json()['data']['season']
   for i_item in resJson.get('items'):
    contentId =i_item['actions'][0]['partnerFeed']['dmcContentId']
    title =i_item['visuals']['episodeTitle']
    tvshowtitle=i_item['visuals']['title']
    desc =i_item['visuals']['description']['full']
    duration =ejcksExdBWOGwzKnrgIaypolFVRLfA(i_item['visuals']['durationMs']/1000)
    seasonNum =i_item['visuals']['seasonNumber']
    episodeNum =i_item['visuals']['episodeNumber']
    imageJson=i_item['visuals']['artwork']['standard']
    fanart =self.Get_imageurl_parser2(imageJson,['thumbnail','background','tile'],['1.78','1.33'])
    thumb =self.Get_imageurl_parser2(imageJson,['tile'],['1.78','1.33'])
    poster =self.Get_imageurl_parser2(imageJson,['tile'],['0.75','0.71','0.67'])
    clearlogo=self.Get_imageurl_parser2(imageJson,['title_treatment'],['1.78'])
    temp_list={'contentId':contentId,'title':title,'tvshowtitle':tvshowtitle,'desc':desc,'duration':duration,'seasonNum':seasonNum,'episodeNum':episodeNum,'fanart':fanart,'thumb':thumb,'poster':poster,'clearlogo':clearlogo,}
    episode_list.append(temp_list)
   more_page=resJson['pagination']['hasMore']
  except ejcksExdBWOGwzKnrgIaypolFVRLfT as exception:
   ejcksExdBWOGwzKnrgIaypolFVRLfP(exception)
   return[],ejcksExdBWOGwzKnrgIaypolFVRLfm
  return episode_list,more_page
 def GetStreamingURL(self,contentId,playOption):
  streamInfo={'streamUrl':'','drmUrl':'','defaultAudio':'',}
  try:
   url =self.Make_Endpoint('STREAMING_URL',contentId=contentId)
   headers =self.Make_Headers(accessToken=ejcksExdBWOGwzKnrgIaypolFVRLfh,Bearer=ejcksExdBWOGwzKnrgIaypolFVRLfh)
   response=self.HttpObj.Call_Request(url,headers=headers,method='GET')
   if response.status_code not in[200,201]:return streamInfo
   resJson =response.json()['data']['DmcVideo']['video']
   playbackURL=resJson['mediaMetadata']['playbackUrls'][0]['href']
   scenario='restricted-drm-ctr-sw' 
   if playOption.get('wv_secure')and playOption.get('video_h265'):
    scenario='tv-drm-ctr' 
    scenario+='-h265'
    if playOption.get('video_hdr'):
     scenario+='-hdr10'
    elif playOption.get('video_dolby'):
     scenario+='-dovi'
    if playOption.get('sound_atmos'):
     scenario+='-atmos'
   playbackURL=playbackURL.format(scenario=scenario)
   streamInfo['defaultAudio']=resJson['originalLanguage']or 'en'
   headers =self.Make_Headers(accessToken=ejcksExdBWOGwzKnrgIaypolFVRLfh,Bearer=ejcksExdBWOGwzKnrgIaypolFVRLfm)
   headers['accept']='application/vnd.media-service+json; version=5'
   headers['x-dss-feature-filtering']='true'
   response=self.HttpObj.Call_Request(playbackURL,headers=headers,method='GET')
   if response.status_code not in[200,201]:
    if response.status_code==403:
     streamInfo['drmUrl']=response.json()['errors'][0]['code']
    return streamInfo
   streamInfo['streamUrl'] =response.json()['stream']['complete'][0]['url']
   streamInfo['drmUrl'] =self.DZ['services']['drm']['widevineLicense']['href']
  except ejcksExdBWOGwzKnrgIaypolFVRLfT as exception:
   ejcksExdBWOGwzKnrgIaypolFVRLfP(exception)
   return streamInfo
  self.Disney_Parse_Main(streamInfo['streamUrl'],streamInfo['defaultAudio'],playOption)
  return streamInfo
 def Get_BaseUrl(self,in_url):
  parseResult=urllib.parse.urlparse(in_url) 
  scheme =parseResult.scheme
  netloc =parseResult.netloc
  full_path=parseResult.path.strip('/').split('/')
  full_path.pop(ejcksExdBWOGwzKnrgIaypolFVRLfY(full_path)-1)
  baseUrl =scheme+'://'+netloc+'/'+'/'.join(full_path)+'/'
  return baseUrl
 def VTT_FileList(self,vtt_url):
  file_list=[]
  response=requests.get(vtt_url)
  m3u8_data=response.content.decode('utf-8')
  skipTag=ejcksExdBWOGwzKnrgIaypolFVRLfm
  for nowln in m3u8_data.splitlines():
   if nowln.endswith('.vtt'):
    if skipTag:
     skipTag=ejcksExdBWOGwzKnrgIaypolFVRLfm
    else:
     file_list.append(nowln)
  return file_list
 def VTT_Detail(self,sub_url,vttDelay):
  subtitle=''
  response=requests.get(sub_url)
  vtt_data=response.content.decode('utf-8')
  SUB_START=ejcksExdBWOGwzKnrgIaypolFVRLfm
  tm_delay=datetime.timedelta(seconds=vttDelay)
  for nowln in vtt_data.splitlines():
   line=re.match('\d\d:\d\d:\d\d.\d\d\d',nowln)
   if line:
    SUB_START=ejcksExdBWOGwzKnrgIaypolFVRLfh
    if vttDelay==0.0:
     subtitle+=nowln[0:29]+'\n'
    else:
     starttm=self.Timedelta_To_Str(self.Str_To_Timedelta(nowln[0:12])+tm_delay)
     endtm =self.Timedelta_To_Str(self.Str_To_Timedelta(nowln[17:29])+tm_delay)
     subtitle+='{} --> {}\n'.format(starttm,endtm)
   elif nowln!='' and SUB_START==ejcksExdBWOGwzKnrgIaypolFVRLfh:
    subtitle+=nowln+'\n'
   elif nowln=='' and SUB_START==ejcksExdBWOGwzKnrgIaypolFVRLfh:
    SUB_START=ejcksExdBWOGwzKnrgIaypolFVRLfm
    subtitle+='\n'
  return subtitle
 def Str_To_Timedelta(self,in_tm):
  hours =ejcksExdBWOGwzKnrgIaypolFVRLfA(in_tm[0:2])
  minutes =ejcksExdBWOGwzKnrgIaypolFVRLfA(in_tm[3:5])
  seconds =ejcksExdBWOGwzKnrgIaypolFVRLfA(in_tm[6:8])
  milliseconds=ejcksExdBWOGwzKnrgIaypolFVRLfA(in_tm[-3:])
  return datetime.timedelta(hours=hours,minutes=minutes,seconds=seconds,milliseconds=milliseconds)
 def Timedelta_To_Str(self,tm_delta):
  seconds =tm_delta.seconds
  hours ,seconds=ejcksExdBWOGwzKnrgIaypolFVRLfD(seconds,3600)
  minutes,seconds=ejcksExdBWOGwzKnrgIaypolFVRLfD(seconds,60)
  milliseconds =ejcksExdBWOGwzKnrgIaypolFVRLfA(tm_delta.microseconds/1000)
  return '{:0>2}:{:0>2}:{:0>2}.{:0<3}'.format(hours,minutes,seconds,milliseconds)
 def Check_DelayTime(self,vod_url):
  delay_time=0.0
  response=requests.get(vod_url)
  vod_data=response.content.decode('utf-8')
  max_count=10
  for nowln in vod_data.splitlines():
   max_count-=1
   if max_count==0:break
   if nowln.startswith('#EXT-X-DATERANGE'):
    attribs=self.Disney_MediaLine_Parse(nowln,'#EXT-X-DATERANGE')
    if 'DURATION' in attribs: 
     if ejcksExdBWOGwzKnrgIaypolFVRLfX(attribs['DURATION'])<10.0:
      delay_time=ejcksExdBWOGwzKnrgIaypolFVRLfX(attribs['DURATION'])
     break 
  return delay_time
 def Disney_MediaLine_Parse(self,line,prefix):
  attribs={}
  for row in ATTRIBUTE_PATTERN.split(line.replace(prefix+':',''))[1::2]:
   name,value=row.split('=',1)
   attribs[name.upper()]=value.replace('"','').strip()
  return attribs
 def VTT_Make_Main(self,vtt_url,vttDelay):
  try:
   BASE_URL=self.Get_BaseUrl(vtt_url)
   vtt_filelist=self.VTT_FileList(vtt_url)
   f=ejcksExdBWOGwzKnrgIaypolFVRLfC(self.DZ_VTT_FILENAME,'w',-1,'utf-8')
   f.write('WEBVTT\n\n')
   for i_file in vtt_filelist:
    f.write(self.VTT_Detail(sub_url=BASE_URL+i_file,vttDelay=vttDelay))
   f.close()
  except:
   if os.path.isfile(self.DZ_VTT_FILENAME): 
    os.remove(self.DZ_VTT_FILENAME)
   return ejcksExdBWOGwzKnrgIaypolFVRLfm
  return ejcksExdBWOGwzKnrgIaypolFVRLfh
 def Disney_Parse_Main(self,stream_url,defaultAudio,playOption):
  vttDelay=0.0
  response=requests.get(url=stream_url)
  m3u8 =response.content.decode('utf-8')
  BASE_URL=self.Get_BaseUrl(stream_url)
  self.Disney_Parse_m3u8(m3u8,defaultAudio,playOption)
  delay_check =ejcksExdBWOGwzKnrgIaypolFVRLfm
  for line in m3u8.splitlines():
   if delay_check==ejcksExdBWOGwzKnrgIaypolFVRLfh:
    delay_check=ejcksExdBWOGwzKnrgIaypolFVRLfm
    vod_url =BASE_URL+line
    vttDelay=0
    if playOption.get('play_resume')==ejcksExdBWOGwzKnrgIaypolFVRLfm:
     vttDelay=self.Check_DelayTime(vod_url)
    break 
   elif line.startswith('#EXT-X-STREAM-INF'):
    delay_check=ejcksExdBWOGwzKnrgIaypolFVRLfh
  for line in m3u8.splitlines():
   if line.startswith('#EXT-X-MEDIA'):
    attribs=self.Disney_MediaLine_Parse(line,'#EXT-X-MEDIA')
    if attribs.get('TYPE')=='SUBTITLES' and attribs.get('FORCED')!='YES' and attribs.get('LANGUAGE')=='ko':
     return self.VTT_Make_Main(BASE_URL+attribs.get('URI'),vttDelay)
  return ejcksExdBWOGwzKnrgIaypolFVRLfh
 def Disney_Parse_m3u8(self,m3u8,defaultAudio,playOption):
  try:
   exists_aac =ejcksExdBWOGwzKnrgIaypolFVRLfm
   exists_dd =ejcksExdBWOGwzKnrgIaypolFVRLfm
   exists_atoms=ejcksExdBWOGwzKnrgIaypolFVRLfm
   max_res =0
   max_resStr =''
   for line in m3u8.splitlines():
    if line.startswith('#EXT-X-MEDIA'):
     attribs=self.Disney_MediaLine_Parse(line,'#EXT-X-MEDIA')
     if attribs.get('GROUP-ID')in['aac-128k','aac-64k']:exists_aac =ejcksExdBWOGwzKnrgIaypolFVRLfh
     elif attribs.get('GROUP-ID')in['eac-3']:exists_dd =ejcksExdBWOGwzKnrgIaypolFVRLfh
     elif attribs.get('GROUP-ID')in['atmos']:exists_atoms=ejcksExdBWOGwzKnrgIaypolFVRLfh
    elif line.startswith('#EXT-X-STREAM-INF'):
     attribs=self.Disney_MediaLine_Parse(line,'#EXT-X-STREAM-INF')
     i_resolution=ejcksExdBWOGwzKnrgIaypolFVRLfA(attribs.get('RESOLUTION').split('x',1)[0])
     if i_resolution<=playOption['maxResolution']and i_resolution>max_res:
      max_res =i_resolution
      max_resStr=attribs.get('RESOLUTION')
   if exists_atoms==ejcksExdBWOGwzKnrgIaypolFVRLfm and playOption['sound_atmos']==ejcksExdBWOGwzKnrgIaypolFVRLfh:
    playOption['sound_dd']=ejcksExdBWOGwzKnrgIaypolFVRLfh
   if exists_atoms==ejcksExdBWOGwzKnrgIaypolFVRLfm and exists_dd==ejcksExdBWOGwzKnrgIaypolFVRLfm and playOption['sound_dd']==ejcksExdBWOGwzKnrgIaypolFVRLfh:
    playOption['sound_aac']=ejcksExdBWOGwzKnrgIaypolFVRLfh
  except ejcksExdBWOGwzKnrgIaypolFVRLfT as exception:
   ejcksExdBWOGwzKnrgIaypolFVRLfP(exception)
   pass
  Remove_AudioList=[]
  if not playOption['sound_aac']:
   Remove_AudioList.append('aac-128k')
   Remove_AudioList.append('aac-64k')
  if not playOption['sound_dd']:
   Remove_AudioList.append('eac-3')
  if not playOption['sound_atmos']:
   Remove_AudioList.append('atmos')
  res_lines=[]
  try:
   Skip_NextLine=ejcksExdBWOGwzKnrgIaypolFVRLfm
   Before_Blank =ejcksExdBWOGwzKnrgIaypolFVRLfm
   for line in m3u8.splitlines():
    if not line.strip():
     if Before_Blank==ejcksExdBWOGwzKnrgIaypolFVRLfm:
      res_lines.append(line)
      Before_Blank=ejcksExdBWOGwzKnrgIaypolFVRLfh
     continue
    else:
     Before_Blank =ejcksExdBWOGwzKnrgIaypolFVRLfm
    if Skip_NextLine==ejcksExdBWOGwzKnrgIaypolFVRLfh:
     Skip_NextLine=ejcksExdBWOGwzKnrgIaypolFVRLfm
     continue
    if line.startswith('#EXT-X-MEDIA'):
     attribs=self.Disney_MediaLine_Parse(line,'#EXT-X-MEDIA')
     if attribs.get('TYPE')=='AUDIO':
      if attribs.get('LANGUAGE')not in['ko','en',defaultAudio]:
       continue
      if attribs.get('GROUP-ID')in Remove_AudioList:
       continue
      if 'JOC' in attribs.get('CHANNELS'):
       line=line.replace('NAME="{}"'.format(attribs.get('NAME')),'NAME="{} [Atmos]"'.format(attribs.get('NAME')))
       line=line.replace('CHANNELS="{}"'.format(attribs.get('CHANNELS')),'CHANNELS="{}"'.format(attribs.get('CHANNELS').split('/')[0]))
     elif attribs.get('TYPE')=='SUBTITLES':
      continue
    elif line.startswith('#EXT-X-STREAM-INF'):
     attribs=self.Disney_MediaLine_Parse(line,'#EXT-X-STREAM-INF')
     if attribs.get('AUDIO')in Remove_AudioList:
      Skip_NextLine=ejcksExdBWOGwzKnrgIaypolFVRLfh
      continue
     if attribs.get('RESOLUTION')!=max_resStr and playOption['maxResolution']:
      Skip_NextLine=ejcksExdBWOGwzKnrgIaypolFVRLfh
      continue
    res_lines.append(line)
  except ejcksExdBWOGwzKnrgIaypolFVRLfT as exception:
   ejcksExdBWOGwzKnrgIaypolFVRLfP(exception)
   return ejcksExdBWOGwzKnrgIaypolFVRLfb
  return_value='\n'.join(res_lines)
  try:
   fp=ejcksExdBWOGwzKnrgIaypolFVRLfC(self.DZ_M3U8_FILENAME,'w',-1,'utf-8')
   fp.write(return_value)
   fp.close()
  except:
   if os.path.isfile(self.DZ_M3U8_FILENAME): 
    os.remove(self.DZ_M3U8_FILENAME)
   return ejcksExdBWOGwzKnrgIaypolFVRLfm
 def DecodedFamilyId(self,familyId):
  url =self.Make_Endpoint('VIDEO_BUNDLE',encodedFamilyId=familyId)
  response=self.HttpObj.Call_Request(url,params=ejcksExdBWOGwzKnrgIaypolFVRLfb,headers=ejcksExdBWOGwzKnrgIaypolFVRLfb,method='GET')
  if response.status_code!=200:return ejcksExdBWOGwzKnrgIaypolFVRLfb
  resJson=response.json().get('data').get('DmcVideoBundle').get('video')
  return resJson.get('contentId')
 def GetBookmarkInfo(self,videoid,vidtype):
  VIDEO_INFO={'indexinfo':{'ott':'disney','videoid':videoid,'vidtype':vidtype,'encodedId':'','contentId':'','contentClass':'','contentSlugs':'',},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vidtype=='collection':
   VIDEO_INFO['indexinfo']['vidtype'] ='tvshow'
   VIDEO_INFO['saveinfo']['infoLabels']['mediatype']='tvshow'
   VIDEO_INFO['saveinfo']['infoLabels']['genre']=['collection']
   return VIDEO_INFO
  genre_list=JsonFile_Load(self.DZ_GENRE_FILENAME)
  if vidtype=='movie':
   url =self.Make_Endpoint('VIDEO_BUNDLE',encodedFamilyId=videoid)
  elif vidtype=='tvshow':
   url =self.Make_Endpoint('SEASON_LIST',encodedSeriesId=videoid)
  response=self.HttpObj.Call_Request(url,params=ejcksExdBWOGwzKnrgIaypolFVRLfb,headers=ejcksExdBWOGwzKnrgIaypolFVRLfb,method='GET')
  if response.status_code!=200:return ejcksExdBWOGwzKnrgIaypolFVRLfb
  if vidtype=='movie':
   resJson=response.json().get('data').get('DmcVideoBundle').get('video')
   VIDEO_INFO['indexinfo']['contentId']=resJson.get('contentId')
   tmp_title=resJson.get('text').get('title').get('full').get('program').get('default').get('content')
   tmp_year =resJson.get('releases')[0].get('releaseYear')
   VIDEO_INFO['saveinfo']['infoLabels']['title']=tmp_title
   tmp_title='%s  (%s)'%(tmp_title,tmp_year)
   VIDEO_INFO['saveinfo']['title'] =tmp_title
   VIDEO_INFO['saveinfo']['infoLabels']['year']=tmp_year
   VIDEO_INFO['saveinfo']['infoLabels']['plot']=resJson.get('text').get('description').get('full').get('program').get('default').get('content')
   VIDEO_INFO['saveinfo']['infoLabels']['mpaa']=resJson.get('ratings')[0].get('value')
   VIDEO_INFO['saveinfo']['infoLabels']['duration']=ejcksExdBWOGwzKnrgIaypolFVRLfA(resJson.get('mediaMetadata').get('runtimeMillis')/1000)
   VIDEO_INFO['saveinfo']['infoLabels']['premiered']=resJson.get('releases')[0].get('releaseDate')
  elif vidtype=='tvshow':
   resJson=response.json().get('data').get('DmcSeriesBundle').get('series')
   VIDEO_INFO['indexinfo']['encodedId']=resJson.get('encodedSeriesId')
   tmp_title=resJson.get('text').get('title').get('full').get('series').get('default').get('content')
   tmp_year =resJson.get('releases')[0].get('releaseYear')
   VIDEO_INFO['saveinfo']['infoLabels']['title']=tmp_title
   VIDEO_INFO['saveinfo']['title'] =tmp_title
   VIDEO_INFO['saveinfo']['infoLabels']['year']=tmp_year
   VIDEO_INFO['saveinfo']['infoLabels']['plot']=resJson.get('text').get('description').get('full').get('series').get('default').get('content')
   VIDEO_INFO['saveinfo']['infoLabels']['mpaa']=resJson.get('ratings')[0].get('value')
   VIDEO_INFO['saveinfo']['infoLabels']['premiered']=resJson.get('releases')[0].get('releaseDate')
  if vidtype=='movie':
   tmp_poster =resJson.get('image').get('tile').get('0.71').get('program').get('default').get('url')
   if 'title_treatment_centered' in resJson.get('image'):
    tmp_clearlogo=resJson.get('image').get('title_treatment_centered').get('1.78').get('program').get('default').get('url')
   else:
    if '1.78' in resJson.get('image').get('title_treatment'):
     tmp_clearlogo=resJson.get('image').get('title_treatment').get('1.78').get('program').get('default').get('url')
    else:
     tmp_clearlogo=resJson.get('image').get('title_treatment').get('3.32').get('program').get('default').get('url')
   if 'background_details' in resJson.get('image'):
    tmp_thumb =resJson.get('image').get('background_details').get('1.78').get('program').get('default').get('url')
   else:
    tmp_thumb =resJson.get('image').get('background').get('1.78').get('program').get('default').get('url')
   VIDEO_INFO['saveinfo']['thumbnail']['poster']=tmp_poster
   VIDEO_INFO['saveinfo']['thumbnail']['thumb']=tmp_thumb
   VIDEO_INFO['saveinfo']['thumbnail']['clearlogo']=tmp_clearlogo
   for i_genre in resJson.get('typedGenres'):
    VIDEO_INFO['saveinfo']['infoLabels']['genre'].append(genre_list.get(i_genre.get('partnerId'))or i_genre.get('name'))
   if resJson.get('participant'):
    for i_director in resJson.get('participant').get('Director'):
     VIDEO_INFO['saveinfo']['infoLabels']['director'].append(i_director.get('displayName'))
   if 'Actor' in resJson.get('participant'):
    for i_cast in resJson.get('participant').get('Actor'):
     VIDEO_INFO['saveinfo']['infoLabels']['cast'].append(i_cast.get('displayName'))
  elif vidtype=='tvshow':
   tmp_poster =resJson.get('image').get('tile').get('0.71').get('series').get('default').get('url')
   if 'title_treatment_centered' in resJson.get('image'):
    tmp_clearlogo=resJson.get('image').get('title_treatment_centered').get('1.78').get('series').get('default').get('url')
   else:
    if '1.78' in resJson.get('image').get('title_treatment'):
     tmp_clearlogo=resJson.get('image').get('title_treatment').get('1.78').get('series').get('default').get('url')
    else:
     tmp_clearlogo=resJson.get('image').get('title_treatment').get('3.32').get('series').get('default').get('url')
   if 'background_details' in resJson.get('image'):
    tmp_thumb =resJson.get('image').get('background_details').get('1.78').get('series').get('default').get('url')
   else:
    tmp_thumb =resJson.get('image').get('background').get('1.78').get('series').get('default').get('url')
   VIDEO_INFO['saveinfo']['thumbnail']['poster']=tmp_poster
   VIDEO_INFO['saveinfo']['thumbnail']['thumb']=tmp_thumb
   VIDEO_INFO['saveinfo']['thumbnail']['clearlogo']=tmp_clearlogo
   for i_genre in resJson.get('typedGenres'):
    VIDEO_INFO['saveinfo']['infoLabels']['genre'].append(genre_list.get(i_genre.get('partnerId'))or i_genre.get('name'))
   if 'Creator' in resJson.get('participant'):
    for i_director in resJson.get('participant').get('Creator'):
     VIDEO_INFO['saveinfo']['infoLabels']['director'].append(i_director.get('displayName'))
   elif 'Created By' in resJson.get('participant'):
    for i_director in resJson.get('participant').get('Created By'):
     VIDEO_INFO['saveinfo']['infoLabels']['director'].append(i_director.get('displayName'))
   if 'Actor' in resJson.get('participant'):
    for i_cast in resJson.get('participant').get('Actor'):
     VIDEO_INFO['saveinfo']['infoLabels']['cast'].append(i_cast.get('displayName'))
   VIDEO_INFO['saveinfo']['thumbnail']['poster']=VIDEO_INFO['saveinfo']['thumbnail']['poster']+'/scale?width=400&aspectRatio=0.71'
   VIDEO_INFO['saveinfo']['thumbnail']['thumb']=VIDEO_INFO['saveinfo']['thumbnail']['thumb']+'/scale?width=800&aspectRatio=1.78'
   VIDEO_INFO['saveinfo']['thumbnail']['clearlogo']=VIDEO_INFO['saveinfo']['thumbnail']['clearlogo']+'/scale?width=200&aspectRatio=1.78'
  return VIDEO_INFO
 def GetBookmarkInfo2(self,videoid,vidtype):
  VIDEO_INFO={'indexinfo':{'ott':'disney','videoid':videoid,'vidtype':vidtype,'entityId':'',},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  url ='{}/{}/page/{}'.format(self.API_DOMAIN_NEW,self.API_VERSION_NEW,videoid)
  headers=self.Make_Headers(accessToken=ejcksExdBWOGwzKnrgIaypolFVRLfh,Bearer=ejcksExdBWOGwzKnrgIaypolFVRLfh)
  params ={'disableSmartFocus':ejcksExdBWOGwzKnrgIaypolFVRLfh,'enhancedContainersLimit':15,'limit':15,}
  response=self.HttpObj.Call_Request(url,headers=headers,params=params,method='GET')
  if response.status_code not in[200,201]:return[]
  resJson=response.json().get('data').get('page')
  VIDEO_INFO['indexinfo']['entityId']=resJson.get('deeplinkId')
  tmp_title=resJson['visuals']['title']
  tmp_year =resJson['visuals']['metastringParts']['releaseYearRange']['startYear']
  VIDEO_INFO['saveinfo']['infoLabels']['title']=tmp_title
  if vidtype=='movie':
   tmp_title='%s (%s)'%(tmp_title,tmp_year)
  VIDEO_INFO['saveinfo']['title'] =tmp_title
  VIDEO_INFO['saveinfo']['infoLabels']['year']=tmp_year
  VIDEO_INFO['saveinfo']['infoLabels']['mpaa']=resJson['visuals']['metastringParts']['ratingInfo']['rating']['text']
  VIDEO_INFO['saveinfo']['infoLabels']['plot']=resJson['visuals']['description']['full']
  if vidtype=='movie':
   VIDEO_INFO['saveinfo']['infoLabels']['duration']=ejcksExdBWOGwzKnrgIaypolFVRLfA(resJson['visuals']['metastringParts']['runtime']['runtimeMs']/1000)
  for i_genre in resJson['visuals']['metastringParts']['genres']['values']:
   VIDEO_INFO['saveinfo']['infoLabels']['genre'].append(i_genre)
  for i_container in resJson['containers']:
   if i_container['type']!='details':continue
   for i_credit in i_container['visuals']['credits']:
    if i_credit['heading'].startswith('감독'):
     for i_item in i_credit['items']:
      VIDEO_INFO['saveinfo']['infoLabels']['director'].append(i_item['displayText'])
    if i_credit['heading'].startswith('출연'):
     for i_item in i_credit['items']:
      VIDEO_INFO['saveinfo']['infoLabels']['cast'].append(i_item['displayText'])
  imageJson=resJson['visuals']['artwork']['standard']
  poster =self.Get_imageurl_parser2(imageJson,['tile'],['0.75','0.71','0.67'])
  clearlogo=self.Get_imageurl_parser2(imageJson,['title_treatment'],['1.78'])
  thumb =self.Get_imageurl_parser2(imageJson,['tile'],['1.78','1.33'])
  fanart =self.Get_imageurl_parser2(imageJson,['background'],['1.78','1.33'])
  VIDEO_INFO['saveinfo']['thumbnail']['poster']=poster
  VIDEO_INFO['saveinfo']['thumbnail']['thumb']=thumb
  VIDEO_INFO['saveinfo']['thumbnail']['clearlogo']=clearlogo
  VIDEO_INFO['saveinfo']['thumbnail']['fanart'] =fanart
  return VIDEO_INFO
 def Get_DeepLink_PageId(self,pageType):
  pageId=''
  try:
   url ='{}/{}/deeplink?refId={}&refIdType=deeplinkId'.format(self.API_DOMAIN_NEW,self.API_VERSION_NEW,pageType)
   headers=self.Make_Headers(accessToken=ejcksExdBWOGwzKnrgIaypolFVRLfh,Bearer=ejcksExdBWOGwzKnrgIaypolFVRLfh)
   response=self.HttpObj.Call_Request(url,headers=headers,method='GET')
   if response.status_code not in[200,201]:return[]
   pageId=response.json().get('data').get('deeplink').get('actions')[0].get('pageId')
  except ejcksExdBWOGwzKnrgIaypolFVRLfT as exception:
   ejcksExdBWOGwzKnrgIaypolFVRLfP(exception)
   return ''
  return pageId
 def Get_Brand_List2(self):
  page_list=[]
  HomePageId =self.Get_DeepLink_PageId('home')
  BrandsPageId=''
  try:
   url ='{}/{}/page/{}?disableSmartFocus=true&enhancedContainersLimit=0&limit=15'.format(self.API_DOMAIN_NEW,self.API_VERSION_NEW,HomePageId)
   headers=self.Make_Headers(accessToken=ejcksExdBWOGwzKnrgIaypolFVRLfh,Bearer=ejcksExdBWOGwzKnrgIaypolFVRLfh)
   response=self.HttpObj.Call_Request(url,headers=headers,method='GET')
   if response.status_code not in[200,201]:return[]
   resJson=response.json()['data']['page']
   for iContainer in resJson.get('containers'):
    if iContainer['params']['setStyle']in['brand_6']:
     BrandsPageId=iContainer['id']
     break
  except ejcksExdBWOGwzKnrgIaypolFVRLfT as exception:
   ejcksExdBWOGwzKnrgIaypolFVRLfP(exception)
   return[]
  try:
   url ='{}/{}/set/{}'.format(self.API_DOMAIN_NEW,self.API_VERSION_NEW,BrandsPageId)
   headers=self.Make_Headers(accessToken=ejcksExdBWOGwzKnrgIaypolFVRLfh,Bearer=ejcksExdBWOGwzKnrgIaypolFVRLfh)
   params ={'limit':self.ONE_PAGE,'offset':0,}
   response=self.HttpObj.Call_Request(url,headers=headers,params=params,method='GET')
   if response.status_code not in[200,201]:return[]
   resJson=response.json()['data']['set']
   for iItem in resJson.get('items'):
    temp_list={'title':iItem['visuals']['title'],'pageId':iItem['id'],'image':self.Image_IdtoUrl(iItem['visuals']['artwork']['brand']['logo']['2.00']['imageId'])}
    page_list.append(temp_list)
  except ejcksExdBWOGwzKnrgIaypolFVRLfT as exception:
   ejcksExdBWOGwzKnrgIaypolFVRLfP(exception)
   return[]
  return page_list
 def Get_Catagory_Group(self,pageType):
  catagory_list=[]
  pageId=self.Get_DeepLink_PageId(pageType)
  ejcksExdBWOGwzKnrgIaypolFVRLfP('pageId : '+pageId)
  try:
   url ='{}/{}/page/{}'.format(self.API_DOMAIN_NEW,self.API_VERSION_NEW,pageId)
   headers=self.Make_Headers(accessToken=ejcksExdBWOGwzKnrgIaypolFVRLfh,Bearer=ejcksExdBWOGwzKnrgIaypolFVRLfh)
   params ={'limit':48,'disableSmartFocus':ejcksExdBWOGwzKnrgIaypolFVRLfh,'enhancedContainersLimit':0,}
   response=self.HttpObj.Call_Request(url,headers=headers,params=params,method='GET')
   if response.status_code not in[200,201]:return[]
   resJson=response.json()['data']['page']
   for iContainer in resJson.get('containers'):
    temp_list={'title':iContainer['visuals']['name'],'containerId':iContainer['id'],}
    catagory_list.append(temp_list)
  except ejcksExdBWOGwzKnrgIaypolFVRLfT as exception:
   ejcksExdBWOGwzKnrgIaypolFVRLfP(exception)
   return[]
  return catagory_list
 def Get_Container_List(self,pageType,pageId=''):
  container_list=[]
  if pageType=='brands':
   pageId='page-'+pageId 
  else:
   pageId=self.Get_DeepLink_PageId(pageType)
  try:
   url ='{}/{}/page/{}?disableSmartFocus=true&enhancedContainersLimit=0&limit=15'.format(self.API_DOMAIN_NEW,self.API_VERSION_NEW,pageId)
   headers=self.Make_Headers(accessToken=ejcksExdBWOGwzKnrgIaypolFVRLfh,Bearer=ejcksExdBWOGwzKnrgIaypolFVRLfh)
   response=self.HttpObj.Call_Request(url,headers=headers,method='GET')
   if response.status_code not in[200,201]:return[]
   resJson=response.json()['data']['page']
   for iContainer in resJson.get('containers'):
    if iContainer['params']['setStyle']in['hero_carousel','brand_6','hero_inline_single']:continue
    temp_list={'title':iContainer['visuals']['name'],'containerId':iContainer['id'],}
    container_list.append(temp_list)
  except ejcksExdBWOGwzKnrgIaypolFVRLfT as exception:
   ejcksExdBWOGwzKnrgIaypolFVRLfP(exception)
   return[]
  return container_list
 def Get_Program_List2(self,containerId,page_int):
  program_list=[]
  more_page =ejcksExdBWOGwzKnrgIaypolFVRLfm
  try:
   url ='{}/{}/set/{}'.format(self.API_DOMAIN_NEW,self.API_VERSION_NEW,containerId)
   headers=self.Make_Headers(accessToken=ejcksExdBWOGwzKnrgIaypolFVRLfh,Bearer=ejcksExdBWOGwzKnrgIaypolFVRLfh)
   params ={'limit':self.ONE_PAGE,'offset':(page_int-1)*self.ONE_PAGE,}
   response=self.HttpObj.Call_Request(url,headers=headers,params=params,method='GET')
   if response.status_code not in[200,201]:return[]
   resJson=response.json()['data']['set']
   for iItem in resJson.get('items'):
    if 'seasonNumber' in iItem['visuals']:
     vType='tvshow'
     duration=0
    elif 'durationMs' in iItem['visuals']:
     vType='movie'
     duration=ejcksExdBWOGwzKnrgIaypolFVRLfA(iItem['visuals']['durationMs']/1000)
    elif iItem['actions'][0]['pageId'].startswith('page-'):
     vType='collection'
     duration=0
    else:
     vType='tvshow'
     duration=0
    genre_list=[]
    year=0
    mpaa=''
    if 'metastringParts' in iItem['visuals']:
     if 'genres' in iItem['visuals']['metastringParts']:
      for igenre in iItem['visuals']['metastringParts']['genres']['values']:
       genre_list.append(igenre)
     if 'releaseYearRange' in iItem['visuals']['metastringParts']:
      year=iItem['visuals']['metastringParts']['releaseYearRange']['startYear']
      mpaa=iItem['visuals']['metastringParts']['ratingInfo']['rating']['text']
    desc=''
    if 'description' in iItem['visuals']:
     desc=iItem['visuals']['description']['full']
    imageJson=iItem['visuals']['artwork']['standard']
    poster =self.Get_imageurl_parser2(imageJson,['tile'],['0.75','0.71','0.67'])
    clearlogo=self.Get_imageurl_parser2(imageJson,['title_treatment'],['1.78'])
    thumb =self.Get_imageurl_parser2(imageJson,['tile'],['1.78','1.33'])
    fanart =self.Get_imageurl_parser2(imageJson,['background','tile'],['1.78','1.33'])
    temp_list={'title':iItem['visuals']['title'],'entityId':iItem['actions'][0]['pageId'],'vType':vType,'genre':genre_list,'synopsis':desc,'duration':duration,'mpaa':mpaa,'year':year,'thumbnail':{'poster':poster,'thumb':thumb,'clearlogo':clearlogo,'fanart':fanart},}
    program_list.append(temp_list)
   more_page=resJson['pagination']['hasMore']
  except ejcksExdBWOGwzKnrgIaypolFVRLfT as exception:
   ejcksExdBWOGwzKnrgIaypolFVRLfP(exception)
   return[],ejcksExdBWOGwzKnrgIaypolFVRLfm
  return program_list,more_page 
 def Image_IdtoUrl(self,imageId):
  imageServer='https://disney.images.edge.bamgrid.com'
  imageUrl ='{}/ripcut-delivery/v2/variant/disney/{}/compose'.format(imageServer,imageId)
  return imageUrl
 def entityId_to_contentId(self,entityId):
  contentId=''
  try:
   url ='{}/{}/page/{}'.format(self.API_DOMAIN_NEW,self.API_VERSION_NEW,entityId)
   headers=self.Make_Headers(accessToken=ejcksExdBWOGwzKnrgIaypolFVRLfh,Bearer=ejcksExdBWOGwzKnrgIaypolFVRLfh)
   params ={'disableSmartFocus':ejcksExdBWOGwzKnrgIaypolFVRLfh,'enhancedContainersLimit':self.ONE_PAGE,'limit':self.ONE_PAGE,}
   response=self.HttpObj.Call_Request(url,headers=headers,params=params,method='GET')
   if response.status_code not in[200,201]:return[]
   resJson=response.json()['data']['page']
   contentId=resJson['actions'][0]['partnerFeed']['dmcContentId']
  except ejcksExdBWOGwzKnrgIaypolFVRLfT as exception:
   ejcksExdBWOGwzKnrgIaypolFVRLfP(exception)
   return ''
  return contentId
# Created by pyminifier (https://github.com/liftoff/pyminifier)
