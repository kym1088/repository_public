import threading
from http.server import HTTPServer, BaseHTTPRequestHandler
import requests
import urllib
import json
import base64
import re
import os
import datetime
import time

REMOVE_IN_HEADERS  = ['proxy-mini','host','referer','upgrade'] #,'accept-encoding'] #,'content-length']
REMOVE_OUT_HEADERS = ['date','server','set-cookie','keep-alive','connection','transfer-encoding','content-encoding','content-length']
ATTRIBUTE_PATTERN  = re.compile(r'''((?:[^,"']|"[^"]*"|'[^']*')+)''')


class BoriProxyHandler( BaseHTTPRequestHandler ):

	def __init__(self, request, client_address, server):
		self.HTTP_CLIENT = requests.Session()
		self.REQ_INFO    = {}

		try:
		   BaseHTTPRequestHandler.__init__(self, request, client_address, server)
		except (IOError, OSError) as e:
			pass

	def log_message(self, format, *args):
		pass


	def Make_Header( self, header_exceptList=[] ):
		reqHeader = {}
		header_exceptList.extend( REMOVE_IN_HEADERS ) # 소문자

		for key, value in dict(self.headers).items():
			if key.lower() not in header_exceptList:
				reqHeader[key.lower()] = value
				#print( key.lower(), value )
		return reqHeader

	def Make_NewUrl( self, scheme, netloc, path, params='', query='', fragemnt='' ):
		new_url = ( scheme, netloc, path, params, query, fragemnt )
		return urllib.parse.urlunparse( new_url ) 

	def Send_BlankImage( self ):
		self.send_response( 200 )
		self.send_header( 'Content-Type', 'image/x-icon' )
		self.send_header( 'Content-Length', 0 )
		self.end_headers()

	def Send_ErrorPage( self ):
		self.send_response( 200 )
		self.send_header( 'Content-Type', 'text/html; charset=UTF-8' )
		self.end_headers()
		self.wfile.write( 'request error!'.encode('utf-8') )


	def Parse_BaseRequest( self ):
		self.REQ_INFO = {}

		try:
			self.REQ_INFO['url']   = self.path.strip('/') # path 전체
			proxyData = dict(self.headers).get('proxy-mini')
			if proxyData:
				self.REQ_INFO['addon'] = json.loads( base64.standard_b64decode( proxyData ).decode('utf-8') )
			else:
				self.REQ_INFO['addon'] = {}

			#print( self.REQ_INFO['url'] )
			print( self.REQ_INFO['addon'] )

			parseResult = urllib.parse.urlparse( self.REQ_INFO['url'] )  # scheme, netloc, path, params, query, fragment

			self.REQ_INFO['scheme']    = parseResult.scheme
			self.REQ_INFO['netloc']    = parseResult.netloc
			self.REQ_INFO['path']      = parseResult.path.strip('/').split('/')
			self.REQ_INFO['last_path'] = self.REQ_INFO['path'][len(self.REQ_INFO['path'])-1]
			self.REQ_INFO['path'].pop( len(self.REQ_INFO['path'])-1 ) # 마지막 제거 (경로 리스트)

			#self.REQ_INFO['params']    = #parseResult.params
			self.REQ_INFO['query']     = dict( urllib.parse.parse_qsl( parseResult.query ) ) 
			#self.REQ_INFO['fragment']  = parseResult.fragment

			lp_type = self.REQ_INFO['last_path'].split('.')
			self.REQ_INFO['last_type'] = lp_type[len(lp_type)-1] #확장자

			length = int(self.headers.get('content-length', 0))
			self.REQ_INFO['postData'] = self.rfile.read(length) if length else None

			#self.REQ_INFO['baseUrl'] = self.REQ_INFO['scheme'] + '://' + self.REQ_INFO['netloc'] + '/' + '/'.join(self.REQ_INFO['path']) + '/'

		except Exception as e:
			print(Exception)
			self.REQ_INFO = {}
			return False


		return True


	def Output_Headers( self, response ):
		self.send_response( response.status_code )

		for resHeader in list(response.headers.items()):
			self.send_header(resHeader[0], resHeader[1])
			#print(  resHeader[0], resHeader[1] )

		self.end_headers()


	def Output_Response( self, response, res_data=None, header_exceptList=[] ):
		# except header
		for resHeader in list(response.headers.items()):
			if resHeader[0].lower() in REMOVE_OUT_HEADERS or resHeader[0].lower() in header_exceptList:
				response.headers.pop(resHeader[0], None)
                
		if res_data:
			#zipStr = self._gzip( res_data.encode('utf-8') )
			#response.headers['content-encoding'] = 'gzip'
			zipStr = res_data.encode('utf-8')

			response.headers['content-length']   = str(len(zipStr))
			self.Output_Headers( response )
			self.wfile.write( zipStr )

		else:
			self.Output_Headers( response )
			
			for chunk in response.iter_content(1048576):
				try:
					self.wfile.write(chunk)
				except Exception as e:
					print( e )
					break


	def do_HEAD( self ):
		self.send_response(200)


	def do_POST( self ):
		if self.Parse_BaseRequest() == False:
			self.send_response( 404 )
			return 

		# requests URL
		try:
			#response = self.HTTP_CLIENT.post( url=reqParse['url'], headers=self.Make_Header(), data=reqParse['postData'], stream=True )
			response = requests.post( url=self.REQ_INFO['url'], headers=self.Make_Header(), data=self.REQ_INFO['postData'], stream=True )
		except Exception as exception:
			print(exception)
			self.Send_ErrorPage()
			return

		self.Output_Response( response, res_data=None, header_exceptList=[] )



	# http://127.0.0.1:9999/https://www.naver.com
	# http://127.0.0.1:52103/https://www.naver.com
	# http://127.0.0.1:9999/https://vod-spc-ap-north-2.media.dssott.com/ps01/disney/3939e7e3-99ab-4668-a867-00b783e1b05d/ctr-all-8f08b949-08dd-41ea-8fbe-1d37f945b9df-a7eaab44-ac86-4771-86cf-fcbe256a9374.m3u8?r=720&a=3&v=1&hash=aa4b5318d957012246fb7f650e074649d93dd279
	def do_GET( self ):

		if self.Parse_BaseRequest() == False:
			self.send_response( 404 )
			return 

		if self.REQ_INFO['last_path'].lower() == 'favicon.ico':
			self.Send_BlankImage() # 공백icon
			return 

		if self.REQ_INFO['scheme'].lower() not in ['http','https']:
			self.send_response( 404 )
			return 


		# requests URL
		try:
			#response = self.HTTP_CLIENT.get( url=reqParse['url'], headers=self.Make_Header(), stream=True )
			response = requests.get( url=self.REQ_INFO['url'], headers=self.Make_Header(), stream=True )
		except Exception as exception:
			print(exception)
			self.Send_ErrorPage()
			return

		#print( self.REQ_INFO )
		res_data = None
		if self.REQ_INFO['last_type'].lower() in ['m3u8'] and self.REQ_INFO.get('addon').get('addon') == 'disneym':
			#print( 'addon : disneym' )
			m3u8 = response.content.decode('utf-8')
			if '#EXTM3U' not in m3u8 :
				res_data = None 
			# master
			elif 'EXT-X-STREAM-INF' in m3u8:
				#res_data = self.Disney_Parse_m3u8( m3u8 ) # 미사용
				if os.path.isfile( self.REQ_INFO['addon']['playOption']['m3u8Filename']  ):
					try:
						fp = open(self.REQ_INFO['addon']['playOption']['m3u8Filename'], 'r', -1, 'utf-8')
						res_data = fp.read()
						fp.close()
					except:
						res_data = ''

			else:
				res_data = None 


		self.Output_Response( response, res_data, header_exceptList=[] )


	def Disney_MediaLine_Parse( self, line, prefix ):
		attribs = {}
		for row in ATTRIBUTE_PATTERN.split(line.replace(prefix+':', ''))[1::2]:
			name, value = row.split('=', 1)
			attribs[name.upper()] = value.replace('"','').strip()
		return attribs



	def _gzip( self, data=None ):
		from io import BytesIO
		from gzip import GzipFile
		out = BytesIO()
		f = GzipFile(fileobj=out, mode='w', compresslevel=5)
		f.write(data)
		f.close()
		return out.getvalue()





class DisneyProxy(object):
	def __init__( self ):
		self.started = False
		self.PORT = None

	def start(self):
		if self.started: return

		self._server = HTTPServer( ('0.0.0.0', self.PORT), BoriProxyHandler )
		#self._server.timeout = 10
		self._httpd_thread = threading.Thread(target=self._server.serve_forever)
		self._httpd_thread.start()
		self.started = True

	def stop(self):
		if not self.started: return

		self._server.shutdown()
		self._server.server_close()
		self._server.socket.close()
		self._httpd_thread.join()
		self.started = False



if __name__ == "__main__":
	TEST_PORT = 9999
	httpd = HTTPServer( ('0.0.0.0', TEST_PORT), BoriProxyHandler )
	print(f'Server running on port : {TEST_PORT}')
	httpd.serve_forever()
