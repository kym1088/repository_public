_BU='containerId'
_BT='SUBTITLES'
_BS='dmcContentId'
_BR='widevineLicense'
_BQ='videoRanges'
_BP='audioTypes'
_BO='resolution'
_BN='DOLBY_VISION'
_BM='video_dolby'
_BL='video_hdr'
_BK='wv_secure'
_BJ='supportsMultiCodecMaster'
_BI='playbackInitializationContext'
_BH='assetInsertionStrategy'
_BG='frameRates'
_BF='playbackId'
_BE='x-dss-feature-filtering'
_BD='application/vnd.media-service+json'
_BC='ctr-regular'
_BB='seasonNumber'
_BA='seasonNum'
_B9='{}/{}/page/{}?disableSmartFocus=true&enhancedContainersLimit=0&limit=15'
_B8='DEEP_LINK'
_B7='VIDEO_BUNDLE'
_B6='PROGRAM_LIST'
_B5='COLLECTION'
_B4='profileId'
_B3='switchProfile'
_B2='3-3 login start'
_B1='\n    mutation login($input: LoginInput!) {\n        login(login: $input) {\n            actionGrant\n            account {\n              activeProfile {\n                id\n              }\n              profiles {\n                id\n                attributes {\n                  isDefault\n                  parentalControls {\n                    isPinProtected\n                  }\n                }\n              }\n            }\n            activeSession {\n              isSubscriber\n            }\n            identity {\n              personalInfo {\n                dateOfBirth\n                gender\n              }\n              flows {\n                personalInfo {\n                  requiresCollection\n                  eligibleForCollection\n                }\n              }\n            }\n        }\n    }\n'
_B0='3-2 login start'
_A_='validateEmailOnOperations'
_Az='\n    query check($email: String!, $validateEmailOnOperations: ValidateEmailOnOperationsInput) {\n        check(email: $email, validateEmailOnOperations: $validateEmailOnOperations) {\n            operations\n            nextOperation\n            email {\n              isValid\n              validationFailureCodes\n              suggestions {\n                domain\n              }\n            }\n        }\n    }\n'
_Ay='3-1 login start'
_Ax='regionCode'
_Aw='624b805dafc5c73635b1a216'
_Av='x-request-yp-id'
_Au='sdkAppVersion'
_At='%s-%s-%s-%s-%s'
_As='displayText'
_Ar='genres'
_Aq='ratingInfo'
_Ap='genre'
_Ao='contentId'
_An='deeplink'
_Am='video'
_Al='pagination'
_Ak='startYear'
_Aj='tvshow'
_Ai='imageId'
_Ah='PLAYER_EXPERIENCE'
_Ag='STREAMING_URL'
_Af='operations'
_Ae='profiles'
_Ad='media'
_Ac='sdkVersion'
_Ab='browser'
_Aa='clientApiKey'
_AZ='version'
_AY='sound_atmos'
_AX='codecs'
_AW='video_h265'
_AV='targetLanguage'
_AU='originalLanguage'
_AT='drmUrl'
_AS='0.67'
_AR='0.75'
_AQ='enhancedContainersLimit'
_AP='disableSmartFocus'
_AO='{}/{}/page/{}'
_AN='releaseYearRange'
_AM='movie'
_AL='year'
_AK='entityId'
_AJ='title_treatment'
_AI='type'
_AH='login'
_AG='email'
_AF='device'
_AE='deviceId'
_AD='explore'
_AC='clientId'
_AB='user-agent'
_AA='#EXT-X-STREAM-INF'
_A9='fanart'
_A8='clearlogo'
_A7='thumb'
_A6='duration'
_A5='background'
_A4='standard'
_A3='items'
_A2='name'
_A1='#EXT-X-MEDIA'
_A0='1.33'
_z='availId'
_y='resourceId'
_x='limit'
_w='durationMs'
_v='poster'
_u='full'
_t='artwork'
_s='pageId'
_r='profile'
_q='page'
_p='token_limit'
_o='playerExperience'
_n='thumbnail'
_m='0.71'
_l='session'
_k='input'
_j='operationName'
_i='description'
_h='orchestration'
_g='containers'
_f='sessionId'
_e='content'
_d='defaultAudio'
_c='streamUrl'
_b='tile'
_a='playback'
_Z='variables'
_Y='metastringParts'
_X='attributes'
_W='1.78'
_V='POST'
_U='utf-8'
_T='id'
_S='accessTokenType'
_R='title'
_Q='accessToken'
_P=None
_O='actions'
_N='refreshToken'
_M='href'
_L='query'
_K='headers'
_J='GET'
_I='token'
_H='services'
_G='extensions'
_F='data'
_E='sdk'
_D='visuals'
_C='account'
_B=True
_A=False
__author__='NightRain'
import re,random
try:from Cryptodome.Cipher import PKCS1_OAEP,AES;from Cryptodome.Util import Padding;print('Cryptodome')
except ImportError:from Crypto.Cipher import PKCS1_OAEP,AES;from Crypto.Util import Padding;print('Crypto')
from baseHttp import*
from baseFunc import*
ATTRIBUTE_PATTERN=re.compile('((?:[^,"\']|"[^"]*"|\'[^\']*\')+)')
try:
	import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs;__addon__=xbmcaddon.Addon();__language__=__addon__.getLocalizedString;__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo(_r));__version__=__addon__.getAddonInfo(_AZ);__addonid__=__addon__.getAddonInfo(_T);__addonname__=__addon__.getAddonInfo(_A2)
	def addon_log(string):
		try:log_message=string.encode(_U,'ignore')
		except:log_message='addonException: addon_log'
		level=xbmc.LOGINFO;xbmc.log('[%s-%s]: %s'%(__addonid__,__version__,log_message),level=level)
except:
	def addon_log(string):print(string)
class Disney:
	def __init__(self):self.OS_ANDROID=_A;self.API_DOMAIN='https://www.disneyplus.com';self.API_DOMAIN_NEW='https://disney.api.edge.bamgrid.com/explore';self.API_VERSION_NEW='v1.18';self.ONE_PAGE=15;self.COLLECTION_SIZE=30;self.HttpObj=BaseHttp();self.Init_DZ_Total();self.DZ_COOKIES_FILENAME='';self.DZ_SEARCHED_FILENAME='';self.DZ_WATCHED_MOVIE='';self.DZ_WATCHED_VOD='';self.DZ_VTT_FILENAME='';self.DZ_M3U8_FILENAME='';self.DZ_SESSION_COOKIES1='';self.DZ_SESSION_COOKIES2='';self.DZ_SESSION_COOKIES3='';self.DZ_SESSION_COOKIES4='';self.DZ_SESSION_FULLTEXT1='';self.DZ_SESSION_FULLTEXT2='';self.DZ_SESSION_FULLTEXT3='';self.DZ_SESSION_FULLTEXT4='';self.DZ_CONTEXTJSON_FILE1='';self.DZ_CONTEXTJSON_FILE2='';self.DZ_CONTEXTJSON_FILE3='';self.DZ_CONTEXTJSON_FILE4='';self.KodiVersion=20
	def Init_DZ_Total(self):self.DZ={_K:{},_H:{},_C:{}}
	def Save_session_acount(self,dzid,dzpw,dzpf):self.DZ[_C]['dzid']=Base64_Encode(dzid);self.DZ[_C]['dzpw']=Base64_Encode(dzpw);self.DZ[_C]['dzpf']=dzpf
	def Load_session_acount(self):
		try:dzid=Base64_Decode(self.DZ[_C]['dzid']);dzpw=Base64_Decode(self.DZ[_C]['dzpw']);dzpf=self.DZ[_C]['dzpf']
		except:return'','',0
		return dzid,dzpw,dzpf
	def callRequest_httpx(self,jobtype,url,payload=_P,json=_P,params=_P,headers=_P,cookies=_P):
		A='jobtype   : {}';setHeader={_AB:self.HttpObj.USER_AGENT}
		if headers:setHeader.update(headers)
		try:
			if jobtype==_J:addon_log(A.format(jobtype));res=httpx.get(url,data=payload,json=json,params=params,headers=setHeader,cookies=cookies)
			else:addon_log(A.format(jobtype));res=httpx.post(url,data=payload,json=json,params=params,headers=setHeader,cookies=cookies)
		except Exception as exception:addon_log('excetp : {}'.format(exception))
		addon_log(str(res.status_code)+' - '+str(res.url));return res
	def generatePvId(self):import hashlib;m=hashlib.md5();hash_str=str(random.random());m.update(hash_str.encode(_U));pvid=str(m.hexdigest());return _At%(pvid[:8],pvid[8:12],pvid[12:16],pvid[16:20],pvid[20:])
	def Make_Headers(self,accessToken=_B,Bearer=_A):
		if accessToken:authorization=self.DZ[_C][_Q]
		else:authorization=self.DZ[_K][_Aa]
		if Bearer:authorization='Bearer {}'.format(authorization)
		headers={'authorization':authorization,'x-application-version':self.DZ.get(_K).get(_Au,'1.1.2'),'x-bamsdk-client-id':self.DZ[_K][_AC],'x-bamsdk-platform':'javascript/windows/chrome','x-bamsdk-platform-id':_Ab,'x-bamsdk-version':self.DZ[_K][_Ac],'X-DSS-Edge-Accept':'vnd.dss.edge+json; version=2','X-Request-Yp-Id':self.DZ.get(_K).get(_Av,_Aw),'x-disney-identity-client-id':'DTCI-DISNEYPLUS.WEB'};return headers
	def Get_Prod_File(self):B='endpoints';A='client';self.DZ[_K][_Ac]='35.3';prod_url='https://client-sdk-configs.bamgrid.com/bam-sdk/v7.0/{}/browser/v{}/windows/chrome/prod.json'.format(self.DZ[_K][_AC],self.DZ[_K][_Ac]);prod_json=self.HttpObj.Call_Request(prod_url,params=_P,headers=_P,method=_J).json();self.DZ[_H][_h]=prod_json.get(_H).get(_h).get(A).get(B);self.DZ[_H][_e]=prod_json.get(_H).get(_e).get(A).get(B);self.DZ[_H]['drm']=prod_json.get(_H).get('drm').get(A).get(B);self.DZ[_H][_Ad]=prod_json.get(_H).get(_Ad).get(A).get(B);self.DZ[_H][_AD]=prod_json.get(_H).get(_AD).get(A).get(B)
	def Check_ErrorMessage(self,message):
		B='message';A='errors'
		try:
			if A in message:
				if _i in message[A][0]:print(message[A][0][_i])
				elif B in message[A][0]:print(message[A][0][B])
				else:print('etc error')
				return _A
		except Exception as exception:print(exception);return _A
		return _B
	def DZ_Login_Main(self,userid,userpw,userpf):
		addon_log('1. Get_DZ_InitValue')
		if self.Get_DZ_InitValue()==_A:return _A
		addon_log('2. Get_DZ_GetInitToken')
		if self.Get_DZ_GetInitToken()==_A:return _A
		addon_log('3. Get_DZ_Login')
		if self.Get_DZ_Login(userid,userpw,userpf)==_A:return _A
		JsonFile_Save(self.DZ_COOKIES_FILENAME,self.DZ);return _B
	def DZ_Login_ReToken(self):
		if self.Get_DZ_GetReToken()==_A:return _A
		JsonFile_Save(self.DZ_COOKIES_FILENAME,self.DZ);return _B
	def Get_DZ_AccoutInfo(self):
		profile_Info={}
		try:
			url=self.DZ[_H][_h][_L][_M];headers=self.Make_Headers(accessToken=_B,Bearer=_A);payload={_L:'query EntitledGraphMeQuery { me { __typename account { __typename ...accountGraphFragment } activeSession { __typename ...sessionGraphFragment } } } fragment accountGraphFragment on Account { __typename id activeProfile { __typename id } profiles { __typename ...profileGraphFragment } parentalControls { __typename isProfileCreationProtected } flows { __typename star { __typename isOnboarded } } attributes { __typename email emailVerified userVerified locations { __typename manual { __typename country } purchase { __typename country } registration { __typename geoIp { __typename country } } } } } fragment profileGraphFragment on Profile { __typename id name maturityRating { __typename ratingSystem ratingSystemValues contentMaturityRating maxRatingSystemValue isMaxContentMaturityRating } isAge21Verified flows { __typename star { __typename eligibleForOnboarding isOnboarded } } attributes { __typename isDefault kidsModeEnabled groupWatch { __typename enabled } languagePreferences { __typename appLanguage playbackLanguage preferAudioDescription preferSDH subtitleLanguage subtitlesEnabled } parentalControls { __typename isPinProtected kidProofExitEnabled liveAndUnratedContent { __typename enabled } } playbackSettings { __typename autoplay backgroundVideo prefer133 preferImaxEnhancedVersion} avatar { __typename id userSelected } } } fragment sessionGraphFragment on Session { __typename sessionId device { __typename id } entitlements experiments { __typename featureId variantId version } homeLocation { __typename countryCode } inSupportedLocation isSubscriber location { __typename countryCode } portabilityLocation { __typename countryCode } preferredMaturityRating { __typename impliedMaturityRating ratingSystem } }',_Z:{},_j:'EntitledGraphMeQuery'};response=self.HttpObj.Call_Request(url,json=payload,headers=headers,method=_V)
			if response.status_code not in[200,201]:return{}
			resJson=response.json();account=resJson[_F]['me'][_C];activeProfile=account['activeProfile'][_T]
			for i_account in account[_Ae]:
				if i_account[_T]==activeProfile:profile_Info=i_account;break
		except Exception as exception:print(exception);return{}
		return profile_Info
	def _set_Imax(self):
		try:
			url=self.DZ[_H][_h][_L][_M];headers=self.Make_Headers(accessToken=_B,Bearer=_A);payload={_L:'mutation updateProfileImaxEnhancedVersion($input: UpdateProfileImaxEnhancedVersionInput!) {updateProfileImaxEnhancedVersion(updateProfileImaxEnhancedVersion: $input) {accepted}}',_Z:{_k:{'imaxEnhancedVersion':_B}}};response=self.HttpObj.Call_Request(url,json=payload,headers=headers,method=_V)
			if response.status_code not in[200,201]:return{}
			resJson=response.json();JsonFile_Save(self.DZ_SESSION_COOKIES4,resJson);self.DZ[_C][_Q]=resJson.get(_G).get(_E).get(_I).get(_Q);self.DZ[_C][_S]=resJson.get(_G).get(_E).get(_I).get(_S);self.DZ[_C][_N]=resJson.get(_G).get(_E).get(_I).get(_N);self.DZ[_C][_p]=Get_TimeStamp()+14400;self.DZ[_C][_AE]=resJson.get(_G).get(_E).get(_l).get(_AF).get(_T);self.DZ[_C][_f]=resJson.get(_G).get(_E).get(_l).get(_f)
		except Exception as exception:print(exception);return _A
		return _B
	def Set_DZ_Imax(self):
		try:
			profile_Info=self.Get_DZ_AccoutInfo()
			if profile_Info[_X]['playbackSettings']['preferImaxEnhancedVersion']==_A:self._set_Imax();JsonFile_Save(self.DZ_COOKIES_FILENAME,self.DZ)
		except Exception as exception:print(exception)
	def Get_DZ_InitValue(self):
		E='buildId';D='path';C='remoteConfig';B='pageProps';A='props'
		try:url=self.API_DOMAIN;response=self.HttpObj.Call_Request(url,params=_P,headers=_P,method=_J);JSON_REGEX='<script id="__NEXT_DATA__" type="application/json">\\s*(.*?)\\s*</script>';regex_Text=re.compile(JSON_REGEX,re.DOTALL).findall(response.text)[0];paths_json=json.loads(regex_Text);self.DZ[_K][_AC]=paths_json.get(A).get(B).get(C).get(D).get(_E).get(_AC);self.DZ[_K][_Au]=paths_json.get(A).get(B).get(C).get(D).get(_E).get('application').get(_AZ);self.DZ[_K][_Aa]=paths_json.get(A).get(B).get(C).get(D).get(_E).get(_Aa);self.DZ[_K]['lang']='ko-kr';self.DZ[_K][_Ax]='KR';self.DZ[_K][E]=paths_json.get(E);self.DZ[_K][_Av]=_Aw;self.Get_Prod_File()
		except Exception as exception:print(exception);return _A
		return _B
	def Get_DZ_GetInitToken(self):
		E='windows';D='chrome';C='registerDevice';B='https://disney.api.edge.bamgrid.com/graph/v1/device/graphql';A='assertion'
		try:
			url=B;headers=self.Make_Headers(accessToken=_A,Bearer=_B);payload={_j:C,_L:'mutation registerDevice($input:RegisterDeviceInput!){registerDevice(registerDevice:$input){grant{grantType assertion}}}',_Z:{_k:{'applicationRuntime':D,_X:{'brand':'web','browserName':D,'browserVersion':'151.0.0','manufacturer':'microsoft','model':'null','operatingSystem':E,'operatingSystemVersion':'10.0','osDeviceIds':[]},'deviceFamily':_Ab,'deviceLanguage':'ko','devicePlatformId':_Ab,'deviceProfile':E}}};response=self.HttpObj.Call_Request(url,json=payload,headers=headers,method=_V)
			if response.status_code not in[200,201]:return _A
			resJson=response.json()
			if self.Check_ErrorMessage(resJson)==_A:return _A
			self.DZ[_C][A]=resJson.get(_F).get(C).get('grant').get(A);url=B;headers=self.Make_Headers(accessToken=_A,Bearer=_B);payload={_j:'exchangeDeviceGrantForAccessToken',_L:'mutation exchangeDeviceGrantForAccessToken($input:ExchangeDeviceGrantForAccessTokenInput!){exchangeDeviceGrantForAccessToken(exchangeDeviceGrantForAccessToken:$input){accepted}}',_Z:{_k:{'deviceGrant':self.DZ[_C][A]}}};response=self.HttpObj.Call_Request(url,json=payload,headers=headers,method=_V)
			if response.status_code not in[200,201]:return _A
			resJson=response.json()
			if self.Check_ErrorMessage(resJson)==_A:return _A
			self.DZ[_C][_Q]=resJson.get(_G).get(_E).get(_I).get(_Q);self.DZ[_C][_S]=resJson.get(_G).get(_E).get(_I).get(_S);self.DZ[_C][_N]=resJson.get(_G).get(_E).get(_I).get(_N);self.DZ[_C][_p]=Get_TimeStamp()+14400
		except Exception as exception:print(exception);return _A
		return _B
	def Get_DZ_GetReToken(self):
		try:
			self.Get_Prod_File();url=self.DZ[_H][_h][_N][_M];headers=self.Make_Headers(accessToken=_A,Bearer=_A);payload={_L:'mutation refreshToken($input: RefreshTokenInput!) {\n            refreshToken(refreshToken: $input) {\n                activeSession {\n                    sessionId\n                }\n            }\n        }',_Z:{_k:{_N:self.DZ[_C][_N]}}};response=self.HttpObj.Call_Request(url,json=payload,headers=headers,method=_V)
			if response.status_code not in[200,201]:return _A
			resJson=response.json()
			if self.Check_ErrorMessage(resJson)==_A:return _A
			self.DZ[_C][_Q]=resJson.get(_G).get(_E).get(_I).get(_Q);self.DZ[_C][_S]=resJson.get(_G).get(_E).get(_I).get(_S);self.DZ[_C][_N]=resJson.get(_G).get(_E).get(_I).get(_N);self.DZ[_C][_p]=Get_TimeStamp()+14400;self.DZ[_C][_AE]=resJson.get(_G).get(_E).get(_l).get(_AF).get(_T);self.DZ[_C][_f]=resJson.get(_G).get(_E).get(_l).get(_f)
		except Exception as exception:print(exception);return _A
		return _B
	def Get_DZ_Login_httpx(self,userid,userpw,userpf):
		try:
			addon_log(_Ay);url=self.DZ[_H][_h][_L][_M];headers=self.Make_Headers(accessToken=_B,Bearer=_B);payload={_L:_Az,_Z:{_AG:userid,_A_:{_Af:['Register']}}};response=self.callRequest_httpx(_V,url,json=payload,headers=headers)
			if response.status_code not in[200,201]:return _A
			addon_log('resJson : {}'.format(response.json()));resJson=response.json()
			if'Login'not in resJson.get(_F).get('check').get(_Af):return _A
			addon_log(_B0);url=self.DZ[_H][_h][_L][_M];headers=self.Make_Headers(accessToken=_B,Bearer=_B);payload={_j:_AH,_L:_B1,_Z:{_k:{_AG:userid,'password':userpw}}};response=self.callRequest_httpx(_V,url,json=payload,headers=headers)
			if response.status_code not in[200,201]:return _A
			resJson=response.json()
			if self.Check_ErrorMessage(resJson)==_A:return _A
			self.DZ[_C][_Q]=resJson.get(_G).get(_E).get(_I).get(_Q);self.DZ[_C][_S]=resJson.get(_G).get(_E).get(_I).get(_S);self.DZ[_C][_N]=resJson.get(_G).get(_E).get(_I).get(_N);self.DZ[_C][_p]=Get_TimeStamp()+14400;self.DZ[_C][_r]=resJson.get(_F).get(_AH).get(_C).get(_Ae)[userpf].get(_T);addon_log(_B2);url=self.DZ[_H][_h][_L][_M];headers=self.Make_Headers(accessToken=_B,Bearer=_B);payload={_j:_B3,_L:'\n    mutation switchProfile($input: SwitchProfileInput!) {\n        switchProfile(switchProfile: $input) {\n            account {\n                ...account\n\n                activeProfile {\n                    ...profile\n                    \n                }\n            }\n            activeSession {\n                ...session\n            }\n        }\n    }\n\n    \nfragment account on Account {\n    id\n    accountConsentToken\n    attributes {\n        blocks {\n            expiry\n            reason\n        }\n        maxNumberOfProfilesAllowed\n        consentPreferences {\n            dataElements {\n                name\n                value\n            }\n            purposes {\n                consentDate\n                firstTransactionDate\n                id\n                lastTransactionCollectionPointId\n                lastTransactionCollectionPointVersion\n                lastTransactionDate\n                name\n                status\n                totalTransactionCount\n                version\n            }\n        }\n        dssIdentityCreatedAt\n        email\n        emailVerified\n        lastSecurityFlaggedAt\n        locations {\n            manual {\n                country\n            }\n            purchase {\n                country\n                source\n            }\n            registration {\n                geoIp {\n                    country\n                }\n            }\n        }\n        securityFlagged\n        tags\n        taxId\n        userVerified\n    }\n    parentalControls {\n        isProfileCreationProtected\n    }\n    flows {\n        star {\n            isOnboarded\n        }\n    }\n    umpMessages {\n        data {\n            messages {\n                messageId\n                messageSource\n                displayLocations\n                content\n            }\n        }\n    }\n}\n\n    \nfragment profile on Profile {\n    id\n    name\n    isAge21Verified\n    attributes {\n        avatar {\n            id\n            userSelected\n        }\n        isDefault\n        kidsModeEnabled\n        languagePreferences {\n            appLanguage\n            playbackLanguage\n            preferAudioDescription\n            preferSDH\n            subtitleLanguage\n            subtitlesEnabled\n        }\n        parentalControls {\n            kidProofExitEnabled\n            isPinProtected\n            liveAndUnratedContent {\n                enabled\n                available\n            }\n        }\n        playbackSettings {\n            autoplay\n            backgroundVideo\n            prefer133\n            preferImaxEnhancedVersion\n            previewAudioOnHome\n            previewVideoOnHome\n        }\n        privacySettings {\n            consents {\n                consentType\n                value\n            }\n        }\n    }\n    avatar {\n        id\n        type\n        images {\n            masterId\n            url\n        }\n    }\n    personalInfo {\n        dateOfBirth\n        gender\n        age\n    }\n    maturityRating {\n        ...maturityRating\n    }\n    metadata {\n        globalTimeOverride\n    }\n    personalInfo {\n        dateOfBirth\n        age\n        gender\n    }\n    flows {\n        personalInfo {\n            eligibleForCollection\n            requiresCollection\n        }\n        star {\n            eligibleForOnboarding\n            isOnboarded\n        }\n    }\n}\n\n\nfragment maturityRating on MaturityRating {\n    ratingSystem\n    ratingSystemValues\n    contentMaturityRating\n    maxRatingSystemValue\n    isMaxContentMaturityRating\n    suggestedMaturityRatings {\n        minimumAge\n        maximumAge\n        ratingSystemValue\n    }\n}\n\n\n    \nfragment session on Session {\n    device {\n        id\n        platform\n    }\n    entitlements\n    features {\n        coPlay\n    }\n    inSupportedLocation\n    isSubscriber\n    location {\n        type\n        countryCode\n        dma\n        asn\n        regionName\n        connectionType\n        zipCode\n    }\n    sessionId\n    experiments {\n        featureId\n        variantId\n        version\n    }\n    identity {\n        id\n    }\n    account {\n        id\n    }\n    profile {\n        id\n        parentalControls {\n            liveAndUnratedContent {\n                enabled\n            }\n        }\n    }\n    partnerName\n    preferredMaturityRating {\n        impliedMaturityRating\n        ratingSystem\n    }\n    homeLocation {\n        countryCode\n    }\n    portabilityLocation {\n        countryCode\n        type\n    }\n}\n\n',_Z:{_k:{_B4:self.DZ[_C][_r]}}};response=self.callRequest_httpx(_V,url,json=payload,headers=headers)
			if response.status_code not in[200,201]:return _A
			resJson=response.json()
			if self.Check_ErrorMessage(resJson)==_A:return _A
			self.DZ[_C][_Q]=resJson.get(_G).get(_E).get(_I).get(_Q);self.DZ[_C][_S]=resJson.get(_G).get(_E).get(_I).get(_S);self.DZ[_C][_N]=resJson.get(_G).get(_E).get(_I).get(_N);self.DZ[_C][_p]=Get_TimeStamp()+14400;self.DZ[_C][_AE]=resJson.get(_G).get(_E).get(_l).get(_AF).get(_T);self.DZ[_C][_f]=resJson.get(_G).get(_E).get(_l).get(_f);self.Save_session_acount(userid,userpw,userpf)
		except Exception as exception:print(exception);return _A
		return _B
	def Get_DZ_Login(self,userid,userpw,userpf):
		A='https://disney.api.edge.bamgrid.com/v1/public/graphql'
		try:
			addon_log(_Ay);url=A;headers=self.Make_Headers(accessToken=_B,Bearer=_B);payload={_j:'check',_L:_Az,_Z:{_AG:userid,_A_:{_Af:['Register']}}};response=self.HttpObj.Call_Request(url,json=payload,headers=headers,method=_V)
			if response.status_code not in[200,201]:return _A
			resJson=response.json();addon_log(_B0);url=A;headers=self.Make_Headers(accessToken=_B,Bearer=_B);payload={_j:_AH,_L:_B1,_Z:{_k:{_AG:userid,'password':userpw}}};"\n\t\t\tfrom curl_cffi import requests\n\t\t\timpersonate = 'chrome124' # chrome124, chrome\n\t\t\t#headers['user-agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36'\n\t\t\tSESSION = requests.Session()\n\t\t\tresponse = SESSION.post(url, json=payload, headers=headers, impersonate=impersonate )\n\t\t\tprint( '{} - {}'.format(response.status_code, response.url ) )\n\t\t\t";"\n\t\t\timport pycurl\n\t\t\tfrom io import BytesIO\n\t\t\tfrom urllib.parse import urlencode\n\t\t\tbuffer = BytesIO()\n\t\t\tc = pycurl.Curl()\n\t\t\tc.setopt(c.URL, 'https://disney.api.edge.bamgrid.com/v1/public/graphql')\n\t\t\tpostfields = json.dumps(payload)\n\t\t\tauthorization = 'Bearer {}'.format( self.DZ['account']['accessToken'] )\n\t\t\theaders = [\n\t\t\t\t\t'authorization: {}'.format(authorization),\n\t\t\t\t\t'x-application-version: {}'.format( self.DZ['headers']['sdkAppVersion'] ),\n\t\t\t\t\t'x-bamsdk-client-id: {}'.format( self.DZ['headers']['clientId'] ),\n\t\t\t\t\t'x-bamsdk-platform: javascript/windows/chrome',\n\t\t\t\t\t'x-bamsdk-platform-id: browser',\n\t\t\t\t\t'x-bamsdk-version: {}'.format( self.DZ['headers']['sdkVersion'] ),\n\t\t\t\t\t'X-DSS-Edge-Accept: vnd.dss.edge+json; version=2',\n\t\t\t\t\t'X-Request-Yp-Id: {}'.format( self.DZ['headers']['x-request-yp-id']),\n\t\t\t\t\t'x-disney-identity-client-id: DTCI-DISNEYPLUS.WEB'\n\t\t\t]\n\t\t\tc.setopt(c.HTTPHEADER, headers)\n\t\t\tc.setopt(c.POSTFIELDS, postfields)\n\t\t\tc.setopt(c.WRITEDATA, buffer)\n\n\t\t\tc.perform()\n\t\t\tc.close()\n\t\t\tprint(buffer.getvalue().decode('utf-8') )\n\t\t\tresJson = json.loads( buffer.getvalue().decode('utf-8') )\n\t\t\t";time.sleep(1.1);import httpx;from fake_useragent import UserAgent;ua=UserAgent();headers[_AB]=ua.random;print(headers[_AB]);response=httpx.post(url,json=payload,headers=headers)
			if response.status_code not in[200,201]:return _A
			resJson=response.json();print(resJson)
			if self.Check_ErrorMessage(resJson)==_A:return _A
			self.DZ[_C][_Q]=resJson.get(_G).get(_E).get(_I).get(_Q);self.DZ[_C][_S]=resJson.get(_G).get(_E).get(_I).get(_S);self.DZ[_C][_N]=resJson.get(_G).get(_E).get(_I).get(_N);self.DZ[_C][_p]=Get_TimeStamp()+14400;self.DZ[_C][_r]=resJson.get(_F).get(_AH).get(_C).get(_Ae)[userpf].get(_T);addon_log(_B2);url=A;headers=self.Make_Headers(accessToken=_B,Bearer=_B);payload={_j:_B3,_L:'\n    mutation switchProfile($input: SwitchProfileInput!) {\n        switchProfile(switchProfile: $input) {\n            account {\n                ...account\n\n                activeProfile {\n                    ...profile\n                    \n                }\n            }\n            activeSession {\n                ...session\n            }\n        }\n    }\n\n    \nfragment account on Account {\n    id\n    accountConsentToken\n    attributes {\n        blocks {\n            expiry\n            reason\n        }\n        maxNumberOfProfilesAllowed\n        consentPreferences {\n            dataElements {\n                name\n                value\n            }\n            purposes {\n                consentDate\n                firstTransactionDate\n                id\n                lastTransactionCollectionPointId\n                lastTransactionCollectionPointVersion\n                lastTransactionDate\n                name\n                status\n                totalTransactionCount\n                version\n            }\n        }\n        dssIdentityCreatedAt\n        email\n        emailVerified\n        lastSecurityFlaggedAt\n        locations {\n            manual {\n                country\n            }\n            purchase {\n                country\n                source\n            }\n            registration {\n                geoIp {\n                    country\n                }\n            }\n        }\n        securityFlagged\n        tags\n        taxId\n        userVerified\n    }\n    parentalControls {\n        isProfileCreationProtected\n    }\n    flows {\n        star {\n            isOnboarded\n        }\n    }\n    umpMessages {\n        data {\n            messages {\n                messageId\n                messageSource\n                displayLocations\n                content\n            }\n        }\n    }\n}\n\n    \nfragment profile on Profile {\n    id\n    name\n    isAge21Verified\n    attributes {\n        avatar {\n            id\n            userSelected\n        }\n        isDefault\n        isGeminiOnboarded\n        kidsModeEnabled\n        languagePreferences {\n            appLanguage\n            playbackLanguage\n            preferAudioDescription\n            preferSDH\n            subtitleLanguage\n            subtitlesEnabled\n        }\n        parentalControls {\n            kidProofExitEnabled\n            isPinProtected\n            liveAndUnratedContent {\n                enabled\n                available\n            }\n        }\n        playbackSettings {\n            autoplay\n            backgroundVideo\n            prefer133\n            preferImaxEnhancedVersion\n            previewAudioOnHome\n            previewVideoOnHome\n        }\n        privacySettings {\n            consents {\n                consentType\n                value\n            }\n        }\n    }\n    avatar {\n        id\n        type\n        images {\n            masterId\n            url\n        }\n    }\n    personalInfo {\n        dateOfBirth\n        gender\n        age\n    }\n    maturityRating {\n        ...maturityRating\n    }\n    metadata {\n        globalTimeOverride\n    }\n    personalInfo {\n        dateOfBirth\n        age\n        gender\n    }\n    flows {\n        personalInfo {\n            eligibleForCollection\n            requiresCollection\n        }\n        star {\n            eligibleForOnboarding\n            isOnboarded\n        }\n    }\n}\n\n\nfragment maturityRating on MaturityRating {\n    ratingSystem\n    ratingSystemValues\n    contentMaturityRating\n    maxRatingSystemValue\n    isMaxContentMaturityRating\n    suggestedMaturityRatings {\n        minimumAge\n        maximumAge\n        ratingSystemValue\n    }\n}\n\n\n    \nfragment session on Session {\n    device {\n        id\n        platform\n    }\n    entitlements\n    features {\n        coPlay\n    }\n    inSupportedLocation\n    isSubscriber\n    location {\n        type\n        countryCode\n        dma\n        asn\n        regionName\n        connectionType\n        zipCode\n    }\n    sessionId\n    experiments {\n        featureId\n        variantId\n        version\n    }\n    identity {\n        id\n    }\n    account {\n        id\n    }\n    profile {\n        id\n        parentalControls {\n            liveAndUnratedContent {\n                enabled\n            }\n        }\n    }\n    partnerName\n    preferredMaturityRating {\n        impliedMaturityRating\n        ratingSystem\n    }\n    homeLocation {\n        countryCode\n    }\n    portabilityLocation {\n        countryCode\n        type\n    }\n}\n\n',_Z:{_k:{_B4:self.DZ[_C][_r]}}};response=self.HttpObj.Call_Request(url,json=payload,headers=headers,method=_V)
			if response.status_code not in[200,201]:return _A
			resJson=response.json()
			if self.Check_ErrorMessage(resJson)==_A:return _A
			self.DZ[_C][_Q]=resJson.get(_G).get(_E).get(_I).get(_Q);self.DZ[_C][_S]=resJson.get(_G).get(_E).get(_I).get(_S);self.DZ[_C][_N]=resJson.get(_G).get(_E).get(_I).get(_N);self.DZ[_C][_p]=Get_TimeStamp()+14400;self.DZ[_C][_AE]=resJson.get(_G).get(_E).get(_l).get(_AF).get(_T);self.DZ[_C][_f]=resJson.get(_G).get(_E).get(_l).get(_f);self.Save_session_acount(userid,userpw,userpf)
		except Exception as exception:print(exception);return _A
		return _B
	def Make_Endpoint(self,uMode,**kwargs):
		if uMode==_B5:href=self.DZ[_H][_e]['getCollection'][_M]
		elif uMode==_B6:href=self.DZ[_H][_e]['getCuratedSet'][_M]
		elif uMode=='SEASON_LIST':href=self.DZ[_H][_e]['getDmcSeriesBundle'][_M]
		elif uMode=='EPISODE_LIST':href=self.DZ[_H][_e]['getDmcEpisodes'][_M]
		elif uMode==_Ag:href=self.DZ[_H][_Ad]['mediaPayload'][_M]
		elif uMode=='SEARCH_LIST':href=self.DZ[_H][_e]['getSearchResults'][_M]
		elif uMode==_B7:href=self.DZ[_H][_e]['getDmcVideoBundle'][_M]
		elif uMode==_B8:href=self.DZ[_H][_AD]['getDeeplink'][_M]
		elif uMode==_Ah:href=self.DZ[_H][_AD]['getPlayerExperience'][_M]
		else:return''
		_args={'apiVersion':'5.1','region':self.DZ[_K][_Ax],'kidsModeEnabled':'false','impliedMaturityRating':'1870','appLanguage':self.DZ[_K]['lang'][0:2],'partner':'disney','queryType':'ge',_AZ:'v1.10'};_args.update(**kwargs);return href.format(**_args)
	def Get_Brand_List(self):
		page_list=[];HomePageId=self.Get_DeepLink_PageId('home');BrandsPageGroup=_P
		try:
			url=_B9.format(self.API_DOMAIN_NEW,self.API_VERSION_NEW,HomePageId);headers=self.Make_Headers(accessToken=_B,Bearer=_B);response=self.HttpObj.Call_Request(url,headers=headers,method=_J)
			if response.status_code not in[200,201]:return[]
			resJson=response.json()[_F][_q]
			for iContainer in resJson.get(_g):
				if iContainer[_AI]=='nestingGroup':BrandsPageGroup=iContainer['nestedPages'];break
		except Exception as exception:print(exception);return[]
		try:
			for iItem in BrandsPageGroup:temp_list={_R:iItem[_D][_A2],_s:iItem[_g][0][_O][0][_s],'image':self.Image_IdtoUrl(iItem[_D][_t]['brand']['logo_white']['2.00'][_Ai])};page_list.append(temp_list)
		except Exception as exception:print(exception);return[]
		return page_list
	def Get_Group_Title(self,refId,refType):
		A='CuratedSet';group_title='None'
		try:
			url=self.Make_Endpoint(_B6,setId=refId,pageSize=str(15),page=str(1));headers=self.Make_Headers(accessToken=_B,Bearer=_B)
			if refType!=A:url=url.replace(A,refType)
			response=self.HttpObj.Call_Request(url,headers=headers,method=_J)
			if response.status_code not in[200,201]:group_title
			resJson=response.json().get(_F).get(refType);group_title=resJson.get('text').get(_R).get(_u).get('set').get('default').get(_e).strip()
		except Exception as exception:print(exception);return group_title
		return group_title
	def Get_refId(self,contentClass,contentSlugs):
		A='Collection'
		try:
			url=self.Make_Endpoint(_B5,collectionSubType='StandardCollection',contentClass=contentClass,slug=contentSlugs);headers=self.Make_Headers(accessToken=_B,Bearer=_B);response=self.HttpObj.Call_Request(url,headers=headers,method=_J)
			if response.status_code not in[200,201]:return _A
			resJson=response.json();refId=resJson[_F][A][_g][0]['set']['refId'];refType=resJson[_F][A][_g][0]['set']['refType']
		except Exception as exception:print(exception);return'',''
		return refId,refType
	def Get_imageurl_parser2(self,imageJson,imageType,imageSize):
		result_URL=''
		try:
			for iType in imageType:
				tempImage=imageJson.get(iType)
				if tempImage!=_P:break
			for i_size in imageSize:
				if tempImage.get(i_size)==_P:continue
				result_URL=tempImage.get(i_size).get(_Ai);break
			if result_URL=='':
				for i_value in tempImage:result_URL=tempImage.get(i_value).get(_Ai);break
		except Exception as exception:print(exception);return''
		if result_URL!='':result_URL=self.Image_IdtoUrl(result_URL)
		return result_URL
	def Generate_UUID_32(self):import random,hashlib;m=hashlib.md5();hash_str=str(random.random());m.update(hash_str.encode(_U));pvid=str(m.hexdigest());return _At%(pvid[:8],pvid[8:12],pvid[12:16],pvid[16:20],pvid[20:])
	def Delete_Watch_List(self,delInfoBlock):
		try:
			import datetime;nowtime=datetime.datetime.utcnow();nowtime=nowtime.strftime('%Y-%m-%dT%H:%M:%S.001Z');url='https://disney.api.edge.bamgrid.com/envelope';headers=self.Make_Headers(accessToken=_B,Bearer=_B);payload=[{_F:{'action_info_block':delInfoBlock},'datacontenttype':'application/json;charset=utf-8',_T:self.Generate_UUID_32(),'schemaurl':'https://github.bamtech.co/schema-registry/schema-registry-client-signals/blob/series/1.X.X/smithy/dss/cs/event/user-content-actions/preference/v1/watch-history-preference.smithy','source':'urn:dss:source:sdk:javascript:windows:chrome','subject':'sessionId={},profileId={}'.format(self.DZ[_C][_f],self.DZ[_C][_r]),'time':nowtime,_AI:'urn:dss:event:cs:user-content-actions:preference:v1:watch-history-preference'}];response=self.HttpObj.Call_Request(url,json=payload,headers=headers,method=_V)
			if response.status_code not in[200,201]:return _A
		except Exception as exception:print(exception);return _A
		return _B
	def Get_Search_List(self,search_key):
		A='background_details';search_list=[]
		try:
			url='{}/{}/search'.format(self.API_DOMAIN_NEW,self.API_VERSION_NEW);headers=self.Make_Headers(accessToken=_B,Bearer=_B);params={_L:search_key};response=self.HttpObj.Call_Request(url,headers=headers,params=params,method=_J)
			if response.status_code not in[200,201]:return[]
			resJson=response.json().get(_F).get(_q).get(_g)
			for i_item in resJson[0][_A3]:image=i_item[_D][_t][_A4];fanart=self.Get_imageurl_parser2(image,[A,_A5],[_W,_m]);thumb=self.Get_imageurl_parser2(image,[_n,A,_A5],[_W,_m]);poster=self.Get_imageurl_parser2(image,[_b],[_m,_W]);clearlogo=self.Get_imageurl_parser2(image,[_AJ],[_W,_m]);temp_list={_R:i_item[_D][_R],_AK:i_item[_O][0][_s],'vType':_AM if _w in i_item[_D]else _Aj,_A6:int(i_item[_D][_w]/1000)if _w in i_item[_D]else 0,'desc':i_item[_D][_i][_u],_AL:i_item[_D][_Y][_AN][_Ak],_v:poster,_A7:thumb,_A8:clearlogo,_A9:fanart};search_list.append(temp_list)
		except Exception as exception:print(exception);return[]
		return search_list
	def Get_Season_List2(self,entityId):
		season_list=[]
		try:
			url=_AO.format(self.API_DOMAIN_NEW,self.API_VERSION_NEW,entityId);headers=self.Make_Headers(accessToken=_B,Bearer=_B);params={_AP:_B,_AQ:15,_x:15};response=self.HttpObj.Call_Request(url,headers=headers,params=params,method=_J)
			if response.status_code not in[200,201]:return[]
			resJson=response.json()[_F][_q]
			for iContainer in resJson[_g]:
				if iContainer.get(_AI)=='episodes':seasonsJson=iContainer
			detailsJson=resJson[_D];desc=detailsJson[_i][_u];imageJson=detailsJson[_t][_A4];poster=self.Get_imageurl_parser2(imageJson,[_b],[_AR,_m,_AS])
			for iSeason in seasonsJson.get('seasons'):temp_list={'seasonId':iSeason[_T],_BA:iSeason[_D][_A2],'episodeCnt':iSeason[_Al]['totalCount'],'desc':desc,_v:poster};season_list.append(temp_list)
		except Exception as exception:print(exception);return[]
		return season_list
	def Get_Episode_List(self,seasonId,page_int):
		episode_list=[];more_page=_A
		try:
			url='{}/{}/season/{}'.format(self.API_DOMAIN_NEW,self.API_VERSION_NEW,seasonId);headers=self.Make_Headers(accessToken=_B,Bearer=_B);params={_x:self.ONE_PAGE,'offset':(page_int-1)*self.ONE_PAGE};response=self.HttpObj.Call_Request(url,headers=headers,params=params,method=_J)
			if response.status_code not in[200,201]:return[],_A
			resJson=response.json()[_F]['season']
			for i_item in resJson.get(_A3):resourceId=i_item[_O][0][_y];availId=i_item[_O][0][_z];title=i_item[_D]['episodeTitle'];tvshowtitle=i_item[_D][_R];desc=i_item[_D][_i][_u];duration=int(i_item[_D][_w]/1000);seasonNum=i_item[_D][_BB];episodeNum=i_item[_D]['episodeNumber'];imageJson=i_item[_D][_t][_A4];fanart=self.Get_imageurl_parser2(imageJson,[_n,_A5,_b],[_W,_A0]);thumb=self.Get_imageurl_parser2(imageJson,[_b],[_W,_A0]);poster=self.Get_imageurl_parser2(imageJson,[_b],[_AR,_m,_AS]);clearlogo=self.Get_imageurl_parser2(imageJson,[_AJ],[_W]);temp_list={_y:resourceId,_z:availId,_R:title,'tvshowtitle':tvshowtitle,'desc':desc,_A6:duration,_BA:seasonNum,'episodeNum':episodeNum,_A9:fanart,_A7:thumb,_v:poster,_A8:clearlogo};episode_list.append(temp_list)
			more_page=resJson[_Al]['hasMore']
		except Exception as exception:print(exception);return[],_A
		return episode_list,more_page
	def GetStreamingURL(self,resource_id,available_id,playOption):
		streamInfo={_c:'',_AT:'',_d:''}
		try:
			url=self.Make_Endpoint(_Ah,availId=available_id);headers=self.Make_Headers(accessToken=_B,Bearer=_A);response=self.HttpObj.Call_Request(url,headers=headers,method=_J)
			if response.status_code not in[200,201]:return streamInfo
			resJson=response.json()
			if _AU in resJson[_F][_o]:streamInfo[_d]=resJson[_F][_o][_AU]
			elif _AV in resJson[_F][_o]:streamInfo[_d]=resJson[_F][_o][_AV]
			else:streamInfo[_d]='en'
			scenario='ctr-high'if playOption[_AW]else _BC;url=self.Make_Endpoint(_Ag,scenario=scenario);headers=self.Make_Headers(accessToken=_B,Bearer=_A);headers['accept']=_BD;headers[_BE]='true';payload={_BF:resource_id,_a:{_X:{_AX:{_BJ:_A},'protocol':'HTTPS',_BG:[60],_BH:'SGAI',_BI:'ONLINE'}}};video_ranges=[];audio_types=[]
			if playOption.get(_BK)and playOption.get(_AW):
				payload[_a][_X][_AX]={_Am:['h264','h265']}
				if playOption.get(_BL):video_ranges.append('HDR10')
				elif playOption.get(_BM):video_ranges.append(_BN)
				if playOption.get(_AY):audio_types.append('ATMOS')
			else:payload[_a][_X][_BO]={'max':['1280x720']}
			if audio_types:payload[_a][_X][_BP]=audio_types
			if video_ranges:payload[_a][_X][_BQ]=video_ranges
			response=self.HttpObj.Call_Request(url,headers=headers,json=payload,method=_V)
			if response.status_code not in[200,201]:return streamInfo
			resJson=response.json();streamInfo[_c]=response.json()['stream']['sources'][0]['complete']['url'];streamInfo[_c]=self.redirect_streamurl(streamInfo[_c]);streamInfo[_AT]=self.DZ[_H]['drm'][_BR][_M]
		except Exception as exception:print(exception);return streamInfo
		self.Disney_Parse_Main(streamInfo[_c],streamInfo[_d],playOption);return streamInfo
	def redirect_streamurl(self,url):
		if url=='':return''
		print('ori url : {}'.format(url));headers={_AB:self.HttpObj.USER_AGENT};response=requests.get(url,headers=headers,allow_redirects=_A)
		if response.status_code in[200,201]:return url
		elif response.status_code in[301,302]:url=response.headers.get('Location');print('Location : {}'.format(url));return url
		else:return''
	def GetStreamingURL2(self,contentId,playOption):
		streamInfo={_c:'',_AT:'',_d:''}
		try:
			url=self.Make_Endpoint(_B8);headers=self.Make_Headers(accessToken=_B,Bearer=_A);params={'refId':contentId,'refIdType':_BS,'action':_a};response=self.HttpObj.Call_Request(url,headers=headers,params=params,method=_J)
			if response.status_code not in[200,201]:return streamInfo
			resJson=response.json();resource_id=resJson[_F][_An][_O][0][_y];available_id=resJson[_F][_An][_O][0][_z];url=self.Make_Endpoint(_Ah,availId=available_id);headers=self.Make_Headers(accessToken=_B,Bearer=_A);response=self.HttpObj.Call_Request(url,headers=headers,method=_J)
			if response.status_code not in[200,201]:return streamInfo
			resJson=response.json()
			if _AU in resJson[_F][_o]:streamInfo[_d]=resJson[_F][_o][_AU]
			elif _AV in resJson[_F][_o]:streamInfo[_d]=resJson[_F][_o][_AV]
			else:streamInfo[_d]='en'
			scenario='ctr-high'if playOption[_AW]else _BC;url=self.Make_Endpoint(_Ag,scenario=scenario);headers=self.Make_Headers(accessToken=_B,Bearer=_A);headers['accept']=_BD;headers[_BE]='true';payload={_BF:resource_id,_a:{_X:{_AX:{_BJ:_A},'protocol':'HTTPS',_BG:[60],_BH:'SGAI',_BI:'ONLINE'}}};video_ranges=[];audio_types=[]
			if playOption.get(_BK)and playOption.get(_AW):
				payload[_a][_X][_AX]={_Am:['h264','h265']}
				if playOption.get(_BL):video_ranges.append('HDR10')
				elif playOption.get(_BM):video_ranges.append(_BN)
				if playOption.get(_AY):audio_types.append('ATMOS')
			else:payload[_a][_X][_BO]={'max':['1280x720']}
			if audio_types:payload[_a][_X][_BP]=audio_types
			if video_ranges:payload[_a][_X][_BQ]=video_ranges
			response=self.HttpObj.Call_Request(url,headers=headers,json=payload,method=_V)
			if response.status_code not in[200,201]:return streamInfo
			resJson=response.json();streamInfo[_c]=response.json()['stream']['sources'][0]['complete']['url'];streamInfo[_c]=self.redirect_streamurl(streamInfo[_c]);streamInfo[_AT]=self.DZ[_H]['drm'][_BR][_M]
		except Exception as exception:print(exception);return streamInfo
		self.Disney_Parse_Main(streamInfo[_c],streamInfo[_d],playOption);return streamInfo
	def Get_BaseUrl(self,in_url):parseResult=urllib.parse.urlparse(in_url);scheme=parseResult.scheme;netloc=parseResult.netloc;full_path=parseResult.path.strip('/').split('/');full_path.pop(len(full_path)-1);baseUrl=scheme+'://'+netloc+'/'+'/'.join(full_path)+'/';return baseUrl
	def VTT_FileList(self,vtt_url):
		file_list=[];response=requests.get(vtt_url);m3u8_data=response.content.decode(_U);skipTag=_A
		for nowln in m3u8_data.splitlines():
			if nowln.endswith('.vtt'):
				if skipTag:skipTag=_A
				else:file_list.append(nowln)
		return file_list
	def VTT_Detail(self,sub_url,vttDelay):
		subtitle='';response=requests.get(sub_url);vtt_data=response.content.decode(_U);SUB_START=_A;tm_delay=datetime.timedelta(seconds=vttDelay)
		for nowln in vtt_data.splitlines():
			line=re.match('\\d\\d:\\d\\d:\\d\\d.\\d\\d\\d',nowln)
			if line:
				SUB_START=_B
				if vttDelay==.0:subtitle+=nowln[0:29]+'\n'
				else:starttm=self.Timedelta_To_Str(self.Str_To_Timedelta(nowln[0:12])+tm_delay);endtm=self.Timedelta_To_Str(self.Str_To_Timedelta(nowln[17:29])+tm_delay);subtitle+='{} --> {}\n'.format(starttm,endtm)
			elif nowln!=''and SUB_START==_B:subtitle+=nowln+'\n'
			elif nowln==''and SUB_START==_B:SUB_START=_A;subtitle+='\n'
		return subtitle
	def Str_To_Timedelta(self,in_tm):hours=int(in_tm[0:2]);minutes=int(in_tm[3:5]);seconds=int(in_tm[6:8]);milliseconds=int(in_tm[-3:]);return datetime.timedelta(hours=hours,minutes=minutes,seconds=seconds,milliseconds=milliseconds)
	def Timedelta_To_Str(self,tm_delta):seconds=tm_delta.seconds;hours,seconds=divmod(seconds,3600);minutes,seconds=divmod(seconds,60);milliseconds=int(tm_delta.microseconds/1000);return'{:0>2}:{:0>2}:{:0>2}.{:0<3}'.format(hours,minutes,seconds,milliseconds)
	def Check_DelayTime(self,vod_url):
		B='#EXT-X-DATERANGE';A='DURATION';delay_time=.0;response=requests.get(vod_url);vod_data=response.content.decode(_U);max_count=10
		for nowln in vod_data.splitlines():
			max_count-=1
			if max_count==0:break
			if nowln.startswith(B):
				attribs=self.Disney_MediaLine_Parse(nowln,B)
				if A in attribs:
					if float(attribs[A])<1e1:delay_time=float(attribs[A])
					break
		return delay_time
	def Disney_MediaLine_Parse(self,line,prefix):
		attribs={}
		for row in ATTRIBUTE_PATTERN.split(line.replace(prefix+':',''))[1::2]:name,value=row.split('=',1);attribs[name.upper()]=value.replace('"','').strip()
		return attribs
	def VTT_Make_Main(self,vtt_url,vttDelay):
		try:
			BASE_URL=self.Get_BaseUrl(vtt_url);vtt_filelist=self.VTT_FileList(vtt_url);f=open(self.DZ_VTT_FILENAME,'w',-1,_U);f.write('WEBVTT\n\n')
			for i_file in vtt_filelist:f.write(self.VTT_Detail(sub_url=BASE_URL+i_file,vttDelay=vttDelay))
			f.close()
		except:
			if os.path.isfile(self.DZ_VTT_FILENAME):os.remove(self.DZ_VTT_FILENAME)
			return _A
		return _B
	def Disney_Parse_Main(self,stream_url,defaultAudio,playOption):
		vttDelay=.0;response=requests.get(url=stream_url);m3u8=response.content.decode(_U);BASE_URL=self.Get_BaseUrl(stream_url);self.Disney_Parse_m3u8(m3u8,defaultAudio,playOption);delay_check=_A
		for line in m3u8.splitlines():
			if delay_check==_B:
				delay_check=_A;vod_url=BASE_URL+line;vttDelay=0
				if playOption.get('play_resume')==_A:vttDelay=self.Check_DelayTime(vod_url)
				break
			elif line.startswith(_AA):delay_check=_B
		for line in m3u8.splitlines():
			if line.startswith(_A1):
				attribs=self.Disney_MediaLine_Parse(line,_A1)
				if attribs.get('TYPE')==_BT and attribs.get('FORCED')!='YES'and attribs.get('LANGUAGE')=='ko':return self.VTT_Make_Main(BASE_URL+attribs.get('URI'),vttDelay)
		return _B
	def Disney_Parse_m3u8(self,m3u8,defaultAudio,playOption):
		M='CHANNELS="{}"';L='NAME';K='AUDIO';J='sound_aac';I='maxResolution';H='atmos';G='eac-3';F='aac-64k';E='aac-128k';D='CHANNELS';C='sound_dd';B='RESOLUTION';A='GROUP-ID'
		try:
			exists_aac=_A;exists_dd=_A;exists_atoms=_A;max_res=0;max_resStr=''
			for line in m3u8.splitlines():
				if line.startswith(_A1):
					attribs=self.Disney_MediaLine_Parse(line,_A1)
					if attribs.get(A)in[E,F]:exists_aac=_B
					elif attribs.get(A)in[G]:exists_dd=_B
					elif attribs.get(A)in[H]:exists_atoms=_B
				elif line.startswith(_AA):
					attribs=self.Disney_MediaLine_Parse(line,_AA);i_resolution=int(attribs.get(B).split('x',1)[0])
					if i_resolution<=playOption[I]and i_resolution>max_res:max_res=i_resolution;max_resStr=attribs.get(B)
			if exists_atoms==_A and playOption[_AY]==_B:playOption[C]=_B
			if exists_atoms==_A and exists_dd==_A and playOption[C]==_B:playOption[J]=_B
		except Exception as exception:print(exception);pass
		Remove_AudioList=[]
		if not playOption[J]:Remove_AudioList.append(E);Remove_AudioList.append(F)
		if not playOption[C]:Remove_AudioList.append(G)
		if not playOption[_AY]:Remove_AudioList.append(H)
		res_lines=[]
		try:
			Skip_NextLine=_A;Before_Blank=_A
			for line in m3u8.splitlines():
				if not line.strip():
					if Before_Blank==_A:res_lines.append(line);Before_Blank=_B
					continue
				else:Before_Blank=_A
				if Skip_NextLine==_B:Skip_NextLine=_A;continue
				if line.startswith(_A1):
					attribs=self.Disney_MediaLine_Parse(line,_A1)
					if attribs.get('TYPE')==K:
						if attribs.get('LANGUAGE')not in['ko','en',defaultAudio]:continue
						if attribs.get(A)in Remove_AudioList:continue
						if'JOC'in attribs.get(D):line=line.replace('NAME="{}"'.format(attribs.get(L)),'NAME="{} [Atmos]"'.format(attribs.get(L)));line=line.replace(M.format(attribs.get(D)),M.format(attribs.get(D).split('/')[0]))
					elif attribs.get('TYPE')==_BT:continue
				elif line.startswith(_AA):
					attribs=self.Disney_MediaLine_Parse(line,_AA)
					if attribs.get(K)in Remove_AudioList:Skip_NextLine=_B;continue
					if attribs.get(B)!=max_resStr and playOption[I]:Skip_NextLine=_B;continue
				res_lines.append(line)
		except Exception as exception:print(exception);return
		return_value='\n'.join(res_lines)
		try:fp=open(self.DZ_M3U8_FILENAME,'w',-1,_U);fp.write(return_value);fp.close()
		except:
			if os.path.isfile(self.DZ_M3U8_FILENAME):os.remove(self.DZ_M3U8_FILENAME)
			return _A
	def DecodedFamilyId(self,familyId):
		url=self.Make_Endpoint(_B7,encodedFamilyId=familyId);response=self.HttpObj.Call_Request(url,params=_P,headers=_P,method=_J)
		if response.status_code!=200:return
		resJson=response.json().get(_F).get('DmcVideoBundle').get(_Am);return resJson.get(_Ao)
	def GetBookmarkInfo2(self,videoid,vidtype):
		G='heading';F='director';E='cast';D='plot';C='indexinfo';B='infoLabels';A='saveinfo';VIDEO_INFO={C:{'ott':'disney','videoid':videoid,'vidtype':vidtype,_AK:''},A:{_R:'','subtitle':'',_n:{_v:'',_A7:'',_A8:'','icon':'','banner':'',_A9:''},B:{'mediatype':vidtype,_R:'','mpaa':'',D:'',_AL:'','studio':'',_A6:0,E:[],F:[],_Ap:[],'premiered':'','country':''}}};url=_AO.format(self.API_DOMAIN_NEW,self.API_VERSION_NEW,videoid);headers=self.Make_Headers(accessToken=_B,Bearer=_B);params={_AP:_B,_AQ:15,_x:15};response=self.HttpObj.Call_Request(url,headers=headers,params=params,method=_J)
		if response.status_code not in[200,201]:return[]
		resJson=response.json().get(_F).get(_q);VIDEO_INFO[C][_AK]=resJson.get('deeplinkId');tmp_title=resJson[_D][_R];tmp_year=resJson[_D][_Y][_AN][_Ak];VIDEO_INFO[A][B][_R]=tmp_title
		if vidtype==_AM:tmp_title='%s (%s)'%(tmp_title,tmp_year)
		VIDEO_INFO[A][_R]=tmp_title;VIDEO_INFO[A][B][_AL]=tmp_year;VIDEO_INFO[A][B]['mpaa']=resJson[_D][_Y][_Aq]['rating']['text'];VIDEO_INFO[A][B][D]=resJson[_D][_i][_u]
		if vidtype==_AM:VIDEO_INFO[A][B][_A6]=int(resJson[_D][_Y]['runtime']['runtimeMs']/1000)
		for i_genre in resJson[_D][_Y][_Ar]['values']:VIDEO_INFO[A][B][_Ap].append(i_genre)
		for i_container in resJson[_g]:
			if i_container[_AI]!='details':continue
			for i_credit in i_container[_D]['credits']:
				if i_credit[G].startswith('감독'):
					for i_item in i_credit[_A3]:VIDEO_INFO[A][B][F].append(i_item[_As])
				if i_credit[G].startswith('출연'):
					for i_item in i_credit[_A3]:VIDEO_INFO[A][B][E].append(i_item[_As])
		imageJson=resJson[_D][_t][_A4];poster=self.Get_imageurl_parser2(imageJson,[_b],[_AR,_m,_AS]);clearlogo=self.Get_imageurl_parser2(imageJson,[_AJ],[_W]);thumb=self.Get_imageurl_parser2(imageJson,[_b],[_W,_A0]);fanart=self.Get_imageurl_parser2(imageJson,[_A5],[_W,_A0]);VIDEO_INFO[A][_n][_v]=poster;VIDEO_INFO[A][_n][_A7]=thumb;VIDEO_INFO[A][_n][_A8]=clearlogo;VIDEO_INFO[A][_n][_A9]=fanart;return VIDEO_INFO
	def Get_DeepLink_PageId(self,pageType):
		pageId=''
		try:
			url='{}/{}/deeplink?refId={}&refIdType=deeplinkId'.format(self.API_DOMAIN_NEW,self.API_VERSION_NEW,pageType);headers=self.Make_Headers(accessToken=_B,Bearer=_B);response=self.HttpObj.Call_Request(url,headers=headers,method=_J)
			if response.status_code not in[200,201]:return[]
			pageId=response.json().get(_F).get(_An).get(_O)[0].get(_s)
		except Exception as exception:print(exception);return''
		return pageId
	def Get_Catagory_Group(self,pageType):
		catagory_list=[];pageId=self.Get_DeepLink_PageId(pageType);print('pageId : '+pageId)
		try:
			url=_AO.format(self.API_DOMAIN_NEW,self.API_VERSION_NEW,pageId);headers=self.Make_Headers(accessToken=_B,Bearer=_B);params={_x:48,_AP:_B,_AQ:0};response=self.HttpObj.Call_Request(url,headers=headers,params=params,method=_J)
			if response.status_code not in[200,201]:return[]
			resJson=response.json()[_F][_q]
			for iContainer in resJson.get(_g):temp_list={_R:iContainer[_D][_A2],_BU:iContainer[_T]};catagory_list.append(temp_list)
		except Exception as exception:print(exception);return[]
		return catagory_list
	def Get_Container_List(self,pageType,pageId=''):
		container_list=[]
		if pageType=='brands':_P
		else:pageId=self.Get_DeepLink_PageId(pageType)
		try:
			url=_B9.format(self.API_DOMAIN_NEW,self.API_VERSION_NEW,pageId);headers=self.Make_Headers(accessToken=_B,Bearer=_B);response=self.HttpObj.Call_Request(url,headers=headers,method=_J)
			if response.status_code not in[200,201]:return[]
			resJson=response.json()[_F][_q]
			for iContainer in resJson.get(_g):
				if'params'not in iContainer:continue
				temp_list={_R:iContainer[_D][_A2],_BU:iContainer[_T]};container_list.append(temp_list)
		except Exception as exception:print(exception);return[]
		return container_list
	def Get_Program_List(self,containerId,page_int):
		program_list=[];more_page=_A
		try:
			url='{}/{}/set/{}'.format(self.API_DOMAIN_NEW,self.API_VERSION_NEW,containerId);headers=self.Make_Headers(accessToken=_B,Bearer=_B);params={_x:self.ONE_PAGE,'offset':(page_int-1)*self.ONE_PAGE};response=self.HttpObj.Call_Request(url,headers=headers,params=params,method=_J)
			if response.status_code not in[200,201]:return[]
			resJson=response.json()[_F]['set']
			for iItem in resJson.get(_A3):
				if _BB in iItem[_D]:vType=_Aj;duration=0
				elif _w in iItem[_D]:vType=_AM;duration=int(iItem[_D][_w]/1000)
				elif iItem[_O][0][_s].startswith('page-'):vType='collection';duration=0
				else:vType=_Aj;duration=0
				genre_list=[];year=0;mpaa=''
				if _Y in iItem[_D]:
					if _Ar in iItem[_D][_Y]:
						for igenre in iItem[_D][_Y][_Ar]['values']:genre_list.append(igenre)
					if _AN in iItem[_D][_Y]:
						year=iItem[_D][_Y][_AN][_Ak]
						if _Aq in iItem[_D][_Y]:mpaa=iItem[_D][_Y][_Aq]['rating']['text']
				desc=''
				if _i in iItem[_D]:desc=iItem[_D][_i][_u]
				imageJson=iItem[_D][_t][_A4];poster=self.Get_imageurl_parser2(imageJson,[_b],[_AR,_m,_AS]);clearlogo=self.Get_imageurl_parser2(imageJson,[_AJ],[_W]);thumb=self.Get_imageurl_parser2(imageJson,[_b],[_W,_A0]);fanart=self.Get_imageurl_parser2(imageJson,[_A5,_b],[_W,_A0]);tempActions=[];delInfoBlock=''
				if len(iItem[_O])>1:
					for iEliment in iItem[_O]:
						if _O in iEliment:tempActions=iEliment;break
					if tempActions[_O]:
						for iAction in tempActions[_O]:
							if iAction[_D][_As]=='삭제':delInfoBlock=iAction['infoBlock'];break
				temp_list={_R:iItem[_D][_R],_AK:iItem[_O][0][_s],'vType':vType,_Ap:genre_list,'synopsis':desc,_A6:duration,'mpaa':mpaa,_AL:year,_n:{_v:poster,_A7:thumb,_A8:clearlogo,_A9:fanart},'delInfoBlock':delInfoBlock};program_list.append(temp_list)
			more_page=resJson[_Al]['hasMore']
		except Exception as exception:print(exception);return[],_A
		return program_list,more_page
	def Image_IdtoUrl(self,imageId):imageServer='https://disney.images.edge.bamgrid.com';imageUrl='{}/ripcut-delivery/v2/variant/disney/{}/compose'.format(imageServer,imageId);return imageUrl
	def entityId_to_contentId(self,entityId):
		playId={_Ao:'',_y:'',_z:''}
		try:
			url=_AO.format(self.API_DOMAIN_NEW,self.API_VERSION_NEW,entityId);headers=self.Make_Headers(accessToken=_B,Bearer=_B);params={_AP:_B,_AQ:self.ONE_PAGE,_x:self.ONE_PAGE};response=self.HttpObj.Call_Request(url,headers=headers,params=params,method=_J)
			if response.status_code not in[200,201]:return playId
			resJson=response.json()[_F][_q];playId={_Ao:resJson.get(_O)[0].get('partnerFeed').get(_BS,''),_y:resJson.get(_O)[0].get(_y,''),_z:resJson.get(_O)[0].get(_z,'')}
		except Exception as exception:print(exception);return playId
		return playId
	def WebCookies_Load(self,wc_file):
		try:fp=open(wc_file,'r',-1,_U);wc_string=fp.read();fp.close();json_string=self.Web_DecryptPlaintext(wc_string);self.DZ=json.loads(json_string)
		except:return _A
		return _B
	def Web_DecryptKey(self):enckey=bytes('kss2lym0kdw1lks3',_U);vector=bytes('6yhlJ4WF9ZIj6I8n',_U);return enckey,vector
	def Web_DecryptPlaintext(self,ciphertext):encryption_key,init_vector=self.Web_DecryptKey();cipher=AES.new(encryption_key,AES.MODE_CBC,init_vector);plaintext=Padding.unpad(cipher.decrypt(base64.standard_b64decode(ciphertext)),16);return plaintext.decode(_U)