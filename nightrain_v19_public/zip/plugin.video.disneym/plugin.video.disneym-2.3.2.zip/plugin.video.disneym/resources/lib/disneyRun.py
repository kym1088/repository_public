_Aa='DELETE_WATCH'
_AZ='VIEW_DETAIL'
_AY='pageType  : {}'
_AX='vidtype = {}'
_AW='videoid = {}'
_AV='Dialog.Close(all,true)'
_AU='[B]%s >>[/B]'
_AT='seasonNum'
_AS='(통합) 찜 영상에 추가'
_AR='token_limit'
_AQ='Container.Refresh'
_AP='delete.png'
_AO='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
_AN='검색목록 전체를 삭제합니다.'
_AM='play_resume'
_AL='vttFilename'
_AK='search_history.png'
_AJ='LOCAL_SEARCH_HIST'
_AI='search.png'
_AH='BRAND_GROUP'
_AG='genres'
_AF='delInfoBlock'
_AE='availId'
_AD='resourceId'
_AC='EPISODE_LIST'
_AB='tvshows'
_AA='WATCH_ALL'
_A9='WATCH_ONE'
_A8='WATCHED_REMOVE'
_A7='SEARCH_ALL'
_A6='SEARCH_ONE'
_A5='LOCAL_SEARCH_REMOVE'
_A4='search_key'
_A3='LOCAL_SEARCH_LIST'
_A2='CATAGORY_GROUP'
_A1='PROGRAM_LIST'
_A0='pageId'
_z='thumbnail'
_y='seasonId'
_x='SET_BOOKMARK'
_w='clearlogo'
_v='thumb'
_u='fanart'
_t='year'
_s='utf-8'
_r='ALL'
_q='MENU_BOOKMARK'
_p='TOTAL_HISTORY'
_o='WATCHED_LIST'
_n='vidtype'
_m='videoid'
_l='SEASON_LIST'
_k='MOVIE'
_j='img'
_i='path'
_h='delType'
_g='TOTAL_SEARCH'
_f='DEEPLINK_PAGE'
_e='containerId'
_d='duration'
_c='VOD'
_b='RunPlugin(plugin://plugin.video.disneym/?params=%s)'
_a='collection'
_Z='page_int'
_Y='%2B'
_X='+'
_W='poster'
_V='sKey'
_U='mediatype'
_T='pageType'
_S='icon'
_R='programTitle'
_Q='plot'
_P='-'
_O='movie'
_N='image'
_M='true'
_L='tvshow'
_K='FOLDER'
_J='infoLabels'
_I='utf8'
_H='vType'
_G='entityId'
_F=None
_E=True
_D=False
_C='values'
_B='title'
_A='mode'
__author__='NightRain'
import inputstreamhelper,sys
from kodiFunc import*
from disneyCore import*
__addon__=xbmcaddon.Addon()
__language__=__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
MAIN_GROUP=[{_B:'홈',_A:_f,_S:'home.png',_C:{_T:'home'}},{_B:'오리지널',_A:_f,_C:{_T:'originals'}},{_B:'브랜드별',_A:_AH},{_B:'영화',_A:_A2,_C:{_T:'movies'}},{_B:'시리즈',_A:_A2,_C:{_T:'series'}},{_B:'-----------------',_A:'XXX',_C:{}},{_B:'Watched (시청목록)',_A:_o,_S:'history.png',_C:{_H:_P}},{_B:'(디즈니) 검색',_A:_A3,_S:_AI,_C:{}},{_B:'(디즈니) 검색기록',_A:_AJ,_S:_AK,_C:{}},{_B:'통합검색(웨이브,티빙,왓챠,쿠팡,넷플)',_A:_g,_S:_AI,_C:{}},{_B:'통합검색(웨이브,티빙,왓챠,쿠팡,넷플) 기록',_A:_p,_S:_AK,_C:{}},{_B:'통합 찜 목록 (bookmark mini)',_A:_q,_S:'bookmark.png',_C:{}}]
WATCH_GROUP=[{_B:'영화 시청내역',_A:_o,_C:{_H:_O}},{_B:'시리즈 시청내역',_A:_o,_C:{_H:_L}}]
class DisneyRun:
	def __init__(self,in_addonurl,in_handle,in_params,in_resume):
		self.ADDON_URL=in_addonurl;self.ADDON_HANDLE=in_handle;self.MAIN_PARAMS=in_params;self.PLAY_RESUME=in_resume;self.KFuncObj=KodiFunc(in_addonurl,in_handle);self.DisneyObj=Disney();self.DisneyObj.DZ_COOKIES_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'dz_cookies.json'));self.DisneyObj.DZ_SEARCHED_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'dz_searched.json'));self.DisneyObj.DZ_WATCHED_MOVIE=xbmcvfs.translatePath(os.path.join(__profile__,'dz_watched_movie.json'));self.DisneyObj.DZ_WATCHED_VOD=xbmcvfs.translatePath(os.path.join(__profile__,'dz_watched_vod.json'));self.DisneyObj.DZ_VTT_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'dz_subtitles.vtt'));self.DisneyObj.DZ_M3U8_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'dz_play.m3u8'))
		if xbmc.getCondVisibility('system.platform.android'):self.DisneyObj.OS_ANDROID=_E
	def get_settings_totalsearch(self):local_search=_E if __addon__.getSetting('local_search')==_M else _D;local_history=_E if __addon__.getSetting('local_history')==_M else _D;total_search=_E if __addon__.getSetting('total_search')==_M else _D;total_history=_E if __addon__.getSetting('total_history')==_M else _D;menu_bookmark=_E if __addon__.getSetting('menu_bookmark')==_M else _D;return local_search,local_history,total_search,total_history,menu_bookmark
	def get_settings_makebookmark(self):return _E if __addon__.getSetting('make_bookmark')==_M else _D
	def get_settings_account(self):dzid=__addon__.getSetting('id');dzpw=__addon__.getSetting('pw');dzpf=int(__addon__.getSetting('profile'));return dzid,dzpw,dzpf
	def get_settings_proxyport(self):return int(__addon__.getSetting('proxyPort'))
	def get_settings_proxyyn(self):return _E if __addon__.getSetting('proxyyn')==_M else _D
	def get_settings_playback(self):
		H='wv_secure';G='sound_dd';F='maxResolution';E='video_dolby';D='video_hdr';C='video_h265';B='sound_atmos';A='sound_aac';DrmLevel=self.KFuncObj.Get_Drm_Level();res_list={'0':1920,'1':2560,'2':3840};playOption={H:_E,C:_E if __addon__.getSetting(C)==_M else _D,D:_E if __addon__.getSetting(D)==_M else _D,E:_E if __addon__.getSetting(E)==_M else _D,F:res_list.get(__addon__.getSetting(F)),A:_E if __addon__.getSetting(A)==_M else _D,G:_E if __addon__.getSetting(G)==_M else _D,B:_E if __addon__.getSetting(B)==_M else _D,_AL:self.DisneyObj.DZ_VTT_FILENAME,'m3u8Filename':self.DisneyObj.DZ_M3U8_FILENAME,_AM:self.PLAY_RESUME}
		if playOption[H]==_D or playOption[C]==_D:playOption[B]=_D;playOption[D]=_D;playOption[E]=_D;playOption[F]=res_list.get('0')
		if not playOption[A]and not playOption[G]and not playOption[B]:playOption[A]=_E
		return playOption
	def Searched_Save(self,sKey):HistoryFile_Insert(self.DisneyObj.DZ_SEARCHED_FILENAME,sKey)
	def Searched_Load(self):return HistoryFile_Load(self.DisneyObj.DZ_SEARCHED_FILENAME)
	def Searched_Remove(self,delType,sKey=_P):
		if delType==_r:File_Delete(self.DisneyObj.DZ_SEARCHED_FILENAME)
		else:HistoryFile_Remove(self.DisneyObj.DZ_SEARCHED_FILENAME,sKey=sKey)
	def Watched_Save(self,vType,sKey,sValue):
		if vType==_O:fileName=self.DisneyObj.DZ_WATCHED_MOVIE
		else:fileName=self.DisneyObj.DZ_WATCHED_VOD
		HistoryFile_Insert(fileName,sKey,sValue=sValue)
	def Watched_Load(self,vType):
		if vType==_O:fileName=self.DisneyObj.DZ_WATCHED_MOVIE
		else:fileName=self.DisneyObj.DZ_WATCHED_VOD
		return HistoryFile_Load(fileName)
	def Watched_Remove(self,delType,vType,sKey=_P):
		if vType==_O:fileName=self.DisneyObj.DZ_WATCHED_MOVIE
		else:fileName=self.DisneyObj.DZ_WATCHED_VOD
		if delType==_r:File_Delete(fileName)
		else:HistoryFile_Remove(fileName,sKey=sKey)
	def dp_Local_SearchHist(self,argsValue):
		SEARCH_HISTORY=self.Searched_Load()
		for search_history in SEARCH_HISTORY:sKey=search_history.get(_V);params={_A:_A3,_C:{_A4:sKey}};menu_param={_A:_A5,_C:{_h:_A6,_V:sKey}};menu_param_str=Params_JsonToStr(menu_param);ContextMenu=[('선택된 검색어 ( %s ) 삭제'%sKey,_b%menu_param_str)];infoLabels={_Q:'개별삭제는 팝업메뉴 사용'};self.KFuncObj.Add_Dir(sKey,subTitle='',img=_F,infoLabels=infoLabels,isType=_K,ContextMenu=ContextMenu,params=params)
		infoLabels={_Q:_AN};title=_AO;params={_A:_A5,_C:{_h:_A7,_V:_P}};icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo(_i),_j,_AP);self.KFuncObj.Add_Dir(title,subTitle='',img=icon_img,infoLabels=infoLabels,isType=_K,ContextMenu=_F,params=params);xbmcplugin.endOfDirectory(self.ADDON_HANDLE,cacheToDisc=_D)
	def dp_Watched_List(self,argsValue):
		vType=argsValue.get(_H)
		if vType==_P:
			for watch_group in WATCH_GROUP:title=watch_group.get(_B);params={_A:watch_group.get(_A),_C:watch_group.get(_C)};self.KFuncObj.Add_Dir(title,subTitle='',img=_F,infoLabels=_F,isType=_K,ContextMenu=_F,params=params)
			xbmcplugin.endOfDirectory(self.ADDON_HANDLE,cacheToDisc=_E)
		else:
			WATCHLIST=self.Watched_Load(vType)
			for watchlist in WATCHLIST:
				sKey=watchlist.get(_V);sValue=watchlist.get('sValue');title=sValue.get(_B);programTitle=sValue.get(_R);image=sValue.get(_N);infoLabels=sValue.get(_J);entityId=sValue.get(_G);vType=sValue.get(_H)
				if vType==_O:params={_A:_k,_C:{_G:entityId,_B:title,_N:image,_J:infoLabels,_H:vType}};isType=_c;disTitle=title;disSub=''
				elif vType==_L and entityId not in[_F,'']:params={_A:_l,_C:{_G:entityId,_R:programTitle,_B:title,_N:image,_J:infoLabels,_H:vType}};isType=_K;disTitle=programTitle;disSub=title
				"\n\t\t\t\telse:\n\t\t\t\t\tparams = {\n\t\t\t\t\t\t\t\t'mode'   : 'SEASON_LIST',\n\t\t\t\t\t\t\t\t'values'  : {\n\t\t\t\t\t\t\t\t\t\t\t\t'encodedId'    : encodedId,\n\t\t\t\t\t\t\t\t\t\t\t\t'contentClass' : contentClass,\n\t\t\t\t\t\t\t\t\t\t\t\t'contentSlugs' : contentSlugs,\n\t\t\t\t\t\t\t\t\t\t\t\t'programTitle' : programTitle,\n\t\t\t\t\t\t\t\t\t\t\t\t'title'        : title,\n\t\t\t\t\t\t\t\t\t\t\t\t'image'        : image,\n\t\t\t\t\t\t\t\t\t\t\t\t'infoLabels'   : infoLabels,\n\t\t\t\t\t\t\t\t\t\t\t\t'vType'        : vType,\n\t\t\t\t\t\t\t\t}\n\t\t\t\t\t}\n\t\t\t\t\tisType = 'FOLDER'\n\n\t\t\t\t\tif vType == 'single':\n\t\t\t\t\t\tdisTitle = title\n\t\t\t\t\t\tdisSub   = '' \n\t\t\t\t\telse:\n\t\t\t\t\t\tdisTitle = programTitle\n\t\t\t\t\t\tdisSub   = title \n\t\t\t\t";menu_param={_A:_A8,_C:{_h:_A9,_V:sKey,_H:vType}};menu_param_str=Params_JsonToStr(menu_param);ContextMenu=[('선택된 시청이력 ( %s ) 삭제'%disTitle,_b%menu_param_str)];self.KFuncObj.Add_Dir(disTitle,subTitle=disSub,img=image,infoLabels=infoLabels,isType=isType,ContextMenu=ContextMenu,params=params)
			infoLabels={_Q:_AN};title=_AO;params={_A:_A8,_C:{_h:_AA,_V:_P,_H:vType}};icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo(_i),_j,_AP);self.KFuncObj.Add_Dir(title,subTitle='',img=icon_img,infoLabels=infoLabels,isType=_K,ContextMenu=_F,params=params);xbmcplugin.setContent(self.ADDON_HANDLE,'movies');xbmcplugin.endOfDirectory(self.ADDON_HANDLE,cacheToDisc=_D)
	def dp_History_Remove(self,argsValue):
		A='ONE';delType=argsValue.get(_h);sKey=argsValue.get(_V);vType=argsValue.get(_H);dialog=xbmcgui.Dialog()
		if delType==_A7:ret=dialog.yesno(__language__(30911).encode(_I),__language__(30903).encode(_I))
		elif delType==_A6:ret=dialog.yesno(__language__(30912).encode(_I),__language__(30903).encode(_I))
		elif delType==_AA:ret=dialog.yesno(__language__(30913).encode(_I),__language__(30903).encode(_I))
		elif delType==_A9:ret=dialog.yesno(__language__(30914).encode(_I),__language__(30903).encode(_I))
		if ret==_D:sys.exit()
		if delType==_A7:self.Searched_Remove(_r,sKey=_P)
		elif delType==_A6:self.Searched_Remove(A,sKey=sKey)
		elif delType==_AA:self.Watched_Remove(_r,vType=vType,sKey=_P)
		elif delType==_A9:self.Watched_Remove(A,vType=vType,sKey=sKey)
		xbmc.executebuiltin(_AQ)
	def dp_Main_List(self):
		local_search,local_history,total_search,total_history,menu_bookmark=self.get_settings_totalsearch()
		for main_group in MAIN_GROUP:
			if main_group.get(_A)=='LOCAL_SEARCH'and local_search==_D:continue
			elif main_group.get(_A)=='SEARCH_HISTORY'and local_history==_D:continue
			elif main_group.get(_A)==_g and total_search==_D:continue
			elif main_group.get(_A)==_p and total_history==_D:continue
			elif main_group.get(_A)==_q and menu_bookmark==_D:continue
			title=main_group.get(_B);icon_img=_F;params={_A:main_group.get(_A),_C:main_group.get(_C)}
			if main_group.get(_A)in['XXX',_g,_p,_q]:isType='LINK'
			else:isType=_K
			infoLabels={_B:title,_Q:title}
			if main_group.get(_A)=='XXX':infoLabels=_F
			if _S in main_group:icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo(_i),_j,main_group.get(_S))
			self.KFuncObj.Add_Dir(title,subTitle='',img=icon_img,infoLabels=infoLabels,isType=isType,ContextMenu=_F,params=params)
		xbmcplugin.endOfDirectory(self.ADDON_HANDLE)
	def login_main(self):
		dzid,dzpw,dzpf=self.get_settings_account()
		if dzid==''or dzpw=='':
			dialog=xbmcgui.Dialog();ret=dialog.yesno(__language__(30921).encode(_I),__language__(30922).encode(_I))
			if ret==_E:__addon__.openSettings();sys.exit()
			else:sys.exit()
		if self.cookiefile_check()==_E:
			if Get_TimeStamp()>self.DisneyObj.DZ['account'][_AR]:
				if self.DisneyObj.DZ_Login_ReToken()==_D:self.KFuncObj.Addon_Noti(__language__(30923).encode(_I));sys.exit()
		else:
			dialog=xbmcgui.Dialog();wc_file=dialog.browse(1,__language__(30918).encode(_I),'','.twc',_D,_D,'',_D)
			if wc_file!='':
				tempFile=xbmcvfs.translatePath(os.path.join(__profile__,'disneyinfo-temp.twc'));xbmcvfs.copy(wc_file,tempFile);loginResult=self.DisneyObj.WebCookies_Load(tempFile);xbmcvfs.delete(tempFile)
				if loginResult:JsonFile_Save(self.DisneyObj.DZ_COOKIES_FILENAME,self.DisneyObj.DZ);self.KFuncObj.Addon_Noti(__language__(30919).encode(_I));return
			else:self.KFuncObj.Addon_Noti(__language__(30923).encode(_I));sys.exit()
	def cookiefile_check(self):
		self.DisneyObj.DZ=JsonFile_Load(self.DisneyObj.DZ_COOKIES_FILENAME);cf_id,cf_pw,cf_pf=self.get_settings_account();ck_id,ck_pw,ck_pf=self.DisneyObj.Load_session_acount()
		if(cf_id!=ck_id or cf_pw!=ck_pw or cf_pf!=ck_pf)and ck_id!='xxxxx':self.DisneyObj.Init_DZ_Total();return _D
		return _E
	def DZ_logout(self):
		dialog=xbmcgui.Dialog();ret=dialog.yesno(__language__(30925).encode(_I),__language__(30903).encode(_I))
		if ret==_D:return
		File_Delete(self.DisneyObj.DZ_COOKIES_FILENAME);self.KFuncObj.Addon_Noti(__language__(30924).encode(_s))
	def dp_Local_SearchList(self,argsValue):
		if _A4 in argsValue:search_key=argsValue.get(_A4)
		else:
			search_key=self.KFuncObj.Get_Keyboard_Input(__language__(30902).encode(_s))
			if not search_key:return
			self.Searched_Save(search_key)
		RES_LIST=self.DisneyObj.Get_Search_List(search_key)
		for i_res in RES_LIST:
			title=i_res.get(_B);vType=i_res.get(_H);entityId=i_res.get(_G);year=i_res.get(_t);duration=i_res.get(_d);desc=i_res.get('desc');image={_W:i_res.get(_W),_u:i_res.get(_u),_v:i_res.get(_v),_w:i_res.get(_w)}
			if vType in[_L]:mode=_l;mediatype=_L;isType=_K
			elif vType==_O:mode=_k;mediatype=_O;isType=_c
			else:mode=_P;isType=_K;title='check '
			infoLabels={_U:mediatype,_B:title,_d:duration,_t:year,_Q:desc};params={_A:mode,_C:{_R:title,_B:title,_G:entityId,_J:infoLabels,_N:image,_H:vType}}
			if self.get_settings_makebookmark():bm_param={_A:_x,_C:{_m:entityId,_n:vType,_B:title}};param_str=Params_JsonToStr(bm_param);param_str=param_str.replace(_X,_Y);bookmark_url=_b%param_str;ContextMenu=[(_AS,bookmark_url)]
			else:ContextMenu=_F
			self.KFuncObj.Add_Dir(title,subTitle='',img=image,infoLabels=infoLabels,isType=isType,ContextMenu=ContextMenu,params=params)
		xbmcplugin.setContent(self.ADDON_HANDLE,_AB);xbmcplugin.endOfDirectory(self.ADDON_HANDLE,cacheToDisc=_E)
	def dp_Season_List(self,argsValue):
		programTitle=argsValue.get(_R);entityId=argsValue.get(_G)or'';self.KFuncObj.Addon_Log('dp_Season_List entityId  = {}'.format(entityId));RES_LIST=self.DisneyObj.Get_Season_List2(entityId)
		for i_res in RES_LIST:seasonId=i_res.get(_y);seasonNum=i_res.get(_AT);episodeCnt=i_res.get('episodeCnt');desc=i_res.get('desc');image={_W:i_res.get(_W)};title='{} : 시즌 {}'.format(programTitle,seasonNum)if'시즌'not in str(seasonNum)else'{} : {}'.format(programTitle,seasonNum);infoLabels={_U:'season',_Q:'에피소드 {}개\n\n{}'.format(episodeCnt,desc)};params={_A:_AC,_C:{_G:entityId,_y:seasonId,_Z:1}};self.KFuncObj.Add_Dir(title,subTitle='',img=image,infoLabels=infoLabels,isType=_K,ContextMenu=_F,params=params)
		xbmcplugin.setContent(self.ADDON_HANDLE,_AB);xbmcplugin.endOfDirectory(self.ADDON_HANDLE,cacheToDisc=_E)
	def dp_Episode_List(self,argsValue):
		B='episode';A='tvshowtitle';entityId=argsValue.get(_G);seasonId=argsValue.get(_y);page_int=argsValue.get(_Z);self.KFuncObj.Addon_Log('dp_Episode_List seasonId = {}'.format(seasonId));RES_LIST,more_page=self.DisneyObj.Get_Episode_List(seasonId,page_int)
		for i_res in RES_LIST:resourceId=i_res.get(_AD);availId=i_res.get(_AE);title=i_res.get(_B);tvshowtitle=i_res.get(A);desc=i_res.get('desc');duration=i_res.get(_d);seasonNum=i_res.get(_AT);episodeNum=i_res.get('episodeNum');image={_u:i_res.get(_u),_v:i_res.get(_v),_W:i_res.get(_W),_w:i_res.get(_w)};infoLabels={_U:B,_B:title,A:tvshowtitle,_Q:desc,_d:duration,'season':seasonNum,B:episodeNum};dis_title='{}x{:0>2}. {}'.format(seasonNum,episodeNum,title);params={_A:_c,_C:{_AD:resourceId,_AE:availId,_B:dis_title,_R:tvshowtitle,_G:entityId,_N:image,_J:infoLabels,_H:_L}};self.KFuncObj.Add_Dir(dis_title,subTitle='',img=image,infoLabels=infoLabels,isType=_c,ContextMenu=_F,params=params)
		if more_page:title=_AU%'다음 페이지';params={_A:_AC,_C:{_G:entityId,_y:seasonId,_Z:page_int+1}};subtitle=str(page_int+1);icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo(_i),_j,'next.png');self.KFuncObj.Add_Dir(title,subTitle=subtitle,img=icon_img,infoLabels=_F,isType=_K,ContextMenu=_F,params=params)
		xbmcplugin.setContent(self.ADDON_HANDLE,'episodes');xbmcplugin.endOfDirectory(self.ADDON_HANDLE,cacheToDisc=_E)
	def play_VIDEO(self,argsValue):
		C='com.widevine.alpha';B='hls';A='defaultAudio';playOption=self.get_settings_playback();entityId=argsValue.get(_G);vType=argsValue.get(_H);self.KFuncObj.Addon_Log('play_VIDEO 2.entityId   = {}'.format(entityId));playId=self.DisneyObj.entityId_to_contentId(entityId);resourceId=playId.get(_AD);availId=playId.get(_AE);self.KFuncObj.Addon_Log('play_VIDEO 33.resourceId = {}'.format(resourceId));self.KFuncObj.Addon_Log('play_VIDEO 44.availId    = {}'.format(availId));streamInfo=self.DisneyObj.GetStreamingURL(resourceId,availId,playOption);"\n\t\tif resourceId:\n\t\t\tstreamInfo   = self.DisneyObj.GetStreamingURL( resourceId, availId, playOption )\n\t\telse:\n\t\t\tplayId       = self.DisneyObj.entityId_to_contentId( entityId )\n\t\t\tself.KFuncObj.Addon_Log( 'play_VIDEO 1.contentId  = {}'.format( playId.get('contentId') ) )\t\t\n\t\t\t#streamInfo   = self.DisneyObj.GetStreamingURL2( playId.get('contentId'), playOption )\n\t\t\tstreamInfo   = self.DisneyObj.GetStreamingURL( playId.get('resourceId'), playId.get('availId'), playOption )\n\t\t";streamUrl=streamInfo.get('streamUrl');drmUrl=streamInfo.get('drmUrl');defaultAudio=streamInfo.get(A);self.KFuncObj.Addon_Log('streamUrl    : {}'.format(streamUrl));self.KFuncObj.Addon_Log('resume       : {}'.format(playOption.get(_AM)))
		if streamUrl in['',_F]:
			if drmUrl!='':self.KFuncObj.Addon_Noti(drmUrl)
			else:self.KFuncObj.Addon_Noti(__language__(30901).encode(_I))
			return
		raw_headers=self.DisneyObj.Make_Headers(accessToken=_E,Bearer=_D);raw_headers['content-type']='application/octet-stream';raw_headers['user-agent']=self.DisneyObj.HttpObj.USER_AGENT;LICENSE_KEY=drmUrl+'|'+urllib.parse.urlencode(raw_headers)+'|R{SSM}|';stream_headers=make_stream_header(raw_headers,_F);proxyHeader={'addon':'disneym',A:defaultAudio,'playOption':playOption};proxyHeader=Params_JsonToStr(proxyHeader);self.KFuncObj.Addon_Log('proxyHeader    : {}'.format(proxyHeader));proxyPort=self.get_settings_proxyport();proxyUse=self.get_settings_proxyyn()
		if proxyUse:streamUrl='http://127.0.0.1:{}/{}|proxy-mini={}'.format(proxyPort,streamUrl,proxyHeader)
		self.KFuncObj.Addon_Log(streamUrl);item=xbmcgui.ListItem(path=streamUrl);inputstreamhelper.Helper(B,drm=C).check_inputstream();item.setProperty('inputstream','inputstream.adaptive')
		if self.DisneyObj.KodiVersion<=20:item.setProperty('inputstream.adaptive.manifest_type',B)
		item.setProperty('inputstream.adaptive.license_type',C);item.setProperty('inputstream.adaptive.license_key',LICENSE_KEY);item.setProperty('inputstream.adaptive.stream_headers',stream_headers);item.setProperty('inputstream.adaptive.manifest_headers',stream_headers);item.setProperty('inputstream.adaptive.original_audio_language',defaultAudio);item.setMimeType('application/x-mpegURL');item.setContentLookup(_D)
		if proxyUse:item.setSubtitles([playOption[_AL]])
		xbmcplugin.setResolvedUrl(self.ADDON_HANDLE,_E,item)
		try:
			if vType in[_O,_L]:
				if vType==_O:sKey=entityId;sValue={_G:entityId,_B:argsValue.get(_B),_N:argsValue.get(_N),_J:argsValue.get(_J),_H:vType}
				elif vType==_L:argsValue[_J][_U]=_L;sKey=argsValue.get(_G);sValue={_G:argsValue.get(_G),_B:argsValue.get(_B),_R:argsValue.get(_R),_N:argsValue.get(_N),_J:argsValue.get(_J),_H:vType}
				self.Watched_Save(vType,sKey,sValue)
		except:_F
	def DZ_ReToken(self):
		try:
			self.DisneyObj.DZ=JsonFile_Load(self.DisneyObj.DZ_COOKIES_FILENAME)
			if Get_TimeStamp()>self.DisneyObj.DZ['account'][_AR]:
				if self.DisneyObj.DZ_Login_ReToken()==_D:return _D
		except:return _D
		return _E
	def dp_Global_Search(self,mode):
		if mode==_g:ott_url='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
		else:ott_url='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
		xbmc.executebuiltin(_AV);xbmc.executebuiltin(ott_url)
	def dp_Bookmark_Menu(self):ott_url='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)';xbmc.executebuiltin(_AV);xbmc.executebuiltin(ott_url)
	def dp_Set_Bookmark(self,argsValue):
		videoid=argsValue.get(_m);vidtype=argsValue.get(_n);title=argsValue.get(_B);col_info=argsValue.get('col_info');dialog=xbmcgui.Dialog();ret=dialog.yesno(__language__(30915).encode(_I),title+' \n\n'+__language__(30916))
		if ret==_D:return
		self.KFuncObj.Addon_Log(_AW.format(videoid));self.KFuncObj.Addon_Log(_AX.format(vidtype))
		if vidtype==_a:VIDEO_INFO=col_info
		else:VIDEO_INFO=self.DisneyObj.GetBookmarkInfo2(videoid,vidtype)
		params={_A:_x,_C:{'VIDEO_INFO':VIDEO_INFO}};param_str=Params_JsonToStr(params);param_str=param_str.replace(_X,_Y);bookmark_url='RunPlugin(plugin://plugin.video.bookmarkm/?params=%s)'%param_str;xbmc.executebuiltin(bookmark_url)
	def dp_Delete_Watch(self,argsValue):
		title=argsValue.get(_B);delInfoBlock=argsValue.get(_AF);dialog=xbmcgui.Dialog();ret=dialog.yesno(__language__(30917).encode(_I),title+' \n\n'+__language__(30903))
		if ret==_D:return
		self.KFuncObj.Addon_Log('delete_watch({}) : {}'.format(title,delInfoBlock))
		if self.DisneyObj.Delete_Watch_List(delInfoBlock)==_D:self.KFuncObj.Addon_Noti('삭제 오류');return
		self.KFuncObj.Addon_Noti('삭제중... 잠시 기다려주세요~~');xbmc.sleep(2000);xbmc.executebuiltin(_AQ)
	def dp_View_Detail(self,argsValue):
		D='IsPlayable';C='plugin://plugin.video.disneym/?params=%s';B='indexinfo';A='saveinfo';videoid=argsValue.get(_m);vidtype=argsValue.get(_n);self.KFuncObj.Addon_Log(_AW.format(videoid));self.KFuncObj.Addon_Log(_AX.format(vidtype));VIDEO_INFO=self.DisneyObj.GetBookmarkInfo2(videoid,vidtype)
		if vidtype==_L:ott_param={_A:_l,_C:{_G:VIDEO_INFO[B][_G],_H:vidtype,_N:VIDEO_INFO[A][_z],_B:VIDEO_INFO[A][_B],_R:VIDEO_INFO[A][_B],_J:VIDEO_INFO[A][_J]}};ott_param_str=json.dumps(ott_param,separators=(',',':'));ott_param_str=base64.standard_b64encode(ott_param_str.encode()).decode(_s);ott_param_str=ott_param_str.replace(_X,_Y);ott_url=C%ott_param_str
		else:ott_param={_A:_k,_C:{_G:VIDEO_INFO[B][_G],_H:vidtype,_N:VIDEO_INFO[A][_z],_B:VIDEO_INFO[A][_J][_B],_R:VIDEO_INFO[A][_J][_B],_J:VIDEO_INFO[A][_J]}};ott_param_str=json.dumps(ott_param,separators=(',',':'));ott_param_str=base64.standard_b64encode(ott_param_str.encode()).decode(_s);ott_param_str=ott_param_str.replace(_X,_Y);ott_url=C%ott_param_str
		listitem=xbmcgui.ListItem(label=VIDEO_INFO[A][_B],path=ott_url);listitem.setArt(VIDEO_INFO[A][_z]);listitem.setInfo('Video',VIDEO_INFO[A][_J])
		if vidtype==_O:listitem.setIsFolder(_D);listitem.setProperty(D,_M)
		else:listitem.setIsFolder(_E);listitem.setProperty(D,'false')
		dialog=xbmcgui.Dialog();dialog.info(listitem)
	def dp_DeepLink_Page(self,argsValue):
		pageType=argsValue.get(_T);pageId=argsValue.get(_A0);self.KFuncObj.Addon_Log(_AY.format(str(pageType)));self.KFuncObj.Addon_Log('pageId    : {}'.format(str(pageId)))
		if pageType==_a:pageType=pageId
		RES_LIST=self.DisneyObj.Get_Container_List(pageType,pageId)
		for i_res in RES_LIST:title=i_res.get(_B);containerId=i_res.get(_e);infoLabels={_U:_L,_Q:title};params={_A:_A1,_C:{_e:containerId,_Z:1}};self.KFuncObj.Add_Dir(title,subTitle='',img=_F,infoLabels=infoLabels,isType=_K,ContextMenu=_F,params=params)
		xbmcplugin.setContent(self.ADDON_HANDLE,_AG);xbmcplugin.endOfDirectory(self.ADDON_HANDLE,cacheToDisc=_E)
	def dp_Catagory_Group(self,argsValue):
		pageType=argsValue.get(_T);self.KFuncObj.Addon_Log(_AY.format(str(pageType)));RES_LIST=self.DisneyObj.Get_Catagory_Group(pageType)
		for i_res in RES_LIST:title=i_res.get(_B);containerId=i_res.get(_e);infoLabels={_U:_L,_Q:title};params={_A:_A1,_C:{_e:containerId,_Z:1}};self.KFuncObj.Add_Dir(title,subTitle='',img=_F,infoLabels=infoLabels,isType=_K,ContextMenu=_F,params=params)
		xbmcplugin.setContent(self.ADDON_HANDLE,_AG);xbmcplugin.endOfDirectory(self.ADDON_HANDLE,cacheToDisc=_E)
	def dp_Programn_List(self,argsValue):
		B='aired';A='genre';containerId=argsValue.get(_e);page_int=argsValue.get(_Z);self.KFuncObj.Addon_Log('containerId  : {}'.format(str(containerId)));self.KFuncObj.Addon_Log('page_int     : {}'.format(str(page_int)));RES_LIST,more_page=self.DisneyObj.Get_Program_List(containerId,page_int)
		for i_res in RES_LIST:
			title=i_res.get(_B);entityId=i_res.get(_G);vType=i_res.get(_H);genre=i_res.get(A);synopsis=i_res.get('synopsis');duration=i_res.get(_d);year=i_res.get(_t);aired=i_res.get(B);thumbnail=i_res.get(_z);delInfoBlock=i_res.get(_AF)
			if vType==_L:mode=_l;mediatype=_L;isType=_K
			elif vType==_O:mode=_k;mediatype=_O;isType=_c
			elif vType==_a:mode=_f;mediatype=_a;isType=_K
			else:mode=_P;mediatype=_P;isType=_K;title='check'
			infoLabels={_U:mediatype if mediatype!=_a else _L,_B:title,A:genre,_d:duration,_t:year,B:aired,_Q:synopsis};params={_A:mode,_C:{_B:title,_R:title,_G:entityId,_J:infoLabels,_N:thumbnail,_H:mediatype,_T:mediatype,_A0:entityId}};ContextMenu=[]
			if vType!=_a:bm_param={_A:_AZ,_C:{_m:entityId,_n:vType}};param_str=Params_JsonToStr(bm_param);param_str=param_str.replace(_X,_Y);bookmark_url=_b%param_str;ContextMenu.append(('상세정보 조회',bookmark_url))
			if delInfoBlock:bm_param={_A:_Aa,_C:{_B:title,_AF:delInfoBlock}};param_str=Params_JsonToStr(bm_param);param_str=param_str.replace(_X,_Y);bookmark_url=_b%param_str;ContextMenu.append(('시청중인 영상에서 삭제',bookmark_url))
			if self.get_settings_makebookmark()and vType!=_a:bm_param={_A:_x,_C:{_m:entityId,_n:vType,_B:title}};param_str=Params_JsonToStr(bm_param);param_str=param_str.replace(_X,_Y);bookmark_url=_b%param_str;ContextMenu.append((_AS,bookmark_url))
			self.KFuncObj.Add_Dir(title,subTitle='',img=thumbnail,infoLabels=infoLabels,isType=isType,ContextMenu=ContextMenu,params=params)
		if more_page:title=_AU%'다음 페이지';params={_A:_A1,_C:{_e:containerId,_Z:page_int+1}};subtitle=str(page_int+1);icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo(_i),_j,'next.png');self.KFuncObj.Add_Dir(title,subTitle=subtitle,img=icon_img,infoLabels=_F,isType=_K,ContextMenu=_F,params=params)
		xbmcplugin.setContent(self.ADDON_HANDLE,_AB);xbmcplugin.endOfDirectory(self.ADDON_HANDLE,cacheToDisc=_E)
	def dp_Brand_Six(self):
		RES_LIST=self.DisneyObj.Get_Brand_List()
		for i_res in RES_LIST:title=i_res.get(_B);pageId=i_res.get(_A0);image={_W:i_res.get(_N)};infoLabels={_U:_L,_Q:title};params={_A:_f,_C:{_T:'brands',_A0:pageId}};self.KFuncObj.Add_Dir(title,subTitle='',img=image,infoLabels=infoLabels,isType=_K,ContextMenu=_F,params=params)
		xbmcplugin.setContent(self.ADDON_HANDLE,_AG);xbmcplugin.endOfDirectory(self.ADDON_HANDLE,cacheToDisc=_E)
	def disney_main(self):
		self.DisneyObj.KodiVersion=int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0]);mode=_F;paramJson={};paramText=self.MAIN_PARAMS.get('params')
		if paramText:paramJson=Params_StrToJson(paramText);mode=paramJson.get(_A);argsValue=paramJson.get(_C)
		if mode=='LOGOUT':self.DZ_logout();return
		elif mode=='CHECK_TOKEN':self.DZ_ReToken();return
		self.login_main()
		if mode is _F:self.dp_Main_List()
		elif mode==_AH:self.dp_Brand_Six()
		elif mode==_l:self.dp_Season_List(argsValue)
		elif mode in[_k,_c]:self.play_VIDEO(argsValue)
		elif mode==_A3:self.dp_Local_SearchList(argsValue)
		elif mode==_AJ:self.dp_Local_SearchHist(argsValue)
		elif mode in[_A5,_A8]:self.dp_History_Remove(argsValue)
		elif mode==_o:self.dp_Watched_List(argsValue)
		elif mode in[_g,_p]:self.dp_Global_Search(mode)
		elif mode==_q:self.dp_Bookmark_Menu()
		elif mode==_x:self.dp_Set_Bookmark(argsValue)
		elif mode==_AZ:self.dp_View_Detail(argsValue)
		elif mode==_f:self.dp_DeepLink_Page(argsValue)
		elif mode==_A1:self.dp_Programn_List(argsValue)
		elif mode==_A2:self.dp_Catagory_Group(argsValue)
		elif mode==_AC:self.dp_Episode_List(argsValue)
		elif mode==_Aa:self.dp_Delete_Watch(argsValue)
		else:_F