__author__="NightRain"
pKIcosaEArJwSBMmUYkqFdzjWeTPVR=object
pKIcosaEArJwSBMmUYkqFdzjWeTPVg=True
pKIcosaEArJwSBMmUYkqFdzjWeTPVD=False
pKIcosaEArJwSBMmUYkqFdzjWeTPVh=int
pKIcosaEArJwSBMmUYkqFdzjWeTPVG=None
pKIcosaEArJwSBMmUYkqFdzjWeTPVC=str
import inputstreamhelper
import sys
from kodiFunc import*
from disneyCore import*
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
MAIN_GROUP=[{'title':'홈','mode':'DEEPLINK_PAGE','icon':'home.png','values':{'pageType':'home'}},{'title':'오리지널','mode':'DEEPLINK_PAGE','values':{'pageType':'originals'}},{'title':'브랜드별','mode':'BRAND_GROUP'},{'title':'영화','mode':'CATAGORY_GROUP','values':{'pageType':'movies'}},{'title':'시리즈','mode':'CATAGORY_GROUP','values':{'pageType':'series'}},{'title':'-----------------','mode':'XXX','values':{}},{'title':'Watched (시청목록)','mode':'WATCHED_LIST','icon':'history.png','values':{'vType':'-'}},{'title':'(디즈니) 검색','mode':'LOCAL_SEARCH_LIST','icon':'search.png','values':{}},{'title':'(디즈니) 검색기록','mode':'LOCAL_SEARCH_HIST','icon':'search_history.png','values':{}},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플)','mode':'TOTAL_SEARCH','icon':'search.png','values':{}},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png','values':{}},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png','values':{}},]
WATCH_GROUP=[{'title':'영화 시청내역','mode':'WATCHED_LIST','values':{'vType':'movie'}},{'title':'시리즈 시청내역','mode':'WATCHED_LIST','values':{'vType':'tvshow'}},]
class pKIcosaEArJwSBMmUYkqFdzjWeTPVl(pKIcosaEArJwSBMmUYkqFdzjWeTPVR):
 def __init__(self,in_addonurl,in_handle,in_params,in_resume):
  self.ADDON_URL =in_addonurl
  self.ADDON_HANDLE =in_handle
  self.MAIN_PARAMS =in_params
  self.PLAY_RESUME =in_resume 
  self.KFuncObj =KodiFunc(in_addonurl,in_handle)
  self.DisneyObj =KvSpyomJQatdMFgOzHfDWrTukscliB() 
  self.DisneyObj.DZ_COOKIES_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'dz_cookies.json'))
  self.DisneyObj.DZ_SEARCHED_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'dz_searched.json'))
  self.DisneyObj.DZ_WATCHED_MOVIE =xbmcvfs.translatePath(os.path.join(__profile__,'dz_watched_movie.json'))
  self.DisneyObj.DZ_WATCHED_VOD =xbmcvfs.translatePath(os.path.join(__profile__,'dz_watched_vod.json'))
  self.DisneyObj.DZ_VTT_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'dz_subtitles.vtt'))
  self.DisneyObj.DZ_M3U8_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'dz_play.m3u8'))
  if xbmc.getCondVisibility('system.platform.android'):
   self.DisneyObj.OS_ANDROID=pKIcosaEArJwSBMmUYkqFdzjWeTPVg
 def get_settings_totalsearch(self):
  local_search =pKIcosaEArJwSBMmUYkqFdzjWeTPVg if __addon__.getSetting('local_search')=='true' else pKIcosaEArJwSBMmUYkqFdzjWeTPVD
  local_history=pKIcosaEArJwSBMmUYkqFdzjWeTPVg if __addon__.getSetting('local_history')=='true' else pKIcosaEArJwSBMmUYkqFdzjWeTPVD
  total_search =pKIcosaEArJwSBMmUYkqFdzjWeTPVg if __addon__.getSetting('total_search')=='true' else pKIcosaEArJwSBMmUYkqFdzjWeTPVD
  total_history=pKIcosaEArJwSBMmUYkqFdzjWeTPVg if __addon__.getSetting('total_history')=='true' else pKIcosaEArJwSBMmUYkqFdzjWeTPVD
  menu_bookmark=pKIcosaEArJwSBMmUYkqFdzjWeTPVg if __addon__.getSetting('menu_bookmark')=='true' else pKIcosaEArJwSBMmUYkqFdzjWeTPVD
  return(local_search,local_history,total_search,total_history,menu_bookmark)
 def get_settings_makebookmark(self):
  return pKIcosaEArJwSBMmUYkqFdzjWeTPVg if __addon__.getSetting('make_bookmark')=='true' else pKIcosaEArJwSBMmUYkqFdzjWeTPVD
 def get_settings_account(self):
  dzid=__addon__.getSetting('id')
  dzpw=__addon__.getSetting('pw')
  dzpf=pKIcosaEArJwSBMmUYkqFdzjWeTPVh(__addon__.getSetting('profile'))
  return(dzid,dzpw,dzpf)
 def get_settings_proxyport(self):
  return pKIcosaEArJwSBMmUYkqFdzjWeTPVh(__addon__.getSetting('proxyPort'))
 def get_settings_proxyyn(self):
  return pKIcosaEArJwSBMmUYkqFdzjWeTPVg if __addon__.getSetting('proxyyn')=='true' else pKIcosaEArJwSBMmUYkqFdzjWeTPVD
 def get_settings_playback(self):
  DrmLevel=self.KFuncObj.Get_Drm_Level()
  res_list={'0':1920,'1':2560,'2':3840}
  playOption={'wv_secure':pKIcosaEArJwSBMmUYkqFdzjWeTPVg,'video_h265':pKIcosaEArJwSBMmUYkqFdzjWeTPVg if __addon__.getSetting('video_h265')=='true' else pKIcosaEArJwSBMmUYkqFdzjWeTPVD,'video_hdr':pKIcosaEArJwSBMmUYkqFdzjWeTPVg if __addon__.getSetting('video_hdr')=='true' else pKIcosaEArJwSBMmUYkqFdzjWeTPVD,'video_dolby':pKIcosaEArJwSBMmUYkqFdzjWeTPVg if __addon__.getSetting('video_dolby')=='true' else pKIcosaEArJwSBMmUYkqFdzjWeTPVD,'maxResolution':res_list.get(__addon__.getSetting('maxResolution')),'sound_aac':pKIcosaEArJwSBMmUYkqFdzjWeTPVg if __addon__.getSetting('sound_aac')=='true' else pKIcosaEArJwSBMmUYkqFdzjWeTPVD,'sound_dd':pKIcosaEArJwSBMmUYkqFdzjWeTPVg if __addon__.getSetting('sound_dd')=='true' else pKIcosaEArJwSBMmUYkqFdzjWeTPVD,'sound_atmos':pKIcosaEArJwSBMmUYkqFdzjWeTPVg if __addon__.getSetting('sound_atmos')=='true' else pKIcosaEArJwSBMmUYkqFdzjWeTPVD,'vttFilename':self.DisneyObj.DZ_VTT_FILENAME,'m3u8Filename':self.DisneyObj.DZ_M3U8_FILENAME,'play_resume':self.PLAY_RESUME,}
  if playOption['wv_secure']==pKIcosaEArJwSBMmUYkqFdzjWeTPVD or playOption['video_h265']==pKIcosaEArJwSBMmUYkqFdzjWeTPVD:
   playOption['sound_atmos']=pKIcosaEArJwSBMmUYkqFdzjWeTPVD
   playOption['video_hdr']=pKIcosaEArJwSBMmUYkqFdzjWeTPVD
   playOption['video_dolby']=pKIcosaEArJwSBMmUYkqFdzjWeTPVD
   playOption['maxResolution']=res_list.get('0')
  if not playOption['sound_aac']and not playOption['sound_dd']and not playOption['sound_atmos']:
   playOption['sound_aac']=pKIcosaEArJwSBMmUYkqFdzjWeTPVg
  return playOption
 def Searched_Save(self,sKey):
  HistoryFile_Insert(self.DisneyObj.DZ_SEARCHED_FILENAME,sKey)
 def Searched_Load(self):
  return HistoryFile_Load(self.DisneyObj.DZ_SEARCHED_FILENAME)
 def Searched_Remove(self,delType,sKey='-'):
  if delType=='ALL':
   File_Delete(self.DisneyObj.DZ_SEARCHED_FILENAME)
  else:
   HistoryFile_Remove(self.DisneyObj.DZ_SEARCHED_FILENAME,sKey=sKey)
 def Watched_Save(self,vType,sKey,sValue):
  if vType=='movie':fileName=self.DisneyObj.DZ_WATCHED_MOVIE
  else: fileName=self.DisneyObj.DZ_WATCHED_VOD
  HistoryFile_Insert(fileName,sKey,sValue=sValue)
 def Watched_Load(self,vType):
  if vType=='movie':fileName=self.DisneyObj.DZ_WATCHED_MOVIE
  else: fileName=self.DisneyObj.DZ_WATCHED_VOD
  return HistoryFile_Load(fileName)
 def Watched_Remove(self,delType,vType,sKey='-'):
  if vType=='movie':fileName=self.DisneyObj.DZ_WATCHED_MOVIE
  else: fileName=self.DisneyObj.DZ_WATCHED_VOD
  if delType=='ALL':
   File_Delete(fileName)
  else:
   HistoryFile_Remove(fileName,sKey=sKey)
 def dp_Local_SearchHist(self,argsValue):
  SEARCH_HISTORY=self.Searched_Load()
  for search_history in SEARCH_HISTORY:
   sKey =search_history.get('sKey')
   params={'mode':'LOCAL_SEARCH_LIST','values':{'search_key':sKey,}}
   menu_param={'mode':'LOCAL_SEARCH_REMOVE','values':{'delType':'SEARCH_ONE','sKey':sKey,}}
   menu_param_str=Params_JsonToStr(menu_param)
   ContextMenu=[('선택된 검색어 ( %s ) 삭제'%(sKey),'RunPlugin(plugin://plugin.video.disneym/?params=%s)'%(menu_param_str))]
   infoLabels={'plot':'개별삭제는 팝업메뉴 사용'}
   self.KFuncObj.Add_Dir(sKey,subTitle='',img=pKIcosaEArJwSBMmUYkqFdzjWeTPVG,infoLabels=infoLabels,isType='FOLDER',ContextMenu=ContextMenu,params=params)
  infoLabels={'plot':'검색목록 전체를 삭제합니다.'}
  title ='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  params={'mode':'LOCAL_SEARCH_REMOVE','values':{'delType':'SEARCH_ALL','sKey':'-',}}
  icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  self.KFuncObj.Add_Dir(title,subTitle='',img=icon_img,infoLabels=infoLabels,isType='FOLDER',ContextMenu=pKIcosaEArJwSBMmUYkqFdzjWeTPVG,params=params)
  xbmcplugin.endOfDirectory(self.ADDON_HANDLE,cacheToDisc=pKIcosaEArJwSBMmUYkqFdzjWeTPVD)
 def dp_Watched_List(self,argsValue):
  vType=argsValue.get('vType')
  if vType=='-':
   for watch_group in WATCH_GROUP:
    title=watch_group.get('title')
    params={'mode':watch_group.get('mode'),'values':watch_group.get('values'),}
    self.KFuncObj.Add_Dir(title,subTitle='',img=pKIcosaEArJwSBMmUYkqFdzjWeTPVG,infoLabels=pKIcosaEArJwSBMmUYkqFdzjWeTPVG,isType='FOLDER',ContextMenu=pKIcosaEArJwSBMmUYkqFdzjWeTPVG,params=params)
   xbmcplugin.endOfDirectory(self.ADDON_HANDLE,cacheToDisc=pKIcosaEArJwSBMmUYkqFdzjWeTPVg)
  else:
   WATCHLIST=self.Watched_Load(vType)
   for watchlist in WATCHLIST:
    sKey =watchlist.get('sKey')
    sValue =watchlist.get('sValue')
    title =sValue.get('title')
    programTitle=sValue.get('programTitle')
    image =sValue.get('image')
    infoLabels =sValue.get('infoLabels')
    entityId =sValue.get('entityId')
    vType =sValue.get('vType') 
    if vType=='movie':
     params={'mode':'MOVIE','values':{'entityId':entityId,'title':title,'image':image,'infoLabels':infoLabels,'vType':vType,}}
     isType='VOD'
     disTitle=title
     disSub =''
    elif vType=='tvshow' and entityId not in[pKIcosaEArJwSBMmUYkqFdzjWeTPVG,'']:
     params={'mode':'SEASON_LIST','values':{'entityId':entityId,'programTitle':programTitle,'title':title,'image':image,'infoLabels':infoLabels,'vType':vType,}}
     isType='FOLDER'
     disTitle=programTitle
     disSub =title 
    '''
    else:
     params = {'mode' : 'SEASON_LIST', 'values' : {'encodedId' : encodedId, 'contentClass' : contentClass, 'contentSlugs' : contentSlugs, 'programTitle' : programTitle, 'title' : title, 'image' : image, 'infoLabels' : infoLabels, 'vType' : vType, } }
     isType = 'FOLDER'
     if vType == 'single':
      disTitle = title
      disSub   = '' 
     else:
      disTitle = programTitle
      disSub   = title 
    '''    
    menu_param={'mode':'WATCHED_REMOVE','values':{'delType':'WATCH_ONE','sKey':sKey,'vType':vType,}}
    menu_param_str=Params_JsonToStr(menu_param)
    ContextMenu=[('선택된 시청이력 ( %s ) 삭제'%(disTitle),'RunPlugin(plugin://plugin.video.disneym/?params=%s)'%(menu_param_str))]
    self.KFuncObj.Add_Dir(disTitle,subTitle=disSub,img=image,infoLabels=infoLabels,isType=isType,ContextMenu=ContextMenu,params=params)
   infoLabels={'plot':'검색목록 전체를 삭제합니다.'}
   title ='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   params={'mode':'WATCHED_REMOVE','values':{'delType':'WATCH_ALL','sKey':'-','vType':vType,}}
   icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
   self.KFuncObj.Add_Dir(title,subTitle='',img=icon_img,infoLabels=infoLabels,isType='FOLDER',ContextMenu=pKIcosaEArJwSBMmUYkqFdzjWeTPVG,params=params)
   xbmcplugin.setContent(self.ADDON_HANDLE,'movies')
   xbmcplugin.endOfDirectory(self.ADDON_HANDLE,cacheToDisc=pKIcosaEArJwSBMmUYkqFdzjWeTPVD)
 def dp_History_Remove(self,argsValue):
  delType=argsValue.get('delType')
  sKey =argsValue.get('sKey')
  vType =argsValue.get('vType')
  dialog=xbmcgui.Dialog()
  if delType=='SEARCH_ALL':
   ret=dialog.yesno(__language__(30911).encode('utf8'),__language__(30903).encode('utf8'))
  elif delType=='SEARCH_ONE':
   ret=dialog.yesno(__language__(30912).encode('utf8'),__language__(30903).encode('utf8'))
  elif delType=='WATCH_ALL':
   ret=dialog.yesno(__language__(30913).encode('utf8'),__language__(30903).encode('utf8'))
  elif delType=='WATCH_ONE':
   ret=dialog.yesno(__language__(30914).encode('utf8'),__language__(30903).encode('utf8'))
  if ret==pKIcosaEArJwSBMmUYkqFdzjWeTPVD:sys.exit()
  if delType=='SEARCH_ALL':
   self.Searched_Remove('ALL',sKey='-')
  elif delType=='SEARCH_ONE':
   self.Searched_Remove('ONE',sKey=sKey)
  elif delType=='WATCH_ALL':
   self.Watched_Remove('ALL',vType=vType,sKey='-')
  elif delType=='WATCH_ONE':
   self.Watched_Remove('ONE',vType=vType,sKey=sKey)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Main_List(self):
  (local_search,local_history,total_search,total_history,menu_bookmark)=self.get_settings_totalsearch()
  for main_group in MAIN_GROUP:
   if main_group.get('mode')=='LOCAL_SEARCH' and local_search ==pKIcosaEArJwSBMmUYkqFdzjWeTPVD:continue
   elif main_group.get('mode')=='SEARCH_HISTORY' and local_history==pKIcosaEArJwSBMmUYkqFdzjWeTPVD:continue
   elif main_group.get('mode')=='TOTAL_SEARCH' and total_search ==pKIcosaEArJwSBMmUYkqFdzjWeTPVD:continue
   elif main_group.get('mode')=='TOTAL_HISTORY' and total_history==pKIcosaEArJwSBMmUYkqFdzjWeTPVD:continue
   elif main_group.get('mode')=='MENU_BOOKMARK' and menu_bookmark==pKIcosaEArJwSBMmUYkqFdzjWeTPVD:continue
   title =main_group.get('title')
   icon_img=pKIcosaEArJwSBMmUYkqFdzjWeTPVG
   params={'mode':main_group.get('mode'),'values':main_group.get('values'),}
   if main_group.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    isType ='LINK' 
   else:
    isType ='FOLDER' 
   infoLabels={'title':title,'plot':title}
   if main_group.get('mode')=='XXX':infoLabels=pKIcosaEArJwSBMmUYkqFdzjWeTPVG
   if 'icon' in main_group:icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',main_group.get('icon')) 
   self.KFuncObj.Add_Dir(title,subTitle='',img=icon_img,infoLabels=infoLabels,isType=isType,ContextMenu=pKIcosaEArJwSBMmUYkqFdzjWeTPVG,params=params)
  xbmcplugin.endOfDirectory(self.ADDON_HANDLE)
 def login_main(self):
  (dzid,dzpw,dzpf)=self.get_settings_account()
  if dzid=='' or dzpw=='':
   dialog=xbmcgui.Dialog()
   ret=dialog.yesno(__language__(30921).encode('utf8'),__language__(30922).encode('utf8'))
   if ret==pKIcosaEArJwSBMmUYkqFdzjWeTPVg:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if self.cookiefile_check()==pKIcosaEArJwSBMmUYkqFdzjWeTPVg:
   if Get_TimeStamp()>self.DisneyObj.DZ['account']['token_limit']:
    if self.DisneyObj.DZ_Login_ReToken()==pKIcosaEArJwSBMmUYkqFdzjWeTPVD:
     self.KFuncObj.Addon_Noti(__language__(30923).encode('utf8'))
     sys.exit()
  else:
   if self.DisneyObj.DZ_Login_Main(dzid,dzpw,dzpf)==pKIcosaEArJwSBMmUYkqFdzjWeTPVD:
    self.KFuncObj.Addon_Noti(__language__(30923).encode('utf8'))
    sys.exit()
 def cookiefile_check(self):
  self.DisneyObj.DZ=JsonFile_Load(self.DisneyObj.DZ_COOKIES_FILENAME)
  (cf_id,cf_pw,cf_pf)=self.get_settings_account()
  (ck_id,ck_pw,ck_pf)=self.DisneyObj.Load_session_acount()
  if cf_id!=ck_id or cf_pw!=ck_pw or cf_pf!=ck_pf:
   self.DisneyObj.Init_DZ_Total()
   return pKIcosaEArJwSBMmUYkqFdzjWeTPVD
  return pKIcosaEArJwSBMmUYkqFdzjWeTPVg
 def DZ_logout(self):
  dialog=xbmcgui.Dialog()
  ret=dialog.yesno(__language__(30925).encode('utf8'),__language__(30903).encode('utf8'))
  if ret==pKIcosaEArJwSBMmUYkqFdzjWeTPVD:return 
  File_Delete(self.DisneyObj.DZ_COOKIES_FILENAME)
  self.KFuncObj.Addon_Noti(__language__(30924).encode('utf-8'))
 def dp_Local_SearchList(self,argsValue):
  if 'search_key' in argsValue:
   search_key=argsValue.get('search_key')
  else:
   search_key=self.KFuncObj.Get_Keyboard_Input(__language__(30902).encode('utf-8'))
   if not search_key:
    return
   self.Searched_Save(search_key)
  RES_LIST=self.DisneyObj.Get_Search_List(search_key)
  for i_res in RES_LIST:
   title =i_res.get('title')
   vType =i_res.get('vType')
   entityId =i_res.get('entityId')
   year =i_res.get('year')
   duration =i_res.get('duration')
   desc =i_res.get('desc')
   image ={'poster':i_res.get('poster'),'fanart':i_res.get('fanart'),'thumb':i_res.get('thumb'),'clearlogo':i_res.get('clearlogo'),} 
   if vType in['tvshow']:
    mode ='SEASON_LIST'
    mediatype='tvshow'
    isType ='FOLDER'
   elif vType=='movie':
    mode ='MOVIE'
    mediatype='movie'
    isType ='VOD'
   else:
    mode ='-'
    isType ='FOLDER'
    title ='check '
   infoLabels={'mediatype':mediatype,'title':title,'duration':duration,'year':year,'plot':desc,}
   params={'mode':mode,'values':{'programTitle':title,'title':title,'entityId':entityId,'infoLabels':infoLabels,'image':image,'vType':vType,}}
   if self.get_settings_makebookmark():
    bm_param={'mode':'SET_BOOKMARK','values':{'videoid':entityId,'vidtype':vType,'title':title,}}
    param_str=Params_JsonToStr(bm_param)
    param_str=param_str.replace('+','%2B')
    bookmark_url='RunPlugin(plugin://plugin.video.disneym/?params=%s)'%(param_str)
    ContextMenu=[('(통합) 찜 영상에 추가',bookmark_url)]
   else:
    ContextMenu=pKIcosaEArJwSBMmUYkqFdzjWeTPVG
   self.KFuncObj.Add_Dir(title,subTitle='',img=image,infoLabels=infoLabels,isType=isType,ContextMenu=ContextMenu,params=params)
  xbmcplugin.setContent(self.ADDON_HANDLE,'tvshows')
  xbmcplugin.endOfDirectory(self.ADDON_HANDLE,cacheToDisc=pKIcosaEArJwSBMmUYkqFdzjWeTPVg) 
 def dp_Season_List(self,argsValue):
  programTitle=argsValue.get('programTitle')
  entityId =argsValue.get('entityId')or '' 
  self.KFuncObj.Addon_Log('dp_Season_List entityId  = {}'.format(entityId))
  RES_LIST=self.DisneyObj.Get_Season_List2(entityId) 
  for i_res in RES_LIST:
   seasonId =i_res.get('seasonId')
   seasonNum =i_res.get('seasonNum')
   episodeCnt =i_res.get('episodeCnt')
   desc =i_res.get('desc')
   image ={'poster':i_res.get('poster')}
   title ='{} : 시즌 {}'.format(programTitle,seasonNum)if '시즌' not in pKIcosaEArJwSBMmUYkqFdzjWeTPVC(seasonNum)else '{} : {}'.format(programTitle,seasonNum)
   infoLabels={'mediatype':'season','plot':'에피소드 {}개\n\n{}'.format(episodeCnt,desc),}
   params={'mode':'EPISODE_LIST','values':{'entityId':entityId,'seasonId':seasonId,'page_int':1,}}
   self.KFuncObj.Add_Dir(title,subTitle='',img=image,infoLabels=infoLabels,isType='FOLDER',ContextMenu=pKIcosaEArJwSBMmUYkqFdzjWeTPVG,params=params)
  xbmcplugin.setContent(self.ADDON_HANDLE,'tvshows')
  xbmcplugin.endOfDirectory(self.ADDON_HANDLE,cacheToDisc=pKIcosaEArJwSBMmUYkqFdzjWeTPVg)
 def dp_Episode_List(self,argsValue):
  entityId =argsValue.get('entityId')
  seasonId =argsValue.get('seasonId')
  page_int =argsValue.get('page_int')
  self.KFuncObj.Addon_Log('dp_Episode_List seasonId = {}'.format(seasonId))
  RES_LIST,more_page=self.DisneyObj.Get_Episode_List(seasonId,page_int)
  for i_res in RES_LIST:
   resourceId =i_res.get('resourceId')
   availId =i_res.get('availId') 
   title =i_res.get('title')
   tvshowtitle=i_res.get('tvshowtitle')
   desc =i_res.get('desc')
   duration =i_res.get('duration')
   seasonNum =i_res.get('seasonNum')
   episodeNum =i_res.get('episodeNum')
   image ={'fanart':i_res.get('fanart'),'thumb':i_res.get('thumb'),'poster':i_res.get('poster'),'clearlogo':i_res.get('clearlogo'),}
   infoLabels={'mediatype':'episode','title':title,'tvshowtitle':tvshowtitle,'plot':desc,'duration':duration,'season':seasonNum,'episode':episodeNum,}
   dis_title='{}x{:0>2}. {}'.format(seasonNum,episodeNum,title)
   params={'mode':'VOD','values':{'resourceId':resourceId,'availId':availId,'title':dis_title,'programTitle':tvshowtitle,'entityId':entityId,'image':image,'infoLabels':infoLabels,'vType':'tvshow',}}
   self.KFuncObj.Add_Dir(dis_title,subTitle='',img=image,infoLabels=infoLabels,isType='VOD',ContextMenu=pKIcosaEArJwSBMmUYkqFdzjWeTPVG,params=params)
  if more_page:
   title ='[B]%s >>[/B]'%'다음 페이지'
   params={'mode':'EPISODE_LIST','values':{'entityId':entityId,'seasonId':seasonId,'page_int':page_int+1,}}
   subtitle=pKIcosaEArJwSBMmUYkqFdzjWeTPVC(page_int+1)
   icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   self.KFuncObj.Add_Dir(title,subTitle=subtitle,img=icon_img,infoLabels=pKIcosaEArJwSBMmUYkqFdzjWeTPVG,isType='FOLDER',ContextMenu=pKIcosaEArJwSBMmUYkqFdzjWeTPVG,params=params)
  xbmcplugin.setContent(self.ADDON_HANDLE,'episodes')
  xbmcplugin.endOfDirectory(self.ADDON_HANDLE,cacheToDisc=pKIcosaEArJwSBMmUYkqFdzjWeTPVg)
 def play_VIDEO(self,argsValue):
  playOption=self.get_settings_playback()
  entityId =argsValue.get('entityId') 
  resourceId =argsValue.get('resourceId')
  availId =argsValue.get('availId') 
  vType =argsValue.get('vType')
  self.KFuncObj.Addon_Log('play_VIDEO 2.entityId   = {}'.format(entityId)) 
  self.KFuncObj.Addon_Log('play_VIDEO 3.resourceId = {}'.format(resourceId)) 
  self.KFuncObj.Addon_Log('play_VIDEO 4.availId    = {}'.format(availId)) 
  if resourceId:
   streamInfo =self.DisneyObj.GetStreamingURL(resourceId,availId,playOption)
  else:
   contentId=self.DisneyObj.entityId_to_contentId(entityId)
   streamInfo =self.DisneyObj.GetStreamingURL2(contentId,playOption)
  streamUrl =streamInfo.get('streamUrl')
  drmUrl =streamInfo.get('drmUrl')
  defaultAudio=streamInfo.get('defaultAudio')
  self.KFuncObj.Addon_Log('streamUrl    : {}'.format(streamUrl))
  self.KFuncObj.Addon_Log('resume       : {}'.format(playOption.get('play_resume')))
  if streamUrl in['',pKIcosaEArJwSBMmUYkqFdzjWeTPVG]:
   if drmUrl!='':
    self.KFuncObj.Addon_Noti(drmUrl)
   else:
    self.KFuncObj.Addon_Noti(__language__(30901).encode('utf8'))
   return
  raw_headers =self.DisneyObj.Make_Headers(accessToken=pKIcosaEArJwSBMmUYkqFdzjWeTPVg,Bearer=pKIcosaEArJwSBMmUYkqFdzjWeTPVD)
  raw_headers['content-type']='application/octet-stream'
  raw_headers['user-agent'] =self.DisneyObj.HttpObj.USER_AGENT
  LICENSE_KEY=drmUrl+'|'+urllib.parse.urlencode(raw_headers)+'|R{SSM}|'
  stream_headers=make_stream_header(raw_headers,pKIcosaEArJwSBMmUYkqFdzjWeTPVG)
  proxyHeader={'addon':'disneym','defaultAudio':defaultAudio,'playOption':playOption,}
  proxyHeader=Params_JsonToStr(proxyHeader)
  self.KFuncObj.Addon_Log('proxyHeader    : {}'.format(proxyHeader))
  proxyPort =self.get_settings_proxyport()
  proxyUse =self.get_settings_proxyyn()
  if proxyUse:
   streamUrl='http://127.0.0.1:{}/{}|proxy-mini={}'.format(proxyPort,streamUrl,proxyHeader)
  self.KFuncObj.Addon_Log(streamUrl)
  item=xbmcgui.ListItem(path=streamUrl)
  inputstreamhelper.Helper('hls',drm='com.widevine.alpha').check_inputstream()
  item.setProperty('inputstream','inputstream.adaptive')
  if self.DisneyObj.KodiVersion<=20:
   item.setProperty('inputstream.adaptive.manifest_type','hls')
  item.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
  item.setProperty('inputstream.adaptive.license_key',LICENSE_KEY)
  item.setProperty('inputstream.adaptive.stream_headers',stream_headers)
  item.setProperty('inputstream.adaptive.manifest_headers',stream_headers)
  item.setProperty('inputstream.adaptive.original_audio_language',defaultAudio)
  item.setMimeType('application/x-mpegURL')
  item.setContentLookup(pKIcosaEArJwSBMmUYkqFdzjWeTPVD)
  if proxyUse:
   item.setSubtitles([playOption['vttFilename']])
  xbmcplugin.setResolvedUrl(self.ADDON_HANDLE,pKIcosaEArJwSBMmUYkqFdzjWeTPVg,item)
  try:
   if vType in['movie','tvshow']:
    if vType=='movie':
     sKey =entityId
     sValue={'entityId':entityId,'title':argsValue.get('title'),'image':argsValue.get('image'),'infoLabels':argsValue.get('infoLabels'),'vType':vType,}
    elif vType=='tvshow':
     argsValue['infoLabels']['mediatype']='tvshow'
     sKey=argsValue.get('entityId')
     sValue={'entityId':argsValue.get('entityId'),'title':argsValue.get('title'),'programTitle':argsValue.get('programTitle'),'image':argsValue.get('image'),'infoLabels':argsValue.get('infoLabels'),'vType':vType,}
    self.Watched_Save(vType,sKey,sValue)
  except:
   pKIcosaEArJwSBMmUYkqFdzjWeTPVG
 def DZ_ReToken(self):
  try:
   self.DisneyObj.DZ=JsonFile_Load(self.DisneyObj.DZ_COOKIES_FILENAME)
   if Get_TimeStamp()>self.DisneyObj.DZ['account']['token_limit']:
    if self.DisneyObj.DZ_Login_ReToken()==pKIcosaEArJwSBMmUYkqFdzjWeTPVD:
     return pKIcosaEArJwSBMmUYkqFdzjWeTPVD
  except:
   return pKIcosaEArJwSBMmUYkqFdzjWeTPVD
  return pKIcosaEArJwSBMmUYkqFdzjWeTPVg
 def dp_Global_Search(self,mode):
  if mode=='TOTAL_SEARCH':
   ott_url='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   ott_url='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(ott_url)
 def dp_Bookmark_Menu(self):
  ott_url='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(ott_url)
 def dp_Set_Bookmark(self,argsValue):
  videoid =argsValue.get('videoid')
  vidtype =argsValue.get('vidtype')
  title =argsValue.get('title')
  col_info =argsValue.get('col_info')
  dialog=xbmcgui.Dialog()
  ret=dialog.yesno(__language__(30915).encode('utf8'),title+' \n\n'+__language__(30916))
  if ret==pKIcosaEArJwSBMmUYkqFdzjWeTPVD:return
  self.KFuncObj.Addon_Log('videoid = {}'.format(videoid))
  self.KFuncObj.Addon_Log('vidtype = {}'.format(vidtype))
  if vidtype=='collection':
   VIDEO_INFO=col_info
  else:
   VIDEO_INFO=self.DisneyObj.GetBookmarkInfo2(videoid,vidtype)
  params={'mode':'SET_BOOKMARK','values':{'VIDEO_INFO':VIDEO_INFO,}}
  param_str=Params_JsonToStr(params)
  param_str=param_str.replace('+','%2B')
  bookmark_url ='RunPlugin(plugin://plugin.video.bookmarkm/?params=%s)'%(param_str)
  xbmc.executebuiltin(bookmark_url)
 def dp_Delete_Watch(self,argsValue):
  title =argsValue.get('title')
  delInfoBlock =argsValue.get('delInfoBlock')
  dialog=xbmcgui.Dialog()
  ret=dialog.yesno(__language__(30917).encode('utf8'),title+' \n\n'+__language__(30903))
  if ret==pKIcosaEArJwSBMmUYkqFdzjWeTPVD:return
  self.KFuncObj.Addon_Log('delete_watch({}) : {}'.format(title,delInfoBlock))
  if self.DisneyObj.Delete_Watch_List(delInfoBlock)==pKIcosaEArJwSBMmUYkqFdzjWeTPVD:
   self.KFuncObj.Addon_Noti('삭제 오류')
   return
  self.KFuncObj.Addon_Noti('삭제중... 잠시 기다려주세요~~')
  xbmc.sleep(2000)
  xbmc.executebuiltin('Container.Refresh')
 def dp_View_Detail(self,argsValue):
  videoid =argsValue.get('videoid')
  vidtype =argsValue.get('vidtype')
  self.KFuncObj.Addon_Log('videoid = {}'.format(videoid))
  self.KFuncObj.Addon_Log('vidtype = {}'.format(vidtype))
  VIDEO_INFO=self.DisneyObj.GetBookmarkInfo2(videoid,vidtype)
  if vidtype=='tvshow':
   ott_param={'mode':'SEASON_LIST','values':{'entityId':VIDEO_INFO['indexinfo']['entityId'],'vType':vidtype,'image':VIDEO_INFO['saveinfo']['thumbnail'],'title':VIDEO_INFO['saveinfo']['title'],'programTitle':VIDEO_INFO['saveinfo']['title'],'infoLabels':VIDEO_INFO['saveinfo']['infoLabels'],}} 
   ott_param_str=json.dumps(ott_param,separators=(',',':'))
   ott_param_str=base64.standard_b64encode(ott_param_str.encode()).decode('utf-8')
   ott_param_str=ott_param_str.replace('+','%2B')
   ott_url='plugin://plugin.video.disneym/?params=%s'%(ott_param_str)
  else:
   ott_param={'mode':'MOVIE','values':{'entityId':VIDEO_INFO['indexinfo']['entityId'],'vType':vidtype,'image':VIDEO_INFO['saveinfo']['thumbnail'],'title':VIDEO_INFO['saveinfo']['infoLabels']['title'],'programTitle':VIDEO_INFO['saveinfo']['infoLabels']['title'],'infoLabels':VIDEO_INFO['saveinfo']['infoLabels'],}}
   ott_param_str=json.dumps(ott_param,separators=(',',':'))
   ott_param_str=base64.standard_b64encode(ott_param_str.encode()).decode('utf-8')
   ott_param_str=ott_param_str.replace('+','%2B')
   ott_url='plugin://plugin.video.disneym/?params=%s'%(ott_param_str)
  listitem=xbmcgui.ListItem(label=VIDEO_INFO['saveinfo']['title'],path=ott_url)
  listitem.setArt(VIDEO_INFO['saveinfo']['thumbnail'])
  listitem.setInfo('Video',VIDEO_INFO['saveinfo']['infoLabels'])
  if vidtype=='movie':
   listitem.setIsFolder(pKIcosaEArJwSBMmUYkqFdzjWeTPVD)
   listitem.setProperty('IsPlayable','true')
  else:
   listitem.setIsFolder(pKIcosaEArJwSBMmUYkqFdzjWeTPVg)
   listitem.setProperty('IsPlayable','false')
  dialog=xbmcgui.Dialog()
  dialog.info(listitem)
 def dp_DeepLink_Page(self,argsValue):
  pageType=argsValue.get('pageType')
  pageId =argsValue.get('pageId')
  self.KFuncObj.Addon_Log('pageType  : {}'.format(pKIcosaEArJwSBMmUYkqFdzjWeTPVC(pageType)))
  self.KFuncObj.Addon_Log('pageId    : {}'.format(pKIcosaEArJwSBMmUYkqFdzjWeTPVC(pageId)))
  if pageType=='collection':
   pageType=pageId
  RES_LIST=self.DisneyObj.Get_Container_List(pageType,pageId)
  for i_res in RES_LIST:
   title =i_res.get('title') 
   containerId =i_res.get('containerId')
   infoLabels={'mediatype':'tvshow','plot':title,}
   params={'mode':'PROGRAM_LIST','values':{'containerId':containerId,'page_int':1,}}
   self.KFuncObj.Add_Dir(title,subTitle='',img=pKIcosaEArJwSBMmUYkqFdzjWeTPVG,infoLabels=infoLabels,isType='FOLDER',ContextMenu=pKIcosaEArJwSBMmUYkqFdzjWeTPVG,params=params)
  xbmcplugin.setContent(self.ADDON_HANDLE,'genres')
  xbmcplugin.endOfDirectory(self.ADDON_HANDLE,cacheToDisc=pKIcosaEArJwSBMmUYkqFdzjWeTPVg)
 def dp_Catagory_Group(self,argsValue):
  pageType=argsValue.get('pageType')
  self.KFuncObj.Addon_Log('pageType  : {}'.format(pKIcosaEArJwSBMmUYkqFdzjWeTPVC(pageType)))
  RES_LIST=self.DisneyObj.Get_Catagory_Group(pageType)
  for i_res in RES_LIST:
   title =i_res.get('title') 
   containerId =i_res.get('containerId')
   infoLabels={'mediatype':'tvshow','plot':title,}
   params={'mode':'PROGRAM_LIST','values':{'containerId':containerId,'page_int':1,}}
   self.KFuncObj.Add_Dir(title,subTitle='',img=pKIcosaEArJwSBMmUYkqFdzjWeTPVG,infoLabels=infoLabels,isType='FOLDER',ContextMenu=pKIcosaEArJwSBMmUYkqFdzjWeTPVG,params=params)
  xbmcplugin.setContent(self.ADDON_HANDLE,'genres')
  xbmcplugin.endOfDirectory(self.ADDON_HANDLE,cacheToDisc=pKIcosaEArJwSBMmUYkqFdzjWeTPVg)
 def dp_Programn_List(self,argsValue):
  containerId=argsValue.get('containerId')
  page_int =argsValue.get('page_int')
  self.KFuncObj.Addon_Log('containerId  : {}'.format(pKIcosaEArJwSBMmUYkqFdzjWeTPVC(containerId)))
  self.KFuncObj.Addon_Log('page_int     : {}'.format(pKIcosaEArJwSBMmUYkqFdzjWeTPVC(page_int)))
  RES_LIST,more_page=self.DisneyObj.Get_Program_List(containerId,page_int)
  for i_res in RES_LIST:
   title =i_res.get('title')
   entityId =i_res.get('entityId')
   vType =i_res.get('vType')
   genre =i_res.get('genre')
   synopsis =i_res.get('synopsis')
   duration =i_res.get('duration')
   year =i_res.get('year')
   aired =i_res.get('aired')
   thumbnail =i_res.get('thumbnail')
   delInfoBlock=i_res.get('delInfoBlock')
   if vType=='tvshow':
    mode ='SEASON_LIST'
    mediatype='tvshow'
    isType ='FOLDER'
   elif vType=='movie':
    mode ='MOVIE'
    mediatype='movie'
    isType ='VOD'
   elif vType=='collection':
    mode ='DEEPLINK_PAGE'
    mediatype='collection'
    isType ='FOLDER'
   else:
    mode ='-'
    mediatype='-'
    isType ='FOLDER'
    title ='check'
   infoLabels={'mediatype':mediatype if mediatype!='collection' else 'tvshow','title':title,'genre':genre,'duration':duration,'year':year,'aired':aired,'plot':synopsis,}
   params={'mode':mode,'values':{'title':title,'programTitle':title,'entityId':entityId,'infoLabels':infoLabels,'image':thumbnail,'vType':mediatype,'pageType':mediatype,'pageId':entityId,}}
   ContextMenu=[]
   if vType!='collection':
    bm_param={'mode':'VIEW_DETAIL','values':{'videoid':entityId,'vidtype':vType,}}
    param_str=Params_JsonToStr(bm_param)
    param_str=param_str.replace('+','%2B')
    bookmark_url='RunPlugin(plugin://plugin.video.disneym/?params=%s)'%(param_str)
    ContextMenu.append(('상세정보 조회',bookmark_url))
   if delInfoBlock:
    bm_param={'mode':'DELETE_WATCH','values':{'title':title,'delInfoBlock':delInfoBlock,}}
    param_str=Params_JsonToStr(bm_param)
    param_str=param_str.replace('+','%2B')
    bookmark_url='RunPlugin(plugin://plugin.video.disneym/?params=%s)'%(param_str)
    ContextMenu.append(('시청중인 영상에서 삭제',bookmark_url))
   if self.get_settings_makebookmark()and vType!='collection':
    bm_param={'mode':'SET_BOOKMARK','values':{'videoid':entityId,'vidtype':vType,'title':title,}}
    param_str=Params_JsonToStr(bm_param)
    param_str=param_str.replace('+','%2B')
    bookmark_url='RunPlugin(plugin://plugin.video.disneym/?params=%s)'%(param_str)
    ContextMenu.append(('(통합) 찜 영상에 추가',bookmark_url))
   self.KFuncObj.Add_Dir(title,subTitle='',img=thumbnail,infoLabels=infoLabels,isType=isType,ContextMenu=ContextMenu,params=params)
  if more_page:
   title ='[B]%s >>[/B]'%'다음 페이지'
   params={'mode':'PROGRAM_LIST','values':{'containerId':containerId,'page_int':page_int+1,}}
   subtitle=pKIcosaEArJwSBMmUYkqFdzjWeTPVC(page_int+1)
   icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   self.KFuncObj.Add_Dir(title,subTitle=subtitle,img=icon_img,infoLabels=pKIcosaEArJwSBMmUYkqFdzjWeTPVG,isType='FOLDER',ContextMenu=pKIcosaEArJwSBMmUYkqFdzjWeTPVG,params=params)
  xbmcplugin.setContent(self.ADDON_HANDLE,'tvshows')
  xbmcplugin.endOfDirectory(self.ADDON_HANDLE,cacheToDisc=pKIcosaEArJwSBMmUYkqFdzjWeTPVg)
 def dp_Brand_Six(self):
  RES_LIST=self.DisneyObj.Get_Brand_List()
  for i_res in RES_LIST:
   title =i_res.get('title')
   pageId=i_res.get('pageId')
   image ={'poster':i_res.get('image'),}
   infoLabels={'mediatype':'tvshow','plot':title,}
   params={'mode':'DEEPLINK_PAGE','values':{'pageType':'brands','pageId':pageId,}}
   self.KFuncObj.Add_Dir(title,subTitle='',img=image,infoLabels=infoLabels,isType='FOLDER',ContextMenu=pKIcosaEArJwSBMmUYkqFdzjWeTPVG,params=params)
  xbmcplugin.setContent(self.ADDON_HANDLE,'genres')
  xbmcplugin.endOfDirectory(self.ADDON_HANDLE,cacheToDisc=pKIcosaEArJwSBMmUYkqFdzjWeTPVg)
 def disney_main(self):
  self.DisneyObj.KodiVersion=pKIcosaEArJwSBMmUYkqFdzjWeTPVh(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  mode =pKIcosaEArJwSBMmUYkqFdzjWeTPVG
  paramJson={}
  paramText=self.MAIN_PARAMS.get('params')
  if paramText:
   paramJson =Params_StrToJson(paramText)
   mode =paramJson.get('mode')
   argsValue =paramJson.get('values')
  if mode=='LOGOUT':
   self.DZ_logout()
   return
  elif mode=='CHECK_TOKEN':
   self.DZ_ReToken()
   return
  self.login_main()
  if mode is pKIcosaEArJwSBMmUYkqFdzjWeTPVG:
   self.dp_Main_List()
  elif mode=='BRAND_GROUP':
   self.dp_Brand_Six()
  elif mode=='SEASON_LIST':
   self.dp_Season_List(argsValue)
  elif mode in['MOVIE','VOD']:
   self.play_VIDEO(argsValue)
  elif mode=='LOCAL_SEARCH_LIST':
   self.dp_Local_SearchList(argsValue)
  elif mode=='LOCAL_SEARCH_HIST':
   self.dp_Local_SearchHist(argsValue)
  elif mode in['LOCAL_SEARCH_REMOVE','WATCHED_REMOVE']:
   self.dp_History_Remove(argsValue)
  elif mode=='WATCHED_LIST':
   self.dp_Watched_List(argsValue)
  elif mode in['TOTAL_SEARCH','TOTAL_HISTORY']:
   self.dp_Global_Search(mode)
  elif mode=='MENU_BOOKMARK':
   self.dp_Bookmark_Menu()
  elif mode=='SET_BOOKMARK':
   self.dp_Set_Bookmark(argsValue)
  elif mode=='VIEW_DETAIL':
   self.dp_View_Detail(argsValue)
  elif mode=='DEEPLINK_PAGE':
   self.dp_DeepLink_Page(argsValue)
  elif mode=='PROGRAM_LIST':
   self.dp_Programn_List(argsValue)
  elif mode=='CATAGORY_GROUP':
   self.dp_Catagory_Group(argsValue)
  elif mode=='EPISODE_LIST':
   self.dp_Episode_List(argsValue)
  elif mode=='DELETE_WATCH':
   self.dp_Delete_Watch(argsValue)
  else:
   pKIcosaEArJwSBMmUYkqFdzjWeTPVG
# Created by pyminifier (https://github.com/liftoff/pyminifier)
