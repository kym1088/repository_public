__author__="NightRain"
KvSpyomJQatdMFgOzHfDWrTukscliG=object
KvSpyomJQatdMFgOzHfDWrTuksclin=False
KvSpyomJQatdMFgOzHfDWrTukscliV=True
KvSpyomJQatdMFgOzHfDWrTukscliq=None
KvSpyomJQatdMFgOzHfDWrTuksclij=print
KvSpyomJQatdMFgOzHfDWrTukscliY=Exception
KvSpyomJQatdMFgOzHfDWrTuksclix=str
KvSpyomJQatdMFgOzHfDWrTukscliR=int
KvSpyomJQatdMFgOzHfDWrTukscliA=len
KvSpyomJQatdMFgOzHfDWrTukscliP=divmod
KvSpyomJQatdMFgOzHfDWrTukscliN=float
KvSpyomJQatdMFgOzHfDWrTuksclib=open
import re
from baseHttp import*
from baseFunc import*
ATTRIBUTE_PATTERN =re.compile(r'''((?:[^,"']|"[^"]*"|'[^']*')+)''')
class KvSpyomJQatdMFgOzHfDWrTukscliB(KvSpyomJQatdMFgOzHfDWrTukscliG):
 def __init__(self):
  self.OS_ANDROID =KvSpyomJQatdMFgOzHfDWrTuksclin 
  self.API_DOMAIN ='https://www.disneyplus.com'
  self.API_DOMAIN_NEW ='https://disney.api.edge.bamgrid.com/explore'
  self.API_VERSION_NEW ='v1.15' 
  self.ONE_PAGE =15 
  self.COLLECTION_SIZE =30 
  self.HttpObj =BaseHttp()
  self.Init_DZ_Total()
  self.DZ_COOKIES_FILENAME =''
  self.DZ_SEARCHED_FILENAME =''
  self.DZ_WATCHED_MOVIE =''
  self.DZ_WATCHED_VOD =''
  self.DZ_VTT_FILENAME =''
  self.DZ_M3U8_FILENAME =''
  self.DZ_SESSION_COOKIES1 =''
  self.DZ_SESSION_COOKIES2 =''
  self.DZ_SESSION_COOKIES3 =''
  self.DZ_SESSION_COOKIES4 =''
  self.DZ_SESSION_FULLTEXT1 =''
  self.DZ_SESSION_FULLTEXT2 =''
  self.DZ_SESSION_FULLTEXT3 =''
  self.DZ_SESSION_FULLTEXT4 =''
  self.DZ_CONTEXTJSON_FILE1 =''
  self.DZ_CONTEXTJSON_FILE2 =''
  self.DZ_CONTEXTJSON_FILE3 =''
  self.DZ_CONTEXTJSON_FILE4 =''
  self.KodiVersion=20
 def Init_DZ_Total(self):
  self.DZ={'headers':{},'services':{},'account':{},}
 def Save_session_acount(self,dzid,dzpw,dzpf):
  self.DZ['account']['dzid']=Base64_Encode(dzid)
  self.DZ['account']['dzpw']=Base64_Encode(dzpw)
  self.DZ['account']['dzpf']=dzpf 
 def Load_session_acount(self):
  try:
   dzid=Base64_Decode(self.DZ['account']['dzid'])
   dzpw=Base64_Decode(self.DZ['account']['dzpw'])
   dzpf=self.DZ['account']['dzpf']
  except:
   return '','',0
  return dzid,dzpw,dzpf
 def Make_Headers(self,accessToken=KvSpyomJQatdMFgOzHfDWrTukscliV,Bearer=KvSpyomJQatdMFgOzHfDWrTuksclin):
  if accessToken:
   authorization=self.DZ['account']['accessToken']
  else:
   authorization=self.DZ['headers']['clientApiKey']
  if Bearer:
   authorization='Bearer {}'.format(authorization)
  headers={'authorization':authorization,'x-application-version':self.DZ['headers']['buildId'],'x-bamsdk-client-id':self.DZ['headers']['clientId'],'x-bamsdk-platform':'javascript/windows/chrome','x-bamsdk-platform-id':'browser','x-bamsdk-version':self.DZ['headers']['sdkVersion'],'x-bamtech-wpnx-mlp-identifier':'/','x-bamtech-wpnx-mlp-locale':self.DZ['headers']['lang'],}
  return headers
 def Get_Prod_File(self):
  self.DZ['headers']['sdkVersion']='34.4' 
  prod_url='https://client-sdk-configs.bamgrid.com/bam-sdk/v7.0/{}/browser/v{}/windows/chrome/prod.json'.format(self.DZ['headers']['clientId'],self.DZ['headers']['sdkVersion'])
  prod_json=self.HttpObj.Call_Request(prod_url,params=KvSpyomJQatdMFgOzHfDWrTukscliq,headers=KvSpyomJQatdMFgOzHfDWrTukscliq,method='GET',redirects=KvSpyomJQatdMFgOzHfDWrTuksclin).json()
  self.DZ['services']['orchestration']=prod_json.get('services').get('orchestration').get('client').get('endpoints')
  self.DZ['services']['content'] =prod_json.get('services').get('content').get('client').get('endpoints')
  self.DZ['services']['drm'] =prod_json.get('services').get('drm').get('client').get('endpoints')
  self.DZ['services']['media'] =prod_json.get('services').get('media').get('client').get('endpoints')
  self.DZ['services']['explore'] =prod_json.get('services').get('explore').get('client').get('endpoints')
 def Check_ErrorMessage(self,message):
  try:
   if 'errors' in message:
    if 'description' in message['errors'][0]:
     KvSpyomJQatdMFgOzHfDWrTuksclij(message['errors'][0]['description'])
    elif 'message' in message['errors'][0]:
     KvSpyomJQatdMFgOzHfDWrTuksclij(message['errors'][0]['message'])
    else:
     KvSpyomJQatdMFgOzHfDWrTuksclij('etc error')
    return KvSpyomJQatdMFgOzHfDWrTuksclin 
  except KvSpyomJQatdMFgOzHfDWrTukscliY as exception:
   KvSpyomJQatdMFgOzHfDWrTuksclij(exception)
   return KvSpyomJQatdMFgOzHfDWrTuksclin
  return KvSpyomJQatdMFgOzHfDWrTukscliV
 def DZ_Login_Main(self,userid,userpw,userpf):
  if self.Get_DZ_InitValue()==KvSpyomJQatdMFgOzHfDWrTuksclin:return KvSpyomJQatdMFgOzHfDWrTuksclin
  if self.Get_DZ_GetInitToken()==KvSpyomJQatdMFgOzHfDWrTuksclin:return KvSpyomJQatdMFgOzHfDWrTuksclin
  if self.Get_DZ_Login(userid,userpw,userpf)==KvSpyomJQatdMFgOzHfDWrTuksclin:return KvSpyomJQatdMFgOzHfDWrTuksclin 
  JsonFile_Save(self.DZ_COOKIES_FILENAME,self.DZ)
  return KvSpyomJQatdMFgOzHfDWrTukscliV
 def DZ_Login_ReToken(self):
  if self.Get_DZ_GetReToken()==KvSpyomJQatdMFgOzHfDWrTuksclin:return KvSpyomJQatdMFgOzHfDWrTuksclin
  JsonFile_Save(self.DZ_COOKIES_FILENAME,self.DZ)
  return KvSpyomJQatdMFgOzHfDWrTukscliV
 def Get_DZ_AccoutInfo(self):
  profile_Info={}
  try:
   url =self.DZ['services']['orchestration']['query']['href']
   headers=self.Make_Headers(accessToken=KvSpyomJQatdMFgOzHfDWrTukscliV,Bearer=KvSpyomJQatdMFgOzHfDWrTuksclin)
   payload={'query':'query EntitledGraphMeQuery { me { __typename account { __typename ...accountGraphFragment } activeSession { __typename ...sessionGraphFragment } } } fragment accountGraphFragment on Account { __typename id activeProfile { __typename id } profiles { __typename ...profileGraphFragment } parentalControls { __typename isProfileCreationProtected } flows { __typename star { __typename isOnboarded } } attributes { __typename email emailVerified userVerified locations { __typename manual { __typename country } purchase { __typename country } registration { __typename geoIp { __typename country } } } } } fragment profileGraphFragment on Profile { __typename id name maturityRating { __typename ratingSystem ratingSystemValues contentMaturityRating maxRatingSystemValue isMaxContentMaturityRating } isAge21Verified flows { __typename star { __typename eligibleForOnboarding isOnboarded } } attributes { __typename isDefault kidsModeEnabled groupWatch { __typename enabled } languagePreferences { __typename appLanguage playbackLanguage preferAudioDescription preferSDH subtitleLanguage subtitlesEnabled } parentalControls { __typename isPinProtected kidProofExitEnabled liveAndUnratedContent { __typename enabled } } playbackSettings { __typename autoplay backgroundVideo prefer133 preferImaxEnhancedVersion} avatar { __typename id userSelected } } } fragment sessionGraphFragment on Session { __typename sessionId device { __typename id } entitlements experiments { __typename featureId variantId version } homeLocation { __typename countryCode } inSupportedLocation isSubscriber location { __typename countryCode } portabilityLocation { __typename countryCode } preferredMaturityRating { __typename impliedMaturityRating ratingSystem } }','variables':{},'operationName':'EntitledGraphMeQuery',}
   response=self.HttpObj.Call_Request(url,json=payload,headers=headers,method='POST')
   if response.status_code not in[200,201]:return{}
   resJson=response.json()
   account =resJson['data']['me']['account']
   activeProfile=account['activeProfile']['id']
   for i_account in account['profiles']:
    if i_account['id']==activeProfile:
     profile_Info=i_account
     break
  except KvSpyomJQatdMFgOzHfDWrTukscliY as exception:
   KvSpyomJQatdMFgOzHfDWrTuksclij(exception)
   return{}
  return profile_Info
 def _set_Imax(self):
  try:
   url =self.DZ['services']['orchestration']['query']['href']
   headers=self.Make_Headers(accessToken=KvSpyomJQatdMFgOzHfDWrTukscliV,Bearer=KvSpyomJQatdMFgOzHfDWrTuksclin)
   payload={'query':'mutation updateProfileImaxEnhancedVersion($input: UpdateProfileImaxEnhancedVersionInput!) {updateProfileImaxEnhancedVersion(updateProfileImaxEnhancedVersion: $input) {accepted}}','variables':{'input':{'imaxEnhancedVersion':KvSpyomJQatdMFgOzHfDWrTukscliV}},}
   response=self.HttpObj.Call_Request(url,json=payload,headers=headers,method='POST')
   if response.status_code not in[200,201]:return{}
   resJson=response.json()
   JsonFile_Save(self.DZ_SESSION_COOKIES4,resJson)
   self.DZ['account']['accessToken'] =resJson.get('extensions').get('sdk').get('token').get('accessToken')
   self.DZ['account']['accessTokenType']=resJson.get('extensions').get('sdk').get('token').get('accessTokenType')
   self.DZ['account']['refreshToken'] =resJson.get('extensions').get('sdk').get('token').get('refreshToken')
   self.DZ['account']['token_limit'] =Get_TimeStamp()+14400 
   self.DZ['account']['deviceId'] =resJson.get('extensions').get('sdk').get('session').get('device').get('id')
   self.DZ['account']['sessionId'] =resJson.get('extensions').get('sdk').get('session').get('sessionId')
  except KvSpyomJQatdMFgOzHfDWrTukscliY as exception:
   KvSpyomJQatdMFgOzHfDWrTuksclij(exception)
   return KvSpyomJQatdMFgOzHfDWrTuksclin
  return KvSpyomJQatdMFgOzHfDWrTukscliV
 def Set_DZ_Imax(self):
  try:
   profile_Info=self.Get_DZ_AccoutInfo()
   if profile_Info['attributes']['playbackSettings']['preferImaxEnhancedVersion']==KvSpyomJQatdMFgOzHfDWrTuksclin:
    self._set_Imax()
    JsonFile_Save(self.DZ_COOKIES_FILENAME,self.DZ)
  except KvSpyomJQatdMFgOzHfDWrTukscliY as exception:
   KvSpyomJQatdMFgOzHfDWrTuksclij(exception)
 def Get_DZ_InitValue(self):
  try:
   url=self.API_DOMAIN 
   response=self.HttpObj.Call_Request(url,params=KvSpyomJQatdMFgOzHfDWrTukscliq,headers=KvSpyomJQatdMFgOzHfDWrTukscliq,method='GET',redirects=KvSpyomJQatdMFgOzHfDWrTuksclin)
   JSON_REGEX=r'<script id="__NEXT_DATA__" type="application/json">\s*(.*?)\s*</script>'
   regex_Text=re.compile(JSON_REGEX,re.DOTALL).findall(response.text)[0]
   paths_json =json.loads(regex_Text)
   self.DZ['headers']['clientId'] =paths_json.get('props').get('pageProps').get('remoteConfig').get('path').get('sdk').get('clientId') 
   self.DZ['headers']['clientApiKey']=paths_json.get('props').get('pageProps').get('remoteConfig').get('path').get('sdk').get('clientApiKey') 
   self.DZ['headers']['lang'] ='ko-kr' 
   self.DZ['headers']['regionCode'] ='KR' 
   self.DZ['headers']['buildId'] =paths_json.get('buildId')
   self.Get_Prod_File() 
  except KvSpyomJQatdMFgOzHfDWrTukscliY as exception:
   KvSpyomJQatdMFgOzHfDWrTuksclij(exception)
   return KvSpyomJQatdMFgOzHfDWrTuksclin
  return KvSpyomJQatdMFgOzHfDWrTukscliV
 def Get_DZ_GetInitToken(self):
  try:
   url =self.DZ['services']['orchestration']['registerDevice']['href']
   headers=self.Make_Headers(accessToken=KvSpyomJQatdMFgOzHfDWrTuksclin,Bearer=KvSpyomJQatdMFgOzHfDWrTukscliV)
   payload={'operationName':'registerDevice','query':'mutation registerDevice($input: RegisterDeviceInput!) {\n      registerDevice(registerDevice: $input) {\n        grant {\n          grantType\n          assertion\n        },\n        token {\n          accessToken\n          accessTokenType\n          expiresIn\n          refreshToken\n          tokenType\n        },\n        session: activeSession {\n          sessionId\n          partnerName\n          device {\n            id\n            category\n            platform\n          }\n          profile {\n            id\n          }\n          experiments {\n            featureId\n            variantId\n            version\n          }\n          portabilityLocation {\n            countryCode\n            type\n          }\n          homeLocation {\n            adsSupported\n            countryCode\n          }\n          household {\n            householdScore\n          }\n          preferredMaturityRating {\n            impliedMaturityRating\n            ratingSystem\n          }\n          identity {\n            id\n          }\n          location {\n            adsSupported\n            type\n            countryCode\n            dma\n            asn\n            regionName\n            connectionType\n            zipCode\n          }\n        }\n      }\n    }','variables':{'input':{'applicationRuntime':'chrome','attributes':{'brand':'web','browserName':'chrome','browserVersion':'146.0.0.0','manufacturer':'n/a','operatingSystem':'windows','operatingSystemVersion':'10.0',},'deviceFamily':'browser','deviceLanguage':'ko','devicePlatformId':'browser','deviceProfile':'windows',}}}
   '''
   payload = {'query' : 'mutation registerDevice($input: RegisterDeviceInput!) {\n            registerDevice(registerDevice: $input) {\n                grant {\n                    grantType\n                    assertion\n                }\n            }\n        }', 'variables' : {'input' : {'applicationRuntime' : 'chrome', 'attributes' : {'browserName' : 'chrome', 'browserVersion' : '96.0.4664', 'manufacturer' : 'microsoft', 'model' : None, 'operatingSystem' : 'windows', 'operatingSystemVersion' : '10.0', 'osDeviceIds' : [], }, 'deviceFamily' : 'browser', 'deviceLanguage' : 'ko-KR', 'deviceProfile' : 'windows', } } }
   '''   
   response=self.HttpObj.Call_Request(url,json=payload,headers=headers,method='POST')
   if response.status_code not in[200,201]:return KvSpyomJQatdMFgOzHfDWrTuksclin
   resJson=response.json()
   if self.Check_ErrorMessage(resJson)==KvSpyomJQatdMFgOzHfDWrTuksclin:return KvSpyomJQatdMFgOzHfDWrTuksclin
   self.DZ['account']['accessToken'] =resJson.get('extensions').get('sdk').get('token').get('accessToken')
   self.DZ['account']['accessTokenType']=resJson.get('extensions').get('sdk').get('token').get('accessTokenType')
   self.DZ['account']['refreshToken'] =resJson.get('extensions').get('sdk').get('token').get('refreshToken')
   self.DZ['account']['token_limit'] =Get_TimeStamp()+14400 
  except KvSpyomJQatdMFgOzHfDWrTukscliY as exception:
   KvSpyomJQatdMFgOzHfDWrTuksclij(exception)
   return KvSpyomJQatdMFgOzHfDWrTuksclin
  return KvSpyomJQatdMFgOzHfDWrTukscliV
 def Get_DZ_GetReToken(self):
  try:
   self.Get_Prod_File()
   url =self.DZ['services']['orchestration']['refreshToken']['href']
   headers=self.Make_Headers(accessToken=KvSpyomJQatdMFgOzHfDWrTuksclin,Bearer=KvSpyomJQatdMFgOzHfDWrTuksclin)
   payload={'query':'mutation refreshToken($input: RefreshTokenInput!) {\n            refreshToken(refreshToken: $input) {\n                activeSession {\n                    sessionId\n                }\n            }\n        }','variables':{'input':{'refreshToken':self.DZ['account']['refreshToken'],}}}
   response=self.HttpObj.Call_Request(url,json=payload,headers=headers,method='POST')
   if response.status_code not in[200,201]:return KvSpyomJQatdMFgOzHfDWrTuksclin
   resJson=response.json()
   if self.Check_ErrorMessage(resJson)==KvSpyomJQatdMFgOzHfDWrTuksclin:return KvSpyomJQatdMFgOzHfDWrTuksclin
   self.DZ['account']['accessToken'] =resJson.get('extensions').get('sdk').get('token').get('accessToken')
   self.DZ['account']['accessTokenType']=resJson.get('extensions').get('sdk').get('token').get('accessTokenType')
   self.DZ['account']['refreshToken'] =resJson.get('extensions').get('sdk').get('token').get('refreshToken')
   self.DZ['account']['token_limit'] =Get_TimeStamp()+14400 
   self.DZ['account']['deviceId'] =resJson.get('extensions').get('sdk').get('session').get('device').get('id')
   self.DZ['account']['sessionId'] =resJson.get('extensions').get('sdk').get('session').get('sessionId')
  except KvSpyomJQatdMFgOzHfDWrTukscliY as exception:
   KvSpyomJQatdMFgOzHfDWrTuksclij(exception)
   return KvSpyomJQatdMFgOzHfDWrTuksclin
  return KvSpyomJQatdMFgOzHfDWrTukscliV
 def Get_DZ_Login(self,userid,userpw,userpf):
  try:
   url =self.DZ['services']['orchestration']['query']['href']
   headers=self.Make_Headers(accessToken=KvSpyomJQatdMFgOzHfDWrTukscliV,Bearer=KvSpyomJQatdMFgOzHfDWrTukscliV)
   payload={'query':'\n    query check($email: String!, $validateEmailOnOperations: ValidateEmailOnOperationsInput) {\n        check(email: $email, validateEmailOnOperations: $validateEmailOnOperations) {\n            operations\n            nextOperation\n            email {\n              isValid\n              validationFailureCodes\n              suggestions {\n                domain\n              }\n            }\n        }\n    }\n','variables':{'email':userid,'validateEmailOnOperations':{'operations':['Register']},}}
   response=self.HttpObj.Call_Request(url,json=payload,headers=headers,method='POST')
   if response.status_code not in[200,201]:return KvSpyomJQatdMFgOzHfDWrTuksclin
   resJson=response.json()
   if 'Login' not in resJson.get('data').get('check').get('operations'):return KvSpyomJQatdMFgOzHfDWrTuksclin 
   url =self.DZ['services']['orchestration']['query']['href']
   headers=self.Make_Headers(accessToken=KvSpyomJQatdMFgOzHfDWrTukscliV,Bearer=KvSpyomJQatdMFgOzHfDWrTukscliV)
   payload={'operationName':'login','query':'\n    mutation login($input: LoginInput!) {\n        login(login: $input) {\n            actionGrant\n            account {\n              activeProfile {\n                id\n              }\n              profiles {\n                id\n                attributes {\n                  isDefault\n                  parentalControls {\n                    isPinProtected\n                  }\n                }\n              }\n            }\n            activeSession {\n              isSubscriber\n            }\n            identity {\n              personalInfo {\n                dateOfBirth\n                gender\n              }\n              flows {\n                personalInfo {\n                  requiresCollection\n                  eligibleForCollection\n                }\n              }\n            }\n        }\n    }\n','variables':{'input':{'email':userid,'password':userpw,}}}
   response=self.HttpObj.Call_Request(url,json=payload,headers=headers,method='POST')
   if response.status_code not in[200,201]:return KvSpyomJQatdMFgOzHfDWrTuksclin
   resJson=response.json()
   if self.Check_ErrorMessage(resJson)==KvSpyomJQatdMFgOzHfDWrTuksclin:return KvSpyomJQatdMFgOzHfDWrTuksclin
   self.DZ['account']['accessToken'] =resJson.get('extensions').get('sdk').get('token').get('accessToken')
   self.DZ['account']['accessTokenType']=resJson.get('extensions').get('sdk').get('token').get('accessTokenType')
   self.DZ['account']['refreshToken'] =resJson.get('extensions').get('sdk').get('token').get('refreshToken')
   self.DZ['account']['token_limit'] =Get_TimeStamp()+14400 
   self.DZ['account']['profile'] =resJson.get('data').get('login').get('account').get('profiles')[userpf].get('id')
   url =self.DZ['services']['orchestration']['query']['href']
   headers=self.Make_Headers(accessToken=KvSpyomJQatdMFgOzHfDWrTukscliV,Bearer=KvSpyomJQatdMFgOzHfDWrTukscliV)
   payload={'operationName':'switchProfile','query':'\n    mutation switchProfile($input: SwitchProfileInput!) {\n        switchProfile(switchProfile: $input) {\n            account {\n                ...account\n\n                activeProfile {\n                    ...profile\n                    \n                }\n            }\n            activeSession {\n                ...session\n            }\n        }\n    }\n\n    \nfragment account on Account {\n    id\n    accountConsentToken\n    attributes {\n        blocks {\n            expiry\n            reason\n        }\n        maxNumberOfProfilesAllowed\n        consentPreferences {\n            dataElements {\n                name\n                value\n            }\n            purposes {\n                consentDate\n                firstTransactionDate\n                id\n                lastTransactionCollectionPointId\n                lastTransactionCollectionPointVersion\n                lastTransactionDate\n                name\n                status\n                totalTransactionCount\n                version\n            }\n        }\n        dssIdentityCreatedAt\n        email\n        emailVerified\n        lastSecurityFlaggedAt\n        locations {\n            manual {\n                country\n            }\n            purchase {\n                country\n                source\n            }\n            registration {\n                geoIp {\n                    country\n                }\n            }\n        }\n        securityFlagged\n        tags\n        taxId\n        userVerified\n    }\n    parentalControls {\n        isProfileCreationProtected\n    }\n    flows {\n        star {\n            isOnboarded\n        }\n    }\n    umpMessages {\n        data {\n            messages {\n                messageId\n                messageSource\n                displayLocations\n                content\n            }\n        }\n    }\n}\n\n    \nfragment profile on Profile {\n    id\n    name\n    isAge21Verified\n    attributes {\n        avatar {\n            id\n            userSelected\n        }\n        isDefault\n        kidsModeEnabled\n        languagePreferences {\n            appLanguage\n            playbackLanguage\n            preferAudioDescription\n            preferSDH\n            subtitleLanguage\n            subtitlesEnabled\n        }\n        parentalControls {\n            kidProofExitEnabled\n            isPinProtected\n            liveAndUnratedContent {\n                enabled\n                available\n            }\n        }\n        playbackSettings {\n            autoplay\n            backgroundVideo\n            prefer133\n            preferImaxEnhancedVersion\n            previewAudioOnHome\n            previewVideoOnHome\n        }\n        privacySettings {\n            consents {\n                consentType\n                value\n            }\n        }\n    }\n    avatar {\n        id\n        type\n        images {\n            masterId\n            url\n        }\n    }\n    personalInfo {\n        dateOfBirth\n        gender\n        age\n    }\n    maturityRating {\n        ...maturityRating\n    }\n    metadata {\n        globalTimeOverride\n    }\n    personalInfo {\n        dateOfBirth\n        age\n        gender\n    }\n    flows {\n        personalInfo {\n            eligibleForCollection\n            requiresCollection\n        }\n        star {\n            eligibleForOnboarding\n            isOnboarded\n        }\n    }\n}\n\n\nfragment maturityRating on MaturityRating {\n    ratingSystem\n    ratingSystemValues\n    contentMaturityRating\n    maxRatingSystemValue\n    isMaxContentMaturityRating\n    suggestedMaturityRatings {\n        minimumAge\n        maximumAge\n        ratingSystemValue\n    }\n}\n\n\n    \nfragment session on Session {\n    device {\n        id\n        platform\n    }\n    entitlements\n    features {\n        coPlay\n    }\n    inSupportedLocation\n    isSubscriber\n    location {\n        type\n        countryCode\n        dma\n        asn\n        regionName\n        connectionType\n        zipCode\n    }\n    sessionId\n    experiments {\n        featureId\n        variantId\n        version\n    }\n    identity {\n        id\n    }\n    account {\n        id\n    }\n    profile {\n        id\n        parentalControls {\n            liveAndUnratedContent {\n                enabled\n            }\n        }\n    }\n    partnerName\n    preferredMaturityRating {\n        impliedMaturityRating\n        ratingSystem\n    }\n    homeLocation {\n        countryCode\n    }\n    portabilityLocation {\n        countryCode\n        type\n    }\n}\n\n','variables':{'input':{'profileId':self.DZ['account']['profile'],}}}
   response=self.HttpObj.Call_Request(url,json=payload,headers=headers,method='POST')
   if response.status_code not in[200,201]:return KvSpyomJQatdMFgOzHfDWrTuksclin
   resJson=response.json()
   if self.Check_ErrorMessage(resJson)==KvSpyomJQatdMFgOzHfDWrTuksclin:return KvSpyomJQatdMFgOzHfDWrTuksclin
   self.DZ['account']['accessToken'] =resJson.get('extensions').get('sdk').get('token').get('accessToken')
   self.DZ['account']['accessTokenType']=resJson.get('extensions').get('sdk').get('token').get('accessTokenType')
   self.DZ['account']['refreshToken'] =resJson.get('extensions').get('sdk').get('token').get('refreshToken')
   self.DZ['account']['token_limit'] =Get_TimeStamp()+14400 
   self.DZ['account']['deviceId'] =resJson.get('extensions').get('sdk').get('session').get('device').get('id')
   self.DZ['account']['sessionId'] =resJson.get('extensions').get('sdk').get('session').get('sessionId')
   self.Save_session_acount(userid,userpw,userpf)
  except KvSpyomJQatdMFgOzHfDWrTukscliY as exception:
   KvSpyomJQatdMFgOzHfDWrTuksclij(exception)
   return KvSpyomJQatdMFgOzHfDWrTuksclin
  return KvSpyomJQatdMFgOzHfDWrTukscliV
 def Make_Endpoint(self,uMode,**kwargs):
  if uMode=='COLLECTION':
   href=self.DZ['services']['content']['getCollection']['href']
  elif uMode=='PROGRAM_LIST':
   href=self.DZ['services']['content']['getCuratedSet']['href']
  elif uMode=='SEASON_LIST':
   href=self.DZ['services']['content']['getDmcSeriesBundle']['href']
  elif uMode=='EPISODE_LIST':
   href=self.DZ['services']['content']['getDmcEpisodes']['href']
  elif uMode=='STREAMING_URL':
   href=self.DZ['services']['media']['mediaPayload']['href']
  elif uMode=='SEARCH_LIST':
   href=self.DZ['services']['content']['getSearchResults']['href']
  elif uMode=='VIDEO_BUNDLE':
   href=self.DZ['services']['content']['getDmcVideoBundle']['href']
  elif uMode=='DEEP_LINK':
   href=self.DZ['services']['explore']['getDeeplink']['href']
  elif uMode=='PLAYER_EXPERIENCE':
   href=self.DZ['services']['explore']['getPlayerExperience']['href']
  else:
   return ''
  _args={'apiVersion':'5.1','region':self.DZ['headers']['regionCode'],'kidsModeEnabled':'false','impliedMaturityRating':'1870','appLanguage':self.DZ['headers']['lang'][0:2],'partner':'disney','queryType':'ge','version':'v1.10',}
  _args.update(**kwargs)
  return href.format(**_args)
 def Get_Brand_List(self):
  page_list=[]
  HomePageId =self.Get_DeepLink_PageId('home')
  BrandsPageGroup=KvSpyomJQatdMFgOzHfDWrTukscliq
  try:
   url ='{}/{}/page/{}?disableSmartFocus=true&enhancedContainersLimit=0&limit=15'.format(self.API_DOMAIN_NEW,self.API_VERSION_NEW,HomePageId)
   headers=self.Make_Headers(accessToken=KvSpyomJQatdMFgOzHfDWrTukscliV,Bearer=KvSpyomJQatdMFgOzHfDWrTukscliV)
   response=self.HttpObj.Call_Request(url,headers=headers,method='GET')
   if response.status_code not in[200,201]:return[]
   resJson=response.json()['data']['page']
   for iContainer in resJson.get('containers'):
    if iContainer['type']=='nestingGroup':
     BrandsPageGroup=iContainer['nestedPages']
     break
  except KvSpyomJQatdMFgOzHfDWrTukscliY as exception:
   KvSpyomJQatdMFgOzHfDWrTuksclij(exception)
   return[]
  try:
   for iItem in BrandsPageGroup:
    temp_list={'title':iItem['visuals']['name'],'pageId':iItem['containers'][0]['actions'][0]['pageId'],'image':self.Image_IdtoUrl(iItem['visuals']['artwork']['brand']['logo_white']['2.00']['imageId'])}
    page_list.append(temp_list)
  except KvSpyomJQatdMFgOzHfDWrTukscliY as exception:
   KvSpyomJQatdMFgOzHfDWrTuksclij(exception)
   return[]
  return page_list
 def Get_Group_Title(self,refId,refType):
  group_title='None'
  try:
   url =self.Make_Endpoint('PROGRAM_LIST',setId=refId,pageSize=KvSpyomJQatdMFgOzHfDWrTuksclix(15),page=KvSpyomJQatdMFgOzHfDWrTuksclix(1))
   headers=self.Make_Headers(accessToken=KvSpyomJQatdMFgOzHfDWrTukscliV,Bearer=KvSpyomJQatdMFgOzHfDWrTukscliV)
   if refType!='CuratedSet':
    url=url.replace('CuratedSet',refType)
   response=self.HttpObj.Call_Request(url,headers=headers,method='GET')
   if response.status_code not in[200,201]:group_title
   resJson=response.json().get('data').get(refType)
   group_title=resJson.get('text').get('title').get('full').get('set').get('default').get('content').strip()
  except KvSpyomJQatdMFgOzHfDWrTukscliY as exception:
   KvSpyomJQatdMFgOzHfDWrTuksclij(exception)
   return group_title
  return group_title
 def Get_refId(self,contentClass,contentSlugs):
  try:
   url =self.Make_Endpoint('COLLECTION',collectionSubType='StandardCollection',contentClass=contentClass,slug=contentSlugs)
   headers=self.Make_Headers(accessToken=KvSpyomJQatdMFgOzHfDWrTukscliV,Bearer=KvSpyomJQatdMFgOzHfDWrTukscliV)
   response=self.HttpObj.Call_Request(url,headers=headers,method='GET')
   if response.status_code not in[200,201]:return KvSpyomJQatdMFgOzHfDWrTuksclin
   resJson=response.json()
   refId =resJson['data']['Collection']['containers'][0]['set']['refId']
   refType=resJson['data']['Collection']['containers'][0]['set']['refType']
  except KvSpyomJQatdMFgOzHfDWrTukscliY as exception:
   KvSpyomJQatdMFgOzHfDWrTuksclij(exception)
   return '',''
  return refId,refType
 def Get_imageurl_parser2(self,imageJson,imageType,imageSize):
  result_URL =''
  try:
   for iType in imageType:
    tempImage=imageJson.get(iType)
    if tempImage!=KvSpyomJQatdMFgOzHfDWrTukscliq:break
   for i_size in imageSize:
    if tempImage.get(i_size)==KvSpyomJQatdMFgOzHfDWrTukscliq:continue
    result_URL=tempImage.get(i_size).get('imageId')
    break
   if result_URL=='':
    for i_value in tempImage:
     result_URL=tempImage.get(i_value).get('imageId')
     break
  except KvSpyomJQatdMFgOzHfDWrTukscliY as exception:
   KvSpyomJQatdMFgOzHfDWrTuksclij(exception)
   return '' 
  if result_URL!='':
   result_URL=self.Image_IdtoUrl(result_URL)
  return result_URL
 def Generate_UUID_32(self):
  import random
  import hashlib
  m=hashlib.md5()
  hash_str=KvSpyomJQatdMFgOzHfDWrTuksclix(random.random())
  m.update(hash_str.encode('utf-8'))
  pvid=KvSpyomJQatdMFgOzHfDWrTuksclix(m.hexdigest())
  return '%s-%s-%s-%s-%s'%(pvid[:8],pvid[8:12],pvid[12:16],pvid[16:20],pvid[20:])
 def Delete_Watch_List(self,delInfoBlock):
  try:
   import datetime
   nowtime=datetime.datetime.utcnow()
   nowtime=nowtime.strftime('%Y-%m-%dT%H:%M:%S.001Z')
   url ='https://disney.api.edge.bamgrid.com/envelope'
   headers=self.Make_Headers(accessToken=KvSpyomJQatdMFgOzHfDWrTukscliV,Bearer=KvSpyomJQatdMFgOzHfDWrTukscliV)
   payload=[{'data':{'action_info_block':delInfoBlock},'datacontenttype':'application/json;charset=utf-8','id':self.Generate_UUID_32(),'schemaurl':'https://github.bamtech.co/schema-registry/schema-registry-client-signals/blob/series/1.X.X/smithy/dss/cs/event/user-content-actions/preference/v1/watch-history-preference.smithy','source':'urn:dss:source:sdk:javascript:windows:chrome','subject':'sessionId={},profileId={}'.format(self.DZ['account']['sessionId'],self.DZ['account']['profile']),'time':nowtime,'type':'urn:dss:event:cs:user-content-actions:preference:v1:watch-history-preference',}]
   response=self.HttpObj.Call_Request(url,json=payload,headers=headers,method='POST')
   if response.status_code not in[200,201]:return KvSpyomJQatdMFgOzHfDWrTuksclin
  except KvSpyomJQatdMFgOzHfDWrTukscliY as exception:
   KvSpyomJQatdMFgOzHfDWrTuksclij(exception)
   return KvSpyomJQatdMFgOzHfDWrTuksclin
  return KvSpyomJQatdMFgOzHfDWrTukscliV
 def Get_Search_List(self,search_key):
  search_list=[]
  try:
   url ='{}/{}/search'.format(self.API_DOMAIN_NEW,self.API_VERSION_NEW)
   headers=self.Make_Headers(accessToken=KvSpyomJQatdMFgOzHfDWrTukscliV,Bearer=KvSpyomJQatdMFgOzHfDWrTukscliV)
   params ={'query':search_key,}
   response=self.HttpObj.Call_Request(url,headers=headers,params=params,method='GET')
   if response.status_code not in[200,201]:return[]
   resJson=response.json().get('data').get('page').get('containers')
   for i_item in resJson[0]['items']:
    image=i_item['visuals']['artwork']['standard']
    fanart =self.Get_imageurl_parser2(image,['background_details','background'],['1.78','0.71'])
    thumb =self.Get_imageurl_parser2(image,['thumbnail','background_details','background'],['1.78','0.71'])
    poster =self.Get_imageurl_parser2(image,['tile'],['0.71','1.78'])
    clearlogo=self.Get_imageurl_parser2(image,['title_treatment'],['1.78','0.71'])
    temp_list={'title':i_item['visuals']['title'],'entityId':i_item['actions'][0]['pageId'],'vType':'movie' if 'durationMs' in i_item['visuals']else 'tvshow','duration':KvSpyomJQatdMFgOzHfDWrTukscliR(i_item['visuals']['durationMs']/1000)if 'durationMs' in i_item['visuals']else 0,'desc':i_item['visuals']['description']['full'],'year':i_item['visuals']['metastringParts']['releaseYearRange']['startYear'],'poster':poster,'thumb':thumb,'clearlogo':clearlogo,'fanart':fanart,}
    search_list.append(temp_list)
  except KvSpyomJQatdMFgOzHfDWrTukscliY as exception:
   KvSpyomJQatdMFgOzHfDWrTuksclij(exception)
   return[]
  return search_list
 def Get_Season_List2(self,entityId):
  season_list=[]
  try:
   url ='{}/{}/page/{}'.format(self.API_DOMAIN_NEW,self.API_VERSION_NEW,entityId)
   headers=self.Make_Headers(accessToken=KvSpyomJQatdMFgOzHfDWrTukscliV,Bearer=KvSpyomJQatdMFgOzHfDWrTukscliV)
   params ={'disableSmartFocus':KvSpyomJQatdMFgOzHfDWrTukscliV,'enhancedContainersLimit':15,'limit':15,}
   response=self.HttpObj.Call_Request(url,headers=headers,params=params,method='GET')
   if response.status_code not in[200,201]:return[]
   resJson=response.json()['data']['page']
   for iContainer in resJson['containers']:
    if iContainer.get('type')=='episodes':
     seasonsJson=iContainer
   detailsJson=resJson['visuals']
   desc=detailsJson['description']['full']
   imageJson=detailsJson['artwork']['standard']
   poster =self.Get_imageurl_parser2(imageJson,['tile'],['0.75','0.71','0.67'])
   for iSeason in seasonsJson.get('seasons'):
    temp_list={'seasonId':iSeason['id'],'seasonNum':iSeason['visuals']['name'],'episodeCnt':iSeason['pagination']['totalCount'],'desc':desc,'poster':poster,}
    season_list.append(temp_list)
  except KvSpyomJQatdMFgOzHfDWrTukscliY as exception:
   KvSpyomJQatdMFgOzHfDWrTuksclij(exception)
   return[]
  return season_list
 def Get_Episode_List(self,seasonId,page_int):
  episode_list=[]
  more_page =KvSpyomJQatdMFgOzHfDWrTuksclin
  try:
   url ='{}/{}/season/{}'.format(self.API_DOMAIN_NEW,self.API_VERSION_NEW,seasonId)
   headers=self.Make_Headers(accessToken=KvSpyomJQatdMFgOzHfDWrTukscliV,Bearer=KvSpyomJQatdMFgOzHfDWrTukscliV)
   params ={'limit':self.ONE_PAGE,'offset':(page_int-1)*self.ONE_PAGE,}
   response=self.HttpObj.Call_Request(url,headers=headers,params=params,method='GET')
   if response.status_code not in[200,201]:return[],KvSpyomJQatdMFgOzHfDWrTuksclin
   resJson=response.json()['data']['season']
   for i_item in resJson.get('items'):
    resourceId =i_item['actions'][0]['resourceId']
    availId =i_item['actions'][0]['availId']
    title =i_item['visuals']['episodeTitle']
    tvshowtitle=i_item['visuals']['title']
    desc =i_item['visuals']['description']['full']
    duration =KvSpyomJQatdMFgOzHfDWrTukscliR(i_item['visuals']['durationMs']/1000)
    seasonNum =i_item['visuals']['seasonNumber']
    episodeNum =i_item['visuals']['episodeNumber']
    imageJson=i_item['visuals']['artwork']['standard']
    fanart =self.Get_imageurl_parser2(imageJson,['thumbnail','background','tile'],['1.78','1.33'])
    thumb =self.Get_imageurl_parser2(imageJson,['tile'],['1.78','1.33'])
    poster =self.Get_imageurl_parser2(imageJson,['tile'],['0.75','0.71','0.67'])
    clearlogo=self.Get_imageurl_parser2(imageJson,['title_treatment'],['1.78'])
    temp_list={'resourceId':resourceId,'availId':availId,'title':title,'tvshowtitle':tvshowtitle,'desc':desc,'duration':duration,'seasonNum':seasonNum,'episodeNum':episodeNum,'fanart':fanart,'thumb':thumb,'poster':poster,'clearlogo':clearlogo,}
    episode_list.append(temp_list)
   more_page=resJson['pagination']['hasMore']
  except KvSpyomJQatdMFgOzHfDWrTukscliY as exception:
   KvSpyomJQatdMFgOzHfDWrTuksclij(exception)
   return[],KvSpyomJQatdMFgOzHfDWrTuksclin
  return episode_list,more_page
 def GetStreamingURL(self,resource_id,available_id,playOption):
  streamInfo={'streamUrl':'','drmUrl':'','defaultAudio':'',}
  try:
   url =self.Make_Endpoint('PLAYER_EXPERIENCE',availId=available_id)
   headers =self.Make_Headers(accessToken=KvSpyomJQatdMFgOzHfDWrTukscliV,Bearer=KvSpyomJQatdMFgOzHfDWrTuksclin)
   response=self.HttpObj.Call_Request(url,headers=headers,method='GET')
   if response.status_code not in[200,201]:return streamInfo
   resJson =response.json()
   streamInfo['defaultAudio']=resJson['data']['playerExperience']['originalLanguage']
   scenario='ctr-high' if playOption['video_h265']else 'ctr-regular'
   url =self.Make_Endpoint('STREAMING_URL',scenario=scenario)
   headers =self.Make_Headers(accessToken=KvSpyomJQatdMFgOzHfDWrTukscliV,Bearer=KvSpyomJQatdMFgOzHfDWrTuksclin)
   headers['accept']='application/vnd.media-service+json'
   headers['x-dss-feature-filtering']='true'
   payload={'playbackId':resource_id,'playback':{"attributes":{'codecs':{'supportsMultiCodecMaster':KvSpyomJQatdMFgOzHfDWrTuksclin,},'protocol':'HTTPS','frameRates':[60],'assetInsertionStrategy':'SGAI','playbackInitializationContext':'ONLINE',},},}
   video_ranges=[]
   audio_types =[]
   if playOption.get('wv_secure')and playOption.get('video_h265'):
    payload['playback']['attributes']['codecs']={'video':['h264','h265']}
    if playOption.get('video_hdr'):
     video_ranges.append('HDR10')
    elif playOption.get('video_dolby'):
     video_ranges.append('DOLBY_VISION')
    if playOption.get('sound_atmos'):
     audio_types.append('ATMOS')
   else:
    payload['playback']['attributes']['resolution']={'max':['1280x720']}
   if audio_types:
    payload['playback']['attributes']['audioTypes']=audio_types
   if video_ranges:
    payload['playback']['attributes']['videoRanges']=video_ranges
   response=self.HttpObj.Call_Request(url,headers=headers,json=payload,method='POST')
   if response.status_code not in[200,201]:return streamInfo
   resJson =response.json()
   streamInfo['streamUrl'] =response.json()['stream']['sources'][0]['complete']['url']
   streamInfo['drmUrl'] =self.DZ['services']['drm']['widevineLicense']['href']
  except KvSpyomJQatdMFgOzHfDWrTukscliY as exception:
   KvSpyomJQatdMFgOzHfDWrTuksclij(exception)
   return streamInfo
  self.Disney_Parse_Main(streamInfo['streamUrl'],streamInfo['defaultAudio'],playOption)
  return streamInfo
 def GetStreamingURL2(self,contentId,playOption):
  streamInfo={'streamUrl':'','drmUrl':'','defaultAudio':'',}
  try:
   url =self.Make_Endpoint('DEEP_LINK')
   headers =self.Make_Headers(accessToken=KvSpyomJQatdMFgOzHfDWrTukscliV,Bearer=KvSpyomJQatdMFgOzHfDWrTuksclin)
   params ={'refId':contentId,'refIdType':'dmcContentId','action':'playback',}
   response=self.HttpObj.Call_Request(url,headers=headers,params=params,method='GET')
   if response.status_code not in[200,201]:return streamInfo
   resJson =response.json()
   resource_id =resJson['data']['deeplink']['actions'][0]['resourceId']
   available_id=resJson['data']['deeplink']['actions'][0]['availId']
   url =self.Make_Endpoint('PLAYER_EXPERIENCE',availId=available_id)
   headers =self.Make_Headers(accessToken=KvSpyomJQatdMFgOzHfDWrTukscliV,Bearer=KvSpyomJQatdMFgOzHfDWrTuksclin)
   response=self.HttpObj.Call_Request(url,headers=headers,method='GET')
   if response.status_code not in[200,201]:return streamInfo
   resJson =response.json()
   streamInfo['defaultAudio']=resJson['data']['playerExperience']['originalLanguage']
   scenario='ctr-high' if playOption['video_h265']else 'ctr-regular'
   url =self.Make_Endpoint('STREAMING_URL',scenario=scenario)
   headers =self.Make_Headers(accessToken=KvSpyomJQatdMFgOzHfDWrTukscliV,Bearer=KvSpyomJQatdMFgOzHfDWrTuksclin)
   headers['accept']='application/vnd.media-service+json'
   headers['x-dss-feature-filtering']='true'
   payload={'playbackId':resource_id,'playback':{"attributes":{'codecs':{'supportsMultiCodecMaster':KvSpyomJQatdMFgOzHfDWrTuksclin,},'protocol':'HTTPS','frameRates':[60],'assetInsertionStrategy':'SGAI','playbackInitializationContext':'ONLINE',},},}
   video_ranges=[]
   audio_types =[]
   if playOption.get('wv_secure')and playOption.get('video_h265'):
    payload['playback']['attributes']['codecs']={'video':['h264','h265']}
    if playOption.get('video_hdr'):
     video_ranges.append('HDR10')
    elif playOption.get('video_dolby'):
     video_ranges.append('DOLBY_VISION')
    if playOption.get('sound_atmos'):
     audio_types.append('ATMOS')
   else:
    payload['playback']['attributes']['resolution']={'max':['1280x720']}
   if audio_types:
    payload['playback']['attributes']['audioTypes']=audio_types
   if video_ranges:
    payload['playback']['attributes']['videoRanges']=video_ranges
   response=self.HttpObj.Call_Request(url,headers=headers,json=payload,method='POST')
   if response.status_code not in[200,201]:return streamInfo
   resJson =response.json()
   streamInfo['streamUrl'] =response.json()['stream']['sources'][0]['complete']['url']
   streamInfo['drmUrl'] =self.DZ['services']['drm']['widevineLicense']['href']
  except KvSpyomJQatdMFgOzHfDWrTukscliY as exception:
   KvSpyomJQatdMFgOzHfDWrTuksclij(exception)
   return streamInfo
  self.Disney_Parse_Main(streamInfo['streamUrl'],streamInfo['defaultAudio'],playOption)
  return streamInfo
 def Get_BaseUrl(self,in_url):
  parseResult=urllib.parse.urlparse(in_url) 
  scheme =parseResult.scheme
  netloc =parseResult.netloc
  full_path=parseResult.path.strip('/').split('/')
  full_path.pop(KvSpyomJQatdMFgOzHfDWrTukscliA(full_path)-1)
  baseUrl =scheme+'://'+netloc+'/'+'/'.join(full_path)+'/'
  return baseUrl
 def VTT_FileList(self,vtt_url):
  file_list=[]
  response=requests.get(vtt_url)
  m3u8_data=response.content.decode('utf-8')
  skipTag=KvSpyomJQatdMFgOzHfDWrTuksclin
  for nowln in m3u8_data.splitlines():
   if nowln.endswith('.vtt'):
    if skipTag:
     skipTag=KvSpyomJQatdMFgOzHfDWrTuksclin
    else:
     file_list.append(nowln)
  return file_list
 def VTT_Detail(self,sub_url,vttDelay):
  subtitle=''
  response=requests.get(sub_url)
  vtt_data=response.content.decode('utf-8')
  SUB_START=KvSpyomJQatdMFgOzHfDWrTuksclin
  tm_delay=datetime.timedelta(seconds=vttDelay)
  for nowln in vtt_data.splitlines():
   line=re.match('\d\d:\d\d:\d\d.\d\d\d',nowln)
   if line:
    SUB_START=KvSpyomJQatdMFgOzHfDWrTukscliV
    if vttDelay==0.0:
     subtitle+=nowln[0:29]+'\n'
    else:
     starttm=self.Timedelta_To_Str(self.Str_To_Timedelta(nowln[0:12])+tm_delay)
     endtm =self.Timedelta_To_Str(self.Str_To_Timedelta(nowln[17:29])+tm_delay)
     subtitle+='{} --> {}\n'.format(starttm,endtm)
   elif nowln!='' and SUB_START==KvSpyomJQatdMFgOzHfDWrTukscliV:
    subtitle+=nowln+'\n'
   elif nowln=='' and SUB_START==KvSpyomJQatdMFgOzHfDWrTukscliV:
    SUB_START=KvSpyomJQatdMFgOzHfDWrTuksclin
    subtitle+='\n'
  return subtitle
 def Str_To_Timedelta(self,in_tm):
  hours =KvSpyomJQatdMFgOzHfDWrTukscliR(in_tm[0:2])
  minutes =KvSpyomJQatdMFgOzHfDWrTukscliR(in_tm[3:5])
  seconds =KvSpyomJQatdMFgOzHfDWrTukscliR(in_tm[6:8])
  milliseconds=KvSpyomJQatdMFgOzHfDWrTukscliR(in_tm[-3:])
  return datetime.timedelta(hours=hours,minutes=minutes,seconds=seconds,milliseconds=milliseconds)
 def Timedelta_To_Str(self,tm_delta):
  seconds =tm_delta.seconds
  hours ,seconds=KvSpyomJQatdMFgOzHfDWrTukscliP(seconds,3600)
  minutes,seconds=KvSpyomJQatdMFgOzHfDWrTukscliP(seconds,60)
  milliseconds =KvSpyomJQatdMFgOzHfDWrTukscliR(tm_delta.microseconds/1000)
  return '{:0>2}:{:0>2}:{:0>2}.{:0<3}'.format(hours,minutes,seconds,milliseconds)
 def Check_DelayTime(self,vod_url):
  delay_time=0.0
  response=requests.get(vod_url)
  vod_data=response.content.decode('utf-8')
  max_count=10
  for nowln in vod_data.splitlines():
   max_count-=1
   if max_count==0:break
   if nowln.startswith('#EXT-X-DATERANGE'):
    attribs=self.Disney_MediaLine_Parse(nowln,'#EXT-X-DATERANGE')
    if 'DURATION' in attribs: 
     if KvSpyomJQatdMFgOzHfDWrTukscliN(attribs['DURATION'])<10.0:
      delay_time=KvSpyomJQatdMFgOzHfDWrTukscliN(attribs['DURATION'])
     break 
  return delay_time
 def Disney_MediaLine_Parse(self,line,prefix):
  attribs={}
  for row in ATTRIBUTE_PATTERN.split(line.replace(prefix+':',''))[1::2]:
   name,value=row.split('=',1)
   attribs[name.upper()]=value.replace('"','').strip()
  return attribs
 def VTT_Make_Main(self,vtt_url,vttDelay):
  try:
   BASE_URL=self.Get_BaseUrl(vtt_url)
   vtt_filelist=self.VTT_FileList(vtt_url)
   f=KvSpyomJQatdMFgOzHfDWrTuksclib(self.DZ_VTT_FILENAME,'w',-1,'utf-8')
   f.write('WEBVTT\n\n')
   for i_file in vtt_filelist:
    f.write(self.VTT_Detail(sub_url=BASE_URL+i_file,vttDelay=vttDelay))
   f.close()
  except:
   if os.path.isfile(self.DZ_VTT_FILENAME): 
    os.remove(self.DZ_VTT_FILENAME)
   return KvSpyomJQatdMFgOzHfDWrTuksclin
  return KvSpyomJQatdMFgOzHfDWrTukscliV
 def Disney_Parse_Main(self,stream_url,defaultAudio,playOption):
  vttDelay=0.0
  response=requests.get(url=stream_url)
  m3u8 =response.content.decode('utf-8')
  BASE_URL=self.Get_BaseUrl(stream_url)
  self.Disney_Parse_m3u8(m3u8,defaultAudio,playOption)
  delay_check =KvSpyomJQatdMFgOzHfDWrTuksclin
  for line in m3u8.splitlines():
   if delay_check==KvSpyomJQatdMFgOzHfDWrTukscliV:
    delay_check=KvSpyomJQatdMFgOzHfDWrTuksclin
    vod_url =BASE_URL+line
    vttDelay=0
    if playOption.get('play_resume')==KvSpyomJQatdMFgOzHfDWrTuksclin:
     vttDelay=self.Check_DelayTime(vod_url)
    break 
   elif line.startswith('#EXT-X-STREAM-INF'):
    delay_check=KvSpyomJQatdMFgOzHfDWrTukscliV
  for line in m3u8.splitlines():
   if line.startswith('#EXT-X-MEDIA'):
    attribs=self.Disney_MediaLine_Parse(line,'#EXT-X-MEDIA')
    if attribs.get('TYPE')=='SUBTITLES' and attribs.get('FORCED')!='YES' and attribs.get('LANGUAGE')=='ko':
     return self.VTT_Make_Main(BASE_URL+attribs.get('URI'),vttDelay)
  return KvSpyomJQatdMFgOzHfDWrTukscliV
 def Disney_Parse_m3u8(self,m3u8,defaultAudio,playOption):
  try:
   exists_aac =KvSpyomJQatdMFgOzHfDWrTuksclin
   exists_dd =KvSpyomJQatdMFgOzHfDWrTuksclin
   exists_atoms=KvSpyomJQatdMFgOzHfDWrTuksclin
   max_res =0
   max_resStr =''
   for line in m3u8.splitlines():
    if line.startswith('#EXT-X-MEDIA'):
     attribs=self.Disney_MediaLine_Parse(line,'#EXT-X-MEDIA')
     if attribs.get('GROUP-ID')in['aac-128k','aac-64k']:exists_aac =KvSpyomJQatdMFgOzHfDWrTukscliV
     elif attribs.get('GROUP-ID')in['eac-3']:exists_dd =KvSpyomJQatdMFgOzHfDWrTukscliV
     elif attribs.get('GROUP-ID')in['atmos']:exists_atoms=KvSpyomJQatdMFgOzHfDWrTukscliV
    elif line.startswith('#EXT-X-STREAM-INF'):
     attribs=self.Disney_MediaLine_Parse(line,'#EXT-X-STREAM-INF')
     i_resolution=KvSpyomJQatdMFgOzHfDWrTukscliR(attribs.get('RESOLUTION').split('x',1)[0])
     if i_resolution<=playOption['maxResolution']and i_resolution>max_res:
      max_res =i_resolution
      max_resStr=attribs.get('RESOLUTION')
   if exists_atoms==KvSpyomJQatdMFgOzHfDWrTuksclin and playOption['sound_atmos']==KvSpyomJQatdMFgOzHfDWrTukscliV:
    playOption['sound_dd']=KvSpyomJQatdMFgOzHfDWrTukscliV
   if exists_atoms==KvSpyomJQatdMFgOzHfDWrTuksclin and exists_dd==KvSpyomJQatdMFgOzHfDWrTuksclin and playOption['sound_dd']==KvSpyomJQatdMFgOzHfDWrTukscliV:
    playOption['sound_aac']=KvSpyomJQatdMFgOzHfDWrTukscliV
  except KvSpyomJQatdMFgOzHfDWrTukscliY as exception:
   KvSpyomJQatdMFgOzHfDWrTuksclij(exception)
   pass
  Remove_AudioList=[]
  if not playOption['sound_aac']:
   Remove_AudioList.append('aac-128k')
   Remove_AudioList.append('aac-64k')
  if not playOption['sound_dd']:
   Remove_AudioList.append('eac-3')
  if not playOption['sound_atmos']:
   Remove_AudioList.append('atmos')
  res_lines=[]
  try:
   Skip_NextLine=KvSpyomJQatdMFgOzHfDWrTuksclin
   Before_Blank =KvSpyomJQatdMFgOzHfDWrTuksclin
   for line in m3u8.splitlines():
    if not line.strip():
     if Before_Blank==KvSpyomJQatdMFgOzHfDWrTuksclin:
      res_lines.append(line)
      Before_Blank=KvSpyomJQatdMFgOzHfDWrTukscliV
     continue
    else:
     Before_Blank =KvSpyomJQatdMFgOzHfDWrTuksclin
    if Skip_NextLine==KvSpyomJQatdMFgOzHfDWrTukscliV:
     Skip_NextLine=KvSpyomJQatdMFgOzHfDWrTuksclin
     continue
    if line.startswith('#EXT-X-MEDIA'):
     attribs=self.Disney_MediaLine_Parse(line,'#EXT-X-MEDIA')
     if attribs.get('TYPE')=='AUDIO':
      if attribs.get('LANGUAGE')not in['ko','en',defaultAudio]:
       continue
      if attribs.get('GROUP-ID')in Remove_AudioList:
       continue
      if 'JOC' in attribs.get('CHANNELS'):
       line=line.replace('NAME="{}"'.format(attribs.get('NAME')),'NAME="{} [Atmos]"'.format(attribs.get('NAME')))
       line=line.replace('CHANNELS="{}"'.format(attribs.get('CHANNELS')),'CHANNELS="{}"'.format(attribs.get('CHANNELS').split('/')[0]))
     elif attribs.get('TYPE')=='SUBTITLES':
      continue
    elif line.startswith('#EXT-X-STREAM-INF'):
     attribs=self.Disney_MediaLine_Parse(line,'#EXT-X-STREAM-INF')
     if attribs.get('AUDIO')in Remove_AudioList:
      Skip_NextLine=KvSpyomJQatdMFgOzHfDWrTukscliV
      continue
     if attribs.get('RESOLUTION')!=max_resStr and playOption['maxResolution']:
      Skip_NextLine=KvSpyomJQatdMFgOzHfDWrTukscliV
      continue
    res_lines.append(line)
  except KvSpyomJQatdMFgOzHfDWrTukscliY as exception:
   KvSpyomJQatdMFgOzHfDWrTuksclij(exception)
   return KvSpyomJQatdMFgOzHfDWrTukscliq
  return_value='\n'.join(res_lines)
  try:
   fp=KvSpyomJQatdMFgOzHfDWrTuksclib(self.DZ_M3U8_FILENAME,'w',-1,'utf-8')
   fp.write(return_value)
   fp.close()
  except:
   if os.path.isfile(self.DZ_M3U8_FILENAME): 
    os.remove(self.DZ_M3U8_FILENAME)
   return KvSpyomJQatdMFgOzHfDWrTuksclin
 def DecodedFamilyId(self,familyId):
  url =self.Make_Endpoint('VIDEO_BUNDLE',encodedFamilyId=familyId)
  response=self.HttpObj.Call_Request(url,params=KvSpyomJQatdMFgOzHfDWrTukscliq,headers=KvSpyomJQatdMFgOzHfDWrTukscliq,method='GET')
  if response.status_code!=200:return KvSpyomJQatdMFgOzHfDWrTukscliq
  resJson=response.json().get('data').get('DmcVideoBundle').get('video')
  return resJson.get('contentId')
 def GetBookmarkInfo2(self,videoid,vidtype):
  VIDEO_INFO={'indexinfo':{'ott':'disney','videoid':videoid,'vidtype':vidtype,'entityId':'',},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  url ='{}/{}/page/{}'.format(self.API_DOMAIN_NEW,self.API_VERSION_NEW,videoid)
  headers=self.Make_Headers(accessToken=KvSpyomJQatdMFgOzHfDWrTukscliV,Bearer=KvSpyomJQatdMFgOzHfDWrTukscliV)
  params ={'disableSmartFocus':KvSpyomJQatdMFgOzHfDWrTukscliV,'enhancedContainersLimit':15,'limit':15,}
  response=self.HttpObj.Call_Request(url,headers=headers,params=params,method='GET')
  if response.status_code not in[200,201]:return[]
  resJson=response.json().get('data').get('page')
  VIDEO_INFO['indexinfo']['entityId']=resJson.get('deeplinkId')
  tmp_title=resJson['visuals']['title']
  tmp_year =resJson['visuals']['metastringParts']['releaseYearRange']['startYear']
  VIDEO_INFO['saveinfo']['infoLabels']['title']=tmp_title
  if vidtype=='movie':
   tmp_title='%s (%s)'%(tmp_title,tmp_year)
  VIDEO_INFO['saveinfo']['title'] =tmp_title
  VIDEO_INFO['saveinfo']['infoLabels']['year']=tmp_year
  VIDEO_INFO['saveinfo']['infoLabels']['mpaa']=resJson['visuals']['metastringParts']['ratingInfo']['rating']['text']
  VIDEO_INFO['saveinfo']['infoLabels']['plot']=resJson['visuals']['description']['full']
  if vidtype=='movie':
   VIDEO_INFO['saveinfo']['infoLabels']['duration']=KvSpyomJQatdMFgOzHfDWrTukscliR(resJson['visuals']['metastringParts']['runtime']['runtimeMs']/1000)
  for i_genre in resJson['visuals']['metastringParts']['genres']['values']:
   VIDEO_INFO['saveinfo']['infoLabels']['genre'].append(i_genre)
  for i_container in resJson['containers']:
   if i_container['type']!='details':continue
   for i_credit in i_container['visuals']['credits']:
    if i_credit['heading'].startswith('감독'):
     for i_item in i_credit['items']:
      VIDEO_INFO['saveinfo']['infoLabels']['director'].append(i_item['displayText'])
    if i_credit['heading'].startswith('출연'):
     for i_item in i_credit['items']:
      VIDEO_INFO['saveinfo']['infoLabels']['cast'].append(i_item['displayText'])
  imageJson=resJson['visuals']['artwork']['standard']
  poster =self.Get_imageurl_parser2(imageJson,['tile'],['0.75','0.71','0.67'])
  clearlogo=self.Get_imageurl_parser2(imageJson,['title_treatment'],['1.78'])
  thumb =self.Get_imageurl_parser2(imageJson,['tile'],['1.78','1.33'])
  fanart =self.Get_imageurl_parser2(imageJson,['background'],['1.78','1.33'])
  VIDEO_INFO['saveinfo']['thumbnail']['poster']=poster
  VIDEO_INFO['saveinfo']['thumbnail']['thumb']=thumb
  VIDEO_INFO['saveinfo']['thumbnail']['clearlogo']=clearlogo
  VIDEO_INFO['saveinfo']['thumbnail']['fanart'] =fanart
  return VIDEO_INFO
 def Get_DeepLink_PageId(self,pageType):
  pageId=''
  try:
   url ='{}/{}/deeplink?refId={}&refIdType=deeplinkId'.format(self.API_DOMAIN_NEW,self.API_VERSION_NEW,pageType)
   headers=self.Make_Headers(accessToken=KvSpyomJQatdMFgOzHfDWrTukscliV,Bearer=KvSpyomJQatdMFgOzHfDWrTukscliV)
   response=self.HttpObj.Call_Request(url,headers=headers,method='GET')
   if response.status_code not in[200,201]:return[]
   pageId=response.json().get('data').get('deeplink').get('actions')[0].get('pageId')
  except KvSpyomJQatdMFgOzHfDWrTukscliY as exception:
   KvSpyomJQatdMFgOzHfDWrTuksclij(exception)
   return ''
  return pageId
 def Get_Catagory_Group(self,pageType):
  catagory_list=[]
  pageId=self.Get_DeepLink_PageId(pageType)
  KvSpyomJQatdMFgOzHfDWrTuksclij('pageId : '+pageId)
  try:
   url ='{}/{}/page/{}'.format(self.API_DOMAIN_NEW,self.API_VERSION_NEW,pageId)
   headers=self.Make_Headers(accessToken=KvSpyomJQatdMFgOzHfDWrTukscliV,Bearer=KvSpyomJQatdMFgOzHfDWrTukscliV)
   params ={'limit':48,'disableSmartFocus':KvSpyomJQatdMFgOzHfDWrTukscliV,'enhancedContainersLimit':0,}
   response=self.HttpObj.Call_Request(url,headers=headers,params=params,method='GET')
   if response.status_code not in[200,201]:return[]
   resJson=response.json()['data']['page']
   for iContainer in resJson.get('containers'):
    temp_list={'title':iContainer['visuals']['name'],'containerId':iContainer['id'],}
    catagory_list.append(temp_list)
  except KvSpyomJQatdMFgOzHfDWrTukscliY as exception:
   KvSpyomJQatdMFgOzHfDWrTuksclij(exception)
   return[]
  return catagory_list
 def Get_Container_List(self,pageType,pageId=''):
  container_list=[]
  if pageType=='brands':
   KvSpyomJQatdMFgOzHfDWrTukscliq
  else:
   pageId=self.Get_DeepLink_PageId(pageType)
  try:
   url ='{}/{}/page/{}?disableSmartFocus=true&enhancedContainersLimit=0&limit=15'.format(self.API_DOMAIN_NEW,self.API_VERSION_NEW,pageId)
   headers=self.Make_Headers(accessToken=KvSpyomJQatdMFgOzHfDWrTukscliV,Bearer=KvSpyomJQatdMFgOzHfDWrTukscliV)
   response=self.HttpObj.Call_Request(url,headers=headers,method='GET')
   if response.status_code not in[200,201]:return[]
   resJson=response.json()['data']['page']
   for iContainer in resJson.get('containers'):
    if 'params' not in iContainer:continue 
    temp_list={'title':iContainer['visuals']['name'],'containerId':iContainer['id'],}
    container_list.append(temp_list)
  except KvSpyomJQatdMFgOzHfDWrTukscliY as exception:
   KvSpyomJQatdMFgOzHfDWrTuksclij(exception)
   return[]
  return container_list
 def Get_Program_List(self,containerId,page_int):
  program_list=[]
  more_page =KvSpyomJQatdMFgOzHfDWrTuksclin
  try:
   url ='{}/{}/set/{}'.format(self.API_DOMAIN_NEW,self.API_VERSION_NEW,containerId)
   headers=self.Make_Headers(accessToken=KvSpyomJQatdMFgOzHfDWrTukscliV,Bearer=KvSpyomJQatdMFgOzHfDWrTukscliV)
   params ={'limit':self.ONE_PAGE,'offset':(page_int-1)*self.ONE_PAGE,}
   response=self.HttpObj.Call_Request(url,headers=headers,params=params,method='GET')
   if response.status_code not in[200,201]:return[]
   resJson=response.json()['data']['set']
   for iItem in resJson.get('items'):
    if 'seasonNumber' in iItem['visuals']:
     vType='tvshow'
     duration=0
    elif 'durationMs' in iItem['visuals']:
     vType='movie'
     duration=KvSpyomJQatdMFgOzHfDWrTukscliR(iItem['visuals']['durationMs']/1000)
    elif iItem['actions'][0]['pageId'].startswith('page-'):
     vType='collection'
     duration=0
    else:
     vType='tvshow'
     duration=0
    genre_list=[]
    year=0
    mpaa=''
    if 'metastringParts' in iItem['visuals']:
     if 'genres' in iItem['visuals']['metastringParts']:
      for igenre in iItem['visuals']['metastringParts']['genres']['values']:
       genre_list.append(igenre)
     if 'releaseYearRange' in iItem['visuals']['metastringParts']:
      year=iItem['visuals']['metastringParts']['releaseYearRange']['startYear']
      if 'ratingInfo' in iItem['visuals']['metastringParts']:
       mpaa=iItem['visuals']['metastringParts']['ratingInfo']['rating']['text']
    desc=''
    if 'description' in iItem['visuals']:
     desc=iItem['visuals']['description']['full']
    imageJson=iItem['visuals']['artwork']['standard']
    poster =self.Get_imageurl_parser2(imageJson,['tile'],['0.75','0.71','0.67'])
    clearlogo=self.Get_imageurl_parser2(imageJson,['title_treatment'],['1.78'])
    thumb =self.Get_imageurl_parser2(imageJson,['tile'],['1.78','1.33'])
    fanart =self.Get_imageurl_parser2(imageJson,['background','tile'],['1.78','1.33'])
    tempActions =[]
    delInfoBlock=''
    if KvSpyomJQatdMFgOzHfDWrTukscliA(iItem['actions'])>1:
     for iEliment in iItem['actions']:
      if 'actions' in iEliment:
       tempActions=iEliment
       break
     if tempActions['actions']:
      for iAction in tempActions['actions']:
       if iAction['visuals']['displayText']=='삭제':
        delInfoBlock=iAction['infoBlock']
        break
    temp_list={'title':iItem['visuals']['title'],'entityId':iItem['actions'][0]['pageId'],'vType':vType,'genre':genre_list,'synopsis':desc,'duration':duration,'mpaa':mpaa,'year':year,'thumbnail':{'poster':poster,'thumb':thumb,'clearlogo':clearlogo,'fanart':fanart},'delInfoBlock':delInfoBlock,}
    program_list.append(temp_list)
   more_page=resJson['pagination']['hasMore']
  except KvSpyomJQatdMFgOzHfDWrTukscliY as exception:
   KvSpyomJQatdMFgOzHfDWrTuksclij(exception)
   return[],KvSpyomJQatdMFgOzHfDWrTuksclin
  return program_list,more_page 
 def Image_IdtoUrl(self,imageId):
  imageServer='https://disney.images.edge.bamgrid.com'
  imageUrl ='{}/ripcut-delivery/v2/variant/disney/{}/compose'.format(imageServer,imageId)
  return imageUrl
 def entityId_to_contentId(self,entityId):
  contentId=''
  try:
   url ='{}/{}/page/{}'.format(self.API_DOMAIN_NEW,self.API_VERSION_NEW,entityId)
   headers=self.Make_Headers(accessToken=KvSpyomJQatdMFgOzHfDWrTukscliV,Bearer=KvSpyomJQatdMFgOzHfDWrTukscliV)
   params ={'disableSmartFocus':KvSpyomJQatdMFgOzHfDWrTukscliV,'enhancedContainersLimit':self.ONE_PAGE,'limit':self.ONE_PAGE,}
   response=self.HttpObj.Call_Request(url,headers=headers,params=params,method='GET')
   if response.status_code not in[200,201]:return[]
   resJson=response.json()['data']['page']
   contentId=resJson['actions'][0]['partnerFeed']['dmcContentId']
  except KvSpyomJQatdMFgOzHfDWrTukscliY as exception:
   KvSpyomJQatdMFgOzHfDWrTuksclij(exception)
   return ''
  return contentId
# Created by pyminifier (https://github.com/liftoff/pyminifier)
