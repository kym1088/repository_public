__author__="NightRain"
ElDdayMkzqHjhsbQWLCpAxvcGfmgTP=object
ElDdayMkzqHjhsbQWLCpAxvcGfmgTR=True
ElDdayMkzqHjhsbQWLCpAxvcGfmgTr=False
ElDdayMkzqHjhsbQWLCpAxvcGfmgTV=int
ElDdayMkzqHjhsbQWLCpAxvcGfmgTI=None
ElDdayMkzqHjhsbQWLCpAxvcGfmgTO=str
import inputstreamhelper
import sys
from kodiFunc import*
from disneyCore import*
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
MAIN_GROUP=[{'title':'홈','mode':'COLLECTION_GROUP','icon':'home.png','values':{'contentClass':'home','contentSlugs':'home'}},{'title':'브랜드별','mode':'BRAND_GROUP'},{'title':'오리지널','mode':'COLLECTION_GROUP','values':{'contentClass':'originals','contentSlugs':'originals'}},{'title':'영화','mode':'COLLECTION_GROUP','values':{'contentClass':'contentType','contentSlugs':'movies'}},{'title':'시리즈','mode':'COLLECTION_GROUP','values':{'contentClass':'contentType','contentSlugs':'series'}},{'title':'-----------------','mode':'XXX','values':{}},{'title':'Watched (시청목록)','mode':'WATCHED_LIST','icon':'history.png','values':{'vType':'-'}},{'title':'(디즈니) 검색','mode':'LOCAL_SEARCH_LIST','icon':'search.png','values':{}},{'title':'(디즈니) 검색기록','mode':'LOCAL_SEARCH_HIST','icon':'search_history.png','values':{}},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플)','mode':'TOTAL_SEARCH','icon':'search.png','values':{}},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png','values':{}},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png','values':{}},]
WATCH_GROUP=[{'title':'영화 시청내역','mode':'WATCHED_LIST','values':{'vType':'movie'}},{'title':'시리즈 시청내역','mode':'WATCHED_LIST','values':{'vType':'tvshow'}},]
class ElDdayMkzqHjhsbQWLCpAxvcGfmgTB(ElDdayMkzqHjhsbQWLCpAxvcGfmgTP):
 def __init__(self,in_addonurl,in_handle,in_params,in_resume):
  self.ADDON_URL =in_addonurl
  self.ADDON_HANDLE =in_handle
  self.MAIN_PARAMS =in_params
  self.PLAY_RESUME =in_resume 
  self.KFuncObj =KodiFunc(in_addonurl,in_handle)
  self.DisneyObj =BdqeLUHPEgNzyicMlmaCOvtspbFVTS() 
  self.DisneyObj.DZ_COOKIES_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'dz_cookies.json'))
  self.DisneyObj.DZ_SEARCHED_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'dz_searched.json'))
  self.DisneyObj.DZ_WATCHED_MOVIE =xbmcvfs.translatePath(os.path.join(__profile__,'dz_watched_movie.json'))
  self.DisneyObj.DZ_WATCHED_VOD =xbmcvfs.translatePath(os.path.join(__profile__,'dz_watched_vod.json'))
  self.DisneyObj.DZ_GENRE_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'dz_genre.json'))
  self.DisneyObj.DZ_VTT_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'dz_subtitles.vtt'))
  self.DisneyObj.DZ_M3U8_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'dz_play.m3u8'))
  self.DisneyObj.DZ_TEMP_JSON =xbmcvfs.translatePath(os.path.join(__profile__,'dz_temp.json'))
  if xbmc.getCondVisibility('system.platform.android'):
   self.DisneyObj.OS_ANDROID=ElDdayMkzqHjhsbQWLCpAxvcGfmgTR
 def get_settings_totalsearch(self):
  local_search =ElDdayMkzqHjhsbQWLCpAxvcGfmgTR if __addon__.getSetting('local_search')=='true' else ElDdayMkzqHjhsbQWLCpAxvcGfmgTr
  local_history=ElDdayMkzqHjhsbQWLCpAxvcGfmgTR if __addon__.getSetting('local_history')=='true' else ElDdayMkzqHjhsbQWLCpAxvcGfmgTr
  total_search =ElDdayMkzqHjhsbQWLCpAxvcGfmgTR if __addon__.getSetting('total_search')=='true' else ElDdayMkzqHjhsbQWLCpAxvcGfmgTr
  total_history=ElDdayMkzqHjhsbQWLCpAxvcGfmgTR if __addon__.getSetting('total_history')=='true' else ElDdayMkzqHjhsbQWLCpAxvcGfmgTr
  menu_bookmark=ElDdayMkzqHjhsbQWLCpAxvcGfmgTR if __addon__.getSetting('menu_bookmark')=='true' else ElDdayMkzqHjhsbQWLCpAxvcGfmgTr
  return(local_search,local_history,total_search,total_history,menu_bookmark)
 def get_settings_makebookmark(self):
  return ElDdayMkzqHjhsbQWLCpAxvcGfmgTR if __addon__.getSetting('make_bookmark')=='true' else ElDdayMkzqHjhsbQWLCpAxvcGfmgTr
 def get_settings_account(self):
  dzid=__addon__.getSetting('id')
  dzpw=__addon__.getSetting('pw')
  dzpf=ElDdayMkzqHjhsbQWLCpAxvcGfmgTV(__addon__.getSetting('profile'))
  return(dzid,dzpw,dzpf)
 def get_settings_proxyport(self):
  return ElDdayMkzqHjhsbQWLCpAxvcGfmgTV(__addon__.getSetting('proxyPort'))
 def get_settings_proxyyn(self):
  return ElDdayMkzqHjhsbQWLCpAxvcGfmgTR if __addon__.getSetting('proxyyn')=='true' else ElDdayMkzqHjhsbQWLCpAxvcGfmgTr
 def get_settings_playback(self):
  DrmLevel=self.KFuncObj.Get_Drm_Level()
  res_list={'0':1920,'1':2560,'2':3840}
  playOption={'wv_secure':ElDdayMkzqHjhsbQWLCpAxvcGfmgTR,'video_h265':ElDdayMkzqHjhsbQWLCpAxvcGfmgTR if __addon__.getSetting('video_h265')=='true' else ElDdayMkzqHjhsbQWLCpAxvcGfmgTr,'video_hdr':ElDdayMkzqHjhsbQWLCpAxvcGfmgTR if __addon__.getSetting('video_hdr')=='true' else ElDdayMkzqHjhsbQWLCpAxvcGfmgTr,'video_dolby':ElDdayMkzqHjhsbQWLCpAxvcGfmgTR if __addon__.getSetting('video_dolby')=='true' else ElDdayMkzqHjhsbQWLCpAxvcGfmgTr,'maxResolution':res_list.get(__addon__.getSetting('maxResolution')),'sound_aac':ElDdayMkzqHjhsbQWLCpAxvcGfmgTR if __addon__.getSetting('sound_aac')=='true' else ElDdayMkzqHjhsbQWLCpAxvcGfmgTr,'sound_dd':ElDdayMkzqHjhsbQWLCpAxvcGfmgTR if __addon__.getSetting('sound_dd')=='true' else ElDdayMkzqHjhsbQWLCpAxvcGfmgTr,'sound_atmos':ElDdayMkzqHjhsbQWLCpAxvcGfmgTR if __addon__.getSetting('sound_atmos')=='true' else ElDdayMkzqHjhsbQWLCpAxvcGfmgTr,'vttFilename':self.DisneyObj.DZ_VTT_FILENAME,'m3u8Filename':self.DisneyObj.DZ_M3U8_FILENAME,'play_resume':self.PLAY_RESUME,}
  if playOption['wv_secure']==ElDdayMkzqHjhsbQWLCpAxvcGfmgTr or playOption['video_h265']==ElDdayMkzqHjhsbQWLCpAxvcGfmgTr:
   playOption['sound_atmos']=ElDdayMkzqHjhsbQWLCpAxvcGfmgTr
   playOption['video_hdr']=ElDdayMkzqHjhsbQWLCpAxvcGfmgTr
   playOption['video_dolby']=ElDdayMkzqHjhsbQWLCpAxvcGfmgTr
   playOption['maxResolution']=res_list.get('0')
  if not playOption['sound_aac']and not playOption['sound_dd']and not playOption['sound_atmos']:
   playOption['sound_aac']=ElDdayMkzqHjhsbQWLCpAxvcGfmgTR
  return playOption
 def Searched_Save(self,sKey):
  HistoryFile_Insert(self.DisneyObj.DZ_SEARCHED_FILENAME,sKey)
 def Searched_Load(self):
  return HistoryFile_Load(self.DisneyObj.DZ_SEARCHED_FILENAME)
 def Searched_Remove(self,delType,sKey='-'):
  if delType=='ALL':
   File_Delete(self.DisneyObj.DZ_SEARCHED_FILENAME)
  else:
   HistoryFile_Remove(self.DisneyObj.DZ_SEARCHED_FILENAME,sKey=sKey)
 def Watched_Save(self,vType,sKey,sValue):
  if vType=='movie':fileName=self.DisneyObj.DZ_WATCHED_MOVIE
  else: fileName=self.DisneyObj.DZ_WATCHED_VOD
  HistoryFile_Insert(fileName,sKey,sValue=sValue)
 def Watched_Load(self,vType):
  if vType=='movie':fileName=self.DisneyObj.DZ_WATCHED_MOVIE
  else: fileName=self.DisneyObj.DZ_WATCHED_VOD
  return HistoryFile_Load(fileName)
 def Watched_Remove(self,delType,vType,sKey='-'):
  if vType=='movie':fileName=self.DisneyObj.DZ_WATCHED_MOVIE
  else: fileName=self.DisneyObj.DZ_WATCHED_VOD
  if delType=='ALL':
   File_Delete(fileName)
  else:
   HistoryFile_Remove(fileName,sKey=sKey)
 def dp_Local_SearchHist(self,argsValue):
  SEARCH_HISTORY=self.Searched_Load()
  for search_history in SEARCH_HISTORY:
   sKey =search_history.get('sKey')
   params={'mode':'LOCAL_SEARCH_LIST','values':{'search_key':sKey,}}
   menu_param={'mode':'LOCAL_SEARCH_REMOVE','values':{'delType':'SEARCH_ONE','sKey':sKey,}}
   menu_param_str=Params_JsonToStr(menu_param)
   ContextMenu=[('선택된 검색어 ( %s ) 삭제'%(sKey),'RunPlugin(plugin://plugin.video.disneym/?params=%s)'%(menu_param_str))]
   infoLabels={'plot':'개별삭제는 팝업메뉴 사용'}
   self.KFuncObj.Add_Dir(sKey,subTitle='',img=ElDdayMkzqHjhsbQWLCpAxvcGfmgTI,infoLabels=infoLabels,isType='FOLDER',ContextMenu=ContextMenu,params=params)
  infoLabels={'plot':'검색목록 전체를 삭제합니다.'}
  title ='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  params={'mode':'LOCAL_SEARCH_REMOVE','values':{'delType':'SEARCH_ALL','sKey':'-',}}
  icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  self.KFuncObj.Add_Dir(title,subTitle='',img=icon_img,infoLabels=infoLabels,isType='FOLDER',ContextMenu=ElDdayMkzqHjhsbQWLCpAxvcGfmgTI,params=params)
  xbmcplugin.endOfDirectory(self.ADDON_HANDLE,cacheToDisc=ElDdayMkzqHjhsbQWLCpAxvcGfmgTr)
 def dp_Watched_List(self,argsValue):
  vType=argsValue.get('vType')
  if vType=='-':
   for watch_group in WATCH_GROUP:
    title=watch_group.get('title')
    params={'mode':watch_group.get('mode'),'values':watch_group.get('values'),}
    self.KFuncObj.Add_Dir(title,subTitle='',img=ElDdayMkzqHjhsbQWLCpAxvcGfmgTI,infoLabels=ElDdayMkzqHjhsbQWLCpAxvcGfmgTI,isType='FOLDER',ContextMenu=ElDdayMkzqHjhsbQWLCpAxvcGfmgTI,params=params)
   xbmcplugin.endOfDirectory(self.ADDON_HANDLE,cacheToDisc=ElDdayMkzqHjhsbQWLCpAxvcGfmgTR)
  else:
   WATCHLIST=self.Watched_Load(vType)
   for watchlist in WATCHLIST:
    sKey =watchlist.get('sKey')
    sValue =watchlist.get('sValue')
    title =sValue.get('title')
    programTitle=sValue.get('programTitle')
    contentId =sValue.get('contentId')
    encodedId =sValue.get('encodedId')
    image =sValue.get('image')
    infoLabels =sValue.get('infoLabels')
    contentClass=sValue.get('contentClass')
    contentSlugs=sValue.get('contentSlugs')
    vType =sValue.get('vType') 
    if vType=='movie':
     params={'mode':'MOVIE','values':{'contentId':contentId,'title':title,'image':image,'infoLabels':infoLabels,'vType':vType,}}
     isType='VOD'
     disTitle=title
     disSub =''
    else:
     params={'mode':'PROGRAM_LIST' if vType=='single' else 'SEASON_LIST','values':{'encodedId':encodedId,'contentClass':contentClass,'contentSlugs':contentSlugs,'programTitle':programTitle,'title':title,'image':image,'infoLabels':infoLabels,'vType':vType,}}
     isType='FOLDER'
     if vType=='single':
      disTitle=title
      disSub ='' 
     else:
      disTitle=programTitle
      disSub =title 
    menu_param={'mode':'WATCHED_REMOVE','values':{'delType':'WATCH_ONE','sKey':sKey,'vType':vType,}}
    menu_param_str=Params_JsonToStr(menu_param)
    ContextMenu=[('선택된 시청이력 ( %s ) 삭제'%(disTitle),'RunPlugin(plugin://plugin.video.disneym/?params=%s)'%(menu_param_str))]
    self.KFuncObj.Add_Dir(disTitle,subTitle=disSub,img=image,infoLabels=infoLabels,isType=isType,ContextMenu=ContextMenu,params=params)
   infoLabels={'plot':'검색목록 전체를 삭제합니다.'}
   title ='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   params={'mode':'WATCHED_REMOVE','values':{'delType':'WATCH_ALL','sKey':'-','vType':vType,}}
   icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
   self.KFuncObj.Add_Dir(title,subTitle='',img=icon_img,infoLabels=infoLabels,isType='FOLDER',ContextMenu=ElDdayMkzqHjhsbQWLCpAxvcGfmgTI,params=params)
   xbmcplugin.setContent(self.ADDON_HANDLE,'movies')
   xbmcplugin.endOfDirectory(self.ADDON_HANDLE,cacheToDisc=ElDdayMkzqHjhsbQWLCpAxvcGfmgTr)
 def dp_History_Remove(self,argsValue):
  delType=argsValue.get('delType')
  sKey =argsValue.get('sKey')
  vType =argsValue.get('vType')
  dialog=xbmcgui.Dialog()
  if delType=='SEARCH_ALL':
   ret=dialog.yesno(__language__(30911).encode('utf8'),__language__(30903).encode('utf8'))
  elif delType=='SEARCH_ONE':
   ret=dialog.yesno(__language__(30912).encode('utf8'),__language__(30903).encode('utf8'))
  elif delType=='WATCH_ALL':
   ret=dialog.yesno(__language__(30913).encode('utf8'),__language__(30903).encode('utf8'))
  elif delType=='WATCH_ONE':
   ret=dialog.yesno(__language__(30914).encode('utf8'),__language__(30903).encode('utf8'))
  if ret==ElDdayMkzqHjhsbQWLCpAxvcGfmgTr:sys.exit()
  if delType=='SEARCH_ALL':
   self.Searched_Remove('ALL',sKey='-')
  elif delType=='SEARCH_ONE':
   self.Searched_Remove('ONE',sKey=sKey)
  elif delType=='WATCH_ALL':
   self.Watched_Remove('ALL',vType=vType,sKey='-')
  elif delType=='WATCH_ONE':
   self.Watched_Remove('ONE',vType=vType,sKey=sKey)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Main_List(self):
  (local_search,local_history,total_search,total_history,menu_bookmark)=self.get_settings_totalsearch()
  for main_group in MAIN_GROUP:
   if main_group.get('mode')=='LOCAL_SEARCH' and local_search ==ElDdayMkzqHjhsbQWLCpAxvcGfmgTr:continue
   elif main_group.get('mode')=='SEARCH_HISTORY' and local_history==ElDdayMkzqHjhsbQWLCpAxvcGfmgTr:continue
   elif main_group.get('mode')=='TOTAL_SEARCH' and total_search ==ElDdayMkzqHjhsbQWLCpAxvcGfmgTr:continue
   elif main_group.get('mode')=='TOTAL_HISTORY' and total_history==ElDdayMkzqHjhsbQWLCpAxvcGfmgTr:continue
   elif main_group.get('mode')=='MENU_BOOKMARK' and menu_bookmark==ElDdayMkzqHjhsbQWLCpAxvcGfmgTr:continue
   title =main_group.get('title')
   icon_img=ElDdayMkzqHjhsbQWLCpAxvcGfmgTI
   params={'mode':main_group.get('mode'),'values':main_group.get('values'),}
   if main_group.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    isType ='LINK' 
   else:
    isType ='FOLDER' 
   infoLabels={'title':title,'plot':title}
   if main_group.get('mode')=='XXX':infoLabels=ElDdayMkzqHjhsbQWLCpAxvcGfmgTI
   if 'icon' in main_group:icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',main_group.get('icon')) 
   self.KFuncObj.Add_Dir(title,subTitle='',img=icon_img,infoLabels=infoLabels,isType=isType,ContextMenu=ElDdayMkzqHjhsbQWLCpAxvcGfmgTI,params=params)
  xbmcplugin.endOfDirectory(self.ADDON_HANDLE)
 def login_main(self):
  (dzid,dzpw,dzpf)=self.get_settings_account()
  if dzid=='' or dzpw=='':
   dialog=xbmcgui.Dialog()
   ret=dialog.yesno(__language__(30921).encode('utf8'),__language__(30922).encode('utf8'))
   if ret==ElDdayMkzqHjhsbQWLCpAxvcGfmgTR:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if self.cookiefile_check()==ElDdayMkzqHjhsbQWLCpAxvcGfmgTR:
   if Get_TimeStamp()>self.DisneyObj.DZ['account']['token_limit']:
    if self.DisneyObj.DZ_Login_ReToken()==ElDdayMkzqHjhsbQWLCpAxvcGfmgTr:
     self.KFuncObj.Addon_Noti(__language__(30923).encode('utf8'))
     sys.exit()
  else:
   if self.DisneyObj.DZ_Login_Main(dzid,dzpw,dzpf)==ElDdayMkzqHjhsbQWLCpAxvcGfmgTr:
    self.KFuncObj.Addon_Noti(__language__(30923).encode('utf8'))
    sys.exit()
 def cookiefile_check(self):
  self.DisneyObj.DZ=JsonFile_Load(self.DisneyObj.DZ_COOKIES_FILENAME)
  (cf_id,cf_pw,cf_pf)=self.get_settings_account()
  (ck_id,ck_pw,ck_pf)=self.DisneyObj.Load_session_acount()
  if cf_id!=ck_id or cf_pw!=ck_pw or cf_pf!=ck_pf:
   self.DisneyObj.Init_DZ_Total()
   return ElDdayMkzqHjhsbQWLCpAxvcGfmgTr
  return ElDdayMkzqHjhsbQWLCpAxvcGfmgTR
 def DZ_logout(self):
  dialog=xbmcgui.Dialog()
  ret=dialog.yesno(__language__(30925).encode('utf8'),__language__(30903).encode('utf8'))
  if ret==ElDdayMkzqHjhsbQWLCpAxvcGfmgTr:return 
  File_Delete(self.DisneyObj.DZ_COOKIES_FILENAME)
  self.KFuncObj.Addon_Noti(__language__(30924).encode('utf-8'))
 def dp_Collection_Group(self,argsValue):
  contentClass=argsValue.get('contentClass')
  contentSlugs=argsValue.get('contentSlugs')
  RES_LIST=self.DisneyObj.Get_Collection_Group(contentClass,contentSlugs)
  for i_res in RES_LIST:
   title =i_res.get('title')
   refId =i_res.get('refId')
   refType=i_res.get('refType')
   infoLabels={'mediatype':'tvshow','plot':title,}
   params={'mode':'PROGRAM_LIST','values':{'refId':refId,'refType':refType,'page_int':1,'page_Size':self.DisneyObj.ONE_PAGE}}
   self.KFuncObj.Add_Dir(title,subTitle='',img=ElDdayMkzqHjhsbQWLCpAxvcGfmgTI,infoLabels=infoLabels,isType='FOLDER',ContextMenu=ElDdayMkzqHjhsbQWLCpAxvcGfmgTI,params=params)
  xbmcplugin.setContent(self.ADDON_HANDLE,'genres')
  xbmcplugin.endOfDirectory(self.ADDON_HANDLE,cacheToDisc=ElDdayMkzqHjhsbQWLCpAxvcGfmgTR)
 def dp_Brand_Six(self):
  RES_LIST=self.DisneyObj.Get_Brand_List()
  for i_res in RES_LIST:
   contentClass =i_res.get('contentClass')
   contentSlugs =i_res.get('contentSlugs')
   contentName =i_res.get('contentName')
   image ={'poster':i_res.get('thumb'),'fanart':i_res.get('poster'),'thumb':i_res.get('poster'),}
   infoLabels={'mediatype':'tvshow','plot':contentName,}
   params={'mode':'COLLECTION_GROUP','values':{'contentClass':contentClass,'contentSlugs':contentSlugs,}}
   self.KFuncObj.Add_Dir(contentName,subTitle='',img=image,infoLabels=infoLabels,isType='FOLDER',ContextMenu=ElDdayMkzqHjhsbQWLCpAxvcGfmgTI,params=params)
  xbmcplugin.setContent(self.ADDON_HANDLE,'genres')
  xbmcplugin.endOfDirectory(self.ADDON_HANDLE,cacheToDisc=ElDdayMkzqHjhsbQWLCpAxvcGfmgTR)
 def dp_Local_SearchList(self,argsValue):
  if 'search_key' in argsValue:
   search_key=argsValue.get('search_key')
  else:
   search_key=self.KFuncObj.Get_Keyboard_Input(__language__(30902).encode('utf-8'))
   if not search_key:
    return
   self.Searched_Save(search_key)
  RES_LIST=self.DisneyObj.Get_Search_List(search_key)
  for i_res in RES_LIST:
   title =i_res.get('title')
   vType =i_res.get('vType')
   encodedId =i_res.get('encodedId') 
   contentId =i_res.get('contentId') 
   contentClass=i_res.get('contentClass')
   contentSlugs=i_res.get('contentSlugs')
   year =i_res.get('year')
   duration =i_res.get('duration')
   aired =i_res.get('aired')
   image ={'poster':i_res.get('poster'),'fanart':i_res.get('thumb'),'thumb':i_res.get('thumb'),} 
   if vType in['tvshow']:
    mode ='SEASON_LIST'
    mediatype='tvshow'
    isType ='FOLDER'
   elif vType=='movie':
    mode ='MOVIE'
    mediatype='movie'
    isType ='VOD'
   elif vType=='collection':
    mode ='PROGRAM_LIST'
    mediatype='tvshow'
    isType ='FOLDER'
   else:
    mode ='-'
    isType ='FOLDER'
    title ='check '
   infoLabels={'mediatype':mediatype,'title':title,'duration':duration,'year':year,'aired':aired,'plot':vType,}
   params={'mode':mode,'values':{'programTitle':title,'title':title,'encodedId':encodedId,'contentId':contentId,'contentClass':contentClass,'contentSlugs':contentSlugs,'page_int':1,'page_Size':self.DisneyObj.COLLECTION_SIZE,'infoLabels':infoLabels,'image':image,'vType':vType,}}
   if self.get_settings_makebookmark():
    bm_param={'mode':'SET_BOOKMARK','values':{'videoid':encodedId,'vidtype':vType,'title':title,}}
    param_str=Params_JsonToStr(bm_param)
    param_str=param_str.replace('+','%2B')
    bookmark_url='RunPlugin(plugin://plugin.video.disneym/?params=%s)'%(param_str)
    ContextMenu=[('(통합) 찜 영상에 추가',bookmark_url)]
   else:
    ContextMenu=ElDdayMkzqHjhsbQWLCpAxvcGfmgTI
   self.KFuncObj.Add_Dir(title,subTitle='',img=image,infoLabels=infoLabels,isType=isType,ContextMenu=ContextMenu,params=params)
  xbmcplugin.setContent(self.ADDON_HANDLE,'tvshows')
  xbmcplugin.endOfDirectory(self.ADDON_HANDLE,cacheToDisc=ElDdayMkzqHjhsbQWLCpAxvcGfmgTR) 
 def dp_Programn_List(self,argsValue):
  refId =argsValue.get('refId')
  refType =argsValue.get('refType')
  page_int =argsValue.get('page_int')
  page_Size =argsValue.get('page_Size')
  baseClass =argsValue.get('contentClass')
  baseSlugs =argsValue.get('contentSlugs')
  programTitle=argsValue.get('programTitle')
  self.KFuncObj.Addon_Log('refId        : {}'.format(ElDdayMkzqHjhsbQWLCpAxvcGfmgTO(refId)))
  self.KFuncObj.Addon_Log('refType      : {}'.format(ElDdayMkzqHjhsbQWLCpAxvcGfmgTO(refType)))
  self.KFuncObj.Addon_Log('page_int     : {}'.format(ElDdayMkzqHjhsbQWLCpAxvcGfmgTO(page_int)))
  self.KFuncObj.Addon_Log('page_Size    : {}'.format(ElDdayMkzqHjhsbQWLCpAxvcGfmgTO(page_Size)))
  single=ElDdayMkzqHjhsbQWLCpAxvcGfmgTr
  if not refId:
   refId,refType=self.DisneyObj.Get_refId(baseClass,baseSlugs)
   page_int =1 
   page_Size=self.DisneyObj.COLLECTION_SIZE 
   single=ElDdayMkzqHjhsbQWLCpAxvcGfmgTR
  RES_LIST,more_page=self.DisneyObj.Get_Program_List(refId,refType,page_int,page_Size)
  for i_res in RES_LIST:
   title =i_res.get('title')
   vType =i_res.get('vType')
   encodedId =i_res.get('encodedId') 
   contentId =i_res.get('contentId') 
   contentClass=i_res.get('contentClass')
   contentSlugs=i_res.get('contentSlugs')
   year =i_res.get('year')
   duration =i_res.get('duration')
   aired =i_res.get('aired')
   image ={'poster':i_res.get('poster'),'fanart':i_res.get('thumb'),'thumb':i_res.get('thumb'),'clearlogo':i_res.get('clearlogo'),} 
   if vType=='tvshow':
    mode ='SEASON_LIST'
    mediatype='tvshow'
    isType ='FOLDER'
   elif vType=='movie':
    mode ='MOVIE'
    mediatype='movie'
    isType ='VOD'
   elif vType=='collection':
    mode ='PROGRAM_LIST'
    mediatype='tvshow'
    isType ='FOLDER'
   else:
    mode ='-'
    isType ='FOLDER'
    title ='check '
   infoLabels={'mediatype':mediatype,'title':title,'duration':duration,'year':year,'aired':aired,'plot':vType,}
   params={'mode':mode,'values':{'programTitle':programTitle if single else title,'title':title,'encodedId':encodedId,'contentId':contentId,'contentClass':baseClass if single else contentClass,'contentSlugs':baseSlugs if single else contentSlugs,'infoLabels':infoLabels,'image':image,'vType':'single' if single else vType,}}
   ContextMenu=[]
   if vType!='collection':
    bm_param={'mode':'VIEW_DETAIL','values':{'videoid':encodedId,'vidtype':vType,}}
    param_str=Params_JsonToStr(bm_param)
    param_str=param_str.replace('+','%2B')
    bookmark_url='RunPlugin(plugin://plugin.video.disneym/?params=%s)'%(param_str)
    ContextMenu.append(('상세정보 조회',bookmark_url))
   if self.get_settings_makebookmark():
    if vType=='collection':
     encodedId='{}_{}'.format(contentClass,contentSlugs)
     col_info =self.DisneyObj.GetBookmarkInfo(encodedId,vType)
     col_info['indexinfo']['contentClass']=contentClass
     col_info['indexinfo']['contentSlugs']=contentSlugs
     col_info['saveinfo']['title'] =title
     col_info['saveinfo']['infoLabels']['title']=title
     col_info['saveinfo']['thumbnail'] =image
    bm_param={'mode':'SET_BOOKMARK','values':{'videoid':encodedId,'vidtype':vType,'title':programTitle if single else title,'col_info':col_info if vType=='collection' else ElDdayMkzqHjhsbQWLCpAxvcGfmgTI,}}
    param_str=Params_JsonToStr(bm_param)
    param_str=param_str.replace('+','%2B')
    bookmark_url='RunPlugin(plugin://plugin.video.disneym/?params=%s)'%(param_str)
    ContextMenu.append(('(통합) 찜 영상에 추가',bookmark_url))
   self.KFuncObj.Add_Dir(title,subTitle='',img=image,infoLabels=infoLabels,isType=isType,ContextMenu=ContextMenu,params=params)
  if more_page:
   title ='[B]%s >>[/B]'%'다음 페이지'
   params={'mode':'PROGRAM_LIST','values':{'refId':refId,'refType':refType,'page_int':page_int+1,'page_Size':page_Size,}}
   subtitle=ElDdayMkzqHjhsbQWLCpAxvcGfmgTO(page_int+1)
   icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   self.KFuncObj.Add_Dir(title,subTitle=subtitle,img=icon_img,infoLabels=ElDdayMkzqHjhsbQWLCpAxvcGfmgTI,isType='FOLDER',ContextMenu=ElDdayMkzqHjhsbQWLCpAxvcGfmgTI,params=params)
  xbmcplugin.setContent(self.ADDON_HANDLE,'tvshows')
  xbmcplugin.endOfDirectory(self.ADDON_HANDLE,cacheToDisc=ElDdayMkzqHjhsbQWLCpAxvcGfmgTR)
 def dp_Season_List(self,argsValue):
  encodedId =argsValue.get('encodedId')
  programTitle=argsValue.get('programTitle')
  RES_LIST=self.DisneyObj.Get_Season_List(encodedId)
  for i_res in RES_LIST:
   seasonId =i_res.get('seasonId')
   seasonNum =i_res.get('seasonNum')
   episodeCnt =i_res.get('episodeCnt')
   year =i_res.get('year')
   aired =i_res.get('aired')
   desc =i_res.get('desc')
   image ={'poster':i_res.get('poster')}
   title ='{} : 시즌 {}'.format(programTitle,seasonNum)
   infoLabels={'mediatype':'season','year':year,'aired':aired,'plot':'에피소드 {}개\n\n{}'.format(episodeCnt,desc),}
   params={'mode':'EPISODE_LIST','values':{'seasonId':seasonId,'page_int':1,}}
   self.KFuncObj.Add_Dir(title,subTitle='',img=image,infoLabels=infoLabels,isType='FOLDER',ContextMenu=ElDdayMkzqHjhsbQWLCpAxvcGfmgTI,params=params)
  xbmcplugin.setContent(self.ADDON_HANDLE,'tvshows')
  xbmcplugin.endOfDirectory(self.ADDON_HANDLE,cacheToDisc=ElDdayMkzqHjhsbQWLCpAxvcGfmgTR)
 def dp_Episode_List(self,argsValue):
  seasonId =argsValue.get('seasonId')
  page_int =argsValue.get('page_int')
  RES_LIST,more_page=self.DisneyObj.Get_Episode_List(seasonId,page_int)
  for i_res in RES_LIST:
   contentId =i_res.get('contentId')
   title =i_res.get('title')
   tvshowtitle=i_res.get('tvshowtitle')
   desc =i_res.get('desc')
   duration =i_res.get('duration')
   year =i_res.get('year')
   aired =i_res.get('aired')
   seasonNum =i_res.get('seasonNum')
   episodeNum =i_res.get('episodeNum')
   encodedId =i_res.get('encodedId')
   image ={'fanart':i_res.get('fanart'),'thumb':i_res.get('thumb'),'poster':i_res.get('poster'),'clearlogo':i_res.get('clearlogo'),}
   infoLabels={'mediatype':'episode','title':title,'tvshowtitle':tvshowtitle,'plot':desc,'duration':duration,'year':year,'aired':aired,'season':seasonNum,'episode':episodeNum,}
   dis_title='{}x{:0>2}. {}'.format(seasonNum,episodeNum,title)
   params={'mode':'VOD','values':{'contentId':contentId,'title':dis_title,'programTitle':tvshowtitle,'encodedId':encodedId,'image':image,'infoLabels':infoLabels,'vType':'tvshow',}}
   self.KFuncObj.Add_Dir(dis_title,subTitle='',img=image,infoLabels=infoLabels,isType='VOD',ContextMenu=ElDdayMkzqHjhsbQWLCpAxvcGfmgTI,params=params)
  if more_page:
   title ='[B]%s >>[/B]'%'다음 페이지'
   params={'mode':'EPISODE_LIST','values':{'seasonId':seasonId,'page_int':page_int+1,}}
   subtitle=ElDdayMkzqHjhsbQWLCpAxvcGfmgTO(page_int+1)
   icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   self.KFuncObj.Add_Dir(title,subTitle=subtitle,img=icon_img,infoLabels=ElDdayMkzqHjhsbQWLCpAxvcGfmgTI,isType='FOLDER',ContextMenu=ElDdayMkzqHjhsbQWLCpAxvcGfmgTI,params=params)
  xbmcplugin.setContent(self.ADDON_HANDLE,'episodes')
  xbmcplugin.endOfDirectory(self.ADDON_HANDLE,cacheToDisc=ElDdayMkzqHjhsbQWLCpAxvcGfmgTR)
 def play_VIDEO(self,argsValue):
  playOption=self.get_settings_playback()
  contentId =argsValue.get('contentId')
  vType =argsValue.get('vType')
  if vType=='kinolight':
   contentId=self.DisneyObj.DecodedFamilyId(contentId)
  streamInfo =self.DisneyObj.GetStreamingURL(contentId,playOption)
  streamUrl =streamInfo.get('streamUrl')
  drmUrl =streamInfo.get('drmUrl')
  defaultAudio=streamInfo.get('defaultAudio')
  self.KFuncObj.Addon_Log('contentId    : {}'.format(contentId))
  self.KFuncObj.Addon_Log('streamUrl    : {}'.format(streamUrl))
  self.KFuncObj.Addon_Log('resume       : {}'.format(playOption.get('play_resume')))
  if streamUrl in['',ElDdayMkzqHjhsbQWLCpAxvcGfmgTI]:
   if drmUrl!='':
    self.KFuncObj.Addon_Noti(drmUrl)
   else:
    self.KFuncObj.Addon_Noti(__language__(30901).encode('utf8'))
   return
  raw_headers =self.DisneyObj.Make_Headers(accessToken=ElDdayMkzqHjhsbQWLCpAxvcGfmgTR,Bearer=ElDdayMkzqHjhsbQWLCpAxvcGfmgTr)
  raw_headers['content-type']='application/octet-stream'
  raw_headers['user-agent'] =self.DisneyObj.HttpObj.USER_AGENT
  LICENSE_KEY=drmUrl+'|'+urllib.parse.urlencode(raw_headers)+'|R{SSM}|'
  stream_headers=make_stream_header(raw_headers,ElDdayMkzqHjhsbQWLCpAxvcGfmgTI)
  proxyHeader={'addon':'disneym','defaultAudio':defaultAudio,'playOption':playOption,}
  proxyHeader=Params_JsonToStr(proxyHeader)
  self.KFuncObj.Addon_Log('proxyHeader    : {}'.format(proxyHeader))
  proxyPort =self.get_settings_proxyport()
  proxyUse =self.get_settings_proxyyn()
  if proxyUse:
   streamUrl='http://127.0.0.1:{}/{}|proxy-mini={}'.format(proxyPort,streamUrl,proxyHeader)
  self.KFuncObj.Addon_Log(streamUrl)
  item=xbmcgui.ListItem(path=streamUrl)
  inputstreamhelper.Helper('hls',drm='com.widevine.alpha').check_inputstream()
  item.setProperty('inputstream','inputstream.adaptive')
  if self.DisneyObj.KodiVersion<=20:
   item.setProperty('inputstream.adaptive.manifest_type','hls')
  item.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
  item.setProperty('inputstream.adaptive.license_key',LICENSE_KEY)
  item.setProperty('inputstream.adaptive.stream_headers',stream_headers)
  item.setProperty('inputstream.adaptive.manifest_headers',stream_headers)
  item.setProperty('inputstream.adaptive.original_audio_language',defaultAudio)
  item.setMimeType('application/x-mpegURL')
  item.setContentLookup(ElDdayMkzqHjhsbQWLCpAxvcGfmgTr)
  if proxyUse:
   item.setSubtitles([playOption['vttFilename']])
  xbmcplugin.setResolvedUrl(self.ADDON_HANDLE,ElDdayMkzqHjhsbQWLCpAxvcGfmgTR,item)
  try:
   if vType in['movie','tvshow','single']:
    if vType=='movie':
     sKey =contentId
     sValue={'contentId':contentId,'title':argsValue.get('title'),'image':argsValue.get('image'),'infoLabels':argsValue.get('infoLabels'),'vType':vType,}
    elif vType=='tvshow':
     argsValue['infoLabels']['mediatype']='tvshow'
     sKey=argsValue.get('encodedId')
     sValue={'encodedId':argsValue.get('encodedId'),'title':argsValue.get('title'),'programTitle':argsValue.get('programTitle'),'image':argsValue.get('image'),'infoLabels':argsValue.get('infoLabels'),'vType':vType,}
    elif vType=='single':
     argsValue['infoLabels']['mediatype']='tvshow'
     sKey='{}_{}'.format(argsValue.get('contentClass'),argsValue.get('contentSlugs'))
     sValue={'contentClass':argsValue.get('contentClass'),'contentSlugs':argsValue.get('contentSlugs'),'title':argsValue.get('title'),'programTitle':argsValue.get('programTitle'),'image':argsValue.get('image'),'infoLabels':argsValue.get('infoLabels'),'vType':'single',}
    self.Watched_Save(vType,sKey,sValue)
  except:
   ElDdayMkzqHjhsbQWLCpAxvcGfmgTI
 def DZ_ReToken(self):
  try:
   self.DisneyObj.DZ=JsonFile_Load(self.DisneyObj.DZ_COOKIES_FILENAME)
   if Get_TimeStamp()>self.DisneyObj.DZ['account']['token_limit']:
    if self.DisneyObj.DZ_Login_ReToken()==ElDdayMkzqHjhsbQWLCpAxvcGfmgTr:
     return ElDdayMkzqHjhsbQWLCpAxvcGfmgTr
  except:
   return ElDdayMkzqHjhsbQWLCpAxvcGfmgTr
  return ElDdayMkzqHjhsbQWLCpAxvcGfmgTR
 def dp_Global_Search(self,mode):
  if mode=='TOTAL_SEARCH':
   ott_url='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   ott_url='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(ott_url)
 def dp_Bookmark_Menu(self):
  ott_url='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(ott_url)
 def dp_Set_Bookmark(self,argsValue):
  videoid =argsValue.get('videoid')
  vidtype =argsValue.get('vidtype')
  title =argsValue.get('title')
  col_info =argsValue.get('col_info')
  dialog=xbmcgui.Dialog()
  ret=dialog.yesno(__language__(30915).encode('utf8'),title+' \n\n'+__language__(30916))
  if ret==ElDdayMkzqHjhsbQWLCpAxvcGfmgTr:return
  self.KFuncObj.Addon_Log('videoid = {}'.format(videoid))
  self.KFuncObj.Addon_Log('vidtype = {}'.format(vidtype))
  if vidtype=='collection':
   VIDEO_INFO=col_info
  else:
   VIDEO_INFO=self.DisneyObj.GetBookmarkInfo(videoid,vidtype)
  params={'mode':'SET_BOOKMARK','values':{'VIDEO_INFO':VIDEO_INFO,}}
  param_str=Params_JsonToStr(params)
  param_str=param_str.replace('+','%2B')
  bookmark_url ='RunPlugin(plugin://plugin.video.bookmarkm/?params=%s)'%(param_str)
  xbmc.executebuiltin(bookmark_url)
 def dp_View_Detail(self,argsValue):
  videoid =argsValue.get('videoid')
  vidtype =argsValue.get('vidtype')
  self.KFuncObj.Addon_Log('videoid = {}'.format(videoid))
  self.KFuncObj.Addon_Log('vidtype = {}'.format(vidtype))
  VIDEO_INFO=self.DisneyObj.GetBookmarkInfo(videoid,vidtype)
  if vidtype=='tvshow':
   ott_param={'mode':'SEASON_LIST','values':{'encodedId':VIDEO_INFO['indexinfo']['encodedId'],'vType':vidtype,'image':VIDEO_INFO['saveinfo']['thumbnail'],'title':VIDEO_INFO['saveinfo']['title'],'programTitle':VIDEO_INFO['saveinfo']['title'],'infoLabels':VIDEO_INFO['saveinfo']['infoLabels'],}} 
   ott_param_str=json.dumps(ott_param,separators=(',',':'))
   ott_param_str=base64.standard_b64encode(ott_param_str.encode()).decode('utf-8')
   ott_param_str=ott_param_str.replace('+','%2B')
   ott_url='plugin://plugin.video.disneym/?params=%s'%(ott_param_str)
  else:
   ott_param={'mode':'MOVIE','values':{'contentId':VIDEO_INFO['indexinfo']['contentId'],'vType':vidtype,'image':VIDEO_INFO['saveinfo']['thumbnail'],'title':VIDEO_INFO['saveinfo']['infoLabels']['title'],'programTitle':VIDEO_INFO['saveinfo']['infoLabels']['title'],'infoLabels':VIDEO_INFO['saveinfo']['infoLabels'],}}
   ott_param_str=json.dumps(ott_param,separators=(',',':'))
   ott_param_str=base64.standard_b64encode(ott_param_str.encode()).decode('utf-8')
   ott_param_str=ott_param_str.replace('+','%2B')
   ott_url='plugin://plugin.video.disneym/?params=%s'%(ott_param_str)
  listitem=xbmcgui.ListItem(label=VIDEO_INFO['saveinfo']['title'],path=ott_url)
  listitem.setArt(VIDEO_INFO['saveinfo']['thumbnail'])
  listitem.setInfo('Video',VIDEO_INFO['saveinfo']['infoLabels'])
  if vidtype=='movie':
   listitem.setIsFolder(ElDdayMkzqHjhsbQWLCpAxvcGfmgTr)
   listitem.setProperty('IsPlayable','true')
  else:
   listitem.setIsFolder(ElDdayMkzqHjhsbQWLCpAxvcGfmgTR)
   listitem.setProperty('IsPlayable','false')
  dialog=xbmcgui.Dialog()
  dialog.info(listitem)
 def disney_main(self):
  self.DisneyObj.KodiVersion=ElDdayMkzqHjhsbQWLCpAxvcGfmgTV(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  mode =ElDdayMkzqHjhsbQWLCpAxvcGfmgTI
  paramJson={}
  paramText=self.MAIN_PARAMS.get('params')
  if paramText:
   paramJson =Params_StrToJson(paramText)
   mode =paramJson.get('mode')
   argsValue =paramJson.get('values')
  if mode=='LOGOUT':
   self.DZ_logout()
   return
  elif mode=='CHECK_TOKEN':
   self.DZ_ReToken()
   return
  self.login_main()
  if mode is ElDdayMkzqHjhsbQWLCpAxvcGfmgTI:
   self.dp_Main_List()
  elif mode=='COLLECTION_GROUP':
   self.dp_Collection_Group(argsValue)
  elif mode=='BRAND_GROUP':
   self.dp_Brand_Six()
  elif mode=='PROGRAM_LIST':
   self.dp_Programn_List(argsValue)
  elif mode=='SEASON_LIST':
   self.dp_Season_List(argsValue)
  elif mode=='EPISODE_LIST':
   self.dp_Episode_List(argsValue)
  elif mode in['MOVIE','VOD']:
   self.play_VIDEO(argsValue)
  elif mode=='LOCAL_SEARCH_LIST':
   self.dp_Local_SearchList(argsValue)
  elif mode=='LOCAL_SEARCH_HIST':
   self.dp_Local_SearchHist(argsValue)
  elif mode in['LOCAL_SEARCH_REMOVE','WATCHED_REMOVE']:
   self.dp_History_Remove(argsValue)
  elif mode=='WATCHED_LIST':
   self.dp_Watched_List(argsValue)
  elif mode in['TOTAL_SEARCH','TOTAL_HISTORY']:
   self.dp_Global_Search(mode)
  elif mode=='MENU_BOOKMARK':
   self.dp_Bookmark_Menu()
  elif mode=='SET_BOOKMARK':
   self.dp_Set_Bookmark(argsValue)
  elif mode=='VIEW_DETAIL':
   self.dp_View_Detail(argsValue)
  else:
   ElDdayMkzqHjhsbQWLCpAxvcGfmgTI
# Created by pyminifier (https://github.com/liftoff/pyminifier)
